package com.optum.oadw

import com.optum.oap.parser.oracletohive.OracleToHiveParser
import scala.util.matching.Regex
import scala.io.Source
import better.files.{File => ScalaFile}

object ConvertIISqlToHQL {
  private val basePath = System.getProperty("user.dir")
  private val maxVarcharReplaceVal = 4000

  def main(args: Array[String]): Unit = {
    val sqlFilePath = s"$basePath/ii-schema/schema/ii811/II_v8.1.1_Schema.sql"
    val hqlFilePath = s"$basePath/ii-schema/schema/ii811/ii_external_schema.hql"
    val iiDataTypeMap = s"$basePath/ii-schema/schema/ii811/IIExternalDataTypeMap-8-1.1.txt"
    val oadwSchemaPath = s"$basePath/oadw-schema/src/main/resources/oadw_schema.hql"
    val iiSynonymsPath = s"$basePath/ii-schema/src/main/resources/ii/ii_synonyms-8-1.txt"
    convertSqlToHql(sqlFilePath, hqlFilePath, oadwSchemaPath, iiDataTypeMap, iiSynonymsPath)
  }

  private def getRenamedTable(statement: String, prefix: String, iiSynonymMap: Map[String, String]): String = {
    statement.split("\n").map(line => {
      if (line.toUpperCase.contains("CREATE EXTERNAL TABLE")) {
        val tableName = line.split('.')(1).replace("(", "").trim
        val synonym = if(iiSynonymMap.contains(tableName.toLowerCase)) prefix + iiSynonymMap(tableName.toLowerCase) else prefix + tableName.toLowerCase
        line.replace(tableName, synonym)
      } else {
        line
      }
    }).mkString("\n")
  }

  private def getTableName(statement: String): String = {
    statement.split("""\{\{db_name\}\}\.""")(1).trim.split("\\s+")(0).toLowerCase
  }

  private def cleanUpSql(sqlContent: String): String = {
    val withOutComments =
      sqlContent
        .split("\n")
        .map(line => if (line.trim.startsWith("--")) "" else line)
        .mkString("\n")

    withOutComments
      .split("GO\n")
      .map(sqlStatement => {
        val trimmedSqlStatement = sqlStatement.trim
        if (trimmedSqlStatement.toLowerCase.startsWith("create")) {
          val formattedStatement = trimmedSqlStatement
            .replace("[", "")
            .replace("]", "")
            .replaceAll("(?i)smalldatetime", "timestamp")
            .replaceAll("(?i)datetime", "timestamp")
            .replaceAll("(?i)smallint", "number(5)")
            .replaceAll("(?i)tinyint", "number(3)")
            .replaceAll("(?i)money", "number(19,4)")
            //.replaceAll("(?i)bit", "number(3)")
          formattedStatement + ";"
        } else {
          ""
        }
      }).mkString("\n")
  }

  private def findIIOverrides(oadwSchemaContent: String): Set[String] = {
    val iiPatern = new Regex("IF NOT EXISTS \\{\\{db_name\\}\\}\\.[t_]*l2_ii_\\w*\\s+")
    iiPatern.findAllIn(oadwSchemaContent).map(model => {
      model.trim.replaceAll("\\{\\{db_name\\}\\}.", "").stripPrefix("IF NOT EXISTS ").toLowerCase.stripPrefix("t_").stripPrefix("l2_ii_")
    }).toSet
  }

  private def saveToFile(filePath: String, content: String) = {
    val outputFile = ScalaFile(filePath)
    outputFile.createFileIfNotExists().overwrite("").appendLines(content)
  }

  private def getDataType(dataType: String, dataTypeArgList: Seq[String]): String = {
    if (dataTypeArgList.isEmpty) {
      ""
    } else {
      if (dataType.equalsIgnoreCase("varchar") && dataTypeArgList(0).equalsIgnoreCase("max")) s"$maxVarcharReplaceVal" else dataTypeArgList.mkString(",")
    }
  }

  def convertSqlToHql(sqlFilePath: String, hqlFilePath: String, oadwSchemaPath: String, iiDataTypeMapPath: String, iiSynonymsPath: String): Unit = {
    val maskKeys = Set("EXCLUDE", "exclude", "INTERVAL", "interval")
    val oracleToHiveParser = OracleToHiveParser(preMaskKeyWords = maskKeys, postMaskKeyWords = maskKeys)
    val sqlContentOriginal = Source.fromFile(sqlFilePath).getLines.mkString("\n")
    val sqlContent = cleanUpSql(sqlContentOriginal).split("\n").toList
    val oadwContent = Source.fromFile(oadwSchemaPath).getLines.mkString("\n")
    val l2SkipTables = findIIOverrides(oadwContent)
    val skipBMKTables = List("l2_ii_bmk_adm_den_detail","l2_ii_bmk_adm_num_detail","l2_ii_bmk_date_range","l2_ii_bmk_dem_yr","l2_ii_bmk_dp_den_detail","l2_ii_bmk_dp_num_detail","l2_ii_bmk_epi_den_detail","l2_ii_bmk_epi_num_detail","l2_ii_bmk_phm_num_detail","l2_ii_bmk_pop_den_detail","l2_ii_bmk_pop_num_detail")

    val iiSynonymMap: Map[String, String] =
    Source.fromFile(iiSynonymsPath).getLines().filter(_.nonEmpty).map(_.split("\\|")).filter(_.length == 2).map(item => item(0).toLowerCase -> item(1).split("_").drop(2).mkString("_").toLowerCase).toMap

    val parsedContent = oracleToHiveParser.parse(sqlContent)
    val iiExternalDataTypeMap = parsedContent.sortBy(content=> content.modelName).map(content => {
      val prefix = if (l2SkipTables.contains(content.modelName.toLowerCase)) "l1_ii_" else "l2_ii_"
      val tableName = if(iiSynonymMap.contains(content.modelName.toLowerCase)) prefix + iiSynonymMap(content.modelName.toLowerCase) else prefix + content.modelName.toLowerCase
      content.mappedColumnInfo.filter(stmt => !skipBMKTables.contains(tableName)).map(mappedCol => {
        tableName + "|" + mappedCol.name + "|" + mappedCol.dataType + "|" + getDataType(mappedCol.dataType, mappedCol.dataTypeArgList.getOrElse(Seq(""))) //mappedCol.dataTypeArgList.getOrElse(Seq("")).mkString(",")
      }).mkString("\n")
    }).filter(_.nonEmpty).mkString("\n\n")
    val ddlStatements =
      oracleToHiveParser
        .generateDDLStatement("{{db_name}}", "{{basePath}}/{{env}}/external/ii/{{process_id}}/{{dateStamp}}/data")
        .map(_.replace("VARCHAR (max)", s"VARCHAR ($maxVarcharReplaceVal)"))
    val createDatabase = "CREATE DATABASE IF NOT EXISTS {{db_name}} LOCATION '{{basePath}}/{{env}}/external/ii/{{process_id}}/{{dateStamp}}/data/do_not_modify/';\n\n"

    val iiSchemaContent = ddlStatements.map(statment => {
      val tableName = getTableName(statment)
      val trimmedStatement = statment.trim
      val prefix = if (l2SkipTables.contains(tableName)) "l1_ii_" else "l2_ii_"
      val iiTables = getRenamedTable(trimmedStatement, prefix, iiSynonymMap)

      iiTables
    }).filter(stmt => !skipBMKTables.contains(getTableName(stmt))).sorted.mkString("\n")
    val header = "/** Auto-generated **/\ntableName|columnName|dataType|dataTypeSpec\n\n"
    saveToFile(hqlFilePath, createDatabase + iiSchemaContent)
    saveToFile(iiDataTypeMapPath, header + iiExternalDataTypeMap)
  }
}

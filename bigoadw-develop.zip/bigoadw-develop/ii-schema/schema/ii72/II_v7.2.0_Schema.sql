-- 20190703 created from [BOSS7II2SQL02].[II_MR72_1906211231] per John Vidaver

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SUBSCRIBER](
	[SUBSCRIBER_ID] [varchar](32) NOT NULL,
	[EFF_DT] [smalldatetime] NOT NULL,
	[END_DT] [smalldatetime] NOT NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[CONTRACT_TYPE_ID] [varchar](40) NOT NULL,
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL,
	[CONTRACT_ID] [varchar](40) NOT NULL,
	[RISK_TYPE_ID] [varchar](40) NULL,
	[CUST_SUB_1] [varchar](255) NULL,
	[CUST_SUB_10] [varchar](255) NULL,
	[CUST_SUB_11] [varchar](255) NULL,
	[CUST_SUB_12] [varchar](255) NULL,
	[CUST_SUB_13] [varchar](255) NULL,
	[CUST_SUB_14] [varchar](255) NULL,
	[CUST_SUB_15] [varchar](255) NULL,
	[CUST_SUB_16] [float] NULL,
	[CUST_SUB_17] [float] NULL,
	[CUST_SUB_18] [float] NULL,
	[CUST_SUB_19] [float] NULL,
	[CUST_SUB_2] [varchar](255) NULL,
	[CUST_SUB_20] [float] NULL,
	[CUST_SUB_3] [varchar](255) NULL,
	[CUST_SUB_4] [varchar](255) NULL,
	[CUST_SUB_5] [varchar](255) NULL,
	[CUST_SUB_6] [varchar](255) NULL,
	[CUST_SUB_7] [varchar](255) NULL,
	[CUST_SUB_8] [varchar](255) NULL,
	[CUST_SUB_9] [varchar](255) NULL,
	[CUST_SUB_PK_ID] [varchar](32) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_UNIQ_MEMBER](
	[MEMBER] [varchar](32) NOT NULL,
	[MAX_EFF_DT] [smalldatetime] NULL,
	[NBR] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_SUMMARY_TOS_PMPM](
	[Year] [varchar](9) NULL,
	[Product] [varchar](150) NOT NULL,
	[Service_Category] [varchar](100) NULL,
	[Type_of_Service] [varchar](255) NULL,
	[Requested] [float] NULL,
	[Allowed] [float] NULL,
	[Paid] [float] NULL,
	[Original] [float] NULL,
	[Normalized] [decimal](38, 2) NULL,
	[Member_Months] [int] NULL,
	[Requested_PMPM] [float] NULL,
	[Allowed_PMPM] [float] NULL,
	[Paid_PMPM] [float] NULL,
	[Original_PMPM] [float] NULL,
	[Normalized_PMPM] [decimal](38, 6) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_SUMMARY_PTILES](
	[Year] [varchar](10) NULL,
	[Product] [varchar](150) NULL,
	[Proc_Code] [varchar](15) NULL,
	[Modifier] [varchar](15) NULL,
	[Procedure_Desc] [varchar](100) NULL,
	[Records] [int] NULL,
	[Avg_Normalized_Amt] [float] NULL,
	[Avg_Original_Amt] [float] NULL,
	[Orig_Tot] [float] NULL,
	[Ratio] [float] NULL,
	[Pct_Outlier] [float] NULL,
	[Pct_Zero] [float] NULL,
	[p10th] [float] NULL,
	[p25th] [float] NULL,
	[p50th] [float] NULL,
	[p75th] [float] NULL,
	[p90th] [float] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_SUMMARY_CONF](
	[Year] [int] NULL,
	[Product] [varchar](150) NOT NULL,
	[Type_of_Service] [varchar](255) NULL,
	[Service_Category] [varchar](100) NULL,
	[Requested] [decimal](38, 2) NULL,
	[Allowed] [decimal](38, 2) NULL,
	[Paid] [decimal](38, 2) NULL,
	[Original] [decimal](38, 2) NULL,
	[Normalized] [decimal](38, 2) NULL,
	[Confinements] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_SUMMARY_ALL](
	[Year] [int] NULL,
	[Product] [varchar](150) NULL,
	[Type_of_Service] [varchar](255) NULL,
	[Service_Category] [varchar](100) NULL,
	[Record_Type] [varchar](37) NOT NULL,
	[Place_of_Service] [varchar](150) NULL,
	[Specialty_Level1] [varchar](12) NULL,
	[Specialty_Level2] [varchar](30) NULL,
	[Specialty_Level3] [varchar](40) NULL,
	[Specialty_Level4] [varchar](40) NULL,
	[Priced_Flag] [varchar](3) NOT NULL,
	[Pricing_Method] [varchar](150) NOT NULL,
	[Records] [int] NULL,
	[Requested] [float] NULL,
	[Allowed] [float] NULL,
	[Paid] [float] NULL,
	[Original] [float] NULL,
	[Normalized] [decimal](38, 2) NULL,
	[Zero_Orig] [int] NULL,
	[Negative_Orig] [int] NULL,
	[Zero_Orig_Flag] [varchar](1) NOT NULL,
	[Negative_Orig_Flag] [varchar](1) NOT NULL,
	[Zero_Requtested] [int] NULL,
	[Negative_Requested] [int] NULL,
	[Zero_MetQty] [int] NULL,
	[Negative_MetQty] [int] NULL,
	[Set_Mod_Used] [int] NULL,
	[Outliers] [int] NULL,
	[LOS_Outlier] [int] NULL,
	[Amt_Outlier] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_RX_FINAL](
	[UNIQ_REC_ID] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[DOS] [smalldatetime] NOT NULL,
	[NDC] [varchar](11) NULL,
	[MET_QTY] [decimal](19, 2) NULL,
	[DAY_SUP] [smallint] NULL,
	[AMT_EQV] [money] NULL,
	[AMT_PAY] [money] NULL,
	[AMT_REQ] [money] NULL,
	[AMT_OTH1] [money] NULL,
	[AMT_OTH2] [money] NULL,
	[AMT_OTH3] [money] NULL,
	[AMT_OTH4] [money] NULL,
	[PRICING_VAR] [decimal](19, 2) NULL,
	[CF_VAR1] [int] NULL,
	[CF_VAR2] [int] NULL,
	[GBO_SSPP] [varchar](1) NULL,
	[GBO_LOOK] [varchar](1) NULL,
	[TOS_1] [varchar](13) NOT NULL,
	[TOS_2] [varchar](20) NOT NULL,
	[TOS_I] [varchar](27) NOT NULL,
	[METHOD] [varchar](1) NOT NULL,
	[EOYNPT] [float] NULL,
	[PRICE_TYPE] [varchar](3) NULL,
	[RX_CF_WAC] [decimal](19, 2) NOT NULL,
	[RX_CF_SWP] [decimal](19, 2) NOT NULL,
	[RX_CF_DP] [decimal](19, 2) NOT NULL,
	[EOYNPT_ADJ] [float] NOT NULL,
	[STDPRICE] [decimal](12, 5) NULL,
	[DAY_COST] [decimal](19, 2) NULL,
	[NEW_MET_QTY] [decimal](19, 2) NULL,
	[AMT_STD] [decimal](19, 2) NULL,
	[STD_ZERO] [varchar](1) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_PROF_ANC_FINAL](
	[UNIQ_REC_ID] [bigint] NOT NULL,
	[AMT_PAY] [money] NULL,
	[AMT_REQ] [money] NULL,
	[AMT_EQV] [money] NULL,
	[QUANT] [varchar](2) NOT NULL,
	[SET_MOD] [varchar](1) NULL,
	[MOD_I] [varchar](15) NULL,
	[QTY_I] [float] NULL,
	[RVUS] [decimal](19, 2) NULL,
	[STD_ZERO] [varchar](1) NOT NULL,
	[PRICING_VAR] [money] NULL,
	[AMT_STD] [decimal](19, 2) NULL,
	[METHOD] [varchar](1) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_PREPROCESS_FINAL_EXCLUDE](
	[UNIQ_REC_ID] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[DOS] [smalldatetime] NOT NULL,
	[POS_I] [tinyint] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[REVENUE] [varchar](15) NULL,
	[PROCCODE] [varchar](15) NULL,
	[TOS_N] [varchar](30) NULL,
	[MAP_SRCE_N] [varchar](6) NULL,
	[PRICING_VAR] [decimal](19, 2) NULL,
	[TOS_I_5] [int] NOT NULL,
	[TOS_I_4] [int] NOT NULL,
	[LOCAL_FLAG] [tinyint] NULL,
	[TOS_R_ID] [int] NOT NULL,
	[PSEUDO] [bit] NULL,
	[CUST_DNP_IND] [varchar](20) NOT NULL,
	[CF_VAR1] [int] NULL,
	[CF_VAR2] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_PREPROCESS_FINAL](
	[UNIQ_REC_ID] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[DOS] [smalldatetime] NOT NULL,
	[POS_I] [tinyint] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[REVENUE] [varchar](15) NULL,
	[PROCCODE] [varchar](15) NULL,
	[TOS_N] [varchar](30) NULL,
	[MAP_SRCE_N] [varchar](6) NULL,
	[PRICING_VAR] [decimal](19, 2) NULL,
	[TOS_I_5] [int] NOT NULL,
	[TOS_I_4] [int] NOT NULL,
	[LOCAL_FLAG] [tinyint] NULL,
	[TOS_R_ID] [int] NOT NULL,
	[PSEUDO] [bit] NULL,
	[CUST_DNP_IND] [varchar](20) NOT NULL,
	[CF_VAR1] [int] NULL,
	[CF_VAR2] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_OUTPATIENT_FINAL](
	[UNIQ_REC_ID] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[DOS] [smalldatetime] NOT NULL,
	[PROVIDER] [varchar](20) NOT NULL,
	[PROCCODE] [varchar](15) NOT NULL,
	[MOD_N] [varchar](4) NOT NULL,
	[REVENUE] [varchar](15) NOT NULL,
	[PRICING_VAR] [money] NOT NULL,
	[AMT_REQ] [money] NOT NULL,
	[AMT_EQV] [money] NOT NULL,
	[AMT_PAY] [money] NOT NULL,
	[AMT_OTH1] [money] NULL,
	[AMT_OTH2] [money] NULL,
	[AMT_OTH3] [money] NULL,
	[AMT_OTH4] [money] NULL,
	[PROCTYPE] [char](3) NULL,
	[POS_I] [tinyint] NOT NULL,
	[TOS_R_ID] [int] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[CF_VAR1] [int] NOT NULL,
	[CF_VAR2] [int] NOT NULL,
	[QTY_ADJ] [char](1) NULL,
	[J_CODE_QTY_ADJ] [char](1) NULL,
	[DOS_YEAR] [int] NULL,
	[USE_FLAG] [varchar](1) NOT NULL,
	[QTY] [float] NULL,
	[QUANT] [varchar](2) NULL,
	[OP_TYPE] [varchar](50) NULL,
	[OP_INDICATOR] [varchar](50) NULL,
	[OP_PAYMENT_METHOD] [varchar](50) NULL,
	[OP_PACKAGED_INSTRUCT] [varchar](50) NULL,
	[OP_PACKAGED_RESET] [tinyint] NULL,
	[OP_PACKAGED_FINAL_IND] [tinyint] NULL,
	[OP_MULT_REDUCTION] [varchar](50) NULL,
	[OP_APC] [varchar](50) NULL,
	[OP_RVU_ORIG] [numeric](18, 4) NULL,
	[OP_PROCCODE_KEY] [varchar](50) NULL,
	[OP_ADJ] [numeric](18, 4) NULL,
	[OP_ADJ_REASON] [varchar](100) NULL,
	[PROCCODE_XWALK_FROM_REVENUE] [varchar](100) NULL,
	[PRICE_INDEX] [numeric](18, 4) NULL,
	[OUTLIER] [varchar](50) NULL,
	[OUTLIER_TYPE] [varchar](50) NULL,
	[OP_PAYMENT_METHOD_NOTES] [varchar](150) NULL,
	[OP_PAYMENT_METHOD_NOTES_DESC] [varchar](500) NULL,
	[MOD_I] [varchar](4) NOT NULL,
	[PROCCODE_KEY] [varchar](23) NULL,
	[FAC_OP_VISIT_ID] [bigint] NULL,
	[PRORATION_VAR] [numeric](38, 6) NULL,
	[TOT_VISIT_PRORATION_VAR] [numeric](38, 6) NULL,
	[TOT_VISIT_PRORATE_RVU] [float] NULL,
	[OP_RVU_FINAL] [numeric](18, 4) NULL,
	[OP_RVU_FINAL_SRC] [varchar](130) NULL,
	[STD_ZERO] [varchar](1) NOT NULL,
	[AMT_STD] [numeric](38, 6) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_MEMBER_SPAN](
	[UNIQ_REC_ID] [bigint] NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[SUBSCRIBER_ID] [varchar](32) NULL,
	[EFF_DT] [smalldatetime] NOT NULL,
	[END_DT] [smalldatetime] NOT NULL,
	[CF_VAR1] [int] NULL,
	[CF_VAR2] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SSPP_DATE_RANGE](
	[MONTH_DATE] [datetime] NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_CONFINEMENT_PREFINAL](
	[CONF_NUM] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[BEG_DT] [smalldatetime] NOT NULL,
	[END_DT] [smalldatetime] NOT NULL,
	[LOS] [smallint] NOT NULL,
	[PRV_BEG] [varchar](20) NULL,
	[PROVIDER] [varchar](20) NULL,
	[PAY_DT_BEG] [smalldatetime] NOT NULL,
	[PAY_DT] [smalldatetime] NOT NULL,
	[TOS_I_4] [int] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[TOS_R_ID] [int] NOT NULL,
	[POS_I] [tinyint] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[DIS_STAT] [varchar](3) NULL,
	[CF_VAR1] [int] NULL,
	[CF_VAR2] [int] NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[PRICING_VAR] [decimal](19, 2) NULL,
	[ICD_VERSION] [tinyint] NOT NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[DIAG5] [varchar](8) NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[POA1] [char](1) NOT NULL,
	[POA2] [int] NULL,
	[POA3] [int] NULL,
	[POA4] [int] NULL,
	[POA5] [int] NULL,
	[POA6] [int] NULL,
	[POA7] [int] NULL,
	[POA8] [int] NULL,
	[POA9] [int] NULL,
	[POA10] [int] NULL,
	[NEWBORN] [tinyint] NULL,
	[MATERN] [tinyint] NULL,
	[ICUSTAY] [tinyint] NULL,
	[MSURG] [tinyint] NULL,
	[ICUSURG] [tinyint] NULL,
	[RSNF] [int] NOT NULL,
	[IPRICE_CAT] [varchar](30) NOT NULL,
	[LOSGRP] [varchar](7) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_CONFINEMENT_FINAL](
	[CONF_NUM] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[BEG_DT] [smalldatetime] NOT NULL,
	[END_DT] [smalldatetime] NOT NULL,
	[LOS] [smallint] NOT NULL,
	[PRV_BEG] [varchar](20) NULL,
	[PROVIDER] [varchar](20) NULL,
	[PAY_DT_BEG] [smalldatetime] NOT NULL,
	[PAY_DT] [smalldatetime] NOT NULL,
	[TOS_I_4] [int] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[TOS_R_ID] [int] NOT NULL,
	[POS_I] [tinyint] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[DIS_STAT] [varchar](3) NULL,
	[CF_VAR1] [int] NULL,
	[CF_VAR2] [int] NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[PRICING_VAR] [decimal](19, 2) NULL,
	[ICD_VERSION] [tinyint] NOT NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[DIAG5] [varchar](8) NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[POA1] [char](1) NOT NULL,
	[POA2] [int] NULL,
	[POA3] [int] NULL,
	[POA4] [int] NULL,
	[POA5] [int] NULL,
	[POA6] [int] NULL,
	[POA7] [int] NULL,
	[POA8] [int] NULL,
	[POA9] [int] NULL,
	[POA10] [int] NULL,
	[NEWBORN] [tinyint] NULL,
	[MATERN] [tinyint] NULL,
	[ICUSTAY] [tinyint] NULL,
	[MSURG] [tinyint] NULL,
	[ICUSURG] [tinyint] NULL,
	[RSNF] [int] NOT NULL,
	[IPRICE_CAT] [varchar](30) NOT NULL,
	[LOSGRP] [varchar](7) NOT NULL,
	[AMT_STD] [decimal](19, 2) NULL,
	[AMT_DAY] [decimal](25, 8) NOT NULL,
	[METHOD] [varchar](1) NULL,
	[OUTLIER_LOS] [varchar](1) NULL,
	[OUTLIER_COST] [varchar](1) NULL,
	[RESET_0] [varchar](1) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SSPP_CONFINEMENT_CLMS](
	[MEMBER] [varchar](32) NOT NULL,
	[CLM_ID_N] [varchar](30) NULL,
	[DOS] [smalldatetime] NOT NULL,
	[FROM_DT] [smalldatetime] NULL,
	[TO_DT] [smalldatetime] NULL,
	[MAP_SRCE_N] [varchar](6) NULL,
	[ICD_VERSION] [tinyint] NOT NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[DIAG5] [varchar](8) NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[POA1] [char](1) NOT NULL,
	[POA2] [int] NULL,
	[POA3] [int] NULL,
	[POA4] [int] NULL,
	[POA5] [int] NULL,
	[POA6] [int] NULL,
	[POA7] [int] NULL,
	[POA8] [int] NULL,
	[POA9] [int] NULL,
	[POA10] [int] NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[PROCCODE] [varchar](15) NULL,
	[REVENUE] [varchar](15) NULL,
	[MOD_N] [varchar](4) NULL,
	[MOD_N2] [int] NULL,
	[MOD_N3] [int] NULL,
	[MOD_N4] [int] NULL,
	[MOD_N5] [int] NULL,
	[DIS_STAT] [varchar](3) NULL,
	[POS_N] [varchar](3) NULL,
	[POS_I] [tinyint] NOT NULL,
	[TOS_N] [varchar](30) NULL,
	[TOS_R_ID] [int] NULL,
	[QTY] [int] NULL,
	[PROVIDER] [varchar](20) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[PRICING_VAR] [decimal](19, 2) NULL,
	[PRV_SP_N] [varchar](30) NULL,
	[PAY_DT] [smalldatetime] NOT NULL,
	[DNP_IND] [int] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[BILL_TYPE] [varchar](3) NULL,
	[ORDER_PROV] [varchar](20) NULL,
	[UNIQ_REC_ID] [bigint] NOT NULL,
	[LOCAL_FLAG] [tinyint] NULL,
	[TOS_I_5] [int] NOT NULL,
	[TOS_I_4] [int] NOT NULL,
	[CF_VAR1] [int] NULL,
	[CF_VAR2] [int] NULL,
	[CONF_NUM] [bigint] NULL,
	[FAC_LEVEL] [int] NOT NULL,
	[ER_FLAG] [bit] NULL,
	[ER_CONF] [bit] NULL,
	[NOENR_DOS] [bit] NULL,
	[AMT_STD] [decimal](19, 2) NULL,
	[STD_ZERO] [varchar](1) NOT NULL,
	[EXCLUDE] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SERVICES_RX](
	[MEMBER] [varchar](32) NOT NULL,
	[CLM_ID_N] [varchar](30) NULL,
	[MAP_SRCE_N] [varchar](6) NULL,
	[DOS] [smalldatetime] NOT NULL,
	[PAY_DT] [smalldatetime] NOT NULL,
	[NDC] [varchar](11) NULL,
	[MET_QTY] [decimal](19, 2) NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[DEA] [varchar](15) NULL,
	[DAYS_SUP] [smallint] NULL,
	[GBO] [tinyint] NOT NULL,
	[AMT_COIN] [decimal](19, 2) NULL,
	[AMT_COP] [decimal](19, 2) NULL,
	[AMT_DED] [decimal](19, 2) NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_LIAB] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NULL,
	[AMT_WTH] [decimal](19, 2) NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NULL,
	[CLAIM_ID] [varchar](30) NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[PSEUDO] [bit] NULL,
	[FORMULARY] [tinyint] NULL,
	[PRES_PROVIDER_ID] [varchar](20) NULL,
	[PRES_PRV_I] [varchar](20) NULL,
	[NETWORK_STATUS] [bit] NULL,
	[CHANNEL] [int] NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[EPISODE_ID] [int] NULL,
	[CLUS_PRV] [varchar](20) NULL,
	[CLUSTER] [int] NULL,
	[REC_TYPE] [char](1) NULL,
	[DCC] [char](5) NULL,
	[ETG_ID] [smallint] NULL,
	[ETG] [varchar](9) NULL,
	[UNIQ_REC_ID] [bigint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[TOS_I_4] [int] NULL,
	[TOS_I_5] [int] NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[NOENR_DOS] [bit] NULL,
	[CLM_TYPE] [char](1) NOT NULL,
	[EXCLUDE] [bit] NOT NULL,
	[PSC_CAT1_ID] [smallint] NULL,
	[PSC_CAT2_ID] [smallint] NULL,
	[SCRIPT] [decimal](19, 2) NULL,
	[GENERIC] [bit] NULL,
	[SCRIPT_GEN] [bit] NULL,
	[PRFL_CLM] [tinyint] NULL,
	[AMT_EQV_CF] [decimal](19, 4) NULL,
	[AMT_PAY_CF] [decimal](19, 4) NULL,
	[DISREL] [smallint] NULL,
	[ACW_SRV] [tinyint] NULL,
	[LAG_DAYS] [smallint] NULL,
	[LAG_IND] [bit] NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[MAP_SRCE_P] [varchar](6) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[AMT_COIN_K] [decimal](19, 2) NULL,
	[AMT_COP_K] [decimal](19, 2) NULL,
	[AMT_DED_K] [decimal](19, 2) NULL,
	[AMT_EQV_K] [decimal](19, 2) NULL,
	[AMT_LIAB_K] [decimal](19, 2) NULL,
	[AMT_NP_K] [decimal](19, 2) NULL,
	[AMT_OTH1_K] [decimal](19, 2) NULL,
	[AMT_OTH2_K] [decimal](19, 2) NULL,
	[AMT_OTH3_K] [decimal](19, 2) NULL,
	[AMT_OTH4_K] [decimal](19, 2) NULL,
	[AMT_PAY_K] [decimal](19, 2) NULL,
	[AMT_REQ_K] [decimal](19, 2) NULL,
	[AMT_WTH_K] [decimal](19, 2) NULL,
	[AMT_CAP_PAY_K] [decimal](19, 2) NULL,
	[AMT_COB_K] [decimal](19, 2) NULL,
	[MET_QTY_K] [decimal](19, 2) NULL,
	[DAYS_SUP_K] [smallint] NULL,
	[SVC_GRP] [varchar](30) NOT NULL,
	[ENC_K] [decimal](19, 2) NOT NULL,
	[SCRIPT_K] [decimal](19, 2) NULL,
	[GENERIC_K] [bit] NULL,
	[SCRIPT_GEN_K] [bit] NULL,
	[DENIED_IND_ID] [varchar](40) NULL,
	[SPEC_RX_N_ID] [varchar](40) NULL,
	[DAW] [tinyint] NULL,
	[REFILL_NUM] [int] NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_DISP] [decimal](19, 2) NULL,
	[AMT_INGR] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_SALES_TAX] [decimal](19, 2) NULL,
	[AMT_DISP_K] [decimal](19, 2) NULL,
	[AMT_INGR_K] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED_K] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY_K] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE_K] [decimal](19, 2) NULL,
	[AMT_SALES_TAX_K] [decimal](19, 2) NULL,
	[SPEC_DRUG] [tinyint] NULL,
	[USER_SPEC_DRUG] [tinyint] NULL,
	[CAP_FLAG] [bit] NULL,
	[RX_COUNT_N] [decimal](4, 2) NULL,
	[RX_COUNT_N_K] [decimal](4, 2) NULL,
	[CUST_RX_1] [varchar](255) NULL,
	[CUST_RX_10] [varchar](255) NULL,
	[CUST_RX_11] [varchar](255) NULL,
	[CUST_RX_12] [varchar](255) NULL,
	[CUST_RX_13] [varchar](255) NULL,
	[CUST_RX_14] [varchar](255) NULL,
	[CUST_RX_15] [varchar](255) NULL,
	[CUST_RX_16] [float] NULL,
	[CUST_RX_17] [float] NULL,
	[CUST_RX_18] [float] NULL,
	[CUST_RX_19] [float] NULL,
	[CUST_RX_2] [varchar](255) NULL,
	[CUST_RX_20] [float] NULL,
	[CUST_RX_3] [varchar](255) NULL,
	[CUST_RX_4] [varchar](255) NULL,
	[CUST_RX_5] [varchar](255) NULL,
	[CUST_RX_6] [varchar](255) NULL,
	[CUST_RX_7] [varchar](255) NULL,
	[CUST_RX_8] [varchar](255) NULL,
	[CUST_RX_9] [varchar](255) NULL,
	[CUST_RX_PK_ID] [varchar](32) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SERVICES_MED](
	[MEMBER] [varchar](32) NOT NULL,
	[DOS] [smalldatetime] NOT NULL,
	[CLAIM_ID] [varchar](30) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[FROM_DT] [smalldatetime] NULL,
	[TO_DT] [smalldatetime] NULL,
	[PAY_DT] [smalldatetime] NOT NULL,
	[CLM_ID_N] [varchar](30) NULL,
	[LINE_NAT] [varchar](10) NULL,
	[UNIQ_REC_ID] [bigint] NOT NULL,
	[MAP_SRCE_N] [varchar](6) NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[DIAG5] [varchar](8) NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[PROCCODE] [varchar](15) NULL,
	[REVENUE] [varchar](15) NULL,
	[MOD_N] [varchar](4) NULL,
	[DRG_OUTLIER] [tinyint] NULL,
	[DRG_ID] [varchar](12) NULL,
	[DIS_STAT] [varchar](3) NULL,
	[POS_N] [varchar](3) NULL,
	[POS_I] [tinyint] NOT NULL,
	[TOS_N] [varchar](30) NULL,
	[TOS_I_4] [int] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[PRV_SP_N] [varchar](30) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[QTY] [int] NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_COIN] [decimal](19, 2) NULL,
	[AMT_COP] [decimal](19, 2) NULL,
	[AMT_DED] [decimal](19, 2) NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NULL,
	[AMT_WTH] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_LIAB] [decimal](19, 2) NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NULL,
	[PSEUDO] [bit] NULL,
	[BILL_TYPE] [varchar](3) NULL,
	[POA] [char](1) NOT NULL,
	[ORDER_PROV] [varchar](20) NULL,
	[CONF_NUM] [bigint] NULL,
	[NETWORK_STATUS] [bit] NULL,
	[LOCAL_FLAG] [tinyint] NULL,
	[DCC] [char](5) NULL,
	[EPISODE_ID] [int] NULL,
	[CLUS_PRV] [varchar](20) NULL,
	[CLUSTER] [int] NULL,
	[REC_TYPE] [char](1) NULL,
	[ETG_ID] [smallint] NULL,
	[ETG] [varchar](9) NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[NOENR_DOS] [bit] NULL,
	[CLM_TYPE] [char](1) NOT NULL,
	[EXCLUDE] [bit] NOT NULL,
	[ORDER_PRV_I] [varchar](20) NULL,
	[COV_ORDER] [bit] NULL,
	[ER_FLAG] [bit] NULL,
	[ER_CONF] [bit] NULL,
	[RAD_FLAG] [bit] NULL,
	[LAB_FLAG] [bit] NULL,
	[PSC_CAT1_ID] [smallint] NULL,
	[PSC_CAT2_ID] [smallint] NULL,
	[RAD_UTIL] [decimal](19, 2) NULL,
	[LAB_UTIL] [decimal](19, 2) NULL,
	[MRI_UTIL] [decimal](19, 2) NULL,
	[ER_UTIL] [decimal](19, 2) NULL,
	[EM_SVC_FLAG] [bit] NULL,
	[PCP_VIS_FLAG] [bit] NULL,
	[REF_VIS_FLAG] [bit] NULL,
	[REF_FLAG] [bit] NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NULL,
	[UTIL_SPEC_ENC] [tinyint] NULL,
	[PRFL_CLM] [tinyint] NULL,
	[AMT_EQV_CF] [decimal](19, 4) NULL,
	[AMT_PAY_CF] [decimal](19, 4) NULL,
	[DISREL] [smallint] NULL,
	[ACW_SRV] [tinyint] NULL,
	[LAG_DAYS] [smallint] NULL,
	[LAG_IND] [bit] NULL,
	[ICD_VERSION] [tinyint] NOT NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[MAP_SRCE_P] [varchar](6) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[AMT_CAP_PAY_K] [decimal](19, 2) NULL,
	[AMT_COB_K] [decimal](19, 2) NULL,
	[AMT_COIN_K] [decimal](19, 2) NULL,
	[AMT_COP_K] [decimal](19, 2) NULL,
	[AMT_DED_K] [decimal](19, 2) NULL,
	[AMT_EQV_K] [decimal](19, 2) NULL,
	[AMT_LIAB_K] [decimal](19, 2) NULL,
	[AMT_NP_K] [decimal](19, 2) NULL,
	[AMT_OTH1_K] [decimal](19, 2) NULL,
	[AMT_OTH2_K] [decimal](19, 2) NULL,
	[AMT_OTH3_K] [decimal](19, 2) NULL,
	[AMT_OTH4_K] [decimal](19, 2) NULL,
	[AMT_PAY_K] [decimal](19, 2) NULL,
	[AMT_REQ_K] [decimal](19, 2) NULL,
	[AMT_WTH_K] [decimal](19, 2) NULL,
	[QTY_K] [int] NULL,
	[SVC_GRP] [varchar](30) NOT NULL,
	[ENC_K] [decimal](19, 2) NOT NULL,
	[PCP_VIS_FLAG_K] [bit] NULL,
	[REF_VIS_FLAG_K] [bit] NULL,
	[REF_FLAG_K] [bit] NULL,
	[LAB_UTIL_K] [decimal](19, 2) NULL,
	[RAD_UTIL_K] [decimal](19, 2) NULL,
	[MRI_UTIL_K] [decimal](19, 2) NULL,
	[ER_UTIL_K] [decimal](19, 2) NULL,
	[UTIL_SPEC_ENC_K] [tinyint] NULL,
	[DENIED_IND_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[SPEC_RX_N_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED_K] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY_K] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE_K] [decimal](19, 2) NULL,
	[SPEC_DRUG] [tinyint] NULL,
	[USER_SPEC_DRUG] [tinyint] NULL,
	[BILL_PROVIDER_ID] [varchar](20) NULL,
	[BILL_DRG_ID] [varchar](12) NULL,
	[BILL_DRG_OUTLIER] [tinyint] NULL,
	[MOD_N_2] [varchar](4) NULL,
	[MOD_N_3] [varchar](4) NULL,
	[MOD_N_4] [varchar](4) NULL,
	[DIAG11] [varchar](8) NULL,
	[DIAG12] [varchar](8) NULL,
	[DIAG13] [varchar](8) NULL,
	[DIAG14] [varchar](8) NULL,
	[DIAG15] [varchar](8) NULL,
	[DIAG16] [varchar](8) NULL,
	[DIAG17] [varchar](8) NULL,
	[DIAG18] [varchar](8) NULL,
	[DIAG19] [varchar](8) NULL,
	[DIAG20] [varchar](8) NULL,
	[DIAG21] [varchar](8) NULL,
	[DIAG22] [varchar](8) NULL,
	[DIAG23] [varchar](8) NULL,
	[DIAG24] [varchar](8) NULL,
	[DIAG25] [varchar](8) NULL,
	[IPROC11] [varchar](7) NULL,
	[IPROC12] [varchar](7) NULL,
	[IPROC13] [varchar](7) NULL,
	[IPROC14] [varchar](7) NULL,
	[IPROC15] [varchar](7) NULL,
	[IPROC16] [varchar](7) NULL,
	[IPROC17] [varchar](7) NULL,
	[IPROC18] [varchar](7) NULL,
	[IPROC19] [varchar](7) NULL,
	[IPROC20] [varchar](7) NULL,
	[IPROC21] [varchar](7) NULL,
	[IPROC22] [varchar](7) NULL,
	[IPROC23] [varchar](7) NULL,
	[IPROC24] [varchar](7) NULL,
	[IPROC25] [varchar](7) NULL,
	[CAP_FLAG] [bit] NULL,
	[ADMIT_SOURCE] [char](1) NULL,
	[OP_VISIT_ID] [int] NULL,
	[NP_OP_VISIT_ID] [bigint] NULL,
	[ED_ENC_ID] [int] NULL,
	[CUST_MED_1] [varchar](255) NULL,
	[CUST_MED_10] [varchar](255) NULL,
	[CUST_MED_11] [varchar](255) NULL,
	[CUST_MED_12] [varchar](255) NULL,
	[CUST_MED_13] [varchar](255) NULL,
	[CUST_MED_14] [varchar](255) NULL,
	[CUST_MED_15] [varchar](255) NULL,
	[CUST_MED_16] [float] NULL,
	[CUST_MED_17] [float] NULL,
	[CUST_MED_18] [float] NULL,
	[CUST_MED_19] [float] NULL,
	[CUST_MED_2] [varchar](255) NULL,
	[CUST_MED_20] [float] NULL,
	[CUST_MED_3] [varchar](255) NULL,
	[CUST_MED_4] [varchar](255) NULL,
	[CUST_MED_5] [varchar](255) NULL,
	[CUST_MED_6] [varchar](255) NULL,
	[CUST_MED_7] [varchar](255) NULL,
	[CUST_MED_8] [varchar](255) NULL,
	[CUST_MED_9] [varchar](255) NULL,
	[CUST_MED_PK_ID] [varchar](32) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SERVICES_INP](
	[MEMBER] [varchar](32) NOT NULL,
	[DOS] [smalldatetime] NOT NULL,
	[CLAIM_ID] [varchar](30) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[CLM_ID_N] [varchar](30) NULL,
	[LINE_NAT] [varchar](10) NULL,
	[UNIQ_REC_ID] [bigint] NOT NULL,
	[MAP_SRCE_N] [varchar](6) NULL,
	[FROM_DT] [smalldatetime] NULL,
	[TO_DT] [smalldatetime] NULL,
	[PAY_DT] [smalldatetime] NOT NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[DIAG5] [varchar](8) NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[PROCCODE] [varchar](15) NULL,
	[REVENUE] [varchar](15) NULL,
	[MOD_N] [varchar](4) NULL,
	[DRG_ID] [varchar](12) NULL,
	[DRG_OUTLIER] [tinyint] NULL,
	[DIS_STAT] [varchar](3) NULL,
	[POS_N] [varchar](3) NULL,
	[POS_I] [tinyint] NOT NULL,
	[TOS_N] [varchar](30) NULL,
	[TOS_I_4] [int] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[PRV_SP_N] [varchar](30) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[CONF_NUM] [bigint] NULL,
	[QTY] [int] NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_COIN] [decimal](19, 2) NULL,
	[AMT_COP] [decimal](19, 2) NULL,
	[AMT_DED] [decimal](19, 2) NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NULL,
	[AMT_WTH] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[NETWORK_STATUS] [bit] NULL,
	[AMT_LIAB] [decimal](19, 2) NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NULL,
	[POA] [char](1) NOT NULL,
	[ORDER_PROV] [varchar](20) NULL,
	[BILL_TYPE] [varchar](3) NULL,
	[LOCAL_FLAG] [tinyint] NULL,
	[ER_FLAG] [bit] NULL,
	[ER_CONF] [bit] NULL,
	[NOENR_DOS] [bit] NULL,
	[CLM_TYPE] [char](1) NOT NULL,
	[EXCLUDE] [bit] NOT NULL,
	[ICD_VERSION] [tinyint] NOT NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[MAP_SRCE_P] [varchar](6) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[AMT_COB_K] [decimal](19, 2) NULL,
	[AMT_COIN_K] [decimal](19, 2) NULL,
	[AMT_COP_K] [decimal](19, 2) NULL,
	[AMT_DED_K] [decimal](19, 2) NULL,
	[AMT_EQV_K] [decimal](19, 2) NULL,
	[AMT_LIAB_K] [decimal](19, 2) NULL,
	[AMT_NP_K] [decimal](19, 2) NULL,
	[AMT_OTH1_K] [decimal](19, 2) NULL,
	[AMT_OTH2_K] [decimal](19, 2) NULL,
	[AMT_OTH3_K] [decimal](19, 2) NULL,
	[AMT_OTH4_K] [decimal](19, 2) NULL,
	[AMT_PAY_K] [decimal](19, 2) NULL,
	[AMT_REQ_K] [decimal](19, 2) NULL,
	[AMT_WTH_K] [decimal](19, 2) NULL,
	[AMT_CAP_PAY_K] [decimal](19, 2) NULL,
	[QTY_K] [int] NULL,
	[SVC_GRP] [varchar](30) NOT NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[DENIED_IND_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED_K] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY_K] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE_K] [decimal](19, 2) NULL,
	[BILL_PROVIDER_ID] [varchar](20) NULL,
	[BILL_DRG_ID] [varchar](12) NULL,
	[BILL_DRG_OUTLIER] [tinyint] NULL,
	[MOD_N_2] [varchar](4) NULL,
	[MOD_N_3] [varchar](4) NULL,
	[MOD_N_4] [varchar](4) NULL,
	[DIAG11] [varchar](8) NULL,
	[DIAG12] [varchar](8) NULL,
	[DIAG13] [varchar](8) NULL,
	[DIAG14] [varchar](8) NULL,
	[DIAG15] [varchar](8) NULL,
	[DIAG16] [varchar](8) NULL,
	[DIAG17] [varchar](8) NULL,
	[DIAG18] [varchar](8) NULL,
	[DIAG19] [varchar](8) NULL,
	[DIAG20] [varchar](8) NULL,
	[DIAG21] [varchar](8) NULL,
	[DIAG22] [varchar](8) NULL,
	[DIAG23] [varchar](8) NULL,
	[DIAG24] [varchar](8) NULL,
	[DIAG25] [varchar](8) NULL,
	[IPROC11] [varchar](7) NULL,
	[IPROC12] [varchar](7) NULL,
	[IPROC13] [varchar](7) NULL,
	[IPROC14] [varchar](7) NULL,
	[IPROC15] [varchar](7) NULL,
	[IPROC16] [varchar](7) NULL,
	[IPROC17] [varchar](7) NULL,
	[IPROC18] [varchar](7) NULL,
	[IPROC19] [varchar](7) NULL,
	[IPROC20] [varchar](7) NULL,
	[IPROC21] [varchar](7) NULL,
	[IPROC22] [varchar](7) NULL,
	[IPROC23] [varchar](7) NULL,
	[IPROC24] [varchar](7) NULL,
	[IPROC25] [varchar](7) NULL,
	[CAP_FLAG] [bit] NULL,
	[ADMIT_SOURCE] [char](1) NULL,
	[CUST_MED_1] [varchar](255) NULL,
	[CUST_MED_10] [varchar](255) NULL,
	[CUST_MED_11] [varchar](255) NULL,
	[CUST_MED_12] [varchar](255) NULL,
	[CUST_MED_13] [varchar](255) NULL,
	[CUST_MED_14] [varchar](255) NULL,
	[CUST_MED_15] [varchar](255) NULL,
	[CUST_MED_16] [float] NULL,
	[CUST_MED_17] [float] NULL,
	[CUST_MED_18] [float] NULL,
	[CUST_MED_19] [float] NULL,
	[CUST_MED_2] [varchar](255) NULL,
	[CUST_MED_20] [float] NULL,
	[CUST_MED_3] [varchar](255) NULL,
	[CUST_MED_4] [varchar](255) NULL,
	[CUST_MED_5] [varchar](255) NULL,
	[CUST_MED_6] [varchar](255) NULL,
	[CUST_MED_7] [varchar](255) NULL,
	[CUST_MED_8] [varchar](255) NULL,
	[CUST_MED_9] [varchar](255) NULL,
	[CUST_MED_PK_ID] [varchar](32) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[RS_ROWCOUNT](
	[VIEW_NAME] [varchar](50) NOT NULL,
	[VIEW_ROWCOUNT] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[RP_OPP_DASH](
	[PEER_DEF_ID] [int] NOT NULL,
	[PEER_DEF_DESC] [varchar](50) NOT NULL,
	[PCP_ATTR_ID] [tinyint] NULL,
	[IA_TIME_START] [smalldatetime] NOT NULL,
	[IA_TIME_END] [smalldatetime] NOT NULL,
	[AFFIL_LVL] [tinyint] NOT NULL,
	[PROV_AFFIL_ID] [varchar](100) NOT NULL,
	[PROV_AFFIL_DESC] [varchar](150) NOT NULL,
	[EPI_QTY] [decimal](19, 2) NULL,
	[W_COST1] [decimal](19, 2) NULL,
	[W_COST2] [decimal](19, 2) NULL,
	[W_COST3] [decimal](19, 2) NULL,
	[QUAL_OPP] [decimal](19, 2) NULL,
	[Q_QUAL_OVR_IND] [decimal](28, 6) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[RP_AGR_CLAIMS_HC](
	[MEMBER] [varchar](32) NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[COVERAGE_STATUS_DESC] [varchar](150) NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST3_ANC] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL,
	[COST3_PROF] [decimal](19, 2) NOT NULL,
	[COST3_PHM] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_QUALITY](
	[MEMBER] [varchar](32) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[EVENT_ID] [int] NOT NULL,
	[EBM_NUM] [tinyint] NOT NULL,
	[EBM_DEN] [tinyint] NOT NULL,
	[ALL_EBM_NUM] [decimal](28, 6) NULL,
	[RESULT_FLAG] [tinyint] NOT NULL,
	[MED_QUAL] [bit] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[RRISK] [decimal](10, 4) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[CAT_STATUS_COST3] [tinyint] NOT NULL,
	[AGE] [smallint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[ZIP] [char](5) NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[PCP_ID] [varchar](20) NULL,
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[COVERAGE_STATUS_ID] [varchar](40) NOT NULL,
	[CONTRACT_TYPE_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[AT_RISK_STATUS_ID] [varchar](40) NOT NULL,
	[MEM_CASE_RULE] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_QUAL](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[EBM_DEN] [int] NOT NULL,
	[EBM_NUM] [int] NOT NULL,
	[EBM_NUMX] [int] NOT NULL,
	[QUAL_RATE] [decimal](19, 2) NOT NULL,
	[QUAL_PEER_RATE] [decimal](19, 2) NOT NULL,
	[QUAL_OVR_IND] [decimal](28, 6) NOT NULL,
	[ALL_EBM_NUM] [decimal](28, 6) NOT NULL,
	[QUAL_ALL_RATE] [decimal](19, 2) NOT NULL,
	[PEER_EBM_NUM] [decimal](28, 6) NOT NULL,
	[QUAL_ELIG] [tinyint] NULL,
	[RANK_DEC_QUAL] [tinyint] NULL,
	[NUM_MEMBERS] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_POP_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[COST_ACT_TOT] [decimal](19, 2) NOT NULL,
	[COST2_ACT_TOT] [decimal](19, 2) NULL,
	[COST3_ACT_TOT] [decimal](19, 2) NULL,
	[COST_ACT_PMPM] [decimal](19, 2) NOT NULL,
	[COST2_ACT_PMPM] [decimal](19, 2) NULL,
	[COST3_ACT_PMPM] [decimal](19, 2) NULL,
	[COST_PEER_TOT] [decimal](19, 2) NOT NULL,
	[COST2_PEER_TOT] [decimal](19, 2) NOT NULL,
	[COST3_PEER_TOT] [decimal](19, 2) NOT NULL,
	[COST_PEER_PMPM] [decimal](19, 2) NOT NULL,
	[COST2_PEER_PMPM] [decimal](19, 2) NOT NULL,
	[COST3_PEER_PMPM] [decimal](19, 2) NOT NULL,
	[COST_IND] [decimal](19, 2) NOT NULL,
	[COST2_IND] [decimal](19, 2) NOT NULL,
	[COST3_IND] [decimal](19, 2) NOT NULL,
	[ENC_ACT_TOT] [decimal](19, 2) NOT NULL,
	[ENC_ACT_1K] [decimal](19, 2) NOT NULL,
	[ENC_PEER_TOT] [decimal](19, 2) NOT NULL,
	[ENC_PEER_1K] [decimal](19, 2) NOT NULL,
	[ENC_IND] [decimal](19, 2) NOT NULL,
	[PCP_MMOS] [decimal](19, 2) NOT NULL,
	[PCPVIS_ACT_TOT] [decimal](19, 2) NULL,
	[REF_ACT_TOT] [decimal](19, 2) NULL,
	[REFVIS_ACT_TOT] [decimal](19, 2) NULL,
	[ER_ACT_TOT] [decimal](19, 2) NULL,
	[DAYS_ACT_TOT] [decimal](19, 2) NULL,
	[LAB_ACT_TOT] [decimal](19, 2) NULL,
	[SCRIPT_ACT_TOT] [decimal](19, 2) NULL,
	[GEN_ACT_TOT] [decimal](19, 2) NULL,
	[RAD_ACT_TOT] [decimal](19, 2) NULL,
	[MRI_ACT_TOT] [decimal](19, 2) NULL,
	[ADMIT_ACT_TOT] [int] NULL,
	[PCPVIS_PEER_TOT] [decimal](19, 2) NULL,
	[REF_PEER_TOT] [decimal](19, 2) NULL,
	[REFVIS_PEER_TOT] [decimal](19, 2) NULL,
	[ER_PEER_TOT] [decimal](19, 2) NULL,
	[DAYS_PEER_TOT] [decimal](19, 2) NULL,
	[LAB_PEER_TOT] [decimal](19, 2) NULL,
	[SCRIPT_PEER_TOT] [decimal](19, 2) NULL,
	[GEN_PEER_TOT] [decimal](19, 2) NULL,
	[RAD_PEER_TOT] [decimal](19, 2) NULL,
	[MRI_PEER_TOT] [decimal](19, 2) NULL,
	[ADMIT_PEER_TOT] [decimal](19, 2) NULL,
	[SCRIPT_GEN_ACT_TOT] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_FAC_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NOT NULL,
	[DRG_UNIT_ID] [varchar](12) NOT NULL,
	[COST_ACT_TOT] [decimal](19, 2) NOT NULL,
	[COST2_ACT_TOT] [decimal](19, 2) NOT NULL,
	[COST3_ACT_TOT] [decimal](19, 2) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[DAYS_ACT_TOT] [decimal](19, 2) NOT NULL,
	[READMIT_07_ACT_TOT] [int] NOT NULL,
	[READMIT_30_ACT_TOT] [int] NOT NULL,
	[READMIT_60_ACT_TOT] [int] NOT NULL,
	[READMIT_90_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_07_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_30_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_60_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_90_ACT_TOT] [int] NOT NULL,
	[COST_PEER_TOT] [decimal](19, 2) NOT NULL,
	[COST2_PEER_TOT] [decimal](19, 2) NOT NULL,
	[COST3_PEER_TOT] [decimal](19, 2) NOT NULL,
	[DAYS_PEER_TOT] [decimal](19, 2) NOT NULL,
	[READMIT_07_PEER_TOT] [decimal](19, 2) NOT NULL,
	[READMIT_30_PEER_TOT] [decimal](19, 2) NOT NULL,
	[READMIT_60_PEER_TOT] [decimal](19, 2) NOT NULL,
	[READMIT_90_PEER_TOT] [decimal](19, 2) NOT NULL,
	[RRISK_ADM_ACT_TOT] [decimal](19, 2) NOT NULL,
	[RRISK_ADM_PEER_TOT] [decimal](19, 2) NOT NULL,
	[COST_ADM_ACT] [decimal](19, 2) NOT NULL,
	[COST2_ADM_ACT] [decimal](19, 2) NOT NULL,
	[COST3_ADM_ACT] [decimal](19, 2) NOT NULL,
	[COST_DAY_ACT] [decimal](19, 2) NOT NULL,
	[COST2_DAY_ACT] [decimal](19, 2) NOT NULL,
	[COST3_DAY_ACT] [decimal](19, 2) NOT NULL,
	[LOS_ADM_ACT] [decimal](19, 2) NOT NULL,
	[RRISK_ADM_ACT] [decimal](19, 2) NOT NULL,
	[READMIT_07_ACT] [decimal](19, 2) NOT NULL,
	[READMIT_30_ACT] [decimal](19, 2) NOT NULL,
	[READMIT_60_ACT] [decimal](19, 2) NOT NULL,
	[READMIT_90_ACT] [decimal](19, 2) NOT NULL,
	[RRISK_ADM_PEER] [decimal](19, 2) NOT NULL,
	[COST_ADM_IND] [decimal](19, 2) NOT NULL,
	[COST2_ADM_IND] [decimal](19, 2) NOT NULL,
	[COST3_ADM_IND] [decimal](19, 2) NOT NULL,
	[COST_DAY_IND] [decimal](19, 2) NOT NULL,
	[COST2_DAY_IND] [decimal](19, 2) NOT NULL,
	[COST3_DAY_IND] [decimal](19, 2) NOT NULL,
	[LOS_ADM_IND] [decimal](19, 2) NOT NULL,
	[READMIT_07_IND] [decimal](19, 2) NOT NULL,
	[READMIT_30_IND] [decimal](19, 2) NOT NULL,
	[READMIT_60_IND] [decimal](19, 2) NOT NULL,
	[READMIT_90_IND] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_FAC](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ADMIT_ELIG] [tinyint] NOT NULL,
	[ADM_CASE_MIX] [decimal](19, 2) NOT NULL,
	[ADM_CASE_MIX2] [decimal](19, 2) NOT NULL,
	[ADM_CASE_MIX3] [decimal](19, 2) NOT NULL,
	[RANK_DEC_ADM] [tinyint] NOT NULL,
	[RANK_DEC_ADM2] [tinyint] NOT NULL,
	[RANK_DEC_ADM3] [tinyint] NOT NULL,
	[COST_ACT_TOT] [decimal](19, 2) NOT NULL,
	[COST2_ACT_TOT] [decimal](19, 2) NOT NULL,
	[COST3_ACT_TOT] [decimal](19, 2) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[DAYS_ACT_TOT] [decimal](19, 2) NOT NULL,
	[RRISK_ADM_ACT_TOT] [decimal](19, 2) NOT NULL,
	[COST_ADM_ACT] [decimal](19, 2) NOT NULL,
	[COST2_ADM_ACT] [decimal](19, 2) NOT NULL,
	[COST3_ADM_ACT] [decimal](19, 2) NOT NULL,
	[COST_DAY_ACT] [decimal](19, 2) NOT NULL,
	[COST2_DAY_ACT] [decimal](19, 2) NOT NULL,
	[COST3_DAY_ACT] [decimal](19, 2) NOT NULL,
	[LOS_ADM_ACT] [decimal](19, 2) NOT NULL,
	[RRISK_ADM_ACT] [decimal](19, 2) NOT NULL,
	[READMIT_07_ACT_TOT] [int] NOT NULL,
	[READMIT_30_ACT_TOT] [int] NOT NULL,
	[READMIT_60_ACT_TOT] [int] NOT NULL,
	[READMIT_90_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_07_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_30_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_60_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_90_ACT_TOT] [int] NOT NULL,
	[READMIT_07_ACT] [decimal](19, 2) NOT NULL,
	[READMIT_30_ACT] [decimal](19, 2) NOT NULL,
	[READMIT_60_ACT] [decimal](19, 2) NOT NULL,
	[READMIT_90_ACT] [decimal](19, 2) NOT NULL,
	[COST_PEER_TOT] [decimal](19, 2) NOT NULL,
	[COST2_PEER_TOT] [decimal](19, 2) NOT NULL,
	[COST3_PEER_TOT] [decimal](19, 2) NOT NULL,
	[DAYS_PEER_TOT] [decimal](19, 2) NOT NULL,
	[RRISK_ADM_PEER_TOT] [decimal](19, 2) NOT NULL,
	[COST_ADM_PEER] [decimal](19, 2) NOT NULL,
	[COST2_ADM_PEER] [decimal](19, 2) NOT NULL,
	[COST3_ADM_PEER] [decimal](19, 2) NOT NULL,
	[COST_DAY_PEER] [decimal](19, 2) NOT NULL,
	[COST2_DAY_PEER] [decimal](19, 2) NOT NULL,
	[COST3_DAY_PEER] [decimal](19, 2) NOT NULL,
	[LOS_ADM_PEER] [decimal](19, 2) NOT NULL,
	[RRISK_ADM_PEER] [decimal](19, 2) NOT NULL,
	[READMIT_07_PEER_TOT] [decimal](19, 2) NOT NULL,
	[READMIT_30_PEER_TOT] [decimal](19, 2) NOT NULL,
	[READMIT_60_PEER_TOT] [decimal](19, 2) NOT NULL,
	[READMIT_90_PEER_TOT] [decimal](19, 2) NOT NULL,
	[READMIT_07_PEER] [decimal](19, 2) NOT NULL,
	[READMIT_30_PEER] [decimal](19, 2) NOT NULL,
	[READMIT_60_PEER] [decimal](19, 2) NOT NULL,
	[READMIT_90_PEER] [decimal](19, 2) NOT NULL,
	[COST_ADM_IND] [decimal](19, 2) NOT NULL,
	[COST2_ADM_IND] [decimal](19, 2) NOT NULL,
	[COST3_ADM_IND] [decimal](19, 2) NOT NULL,
	[COST_DAY_IND] [decimal](19, 2) NOT NULL,
	[COST2_DAY_IND] [decimal](19, 2) NOT NULL,
	[COST3_DAY_IND] [decimal](19, 2) NOT NULL,
	[LOS_ADM_IND] [decimal](19, 2) NOT NULL,
	[READMIT_07_IND] [decimal](19, 2) NOT NULL,
	[READMIT_30_IND] [decimal](19, 2) NOT NULL,
	[READMIT_60_IND] [decimal](19, 2) NOT NULL,
	[READMIT_90_IND] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_EPI_POP](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PCP_MEMBERS] [decimal](19, 2) NULL,
	[POP_MORB] [decimal](19, 2) NULL,
	[POP_MORB2] [decimal](19, 2) NULL,
	[POP_MORB3] [decimal](19, 2) NULL,
	[EPI_QTY] [decimal](19, 2) NULL,
	[EPI_CASE_MIX] [decimal](19, 2) NULL,
	[EPI_CASE_MIX2] [decimal](19, 2) NULL,
	[EPI_CASE_MIX3] [decimal](19, 2) NULL,
	[POP_COST_IND] [decimal](19, 2) NULL,
	[POP_COST_ACT_TOT] [decimal](19, 2) NULL,
	[POP_COST_PEER_TOT] [decimal](19, 2) NULL,
	[POP_COST2_IND] [decimal](19, 2) NULL,
	[POP_COST2_ACT_TOT] [decimal](19, 2) NULL,
	[POP_COST2_PEER_TOT] [decimal](19, 2) NULL,
	[POP_COST3_IND] [decimal](19, 2) NULL,
	[POP_COST3_ACT_TOT] [decimal](19, 2) NULL,
	[POP_COST3_PEER_TOT] [decimal](19, 2) NULL,
	[EPI_COST_IND] [decimal](19, 2) NULL,
	[EPI_COST_ACT_TOT] [decimal](19, 2) NULL,
	[EPI_COST_PEER_TOT] [decimal](19, 2) NULL,
	[EPI_COST2_IND] [decimal](19, 2) NULL,
	[EPI_COST2_ACT_TOT] [decimal](19, 2) NULL,
	[EPI_COST2_PEER_TOT] [decimal](19, 2) NULL,
	[EPI_COST3_IND] [decimal](19, 2) NULL,
	[EPI_COST3_ACT_TOT] [decimal](19, 2) NULL,
	[EPI_COST3_PEER_TOT] [decimal](19, 2) NULL,
	[RANK_DEC_POP] [tinyint] NULL,
	[RANK_DEC_POP2] [tinyint] NULL,
	[RANK_DEC_POP3] [tinyint] NULL,
	[RANK_DEC_EPI] [tinyint] NULL,
	[RANK_DEC_EPI2] [tinyint] NULL,
	[RANK_DEC_EPI3] [tinyint] NULL,
	[POP_ENC_IND] [decimal](19, 2) NULL,
	[POP_ENC_ACT_TOT] [decimal](19, 2) NULL,
	[POP_ENC_PEER_TOT] [decimal](19, 2) NULL,
	[EPI_ENC_IND] [decimal](19, 2) NULL,
	[EPI_ENC_ACT_TOT] [decimal](19, 2) NULL,
	[EPI_ENC_PEER_TOT] [decimal](19, 2) NULL,
	[PCP_MMOS] [decimal](19, 2) NOT NULL,
	[PCP_PEER_MMOS] [decimal](19, 2) NULL,
	[EPI_PEER_QTY] [decimal](19, 2) NULL,
	[EPI_ELIG] [tinyint] NULL,
	[PCP_ELIG] [tinyint] NULL,
	[POP_COST_OVR_IND] [decimal](19, 2) NULL,
	[POP_COST2_OVR_IND] [decimal](19, 2) NULL,
	[POP_COST3_OVR_IND] [decimal](19, 2) NULL,
	[POP_ENC_OVR_IND] [decimal](19, 2) NULL,
	[EPI_COST_OVR_IND] [decimal](19, 2) NULL,
	[EPI_COST2_OVR_IND] [decimal](19, 2) NULL,
	[EPI_COST3_OVR_IND] [decimal](19, 2) NULL,
	[EPI_ENC_OVR_IND] [decimal](19, 2) NULL,
	[CI_LO_EPI] [decimal](7, 2) NULL,
	[CI_HI_EPI] [decimal](7, 2) NULL,
	[SIGNIF_EPI] [varchar](2) NULL,
	[CI_LO_EPI2] [decimal](7, 2) NULL,
	[CI_HI_EPI2] [decimal](7, 2) NULL,
	[SIGNIF_EPI2] [varchar](2) NULL,
	[CI_LO_EPI3] [decimal](7, 2) NULL,
	[CI_HI_EPI3] [decimal](7, 2) NULL,
	[SIGNIF_EPI3] [varchar](2) NULL,
	[CI_LO_POP] [decimal](7, 2) NULL,
	[CI_HI_POP] [decimal](7, 2) NULL,
	[SIGNIF_POP] [varchar](2) NULL,
	[CI_LO_POP2] [decimal](7, 2) NULL,
	[CI_HI_POP2] [decimal](7, 2) NULL,
	[SIGNIF_POP2] [varchar](2) NULL,
	[CI_LO_POP3] [decimal](7, 2) NULL,
	[CI_HI_POP3] [decimal](7, 2) NULL,
	[SIGNIF_POP3] [varchar](2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_EPI_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[MPC] [smallint] NOT NULL,
	[FAMILY] [smallint] NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[COST_ACT_TOT] [decimal](19, 2) NULL,
	[COST2_ACT_TOT] [decimal](19, 2) NULL,
	[COST3_ACT_TOT] [decimal](19, 2) NULL,
	[COST_PEER_TOT] [decimal](19, 2) NULL,
	[COST2_PEER_TOT] [decimal](19, 2) NULL,
	[COST3_PEER_TOT] [decimal](19, 2) NULL,
	[COST_IND] [decimal](19, 2) NULL,
	[COST2_IND] [decimal](19, 2) NULL,
	[COST3_IND] [decimal](19, 2) NULL,
	[PCC_COST_ACT_TOT] [decimal](19, 2) NULL,
	[PCC_COST_PEER_TOT] [decimal](19, 2) NULL,
	[PCC_COST_IND] [decimal](19, 2) NULL,
	[SPEC_COST_ACT_TOT] [decimal](19, 2) NULL,
	[SPEC_COST_PEER_TOT] [decimal](19, 2) NULL,
	[SPEC_COST_IND] [decimal](19, 2) NULL,
	[ER_COST_ACT_TOT] [decimal](19, 2) NULL,
	[ER_COST_PEER_TOT] [decimal](19, 2) NULL,
	[ER_COST_IND] [decimal](19, 2) NULL,
	[RAD_COST_ACT_TOT] [decimal](19, 2) NULL,
	[RAD_COST_PEER_TOT] [decimal](19, 2) NULL,
	[RAD_COST_IND] [decimal](19, 2) NULL,
	[RX_COST_ACT_TOT] [decimal](19, 2) NULL,
	[RX_COST_PEER_TOT] [decimal](19, 2) NULL,
	[RX_COST_IND] [decimal](19, 2) NULL,
	[LAB_COST_ACT_TOT] [decimal](19, 2) NULL,
	[LAB_COST_PEER_TOT] [decimal](19, 2) NULL,
	[LAB_COST_IND] [decimal](19, 2) NULL,
	[HOSP_COST_ACT_TOT] [decimal](19, 2) NULL,
	[HOSP_COST_PEER_TOT] [decimal](19, 2) NULL,
	[HOSP_COST_IND] [decimal](19, 2) NULL,
	[ENC_ACT_TOT] [decimal](19, 2) NULL,
	[ENC_PEER_TOT] [decimal](19, 2) NULL,
	[ENC_IND] [decimal](19, 2) NULL,
	[PCC_ENC_ACT_TOT] [decimal](19, 2) NULL,
	[PCC_ENC_PEER_TOT] [decimal](19, 2) NULL,
	[PCC_ENC_IND] [decimal](19, 2) NULL,
	[SPEC_ENC_ACT_TOT] [decimal](19, 2) NULL,
	[SPEC_ENC_PEER_TOT] [decimal](19, 2) NULL,
	[SPEC_ENC_IND] [decimal](19, 2) NULL,
	[ER_ENC_ACT_TOT] [decimal](19, 2) NULL,
	[ER_ENC_PEER_TOT] [decimal](19, 2) NULL,
	[ER_ENC_IND] [decimal](19, 2) NULL,
	[RAD_ENC_ACT_TOT] [decimal](19, 2) NULL,
	[RAD_ENC_PEER_TOT] [decimal](19, 2) NULL,
	[RAD_ENC_IND] [decimal](19, 2) NULL,
	[RX_ENC_ACT_TOT] [decimal](19, 2) NULL,
	[RX_ENC_PEER_TOT] [decimal](19, 2) NULL,
	[RX_ENC_IND] [decimal](19, 2) NULL,
	[LAB_ENC_ACT_TOT] [decimal](19, 2) NULL,
	[LAB_ENC_PEER_TOT] [decimal](19, 2) NULL,
	[LAB_ENC_IND] [decimal](19, 2) NULL,
	[HOSP_ENC_ACT_TOT] [decimal](19, 2) NULL,
	[HOSP_ENC_PEER_TOT] [decimal](19, 2) NULL,
	[HOSP_ENC_IND] [decimal](19, 2) NULL,
	[SPVIS_PEER_TOT] [decimal](19, 2) NOT NULL,
	[OSPVIS_PEER_TOT] [decimal](19, 2) NOT NULL,
	[SCRIPT_PEER_TOT] [decimal](19, 2) NOT NULL,
	[RAD_PEER_TOT] [decimal](19, 2) NOT NULL,
	[LAB_PEER_TOT] [decimal](19, 2) NOT NULL,
	[ER_PEER_TOT] [decimal](19, 2) NOT NULL,
	[DAYS_PEER_TOT] [decimal](19, 2) NOT NULL,
	[MRI_PEER_TOT] [decimal](19, 2) NOT NULL,
	[GEN_PEER_TOT] [decimal](19, 2) NOT NULL,
	[ADMIT_PEER_TOT] [decimal](19, 2) NOT NULL,
	[SPVIS_ACT_TOT] [decimal](19, 2) NOT NULL,
	[OSPVIS_ACT_TOT] [decimal](19, 2) NOT NULL,
	[SCRIPT_ACT_TOT] [decimal](19, 2) NOT NULL,
	[RAD_ACT_TOT] [decimal](19, 2) NOT NULL,
	[LAB_ACT_TOT] [decimal](19, 2) NOT NULL,
	[ER_ACT_TOT] [decimal](19, 2) NOT NULL,
	[DAYS_ACT_TOT] [decimal](19, 2) NOT NULL,
	[MRI_ACT_TOT] [decimal](19, 2) NOT NULL,
	[GEN_ACT_TOT] [decimal](19, 2) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[SCRIPT_GEN_ACT_TOT] [decimal](19, 2) NOT NULL,
	[PCC_COST2_ACT_TOT] [decimal](19, 2) NULL,
	[PCC_COST2_PEER_TOT] [decimal](19, 2) NULL,
	[PCC_COST2_IND] [decimal](19, 2) NULL,
	[SPEC_COST2_ACT_TOT] [decimal](19, 2) NULL,
	[SPEC_COST2_PEER_TOT] [decimal](19, 2) NULL,
	[SPEC_COST2_IND] [decimal](19, 2) NULL,
	[ER_COST2_ACT_TOT] [decimal](19, 2) NULL,
	[ER_COST2_PEER_TOT] [decimal](19, 2) NULL,
	[ER_COST2_IND] [decimal](19, 2) NULL,
	[RAD_COST2_ACT_TOT] [decimal](19, 2) NULL,
	[RAD_COST2_PEER_TOT] [decimal](19, 2) NULL,
	[RAD_COST2_IND] [decimal](19, 2) NULL,
	[RX_COST2_ACT_TOT] [decimal](19, 2) NULL,
	[RX_COST2_PEER_TOT] [decimal](19, 2) NULL,
	[RX_COST2_IND] [decimal](19, 2) NULL,
	[LAB_COST2_ACT_TOT] [decimal](19, 2) NULL,
	[LAB_COST2_PEER_TOT] [decimal](19, 2) NULL,
	[LAB_COST2_IND] [decimal](19, 2) NULL,
	[HOSP_COST2_ACT_TOT] [decimal](19, 2) NULL,
	[HOSP_COST2_PEER_TOT] [decimal](19, 2) NULL,
	[HOSP_COST2_IND] [decimal](19, 2) NULL,
	[PCC_COST3_ACT_TOT] [decimal](19, 2) NULL,
	[PCC_COST3_PEER_TOT] [decimal](19, 2) NULL,
	[PCC_COST3_IND] [decimal](19, 2) NULL,
	[SPEC_COST3_ACT_TOT] [decimal](19, 2) NULL,
	[SPEC_COST3_PEER_TOT] [decimal](19, 2) NULL,
	[SPEC_COST3_IND] [decimal](19, 2) NULL,
	[ER_COST3_ACT_TOT] [decimal](19, 2) NULL,
	[ER_COST3_PEER_TOT] [decimal](19, 2) NULL,
	[ER_COST3_IND] [decimal](19, 2) NULL,
	[RAD_COST3_ACT_TOT] [decimal](19, 2) NULL,
	[RAD_COST3_PEER_TOT] [decimal](19, 2) NULL,
	[RAD_COST3_IND] [decimal](19, 2) NULL,
	[RX_COST3_ACT_TOT] [decimal](19, 2) NULL,
	[RX_COST3_PEER_TOT] [decimal](19, 2) NULL,
	[RX_COST3_IND] [decimal](19, 2) NULL,
	[LAB_COST3_ACT_TOT] [decimal](19, 2) NULL,
	[LAB_COST3_PEER_TOT] [decimal](19, 2) NULL,
	[LAB_COST3_IND] [decimal](19, 2) NULL,
	[HOSP_COST3_ACT_TOT] [decimal](19, 2) NULL,
	[HOSP_COST3_PEER_TOT] [decimal](19, 2) NULL,
	[HOSP_COST3_IND] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_DEM](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PROV_FEMALE_QTY] [decimal](19, 2) NULL,
	[PROV_FEMALE_PCT] [decimal](19, 2) NULL,
	[PEER_FEMALE_PCT] [decimal](19, 2) NULL,
	[PROV_MALE_QTY] [decimal](19, 2) NULL,
	[PROV_MALE_PCT] [decimal](19, 2) NULL,
	[PEER_MALE_PCT] [decimal](19, 2) NULL,
	[PEER_MALE_QTY] [decimal](19, 2) NULL,
	[PEER_FEMALE_QTY] [decimal](19, 2) NULL,
	[AGE_CAT2] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_CI_QUAL](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[EBM_NUM] [int] NOT NULL,
	[EBM_DEN] [int] NOT NULL,
	[PEER_EBM_NUM] [decimal](28, 6) NOT NULL,
	[SUM_ODD] [decimal](28, 6) NOT NULL,
	[VAR_ODD] [decimal](28, 6) NOT NULL,
	[WGT_VAR_ODD] [decimal](28, 6) NOT NULL,
	[CI_LO_QUAL] [decimal](7, 2) NULL,
	[CI_HI_QUAL] [decimal](7, 2) NULL,
	[SIGNIF_QUAL] [varchar](2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_CI_POP](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[PCP_MMOS] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NULL,
	[COST_PEER_TOT] [decimal](28, 6) NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NULL,
	[POP_PCT] [decimal](7, 4) NULL,
	[COST_ACT_TOT_VAR] [decimal](28, 6) NULL,
	[COST2_ACT_TOT_VAR] [decimal](28, 6) NULL,
	[COST3_ACT_TOT_VAR] [decimal](28, 6) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV_CI_EPI](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[EPI_QTY] [decimal](28, 6) NULL,
	[COST_ACT_TOT] [decimal](28, 6) NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NULL,
	[COST_PEER_TOT] [decimal](28, 6) NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NULL,
	[EPI_PCT] [decimal](7, 4) NULL,
	[COST_ACT_TOT_VAR] [decimal](28, 6) NULL,
	[COST2_ACT_TOT_VAR] [decimal](28, 6) NULL,
	[COST3_ACT_TOT_VAR] [decimal](28, 6) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_PROV](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PCP_MEMBERS] [decimal](19, 2) NOT NULL,
	[POP_MORB] [decimal](19, 2) NOT NULL,
	[POP_MORB2] [decimal](19, 2) NOT NULL,
	[POP_MORB3] [decimal](19, 2) NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[EPI_CASE_MIX] [decimal](19, 2) NOT NULL,
	[POP_COST_IND] [decimal](19, 2) NOT NULL,
	[POP_COST2_IND] [decimal](19, 2) NOT NULL,
	[POP_COST3_IND] [decimal](19, 2) NOT NULL,
	[POP_COST_ACT_TOT] [decimal](19, 2) NOT NULL,
	[POP_COST2_ACT_TOT] [decimal](19, 2) NOT NULL,
	[POP_COST3_ACT_TOT] [decimal](19, 2) NOT NULL,
	[POP_COST_PEER_TOT] [decimal](19, 2) NOT NULL,
	[POP_COST2_PEER_TOT] [decimal](19, 2) NOT NULL,
	[POP_COST3_PEER_TOT] [decimal](19, 2) NOT NULL,
	[EPI_COST_IND] [decimal](19, 2) NOT NULL,
	[EPI_COST2_IND] [decimal](19, 2) NOT NULL,
	[EPI_COST3_IND] [decimal](19, 2) NOT NULL,
	[EPI_COST_ACT_TOT] [decimal](19, 2) NOT NULL,
	[EPI_COST2_ACT_TOT] [decimal](19, 2) NOT NULL,
	[EPI_COST3_ACT_TOT] [decimal](19, 2) NOT NULL,
	[EPI_COST_PEER_TOT] [decimal](19, 2) NOT NULL,
	[EPI_COST2_PEER_TOT] [decimal](19, 2) NOT NULL,
	[EPI_COST3_PEER_TOT] [decimal](19, 2) NOT NULL,
	[RANK_DEC_POP] [tinyint] NULL,
	[RANK_DEC_POP2] [tinyint] NULL,
	[RANK_DEC_POP3] [tinyint] NULL,
	[RANK_DEC_EPI] [tinyint] NULL,
	[RANK_DEC_EPI2] [tinyint] NULL,
	[RANK_DEC_EPI3] [tinyint] NULL,
	[POP_ENC_IND] [decimal](19, 2) NOT NULL,
	[POP_ENC_ACT_TOT] [decimal](19, 2) NOT NULL,
	[POP_ENC_PEER_TOT] [decimal](19, 2) NOT NULL,
	[EPI_ENC_IND] [decimal](19, 2) NOT NULL,
	[EPI_ENC_ACT_TOT] [decimal](19, 2) NOT NULL,
	[EPI_ENC_PEER_TOT] [decimal](19, 2) NOT NULL,
	[PCP_MMOS] [decimal](19, 2) NOT NULL,
	[PCP_PEER_MMOS] [decimal](19, 2) NOT NULL,
	[EPI_PEER_QTY] [decimal](19, 2) NOT NULL,
	[EPI_ELIG] [tinyint] NOT NULL,
	[PCP_ELIG] [tinyint] NOT NULL,
	[POP_COST_OVR_IND] [decimal](19, 2) NOT NULL,
	[POP_COST2_OVR_IND] [decimal](19, 2) NOT NULL,
	[POP_COST3_OVR_IND] [decimal](19, 2) NOT NULL,
	[POP_ENC_OVR_IND] [decimal](19, 2) NOT NULL,
	[EPI_COST_OVR_IND] [decimal](19, 2) NOT NULL,
	[EPI_COST2_OVR_IND] [decimal](19, 2) NOT NULL,
	[EPI_COST3_OVR_IND] [decimal](19, 2) NOT NULL,
	[EPI_ENC_OVR_IND] [decimal](19, 2) NOT NULL,
	[QUAL_ELIG] [tinyint] NOT NULL,
	[QUAL_EBM_DEN] [int] NOT NULL,
	[QUAL_EBM_NUM] [int] NOT NULL,
	[RANK_DEC_QUAL] [tinyint] NULL,
	[QUAL_OVR_IND] [decimal](28, 6) NOT NULL,
	[QUAL_PEER_EBM_NUM] [decimal](28, 6) NOT NULL,
	[QUAL_RATE] [decimal](19, 2) NOT NULL,
	[PROVIDER_NAME] [varchar](50) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[AFFIL_ID] [varchar](40) NULL,
	[SEC_PROVIDER_ID] [varchar](20) NULL,
	[PROV_USERDEF_1] [varchar](100) NULL,
	[PROV_USERDEF_2_ID] [varchar](40) NULL,
	[ZIP] [char](5) NOT NULL,
	[PEER_DEF_DESC] [varchar](50) NOT NULL,
	[PEER_CAT1_ID] [tinyint] NOT NULL,
	[SP4] [varchar](40) NOT NULL,
	[SP2_ID] [smallint] NOT NULL,
	[SP3_ID] [smallint] NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[STATE] [tinyint] NOT NULL,
	[CENS_REG] [tinyint] NOT NULL,
	[CENS_REG_DESC] [varchar](30) NOT NULL,
	[STATE_DESC] [char](2) NOT NULL,
	[COUNTY_DESC] [varchar](40) NOT NULL,
	[PROV_AFFIL] [varchar](30) NULL,
	[PROV_AFFIL_DESC] [varchar](150) NULL,
	[PROV_AFFIL_LV2_ID] [varchar](100) NULL,
	[PROV_AFFIL_LV2] [varchar](30) NULL,
	[PROV_AFFIL_LV2_DESC] [varchar](150) NULL,
	[PROV_AFFIL_LV1_ID] [varchar](100) NULL,
	[PROV_AFFIL_LV1] [varchar](30) NULL,
	[PROV_AFFIL_LV1_DESC] [varchar](150) NULL,
	[PROV_USERDEF_2_DESC] [varchar](150) NULL,
	[PEER_CAT2_ID] [tinyint] NOT NULL,
	[PEER_CAT2_DESC] [varchar](50) NULL,
	[IA_TIME_DESC] [varchar](25) NOT NULL,
	[IA_TIME_CODE] [varchar](15) NULL,
	[IA_TIME_DATE_DESC] [varchar](25) NULL,
	[IA_TIME_FULL_DESC] [varchar](55) NULL,
	[IA_TIME_START_DATE] [smalldatetime] NULL,
	[IA_TIME_END_DATE] [smalldatetime] NULL,
	[PD_POP_COST_PEER_TOT] [decimal](38, 2) NULL,
	[PD_POP_COST2_PEER_TOT] [decimal](38, 2) NULL,
	[PD_POP_COST3_PEER_TOT] [decimal](38, 2) NULL,
	[PD_EPI_COST_PEER_TOT] [decimal](38, 2) NULL,
	[PD_EPI_COST2_PEER_TOT] [decimal](38, 2) NULL,
	[PD_EPI_COST3_PEER_TOT] [decimal](38, 2) NULL,
	[EPI_QTY_0] [decimal](28, 2) NOT NULL,
	[EPI_PCC_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_PCC_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RX_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_LAB_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RAD_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_ER_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_PCC_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RX_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_LAB_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_RAD_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_ER_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[EPI_PCC_PCT_0] [decimal](7, 4) NOT NULL,
	[EPI_SPEC_PCT_0] [decimal](7, 4) NOT NULL,
	[EPI_HOSP_PCT_0] [decimal](7, 4) NOT NULL,
	[EPI_PHM_PCT_0] [decimal](7, 4) NOT NULL,
	[EPI_LAB_PCT_0] [decimal](7, 4) NOT NULL,
	[EPI_RAD_PCT_0] [decimal](7, 4) NOT NULL,
	[EPI_ER_PCT_0] [decimal](7, 4) NOT NULL,
	[EPI_QTY_1] [decimal](28, 2) NOT NULL,
	[EPI_PCC_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_PCC_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RX_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_LAB_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RAD_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_ER_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_PCC_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RX_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_LAB_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RAD_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_ER_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[EPI_PCC_PCT_1] [decimal](7, 4) NOT NULL,
	[EPI_SPEC_PCT_1] [decimal](7, 4) NOT NULL,
	[EPI_HOSP_PCT_1] [decimal](7, 4) NOT NULL,
	[EPI_PHM_PCT_1] [decimal](7, 4) NOT NULL,
	[EPI_LAB_PCT_1] [decimal](7, 4) NOT NULL,
	[EPI_RAD_PCT_1] [decimal](7, 4) NOT NULL,
	[EPI_ER_PCT_1] [decimal](7, 4) NOT NULL,
	[EPI_PCC_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_PCC_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_SPEC_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_HOSP_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_RX_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_LAB_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_RAD_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[EPI_ER_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[CI_EPI_VAL] [numeric](4, 3) NOT NULL,
	[PCP_MMOS_0] [numeric](28, 6) NOT NULL,
	[POP_PCC_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RX_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_ER_COST_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RX_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_ER_COST2_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RX_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_ER_COST3_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RX_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_ER_COST_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RX_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_ER_COST2_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RX_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_ER_COST3_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_PCC_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_SPEC_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_HOSP_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RX_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_LAB_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RAD_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_ER_ENC_ACT_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_PCC_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_SPEC_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_HOSP_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RX_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_LAB_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_RAD_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_ER_ENC_PEER_TOT_0] [decimal](28, 6) NOT NULL,
	[POP_PCC_PCT_0] [decimal](7, 4) NOT NULL,
	[POP_SPEC_PCT_0] [decimal](7, 4) NOT NULL,
	[POP_HOSP_PCT_0] [decimal](7, 4) NOT NULL,
	[POP_PHM_PCT_0] [decimal](7, 4) NOT NULL,
	[POP_LAB_PCT_0] [decimal](7, 4) NOT NULL,
	[POP_RAD_PCT_0] [decimal](7, 4) NOT NULL,
	[POP_ER_PCT_0] [decimal](7, 4) NOT NULL,
	[PCP_MMOS_1] [numeric](28, 6) NOT NULL,
	[POP_PCC_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RX_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_ER_COST_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RX_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_ER_COST2_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RX_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_ER_COST3_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RX_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_ER_COST_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RX_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_ER_COST2_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RX_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_ER_COST3_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_PCC_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_SPEC_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_HOSP_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RX_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_LAB_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RAD_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_ER_ENC_ACT_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_PCC_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_SPEC_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_HOSP_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RX_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_LAB_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_RAD_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_ER_ENC_PEER_TOT_1] [decimal](28, 6) NOT NULL,
	[POP_PCC_PCT_1] [decimal](7, 4) NOT NULL,
	[POP_SPEC_PCT_1] [decimal](7, 4) NOT NULL,
	[POP_HOSP_PCT_1] [decimal](7, 4) NOT NULL,
	[POP_PHM_PCT_1] [decimal](7, 4) NOT NULL,
	[POP_LAB_PCT_1] [decimal](7, 4) NOT NULL,
	[POP_RAD_PCT_1] [decimal](7, 4) NOT NULL,
	[POP_ER_PCT_1] [decimal](7, 4) NOT NULL,
	[POP_PCC_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_RX_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_ER_COST_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_RX_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_ER_COST2_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_PCC_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_SPEC_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_HOSP_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_RX_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_LAB_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_RAD_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[POP_ER_COST3_ACT_TOT_VAR] [decimal](28, 6) NOT NULL,
	[CI_POP_VAL] [numeric](4, 3) NOT NULL,
	[CI_EBM_NUM] [decimal](28, 6) NULL,
	[CI_EBM_DEN] [decimal](28, 6) NULL,
	[CI_QUAL_VAL] [numeric](4, 3) NOT NULL,
	[CI_QUAL_WGT_VAR_ODD] [decimal](28, 6) NOT NULL,
	[CI_QUAL_SUM_ODD] [decimal](28, 6) NOT NULL,
	[CI_PEER_EBM_NUM] [decimal](28, 6) NOT NULL,
	[EPI_PHM_QUAL_1] [tinyint] NULL,
	[POP_PHM_QUAL_1] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_OCU_TREND](
	[MEM_ATTR_ID] [int] NOT NULL,
	[TOS_LEVEL] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NULL,
	[TOS2_ID] [smallint] NULL,
	[TOS3_ID] [int] NULL,
	[MM_Q1] [decimal](19, 2) NOT NULL,
	[RRISK_Q1] [decimal](19, 4) NOT NULL,
	[COST1_Q1] [decimal](19, 2) NOT NULL,
	[COST2_Q1] [decimal](19, 2) NOT NULL,
	[COST3_Q1] [decimal](19, 2) NOT NULL,
	[COST4_Q1] [decimal](19, 2) NOT NULL,
	[COST5_Q1] [decimal](19, 2) NOT NULL,
	[COST6_Q1] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q1] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q1] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q1] [decimal](19, 2) NOT NULL,
	[MM_Q2] [decimal](19, 2) NOT NULL,
	[RRISK_Q2] [decimal](19, 4) NOT NULL,
	[COST1_Q2] [decimal](19, 2) NOT NULL,
	[COST2_Q2] [decimal](19, 2) NOT NULL,
	[COST3_Q2] [decimal](19, 2) NOT NULL,
	[COST4_Q2] [decimal](19, 2) NOT NULL,
	[COST5_Q2] [decimal](19, 2) NOT NULL,
	[COST6_Q2] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q2] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q2] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q2] [decimal](19, 2) NOT NULL,
	[MM_Q3] [decimal](19, 2) NOT NULL,
	[RRISK_Q3] [decimal](19, 4) NOT NULL,
	[COST1_Q3] [decimal](19, 2) NOT NULL,
	[COST2_Q3] [decimal](19, 2) NOT NULL,
	[COST3_Q3] [decimal](19, 2) NOT NULL,
	[COST4_Q3] [decimal](19, 2) NOT NULL,
	[COST5_Q3] [decimal](19, 2) NOT NULL,
	[COST6_Q3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q3] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q3] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q3] [decimal](19, 2) NOT NULL,
	[MM_Q4] [decimal](19, 2) NOT NULL,
	[RRISK_Q4] [decimal](19, 4) NOT NULL,
	[COST1_Q4] [decimal](19, 2) NOT NULL,
	[COST2_Q4] [decimal](19, 2) NOT NULL,
	[COST3_Q4] [decimal](19, 2) NOT NULL,
	[COST4_Q4] [decimal](19, 2) NOT NULL,
	[COST5_Q4] [decimal](19, 2) NOT NULL,
	[COST6_Q4] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q4] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q4] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q4] [decimal](19, 2) NOT NULL,
	[MM_Q5] [decimal](19, 2) NOT NULL,
	[RRISK_Q5] [decimal](19, 4) NOT NULL,
	[COST1_Q5] [decimal](19, 2) NOT NULL,
	[COST2_Q5] [decimal](19, 2) NOT NULL,
	[COST3_Q5] [decimal](19, 2) NOT NULL,
	[COST4_Q5] [decimal](19, 2) NOT NULL,
	[COST5_Q5] [decimal](19, 2) NOT NULL,
	[COST6_Q5] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q5] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q5] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q5] [decimal](19, 2) NOT NULL,
	[MM_Q6] [decimal](19, 2) NOT NULL,
	[RRISK_Q6] [decimal](19, 4) NOT NULL,
	[COST1_Q6] [decimal](19, 2) NOT NULL,
	[COST2_Q6] [decimal](19, 2) NOT NULL,
	[COST3_Q6] [decimal](19, 2) NOT NULL,
	[COST4_Q6] [decimal](19, 2) NOT NULL,
	[COST5_Q6] [decimal](19, 2) NOT NULL,
	[COST6_Q6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q6] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q6] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q6] [decimal](19, 2) NOT NULL,
	[MM_Q7] [decimal](19, 2) NOT NULL,
	[RRISK_Q7] [decimal](19, 4) NOT NULL,
	[COST1_Q7] [decimal](19, 2) NOT NULL,
	[COST2_Q7] [decimal](19, 2) NOT NULL,
	[COST3_Q7] [decimal](19, 2) NOT NULL,
	[COST4_Q7] [decimal](19, 2) NOT NULL,
	[COST5_Q7] [decimal](19, 2) NOT NULL,
	[COST6_Q7] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q7] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q7] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q7] [decimal](19, 2) NOT NULL,
	[MM_Q8] [decimal](19, 2) NOT NULL,
	[RRISK_Q8] [decimal](19, 4) NOT NULL,
	[COST1_Q8] [decimal](19, 2) NOT NULL,
	[COST2_Q8] [decimal](19, 2) NOT NULL,
	[COST3_Q8] [decimal](19, 2) NOT NULL,
	[COST4_Q8] [decimal](19, 2) NOT NULL,
	[COST5_Q8] [decimal](19, 2) NOT NULL,
	[COST6_Q8] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q8] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q8] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q8] [decimal](19, 2) NOT NULL,
	[MM_Y1] [decimal](19, 2) NOT NULL,
	[RRISK_Y1] [decimal](19, 4) NOT NULL,
	[COST1_Y1] [decimal](19, 2) NOT NULL,
	[COST2_Y1] [decimal](19, 2) NOT NULL,
	[COST3_Y1] [decimal](19, 2) NOT NULL,
	[COST4_Y1] [decimal](19, 2) NOT NULL,
	[COST5_Y1] [decimal](19, 2) NOT NULL,
	[COST6_Y1] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Y1] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Y1] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Y1] [decimal](19, 2) NOT NULL,
	[MM_Y2] [decimal](19, 2) NOT NULL,
	[RRISK_Y2] [decimal](19, 4) NOT NULL,
	[COST1_Y2] [decimal](19, 2) NOT NULL,
	[COST2_Y2] [decimal](19, 2) NOT NULL,
	[COST3_Y2] [decimal](19, 2) NOT NULL,
	[COST4_Y2] [decimal](19, 2) NOT NULL,
	[COST5_Y2] [decimal](19, 2) NOT NULL,
	[COST6_Y2] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Y2] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Y2] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Y2] [decimal](19, 2) NOT NULL,
	[MM_T] [decimal](19, 2) NOT NULL,
	[RRISK_T] [decimal](19, 4) NOT NULL,
	[COST1_T] [decimal](19, 2) NOT NULL,
	[COST2_T] [decimal](19, 2) NOT NULL,
	[COST3_T] [decimal](19, 2) NOT NULL,
	[COST4_T] [decimal](19, 2) NOT NULL,
	[COST5_T] [decimal](19, 2) NOT NULL,
	[COST6_T] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_T] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_T] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_T] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_OCU_POP_TOS](
	[TOS_LEVEL] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NULL,
	[TOS2_ID] [smallint] NULL,
	[TOS3_ID] [int] NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[AGE_TOT] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[COST3_MEDTOT] [decimal](19, 2) NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[LOS_IFAC] [int] NOT NULL,
	[ENCOUNTER_IFAC] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_OCU_POP_SPEC](
	[SPEC_LEVEL] [tinyint] NOT NULL,
	[SP1_ID] [smallint] NULL,
	[SP2_ID] [smallint] NULL,
	[SP3_ID] [smallint] NULL,
	[SP4_ID] [int] NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_OCU_POP_PHM](
	[TOS_LEVEL] [tinyint] NOT NULL,
	[TOS2_ID] [smallint] NULL,
	[TOS3_ID] [int] NULL,
	[TOS4_ID] [int] NULL,
	[TOS5_ID] [int] NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[BRAND_NAME] [varchar](50) NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[DAYS_SUP] [int] NULL,
	[GENERIC] [int] NOT NULL,
	[SCRIPT_GEN] [int] NULL,
	[SCRIPT] [int] NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[COST3_FORM] [decimal](19, 2) NOT NULL,
	[SCRIPT_FORM] [int] NOT NULL,
	[COST3_MAIL] [decimal](19, 2) NOT NULL,
	[SCRIPT_MAIL] [int] NOT NULL,
	[COST3_GEN] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_OCU_POP_AGG](
	[QOPA_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[LOS] [int] NULL,
	[ADMIT] [int] NULL,
	[ER_UTIL] [decimal](19, 2) NULL,
	[RAD_UTIL] [decimal](19, 2) NULL,
	[LAB_UTIL] [decimal](19, 2) NULL,
	[MRI_UTIL] [decimal](19, 2) NULL,
	[EM_SVC_FLAG] [int] NULL,
	[SCRIPT] [int] NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_OCU_EPI_TOS](
	[TOS_LEVEL] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NULL,
	[TOS2_ID] [smallint] NULL,
	[TOS3_ID] [int] NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_OCU_EPI_SPEC](
	[SPEC_LEVEL] [tinyint] NOT NULL,
	[SP1_ID] [smallint] NULL,
	[SP2_ID] [smallint] NULL,
	[SP3_ID] [smallint] NULL,
	[SP4_ID] [int] NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_OCU_EPI_PHM](
	[TOS_LEVEL] [tinyint] NOT NULL,
	[TOS2_ID] [smallint] NULL,
	[TOS3_ID] [int] NULL,
	[TOS4_ID] [int] NULL,
	[TOS5_ID] [int] NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[DAYS_SUP] [int] NULL,
	[GENERIC] [int] NOT NULL,
	[SCRIPT_GEN] [int] NULL,
	[SCRIPT] [int] NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_OCU_EPI_AGG](
	[QOEA_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[LOS] [int] NULL,
	[ADMIT] [int] NULL,
	[ER_UTIL] [decimal](19, 2) NULL,
	[RAD_UTIL] [decimal](19, 2) NULL,
	[LAB_UTIL] [decimal](19, 2) NULL,
	[MRI_UTIL] [decimal](19, 2) NULL,
	[EM_SVC_FLAG] [int] NULL,
	[SCRIPT] [int] NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_OCU_ADM_FAC](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[DRG_ID] [varchar](12) NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[ADM_YEAR_MTH_ID] [tinyint] NOT NULL,
	[QOAF_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ADMIT] [int] NOT NULL,
	[LOS] [int] NOT NULL,
	[READMIT_07] [int] NULL,
	[READMIT_30] [int] NULL,
	[READMIT_60] [int] NULL,
	[READMIT_90] [int] NULL,
	[READMIT_INDEX_07] [int] NULL,
	[READMIT_INDEX_30] [int] NULL,
	[READMIT_INDEX_60] [int] NULL,
	[READMIT_INDEX_90] [int] NULL,
	[RRISK] [decimal](10, 4) NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_MEMBERS](
	[MEMBER] [varchar](32) NOT NULL,
	[LAST_NAME] [varchar](50) NULL,
	[FIRST_NAME] [varchar](50) NULL,
	[FULL_NAME] [varchar](100) NULL,
	[LAST_ACTIVE_DT] [smalldatetime] NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[COVERAGE_STATUS_ID] [varchar](40) NOT NULL,
	[CONTRACT_TYPE_ID] [varchar](40) NOT NULL,
	[SEX] [bit] NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[AT_RISK_STATUS_ID] [varchar](40) NOT NULL,
	[ZIP] [char](5) NOT NULL,
	[PCP_ID] [varchar](20) NULL,
	[INDUSTRY] [tinyint] NULL,
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL,
	[SUBSCRIBER_ID] [varchar](32) NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[COST1_TOT] [decimal](19, 2) NOT NULL,
	[COST2_TOT] [decimal](19, 2) NOT NULL,
	[COST3_TOT] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_TOT] [decimal](19, 2) NOT NULL,
	[LOS] [int] NOT NULL,
	[ADMIT] [int] NOT NULL,
	[EM_SVC_FLAG] [int] NOT NULL,
	[SCRIPT] [int] NOT NULL,
	[COST1_MEDTOT] [decimal](19, 2) NOT NULL,
	[COST1_IFAC] [decimal](19, 2) NOT NULL,
	[COST1_OFAC] [decimal](19, 2) NOT NULL,
	[COST1_PROF] [decimal](19, 2) NOT NULL,
	[COST1_PHM] [decimal](19, 2) NOT NULL,
	[COST1_ANC] [decimal](19, 2) NOT NULL,
	[COST2_MEDTOT] [decimal](19, 2) NOT NULL,
	[COST2_IFAC] [decimal](19, 2) NOT NULL,
	[COST2_OFAC] [decimal](19, 2) NOT NULL,
	[COST2_PROF] [decimal](19, 2) NOT NULL,
	[COST2_PHM] [decimal](19, 2) NOT NULL,
	[COST2_ANC] [decimal](19, 2) NOT NULL,
	[COST3_MEDTOT] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL,
	[COST3_PROF] [decimal](19, 2) NOT NULL,
	[COST3_PHM] [decimal](19, 2) NOT NULL,
	[COST3_ANC] [decimal](19, 2) NOT NULL,
	[ER_UTIL] [decimal](19, 2) NOT NULL,
	[RAD_UTIL] [decimal](19, 2) NOT NULL,
	[LAB_UTIL] [decimal](19, 2) NOT NULL,
	[MRI_UTIL] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_OFAC] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_PROF] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_ANC] [decimal](19, 2) NOT NULL,
	[EBM_DEN_TOT] [int] NOT NULL,
	[EBM_NUM_TOT] [int] NOT NULL,
	[EBM_RATE_TOT] [decimal](19, 2) NOT NULL,
	[NUM_EPISODES] [int] NOT NULL,
	[NUM_CLAIMS] [int] NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[COMP_CASE_RULE$] [varchar](max) NULL,
	[NCOMP_CASE_RULE$] [varchar](max) NULL,
	[MEM_IA_TIME_CODE] [varchar](50) NOT NULL,
	[COST4_TOT] [decimal](19, 2) NOT NULL,
	[COST5_TOT] [decimal](19, 2) NOT NULL,
	[COST6_TOT] [decimal](19, 2) NOT NULL,
	[COST4_MEDTOT] [decimal](19, 2) NOT NULL,
	[COST4_IFAC] [decimal](19, 2) NOT NULL,
	[COST4_OFAC] [decimal](19, 2) NOT NULL,
	[COST4_PROF] [decimal](19, 2) NOT NULL,
	[COST4_PHM] [decimal](19, 2) NOT NULL,
	[COST4_ANC] [decimal](19, 2) NOT NULL,
	[COST5_MEDTOT] [decimal](19, 2) NOT NULL,
	[COST5_IFAC] [decimal](19, 2) NOT NULL,
	[COST5_OFAC] [decimal](19, 2) NOT NULL,
	[COST5_PROF] [decimal](19, 2) NOT NULL,
	[COST5_PHM] [decimal](19, 2) NOT NULL,
	[COST5_ANC] [decimal](19, 2) NOT NULL,
	[COST6_MEDTOT] [decimal](19, 2) NOT NULL,
	[COST6_IFAC] [decimal](19, 2) NOT NULL,
	[COST6_OFAC] [decimal](19, 2) NOT NULL,
	[COST6_PROF] [decimal](19, 2) NOT NULL,
	[COST6_PHM] [decimal](19, 2) NOT NULL,
	[COST6_ANC] [decimal](19, 2) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_EPISODES](
	[MEMBER] [varchar](32) NOT NULL,
	[EPISODE_ID] [int] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[EPI_FROM] [smalldatetime] NOT NULL,
	[EPI_TO] [smalldatetime] NOT NULL,
	[EPI_DURATION] [decimal](19, 2) NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[EPI_TYPE] [tinyint] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[MED_QUAL] [bit] NOT NULL,
	[RRISK] [decimal](10, 4) NULL,
	[TX_IND] [tinyint] NOT NULL,
	[COST1_TOT] [decimal](19, 2) NOT NULL,
	[COST2_TOT] [decimal](19, 2) NOT NULL,
	[COST3_TOT] [decimal](19, 2) NOT NULL,
	[LOS] [int] NOT NULL,
	[COST1_MEDTOT] [decimal](19, 2) NOT NULL,
	[COST1_IFAC] [decimal](19, 2) NOT NULL,
	[COST1_OFAC] [decimal](19, 2) NOT NULL,
	[COST1_PROF] [decimal](19, 2) NOT NULL,
	[COST1_PHM] [decimal](19, 2) NOT NULL,
	[COST1_ANC] [decimal](19, 2) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PCP_IMP] [varchar](20) NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[CAT_STATUS_COST3] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[AGE] [smallint] NOT NULL,
	[ZIP] [char](5) NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[PCP_ID] [varchar](20) NULL,
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[COVERAGE_STATUS_ID] [varchar](40) NOT NULL,
	[CONTRACT_TYPE_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[AT_RISK_STATUS_ID] [varchar](40) NOT NULL,
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL,
	[INDUSTRY] [tinyint] NULL,
	[MPG_DEF_ID] [int] NULL,
	[CONTRACT_ID] [varchar](40) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_EMP_TREND](
	[MEM_ATTR_ID] [int] NOT NULL,
	[TOS_LEVEL] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NULL,
	[TOS2_ID] [smallint] NULL,
	[TOS3_ID] [int] NULL,
	[MM_Q1] [decimal](19, 2) NOT NULL,
	[RRISK_Q1] [decimal](19, 4) NOT NULL,
	[COST1_Q1] [decimal](19, 2) NOT NULL,
	[COST2_Q1] [decimal](19, 2) NOT NULL,
	[COST3_Q1] [decimal](19, 2) NOT NULL,
	[COST4_Q1] [decimal](19, 2) NOT NULL,
	[COST5_Q1] [decimal](19, 2) NOT NULL,
	[COST6_Q1] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q1] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q1] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q1] [decimal](19, 2) NOT NULL,
	[MM_Q2] [decimal](19, 2) NOT NULL,
	[RRISK_Q2] [decimal](19, 4) NOT NULL,
	[COST1_Q2] [decimal](19, 2) NOT NULL,
	[COST2_Q2] [decimal](19, 2) NOT NULL,
	[COST3_Q2] [decimal](19, 2) NOT NULL,
	[COST4_Q2] [decimal](19, 2) NOT NULL,
	[COST5_Q2] [decimal](19, 2) NOT NULL,
	[COST6_Q2] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q2] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q2] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q2] [decimal](19, 2) NOT NULL,
	[MM_Q3] [decimal](19, 2) NOT NULL,
	[RRISK_Q3] [decimal](19, 4) NOT NULL,
	[COST1_Q3] [decimal](19, 2) NOT NULL,
	[COST2_Q3] [decimal](19, 2) NOT NULL,
	[COST3_Q3] [decimal](19, 2) NOT NULL,
	[COST4_Q3] [decimal](19, 2) NOT NULL,
	[COST5_Q3] [decimal](19, 2) NOT NULL,
	[COST6_Q3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q3] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q3] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q3] [decimal](19, 2) NOT NULL,
	[MM_Q4] [decimal](19, 2) NOT NULL,
	[RRISK_Q4] [decimal](19, 4) NOT NULL,
	[COST1_Q4] [decimal](19, 2) NOT NULL,
	[COST2_Q4] [decimal](19, 2) NOT NULL,
	[COST3_Q4] [decimal](19, 2) NOT NULL,
	[COST4_Q4] [decimal](19, 2) NOT NULL,
	[COST5_Q4] [decimal](19, 2) NOT NULL,
	[COST6_Q4] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q4] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q4] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q4] [decimal](19, 2) NOT NULL,
	[MM_Q5] [decimal](19, 2) NOT NULL,
	[RRISK_Q5] [decimal](19, 4) NOT NULL,
	[COST1_Q5] [decimal](19, 2) NOT NULL,
	[COST2_Q5] [decimal](19, 2) NOT NULL,
	[COST3_Q5] [decimal](19, 2) NOT NULL,
	[COST4_Q5] [decimal](19, 2) NOT NULL,
	[COST5_Q5] [decimal](19, 2) NOT NULL,
	[COST6_Q5] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q5] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q5] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q5] [decimal](19, 2) NOT NULL,
	[MM_Q6] [decimal](19, 2) NOT NULL,
	[RRISK_Q6] [decimal](19, 4) NOT NULL,
	[COST1_Q6] [decimal](19, 2) NOT NULL,
	[COST2_Q6] [decimal](19, 2) NOT NULL,
	[COST3_Q6] [decimal](19, 2) NOT NULL,
	[COST4_Q6] [decimal](19, 2) NOT NULL,
	[COST5_Q6] [decimal](19, 2) NOT NULL,
	[COST6_Q6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q6] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q6] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q6] [decimal](19, 2) NOT NULL,
	[MM_Q7] [decimal](19, 2) NOT NULL,
	[RRISK_Q7] [decimal](19, 4) NOT NULL,
	[COST1_Q7] [decimal](19, 2) NOT NULL,
	[COST2_Q7] [decimal](19, 2) NOT NULL,
	[COST3_Q7] [decimal](19, 2) NOT NULL,
	[COST4_Q7] [decimal](19, 2) NOT NULL,
	[COST5_Q7] [decimal](19, 2) NOT NULL,
	[COST6_Q7] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q7] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q7] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q7] [decimal](19, 2) NOT NULL,
	[MM_Q8] [decimal](19, 2) NOT NULL,
	[RRISK_Q8] [decimal](19, 4) NOT NULL,
	[COST1_Q8] [decimal](19, 2) NOT NULL,
	[COST2_Q8] [decimal](19, 2) NOT NULL,
	[COST3_Q8] [decimal](19, 2) NOT NULL,
	[COST4_Q8] [decimal](19, 2) NOT NULL,
	[COST5_Q8] [decimal](19, 2) NOT NULL,
	[COST6_Q8] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Q8] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Q8] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Q8] [decimal](19, 2) NOT NULL,
	[MM_Y1] [decimal](19, 2) NOT NULL,
	[RRISK_Y1] [decimal](19, 4) NOT NULL,
	[COST1_Y1] [decimal](19, 2) NOT NULL,
	[COST2_Y1] [decimal](19, 2) NOT NULL,
	[COST3_Y1] [decimal](19, 2) NOT NULL,
	[COST4_Y1] [decimal](19, 2) NOT NULL,
	[COST5_Y1] [decimal](19, 2) NOT NULL,
	[COST6_Y1] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Y1] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Y1] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Y1] [decimal](19, 2) NOT NULL,
	[MM_Y2] [decimal](19, 2) NOT NULL,
	[RRISK_Y2] [decimal](19, 4) NOT NULL,
	[COST1_Y2] [decimal](19, 2) NOT NULL,
	[COST2_Y2] [decimal](19, 2) NOT NULL,
	[COST3_Y2] [decimal](19, 2) NOT NULL,
	[COST4_Y2] [decimal](19, 2) NOT NULL,
	[COST5_Y2] [decimal](19, 2) NOT NULL,
	[COST6_Y2] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_Y2] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_Y2] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_Y2] [decimal](19, 2) NOT NULL,
	[MM_T] [decimal](19, 2) NOT NULL,
	[RRISK_T] [decimal](19, 4) NOT NULL,
	[COST1_T] [decimal](19, 2) NOT NULL,
	[COST2_T] [decimal](19, 2) NOT NULL,
	[COST3_T] [decimal](19, 2) NOT NULL,
	[COST4_T] [decimal](19, 2) NOT NULL,
	[COST5_T] [decimal](19, 2) NOT NULL,
	[COST6_T] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_T] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ_T] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ_T] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_EMP_TOS](
	[MEM_ATTR_ID] [int] NOT NULL,
	[TOS_LEVEL] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NULL,
	[TOS2_ID] [smallint] NULL,
	[TOS3_ID] [int] NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[AGE_TOT] [int] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](19, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[COST3_MEDTOT] [decimal](19, 2) NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[LOS_IFAC] [int] NOT NULL,
	[ENCOUNTER_IFAC] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_EMP_SPEC](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[SPEC_LEVEL] [tinyint] NOT NULL,
	[SP1_ID] [smallint] NULL,
	[SP2_ID] [smallint] NULL,
	[SP3_ID] [smallint] NULL,
	[SP4_ID] [int] NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_EMP_RISK](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[RRISK_CAT] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST3_ANC] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL,
	[COST3_PROF] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_EMP_QUAL](
	[MEM_ATTR_ID] [int] NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[EBM_DEN] [int] NOT NULL,
	[EBM_NUM] [int] NOT NULL,
	[EBM_NUMX] [int] NOT NULL,
	[ALL_EBM_NUM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_EMP_PROV](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_EMP_PHM_SUMMARY](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[COST3_GEN] [decimal](19, 2) NOT NULL,
	[COST3_FORM] [decimal](19, 2) NOT NULL,
	[COST3_MAIL] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_GEN] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_FORM] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_MAIL] [decimal](19, 2) NOT NULL,
	[PEER_AMT_REQ_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_LIAB_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_GEN_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_FORM_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_MAIL_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_GEN_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_FORM_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_MAIL_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_EMP_PHM](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[TOS_LEVEL] [tinyint] NOT NULL,
	[TOS2_ID] [smallint] NULL,
	[TOS3_ID] [int] NULL,
	[TOS4_ID] [int] NULL,
	[TOS5_ID] [int] NULL,
	[BRAND_NAME] [varchar](50) NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](19, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[DAYS_SUP] [int] NULL,
	[GENERIC] [int] NOT NULL,
	[SCRIPT_GEN] [int] NULL,
	[SCRIPT] [int] NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[COST3_FORM] [decimal](19, 2) NOT NULL,
	[SCRIPT_FORM] [int] NOT NULL,
	[COST3_MAIL] [decimal](19, 2) NOT NULL,
	[SCRIPT_MAIL] [int] NOT NULL,
	[COST3_GEN] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_EMP_FAC](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[LOS] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_EMP_EPI_FAMILY](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[FAMILY] [smallint] NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST1_ANC] [decimal](19, 2) NOT NULL,
	[COST2_ANC] [decimal](19, 2) NOT NULL,
	[COST3_ANC] [decimal](19, 2) NOT NULL,
	[COST1_IFAC] [decimal](19, 2) NOT NULL,
	[COST2_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[COST1_OFAC] [decimal](19, 2) NOT NULL,
	[COST2_OFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL,
	[COST1_PROF] [decimal](19, 2) NOT NULL,
	[COST2_PROF] [decimal](19, 2) NOT NULL,
	[COST3_PROF] [decimal](19, 2) NOT NULL,
	[COST1_PHM] [decimal](19, 2) NOT NULL,
	[COST2_PHM] [decimal](19, 2) NOT NULL,
	[COST3_PHM] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QL_EMP_CLAIMS_DIST](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[COST3_MEDTOT] [decimal](19, 2) NOT NULL,
	[COST3_ANC] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL,
	[COST3_PROF] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_CONF](
	[CONF_NUM] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[BEG_DT] [smalldatetime] NOT NULL,
	[END_DT] [smalldatetime] NOT NULL,
	[LOS] [smallint] NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[DIAG5] [varchar](8) NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[POA] [char](1) NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[PAY_DT] [smalldatetime] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[POS_I] [tinyint] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[DRG_ID] [varchar](12) NOT NULL,
	[EPISODE_ID] [int] NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[CLM_EXCLUDE] [tinyint] NOT NULL,
	[DRG_DESC] [varchar](150) NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[ACCOUNT_ID] [varchar](40) NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[CAT_STATUS] [tinyint] NULL,
	[CAT_STATUS_COST3] [tinyint] NULL,
	[SEX] [bit] NOT NULL,
	[AGE] [smallint] NULL,
	[ZIP] [char](5) NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[DISREL] [smallint] NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[READMIT_07] [bit] NOT NULL,
	[READMIT_30] [bit] NOT NULL,
	[READMIT_60] [bit] NOT NULL,
	[READMIT_90] [bit] NOT NULL,
	[READMIT_INDEX_07] [bit] NOT NULL,
	[READMIT_INDEX_30] [bit] NOT NULL,
	[READMIT_INDEX_60] [bit] NOT NULL,
	[READMIT_INDEX_90] [bit] NOT NULL,
	[READMIT_CONF_07] [bigint] NULL,
	[READMIT_CONF_30] [bigint] NULL,
	[READMIT_CONF_60] [bigint] NULL,
	[READMIT_CONF_90] [bigint] NULL,
	[ICD_VERSION] [tinyint] NOT NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[DIS_STAT] [varchar](3) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_CM_DISPREV](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[DISEASE_ID] [smallint] NOT NULL,
	[ACT_LAST] [bit] NOT NULL,
	[RRISK_CAT] [tinyint] NOT NULL,
	[PRISK_CAT] [tinyint] NOT NULL,
	[PTL_YR_ENR] [bit] NOT NULL,
	[MEMS] [int] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[WRRISK] [decimal](19, 4) NOT NULL,
	[PRISK] [decimal](19, 4) NOT NULL,
	[ARISK] [decimal](19, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[COST1_ANC] [decimal](19, 2) NOT NULL,
	[COST2_ANC] [decimal](19, 2) NOT NULL,
	[COST3_ANC] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_ANC] [decimal](19, 2) NOT NULL,
	[COST1_IFAC] [decimal](19, 2) NOT NULL,
	[COST2_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_IFAC] [decimal](19, 2) NOT NULL,
	[ADMIT_IFAC] [int] NOT NULL,
	[LOS_IFAC] [int] NOT NULL,
	[COST1_OFAC] [decimal](19, 2) NOT NULL,
	[COST2_OFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_OFAC] [decimal](19, 2) NOT NULL,
	[COST1_PROF] [decimal](19, 2) NOT NULL,
	[COST2_PROF] [decimal](19, 2) NOT NULL,
	[COST3_PROF] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_PROF] [decimal](19, 2) NOT NULL,
	[COST1_PHM] [decimal](19, 2) NOT NULL,
	[COST2_PHM] [decimal](19, 2) NOT NULL,
	[COST3_PHM] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_PHM] [decimal](19, 2) NOT NULL,
	[COST1_ACUTE] [decimal](19, 2) NOT NULL,
	[COST2_ACUTE] [decimal](19, 2) NOT NULL,
	[COST3_ACUTE] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_ACUTE] [decimal](19, 2) NOT NULL,
	[COST1_CHRONIC] [decimal](19, 2) NOT NULL,
	[COST2_CHRONIC] [decimal](19, 2) NOT NULL,
	[COST3_CHRONIC] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_CHRONIC] [decimal](19, 2) NOT NULL,
	[COST1_WELL] [decimal](19, 2) NOT NULL,
	[COST2_WELL] [decimal](19, 2) NOT NULL,
	[COST3_WELL] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_WELL] [decimal](19, 2) NOT NULL,
	[COST3_DISR] [decimal](19, 2) NOT NULL,
	[COST3_ANC_DISR] [decimal](19, 2) NOT NULL,
	[COST3_IFAC_DISR] [decimal](19, 2) NOT NULL,
	[COST3_OFAC_DISR] [decimal](19, 2) NOT NULL,
	[COST3_PROF_DISR] [decimal](19, 2) NOT NULL,
	[COST3_PHM_DISR] [decimal](19, 2) NOT NULL,
	[LOS_IFAC_DISR] [int] NOT NULL,
	[ADMIT_IFAC_DISR] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[QL_CLAIMS](
	[QLC_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[CLAIM_ID] [varchar](30) NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[CONF_NUM] [bigint] NULL,
	[FROM_DT] [smalldatetime] NULL,
	[TO_DT] [smalldatetime] NULL,
	[SVC_QTY] [decimal](19, 2) NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[DIAG5] [varchar](8) NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[PROC_SRV] [varchar](15) NULL,
	[POA] [char](1) NULL,
	[MOD_N] [varchar](4) NULL,
	[PAY_DT] [smalldatetime] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[POS_I] [tinyint] NULL,
	[PRV_SP_4] [int] NOT NULL,
	[EPISODE_ID] [int] NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[CLM_ID_N] [varchar](30) NULL,
	[LINE_NAT] [varchar](10) NULL,
	[CLM_TYPE] [char](1) NOT NULL,
	[CLM_EXCLUDE] [tinyint] NOT NULL,
	[PROC_SRV_DESC] [varchar](150) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[CAT_STATUS] [tinyint] NULL,
	[CAT_STATUS_COST3] [tinyint] NULL,
	[SEX] [bit] NOT NULL,
	[AGE] [smallint] NULL,
	[ZIP] [char](5) NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[MAP_SRCE_N] [varchar](6) NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ICD_VERSION] [tinyint] NULL,
	[ENC_K] [decimal](19, 2) NULL,
	[COST1_K] [decimal](19, 2) NOT NULL,
	[COST2_K] [decimal](19, 2) NOT NULL,
	[COST3_K] [decimal](19, 2) NOT NULL,
	[COST4_K] [decimal](19, 2) NOT NULL,
	[COST5_K] [decimal](19, 2) NOT NULL,
	[COST6_K] [decimal](19, 2) NOT NULL,
	[AMT_REQ_K] [decimal](19, 2) NOT NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[SVC_GRP] [varchar](30) NULL,
	[SVC_QTY_K] [decimal](19, 2) NULL,
	[DAYS_SUP] [int] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PS_RESULTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[SURVEY_ID] [int] NOT NULL,
	[QUEST_ID] [varchar](5) NOT NULL,
	[QUEST_RESP] [int] NOT NULL,
	[QUEST_RESULT] [decimal](19, 2) NOT NULL,
	[QUEST_RESP_PEER] [int] NOT NULL,
	[QUEST_RESULT_PEER] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PS_PATSAT](
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[SURVEY_ID] [int] NOT NULL,
	[QUEST_ID] [varchar](5) NOT NULL,
	[QUEST_RESP] [int] NOT NULL,
	[QUEST_RESULT] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROVINFO](
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[PROVIDER_NAME] [varchar](50) NULL,
	[PCP_INDICATOR] [bit] NULL,
	[MAP_SRCE_P] [varchar](6) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[ZIP_N] [varchar](10) NULL,
	[STATE_N] [char](2) NULL,
	[AFFIL_ID] [varchar](40) NULL,
	[ZIP] [char](5) NOT NULL,
	[ADDRESS] [varchar](100) NULL,
	[PRV_SP_N] [varchar](30) NULL,
	[SEC_PROVIDER_ID] [varchar](20) NULL,
	[PROV_USERDEF_1] [varchar](100) NULL,
	[PROV_USERDEF_2_ID] [varchar](40) NULL,
	[PROV_CITY] [varchar](50) NULL,
	[PROV_PHONE] [varchar](15) NULL,
	[SEC_PROVIDER_ID_2] [varchar](20) NULL,
	[PROV_FIRST_NAME] [varchar](50) NULL,
	[PROV_LAST_NAME] [varchar](50) NULL,
	[PROV_EMAIL] [varchar](50) NULL,
	[PROV_GEO_LAT] [decimal](9, 6) NULL,
	[PROV_GEO_LON] [decimal](9, 6) NULL,
	[CUST_PRV_1] [varchar](255) NULL,
	[CUST_PRV_10] [varchar](255) NULL,
	[CUST_PRV_11] [varchar](255) NULL,
	[CUST_PRV_12] [varchar](255) NULL,
	[CUST_PRV_13] [varchar](255) NULL,
	[CUST_PRV_14] [varchar](255) NULL,
	[CUST_PRV_15] [varchar](255) NULL,
	[CUST_PRV_16] [float] NULL,
	[CUST_PRV_17] [float] NULL,
	[CUST_PRV_18] [float] NULL,
	[CUST_PRV_19] [float] NULL,
	[CUST_PRV_2] [varchar](255) NULL,
	[CUST_PRV_20] [float] NULL,
	[CUST_PRV_3] [varchar](255) NULL,
	[CUST_PRV_4] [varchar](255) NULL,
	[CUST_PRV_5] [varchar](255) NULL,
	[CUST_PRV_6] [varchar](255) NULL,
	[CUST_PRV_7] [varchar](255) NULL,
	[CUST_PRV_8] [varchar](255) NULL,
	[CUST_PRV_9] [varchar](255) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROVIDER_STATUS_SPAN](
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[STATUS_BEGIN] [smalldatetime] NOT NULL,
	[STATUS_END] [smalldatetime] NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NOT NULL,
	[MAP_SRCE_P] [varchar](6) NULL,
	[UPDATE_DATE] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_QUAL_RULE](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[PCP_IMP_FLAG] [bit] NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[EVENT_ID] [int] NOT NULL,
	[RESULT_FLAG] [tinyint] NOT NULL,
	[EBM_NUM] [tinyint] NOT NULL,
	[EBM_DEN] [int] NOT NULL,
	[MEM_CASE_RULE] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_QUAL_EBM](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[RANK_DEC_QUAL] [tinyint] NOT NULL,
	[QUAL_ELIG] [bit] NOT NULL,
	[QUAL_OVR_IND] [decimal](28, 6) NOT NULL,
	[QUAL_EBM_NUM] [int] NOT NULL,
	[QUAL_EBM_DEN] [int] NOT NULL,
	[QUAL_PEER_EBM_NUM] [decimal](28, 6) NOT NULL,
	[EBM_100] [bit] NOT NULL,
	[EBM_200] [bit] NOT NULL,
	[EBM_300] [bit] NOT NULL,
	[EBM_400] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_POP_DET_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PCP_MMOS] [decimal](28, 6) NOT NULL,
	[PCP_MEMBERS] [int] NOT NULL,
	[POP_200] [tinyint] NOT NULL,
	[POP_300] [tinyint] NOT NULL,
	[POP_400] [tinyint] NOT NULL,
	[POP_500] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_PEER_DEF](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_EPI_DET_COUNT_PEG](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PEG_PPC] [smallint] NOT NULL,
	[PEG_EPI_QTY] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_EPI_DET_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[FAMILY] [smallint] NOT NULL,
	[EPI_QTY] [decimal](28, 6) NOT NULL,
	[EPI_FAM_10] [bit] NOT NULL,
	[EPI_FAM_20] [bit] NOT NULL,
	[EPI_FAM_30] [bit] NOT NULL,
	[EPI_FAM_40] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_EPI_COUNT_PEG](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PEG_PPC] [smallint] NOT NULL,
	[PEG_EPI_QTY] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_EPI_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[FAMILY] [smallint] NOT NULL,
	[EPI_QTY] [decimal](28, 6) NOT NULL,
	[EPI_FAM_10] [bit] NOT NULL,
	[EPI_FAM_20] [bit] NOT NULL,
	[EPI_FAM_30] [bit] NOT NULL,
	[EPI_FAM_40] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_EFF_POP](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[RANK_DEC_POP] [tinyint] NOT NULL,
	[RANK_DEC_POP2] [tinyint] NOT NULL,
	[RANK_DEC_POP3] [tinyint] NOT NULL,
	[PCP_ELIG] [tinyint] NOT NULL,
	[PCP_MMOS] [decimal](28, 6) NOT NULL,
	[PCP_MEMBERS] [int] NOT NULL,
	[POP_200] [tinyint] NOT NULL,
	[POP_300] [tinyint] NOT NULL,
	[POP_400] [tinyint] NOT NULL,
	[POP_500] [tinyint] NOT NULL,
	[POP_MORB] [decimal](28, 6) NOT NULL,
	[POP_MORB2] [decimal](28, 6) NOT NULL,
	[POP_MORB3] [decimal](28, 6) NOT NULL,
	[POP_COST_OVR_IND] [decimal](28, 6) NOT NULL,
	[POP_COST2_OVR_IND] [decimal](28, 6) NOT NULL,
	[POP_COST3_OVR_IND] [decimal](28, 6) NOT NULL,
	[POP_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[POP_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[POP_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[POP_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[POP_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[POP_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[POP_ENC_OVR_IND] [decimal](28, 6) NOT NULL,
	[POP_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[POP_ENC_PEER_TOT] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_EFF_EPI_PEG](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PEG_EPI_QTY] [decimal](28, 6) NOT NULL,
	[PEG_ELIG] [bit] NOT NULL,
	[PEG_EPI_CASE_MIX] [decimal](28, 6) NOT NULL,
	[PEG_EPI_CASE_MIX2] [decimal](28, 6) NOT NULL,
	[PEG_EPI_CASE_MIX3] [decimal](28, 6) NOT NULL,
	[PEG_EPI_COST_OVR_IND] [decimal](28, 6) NOT NULL,
	[PEG_EPI_COST2_OVR_IND] [decimal](28, 6) NOT NULL,
	[PEG_EPI_COST3_OVR_IND] [decimal](28, 6) NOT NULL,
	[PEG_EPI_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PEG_EPI_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PEG_EPI_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PEG_EPI_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PEG_EPI_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PEG_EPI_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PEG_EPI_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PEG_EPI_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PEG_EPI_ENC_OVR_IND] [decimal](28, 6) NOT NULL,
	[RANK_DEC_EPI_PEG] [tinyint] NOT NULL,
	[RANK_DEC_EPI2_PEG] [tinyint] NOT NULL,
	[RANK_DEC_EPI3_PEG] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_EFF_EPI](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[EPI_QTY] [decimal](28, 6) NOT NULL,
	[EPI_ELIG] [bit] NOT NULL,
	[EPI_40] [bit] NOT NULL,
	[EPI_50] [bit] NOT NULL,
	[EPI_60] [bit] NOT NULL,
	[EPI_70] [bit] NOT NULL,
	[EPI_CASE_MIX] [decimal](28, 6) NOT NULL,
	[EPI_CASE_MIX2] [decimal](28, 6) NOT NULL,
	[EPI_CASE_MIX3] [decimal](28, 6) NOT NULL,
	[EPI_COST_OVR_IND] [decimal](28, 6) NOT NULL,
	[EPI_COST2_OVR_IND] [decimal](28, 6) NOT NULL,
	[EPI_COST3_OVR_IND] [decimal](28, 6) NOT NULL,
	[EPI_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[EPI_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[EPI_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[EPI_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[EPI_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[EPI_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[EPI_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[EPI_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[EPI_ENC_OVR_IND] [decimal](28, 6) NOT NULL,
	[RANK_DEC_EPI] [tinyint] NOT NULL,
	[RANK_DEC_EPI2] [tinyint] NOT NULL,
	[RANK_DEC_EPI3] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_EFF_ADM](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ADMIT_ELIG] [tinyint] NOT NULL,
	[ADM_100] [tinyint] NOT NULL,
	[ADM_200] [tinyint] NOT NULL,
	[ADM_300] [tinyint] NOT NULL,
	[ADM_400] [tinyint] NOT NULL,
	[ADM_CASE_MIX] [decimal](28, 6) NOT NULL,
	[ADM_CASE_MIX2] [decimal](28, 6) NOT NULL,
	[ADM_CASE_MIX3] [decimal](28, 6) NOT NULL,
	[RANK_DEC_ADM] [tinyint] NOT NULL,
	[RANK_DEC_ADM2] [tinyint] NOT NULL,
	[RANK_DEC_ADM3] [tinyint] NOT NULL,
	[RRISK_ADM_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_07_ACT_TOT] [int] NOT NULL,
	[READMIT_30_ACT_TOT] [int] NOT NULL,
	[READMIT_60_ACT_TOT] [int] NOT NULL,
	[READMIT_90_ACT_TOT] [int] NOT NULL,
	[RRISK_ADM_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_07_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_30_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_60_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_90_PEER_TOT] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PROV_ADM_DET_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ADM_100] [tinyint] NOT NULL,
	[ADM_200] [tinyint] NOT NULL,
	[ADM_300] [tinyint] NOT NULL,
	[ADM_400] [tinyint] NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PREMIUM](
	[SUBSCRIBER_ID] [varchar](32) NOT NULL,
	[BILLED_MTH] [tinyint] NOT NULL,
	[BILLED_YR] [smallint] NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_TREND_QTR](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[QTR_ID] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[COST3_IN_NET] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_TREND_PD](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[SUBSCR_MONTHS] [decimal](19, 2) NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_TREND](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[MALE_MEMS] [decimal](19, 2) NOT NULL,
	[FEMALE_MEMS] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](19, 4) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[AGE] [int] NOT NULL,
	[SUBSCR_MONTHS] [decimal](19, 2) NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NOT NULL,
	[COST3_IN_NET] [decimal](19, 2) NOT NULL,
	[PEER_RRISK_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST1_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST2_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST4_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_IN_NET_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_TOS_TREND_QTR](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[QTR_ID] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_TOS_TREND](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[LOS] [decimal](19, 2) NOT NULL,
	[PEER_COST1_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST2_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST4_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_LIAB_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_DED_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_COIN_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_COP_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_EQV_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_REQ_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_LOS_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_SPEC](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[SP3_ID] [smallint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_RISK](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[RISKCAT_LV2] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_QUAL](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[RULE_TYPE_ID] [tinyint] NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[EBM_NUM] [int] NOT NULL,
	[EBM_DEN] [int] NOT NULL,
	[ALL_EBM_NUM] [decimal](28, 6) NOT NULL,
	[PEER_COMP_RATE] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_PROV](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[LOS] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_PREMIUM_PD](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[SUBSCR_MONTHS] [decimal](19, 2) NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NOT NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NOT NULL,
	[COST3_MED] [decimal](19, 2) NOT NULL,
	[COST3_PHM] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_PHM_SUMMARY](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[SUBSCR_MONTHS] [decimal](19, 2) NOT NULL,
	[SCRIPT] [int] NOT NULL,
	[SCRIPT_GEN] [int] NOT NULL,
	[GENERIC] [int] NOT NULL,
	[SCRIPT_BRAND] [int] NOT NULL,
	[SCRIPT_FORM] [int] NOT NULL,
	[SCRIPT_NON_FORM] [int] NOT NULL,
	[SCRIPT_MAIL] [int] NOT NULL,
	[SCRIPT_RETAIL] [int] NOT NULL,
	[DAYS_SUP] [int] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST3_GEN] [decimal](19, 2) NOT NULL,
	[COST3_BRAND] [decimal](19, 2) NOT NULL,
	[COST3_FORM] [decimal](19, 2) NOT NULL,
	[COST3_NON_FORM] [decimal](19, 2) NOT NULL,
	[COST3_MAIL] [decimal](19, 2) NOT NULL,
	[COST3_RETAIL] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[PEER_DAYS_SUP_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_SCRIPT_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_GEN_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_BRAND_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_GENERIC_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_SCRIPT_BRAND_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_SCRIPT_GEN_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_FORM_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_NON_FORM_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_SCRIPT_FORM_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_SCRIPT_NON_FORM_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_MAIL_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_RETAIL_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_SCRIPT_MAIL_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_SCRIPT_RETAIL_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_LIAB_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_REQ_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_PHM_SCRIPT](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[BRAND_NAME] [varchar](40) NOT NULL,
	[SCRIPT] [int] NOT NULL,
	[DAYS_SUP] [int] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_PHM_FORM](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[FORMULARY] [tinyint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[SCRIPT] [decimal](19, 2) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_SCRIPT_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_PHM](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[SCRIPT] [decimal](19, 2) NOT NULL,
	[SCRIPT_GEN] [decimal](19, 2) NOT NULL,
	[GENERIC] [int] NOT NULL,
	[DAYS_SUP] [int] NOT NULL,
	[SCRIPT_FORM] [decimal](19, 2) NOT NULL,
	[PEER_SCRIPT_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_NETWORK_PD](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[COST3_IN] [decimal](19, 2) NOT NULL,
	[COST3_OUT] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_NETWORK](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[COST3_IN] [decimal](19, 2) NOT NULL,
	[COST3_OUT] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_IN] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_OUT] [decimal](19, 2) NOT NULL,
	[PEER_COST3_IN_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_OUT_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_EXEC_SUMMARY](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MM_Y1] [decimal](38, 2) NULL,
	[MM_Y2] [decimal](38, 2) NULL,
	[SUBSCR_MONTHS_Y1] [decimal](38, 2) NULL,
	[SUBSCR_MONTHS_Y2] [decimal](38, 2) NULL,
	[COST3_Y1] [decimal](38, 2) NULL,
	[COST3_Y2] [decimal](38, 2) NULL,
	[AGE_Y1] [int] NULL,
	[AGE_Y2] [int] NULL,
	[RRISK_Y1] [decimal](38, 4) NULL,
	[RRISK_Y2] [decimal](38, 4) NULL,
	[COST3_IN_NET_Y1] [decimal](38, 2) NULL,
	[COST3_IN_NET_Y2] [decimal](38, 2) NULL,
	[COST3_HC_Y1] [decimal](38, 2) NOT NULL,
	[COST3_HC_Y2] [decimal](38, 2) NOT NULL,
	[MM_HC_Y1] [decimal](38, 2) NOT NULL,
	[MM_HC_Y2] [decimal](38, 2) NOT NULL,
	[SCRIPT_Y1] [int] NOT NULL,
	[SCRIPT_Y2] [int] NOT NULL,
	[GENERIC_Y1] [int] NOT NULL,
	[GENERIC_Y2] [int] NOT NULL,
	[SCRIPT_GEN_Y1] [int] NOT NULL,
	[SCRIPT_GEN_Y2] [int] NOT NULL,
	[SCRIPT_FORM_Y1] [int] NOT NULL,
	[SCRIPT_FORM_Y2] [int] NOT NULL,
	[SCRIPT_MAIL_Y1] [int] NOT NULL,
	[SCRIPT_MAIL_Y2] [int] NOT NULL,
	[AMT_LIAB_Y1] [decimal](38, 2) NOT NULL,
	[AMT_LIAB_Y2] [decimal](38, 2) NOT NULL,
	[AMT_DED_Y1] [decimal](38, 2) NOT NULL,
	[AMT_DED_Y2] [decimal](38, 2) NOT NULL,
	[AMT_COIN_Y1] [decimal](38, 2) NOT NULL,
	[AMT_COIN_Y2] [decimal](38, 2) NOT NULL,
	[AMT_COP_Y1] [decimal](38, 2) NOT NULL,
	[AMT_COP_Y2] [decimal](38, 2) NOT NULL,
	[PEER_RRISK_PMPM_Y1] [decimal](38, 4) NULL,
	[PEER_RRISK_PMPM_Y2] [decimal](38, 4) NULL,
	[PEER_COST3_PMPM_Y1] [decimal](38, 2) NULL,
	[PEER_COST3_PMPM_Y2] [decimal](38, 2) NULL,
	[PEER_COST3_IN_NET_PMPM_Y1] [decimal](38, 2) NULL,
	[PEER_COST3_IN_NET_PMPM_Y2] [decimal](38, 2) NULL,
	[PEER_SCRIPT_PMPM_Y1] [decimal](38, 2) NOT NULL,
	[PEER_SCRIPT_PMPM_Y2] [decimal](38, 2) NOT NULL,
	[PEER_GENERIC_PMPM_Y1] [decimal](38, 2) NOT NULL,
	[PEER_GENERIC_PMPM_Y2] [decimal](38, 2) NOT NULL,
	[PEER_SCRIPT_GEN_PMPM_Y1] [decimal](38, 2) NOT NULL,
	[PEER_SCRIPT_GEN_PMPM_Y2] [decimal](38, 2) NOT NULL,
	[PEER_SCRIPT_FORM_PMPM_Y1] [decimal](38, 2) NOT NULL,
	[PEER_SCRIPT_FORM_PMPM_Y2] [decimal](38, 2) NOT NULL,
	[PEER_SCRIPT_MAIL_PMPM_Y1] [decimal](38, 2) NOT NULL,
	[PEER_SCRIPT_MAIL_PMPM_Y2] [decimal](38, 2) NOT NULL,
	[PEER_AMT_LIAB_PMPM_Y1] [decimal](38, 2) NOT NULL,
	[PEER_AMT_LIAB_PMPM_Y2] [decimal](38, 2) NOT NULL,
	[PEER_AMT_DED_PMPM_Y1] [decimal](38, 2) NOT NULL,
	[PEER_AMT_DED_PMPM_Y2] [decimal](38, 2) NOT NULL,
	[PEER_AMT_COIN_PMPM_Y1] [decimal](38, 2) NOT NULL,
	[PEER_AMT_COIN_PMPM_Y2] [decimal](38, 2) NOT NULL,
	[PEER_AMT_COP_PMPM_Y1] [decimal](38, 2) NOT NULL,
	[PEER_AMT_COP_PMPM_Y2] [decimal](38, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_EPI_FAMILY](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[FAMILY] [smallint] NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL,
	[COST3_PROF] [decimal](19, 2) NOT NULL,
	[COST3_ANC] [decimal](19, 2) NOT NULL,
	[COST3_PHM] [decimal](19, 2) NOT NULL,
	[PEER_COST3] [decimal](19, 2) NOT NULL,
	[PEER_COST3_IFAC] [decimal](19, 2) NOT NULL,
	[PEER_COST3_OFAC] [decimal](19, 2) NOT NULL,
	[PEER_COST3_PROF] [decimal](19, 2) NOT NULL,
	[PEER_COST3_ANC] [decimal](19, 2) NOT NULL,
	[PEER_COST3_PHM] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_DISPREV](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[DISEASE_RELATED_FLAG] [tinyint] NOT NULL,
	[DISEASE_ID] [smallint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[WRRISK] [decimal](19, 4) NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL,
	[COST3_PROF] [decimal](19, 2) NOT NULL,
	[COST3_ANC] [decimal](19, 2) NOT NULL,
	[COST3_PHM] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_DEM](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[MALE_MM] [decimal](19, 2) NOT NULL,
	[FEMALE_MM] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_CONTRACT_TYPE](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[CONTRACT_TYPE_ID] [varchar](40) NOT NULL,
	[QTR_ID] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[SUBSCR_MONTHS] [decimal](19, 2) NOT NULL,
	[SUBSCR_RELATED_MM] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_CLAIMS_LAG](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_CLAIMS_HC](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[MEMBER] [varchar](32) NULL,
	[HIGH_COST_FLAG] [tinyint] NOT NULL,
	[COVERAGE_STATUS_DESC] [varchar](150) NULL,
	[MEM_STATUS] [varchar](6) NULL,
	[COST3_TOT] [decimal](19, 2) NULL,
	[COST3_IFAC] [decimal](19, 2) NULL,
	[ADMIT] [int] NULL,
	[COST3_OFAC] [decimal](19, 2) NULL,
	[ENCOUNTER_OFAC] [decimal](19, 2) NULL,
	[COST3_PROF] [decimal](19, 2) NULL,
	[ENCOUNTER_PROF] [decimal](19, 2) NULL,
	[COST3_PHM] [decimal](19, 2) NULL,
	[SCRIPT] [decimal](19, 2) NULL,
	[COST3_ANC] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_CLAIMS_DIST](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[CAT_STATUS_COST3] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST3_PHM] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PR_EMP_CLAIMS_AGE_PD](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [tinyint] NOT NULL,
	[COVERAGE_CLASS] [tinyint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[POP_PROV](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PCP_IMP_FLAG] [tinyint] NOT NULL,
	[PCP_MMOS] [decimal](28, 6) NOT NULL,
	[PCP_MMOS_RX] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[POP_DET_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[RRISK_CAT] [tinyint] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[PCP_IMP_FLAG] [tinyint] NOT NULL,
	[PCP_MMOS] [decimal](28, 6) NOT NULL,
	[RRISK_W] [decimal](28, 6) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[POP_DET_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[RRISK_CAT] [tinyint] NOT NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[PCP_IMP_FLAG] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NULL,
	[CODE_TYPE] [tinyint] NOT NULL,
	[SERV_CODE] [varchar](20) NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_O_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[POP_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[IA_TIME_ADJ] [int] NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[RRISK_CAT] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[PCP_MMOS] [decimal](28, 6) NOT NULL,
	[RRISK_W] [decimal](28, 6) NOT NULL,
	[SEX] [bit] NOT NULL,
	[PCP_IMP_FLAG] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[POP_COSTS_POPLEVEL](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[RRISK_CAT] [tinyint] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[PCP_IMP_FLAG] [tinyint] NOT NULL,
	[PCP_MMOS] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[REFVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[REF_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ACT_TOT] [decimal](28, 6) NOT NULL,
	[MRI_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_ACT_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_PEER_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[MRI_PEER_TOT] [decimal](28, 6) NOT NULL,
	[REF_PEER_TOT] [decimal](28, 6) NOT NULL,
	[REFVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[GEN_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[POP_PCC_PCT] [decimal](7, 4) NOT NULL,
	[POP_SPEC_PCT] [decimal](7, 4) NOT NULL,
	[POP_ER_PCT] [decimal](7, 4) NOT NULL,
	[POP_PHM_PCT] [decimal](7, 4) NOT NULL,
	[POP_LAB_PCT] [decimal](7, 4) NOT NULL,
	[POP_RAD_PCT] [decimal](7, 4) NOT NULL,
	[POP_HOSP_PCT] [decimal](7, 4) NOT NULL,
	[POP_PCC_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[POP_SPEC_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[POP_ER_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[POP_PHM_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[POP_LAB_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[POP_RAD_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[POP_HOSP_PCT_ADJ] [decimal](7, 4) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[POP_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[IA_TIME_ADJ] [tinyint] NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[RRISK_CAT] [tinyint] NOT NULL,
	[PCP_IMP_FLAG] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[REFVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[REF_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_ACT_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[MRI_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[REFVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[REF_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_PEER_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[MRI_PEER_TOT] [decimal](28, 6) NOT NULL,
	[GEN_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER_TOT] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_SUMMARY](
	[PEG_EPISODE_ID] [int] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[GENDER] [char](1) NOT NULL,
	[AGE] [smallint] NOT NULL,
	[RESP_PROV] [varchar](20) NULL,
	[RESP_PROV_TYPE] [varchar](10) NULL,
	[PEG_PPC] [smallint] NOT NULL,
	[TOT_ALLOW] [decimal](19, 2) NOT NULL,
	[TOT_PAID] [decimal](19, 2) NOT NULL,
	[MGMT_ALLOW] [decimal](19, 2) NOT NULL,
	[MGMT_PAID] [decimal](19, 2) NOT NULL,
	[SURG_ALLOW] [decimal](19, 2) NOT NULL,
	[SURG_PAID] [decimal](19, 2) NOT NULL,
	[FAC_ALLOW] [decimal](19, 2) NOT NULL,
	[FAC_PAID] [decimal](19, 2) NOT NULL,
	[RX_ALLOW] [decimal](19, 2) NOT NULL,
	[RX_PAID] [decimal](19, 2) NOT NULL,
	[INP_ALLOW] [decimal](19, 2) NOT NULL,
	[INP_PAID] [decimal](19, 2) NOT NULL,
	[OUT_ALLOW] [decimal](19, 2) NOT NULL,
	[OUT_PAID] [decimal](19, 2) NOT NULL,
	[OTHER_ALLOW] [decimal](19, 2) NOT NULL,
	[OTHER_PAID] [decimal](19, 2) NOT NULL,
	[PEG_EPI_FROM] [smalldatetime] NOT NULL,
	[PEG_EPI_TO] [smalldatetime] NOT NULL,
	[ANCHOR_PROC_DT] [smalldatetime] NOT NULL,
	[PEG_EPI_COMPLETE] [tinyint] NOT NULL,
	[BEGIN_CLEAN] [tinyint] NOT NULL,
	[END_CLEAN] [tinyint] NOT NULL,
	[COMBINED] [tinyint] NOT NULL,
	[LATERALITY] [char](1) NOT NULL,
	[PEG_SEV_SCORE] [decimal](10, 4) NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[PEG_SEV_ERROR_STAT] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_PHANTOM](
	[CLAIM_ID] [varchar](30) NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[PROCCODE] [varchar](15) NULL,
	[MOD_N] [varchar](4) NULL,
	[REVENUE] [varchar](15) NULL,
	[ICD_VERSION] [tinyint] NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[PROVIDER] [varchar](20) NULL,
	[ETG_TOP] [smallint] NOT NULL,
	[ORDER_PROV] [varchar](20) NULL,
	[ETG_CLUS_PRV] [varchar](20) NULL,
	[ETG_TOS] [smallint] NULL,
	[ETG] [varchar](9) NOT NULL,
	[ETG_EPISODE_ID] [int] NULL,
	[ETG_CLUSTER] [int] NULL,
	[ETG_EPI_TYPE] [tinyint] NOT NULL,
	[ETG_REC_TYPE] [char](1) NULL,
	[ETG_ANC_TYPE] [char](1) NULL,
	[ETG_FROM_DT] [smalldatetime] NOT NULL,
	[ETG_TO_DT] [smalldatetime] NOT NULL,
	[PAY_DT] [smalldatetime] NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[PEG_EPISODE_ID] [int] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_TARGET] [int] NULL,
	[PEG_UNRELATED_ETG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_EPISODES](
	[PEG_EPISODE_ID] [int] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[GENDER] [char](1) NOT NULL,
	[AGE] [smallint] NOT NULL,
	[RESP_PROV] [varchar](20) NULL,
	[RESP_PROV_TYPE] [varchar](10) NULL,
	[PEG_PPC] [smallint] NOT NULL,
	[TOT_ALLOW] [decimal](19, 2) NOT NULL,
	[TOT_PAID] [decimal](19, 2) NOT NULL,
	[MGMT_ALLOW] [decimal](19, 2) NOT NULL,
	[MGMT_PAID] [decimal](19, 2) NOT NULL,
	[SURG_ALLOW] [decimal](19, 2) NOT NULL,
	[SURG_PAID] [decimal](19, 2) NOT NULL,
	[FAC_ALLOW] [decimal](19, 2) NOT NULL,
	[FAC_PAID] [decimal](19, 2) NOT NULL,
	[RX_ALLOW] [decimal](19, 2) NOT NULL,
	[RX_PAID] [decimal](19, 2) NOT NULL,
	[INP_ALLOW] [decimal](19, 2) NOT NULL,
	[INP_PAID] [decimal](19, 2) NOT NULL,
	[OUT_ALLOW] [decimal](19, 2) NOT NULL,
	[OUT_PAID] [decimal](19, 2) NOT NULL,
	[OTHER_ALLOW] [decimal](19, 2) NOT NULL,
	[OTHER_PAID] [decimal](19, 2) NOT NULL,
	[PEG_EPI_FROM] [smalldatetime] NOT NULL,
	[PEG_EPI_TO] [smalldatetime] NOT NULL,
	[ANCHOR_PROC_DT] [smalldatetime] NOT NULL,
	[PEG_EPI_COMPLETE] [tinyint] NOT NULL,
	[BEGIN_CLEAN] [tinyint] NOT NULL,
	[END_CLEAN] [tinyint] NOT NULL,
	[COMBINED] [tinyint] NOT NULL,
	[LATERALITY] [char](1) NOT NULL,
	[PEG_SEV_SCORE] [decimal](10, 4) NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[PEG_SEV_ERROR_STAT] [tinyint] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[PEG_EPI_COST_RATIO_LO] [decimal](19, 2) NOT NULL,
	[PEG_EPI_COST_RATIO_HI] [decimal](19, 2) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[MED_QUAL] [tinyint] NOT NULL,
	[PHM_QUAL] [tinyint] NOT NULL,
	[DISQUALIFIED_FLAG] [bit] NOT NULL,
	[DRG_ID] [varchar](30) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_EPI_PROV](
	[PEER_DEF_ID] [int] NOT NULL,
	[PEG_EPISODE_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[ATTR_REASON_ID] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_EPI_DET_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PEG_UNIT_ID] [smallint] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[LATERALITY] [char](1) NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[COMPLETE] [bit] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[PEG_EPI_QTY_ELIG_PEER] [bit] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[OUTLIER_CLINICAL] [tinyint] NOT NULL,
	[PEG_EPI_QTY] [decimal](28, 6) NOT NULL,
	[RRISK_EPI_W] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_EPI_DET_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PEG_UNIT_ID] [smallint] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[PEG_PSC_CAT1_ID] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[PEG_WINDOW] [tinyint] NOT NULL,
	[LATERALITY] [char](1) NOT NULL,
	[CODE_TYPE] [tinyint] NOT NULL,
	[SERV_CODE] [varchar](15) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[PEG_EPI_QTY_ELIG_PEER] [bit] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[OUTLIER_CLINICAL] [tinyint] NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_E_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_EPI_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PEG_UNIT_ID] [smallint] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[LATERALITY] [char](1) NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[IA_TIME_ADJ] [tinyint] NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[PEG_EPI_QTY] [decimal](28, 6) NOT NULL,
	[RRISK_EPI_W] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_EPI_COSTS_EPILEVEL](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PEG_UNIT_ID] [smallint] NOT NULL,
	[PEG_EPISODE_ID] [int] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[PEG_EPI_QTY] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_INP_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_INP_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[OSPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_ACT_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[MRI_ACT_TOT] [decimal](28, 6) NOT NULL,
	[GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[SCRIPT_GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[OSPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_PEER_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[MRI_PEER_TOT] [decimal](28, 6) NOT NULL,
	[GEN_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[PCC_COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[PCC_COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[PCC_COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPEC_COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RX_COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RX_COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RX_COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST2_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST3_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[PCC_ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RX_ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_INP_ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_ENC_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[PCC_COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[PCC_COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[PCC_COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPEC_COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RX_COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RX_COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RX_COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST2_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST3_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[PCC_ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RX_ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_INP_ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_ENC_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPVIS_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[OSPVIS_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SCRIPT_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[DAYS_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[MRI_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[GEN_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT_PRE] [int] NOT NULL,
	[SCRIPT_GEN_ACT_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SPVIS_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[OSPVIS_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[RAD_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[LAB_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ER_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[MRI_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[GEN_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER_TOT_PRE] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[PCC_COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[PCC_COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[PCC_COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPEC_COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[RX_COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[RX_COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[RX_COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST2_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST3_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[PCC_ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[RX_ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_INP_ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_ENC_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[PCC_COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[PCC_COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[PCC_COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPEC_COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[RX_COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[RX_COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[RX_COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_INP_COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST2_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_COST3_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[PCC_ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[RX_ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_INP_ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_SURG_ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[HOSP_OP_OTHR_ENC_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPVIS_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[OSPVIS_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[SCRIPT_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[DAYS_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[MRI_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[GEN_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT_POST] [int] NOT NULL,
	[SCRIPT_GEN_ACT_TOT_POST] [decimal](28, 6) NOT NULL,
	[SPVIS_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[OSPVIS_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[RAD_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[LAB_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[ER_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[MRI_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[GEN_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER_TOT_POST] [decimal](28, 6) NOT NULL,
	[PEG_EPI_PCC_PCT] [decimal](7, 4) NOT NULL,
	[PEG_EPI_SPEC_PCT] [decimal](7, 4) NOT NULL,
	[PEG_EPI_ER_PCT] [decimal](7, 4) NOT NULL,
	[PEG_EPI_RAD_PCT] [decimal](7, 4) NOT NULL,
	[PEG_EPI_LAB_PCT] [decimal](7, 4) NOT NULL,
	[PEG_EPI_HOSP_INP_PCT] [decimal](7, 4) NOT NULL,
	[PEG_EPI_HOSP_OP_SURG_PCT] [decimal](7, 4) NOT NULL,
	[PEG_EPI_HOSP_OP_OTHR_PCT] [decimal](7, 4) NOT NULL,
	[PEG_EPI_PHM_PCT] [decimal](7, 4) NOT NULL,
	[PEG_EPI_PCC_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[PEG_EPI_SPEC_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[PEG_EPI_ER_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[PEG_EPI_RAD_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[PEG_EPI_LAB_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[PEG_EPI_HOSP_INP_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[PEG_EPI_HOSP_OP_SURG_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[PEG_EPI_HOSP_OP_OTHR_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[PEG_EPI_PHM_PCT_ADJ] [decimal](7, 4) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_EPI_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PEG_UNIT_ID] [smallint] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[IA_TIME_ADJ] [tinyint] NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[PEG_PSC_CAT1_ID] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[PEG_WINDOW] [tinyint] NOT NULL,
	[LATERALITY] [char](1) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[OSPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_ACT_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[MRI_ACT_TOT] [decimal](28, 6) NOT NULL,
	[GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[SCRIPT_GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[OSPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_PEER_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[MRI_PEER_TOT] [decimal](28, 6) NOT NULL,
	[GEN_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER_TOT] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_DETAIL](
	[CLAIM_ID] [varchar](30) NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[PROCCODE] [varchar](15) NULL,
	[MOD_N] [varchar](4) NULL,
	[REVENUE] [varchar](15) NULL,
	[ICD_VERSION] [tinyint] NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[PROVIDER] [varchar](20) NULL,
	[ETG_TOP] [smallint] NOT NULL,
	[ORDER_PROV] [varchar](20) NULL,
	[ETG_CLUS_PRV] [varchar](20) NULL,
	[ETG_TOS] [smallint] NULL,
	[ETG] [varchar](9) NOT NULL,
	[ETG_EPISODE_ID] [int] NULL,
	[ETG_CLUSTER] [int] NULL,
	[ETG_EPI_TYPE] [tinyint] NOT NULL,
	[ETG_REC_TYPE] [char](1) NULL,
	[ETG_ANC_TYPE] [char](1) NULL,
	[ETG_FROM_DT] [smalldatetime] NOT NULL,
	[ETG_TO_DT] [smalldatetime] NOT NULL,
	[PAY_DT] [smalldatetime] NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[PEG_EPISODE_ID] [int] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_ANCHOR_PROC_FLAG] [tinyint] NULL,
	[PEG_TARGET] [int] NULL,
	[PEG_UNRELATED_ETG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEG_CLAIMS_DETAIL](
	[CLAIM_ID] [varchar](30) NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[PROCCODE] [varchar](15) NULL,
	[MOD_N] [varchar](4) NULL,
	[REVENUE] [varchar](15) NULL,
	[ICD_VERSION] [tinyint] NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[PROVIDER] [varchar](20) NULL,
	[ETG_TOP] [smallint] NOT NULL,
	[ORDER_PROV] [varchar](20) NULL,
	[ETG_CLUS_PRV] [varchar](20) NULL,
	[ETG_TOS] [smallint] NULL,
	[ETG] [varchar](9) NOT NULL,
	[ETG_EPISODE_ID] [int] NULL,
	[ETG_CLUSTER] [int] NULL,
	[ETG_EPI_TYPE] [tinyint] NOT NULL,
	[ETG_REC_TYPE] [char](1) NULL,
	[ETG_ANC_TYPE] [char](1) NULL,
	[ETG_FROM_DT] [smalldatetime] NOT NULL,
	[ETG_TO_DT] [smalldatetime] NOT NULL,
	[PAY_DT] [smalldatetime] NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[PEG_EPISODE_ID] [int] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_WINDOW] [tinyint] NOT NULL,
	[PEG_ANCHOR_PROC_FLAG] [tinyint] NULL,
	[PEG_TARGET] [int] NULL,
	[PEG_UNRELATED_ETG] [tinyint] NULL,
	[PHANTOM_CLAIM] [bit] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[PEG_EPI_COST_RATIO_LO] [decimal](19, 2) NOT NULL,
	[PEG_EPI_COST_RATIO_HI] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEER_PS_RESULTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[SURVEY_ID] [int] NOT NULL,
	[QUEST_ID] [varchar](5) NOT NULL,
	[QUEST_RESULT_PEER] [decimal](19, 2) NOT NULL,
	[QUEST_RESP_PEER] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PEER_POP_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[RRISK_CAT] [tinyint] NOT NULL,
	[IA_TIME] [tinyint] NULL,
	[PCP_IMP_FLAG] [tinyint] NOT NULL,
	[PCP_MMOS_PEER] [decimal](28, 6) NOT NULL,
	[PCP_MMOS_RX_PEER] [decimal](28, 6) NOT NULL,
	[POP_QTY_ELIG_PEER] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PEER_POP_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[RRISK_CAT] [tinyint] NOT NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[PCP_IMP_FLAG] [tinyint] NOT NULL,
	[IA_TIME] [tinyint] NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[COST_PEER] [decimal](28, 6) NOT NULL,
	[COST2_PEER] [decimal](28, 6) NOT NULL,
	[COST3_PEER] [decimal](28, 6) NOT NULL,
	[ENC_PEER] [decimal](28, 6) NOT NULL,
	[PCPVIS_PEER] [decimal](28, 6) NOT NULL,
	[REFVIS_PEER] [decimal](28, 6) NOT NULL,
	[REF_PEER] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER] [decimal](28, 6) NOT NULL,
	[RAD_PEER] [decimal](28, 6) NOT NULL,
	[LAB_PEER] [decimal](28, 6) NOT NULL,
	[MRI_PEER] [decimal](28, 6) NOT NULL,
	[ER_PEER] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER] [decimal](28, 6) NOT NULL,
	[DAYS_PEER] [decimal](28, 6) NOT NULL,
	[GEN_PEER] [decimal](28, 6) NOT NULL,
	[POP_QTY_ELIG_PEER] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEER_MEM_EXC](
	[PEER_DEF_ID] [int] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PEER_EPI_COUNT_PEG](
	[PEER_DEF_ID] [int] NOT NULL,
	[PEG_UNIT_ID] [smallint] NOT NULL,
	[IA_TIME] [tinyint] NULL,
	[PEG_EPI_QTY_PEER] [decimal](28, 6) NOT NULL,
	[PEG_EPI_QTY_RX_PEER] [decimal](28, 6) NOT NULL,
	[PEG_EPI_QTY_ELIG_PEER] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PEER_EPI_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NULL,
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[EPI_QTY_PEER] [decimal](28, 6) NOT NULL,
	[EPI_QTY_RX_PEER] [decimal](28, 6) NOT NULL,
	[EPI_QTY_ELIG_PEER] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PEER_EPI_COSTS_PEG](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NULL,
	[PEG_UNIT_ID] [smallint] NOT NULL,
	[PEG_PSC_CAT1_ID] [smallint] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[PEG_WINDOW] [tinyint] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[COST_PEER] [decimal](28, 6) NOT NULL,
	[COST2_PEER] [decimal](28, 6) NOT NULL,
	[COST3_PEER] [decimal](28, 6) NOT NULL,
	[ENC_PEER] [decimal](28, 6) NOT NULL,
	[SPVIS_PEER] [decimal](28, 6) NOT NULL,
	[OSPVIS_PEER] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER] [decimal](28, 6) NOT NULL,
	[RAD_PEER] [decimal](28, 6) NOT NULL,
	[LAB_PEER] [decimal](28, 6) NOT NULL,
	[MRI_PEER] [decimal](28, 6) NOT NULL,
	[ER_PEER] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER] [decimal](28, 6) NOT NULL,
	[DAYS_PEER] [decimal](28, 6) NOT NULL,
	[GEN_PEER] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PEER_EPI_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NULL,
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[SPECPRV] [bit] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[COST_PEER] [decimal](28, 6) NOT NULL,
	[COST2_PEER] [decimal](28, 6) NOT NULL,
	[COST3_PEER] [decimal](28, 6) NOT NULL,
	[ENC_PEER] [decimal](28, 6) NOT NULL,
	[SPVIS_PEER] [decimal](28, 6) NOT NULL,
	[OSPVIS_PEER] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER] [decimal](28, 6) NOT NULL,
	[RAD_PEER] [decimal](28, 6) NOT NULL,
	[LAB_PEER] [decimal](28, 6) NOT NULL,
	[MRI_PEER] [decimal](28, 6) NOT NULL,
	[ER_PEER] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER] [decimal](28, 6) NOT NULL,
	[DAYS_PEER] [decimal](28, 6) NOT NULL,
	[GEN_PEER] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEER_EPI_ANALYTIC](
	[MEMBER] [varchar](32) NOT NULL,
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[EPISODE_ID] [int] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[ETG_UNIT] [varchar](9) NOT NULL,
	[SPECPRV] [bit] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[OUTLIER_E] [tinyint] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[CODE_TYPE] [tinyint] NOT NULL,
	[SERV_CODE] [varchar](15) NULL,
	[ATTR_REASON_ID] [tinyint] NOT NULL,
	[EPI_QTY] [decimal](28, 6) NOT NULL,
	[COST1] [decimal](28, 6) NOT NULL,
	[COST2] [decimal](28, 6) NOT NULL,
	[COST3] [decimal](28, 6) NOT NULL,
	[ENCOUNTER] [decimal](28, 6) NOT NULL,
	[SPVIS] [decimal](28, 6) NOT NULL,
	[OSPVIS] [decimal](28, 6) NOT NULL,
	[SCRIPT] [decimal](28, 6) NOT NULL,
	[RAD_UTIL] [decimal](28, 6) NOT NULL,
	[LAB_UTIL] [decimal](28, 6) NOT NULL,
	[ER_UTIL] [decimal](28, 6) NOT NULL,
	[MRI_UTIL] [decimal](28, 6) NOT NULL,
	[GENERIC] [decimal](28, 6) NOT NULL,
	[SCRIPT_GEN] [decimal](28, 6) NOT NULL,
	[ADMIT] [int] NOT NULL,
	[LOS] [decimal](28, 6) NOT NULL,
	[COST_E] [decimal](28, 6) NOT NULL,
	[OUTLIER_CLINICAL] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PEER_EBM_RATES](
	[PEER_DEF_ID] [int] NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[PEER_RATE] [decimal](28, 6) NOT NULL,
	[PCP_IMP_FLAG] [bit] NOT NULL,
	[QUAL_OPP_ELIG_PEER] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PEER_ADM_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NULL,
	[DRG_UNIT_ID] [varchar](12) NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NOT NULL,
	[RRISK_ADM_PEER] [decimal](28, 6) NOT NULL,
	[COST_ADM_PEER] [decimal](28, 6) NOT NULL,
	[COST2_ADM_PEER] [decimal](28, 6) NOT NULL,
	[COST3_ADM_PEER] [decimal](28, 6) NOT NULL,
	[LOS_ADM_PEER] [decimal](28, 6) NOT NULL,
	[READMIT_07_PEER] [decimal](28, 6) NOT NULL,
	[READMIT_30_PEER] [decimal](28, 6) NOT NULL,
	[READMIT_60_PEER] [decimal](28, 6) NOT NULL,
	[READMIT_90_PEER] [decimal](28, 6) NOT NULL,
	[FAC_QTY_ELIG_PEER] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PAF_COMPLETION_MEMBER](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MEMBER_ID] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_POP_SPEC_PHM_COSTS_CONTRACT](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[TOS_I_5] [int] NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[PROCCODE] [varchar](15) NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[SPEC_RX_N_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[NDC] [varchar](11) NULL,
	[SPEC_DRUG] [tinyint] NULL,
	[USER_SPEC_DRUG] [tinyint] NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[DAW] [tinyint] NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_DISP] [decimal](19, 2) NULL,
	[AMT_INGR] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_SALES_TAX] [decimal](19, 2) NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_DED] [decimal](19, 2) NULL,
	[AMT_COIN] [decimal](19, 2) NULL,
	[AMT_COP] [decimal](19, 2) NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[ENCOUNTER_K] [decimal](19, 2) NULL,
	[AMT_EQV_K] [decimal](19, 2) NULL,
	[AMT_DED_K] [decimal](19, 2) NULL,
	[AMT_COIN_K] [decimal](19, 2) NULL,
	[AMT_COP_K] [decimal](19, 2) NULL,
	[AMT_LIAB_K] [decimal](19, 2) NULL,
	[AMT_CAP_PAY_K] [decimal](19, 2) NULL,
	[AMT_PAY_K] [decimal](19, 2) NULL,
	[AMT_NP_K] [decimal](19, 2) NULL,
	[AMT_COB_K] [decimal](19, 2) NULL,
	[AMT_DISP_K] [decimal](19, 2) NULL,
	[AMT_INGR_K] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED_K] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY_K] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE_K] [decimal](19, 2) NULL,
	[AMT_SALES_TAX_K] [decimal](19, 2) NULL,
	[AMT_REQ_K] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_OTH1_K] [decimal](19, 2) NULL,
	[AMT_OTH2_K] [decimal](19, 2) NULL,
	[AMT_OTH3_K] [decimal](19, 2) NULL,
	[AMT_OTH4_K] [decimal](19, 2) NULL,
	[RX_COUNT_N] [decimal](10, 2) NULL,
	[RX_COUNT_N_K] [decimal](10, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_POP_SPEC_PHM_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[TOS_I_5] [int] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[PROCCODE] [varchar](15) NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[SPEC_RX_N_ID] [varchar](40) NULL,
	[NDC] [varchar](11) NULL,
	[SPEC_DRUG] [tinyint] NULL,
	[USER_SPEC_DRUG] [tinyint] NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[DAW] [tinyint] NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_DISP] [decimal](19, 2) NULL,
	[AMT_INGR] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_SALES_TAX] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_POP_RAD_COSTS_CONTRACT](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[POS_I] [tinyint] NULL,
	[PROCCODE] [varchar](15) NULL,
	[REVENUE] [varchar](15) NULL,
	[TOS_I_5] [int] NULL,
	[ETG_ID] [smallint] NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NOT NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_NP] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_K] [decimal](19, 2) NULL,
	[AMT_REQ_K] [decimal](19, 2) NULL,
	[AMT_EQV_K] [decimal](19, 2) NULL,
	[AMT_DED_K] [decimal](19, 2) NULL,
	[AMT_COIN_K] [decimal](19, 2) NULL,
	[AMT_COP_K] [decimal](19, 2) NULL,
	[AMT_LIAB_K] [decimal](19, 2) NULL,
	[AMT_CAP_PAY_K] [decimal](19, 2) NULL,
	[AMT_PAY_K] [decimal](19, 2) NULL,
	[AMT_NP_K] [decimal](19, 2) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED_K] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY_K] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE_K] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_POP_RAD_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[POS_I] [tinyint] NULL,
	[PROCCODE] [varchar](15) NULL,
	[TOS_I_5] [int] NOT NULL,
	[ETG_ID] [smallint] NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[REVENUE] [varchar](15) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OCU_POP_PHM_COSTS_EGR](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT25K] [bit] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[FORMULARY] [tinyint] NULL,
	[CHANNEL] [int] NULL,
	[GBO] [tinyint] NOT NULL,
	[GENERIC] [int] NULL,
	[ENCOUNTER] [decimal](38, 2) NOT NULL,
	[SCRIPT] [int] NULL,
	[SCRIPT_GEN] [int] NULL,
	[DAYS_SUP] [int] NULL,
	[AMT_REQ] [decimal](38, 2) NOT NULL,
	[AMT_LIAB] [decimal](38, 2) NOT NULL,
	[COST3] [decimal](38, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_POP_PHM_COSTS_CONTRACT](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PRES_PRV_I] [varchar](20) NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[NDC] [varchar](11) NULL,
	[BRAND_NAME] [varchar](50) NOT NULL,
	[FORMULARY] [tinyint] NULL,
	[CHANNEL] [int] NULL,
	[GBO] [tinyint] NOT NULL,
	[TOS_I_5] [int] NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[DAYS_SUP] [int] NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NOT NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_NP] [decimal](19, 2) NOT NULL,
	[SCRIPT] [int] NOT NULL,
	[GENERIC] [int] NOT NULL,
	[SCRIPT_GEN] [int] NOT NULL,
	[ENCOUNTER_K] [decimal](19, 2) NULL,
	[AMT_REQ_K] [decimal](19, 2) NULL,
	[AMT_EQV_K] [decimal](19, 2) NULL,
	[AMT_DED_K] [decimal](19, 2) NULL,
	[AMT_COIN_K] [decimal](19, 2) NULL,
	[AMT_COP_K] [decimal](19, 2) NULL,
	[AMT_LIAB_K] [decimal](19, 2) NULL,
	[AMT_CAP_PAY_K] [decimal](19, 2) NULL,
	[AMT_PAY_K] [decimal](19, 2) NULL,
	[AMT_NP_K] [decimal](19, 2) NULL,
	[SCRIPT_K] [int] NULL,
	[GENERIC_K] [int] NULL,
	[SCRIPT_GEN_K] [int] NULL,
	[DAYS_SUP_K] [int] NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[DAW] [tinyint] NULL,
	[SPEC_RX_N_ID] [varchar](40) NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_DISP] [decimal](19, 2) NULL,
	[AMT_INGR] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_SALES_TAX] [decimal](19, 2) NULL,
	[AMT_COB_K] [decimal](19, 2) NULL,
	[AMT_DISP_K] [decimal](19, 2) NULL,
	[AMT_INGR_K] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED_K] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY_K] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE_K] [decimal](19, 2) NULL,
	[AMT_SALES_TAX_K] [decimal](19, 2) NULL,
	[AMT_WTH] [decimal](19, 2) NULL,
	[AMT_WTH_K] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH1_K] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH2_K] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH3_K] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_OTH4_K] [decimal](19, 2) NULL,
	[RX_COUNT_N] [decimal](10, 2) NULL,
	[RX_COUNT_N_K] [decimal](10, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_POP_PHM_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PRES_PRV_I] [varchar](20) NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[NDC] [varchar](11) NULL,
	[BRAND_NAME] [varchar](50) NOT NULL,
	[FORMULARY] [tinyint] NULL,
	[CHANNEL] [int] NULL,
	[GBO] [tinyint] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[GENERIC] [int] NOT NULL,
	[SCRIPT] [int] NOT NULL,
	[SCRIPT_GEN] [int] NOT NULL,
	[DAYS_SUP] [int] NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[DAW] [tinyint] NULL,
	[SPEC_RX_N_ID] [varchar](40) NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_DISP] [decimal](19, 2) NULL,
	[AMT_INGR] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_SALES_TAX] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OCU_POP_COSTS_EGR_TOS5](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[COST3] [decimal](38, 2) NOT NULL,
	[ENCOUNTER] [decimal](38, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_POP_COSTS_EGR](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[TOS1] [varchar](100) NOT NULL,
	[TOS_CAT_ID] [tinyint] NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT25K] [bit] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[COST3] [decimal](38, 2) NOT NULL,
	[AMT_REQ] [decimal](38, 2) NOT NULL,
	[AMT_EQV] [decimal](38, 2) NOT NULL,
	[AMT_DED] [decimal](38, 2) NOT NULL,
	[AMT_COIN] [decimal](38, 2) NOT NULL,
	[AMT_COP] [decimal](38, 2) NOT NULL,
	[AMT_LIAB] [decimal](38, 2) NOT NULL,
	[ADMIT] [int] NOT NULL,
	[LOS] [int] NOT NULL,
	[ENCOUNTER] [decimal](38, 2) NOT NULL,
	[SCRIPT] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_POP_COSTS_CONTRACT](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[DISREL] [smallint] NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[DRG_ID] [varchar](12) NULL,
	[POS_I] [tinyint] NULL,
	[PRV_SP_4] [int] NOT NULL,
	[TOS_I_5] [int] NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[PROCCODE] [varchar](15) NULL,
	[ENCOUNTER] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NOT NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_NP] [decimal](19, 2) NOT NULL,
	[EM_SVC_FLAG] [int] NOT NULL,
	[RAD_UTIL] [decimal](19, 2) NOT NULL,
	[LAB_UTIL] [decimal](19, 2) NOT NULL,
	[MRI_UTIL] [decimal](19, 2) NOT NULL,
	[ER_UTIL] [decimal](19, 2) NOT NULL,
	[LOS] [decimal](19, 2) NOT NULL,
	[ADMIT] [int] NOT NULL,
	[SCRIPT] [int] NOT NULL,
	[GENERIC] [int] NOT NULL,
	[SCRIPT_GEN] [int] NOT NULL,
	[ENCOUNTER_K] [decimal](19, 2) NULL,
	[AMT_REQ_K] [decimal](19, 2) NULL,
	[AMT_EQV_K] [decimal](19, 2) NULL,
	[AMT_DED_K] [decimal](19, 2) NULL,
	[AMT_COIN_K] [decimal](19, 2) NULL,
	[AMT_COP_K] [decimal](19, 2) NULL,
	[AMT_LIAB_K] [decimal](19, 2) NULL,
	[AMT_CAP_PAY_K] [decimal](19, 2) NULL,
	[AMT_PAY_K] [decimal](19, 2) NULL,
	[AMT_NP_K] [decimal](19, 2) NULL,
	[EM_SVC_FLAG_K] [int] NOT NULL,
	[RAD_UTIL_K] [decimal](19, 2) NOT NULL,
	[LAB_UTIL_K] [decimal](19, 2) NOT NULL,
	[MRI_UTIL_K] [decimal](19, 2) NOT NULL,
	[ER_UTIL_K] [decimal](19, 2) NOT NULL,
	[SCRIPT_K] [int] NULL,
	[GENERIC_K] [int] NULL,
	[SCRIPT_GEN_K] [int] NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED_K] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY_K] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE_K] [decimal](19, 2) NULL,
	[ADMIT_SOURCE] [char](1) NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_COB_K] [decimal](19, 2) NULL,
	[AMT_WTH] [decimal](19, 2) NULL,
	[AMT_WTH_K] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH1_K] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH2_K] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH3_K] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_OTH4_K] [decimal](19, 2) NULL,
	[REVENUE] [varchar](15) NULL,
	[ER_CONF] [bit] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_POP_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[DRG_ID] [varchar](12) NULL,
	[POS_I] [tinyint] NULL,
	[PRV_SP_4] [int] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[EM_SVC_FLAG] [int] NOT NULL,
	[RAD_UTIL] [decimal](19, 2) NOT NULL,
	[LAB_UTIL] [decimal](19, 2) NOT NULL,
	[MRI_UTIL] [decimal](19, 2) NOT NULL,
	[ER_UTIL] [decimal](19, 2) NOT NULL,
	[LOS] [int] NOT NULL,
	[ADMIT] [int] NOT NULL,
	[SCRIPT] [int] NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[PROCCODE] [varchar](15) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_PEG_EPI_RAD_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[LATERALITY] [char](1) NOT NULL,
	[DISQUALIFIED_FLAG] [bit] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[TOS_I_5] [int] NULL,
	[PRV_SP_4] [int] NOT NULL,
	[POS_I] [tinyint] NOT NULL,
	[ETG_ID] [smallint] NULL,
	[ETG_SEV_LEVEL] [tinyint] NULL,
	[PROCCODE] [varchar](15) NULL,
	[REVENUE] [varchar](15) NULL,
	[PEG_WINDOW] [tinyint] NOT NULL,
	[PEG_TARGET] [int] NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NOT NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NOT NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_PEG_EPI_PHM_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[LATERALITY] [char](1) NOT NULL,
	[DISQUALIFIED_FLAG] [bit] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [tinyint] NOT NULL,
	[PRES_PRV_I] [varchar](20) NULL,
	[ETG_ID] [smallint] NULL,
	[ETG_SEV_LEVEL] [tinyint] NULL,
	[NDC] [varchar](11) NULL,
	[TOS_I_5] [int] NULL,
	[FORMULARY] [tinyint] NULL,
	[CHANNEL] [int] NULL,
	[GBO] [tinyint] NOT NULL,
	[PEG_WINDOW] [tinyint] NOT NULL,
	[PEG_TARGET] [int] NULL,
	[SCRIPT] [int] NOT NULL,
	[GENERIC] [int] NOT NULL,
	[SCRIPT_GEN] [int] NOT NULL,
	[DAYS_SUP] [int] NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[LAG_IND] [bit] NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NOT NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NOT NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[AMT_NP] [decimal](19, 2) NOT NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[AMT_COB] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_WTH] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NOT NULL,
	[AMT_OTH1] [decimal](19, 2) NOT NULL,
	[AMT_OTH2] [decimal](19, 2) NOT NULL,
	[AMT_OTH3] [decimal](19, 2) NOT NULL,
	[AMT_OTH4] [decimal](19, 2) NOT NULL,
	[AMT_DISP] [decimal](19, 2) NOT NULL,
	[AMT_INGR] [decimal](19, 2) NOT NULL,
	[AMT_SALES_TAX] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_PEG_EPI_COUNT](
	[MEM_ATTR_ID] [int] NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[LATERALITY] [char](1) NOT NULL,
	[DISQUALIFIED_FLAG] [bit] NOT NULL,
	[COMPLETE] [tinyint] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[PEG_EPI_QTY] [decimal](28, 6) NOT NULL,
	[PEG_SCORE] [decimal](10, 4) NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[RRISK] [decimal](10, 4) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_PEG_EPI_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[LATERALITY] [char](1) NOT NULL,
	[DISQUALIFIED_FLAG] [bit] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [tinyint] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[TOS_I_5] [int] NULL,
	[POS_I] [tinyint] NULL,
	[ETG_ID] [smallint] NULL,
	[ETG_SEV_LEVEL] [tinyint] NULL,
	[PROCCODE] [varchar](15) NULL,
	[PEG_WINDOW] [tinyint] NOT NULL,
	[PEG_TARGET] [int] NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[RAD_UTIL] [decimal](19, 2) NOT NULL,
	[LAB_UTIL] [decimal](19, 2) NOT NULL,
	[MRI_UTIL] [decimal](19, 2) NOT NULL,
	[ER_UTIL] [decimal](19, 2) NOT NULL,
	[EM_SVC_FLAG] [int] NOT NULL,
	[LOS] [int] NOT NULL,
	[ADMIT] [int] NOT NULL,
	[SCRIPT] [decimal](19, 2) NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NOT NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NOT NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[AMT_NP] [decimal](19, 2) NOT NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[AMT_COB] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_WTH] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NOT NULL,
	[AMT_OTH1] [decimal](19, 2) NOT NULL,
	[AMT_OTH2] [decimal](19, 2) NOT NULL,
	[AMT_OTH3] [decimal](19, 2) NOT NULL,
	[AMT_OTH4] [decimal](19, 2) NOT NULL,
	[RESP_PROV] [varchar](20) NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[LAG_IND] [bit] NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[DRG_ID] [varchar](12) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OCU_MEMBER_EGR](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT25K] [bit] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[MM_RX] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_MEMBER_CONTRACT](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[MM_RX] [decimal](19, 2) NOT NULL,
	[SUBSCR_MONTHS] [decimal](19, 2) NOT NULL,
	[AGE_TOT] [int] NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[PRISK] [decimal](10, 4) NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NULL,
	[CONTRACT_ID] [varchar](40) NOT NULL,
	[PRIMARY_PAYER_IND] [bit] NULL,
	[CONTRACT_PRISK] [decimal](10, 4) NULL,
	[CONTRACT_RRISK] [decimal](10, 4) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[MM_DEN] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_MEMBER](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[IATIME_LAG] [tinyint] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[MM_RX] [decimal](19, 2) NOT NULL,
	[SUBSCR_MONTHS] [decimal](19, 2) NOT NULL,
	[AGE_TOT] [int] NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[PRISK] [decimal](10, 4) NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[MM_DEN] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_EPI_RAD_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[PROCCODE] [varchar](15) NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[POS_I] [tinyint] NULL,
	[TOS_I_5] [int] NOT NULL,
	[ETG_ID] [smallint] NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[TX_IND] [tinyint] NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[REVENUE] [varchar](15) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_EPI_PHM_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[ETG_ID] [smallint] NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[PRES_PRV_I] [varchar](20) NULL,
	[NDC] [varchar](11) NULL,
	[FORMULARY] [tinyint] NULL,
	[CHANNEL] [int] NULL,
	[GBO] [tinyint] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[GENERIC] [int] NOT NULL,
	[SCRIPT] [int] NOT NULL,
	[SCRIPT_GEN] [int] NOT NULL,
	[DAYS_SUP] [int] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[TX_IND] [tinyint] NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_COIN] [decimal](19, 2) NULL,
	[AMT_COP] [decimal](19, 2) NULL,
	[AMT_DED] [decimal](19, 2) NULL,
	[AMT_WTH] [decimal](19, 2) NULL,
	[AMT_LIAB] [decimal](19, 2) NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_DISP] [decimal](19, 2) NULL,
	[AMT_INGR] [decimal](19, 2) NULL,
	[AMT_SALES_TAX] [decimal](19, 2) NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OCU_EPI_COUNT_EGR](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[EPI_QTY] [decimal](38, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_EPI_COUNT](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[TX_IND] [tinyint] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OCU_EPI_COSTS_EGR](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[COST3] [decimal](38, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_EPI_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[TX_IND] [tinyint] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[DRG_ID] [varchar](12) NULL,
	[POS_I] [tinyint] NULL,
	[PRV_SP_4] [int] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[EM_SVC_FLAG] [int] NOT NULL,
	[RAD_UTIL] [decimal](19, 2) NOT NULL,
	[LAB_UTIL] [decimal](19, 2) NOT NULL,
	[MRI_UTIL] [decimal](19, 2) NOT NULL,
	[ER_UTIL] [decimal](19, 2) NOT NULL,
	[LOS] [int] NOT NULL,
	[ADMIT] [int] NOT NULL,
	[SCRIPT] [int] NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[PROCCODE] [varchar](15) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_COIN] [decimal](19, 2) NULL,
	[AMT_COP] [decimal](19, 2) NULL,
	[AMT_DED] [decimal](19, 2) NULL,
	[AMT_WTH] [decimal](19, 2) NULL,
	[AMT_LIAB] [decimal](19, 2) NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[ETG_RESP_PROV] [varchar](20) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_CONF_COUNT](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[DRG_ID] [varchar](12) NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[POA] [char](1) NOT NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[ADMIT] [int] NOT NULL,
	[LOS] [int] NOT NULL,
	[READMIT_07] [int] NOT NULL,
	[READMIT_30] [int] NOT NULL,
	[READMIT_60] [int] NOT NULL,
	[READMIT_90] [int] NOT NULL,
	[READMIT_INDEX_07] [int] NOT NULL,
	[READMIT_INDEX_30] [int] NOT NULL,
	[READMIT_INDEX_60] [int] NOT NULL,
	[READMIT_INDEX_90] [int] NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[ADMIT_SOURCE] [char](1) NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OCU_CONF_COSTS](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NOT NULL,
	[MEM_ATTR_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[ETG_ID] [smallint] NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[DRG_ID] [varchar](12) NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[LAG_IND] [bit] NOT NULL,
	[LAG_MONTHS] [int] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[FACIP_FLAG] [tinyint] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[POA] [char](1) NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[AMT_PAY_ADJ] [decimal](19, 2) NOT NULL,
	[AMT_EQV_ADJ] [decimal](19, 2) NOT NULL,
	[DIS_STAT] [varchar](3) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[ADMIT_SOURCE] [char](1) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MPG_QUAL](
	[MPG_DEF_ID] [int] NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[EBM_NUM] [int] NOT NULL,
	[EBM_DEN] [int] NOT NULL,
	[PEER_COMP_RATE] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MPG_POP_TOS](
	[MPG_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_REQ] [decimal](19, 2) NOT NULL,
	[AMT_COIN] [decimal](19, 2) NOT NULL,
	[AMT_COP] [decimal](19, 2) NOT NULL,
	[AMT_DED] [decimal](19, 2) NOT NULL,
	[AMT_LIAB] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[COST3_NET_IN] [decimal](19, 2) NOT NULL,
	[COST3_NET_OUT] [decimal](19, 2) NOT NULL,
	[LOS] [decimal](19, 2) NOT NULL,
	[ADMIT] [int] NOT NULL,
	[PEER_COST1_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST2_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST4_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_EQV_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_PAY_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_REQ_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_COIN_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_COP_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_DED_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_LIAB_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_NET_IN_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_NET_OUT_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_LOS_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ADMIT_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_RX_PMPM] [decimal](28, 6) NULL,
	[PEER_ENCOUNTER_RX_PMPM] [decimal](28, 6) NULL,
	[PEER_AMT_LIAB_RX_PMPM] [decimal](28, 6) NULL,
	[PEER_AMT_REQ_RX_PMPM] [decimal](28, 6) NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MPG_POP_SOURCE](
	[MPG_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[GBO] [tinyint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MPG_POP_GENERIC](
	[MPG_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[GENERIC] [bit] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[SCRIPT_GEN] [decimal](19, 2) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_SCRIPT_GEN_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MPG_POP_FORMULARY](
	[MPG_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[FORMULARY] [tinyint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MPG_POP_DRUG](
	[MPG_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[BRAND_NAME] [varchar](50) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MPG_POP_CHANNEL](
	[MPG_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CHANNEL] [int] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MPG_POP](
	[MPG_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[MM] [decimal](28, 6) NOT NULL,
	[MM_RX] [decimal](28, 6) NOT NULL,
	[RRISK] [decimal](28, 6) NULL,
	[ADMIT] [int] NOT NULL,
	[DAYS_SUP] [int] NOT NULL,
	[AMT_REQ] [decimal](28, 6) NOT NULL,
	[ENCOUNTER] [decimal](28, 6) NOT NULL,
	[COST1] [decimal](28, 6) NOT NULL,
	[COST2] [decimal](28, 6) NOT NULL,
	[COST3] [decimal](28, 6) NOT NULL,
	[COST4] [decimal](28, 6) NOT NULL,
	[PEER_RRISK_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ADMIT_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_DAYS_SUP_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_AMT_REQ_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_ENCOUNTER_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST1_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST2_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST3_PMPM] [decimal](28, 6) NOT NULL,
	[PEER_COST4_PMPM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MPG_MEM_ATTR](
	[MPG_DEF_ID] [int] NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[INDUSTRY] [tinyint] NULL,
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MPG_EPI_TOS](
	[MPG_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[PEER_COST3] [decimal](19, 2) NOT NULL,
	[PEER_ENCOUNTER] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MPG_EPI](
	[MPG_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MODULE_DATE_RANGE](
	[MODULE_ID] [int] NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEMINFO](
	[MEMBER] [varchar](32) NOT NULL,
	[SEX] [bit] NOT NULL,
	[DOB] [datetime] NOT NULL,
	[LAST_NAME] [varchar](50) NULL,
	[FIRST_NAME] [varchar](50) NULL,
	[FULL_NAME] [varchar](100) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEMBER_STATUS](
	[MEMBER_ID] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[STATUS] [int] NULL,
	[PAF_STATUS] [int] NULL,
	[ERROR_MSG] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEM_ENROLL_CONTRACT](
	[MEMBER] [varchar](32) NOT NULL,
	[EFF_DT] [smalldatetime] NOT NULL,
	[END_DT] [smalldatetime] NOT NULL,
	[COVERAGE_STATUS_ID] [varchar](40) NOT NULL,
	[RX] [bit] NULL,
	[MED] [bit] NULL,
	[PCP_ID] [varchar](20) NULL,
	[STATE_N] [char](2) NULL,
	[ZIP_N] [varchar](10) NULL,
	[ZIP] [char](5) NOT NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[SUBSCRIBER_ID] [varchar](32) NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NULL,
	[AT_RISK_STATUS_ID] [varchar](40) NULL,
	[DEN] [bit] NOT NULL,
	[MH] [bit] NOT NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[ADDRESS] [varchar](100) NULL,
	[CITY] [varchar](50) NULL,
	[PHONE] [varchar](15) NULL,
	[EMAIL] [varchar](50) NULL,
	[SEC_MEMBER_ID_1] [varchar](32) NULL,
	[SEC_MEMBER_ID_2] [varchar](32) NULL,
	[EMPLOYEE_TYPE_ID] [varchar](40) NULL,
	[HRA_IND] [bit] NULL,
	[HSA_IND] [bit] NULL,
	[GEO_LAT] [decimal](9, 6) NULL,
	[GEO_LON] [decimal](9, 6) NULL,
	[CUST_MEM_1] [varchar](255) NULL,
	[CUST_MEM_10] [varchar](255) NULL,
	[CUST_MEM_11] [varchar](255) NULL,
	[CUST_MEM_12] [varchar](255) NULL,
	[CUST_MEM_13] [varchar](255) NULL,
	[CUST_MEM_14] [varchar](255) NULL,
	[CUST_MEM_15] [varchar](255) NULL,
	[CUST_MEM_16] [float] NULL,
	[CUST_MEM_17] [float] NULL,
	[CUST_MEM_18] [float] NULL,
	[CUST_MEM_19] [float] NULL,
	[CUST_MEM_2] [varchar](255) NULL,
	[CUST_MEM_20] [float] NULL,
	[CUST_MEM_3] [varchar](255) NULL,
	[CUST_MEM_4] [varchar](255) NULL,
	[CUST_MEM_5] [varchar](255) NULL,
	[CUST_MEM_6] [varchar](255) NULL,
	[CUST_MEM_7] [varchar](255) NULL,
	[CUST_MEM_8] [varchar](255) NULL,
	[CUST_MEM_9] [varchar](255) NULL,
	[CUST_MEM_PK_ID] [varchar](32) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEM_ENROLL](
	[MEMBER] [varchar](32) NOT NULL,
	[EFF_DT] [smalldatetime] NOT NULL,
	[END_DT] [smalldatetime] NOT NULL,
	[COVERAGE_STATUS_ID] [varchar](40) NOT NULL,
	[RX] [bit] NULL,
	[MED] [bit] NULL,
	[PCP_ID] [varchar](20) NULL,
	[STATE_N] [char](2) NULL,
	[ZIP_N] [varchar](10) NULL,
	[ZIP] [char](5) NOT NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[SUBSCRIBER_ID] [varchar](32) NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NULL,
	[AT_RISK_STATUS_ID] [varchar](40) NULL,
	[DUAL_ELIG] [bit] NOT NULL,
	[PRIM_PAYER_ID] [varchar](40) NULL,
	[SEC_PAYER_ID] [varchar](40) NULL,
	[DEN] [bit] NOT NULL,
	[MH] [bit] NOT NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[ADDRESS] [varchar](100) NULL,
	[CITY] [varchar](50) NULL,
	[PHONE] [varchar](15) NULL,
	[EMAIL] [varchar](50) NULL,
	[SEC_MEMBER_ID_1] [varchar](32) NULL,
	[SEC_MEMBER_ID_2] [varchar](32) NULL,
	[EMPLOYEE_TYPE_ID] [varchar](40) NULL,
	[HRA_IND] [bit] NULL,
	[HSA_IND] [bit] NULL,
	[GEO_LAT] [decimal](9, 6) NULL,
	[GEO_LON] [decimal](9, 6) NULL,
	[CUST_MEM_1] [varchar](255) NULL,
	[CUST_MEM_10] [varchar](255) NULL,
	[CUST_MEM_11] [varchar](255) NULL,
	[CUST_MEM_12] [varchar](255) NULL,
	[CUST_MEM_13] [varchar](255) NULL,
	[CUST_MEM_14] [varchar](255) NULL,
	[CUST_MEM_15] [varchar](255) NULL,
	[CUST_MEM_16] [float] NULL,
	[CUST_MEM_17] [float] NULL,
	[CUST_MEM_18] [float] NULL,
	[CUST_MEM_19] [float] NULL,
	[CUST_MEM_2] [varchar](255) NULL,
	[CUST_MEM_20] [float] NULL,
	[CUST_MEM_3] [varchar](255) NULL,
	[CUST_MEM_4] [varchar](255) NULL,
	[CUST_MEM_5] [varchar](255) NULL,
	[CUST_MEM_6] [varchar](255) NULL,
	[CUST_MEM_7] [varchar](255) NULL,
	[CUST_MEM_8] [varchar](255) NULL,
	[CUST_MEM_9] [varchar](255) NULL,
	[CUST_MEM_PK_ID] [varchar](32) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEM_DISPREV](
	[MEMBER] [varchar](32) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[DISEASE_ID] [smallint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEM_AVOIDABLE](
	[IA_TIME] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[COUNTY_ID] [int] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_AFFIL_ID] [varchar](40) NOT NULL,
	[PCP_IMP] [varchar](20) NULL,
	[PCP_IMP_AFFIL_ID] [varchar](40) NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[ACCOUNT_LV1_ID] [varchar](100) NULL,
	[ACCOUNT_LV2_ID] [varchar](100) NULL,
	[PRODUCT_LV1_ID] [varchar](100) NULL,
	[PRODUCT_LV2_ID] [varchar](100) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEM_ATTR_MEMBER_COSTS_EGR](
	[MEMBER] [varchar](32) NOT NULL,
	[MEMBER_ATTR_ID] [int] NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YEAR_MTH_PD] [tinyint] NULL,
	[RRISK_CAT] [tinyint] NULL,
	[CAT_STATUS_COST3] [tinyint] NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST3_ANC] [decimal](19, 2) NOT NULL,
	[COST3_IFAC] [decimal](19, 2) NOT NULL,
	[COST3_OFAC] [decimal](19, 2) NOT NULL,
	[COST3_PROF] [decimal](19, 2) NOT NULL,
	[COST3_PHM] [decimal](19, 2) NOT NULL,
	[ENC] [decimal](19, 2) NOT NULL,
	[ENC_ANC] [decimal](19, 2) NOT NULL,
	[ENC_IFAC] [decimal](19, 2) NOT NULL,
	[ENC_OFAC] [decimal](19, 2) NOT NULL,
	[ENC_PROF] [decimal](19, 2) NOT NULL,
	[ENC_PHM] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEM_ATTR_MEMBER_CONTRACT](
	[MEMBER] [varchar](32) NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEMBER_ATTR_ID] [int] NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[RX] [bit] NOT NULL,
	[MED] [bit] NOT NULL,
	[SEX] [bit] NOT NULL,
	[ZIP] [char](5) NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[AGE] [smallint] NOT NULL,
	[MEM_EFF_DT] [smalldatetime] NOT NULL,
	[MEM_END_DT] [smalldatetime] NOT NULL,
	[SUBSCRIBER_ID] [varchar](32) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL,
	[CONTRACT_ID] [varchar](40) NOT NULL,
	[CAT_STATUS_COST3] [tinyint] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[CONTRACT_TYPE_ID] [varchar](40) NOT NULL,
	[COVERAGE_STATUS_ID] [varchar](40) NOT NULL,
	[COVERAGE_CLASS] [tinyint] NULL,
	[INDUSTRY] [tinyint] NULL,
	[IATIME_LAG] [bit] NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[AT_RISK_STATUS_ID] [varchar](40) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[SUB_EFF_DT] [smalldatetime] NOT NULL,
	[SUB_END_DT] [smalldatetime] NOT NULL,
	[LAST_ENROLL] [bit] NOT NULL,
	[MED_QUAL] [bit] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[MM_RX] [decimal](19, 2) NOT NULL,
	[SUBSCR_MONTHS] [decimal](19, 2) NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NULL,
	[PRISK] [decimal](10, 4) NULL,
	[RRISK] [decimal](10, 4) NULL,
	[PRIMARY_PAYER_IND] [bit] NOT NULL,
	[CONTRACT_PRISK] [decimal](10, 4) NULL,
	[CONTRACT_RRISK] [decimal](10, 4) NULL,
	[CONTRACT_ARISK] [decimal](10, 4) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[EMPLOYEE_TYPE_ID] [varchar](40) NULL,
	[HRA_IND] [bit] NULL,
	[HSA_IND] [bit] NULL,
	[RISK_TYPE_ID] [varchar](40) NULL,
	[DEN] [bit] NOT NULL,
	[MM_DEN] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEM_ATTR_MEMBER](
	[MEMBER] [varchar](32) NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[MEMBER_ATTR_ID] [int] NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[RX] [bit] NOT NULL,
	[MED] [bit] NOT NULL,
	[SEX] [bit] NOT NULL,
	[ZIP] [char](5) NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[AGE] [smallint] NOT NULL,
	[MEM_EFF_DT] [smalldatetime] NOT NULL,
	[MEM_END_DT] [smalldatetime] NOT NULL,
	[SUBSCRIBER_ID] [varchar](32) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[CAT_STATUS_COST3] [tinyint] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[CONTRACT_TYPE_ID] [varchar](40) NOT NULL,
	[COVERAGE_STATUS_ID] [varchar](40) NOT NULL,
	[COVERAGE_CLASS] [tinyint] NULL,
	[INDUSTRY] [tinyint] NULL,
	[IATIME_LAG] [bit] NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[AT_RISK_STATUS_ID] [varchar](40) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[SUB_EFF_DT] [smalldatetime] NOT NULL,
	[SUB_END_DT] [smalldatetime] NOT NULL,
	[LAST_ENROLL] [bit] NOT NULL,
	[MED_QUAL] [bit] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[MM] [decimal](19, 2) NOT NULL,
	[MM_RX] [decimal](19, 2) NOT NULL,
	[SUBSCR_MONTHS] [decimal](19, 2) NOT NULL,
	[PREMIUM_TOT] [decimal](19, 2) NULL,
	[PRISK] [decimal](10, 4) NULL,
	[RRISK] [decimal](10, 4) NULL,
	[PCP_AFFIL_ID] [varchar](40) NULL,
	[EMPLOYEE_TYPE_ID] [varchar](40) NULL,
	[HRA_IND] [bit] NULL,
	[HSA_IND] [bit] NULL,
	[RISK_TYPE_ID] [varchar](40) NULL,
	[DEN] [bit] NOT NULL,
	[MM_DEN] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MEM_ATTR](
	[MEMBER_ATTR_ID] [int] IDENTITY(1,1) NOT NULL,
	[MPG_DEF_ID] [int] NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[RX] [bit] NOT NULL,
	[MED] [bit] NOT NULL,
	[CONTRACT_TYPE_ID] [varchar](40) NOT NULL,
	[COVERAGE_STATUS_ID] [varchar](40) NOT NULL,
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[INDUSTRY] [tinyint] NULL,
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[CAT_STATUS_COST3] [tinyint] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[AT_RISK_STATUS_ID] [varchar](40) NULL,
	[EMPLOYEE_TYPE_ID] [varchar](40) NULL,
	[RISK_TYPE_ID] [varchar](40) NULL,
	[DEN] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_UTIL_SPEC_CAT_CPAONLY](
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_DESC] [varchar](90) NOT NULL,
	[UTIL_SPEC_ID1] [smallint] NOT NULL,
	[UTIL_SPEC1] [varchar](90) NOT NULL,
	[UTIL_SPEC_ID2] [smallint] NOT NULL,
	[UTIL_SPEC2] [varchar](90) NOT NULL,
	[DEF_UTIL_SPEC_CAT] [smallint] NOT NULL,
	[UTIL_SPEC_ID0] [tinyint] NULL,
	[UTIL_SPEC0] [varchar](90) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_UTIL_SPEC_CAT](
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_DESC] [varchar](90) NOT NULL,
	[UTIL_SPEC_ID1] [smallint] NOT NULL,
	[UTIL_SPEC1] [varchar](90) NOT NULL,
	[UTIL_SPEC_ID2] [smallint] NOT NULL,
	[UTIL_SPEC2] [varchar](90) NOT NULL,
	[DEF_UTIL_SPEC_CAT] [smallint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_TX_IND](
	[TX_IND] [tinyint] NOT NULL,
	[TX_IND_FLAG] [tinyint] NOT NULL,
	[TX_IND_DESC] [varchar](20) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_TOS_CAT](
	[TOS_CAT_ID] [tinyint] NOT NULL,
	[TOS_CAT_DESC] [varchar](100) NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_TOS](
	[TOS_I_5] [int] NOT NULL,
	[TOS_I_4] [int] NOT NULL,
	[TOS_I] [varchar](255) NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL,
	[TOS3_ID] [int] NOT NULL,
	[TOS1] [varchar](100) NOT NULL,
	[TOS2] [varchar](100) NOT NULL,
	[TOS3] [varchar](120) NOT NULL,
	[TOS4] [varchar](255) NOT NULL,
	[TOS5] [varchar](255) NOT NULL,
	[TOS_I_SHORT] [varchar](255) NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_TCC](
	[TCC] [char](2) NOT NULL,
	[TCC_DESC] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_SPECIALTY_NDC](
	[NDC] [varchar](11) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_SPECIALTY_HCPCS](
	[HCPCS] [varchar](5) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_SPEC_RX_N](
	[SPEC_RX_N_ID] [varchar](40) NOT NULL,
	[SPEC_RX_N] [varchar](30) NOT NULL,
	[SPEC_RX_N_DESC] [varchar](150) NOT NULL,
	[SPEC_RX_N_LV2_ID] [varchar](100) NULL,
	[SPEC_RX_N_LV2] [varchar](20) NULL,
	[SPEC_RX_N_LV2_DESC] [varchar](150) NULL,
	[SPEC_RX_N_LV1_ID] [varchar](100) NULL,
	[SPEC_RX_N_LV1] [varchar](20) NULL,
	[SPEC_RX_N_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_N] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_SPEC](
	[PRV_SP_4] [int] NOT NULL,
	[PRV_SP_I] [varchar](11) NOT NULL,
	[SP1_ID] [smallint] NOT NULL,
	[SP2_ID] [smallint] NOT NULL,
	[SP3_ID] [smallint] NOT NULL,
	[SP1] [varchar](12) NOT NULL,
	[SP2] [varchar](30) NOT NULL,
	[SP3] [varchar](40) NOT NULL,
	[SP4] [varchar](40) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_SEX](
	[SEX] [bit] NOT NULL,
	[SEX_DESC] [char](1) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_SERVICE_CODE](
	[CODE_TYPE] [int] NOT NULL,
	[SERV_CODE] [varchar](15) NOT NULL,
	[CODE_DESC] [varchar](255) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_RISKCAT](
	[RISK_CAT] [tinyint] NOT NULL,
	[RISK_CAT_DESC] [varchar](20) NOT NULL,
	[RISKCAT_LV2] [tinyint] NOT NULL,
	[RISKCAT_LV2_DESC] [varchar](20) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_RISK_TYPE](
	[MAP_SRCE_E] [varchar](6) NULL,
	[RISK_TYPE_ID] [varchar](40) NOT NULL,
	[RISK_TYPE] [varchar](30) NOT NULL,
	[RISK_TYPE_DESC] [varchar](150) NOT NULL,
	[RISK_TYPE_LV1_ID] [varchar](100) NULL,
	[RISK_TYPE_LV1] [varchar](30) NULL,
	[RISK_TYPE_LV1_DESC] [varchar](150) NULL,
	[RISK_TYPE_LV2_ID] [varchar](100) NULL,
	[RISK_TYPE_LV2] [varchar](30) NULL,
	[RISK_TYPE_LV2_DESC] [varchar](150) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_RISK_ADJ](
	[RISK_ADJ_ID] [tinyint] NOT NULL,
	[RISK_ADJ_DESC] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_REVENUE](
	[REVENUE] [varchar](15) NOT NULL,
	[REVENUE_DESC] [varchar](190) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_REGION](
	[ZIP] [char](5) NOT NULL,
	[COUNTY_DESC] [varchar](40) NOT NULL,
	[STATE] [tinyint] NOT NULL,
	[STATE_DESC] [char](2) NOT NULL,
	[CENS_REG] [tinyint] NOT NULL,
	[CENS_REG_DESC] [varchar](30) NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[MSA] [varchar](35) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_RANK_DEC](
	[RANK_DEC] [tinyint] NOT NULL,
	[DEC_DESC] [varchar](20) NOT NULL,
	[QUINT_DESC] [varchar](25) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_QL_PROV_RATE_TYPE](
	[RATE_TYPE_ID] [tinyint] NOT NULL,
	[RATE_TYPE_DESC] [varchar](30) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PSC](
	[PSC_CAT] [int] NOT NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[PSC_CAT2_ID] [smallint] NOT NULL,
	[PSC_CAT1] [varchar](100) NOT NULL,
	[PSC_CAT2] [varchar](100) NOT NULL,
	[PEG_PSC_CAT1_ID] [smallint] NOT NULL,
	[PEG_PSC_CAT2_ID] [smallint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PS_SURVEY](
	[SURVEY_ID] [smallint] NOT NULL,
	[SURVEY_DESC] [varchar](120) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PS_QUESTION](
	[QUEST_ID] [varchar](5) NOT NULL,
	[SURVEY_ID] [int] NOT NULL,
	[QUEST_DESC] [varchar](1000) NOT NULL,
	[QUEST_MAX] [float] NULL,
	[QUEST_TYPE] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PS_QUEST_TYPE](
	[QUEST_TYPE] [tinyint] NOT NULL,
	[QUEST_TYPE_DESC] [varchar](30) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PROVIDER_STATUS](
	[PROVIDER_STATUS_ID] [varchar](40) NOT NULL,
	[PROVIDER_STATUS] [varchar](30) NOT NULL,
	[PROVIDER_STATUS_DESC] [varchar](150) NULL,
	[PROVIDER_STATUS_LV2_ID] [varchar](100) NULL,
	[PROVIDER_STATUS_LV2] [varchar](30) NULL,
	[PROVIDER_STATUS_LV2_DESC] [varchar](150) NULL,
	[PROVIDER_STATUS_LV1_ID] [varchar](100) NULL,
	[PROVIDER_STATUS_LV1] [varchar](30) NULL,
	[PROVIDER_STATUS_LV1_DESC] [varchar](150) NULL,
	[PAR_STATUS] [bit] NOT NULL,
	[MAP_SRCE_P] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PROV_USERDEF_2](
	[PROV_USERDEF_2_ID] [varchar](40) NOT NULL,
	[PROV_USERDEF_2] [varchar](30) NOT NULL,
	[PROV_USERDEF_2_DESC] [varchar](150) NOT NULL,
	[MAP_SRCE_P] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PROV_AFFIL](
	[AFFIL_ID] [varchar](40) NOT NULL,
	[MAP_SRCE_P] [varchar](6) NULL,
	[PROV_AFFIL] [varchar](30) NOT NULL,
	[PROV_AFFIL_DESC] [varchar](150) NULL,
	[PROV_AFFIL_LV2_ID] [varchar](100) NULL,
	[PROV_AFFIL_LV2] [varchar](30) NULL,
	[PROV_AFFIL_LV2_DESC] [varchar](150) NULL,
	[PROV_AFFIL_LV1_ID] [varchar](100) NULL,
	[PROV_AFFIL_LV1] [varchar](30) NULL,
	[PROV_AFFIL_LV1_DESC] [varchar](150) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PRODUCT](
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[PRODUCT] [varchar](30) NOT NULL,
	[PRODUCT_DESC] [varchar](150) NULL,
	[PRODUCT_LV2_ID] [varchar](100) NULL,
	[PRODUCT_LV2] [varchar](30) NULL,
	[PRODUCT_LV2_DESC] [varchar](150) NULL,
	[PRODUCT_LV1_ID] [varchar](100) NULL,
	[PRODUCT_LV1] [varchar](30) NULL,
	[PRODUCT_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL,
	[PRODUCT_NUM_ID] [int] IDENTITY(1,1) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PROCCODE](
	[PROCCODE] [varchar](15) NOT NULL,
	[PROCCODE_DESC] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PROC_FMT](
	[ICDPROC] [varchar](7) NOT NULL,
	[FMT] [varchar](10) NOT NULL,
	[ICD_VERSION] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PQI](
	[PQI] [tinyint] NOT NULL,
	[PQI_DESC] [varchar](100) NOT NULL,
	[PQI_HIER] [tinyint] NULL,
	[AVOIDABLE] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_POS](
	[POS_I] [tinyint] NOT NULL,
	[POS_DESC] [varchar](150) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_POP_MORB_CAT](
	[INTERVAL] [decimal](19, 2) NOT NULL,
	[LOW] [decimal](19, 2) NOT NULL,
	[HIGH] [decimal](19, 2) NULL,
	[DISTRIB_LABEL] [varchar](12) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_POP_CAT_MEM](
	[POP_CAT_MEM] [tinyint] NOT NULL,
	[POP_CAT_MEM_DESC] [varchar](75) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_POA](
	[POA] [char](1) NOT NULL,
	[POA_DESC] [varchar](25) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEG_UNIT](
	[PEG_UNIT_ID] [smallint] NOT NULL,
	[PEG_UNIT] [varchar](8) NOT NULL,
	[PEG_UNIT_DESC] [varchar](100) NOT NULL,
	[PEG_PPC] [smallint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEG_TARGET](
	[PEG_TARGET] [int] NOT NULL,
	[PEG_TARGET_DESC] [varchar](150) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEG_SEV](
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_SEV_LEVEL] [tinyint] NULL,
	[PEG_SEV_DESC] [varchar](175) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEG_PSC](
	[PEG_PSC_CAT1_ID] [smallint] NOT NULL,
	[PEG_PSC_CAT2_ID] [smallint] NOT NULL,
	[PEG_PSC_CAT1] [varchar](100) NULL,
	[PEG_PSC_CAT2] [varchar](100) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEG_PPC](
	[PEG_PPC] [tinyint] NOT NULL,
	[PEG_PPC_DESC] [varchar](150) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEG_LATERALITY](
	[LATERALITY] [char](1) NOT NULL,
	[LATERALITY_DESC] [varchar](100) NOT NULL,
	[PEG_UNIT_LATERALITY] [char](1) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEG](
	[PEG_CAT_ID] [int] NOT NULL,
	[PEG_CAT_DESC] [varchar](150) NOT NULL,
	[PEG_PPC] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEER_CODETYPE](
	[CODETYPE_ID] [tinyint] NOT NULL,
	[CODETYPE] [varchar](50) NULL,
	[CODETYPE_DESC] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEER_CODE](
	[PEER_DEF_ID] [int] NOT NULL,
	[CODETYPE_ID] [int] NULL,
	[CODE] [int] NULL,
	[CODE_STR] [varchar](100) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEER_CAT2](
	[PEER_CAT2_ID] [tinyint] NOT NULL,
	[PEER_CAT2_DESC] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEER_CAT1](
	[PEER_CAT1_ID] [tinyint] NOT NULL,
	[PEER_CAT1_DESC] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PEER](
	[PEER_DEF_ID] [int] NOT NULL,
	[PEER_DEF_DESC] [varchar](50) NOT NULL,
	[RISK_ADJ_ID] [tinyint] NULL,
	[EPI_ATTR_ID] [tinyint] NULL,
	[PCP_ATTR_ID] [tinyint] NULL,
	[EBM_ATTR_ID] [tinyint] NULL,
	[RESP_SPEC_PCT] [decimal](6, 3) NULL,
	[RESP_PCT] [decimal](6, 3) NULL,
	[ELIG_MMOS] [int] NOT NULL,
	[ELIG_MEMS] [int] NOT NULL,
	[EPI_PCC_PCT] [decimal](6, 3) NULL,
	[EPI_SPEC_PCT] [decimal](6, 3) NULL,
	[EPI_HOSP_PCT] [decimal](6, 3) NULL,
	[EPI_PHM_PCT] [decimal](6, 3) NULL,
	[EPI_LAB_PCT] [decimal](6, 3) NULL,
	[EPI_RAD_PCT] [decimal](6, 3) NULL,
	[EPI_ER_PCT] [decimal](6, 3) NULL,
	[POP_PCC_PCT] [decimal](6, 3) NULL,
	[POP_SPEC_PCT] [decimal](6, 3) NULL,
	[POP_HOSP_PCT] [decimal](6, 3) NULL,
	[POP_PHM_PCT] [decimal](6, 3) NULL,
	[POP_LAB_PCT] [decimal](6, 3) NULL,
	[POP_RAD_PCT] [decimal](6, 3) NULL,
	[POP_ER_PCT] [decimal](6, 3) NULL,
	[PEER_CAT1_ID] [tinyint] NOT NULL,
	[PEER_CAT2_ID] [tinyint] NOT NULL,
	[ACTIVE] [tinyint] NOT NULL,
	[ELIG_EPI_QTY] [int] NOT NULL,
	[EBM_ATTR_PREV_ID] [tinyint] NULL,
	[ELIG_DENS] [int] NULL,
	[CUST_PEER_PROV] [tinyint] NULL,
	[FAC_RISK_ADJ_ID] [tinyint] NOT NULL,
	[ELIG_ADMITS] [int] NULL,
	[PAT_SAT] [tinyint] NOT NULL,
	[RESP_EBM_SPEC_PCT] [decimal](6, 3) NULL,
	[RESP_EBM_ALL_PCT] [decimal](6, 3) NULL,
	[PEER_EPI_OUT_LO] [tinyint] NULL,
	[PEER_EPI_OUT_HI] [tinyint] NULL,
	[ATTRIB_LVL_ID] [tinyint] NOT NULL,
	[MEM_EXC_IND] [tinyint] NOT NULL,
	[CUST_PEER_MEM] [tinyint] NOT NULL,
	[NUM_YEARS_EPI] [tinyint] NULL,
	[NUM_YEARS_POP] [tinyint] NULL,
	[NUM_YEARS_FAC] [tinyint] NULL,
	[EPI_ELIG_PEER] [int] NULL,
	[FAC_ELIG_PEER] [int] NULL,
	[QUAL_ELIG_PEER] [int] NULL,
	[PCP_ELIG_PEER] [int] NULL,
	[RISK_ADJ_EPI_IA_TIME] [bit] NULL,
	[RISK_ADJ_POP_IA_TIME] [bit] NULL,
	[RISK_ADJ_FAC_IA_TIME] [bit] NULL,
	[EPI_PROD_LV] [bit] NULL,
	[POP_PROD_LV] [bit] NULL,
	[POP_CAT_MEM] [tinyint] NULL,
	[CI_EPI] [decimal](6, 3) NULL,
	[CI_POP] [decimal](6, 3) NULL,
	[CI_QUAL] [decimal](6, 3) NULL,
	[EPI_CLIN_OUT] [tinyint] NULL,
	[EPI_CLUST_MIN_THRESH] [int] NULL,
	[EPI_COV_MIN_THRESH] [decimal](6, 3) NULL,
	[EPI_COV_MAX_THRESH] [decimal](6, 3) NULL,
	[EPI_MIN_EPI_THRESH] [int] NULL,
	[EPI_MIN_EPI_PCT_THRESH] [decimal](6, 3) NULL,
	[EPI_MEDIAN_COST_MIN_THRESH] [decimal](19, 2) NULL,
	[EPI_MEDIAN_COST_MAX_THRESH] [decimal](19, 2) NULL,
	[EPI_MAX_ETG] [int] NULL,
	[EPI_MIN_PCT_TOT_COST] [decimal](6, 3) NULL,
	[PEG_EPI_PCC_PCT] [decimal](6, 3) NULL,
	[PEG_EPI_SPEC_PCT] [decimal](6, 3) NULL,
	[PEG_EPI_HOSP_INP_PCT] [decimal](6, 3) NULL,
	[PEG_EPI_HOSP_OP_SURG_PCT] [decimal](6, 3) NULL,
	[PEG_EPI_HOSP_OP_OTHR_PCT] [decimal](6, 3) NULL,
	[PEG_EPI_PHM_PCT] [decimal](6, 3) NULL,
	[PEG_EPI_LAB_PCT] [decimal](6, 3) NULL,
	[PEG_EPI_RAD_PCT] [decimal](6, 3) NULL,
	[PEG_EPI_ER_PCT] [decimal](6, 3) NULL,
	[ELIG_EPI_QTY_PEG] [int] NOT NULL,
	[PEER_EPI_OUT_LO_PEG] [tinyint] NULL,
	[PEER_EPI_OUT_HI_PEG] [tinyint] NULL,
	[NUM_YEARS_EPI_PEG] [tinyint] NULL,
	[PEG_EPI_ELIG_PEER] [int] NULL,
	[RISK_ADJ_PEG_EPI_IA_TIME] [bit] NULL,
	[PEG_EPI_PROD_LV] [bit] NULL,
	[CI_EPI_PEG] [decimal](6, 3) NULL,
	[PEG_EPI_CLIN_OUT] [tinyint] NULL,
	[PEG_RISK_ADJ_ID] [tinyint] NULL,
	[PEG_EPI_COV_MIN_THRESH] [decimal](6, 3) NULL,
	[PEG_EPI_COV_MAX_THRESH] [decimal](6, 3) NULL,
	[PEG_EPI_MIN_EPI_THRESH] [int] NULL,
	[PEG_EPI_MIN_EPI_PCT_THRESH] [decimal](6, 3) NULL,
	[PEG_EPI_MEDIAN_COST_MIN_THRESH] [decimal](19, 2) NULL,
	[PEG_EPI_MEDIAN_COST_MAX_THRESH] [decimal](19, 2) NULL,
	[EPI_MAX_PEG] [int] NULL,
	[PEG_EPI_MIN_PCT_TOT_COST] [decimal](6, 3) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PCP_ATTR](
	[PCP_ATTR_ID] [tinyint] NOT NULL,
	[PCP_ATTR_DESC] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_PCC](
	[PCC_DESC] [varchar](120) NOT NULL,
	[PCC] [char](3) NOT NULL,
	[TCC] [char](2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_NETWORK_PAID_STATUS](
	[NETWORK_PAID_STATUS_ID] [varchar](40) NOT NULL,
	[NETWORK_PAID_STATUS] [varchar](30) NOT NULL,
	[NETWORK_PAID_STATUS_DESC] [varchar](150) NULL,
	[NETWORK_PAID_STATUS_LV2_ID] [varchar](40) NULL,
	[NETWORK_PAID_STATUS_LV2] [varchar](30) NULL,
	[NETWORK_PAID_STATUS_LV2_DESC] [varchar](150) NULL,
	[NETWORK_PAID_STATUS_LV1_ID] [varchar](40) NULL,
	[NETWORK_PAID_STATUS_LV1] [varchar](30) NULL,
	[NETWORK_PAID_STATUS_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_P] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL,
	[NETWORK_STATUS] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_NDC](
	[NDC] [varchar](11) NOT NULL,
	[NDC_DESC] [varchar](50) NOT NULL,
	[BRAND_NAME] [varchar](50) NOT NULL,
	[BRAND_NAME_MASK] [varchar](50) NULL,
	[DCC] [char](5) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_MPG_DEF](
	[MPG_DEF_ID] [int] NOT NULL,
	[MPG_DEF_DESC] [varchar](60) NOT NULL,
	[PARENT_MPG_DEF_ID] [int] NULL,
	[MPG_SEG_LVL] [int] NOT NULL,
	[MPG_OTHER_FLAG] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_MPG_CODETYPE](
	[MPG_CODETYPE_ID] [int] NOT NULL,
	[MPG_CODETYPE] [varchar](50) NOT NULL,
	[MPG_CODETYPE_DESC] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_MPG_CODE](
	[MPG_DEF_ID] [int] NOT NULL,
	[MPG_CODETYPE_ID] [int] NOT NULL,
	[MPG_CODE] [int] NULL,
	[MPG_CODE_STR] [varchar](100) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_MPC](
	[MPC] [smallint] NOT NULL,
	[MPC_DESC] [varchar](50) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_MEM_USERDEF_4](
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4] [varchar](30) NOT NULL,
	[MEM_USERDEF_4_DESC] [varchar](150) NOT NULL,
	[MEM_USERDEF_4_LV2_ID] [varchar](100) NULL,
	[MEM_USERDEF_4_LV2] [varchar](30) NULL,
	[MEM_USERDEF_4_LV2_DESC] [varchar](150) NULL,
	[MEM_USERDEF_4_LV1_ID] [varchar](100) NULL,
	[MEM_USERDEF_4_LV1] [varchar](30) NULL,
	[MEM_USERDEF_4_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_MEM_USERDEF_3](
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3] [varchar](30) NOT NULL,
	[MEM_USERDEF_3_DESC] [varchar](150) NOT NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_MEM_USERDEF_2](
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2] [varchar](30) NOT NULL,
	[MEM_USERDEF_2_DESC] [varchar](150) NOT NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_MEM_USERDEF_1](
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1] [varchar](30) NOT NULL,
	[MEM_USERDEF_1_DESC] [varchar](150) NOT NULL,
	[MEM_USERDEF_1_LV2_ID] [varchar](100) NULL,
	[MEM_USERDEF_1_LV2] [varchar](30) NULL,
	[MEM_USERDEF_1_LV2_DESC] [varchar](150) NULL,
	[MEM_USERDEF_1_LV1_ID] [varchar](100) NULL,
	[MEM_USERDEF_1_LV1] [varchar](30) NULL,
	[MEM_USERDEF_1_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_MDC](
	[MDC] [smallint] NOT NULL,
	[MDC_DESC] [varchar](150) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_INDUSTRY](
	[INDUSTRY] [tinyint] NOT NULL,
	[INDUSTRY_DESC] [varchar](50) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ICDPROC](
	[ICDPROC] [varchar](7) NOT NULL,
	[ICDPROC_DESC] [varchar](150) NOT NULL,
	[ICD_VERSION] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ICDDX](
	[ICDDX] [varchar](7) NOT NULL,
	[ICDDX_DESC] [varchar](150) NOT NULL,
	[ICD_VERSION] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_GBO](
	[GBO] [tinyint] NOT NULL,
	[GBO_DESC] [varchar](50) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_FORMULARY](
	[FORMULARY] [tinyint] NOT NULL,
	[FORMULARY_DESC] [varchar](25) NOT NULL,
	[FORMULARY_IND] [bit] NOT NULL,
	[TIER_ORDER] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_FAC_RISK_ADJ](
	[FAC_RISK_ADJ_ID] [tinyint] NOT NULL,
	[FAC_RISK_ADJ_DESC] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_FAC_ATTR_ETG_BASE](
	[ETG_ID] [smallint] NOT NULL,
	[ETG_IMPACT] [varchar](8) NOT NULL,
	[BASE_ETG] [varchar](6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG_UNIT](
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[ETG_UNIT] [varchar](9) NOT NULL,
	[ETG_UNIT_DESC] [varchar](75) NOT NULL,
	[FAMILY] [smallint] NULL,
	[MPC] [smallint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG_TX](
	[TX_CODE] [int] NOT NULL,
	[TX_DESC] [varchar](150) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG_SEV](
	[ETG_SEV_ID] [int] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[ETG_SEV_DESC] [varchar](150) NOT NULL,
	[SEV_LEVEL] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG_PRIM_COND](
	[PRIM_COND_CODE] [smallint] NOT NULL,
	[PRIM_COND_DESC] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG_IMPACT](
	[ETG] [varchar](9) NOT NULL,
	[ETG_IMPACT] [varchar](8) NOT NULL,
	[ETG_DESC] [varchar](150) NOT NULL,
	[ETG_SHORT] [varchar](60) NULL,
	[BASE] [varchar](6) NULL,
	[PRIM_COND_CODE] [smallint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG_FAMILY](
	[FAMILY] [smallint] NOT NULL,
	[FAMILY_DESC] [varchar](80) NOT NULL,
	[FAMILY_DESC_MASK] [varchar](80) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG_COND](
	[COND_STATUS] [int] NOT NULL,
	[COND_DESC] [varchar](150) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG_COMORB](
	[COMORB_CODE] [int] NOT NULL,
	[COMORB_DESC] [varchar](150) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG_BASE](
	[BASE] [varchar](6) NOT NULL,
	[BASE_DESC_LONG] [varchar](100) NOT NULL,
	[BASE_DESC] [varchar](50) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ETG](
	[ETG_ID] [smallint] NOT NULL,
	[ETG_IMPACT] [varchar](8) NOT NULL,
	[ETG_IMPACT_DESC] [varchar](150) NOT NULL,
	[FAMILY] [smallint] NOT NULL,
	[MPC] [smallint] NOT NULL,
	[CHRONIC] [tinyint] NOT NULL,
	[TX_IND] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_EPI_TYPE](
	[EPI_TYPE] [tinyint] NOT NULL,
	[EPI_TYPE_DESC] [varchar](40) NOT NULL,
	[COMPLETE] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_EPI_ATTR](
	[EPI_ATTR_ID] [tinyint] NOT NULL,
	[EPI_ATTR_DESC] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_EMPLOYEE_TYPE](
	[EMPLOYEE_TYPE_ID] [varchar](40) NOT NULL,
	[EMPLOYEE_TYPE] [varchar](30) NOT NULL,
	[EMPLOYEE_TYPE_DESC] [varchar](150) NOT NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL,
	[EMPLOYEE_STATUS] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ED_UNAVOID_ED](
	[UNAVOID_ED] [tinyint] NOT NULL,
	[UNAVOID_ED_DESC] [varchar](30) NOT NULL,
	[PRIORITY] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ED_AMB_SENS](
	[AMB_SENS] [tinyint] NOT NULL,
	[AMB_SENS_DESC] [varchar](30) NOT NULL,
	[PRIORITY] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_EBM_SVC](
	[SVC_ID] [varchar](25) NOT NULL,
	[SVC_DESC] [varchar](212) NOT NULL,
	[SVC_CASE_ID] [int] NOT NULL,
	[SVC_RULE_ID] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_EBM_RULES](
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[RULE_TYPE_ID] [tinyint] NOT NULL,
	[RULE_DESC] [varchar](212) NOT NULL,
	[NQF_ENDORSED] [bit] NOT NULL,
	[NQF_SIMILAR] [bit] NOT NULL,
	[AUTHOR] [varchar](25) NULL,
	[RX_REQ] [bit] NOT NULL,
	[LABDATA_REQ] [bit] NOT NULL,
	[LABRESULTS_REQ] [bit] NOT NULL,
	[ENABLED] [bit] NOT NULL,
	[EXT_FLAG] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_EBM_RULE_TYPES](
	[RULE_TYPE_ID] [tinyint] NOT NULL,
	[RULE_TYPE_1_ID] [tinyint] NOT NULL,
	[RULE_TYPE] [varchar](6) NOT NULL,
	[EBM_RULETYP_1] [varchar](35) NOT NULL,
	[EBM_RULETYP_2] [varchar](55) NOT NULL,
	[TYPICAL] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MAP_EBM_DLS](
	[SVC_CASE_ID] [int] NOT NULL,
	[SVC_RULE_ID] [int] NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_EBM_CASES](
	[RPT_CASE_ID] [int] NOT NULL,
	[EBM_COND_1_ID] [int] NOT NULL,
	[EBM_COND_1] [varchar](50) NOT NULL,
	[EBM_COND_2] [varchar](50) NOT NULL,
	[EBM_COND_2_MASK] [varchar](50) NULL,
	[ENABLED] [bit] NOT NULL,
	[EXT_FLAG] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_EBM_ATTR](
	[EBM_ATTR_ID] [tinyint] NOT NULL,
	[EBM_ATTR_DESC] [varchar](50) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_DX_FMT](
	[ICDDX] [varchar](7) NOT NULL,
	[FMT] [varchar](10) NOT NULL,
	[ICD_VERSION] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_DRG_TYPE](
	[DRG_ADMITTYP] [varchar](3) NOT NULL,
	[DRG_TYPE_DESC] [varchar](79) NOT NULL,
	[DRG_ADMIT_LV1] [varchar](9) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_DRG](
	[DRG_CODE] [varchar](4) NOT NULL,
	[DRG_DESC] [varchar](150) NOT NULL,
	[MDC] [smallint] NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[DRG_VERSION] [varchar](3) NULL,
	[DRG_LEVEL] [varchar](2) NULL,
	[DRG_ID] [varchar](12) NOT NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_DISEASE](
	[DISEASE_ID] [smallint] NOT NULL,
	[DISEASE_DESC] [varchar](60) NOT NULL,
	[DISEASE_DESC_MASK] [varchar](60) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_DENIED_IND](
	[DENIED_IND_ID] [varchar](40) NOT NULL,
	[DENIED_IND] [varchar](30) NOT NULL,
	[DENIED_IND_DESC] [varchar](150) NOT NULL,
	[DENIED_IND_LV2_ID] [varchar](100) NULL,
	[DENIED_IND_LV2] [varchar](30) NULL,
	[DENIED_IND_LV2_DESC] [varchar](150) NULL,
	[DENIED_IND_LV1_ID] [varchar](100) NULL,
	[DENIED_IND_LV1] [varchar](30) NULL,
	[DENIED_IND_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_N] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL,
	[DENIED_STATUS] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_DCC](
	[DCC] [char](5) NOT NULL,
	[GEN_NAME] [varchar](255) NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[PCC] [char](3) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_DAW](
	[DAW] [tinyint] NOT NULL,
	[DAW_DESC] [varchar](75) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_DATE_RANGE](
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[YR_MONTH] [int] NOT NULL,
	[YEAR_VAL] [smallint] NOT NULL,
	[YEAR_LABEL] [char](4) NOT NULL,
	[QTR_ID] [tinyint] NOT NULL,
	[QTR_VAL] [tinyint] NOT NULL,
	[QTR_CODE] [varchar](10) NULL,
	[QTR_LABEL1] [varchar](3) NOT NULL,
	[QTR_LABEL2] [varchar](12) NOT NULL,
	[QTR_DATE_DESC] [varchar](50) NULL,
	[QTR_FULL_DESC] [varchar](50) NULL,
	[MONTH_VAL] [tinyint] NOT NULL,
	[MONTH_LABEL1] [varchar](10) NOT NULL,
	[MONTH_LABEL2] [char](3) NOT NULL,
	[MONTH_LABEL3] [varchar](10) NOT NULL,
	[MONTH_DATE] [smalldatetime] NOT NULL,
	[MONTH_END_DATE] [smalldatetime] NULL,
	[MONTH_CODE] [varchar](10) NULL,
	[MONTH_FULL_DESC] [varchar](50) NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[IA_TIME_CODE] [varchar](15) NULL,
	[IA_TIME_DESC] [varchar](25) NOT NULL,
	[IA_TIME_DATE_DESC] [varchar](25) NULL,
	[IA_TIME_FULL_DESC] [varchar](55) NULL,
	[IA_TIME_START_DATE] [smalldatetime] NULL,
	[IA_TIME_END_DATE] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_COVERAGE_STATUS](
	[COVERAGE_STATUS_ID] [varchar](40) NOT NULL,
	[COVERAGE_STATUS] [varchar](30) NOT NULL,
	[COVERAGE_STATUS_DESC] [varchar](150) NOT NULL,
	[COVERAGE_STATUS_LV2_ID] [varchar](100) NULL,
	[COVERAGE_STATUS_LV2] [varchar](30) NULL,
	[COVERAGE_STATUS_LV2_DESC] [varchar](150) NULL,
	[COVERAGE_STATUS_LV1_ID] [varchar](100) NULL,
	[COVERAGE_STATUS_LV1] [varchar](30) NULL,
	[COVERAGE_STATUS_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL,
	[COVERAGE_CLASS] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_COVERAGE_CLASS](
	[COVERAGE_CLASS] [tinyint] NOT NULL,
	[COVERAGE_CLASS_DESC] [varchar](20) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_COUNTY](
	[COUNTY_ID] [int] NOT NULL,
	[COUNTY_DESC] [varchar](40) NOT NULL,
	[STATE] [tinyint] NOT NULL,
	[STATE_DESC] [char](2) NOT NULL,
	[CENS_REG] [tinyint] NOT NULL,
	[CENS_REG_DESC] [varchar](30) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_CONTRACT_TYPE](
	[CONTRACT_TYPE_ID] [varchar](40) NOT NULL,
	[CONTRACT_TYPE] [varchar](30) NOT NULL,
	[CONTRACT_TYPE_DESC] [varchar](150) NOT NULL,
	[CONTRACT_TYPE_LV2_ID] [varchar](100) NULL,
	[CONTRACT_TYPE_LV2] [varchar](30) NULL,
	[CONTRACT_TYPE_LV2_DESC] [varchar](150) NULL,
	[CONTRACT_TYPE_LV1_ID] [varchar](100) NULL,
	[CONTRACT_TYPE_LV1] [varchar](30) NULL,
	[CONTRACT_TYPE_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_CONTRACT](
	[CONTRACT_ID] [varchar](40) NOT NULL,
	[CONTRACT] [varchar](30) NOT NULL,
	[CONTRACT_DESC] [varchar](150) NULL,
	[CONTRACT_LV2_ID] [varchar](100) NULL,
	[CONTRACT_LV2] [varchar](30) NULL,
	[CONTRACT_LV2_DESC] [varchar](150) NULL,
	[CONTRACT_LV1_ID] [varchar](100) NULL,
	[CONTRACT_LV1] [varchar](30) NULL,
	[CONTRACT_LV1_DESC] [varchar](150) NULL,
	[CONTRACT_HIER] [tinyint] NOT NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_CLM_TYPE](
	[CLM_TYPE] [char](1) NOT NULL,
	[CLM_TYPE_DESC] [varchar](12) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_CLM_EXCLUDE](
	[CLM_EXCLUDE] [tinyint] NOT NULL,
	[CLM_EXCLUDE_DESC] [varchar](40) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_CHANNEL](
	[CHANNEL] [int] NOT NULL,
	[CHANNEL_DESC] [varchar](25) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_CATSTATUS](
	[CAT_STATUS_LV2] [tinyint] NOT NULL,
	[CAT_STATUS_LV2_DESC] [varchar](22) NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[CAT_STATUS_DESC] [varchar](22) NOT NULL,
	[THRESHOLD] [decimal](19, 2) NOT NULL,
	[CAT25K] [bit] NOT NULL,
	[CAT50K] [bit] NOT NULL,
	[CAT100K] [bit] NOT NULL,
	[CAT200K] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MAP_CASE_RULE](
	[CASE_RULE_ID] [int] NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_BIZ_SEGMENT](
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[BIZ_SEGMENT] [varchar](30) NOT NULL,
	[BIZ_SEGMENT_DESC] [varchar](150) NOT NULL,
	[BIZ_SEGMENT_LV2_ID] [varchar](100) NULL,
	[BIZ_SEGMENT_LV2] [varchar](30) NULL,
	[BIZ_SEGMENT_LV2_DESC] [varchar](150) NULL,
	[BIZ_SEGMENT_LV1_ID] [varchar](100) NULL,
	[BIZ_SEGMENT_LV1] [varchar](30) NULL,
	[BIZ_SEGMENT_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL,
	[BIZ_SEGMENT_NUM_ID] [int] IDENTITY(1,1) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_BENEFIT_PLAN](
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL,
	[BENEFIT_PLAN] [varchar](30) NOT NULL,
	[BENEFIT_PLAN_DESC] [varchar](150) NOT NULL,
	[BENEFIT_PLAN_LV2_ID] [varchar](100) NULL,
	[BENEFIT_PLAN_LV2] [varchar](30) NULL,
	[BENEFIT_PLAN_LV2_DESC] [varchar](150) NULL,
	[BENEFIT_PLAN_LV1_ID] [varchar](100) NULL,
	[BENEFIT_PLAN_LV1] [varchar](30) NULL,
	[BENEFIT_PLAN_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ATTRIB_LVL](
	[ATTRIB_LVL_ID] [tinyint] NOT NULL,
	[ATTRIB_LVL_CODE] [varchar](5) NOT NULL,
	[ATTRIB_LVL_DESC] [varchar](20) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ATTR_REASON](
	[ATTR_REASON_ID] [tinyint] NOT NULL,
	[ATTR_REASON_DESC] [varchar](120) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_AT_RISK_STATUS](
	[MAP_SRCE_E] [varchar](6) NULL,
	[AT_RISK_STATUS_ID] [varchar](40) NOT NULL,
	[AT_RISK_STATUS] [varchar](30) NOT NULL,
	[AT_RISK_STATUS_DESC] [varchar](150) NOT NULL,
	[AT_RISK_STATUS_LV1_ID] [varchar](100) NULL,
	[AT_RISK_STATUS_LV1] [varchar](30) NULL,
	[AT_RISK_STATUS_LV1_DESC] [varchar](150) NULL,
	[AT_RISK_STATUS_LV2_ID] [varchar](100) NULL,
	[AT_RISK_STATUS_LV2] [varchar](30) NULL,
	[AT_RISK_STATUS_LV2_DESC] [varchar](150) NULL,
	[RIFLAG] [tinyint] NULL,
	[RISK_STATUS] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_AGE](
	[AGE] [smallint] NOT NULL,
	[AGE_CAT1] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[AGE_LAB1] [char](5) NOT NULL,
	[AGE_LAB2] [char](5) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ADMIT_SOURCE](
	[ADMIT_SOURCE] [char](1) NOT NULL,
	[ADMIT_SOURCE_DESC] [varchar](100) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ACW](
	[ACW_ID] [tinyint] NOT NULL,
	[ACW_DESC] [varchar](10) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[MAP_ACCOUNT](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[ACCOUNT] [varchar](30) NOT NULL,
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[ACCOUNT_DESC] [varchar](150) NULL,
	[ACCOUNT_LV2_ID] [varchar](100) NULL,
	[ACCOUNT_LV2] [varchar](30) NULL,
	[ACCOUNT_LV2_DESC] [varchar](150) NULL,
	[ACCOUNT_LV1_ID] [varchar](100) NULL,
	[ACCOUNT_LV1] [varchar](30) NULL,
	[ACCOUNT_LV1_DESC] [varchar](150) NULL,
	[MAP_SRCE_E] [varchar](6) NULL,
	[RIFLAG] [tinyint] NULL,
	[ACCOUNT_NUM_ID] [int] IDENTITY(1,1) NOT NULL,
	[INDUSTRY] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[LAB](
	[MEMBER] [varchar](32) NOT NULL,
	[DOS] [smalldatetime] NOT NULL,
	[LOINC] [varchar](7) NULL,
	[UNITS] [varchar](25) NULL,
	[STR_VAL] [varchar](25) NULL,
	[NUM_VAL] [decimal](19, 2) NULL,
	[CLAIM_ID] [varchar](30) NOT NULL,
	[CLM_TYPE] [char](1) NOT NULL,
	[UNIQ_REC_ID] [bigint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[II_DB_VERSION](
	[SETID] [char](10) NOT NULL,
	[MAJOR] [smallint] NOT NULL,
	[MINOR] [smallint] NOT NULL,
	[BUILD] [smallint] NOT NULL,
	[REVISION] [smallint] NOT NULL,
	[MODULE] [varchar](10) NULL,
	[CODE_UPD_VERSION] [smalldatetime] NULL,
	[CODE_UPD_APPLIED] [smalldatetime] NULL,
	[REPORT_BEGIN_DATE] [smalldatetime] NULL,
	[REPORT_END_DATE] [smalldatetime] NULL,
	[PAID_THROUGH_DATE] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[IA_TIMES](
	[MEMBER] [varchar](32) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[TOT_MM] [decimal](19, 2) NULL,
	[TOT_PHM_MM] [decimal](19, 2) NULL,
	[MED_QUAL] [bit] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[PRISK] [decimal](10, 4) NULL,
	[RRISK] [decimal](10, 4) NULL,
	[ARISK] [decimal](10, 4) NULL,
	[PRISK_CAT] [tinyint] NULL,
	[RRISK_CAT] [tinyint] NULL,
	[WRRISK] [decimal](10, 4) NULL,
	[PTL_YR_ENR] [bit] NOT NULL,
	[AGE] [smallint] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[CAT_STATUS_COST3] [tinyint] NOT NULL,
	[CAT_RATIO] [decimal](19, 2) NOT NULL,
	[ACT_LAST] [bit] NOT NULL,
	[PRFL_MEM] [tinyint] NULL,
	[PCP_IMP] [varchar](20) NULL,
	[TOT_DEN_MM] [decimal](19, 2) NULL,
	[CUST_MEM_1] [varchar](255) NULL,
	[CUST_MEM_10] [varchar](255) NULL,
	[CUST_MEM_11] [varchar](255) NULL,
	[CUST_MEM_12] [varchar](255) NULL,
	[CUST_MEM_13] [varchar](255) NULL,
	[CUST_MEM_14] [varchar](255) NULL,
	[CUST_MEM_15] [varchar](255) NULL,
	[CUST_MEM_16] [float] NULL,
	[CUST_MEM_17] [float] NULL,
	[CUST_MEM_18] [float] NULL,
	[CUST_MEM_19] [float] NULL,
	[CUST_MEM_2] [varchar](255) NULL,
	[CUST_MEM_20] [float] NULL,
	[CUST_MEM_3] [varchar](255) NULL,
	[CUST_MEM_4] [varchar](255) NULL,
	[CUST_MEM_5] [varchar](255) NULL,
	[CUST_MEM_6] [varchar](255) NULL,
	[CUST_MEM_7] [varchar](255) NULL,
	[CUST_MEM_8] [varchar](255) NULL,
	[CUST_MEM_9] [varchar](255) NULL,
	[CUST_MEM_PK_ID] [varchar](32) NULL,
	[CUST_SUB_1] [varchar](255) NULL,
	[CUST_SUB_10] [varchar](255) NULL,
	[CUST_SUB_11] [varchar](255) NULL,
	[CUST_SUB_12] [varchar](255) NULL,
	[CUST_SUB_13] [varchar](255) NULL,
	[CUST_SUB_14] [varchar](255) NULL,
	[CUST_SUB_15] [varchar](255) NULL,
	[CUST_SUB_16] [float] NULL,
	[CUST_SUB_17] [float] NULL,
	[CUST_SUB_18] [float] NULL,
	[CUST_SUB_19] [float] NULL,
	[CUST_SUB_2] [varchar](255) NULL,
	[CUST_SUB_20] [float] NULL,
	[CUST_SUB_3] [varchar](255) NULL,
	[CUST_SUB_4] [varchar](255) NULL,
	[CUST_SUB_5] [varchar](255) NULL,
	[CUST_SUB_6] [varchar](255) NULL,
	[CUST_SUB_7] [varchar](255) NULL,
	[CUST_SUB_8] [varchar](255) NULL,
	[CUST_SUB_9] [varchar](255) NULL,
	[CUST_SUB_PK_ID] [varchar](32) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[FACT_PROV_QUALITY](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[CASE_RULE_ID] [int] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[PCP_IMP_FLAG] [bit] NOT NULL,
	[EVENT_ID] [int] NOT NULL,
	[RESULT_FLAG] [tinyint] NOT NULL,
	[EBM_NUM] [tinyint] NOT NULL,
	[EBM_DEN] [int] NOT NULL,
	[PEER_EBM_NUM] [decimal](28, 6) NOT NULL,
	[ALL_EBM_NUM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[FACT_POP_MEM](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[RISKCAT_LV2] [tinyint] NOT NULL,
	[MM_CP] [decimal](19, 2) NOT NULL,
	[MM_PP] [decimal](19, 2) NOT NULL,
	[ACCOUNT_LV1_ID] [varchar](100) NULL,
	[ACCOUNT_LV2_ID] [varchar](100) NULL,
	[PRODUCT_LV1_ID] [varchar](100) NULL,
	[PRODUCT_LV2_ID] [varchar](100) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[FACT_POP_COST_UTIL](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[RISKCAT_LV2] [tinyint] NOT NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL,
	[TOS3_ID] [int] NOT NULL,
	[MPC] [smallint] NOT NULL,
	[FAMILY] [smallint] NOT NULL,
	[COST1_PP] [decimal](19, 2) NOT NULL,
	[COST1_CP] [decimal](19, 2) NOT NULL,
	[COST3_PP] [decimal](19, 2) NOT NULL,
	[COST3_CP] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_PP] [decimal](19, 2) NOT NULL,
	[ENCOUNTER_CP] [decimal](19, 2) NOT NULL,
	[ADMIT_PP] [decimal](19, 2) NOT NULL,
	[ADMIT_CP] [decimal](19, 2) NOT NULL,
	[RAD_UTIL_PP] [decimal](19, 2) NOT NULL,
	[RAD_UTIL_CP] [decimal](19, 2) NOT NULL,
	[LAB_UTIL_PP] [decimal](19, 2) NOT NULL,
	[LAB_UTIL_CP] [decimal](19, 2) NOT NULL,
	[MRI_UTIL_PP] [decimal](19, 2) NOT NULL,
	[MRI_UTIL_CP] [decimal](19, 2) NOT NULL,
	[ER_UTIL_PP] [decimal](19, 2) NOT NULL,
	[ER_UTIL_CP] [decimal](19, 2) NOT NULL,
	[ACCOUNT_LV1_ID] [varchar](100) NULL,
	[ACCOUNT_LV2_ID] [varchar](100) NULL,
	[PRODUCT_LV1_ID] [varchar](100) NULL,
	[PRODUCT_LV2_ID] [varchar](100) NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[AFFIL_ID] [varchar](40) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[FAC_ATTRIB_BASE_ETG_TOS](
	[BASE_ETG] [varchar](6) NOT NULL,
	[BASE_ETG_DESC] [varchar](150) NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[LOW_OUTLIERS_INCLUDED] [int] NOT NULL,
	[ZERO_DOLLARS_INCLUDED] [int] NOT NULL,
	[EPISODE_COUNT] [int] NOT NULL,
	[ACTUAL_COST] [decimal](19, 2) NULL,
	[EXPECTED_COST] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ETG_TX](
	[EPISODE_ID] [int] NOT NULL,
	[TX_CODE] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_SUMMARY](
	[MEMBER] [varchar](32) NOT NULL,
	[ETG_RESP_PROV] [varchar](20) NULL,
	[ETG] [varchar](9) NOT NULL,
	[ETG_AGE] [smallint] NOT NULL,
	[ETG_GENDER] [char](1) NOT NULL,
	[EPISODE_ID] [int] NOT NULL,
	[TOT_ALLOW] [decimal](19, 2) NOT NULL,
	[TOT_PAID] [decimal](19, 2) NOT NULL,
	[MGMT_ALLOW] [decimal](19, 2) NOT NULL,
	[SURG_ALLOW] [decimal](19, 2) NOT NULL,
	[FAC_ALLOW] [decimal](19, 2) NOT NULL,
	[ANC_INP_ALLOW] [decimal](19, 2) NOT NULL,
	[ANC_OUT_ALLOW] [decimal](19, 2) NOT NULL,
	[RX_ALLOW] [decimal](19, 2) NOT NULL,
	[MGMT_PAID] [decimal](19, 2) NOT NULL,
	[SURG_PAID] [decimal](19, 2) NOT NULL,
	[FAC_PAID] [decimal](19, 2) NOT NULL,
	[ANC_INP_PAID] [decimal](19, 2) NOT NULL,
	[ANC_OUT_PAID] [decimal](19, 2) NOT NULL,
	[RX_PAID] [decimal](19, 2) NOT NULL,
	[EPI_FROM] [smalldatetime] NOT NULL,
	[EPI_TO] [smalldatetime] NOT NULL,
	[START_DX] [varchar](8) NULL,
	[SHIFT_PROC] [varchar](5) NULL,
	[SHIFT_DX] [varchar](8) NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[USER_OUTLIER] [tinyint] NULL,
	[EPI_TYPE] [tinyint] NOT NULL,
	[USER_EPI_TYPE] [tinyint] NULL,
	[TOT_CLUS] [int] NOT NULL,
	[TOT_PHANTOM] [int] NOT NULL,
	[INC_REASON] [tinyint] NULL,
	[USER_INC_REASON] [tinyint] NULL,
	[SEV_SCORE] [decimal](10, 4) NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[SEV_ERROR_STAT] [tinyint] NOT NULL,
	[ETG_CHRONIC_ID] [smallint] NULL,
	[ELIG_DAYS] [smallint] NULL,
	[START_DX_ICD_VERSION] [tinyint] NULL,
	[SHIFT_DX_ICD_VERSION] [tinyint] NULL,
	[FIRST_ANCHOR_DATE] [smalldatetime] NULL,
	[LAST_ANCHOR_DATE] [smalldatetime] NULL,
	[SPEC_DRUG_COUNT] [tinyint] NULL,
	[USER_SPEC_DRUG_COUNT] [tinyint] NULL,
	[LOB] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_PHANTOM](
	[MEMBER] [varchar](32) NOT NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[REVENUE] [varchar](15) NULL,
	[PROCCODE] [varchar](15) NULL,
	[MOD_N] [varchar](4) NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[ETG_FROM_DT] [smalldatetime] NOT NULL,
	[ETG_TO_DT] [smalldatetime] NOT NULL,
	[ETG_TOS] [smallint] NULL,
	[PROVIDER] [varchar](20) NOT NULL,
	[ETG_TOP] [smallint] NOT NULL,
	[NDC] [varchar](11) NULL,
	[CLAIM_ID] [varchar](30) NOT NULL,
	[ORDER_PROV] [varchar](20) NULL,
	[BILL_TYPE_IND] [char](1) NULL,
	[DIS_STAT] [varchar](3) NULL,
	[BED_TYPE] [varchar](2) NULL,
	[ETG] [varchar](9) NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[EPISODE_ID] [int] NULL,
	[CLUSTER] [int] NULL,
	[EPI_TYPE] [tinyint] NOT NULL,
	[USER_EPI_TYPE] [tinyint] NULL,
	[REC_TYPE] [char](1) NOT NULL,
	[CLUS_PRV] [varchar](20) NULL,
	[DCC] [char](5) NULL,
	[INT_ETG_TOP] [smallint] NOT NULL,
	[INT_ETG_TOS] [smallint] NOT NULL,
	[ETG_CONF_NUM] [int] NULL,
	[ETG_VERSION] [varchar](1) NOT NULL,
	[PHANTOM] [tinyint] NOT NULL,
	[ANC_TYPE] [char](1) NULL,
	[OUTLIER] [tinyint] NULL,
	[USER_OUTLIER] [tinyint] NULL,
	[MED_CLM_TYPE] [bit] NOT NULL,
	[POS_I] [tinyint] NULL,
	[PRV_SP_4] [int] NULL,
	[PAY_DT] [smalldatetime] NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[MET_QTY] [decimal](19, 2) NULL,
	[DAYS_SUP] [smallint] NULL,
	[UNQ_SVC] [bigint] NULL,
	[PRV_KEY] [varchar](20) NULL,
	[ICD_VERSION] [tinyint] NULL,
	[DIAG5] [varchar](8) NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_PATIENT_COMORB](
	[MEMBER] [varchar](32) NOT NULL,
	[COMORB_CODE] [int] NOT NULL,
	[COMORB_ID] [int] NOT NULL,
	[START_DT] [smalldatetime] NOT NULL,
	[END_DT] [smalldatetime] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_OPP_SUMMARY](
	[IA_TIME] [tinyint] NOT NULL,
	[BASE_ETG] [varchar](6) NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[TOT_EPI_QTY] [decimal](19, 2) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[OE_25] [decimal](28, 6) NULL,
	[OE_50] [decimal](28, 6) NULL,
	[OE_75] [decimal](28, 6) NULL,
	[TOT_EPI_QTY_25] [decimal](19, 2) NOT NULL,
	[TOT_EPI_QTY_50] [decimal](19, 2) NOT NULL,
	[TOT_EPI_QTY_75] [decimal](19, 2) NOT NULL,
	[COST_ACT_TOT_25] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT_50] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT_75] [decimal](28, 6) NOT NULL,
	[COST_PER_EPI_SAVINGS_25] [decimal](28, 6) NOT NULL,
	[COST_PER_EPI_SAVINGS_50] [decimal](28, 6) NOT NULL,
	[COST_PER_EPI_SAVINGS_75] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT_SAVINGS_25] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT_SAVINGS_50] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT_SAVINGS_75] [decimal](28, 6) NOT NULL,
	[NET_DISRUPT_25] [decimal](28, 6) NOT NULL,
	[NET_DISRUPT_50] [decimal](28, 6) NOT NULL,
	[NET_DISRUPT_75] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_OPP_PROV](
	[IA_TIME] [tinyint] NOT NULL,
	[BASE_ETG] [varchar](6) NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[PROVIDER_NAME] [varchar](50) NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[OE] [decimal](28, 6) NULL,
	[ETG_25] [bit] NULL,
	[ETG_50] [bit] NULL,
	[ETG_75] [bit] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_EPISODE_ATTRIB](
	[EPISODE_ID] [int] NOT NULL,
	[PROVIDER] [varchar](20) NOT NULL,
	[PMS_CLAIM_COUNT] [int] NOT NULL,
	[PMS_CLAIM_ALLOW] [decimal](19, 2) NOT NULL,
	[PMSRB_CLAIM_ALLOW] [decimal](19, 2) NOT NULL,
	[EM_VISITS] [int] NOT NULL,
	[NON_ACUTE_EM_VISITS] [int] NOT NULL,
	[TOT_ALLOW] [decimal](19, 2) NOT NULL,
	[TOT_CLUSTER] [int] NOT NULL,
	[TOT_CLUSTER_PHANTOM] [int] NOT NULL,
	[FIRST_PROVIDER] [tinyint] NOT NULL,
	[LAST_PROVIDER] [tinyint] NOT NULL,
	[CLUSTER_FROM_DT] [smalldatetime] NULL,
	[CLUSTER_TO_DT] [smalldatetime] NULL,
	[CLINICIAN_FLAG] [tinyint] NOT NULL,
	[FACILITY_FLAG] [tinyint] NOT NULL,
	[PCT_TOT_AMT_ALLOW] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_EPISODE](
	[EPISODE_ID] [int] NOT NULL,
	[ETG_BASE_CLASS] [varchar](6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_CONFINEMENT](
	[ETG_CONF_NUM] [int] NOT NULL,
	[EPISODE_ID] [int] NULL,
	[ETG] [varchar](9) NOT NULL,
	[ADMIT_DT] [smalldatetime] NOT NULL,
	[DISCHG_DT] [smalldatetime] NOT NULL,
	[LOS] [smallint] NOT NULL,
	[EPI_TYPE] [tinyint] NULL,
	[CONF_TYPE] [tinyint] NOT NULL,
	[PROVIDER] [varchar](20) NOT NULL,
	[RESP_PROVIDER] [varchar](20) NULL,
	[DIS_STAT] [varchar](3) NULL,
	[ETG_GENDER] [char](1) NOT NULL,
	[ADMIT_AGE] [smallint] NOT NULL,
	[DISCHG_AGE] [smallint] NOT NULL,
	[FAC_TYPE] [varchar](2) NULL,
	[BED_TYPE] [varchar](1) NULL,
	[PROC1] [varchar](5) NULL,
	[PROC2] [varchar](5) NULL,
	[PROC3] [varchar](5) NULL,
	[PROC4] [varchar](5) NULL,
	[PROC5] [varchar](5) NULL,
	[PROC6] [varchar](5) NULL,
	[PROC7] [varchar](5) NULL,
	[PROC8] [varchar](5) NULL,
	[PROC9] [varchar](5) NULL,
	[PROC10] [varchar](5) NULL,
	[PROC11] [varchar](5) NULL,
	[PROC12] [varchar](5) NULL,
	[PROC13] [varchar](5) NULL,
	[PROC14] [varchar](5) NULL,
	[PROC15] [varchar](5) NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[DIAG5] [varchar](8) NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[DIAG11] [varchar](8) NULL,
	[DIAG12] [varchar](8) NULL,
	[DIAG13] [varchar](8) NULL,
	[DIAG14] [varchar](8) NULL,
	[DIAG15] [varchar](8) NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[IPROC11] [varchar](7) NULL,
	[IPROC12] [varchar](7) NULL,
	[IPROC13] [varchar](7) NULL,
	[IPROC14] [varchar](7) NULL,
	[IPROC15] [varchar](7) NULL,
	[TOT_ALLOW] [decimal](19, 2) NOT NULL,
	[TOT_PAID] [decimal](19, 2) NOT NULL,
	[FAC_ALLOW] [decimal](19, 2) NOT NULL,
	[FAC_PAID] [decimal](19, 2) NOT NULL,
	[ROOM_BOARD_ALLOW] [decimal](19, 2) NOT NULL,
	[ROOM_BOARD_PAID] [decimal](19, 2) NOT NULL,
	[ANC_INP_ALLOW] [decimal](19, 2) NOT NULL,
	[ANC_INP_PAID] [decimal](19, 2) NOT NULL,
	[CLIN_ALLOW] [decimal](19, 2) NOT NULL,
	[CLIN_PAID] [decimal](19, 2) NOT NULL,
	[OTH_ALLOW] [decimal](19, 2) NOT NULL,
	[OTH_PAID] [decimal](19, 2) NOT NULL,
	[EPI_ALLOW] [decimal](19, 2) NOT NULL,
	[EPI_PAID] [decimal](19, 2) NOT NULL,
	[NON_EPI_ALLOW] [decimal](19, 2) NOT NULL,
	[NON_EPI_PAID] [decimal](19, 2) NOT NULL,
	[DIAG1_ICD_VERSION] [tinyint] NULL,
	[DIAG2_ICD_VERSION] [tinyint] NULL,
	[DIAG3_ICD_VERSION] [tinyint] NULL,
	[DIAG4_ICD_VERSION] [tinyint] NULL,
	[DIAG5_ICD_VERSION] [tinyint] NULL,
	[DIAG6_ICD_VERSION] [tinyint] NULL,
	[DIAG7_ICD_VERSION] [tinyint] NULL,
	[DIAG8_ICD_VERSION] [tinyint] NULL,
	[DIAG9_ICD_VERSION] [tinyint] NULL,
	[DIAG10_ICD_VERSION] [tinyint] NULL,
	[DIAG11_ICD_VERSION] [tinyint] NULL,
	[DIAG12_ICD_VERSION] [tinyint] NULL,
	[DIAG13_ICD_VERSION] [tinyint] NULL,
	[DIAG14_ICD_VERSION] [tinyint] NULL,
	[DIAG15_ICD_VERSION] [tinyint] NULL,
	[IPROC1_ICD_VERSION] [tinyint] NULL,
	[IPROC2_ICD_VERSION] [tinyint] NULL,
	[IPROC3_ICD_VERSION] [tinyint] NULL,
	[IPROC4_ICD_VERSION] [tinyint] NULL,
	[IPROC5_ICD_VERSION] [tinyint] NULL,
	[IPROC6_ICD_VERSION] [tinyint] NULL,
	[IPROC7_ICD_VERSION] [tinyint] NULL,
	[IPROC8_ICD_VERSION] [tinyint] NULL,
	[IPROC9_ICD_VERSION] [tinyint] NULL,
	[IPROC10_ICD_VERSION] [tinyint] NULL,
	[IPROC11_ICD_VERSION] [tinyint] NULL,
	[IPROC12_ICD_VERSION] [tinyint] NULL,
	[IPROC13_ICD_VERSION] [tinyint] NULL,
	[IPROC14_ICD_VERSION] [tinyint] NULL,
	[IPROC15_ICD_VERSION] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ETG_CONDSTAT](
	[EPISODE_ID] [int] NOT NULL,
	[COND_STAT] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ETG_COMORB](
	[EPISODE_ID] [int] NOT NULL,
	[COMORB_CODE] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_CLAIMS](
	[MEMBER] [varchar](32) NOT NULL,
	[AMT_PAY] [decimal](19, 2) NOT NULL,
	[AMT_EQV] [decimal](19, 2) NOT NULL,
	[REVENUE] [varchar](15) NULL,
	[PROCCODE] [varchar](15) NULL,
	[MOD_N] [varchar](4) NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[ETG_FROM_DT] [smalldatetime] NOT NULL,
	[ETG_TO_DT] [smalldatetime] NOT NULL,
	[ETG_TOS] [smallint] NULL,
	[PROVIDER] [varchar](20) NULL,
	[ETG_TOP] [smallint] NOT NULL,
	[NDC] [varchar](11) NULL,
	[CLAIM_ID] [varchar](30) NOT NULL,
	[ORDER_PROV] [varchar](20) NULL,
	[BILL_TYPE_IND] [char](1) NULL,
	[DIS_STAT] [varchar](3) NULL,
	[BED_TYPE] [varchar](2) NULL,
	[ETG] [varchar](9) NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[EPISODE_ID] [int] NULL,
	[CLUSTER] [int] NULL,
	[EPI_TYPE] [tinyint] NOT NULL,
	[USER_EPI_TYPE] [tinyint] NULL,
	[REC_TYPE] [char](1) NULL,
	[CLUS_PRV] [varchar](20) NULL,
	[DCC] [char](5) NULL,
	[INT_ETG_TOP] [smallint] NOT NULL,
	[INT_ETG_TOS] [smallint] NOT NULL,
	[ETG_CONF_NUM] [int] NULL,
	[ETG_VERSION] [char](1) NOT NULL,
	[PHANTOM] [tinyint] NOT NULL,
	[ANC_TYPE] [char](1) NULL,
	[OUTLIER] [tinyint] NULL,
	[USER_OUTLIER] [tinyint] NULL,
	[MED_CLM_TYPE] [bit] NOT NULL,
	[POS_I] [tinyint] NULL,
	[PRV_SP_4] [int] NULL,
	[PAY_DT] [smalldatetime] NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[MET_QTY] [decimal](19, 2) NULL,
	[DAYS_SUP] [smallint] NULL,
	[UNQ_SVC] [bigint] NULL,
	[PRV_KEY] [varchar](20) NULL,
	[ICD_VERSION] [tinyint] NULL,
	[DIAG5] [varchar](8) NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[SPEC_DRUG] [tinyint] NULL,
	[USER_SPEC_DRUG] [tinyint] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ETG_ANNUAL](
	[MEMBER] [varchar](32) NOT NULL,
	[ETG_BASE_CLASS] [varchar](6) NOT NULL,
	[START_DT] [smalldatetime] NOT NULL,
	[EPI_TYPE] [tinyint] NOT NULL,
	[TOT_ALLOW] [decimal](19, 2) NOT NULL,
	[TOT_PAID] [decimal](19, 2) NOT NULL,
	[MGMT_ALLOW] [decimal](19, 2) NOT NULL,
	[SURG_ALLOW] [decimal](19, 2) NOT NULL,
	[FAC_ALLOW] [decimal](19, 2) NOT NULL,
	[ANC_INP_ALLOW] [decimal](19, 2) NOT NULL,
	[ANC_OUT_ALLOW] [decimal](19, 2) NOT NULL,
	[RX_ALLOW] [decimal](19, 2) NOT NULL,
	[MGMT_PAID] [decimal](19, 2) NOT NULL,
	[SURG_PAID] [decimal](19, 2) NOT NULL,
	[FAC_PAID] [decimal](19, 2) NOT NULL,
	[ANC_INP_PAID] [decimal](19, 2) NOT NULL,
	[ANC_OUT_PAID] [decimal](19, 2) NOT NULL,
	[RX_PAID] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ERG_RISK](
	[MEMBER] [varchar](32) NOT NULL,
	[ERG_AGE] [smallint] NOT NULL,
	[ERG_GENDER] [char](1) NOT NULL,
	[PRISK] [decimal](10, 4) NOT NULL,
	[RRISK] [decimal](10, 4) NOT NULL,
	[ARISK] [decimal](10, 4) NOT NULL,
	[ACT_PRISK] [decimal](10, 4) NOT NULL,
	[PRISK_CAT] [tinyint] NULL,
	[RRISK_CAT] [tinyint] NULL,
	[ACT_PRISK_CAT] [tinyint] NULL,
	[ERG_ARRAY] [varchar](250) NOT NULL,
	[ERG_EXP_THRESH] [tinyint] NULL,
	[ERG_INP_DATA] [tinyint] NULL,
	[ERG_RISK_OUT] [tinyint] NULL,
	[LOB] [tinyint] NULL,
	[ERG_PARTIAL_ENR] [tinyint] NOT NULL,
	[ERG_ERROR_STAT] [tinyint] NOT NULL,
	[PTL_YR_ENR] [tinyint] NOT NULL,
	[ERG_END_DATE] [smalldatetime] NOT NULL,
	[ERG_VERSION] [char](1) NOT NULL,
	[ERG_DB_VERSION] [varchar](2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EPISODES_TX](
	[EPISODE_ID] [int] NOT NULL,
	[TX_CODE] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EPISODES_COND](
	[EPISODE_ID] [int] NOT NULL,
	[COND_STATUS] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EPISODES_COMORB](
	[EPISODE_ID] [int] NOT NULL,
	[COMORB_CODE] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EPISODES](
	[MEMBER] [varchar](32) NOT NULL,
	[EPISODE_ID] [int] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[EPI_TYPE] [tinyint] NOT NULL,
	[EPI_FROM] [smalldatetime] NOT NULL,
	[EPI_TO] [smalldatetime] NOT NULL,
	[EPI_QTY] [decimal](19, 2) NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[CHRONIC] [tinyint] NOT NULL,
	[OUTLIER_O] [tinyint] NOT NULL,
	[SEV_SCORE] [decimal](19, 4) NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[EPI_COST_RATIO_HI] [decimal](10, 2) NOT NULL,
	[EPI_COST_RATIO_LO] [decimal](10, 2) NOT NULL,
	[TOT_ALLOW] [decimal](19, 2) NOT NULL,
	[ELIG_DAYS] [int] NULL,
	[TX_IND] [tinyint] NOT NULL,
	[ETG] [varchar](9) NOT NULL,
	[IA_TIME] [tinyint] NULL,
	[MED_QUAL] [bit] NULL,
	[PHM_QUAL] [bit] NULL,
	[ETG_RESP_PROV] [varchar](20) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EPI_PROV](
	[PEER_DEF_ID] [int] NOT NULL,
	[EPISODE_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[ATTR_REASON_ID] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EPI_DET_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[COMPLETE] [bit] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[EPI_QTY_ELIG_PEER] [bit] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[OUTLIER_CLINICAL] [tinyint] NOT NULL,
	[EPI_QTY] [decimal](28, 6) NOT NULL,
	[RRISK_EPI_W] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EPI_DET_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[SPECPRV] [bit] NOT NULL,
	[CODE_TYPE] [tinyint] NOT NULL,
	[SERV_CODE] [varchar](15) NULL,
	[PRV_SP_4] [int] NOT NULL,
	[COMPLETE] [bit] NOT NULL,
	[OUTLIER] [tinyint] NOT NULL,
	[EPI_QTY_ELIG_PEER] [bit] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[OUTLIER_CLINICAL] [tinyint] NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_E_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EPI_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[IA_TIME_ADJ] [tinyint] NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[EPI_QTY] [decimal](28, 6) NOT NULL,
	[RRISK_EPI_W] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EPI_COSTS_EPILEVEL](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[EPISODE_ID] [int] NOT NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[EPI_QTY] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[PCC_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RX_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[PCC_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPEC_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RX_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[HOSP_ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[OSPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_ACT_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[MRI_ACT_TOT] [decimal](28, 6) NOT NULL,
	[GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[SCRIPT_GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[OSPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_PEER_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[MRI_PEER_TOT] [decimal](28, 6) NOT NULL,
	[GEN_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER_TOT] [decimal](28, 6) NOT NULL,
	[EPI_PCC_PCT] [decimal](7, 4) NOT NULL,
	[EPI_SPEC_PCT] [decimal](7, 4) NOT NULL,
	[EPI_ER_PCT] [decimal](7, 4) NOT NULL,
	[EPI_RAD_PCT] [decimal](7, 4) NOT NULL,
	[EPI_LAB_PCT] [decimal](7, 4) NOT NULL,
	[EPI_HOSP_PCT] [decimal](7, 4) NOT NULL,
	[EPI_PHM_PCT] [decimal](7, 4) NOT NULL,
	[EPI_PCC_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[EPI_SPEC_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[EPI_ER_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[EPI_RAD_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[EPI_LAB_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[EPI_HOSP_PCT_ADJ] [decimal](7, 4) NOT NULL,
	[EPI_PHM_PCT_ADJ] [decimal](7, 4) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EPI_COSTS_CPT_RISKADJ](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[EPISODE_ID] [int] NOT NULL,
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[PSC_CAT1_ID] [tinyint] NOT NULL,
	[SPECPRV] [bit] NOT NULL,
	[CODE_TYPE] [tinyint] NULL,
	[SERV_CODE] [varchar](15) NULL,
	[PRV_SP_4] [int] NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT_STATUS] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT_ADJ] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT_ADJ] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT_ADJ] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT_ADJ] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EPI_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[ETG_UNIT_ID] [smallint] NOT NULL,
	[ETG_ID] [smallint] NOT NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[PHM_QUAL] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[IA_TIME_ADJ] [tinyint] NULL,
	[PRODUCT_ID] [varchar](40) NULL,
	[PSC_CAT1_ID] [smallint] NOT NULL,
	[UTIL_SPEC_CAT_CD] [smallint] NOT NULL,
	[SPECPRV] [bit] NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ENC_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ENC_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[OSPVIS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_ACT_TOT] [decimal](28, 6) NOT NULL,
	[RAD_ACT_TOT] [decimal](28, 6) NOT NULL,
	[LAB_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ER_ACT_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[MRI_ACT_TOT] [decimal](28, 6) NOT NULL,
	[GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[SCRIPT_GEN_ACT_TOT] [decimal](28, 6) NOT NULL,
	[SPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[OSPVIS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[SCRIPT_PEER_TOT] [decimal](28, 6) NOT NULL,
	[RAD_PEER_TOT] [decimal](28, 6) NOT NULL,
	[LAB_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ER_PEER_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[MRI_PEER_TOT] [decimal](28, 6) NOT NULL,
	[GEN_PEER_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_PEER_TOT] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EMP_PRODUCT_INFO](
	[ACCOUNT_LV1_ID] [varchar](100) NULL,
	[ACCOUNT_LV1_DESC] [varchar](150) NULL,
	[ACCOUNT_LV2_ID] [varchar](100) NULL,
	[ACCOUNT_LV2_DESC] [varchar](150) NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[ACCOUNT_DESC] [varchar](150) NULL,
	[PRODUCT_LV1_ID] [varchar](100) NULL,
	[PRODUCT_LV1_DESC] [varchar](150) NULL,
	[PRODUCT_LV2_ID] [varchar](100) NULL,
	[PRODUCT_LV2_DESC] [varchar](150) NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[PRODUCT_DESC] [varchar](150) NULL,
	[BIZ_SEGMENT_LV1_ID] [varchar](100) NULL,
	[BIZ_SEGMENT_LV1_DESC] [varchar](150) NULL,
	[BIZ_SEGMENT_LV2_ID] [varchar](100) NULL,
	[BIZ_SEGMENT_LV2_DESC] [varchar](150) NULL,
	[BIZ_SEGMENT_ID] [varchar](40) NOT NULL,
	[BIZ_SEGMENT_DESC] [varchar](150) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_1_DESC] [varchar](150) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_DESC] [varchar](150) NOT NULL,
	[INDUSTRY] [tinyint] NULL,
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL,
	[BENEFIT_PLAN_LV1_ID] [varchar](100) NULL,
	[BENEFIT_PLAN_LV2_ID] [varchar](100) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EMP_PRODUCT](
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[ACCOUNT_NUM_ID] [int] NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[PRODUCT_NUM_ID] [int] NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[BENEFIT_PLAN_ID] [varchar](40) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ED_AVOIDABLE_DETAIL](
	[ED_ENC_ID] [int] NULL,
	[CLAIM_ID] [varchar](30) NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[DOS] [smalldatetime] NOT NULL,
	[MEMBER_ATTR_ID] [int] NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[IA_TIME_CODE] [varchar](15) NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[MPC_DX] [smallint] NULL,
	[UNAVOID_ED] [tinyint] NULL,
	[AMB_SENS] [tinyint] NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[DIAG1] [varchar](8) NULL,
	[ER_UTIL] [decimal](19, 2) NULL,
	[COST1] [decimal](19, 2) NULL,
	[COST3] [decimal](19, 2) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ED_AVOIDABLE](
	[ED_ENC_ID] [int] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[MEMBER_NAME] [varchar](100) NULL,
	[DOS] [smalldatetime] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AMB_SENS] [tinyint] NOT NULL,
	[UNAVOID_ED] [tinyint] NOT NULL,
	[MPC_DX] [smallint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NOT NULL,
	[PCP_AFFIL_ID] [varchar](40) NOT NULL,
	[PCP_ASSIGN_NAME] [varchar](50) NULL,
	[PCP_IMP] [varchar](20) NOT NULL,
	[PCP_IMP_AFFIL_ID] [varchar](40) NOT NULL,
	[PCP_IMP_NAME] [varchar](50) NULL,
	[ER_UTIL] [decimal](19, 2) NULL,
	[COST1] [decimal](19, 2) NULL,
	[COST2] [decimal](19, 2) NULL,
	[COST3] [decimal](19, 2) NULL,
	[COST4] [decimal](19, 2) NULL,
	[COST5] [decimal](19, 2) NULL,
	[COST6] [decimal](19, 2) NULL,
	[ACCOUNT_LV1_ID] [varchar](100) NULL,
	[ACCOUNT_LV2_ID] [varchar](100) NULL,
	[PRODUCT_LV1_ID] [varchar](100) NULL,
	[PRODUCT_LV2_ID] [varchar](100) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EBM_SUMMARY_RESULTS](
	[MEMBER] [varchar](32) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[EVENT_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[UNUSED_1] [int] NULL,
	[UNUSED_2] [int] NULL,
	[RESULT_FLAG] [varchar](3) NOT NULL,
	[EBM_NONCOMPLIANCE_FLAG] [bit] NOT NULL,
	[EBM_COMPLIANCE_FLAG] [bit] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EBM_RESULTS](
	[MEMBER] [varchar](32) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[EVENT_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[RESULT_FLAG] [tinyint] NOT NULL,
	[EBM_NONCOMPLIANCE_FLAG] [tinyint] NOT NULL,
	[EBM_NUM] [tinyint] NOT NULL,
	[EXT_FLAG] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EBM_PROV](
	[MEMBER] [varchar](32) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[PCP_IMP_FLAG] [bit] NULL,
	[ATTR_REASON_ID] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EBM_PHYSICIAN_VISITS](
	[MEMBER] [varchar](32) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[EVENT_ID] [int] NOT NULL,
	[PROV_KEY] [varchar](20) NOT NULL,
	[PROV_SPEC] [varchar](2) NOT NULL,
	[IMP_PHY_FLAG] [char](1) NOT NULL,
	[RULE_START_DT] [smalldatetime] NOT NULL,
	[RULE_END_DT] [smalldatetime] NOT NULL,
	[FIRST_VISIT_DATE] [smalldatetime] NOT NULL,
	[LAST_VISIT_DATE] [smalldatetime] NOT NULL,
	[NUM_VISITS] [int] NOT NULL,
	[PAID_AMOUNT] [decimal](19, 2) NOT NULL,
	[CHARGE_AMOUNT] [decimal](19, 2) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EBM_EVENT_PHYSICIAN](
	[MEMBER] [varchar](32) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[EVENT_ID] [int] NOT NULL,
	[PROV_KEY] [varchar](20) NOT NULL,
	[PROV_SPEC] [varchar](2) NOT NULL,
	[SUPPORT_FLAG] [char](1) NULL,
	[INITIAL_STATUS] [char](1) NOT NULL,
	[NUM_VISITS] [int] NOT NULL,
	[PAID_AMOUNT] [decimal](19, 2) NOT NULL,
	[CHARGE_AMOUNT] [decimal](19, 2) NOT NULL,
	[LAST_VISIT_DATE] [smalldatetime] NULL,
	[FIRST_VISIT_DATE] [smalldatetime] NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EBM_ETG_MATCH](
	[MEMBER] [varchar](32) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[ETG] [varchar](9) NOT NULL,
	[EPISODE_ID] [int] NOT NULL,
	[MATCH_FLAG] [char](1) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EBM_COUNT](
	[PEER_DEF_ID] [int] NOT NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL,
	[RPT_RULE_ID] [int] NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[PCP_IMP_FLAG] [bit] NOT NULL,
	[EBM_DEN] [int] NOT NULL,
	[EBM_NUM] [int] NOT NULL,
	[PEER_EBM_NUM] [decimal](28, 6) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[DIS_REG](
	[MEMBER] [varchar](32) NOT NULL,
	[RPT_CASE_ID] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CUSTOM_RULE_RESULTS](
	[MEMBER] [varchar](32) NOT NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[ATTRIBUTION_RULE] [tinyint] NOT NULL,
	[CUST_RULE_ID] [int] NOT NULL,
	[RESULT_FLAG] [tinyint] NOT NULL,
	[NEG_FLAG] [tinyint] NOT NULL,
	[EVENT_ID] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CUSTOM_MAP_RULES](
	[CUST_CASE_ID] [int] NOT NULL,
	[CUST_RULE_ID] [int] NOT NULL,
	[RULE_TYPE_ID] [tinyint] NOT NULL,
	[CUST_RULE_DESC] [varchar](212) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CUSTOM_MAP_INFO](
	[CUST_MAP_INFO_ID] [int] IDENTITY(1,1) NOT NULL,
	[MAP_NAME] [varchar](50) NOT NULL,
	[MAP_FRIENDLY_NAME] [varchar](100) NOT NULL,
	[LEVEL1_DESC] [varchar](50) NULL,
	[LEVEL2_DESC] [varchar](50) NULL,
	[LEVEL3_DESC] [varchar](50) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CUSTOM_MAP_CASES](
	[CUST_CASE_ID] [int] NOT NULL,
	[CUST_COND_1_ID] [int] NOT NULL,
	[CUST_COND_1] [varchar](45) NOT NULL,
	[CUST_CASE_DESC] [varchar](45) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CUSTOM_LABELS](
	[LABEL_DEFAULT] [varchar](50) NOT NULL,
	[CUSTOM_LABEL] [varchar](100) NOT NULL,
	[COLUMN_NAME] [varchar](255) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CONTRACT_ERG](
	[ERG_RUN_ID] [smallint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[CONTRACT_ID] [varchar](40) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[TOT_MM] [decimal](19, 2) NULL,
	[TOT_PHM_MM] [decimal](19, 2) NULL,
	[PRISK] [decimal](10, 4) NULL,
	[RRISK] [decimal](10, 4) NULL,
	[ARISK] [decimal](10, 4) NULL,
	[ACT_PRISK] [decimal](10, 4) NULL,
	[PRISK_CAT] [tinyint] NULL,
	[RRISK_CAT] [tinyint] NULL,
	[ACT_PRISK_CAT] [tinyint] NULL,
	[ERG_ARRAY] [varchar](250) NULL,
	[ERG_EXP_THRESH] [tinyint] NULL,
	[ERG_INP_DATA] [tinyint] NULL,
	[ERG_RISK_OUT] [tinyint] NULL,
	[LOB] [tinyint] NULL,
	[ERG_PARTIAL_ENR] [tinyint] NULL,
	[ERG_ERROR_STAT] [tinyint] NULL,
	[PTL_YR_ENR] [tinyint] NULL,
	[ERG_END_DATE] [smalldatetime] NULL,
	[ERG_VERSION] [char](1) NULL,
	[ERG_DB_VERSION] [varchar](2) NULL,
	[ERG_AGE] [smallint] NULL,
	[ERG_GENDER] [char](1) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CONFINEMENTS_PQI](
	[CONF_NUM] [bigint] NOT NULL,
	[PQI] [tinyint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CONFINEMENTS](
	[MEMBER] [varchar](32) NOT NULL,
	[CONF_NUM] [bigint] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[BEG_DT] [smalldatetime] NOT NULL,
	[END_DT] [smalldatetime] NOT NULL,
	[LOS] [smallint] NOT NULL,
	[PRV_BEG] [varchar](20) NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[DIAG1] [varchar](8) NULL,
	[DIAG2] [varchar](8) NULL,
	[DIAG3] [varchar](8) NULL,
	[DIAG4] [varchar](8) NULL,
	[DIAG5] [varchar](8) NULL,
	[DIAG6] [varchar](8) NULL,
	[DIAG7] [varchar](8) NULL,
	[DIAG8] [varchar](8) NULL,
	[DIAG9] [varchar](8) NULL,
	[DIAG10] [varchar](8) NULL,
	[IPROC1] [varchar](7) NULL,
	[IPROC2] [varchar](7) NULL,
	[IPROC3] [varchar](7) NULL,
	[IPROC4] [varchar](7) NULL,
	[IPROC5] [varchar](7) NULL,
	[IPROC6] [varchar](7) NULL,
	[IPROC7] [varchar](7) NULL,
	[IPROC8] [varchar](7) NULL,
	[IPROC9] [varchar](7) NULL,
	[IPROC10] [varchar](7) NULL,
	[PAY_DT_BEG] [smalldatetime] NOT NULL,
	[PAY_DT] [smalldatetime] NOT NULL,
	[TOS_I_4] [int] NOT NULL,
	[TOS_I_5] [int] NOT NULL,
	[POS_I] [tinyint] NOT NULL,
	[PRV_SP_4] [int] NOT NULL,
	[DRG_ID] [varchar](12) NULL,
	[DIS_STAT] [varchar](3) NULL,
	[AMT_CAP_PAY] [decimal](19, 2) NULL,
	[AMT_COB] [decimal](19, 2) NULL,
	[AMT_COIN] [decimal](19, 2) NULL,
	[AMT_COP] [decimal](19, 2) NULL,
	[AMT_DED] [decimal](19, 2) NULL,
	[AMT_EQV] [decimal](19, 2) NULL,
	[AMT_LIAB] [decimal](19, 2) NULL,
	[AMT_OTH1] [decimal](19, 2) NULL,
	[AMT_OTH2] [decimal](19, 2) NULL,
	[AMT_OTH3] [decimal](19, 2) NULL,
	[AMT_OTH4] [decimal](19, 2) NULL,
	[AMT_PAY] [decimal](19, 2) NULL,
	[AMT_REQ] [decimal](19, 2) NULL,
	[AMT_WTH] [decimal](19, 2) NULL,
	[RSNF] [tinyint] NULL,
	[SNF] [tinyint] NULL,
	[REHAB] [tinyint] NULL,
	[NEWBORN] [tinyint] NULL,
	[MSURG] [tinyint] NULL,
	[MATERN] [tinyint] NULL,
	[ICUSTAY] [tinyint] NULL,
	[ICUSURG] [tinyint] NULL,
	[DRG_OUTLIER] [tinyint] NULL,
	[POA] [char](1) NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[EPISODE_ID] [int] NULL,
	[CLUS_PRV] [varchar](20) NULL,
	[CLUSTER] [int] NULL,
	[REC_TYPE] [char](1) NULL,
	[ETG_ID] [smallint] NULL,
	[ETG] [varchar](9) NULL,
	[SEV_LEVEL] [tinyint] NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[NOENR_DOS] [bit] NULL,
	[CLM_TYPE] [char](1) NOT NULL,
	[EXCLUDE] [bit] NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[READMIT_INDEX_07] [bit] NOT NULL,
	[READMIT_INDEX_30] [bit] NOT NULL,
	[READMIT_INDEX_60] [bit] NOT NULL,
	[READMIT_INDEX_90] [bit] NOT NULL,
	[READMIT_07] [bit] NOT NULL,
	[READMIT_30] [bit] NOT NULL,
	[READMIT_60] [bit] NOT NULL,
	[READMIT_90] [bit] NOT NULL,
	[READMIT_CONF_07] [bigint] NULL,
	[READMIT_CONF_30] [bigint] NULL,
	[READMIT_CONF_60] [bigint] NULL,
	[READMIT_CONF_90] [bigint] NULL,
	[PSC_CAT1_ID] [smallint] NULL,
	[PSC_CAT2_ID] [smallint] NULL,
	[ADMIT] [bit] NOT NULL,
	[PRFL_CLM] [tinyint] NULL,
	[AMT_EQV_CF] [decimal](19, 4) NULL,
	[AMT_PAY_CF] [decimal](19, 4) NULL,
	[DISREL] [smallint] NULL,
	[ACW_SRV] [tinyint] NULL,
	[LAG_DAYS] [smallint] NULL,
	[LAG_IND] [bit] NULL,
	[ICD_VERSION] [tinyint] NOT NULL,
	[NETWORK_PAID_STATUS_ID] [varchar](40) NULL,
	[PROVIDER_STATUS_ID] [varchar](40) NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[AMT_NP] [decimal](19, 2) NULL,
	[SERV_PROV_AFFIL_ID] [varchar](40) NULL,
	[AMT_NOT_COVERED] [decimal](19, 2) NULL,
	[AMT_OTHER_CARRIER_PAY] [decimal](19, 2) NULL,
	[AMT_ADMIN_FEE] [decimal](19, 2) NULL,
	[BILL_PROVIDER_ID] [varchar](20) NULL,
	[BILL_DRG_ID] [varchar](12) NULL,
	[DIAG11] [varchar](8) NULL,
	[DIAG12] [varchar](8) NULL,
	[DIAG13] [varchar](8) NULL,
	[DIAG14] [varchar](8) NULL,
	[DIAG15] [varchar](8) NULL,
	[DIAG16] [varchar](8) NULL,
	[DIAG17] [varchar](8) NULL,
	[DIAG18] [varchar](8) NULL,
	[DIAG19] [varchar](8) NULL,
	[DIAG20] [varchar](8) NULL,
	[DIAG21] [varchar](8) NULL,
	[DIAG22] [varchar](8) NULL,
	[DIAG23] [varchar](8) NULL,
	[DIAG24] [varchar](8) NULL,
	[DIAG25] [varchar](8) NULL,
	[IPROC11] [varchar](7) NULL,
	[IPROC12] [varchar](7) NULL,
	[IPROC13] [varchar](7) NULL,
	[IPROC14] [varchar](7) NULL,
	[IPROC15] [varchar](7) NULL,
	[IPROC16] [varchar](7) NULL,
	[IPROC17] [varchar](7) NULL,
	[IPROC18] [varchar](7) NULL,
	[IPROC19] [varchar](7) NULL,
	[IPROC20] [varchar](7) NULL,
	[IPROC21] [varchar](7) NULL,
	[IPROC22] [varchar](7) NULL,
	[IPROC23] [varchar](7) NULL,
	[IPROC24] [varchar](7) NULL,
	[IPROC25] [varchar](7) NULL,
	[ADMIT_SOURCE] [char](1) NULL,
	[PQI] [tinyint] NULL,
	[AVOIDABLE_ADMIT_FLAG] [tinyint] NOT NULL,
	[CUST_MED_1] [varchar](255) NULL,
	[CUST_MED_10] [varchar](255) NULL,
	[CUST_MED_11] [varchar](255) NULL,
	[CUST_MED_12] [varchar](255) NULL,
	[CUST_MED_13] [varchar](255) NULL,
	[CUST_MED_14] [varchar](255) NULL,
	[CUST_MED_15] [varchar](255) NULL,
	[CUST_MED_16] [float] NULL,
	[CUST_MED_17] [float] NULL,
	[CUST_MED_18] [float] NULL,
	[CUST_MED_19] [float] NULL,
	[CUST_MED_2] [varchar](255) NULL,
	[CUST_MED_20] [float] NULL,
	[CUST_MED_3] [varchar](255) NULL,
	[CUST_MED_4] [varchar](255) NULL,
	[CUST_MED_5] [varchar](255) NULL,
	[CUST_MED_6] [varchar](255) NULL,
	[CUST_MED_7] [varchar](255) NULL,
	[CUST_MED_8] [varchar](255) NULL,
	[CUST_MED_9] [varchar](255) NULL,
	[CUST_MED_PK_ID] [varchar](32) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CONF_AVOIDABLE](
	[CONF_NUM] [bigint] NOT NULL,
	[MEMBER] [varchar](32) NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[COUNTY_ID] [int] NOT NULL,
	[CONTRACT_ID] [varchar](40) NULL,
	[PCP_ASSIGN] [varchar](20) NOT NULL,
	[PCP_AFFIL_ID] [varchar](40) NOT NULL,
	[PCP_ASSIGN_NAME] [varchar](50) NULL,
	[PCP_IMP] [varchar](20) NOT NULL,
	[PCP_IMP_AFFIL_ID] [varchar](40) NOT NULL,
	[PCP_IMP_NAME] [varchar](50) NULL,
	[PROVIDER_ID] [varchar](20) NULL,
	[FAC_AFFIL_ID] [varchar](40) NOT NULL,
	[FAC_NAME] [varchar](50) NULL,
	[MDC] [smallint] NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[DRG_ID] [varchar](12) NULL,
	[AVOIDABLE_ADMIT_FLAG] [tinyint] NOT NULL,
	[PQI] [tinyint] NOT NULL,
	[ADMIT] [tinyint] NOT NULL,
	[LOS] [smallint] NOT NULL,
	[COST1] [decimal](19, 2) NULL,
	[COST2] [decimal](19, 2) NULL,
	[COST3] [decimal](19, 2) NULL,
	[COST4] [decimal](19, 2) NULL,
	[COST5] [decimal](19, 2) NULL,
	[COST6] [decimal](19, 2) NULL,
	[READMIT_07] [tinyint] NOT NULL,
	[READMIT_30] [tinyint] NOT NULL,
	[READMIT_60] [tinyint] NOT NULL,
	[READMIT_90] [tinyint] NOT NULL,
	[READMIT_INDEX_07] [tinyint] NOT NULL,
	[READMIT_INDEX_30] [tinyint] NOT NULL,
	[READMIT_INDEX_60] [tinyint] NOT NULL,
	[READMIT_INDEX_90] [tinyint] NOT NULL,
	[ACCOUNT_LV1_ID] [varchar](100) NULL,
	[ACCOUNT_LV2_ID] [varchar](100) NULL,
	[PRODUCT_LV1_ID] [varchar](100) NULL,
	[PRODUCT_LV2_ID] [varchar](100) NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CM_DISPREV_MEM](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[ACT_LAST] [bit] NULL,
	[RRISK_CAT] [tinyint] NULL,
	[PRISK_CAT] [tinyint] NULL,
	[PTL_YR_ENR] [bit] NOT NULL,
	[TOT_MM] [decimal](19, 2) NOT NULL,
	[MEMS] [int] NOT NULL,
	[WRRISK] [decimal](10, 4) NULL,
	[PRISK] [decimal](10, 4) NULL,
	[ARISK] [decimal](10, 4) NULL,
	[DIS_0001] [tinyint] NOT NULL,
	[DIS_0002] [tinyint] NOT NULL,
	[DIS_0003] [tinyint] NOT NULL,
	[DIS_0004] [tinyint] NOT NULL,
	[DIS_0005] [tinyint] NOT NULL,
	[DIS_0006] [tinyint] NOT NULL,
	[DIS_0007] [tinyint] NOT NULL,
	[DIS_0008] [tinyint] NOT NULL,
	[DIS_0009] [tinyint] NOT NULL,
	[DIS_0010] [tinyint] NOT NULL,
	[DIS_0011] [tinyint] NOT NULL,
	[DIS_0012] [tinyint] NOT NULL,
	[DIS_0013] [tinyint] NOT NULL,
	[DIS_0014] [tinyint] NOT NULL,
	[DIS_0015] [tinyint] NOT NULL,
	[DIS_0016] [tinyint] NOT NULL,
	[DIS_0017] [tinyint] NOT NULL,
	[DIS_0018] [tinyint] NOT NULL,
	[DIS_0020] [tinyint] NOT NULL,
	[DIS_0022] [tinyint] NOT NULL,
	[DIS_0023] [tinyint] NOT NULL,
	[DIS_0026] [tinyint] NOT NULL,
	[DIS_0029] [tinyint] NOT NULL,
	[DIS_0030] [tinyint] NOT NULL,
	[DIS_0031] [tinyint] NOT NULL,
	[DIS_0032] [tinyint] NOT NULL,
	[DIS_0033] [tinyint] NOT NULL,
	[DIS_0034] [tinyint] NOT NULL,
	[DIS_0035] [tinyint] NOT NULL,
	[DIS_0036] [tinyint] NOT NULL,
	[DIS_0037] [tinyint] NOT NULL,
	[DIS_0038] [tinyint] NOT NULL,
	[DIS_0040] [tinyint] NOT NULL,
	[DIS_0041] [tinyint] NOT NULL,
	[DIS_0042] [tinyint] NOT NULL,
	[DIS_0043] [tinyint] NOT NULL,
	[DIS_0047] [tinyint] NOT NULL,
	[DIS_0048] [tinyint] NOT NULL,
	[DIS_0050] [tinyint] NOT NULL,
	[DIS_0051] [tinyint] NOT NULL,
	[DIS_0052] [tinyint] NOT NULL,
	[DIS_0053] [tinyint] NOT NULL,
	[DIS_0054] [tinyint] NOT NULL,
	[DIS_0055] [tinyint] NOT NULL,
	[DIS_0056] [tinyint] NOT NULL,
	[DIS_0057] [tinyint] NOT NULL,
	[DIS_0058] [tinyint] NOT NULL,
	[DIS_0059] [tinyint] NOT NULL,
	[DIS_0060] [tinyint] NOT NULL,
	[DIS_0061] [tinyint] NOT NULL,
	[DIS_0065] [tinyint] NOT NULL,
	[DIS_0066] [tinyint] NOT NULL,
	[DIS_0067] [tinyint] NOT NULL,
	[DIS_0068] [tinyint] NOT NULL,
	[DIS_0069] [tinyint] NOT NULL,
	[DIS_0070] [tinyint] NOT NULL,
	[DIS_0200] [tinyint] NOT NULL,
	[DIS_0201] [tinyint] NOT NULL,
	[DIS_0202] [tinyint] NOT NULL,
	[DIS_0203] [tinyint] NOT NULL,
	[DISEASE$] [varchar](250) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CM_DISPREV_COSTS](
	[MEM_ATTR_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[PCP_ASSIGN] [varchar](20) NULL,
	[PCP_IMP] [varchar](20) NULL,
	[ACT_LAST] [bit] NULL,
	[RRISK_CAT] [tinyint] NULL,
	[PRISK_CAT] [tinyint] NULL,
	[PTL_YR_ENR] [bit] NOT NULL,
	[ACW_ID] [tinyint] NOT NULL,
	[DISREL] [smallint] NULL,
	[TOS1_ID] [smallint] NOT NULL,
	[TOS2_ID] [smallint] NOT NULL,
	[NETWORK_STATUS] [bit] NULL,
	[COST1] [decimal](19, 2) NOT NULL,
	[COST2] [decimal](19, 2) NOT NULL,
	[COST3] [decimal](19, 2) NOT NULL,
	[COST4] [decimal](19, 2) NOT NULL,
	[COST5] [decimal](19, 2) NOT NULL,
	[COST6] [decimal](19, 2) NOT NULL,
	[ENCOUNTER] [decimal](19, 2) NOT NULL,
	[LOS] [int] NOT NULL,
	[ADMIT] [int] NOT NULL,
	[DIS_0001] [tinyint] NOT NULL,
	[DIS_0002] [tinyint] NOT NULL,
	[DIS_0003] [tinyint] NOT NULL,
	[DIS_0004] [tinyint] NOT NULL,
	[DIS_0005] [tinyint] NOT NULL,
	[DIS_0006] [tinyint] NOT NULL,
	[DIS_0007] [tinyint] NOT NULL,
	[DIS_0008] [tinyint] NOT NULL,
	[DIS_0009] [tinyint] NOT NULL,
	[DIS_0010] [tinyint] NOT NULL,
	[DIS_0011] [tinyint] NOT NULL,
	[DIS_0012] [tinyint] NOT NULL,
	[DIS_0013] [tinyint] NOT NULL,
	[DIS_0014] [tinyint] NOT NULL,
	[DIS_0015] [tinyint] NOT NULL,
	[DIS_0016] [tinyint] NOT NULL,
	[DIS_0017] [tinyint] NOT NULL,
	[DIS_0018] [tinyint] NOT NULL,
	[DIS_0020] [tinyint] NOT NULL,
	[DIS_0022] [tinyint] NOT NULL,
	[DIS_0023] [tinyint] NOT NULL,
	[DIS_0026] [tinyint] NOT NULL,
	[DIS_0029] [tinyint] NOT NULL,
	[DIS_0030] [tinyint] NOT NULL,
	[DIS_0031] [tinyint] NOT NULL,
	[DIS_0032] [tinyint] NOT NULL,
	[DIS_0033] [tinyint] NOT NULL,
	[DIS_0034] [tinyint] NOT NULL,
	[DIS_0035] [tinyint] NOT NULL,
	[DIS_0036] [tinyint] NOT NULL,
	[DIS_0037] [tinyint] NOT NULL,
	[DIS_0038] [tinyint] NOT NULL,
	[DIS_0040] [tinyint] NOT NULL,
	[DIS_0041] [tinyint] NOT NULL,
	[DIS_0042] [tinyint] NOT NULL,
	[DIS_0043] [tinyint] NOT NULL,
	[DIS_0047] [tinyint] NOT NULL,
	[DIS_0048] [tinyint] NOT NULL,
	[DIS_0050] [tinyint] NOT NULL,
	[DIS_0051] [tinyint] NOT NULL,
	[DIS_0052] [tinyint] NOT NULL,
	[DIS_0053] [tinyint] NOT NULL,
	[DIS_0054] [tinyint] NOT NULL,
	[DIS_0055] [tinyint] NOT NULL,
	[DIS_0056] [tinyint] NOT NULL,
	[DIS_0057] [tinyint] NOT NULL,
	[DIS_0058] [tinyint] NOT NULL,
	[DIS_0059] [tinyint] NOT NULL,
	[DIS_0060] [tinyint] NOT NULL,
	[DIS_0061] [tinyint] NOT NULL,
	[DIS_0065] [tinyint] NOT NULL,
	[DIS_0066] [tinyint] NOT NULL,
	[DIS_0067] [tinyint] NOT NULL,
	[DIS_0068] [tinyint] NOT NULL,
	[DIS_0069] [tinyint] NOT NULL,
	[DIS_0070] [tinyint] NOT NULL,
	[DIS_0200] [tinyint] NOT NULL,
	[DIS_0201] [tinyint] NOT NULL,
	[DIS_0202] [tinyint] NOT NULL,
	[DIS_0203] [tinyint] NOT NULL,
	[DISEASE$] [varchar](250) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CLINMARK](
	[MEMBER] [varchar](32) NOT NULL,
	[RULE_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[MIN_DT] [smalldatetime] NULL,
	[MAX_DT] [smalldatetime] NULL,
	[OCCURRENCES] [smallint] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ADM_DET_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[DRG_UNIT_ID] [varchar](12) NOT NULL,
	[DRG_ID] [varchar](12) NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[COUNTY_M] [int] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[RRISK_ADM_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_07_ACT_TOT] [int] NOT NULL,
	[READMIT_30_ACT_TOT] [int] NOT NULL,
	[READMIT_60_ACT_TOT] [int] NOT NULL,
	[READMIT_90_ACT_TOT] [int] NOT NULL,
	[DRG_OUTLIER_COST] [tinyint] NOT NULL,
	[DRG_OUTLIER_LOS] [tinyint] NOT NULL,
	[FAC_QTY_ELIG_PEER] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ADM_COSTS_ADMLEVEL](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[DRG_ID] [varchar](12) NOT NULL,
	[DRG_UNIT_ID] [varchar](12) NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[CONF_NUM] [bigint] NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_07_ACT_TOT] [int] NOT NULL,
	[READMIT_30_ACT_TOT] [int] NOT NULL,
	[READMIT_60_ACT_TOT] [int] NOT NULL,
	[READMIT_90_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_07_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_30_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_60_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_90_ACT_TOT] [int] NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_07_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_30_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_60_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_90_PEER_TOT] [decimal](28, 6) NOT NULL,
	[FAC_QTY_ELIG_PEER] [int] NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ADM_COSTS](
	[PEER_DEF_ID] [int] NOT NULL,
	[IA_TIME] [tinyint] NOT NULL,
	[IA_TIME_ADJ] [tinyint] NULL,
	[DRG_UNIT_ID] [varchar](12) NOT NULL,
	[DRG_ID] [varchar](12) NOT NULL,
	[DRG_ADMITTYP] [varchar](3) NULL,
	[PROVIDER_ID] [varchar](20) NOT NULL,
	[YEAR_MTH_ID] [tinyint] NOT NULL,
	[PRODUCT_ID] [varchar](40) NOT NULL,
	[COUNTY_M] [int] NOT NULL,
	[AGE_CAT2] [tinyint] NOT NULL,
	[SEX] [bit] NOT NULL,
	[CAT_MEMBER] [tinyint] NOT NULL,
	[ACCOUNT_ID] [varchar](40) NOT NULL,
	[RRISK_ADM_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST2_ACT_TOT] [decimal](28, 6) NOT NULL,
	[COST3_ACT_TOT] [decimal](28, 6) NOT NULL,
	[ADMIT_ACT_TOT] [int] NOT NULL,
	[DAYS_ACT_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_07_ACT_TOT] [int] NOT NULL,
	[READMIT_30_ACT_TOT] [int] NOT NULL,
	[READMIT_60_ACT_TOT] [int] NOT NULL,
	[READMIT_90_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_07_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_30_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_60_ACT_TOT] [int] NOT NULL,
	[READMIT_INDEX_90_ACT_TOT] [int] NOT NULL,
	[RRISK_ADM_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST2_PEER_TOT] [decimal](28, 6) NOT NULL,
	[COST3_PEER_TOT] [decimal](28, 6) NOT NULL,
	[DAYS_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_07_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_30_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_60_PEER_TOT] [decimal](28, 6) NOT NULL,
	[READMIT_90_PEER_TOT] [decimal](28, 6) NOT NULL,
	[MEM_USERDEF_1_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_2_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_3_ID] [varchar](40) NOT NULL,
	[MEM_USERDEF_4_ID] [varchar](40) NOT NULL
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((1)) FOR [ENCOUNTER]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ('C') FOR [CLM_TYPE]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [EXCLUDE]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [READMIT_INDEX_07]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [READMIT_INDEX_30]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [READMIT_INDEX_60]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [READMIT_INDEX_90]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [READMIT_07]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [READMIT_30]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [READMIT_60]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [READMIT_90]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((1)) FOR [ADMIT]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [PRFL_CLM]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [LAG_IND]
GO
ALTER TABLE [dbo].[CONFINEMENTS] ADD  DEFAULT ((0)) FOR [AVOIDABLE_ADMIT_FLAG]
GO
ALTER TABLE [dbo].[EBM_RESULTS] ADD  DEFAULT ((0)) FOR [EXT_FLAG]
GO
ALTER TABLE [dbo].[EPISODES] ADD  DEFAULT ((0)) FOR [OUTLIER]
GO
ALTER TABLE [dbo].[IA_TIMES] ADD  DEFAULT ((0)) FOR [PTL_YR_ENR]
GO
ALTER TABLE [dbo].[IA_TIMES] ADD  DEFAULT ((0)) FOR [AGE]
GO
ALTER TABLE [dbo].[IA_TIMES] ADD  DEFAULT ((0)) FOR [CAT_STATUS]
GO
ALTER TABLE [dbo].[IA_TIMES] ADD  DEFAULT ((0)) FOR [CAT_STATUS_COST3]
GO
ALTER TABLE [dbo].[IA_TIMES] ADD  DEFAULT ((0)) FOR [CAT_RATIO]
GO
ALTER TABLE [dbo].[IA_TIMES] ADD  DEFAULT ((0)) FOR [ACT_LAST]
GO
ALTER TABLE [dbo].[IA_TIMES] ADD  DEFAULT ((0)) FOR [PRFL_MEM]
GO
ALTER TABLE [dbo].[LAB] ADD  DEFAULT ('L') FOR [CLM_TYPE]
GO
ALTER TABLE [dbo].[MAP_AT_RISK_STATUS] ADD  DEFAULT ((0)) FOR [RISK_STATUS]
GO
ALTER TABLE [dbo].[MAP_DCC] ADD  DEFAULT ((0)) FOR [TOS_I_5]
GO
ALTER TABLE [dbo].[MAP_DENIED_IND] ADD  DEFAULT ((0)) FOR [DENIED_STATUS]
GO
ALTER TABLE [dbo].[MAP_EBM_CASES] ADD  DEFAULT ((0)) FOR [ENABLED]
GO
ALTER TABLE [dbo].[MAP_EBM_CASES] ADD  DEFAULT ((0)) FOR [EXT_FLAG]
GO
ALTER TABLE [dbo].[MAP_EBM_RULES] ADD  DEFAULT ((0)) FOR [ENABLED]
GO
ALTER TABLE [dbo].[MAP_EBM_RULES] ADD  DEFAULT ((0)) FOR [EXT_FLAG]
GO
ALTER TABLE [dbo].[MAP_EMPLOYEE_TYPE] ADD  DEFAULT ((0)) FOR [EMPLOYEE_STATUS]
GO
ALTER TABLE [dbo].[MAP_ETG] ADD  DEFAULT ((0)) FOR [MPC]
GO
ALTER TABLE [dbo].[MAP_NETWORK_PAID_STATUS] ADD  DEFAULT ((0)) FOR [NETWORK_STATUS]
GO
ALTER TABLE [dbo].[MAP_PEER] ADD  DEFAULT ((0)) FOR [ELIG_MMOS]
GO
ALTER TABLE [dbo].[MAP_PEER] ADD  DEFAULT ((0)) FOR [ELIG_MEMS]
GO
ALTER TABLE [dbo].[MAP_PEER] ADD  DEFAULT ((0)) FOR [ELIG_EPI_QTY]
GO
ALTER TABLE [dbo].[MAP_PEER] ADD  DEFAULT ((0)) FOR [ELIG_EPI_QTY_PEG]
GO
ALTER TABLE [dbo].[MEM_ATTR_MEMBER_CONTRACT] ADD  DEFAULT ((0)) FOR [PRIMARY_PAYER_IND]
GO
ALTER TABLE [dbo].[SERVICES_INP] ADD  DEFAULT ('I') FOR [CLM_TYPE]
GO
ALTER TABLE [dbo].[SERVICES_INP] ADD  DEFAULT ((0)) FOR [EXCLUDE]
GO
ALTER TABLE [dbo].[SERVICES_INP] ADD  DEFAULT ((0)) FOR [CAP_FLAG]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [ENCOUNTER]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ('M') FOR [CLM_TYPE]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [EXCLUDE]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [COV_ORDER]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [ER_FLAG]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [ER_CONF]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [RAD_FLAG]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [LAB_FLAG]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [RAD_UTIL]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [LAB_UTIL]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [MRI_UTIL]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [ER_UTIL]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [EM_SVC_FLAG]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [PCP_VIS_FLAG]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [REF_VIS_FLAG]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [REF_FLAG]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [PRFL_CLM]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [LAG_IND]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [ENC_K]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [PCP_VIS_FLAG_K]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [REF_VIS_FLAG_K]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [REF_FLAG_K]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [LAB_UTIL_K]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [RAD_UTIL_K]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [MRI_UTIL_K]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [ER_UTIL_K]
GO
ALTER TABLE [dbo].[SERVICES_MED] ADD  DEFAULT ((0)) FOR [CAP_FLAG]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((9)) FOR [GBO]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [AMT_WTH]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [NETWORK_STATUS]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ('P') FOR [CLM_TYPE]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [EXCLUDE]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [SCRIPT]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [GENERIC]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [SCRIPT_GEN]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [PRFL_CLM]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [LAG_IND]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [AMT_WTH_K]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [AMT_COB_K]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [ENC_K]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [SCRIPT_K]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [GENERIC_K]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [SCRIPT_GEN_K]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((9)) FOR [DAW]
GO
ALTER TABLE [dbo].[SERVICES_RX] ADD  DEFAULT ((0)) FOR [CAP_FLAG]
GO

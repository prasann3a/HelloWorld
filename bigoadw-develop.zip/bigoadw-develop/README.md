# BIG OADW
Project containing all modules required to generate builds of OADW using Apache Spark and Hadoop.

## Setup
Refer [Setup-wiki](https://github.optum.com/OptumAnalyticsDataWarehouse/bigoadw/wiki/Setup-guide) to setup in local

## Dev Deployment
You can deploy this after building locally using the ./scripts/deploy.sh bash script. 

Pass in `-u <humedica username>` and optionally `--package` to send all artifacts required to run the stack short of orchestration
`--package` runs `mvn clean install -DskipTests=true` before it sends the built content to the edgenode.

This writes all generated resources to `/opt/bigoadw/<humedica username>/dev-<oadw-version>-release/`.
From there you can execute any task on the stack by running the task's bash-wrapper with parameters.

If you provide parameter `-o`, file system orchestration will be added to your deployment. 
With this parameter another parameter becomes required: `--oraclePass <oracle password encrypted>`
If you don't plan to run any oracle schema creation in your test, you can pass whatever you want to `--oraclePass` parameter, 
but if you need to test an oracle export, you'll have to use the official password of OADW_USER_MANAGER_SVC on racload03
Ask someone on microsoft-teams in the team for it if you don't have it.

In general, you can generate the encrypted password by running a particular test in the OADW codebase called "MakePasswordTest", 
and replacing the password it converts in its test with what you want to encrypt. It will show up in stdout during test execution.

## Run Task on Deployed Stack
Use the `scripts/public_interface/cdr_interface.py` file in --dryrun mode to produce a JSON file for the run

ex: `python3 scripts/public_interface/cdr_interface.py --schema cdr_dev_5 --release 201903 --environment stg --level cdr_be --instance 1 --clientId H303173 --isCurrent false --streamId <username> --dryrun`

The optional parameter `--streamId <username>` (preferred convention: [env]_[initials]_[small description about run] ex: dev_xx_TestRun) enables parallel execution of dev builds (by avoiding any overwrites) while sourcing the same datasets.

If you are running without orchestration, parse out the parameters from the step in the JSON you want to run and piece together the command as needed for your test.

With orchestration enabeld, just copy the generated JSON to /opt/bigoadw/<humedicaUser>/dev-<pom version>-release/watch_path and your orchestration environment should pick it up for running.  

*NOTE - DON'T FORGET TO KILL YOUR TESTING ORCHESTRATION STACK WHEN THE TEST IS COMPLETE. BE MINDFUL OF MEMORY ON EDGENODE!*
You can get the PID for your orch stack by `cat orchestration.pid` from your deployment dir, and then `kill <pid #>`. 
Confirm presence and death of your stack with `ps -ef | grep orchestration | grep ^<humedicaUser>`

# SchemaDeprecator:
Wiki: https://wiki.advisory.com/display/DATAPIPE/OADW+SchemaDeprecator
Note:
We should be mindful about making necessary changes in SchemaDeprecator whenever a new flow is introduced.
Eg: Referring a table or view in a new file added to the project.

# References:
1) [New-OADW-Developer-Handbook](https://wiki.advisory.com/display/ABCOI/New+OADW+developer+handbook)
package com.optum.oadw.schema.validate.lib

import java.util.concurrent.Executors

import com.optum.oap.jdbc.OracleDriver
import com.optum.oap.sparklib.SparkUtils.{createSparkSession, getAppName}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.slf4j.LoggerFactory
import com.optum.oap.utils.Resource.using

import scala.collection.mutable
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, ExecutionContext, Future}

object ETLValidator {

  private val logger = LoggerFactory.getLogger(this.getClass)

  def validate(input: ETLValidatorInput): Unit = {
    import input._

    implicit val executionContext: scala.concurrent.ExecutionContextExecutorService =
      ExecutionContext.fromExecutorService(Executors.newFixedThreadPool(10))

    using(createSparkSession(getAppName(s"OADW-SparkETL-Validator-$dbName"), false, logWarnings = true))(session => {
      import session.implicits._
      val tablesToTest = if (allTablesInHiveSchema) {
        val tables = session.sql(s"show tables in $hiveSchema").as[HiveTables].collect().toList
        tables.map(_.tableName).toList
      } else {
        tables.getOrElse("").split(",").filter(!_.isEmpty).toList
      }
      val result = Future.traverse(tablesToTest) {
        table => Future {
          try {
            session.sparkContext.setJobDescription(s"Processing table $table")

            if (countOnly) {
              // get count from Oracle
              val jdbcConnection = jdbcAdapter.getConnection
              val oracleQuery = String.format(jdbcAdapter.SELECT_COUNT_QUERY, oracleSchema, table)
              val oracleCount = jdbcAdapter.doInsideConnection(oracleQuery, jdbcConnection, resultSet => {
                val tables = mutable.Set[String]()
                while (resultSet.next()) {
                  tables.add(resultSet.getString("TOTAL"))
                }
                tables.head
              })

              val hiveCount = if (table.startsWith("TEMP")) {
                session.read.parquet(s"$baseHdfsPath/${table.toUpperCase}").count()
              } else {
                session.sql(s"Select cast(count(*) as BigInt) as total From $hiveSchema.$table").as[HiveCount].collect().head.total.toLong
              }
              if (oracleCount.toLong != hiveCount) {
                logger.warn(s"Table: $table. Oracle count: $oracleCount vs Hive count: $hiveCount")
              }
            }


            if(schemaOnly) {
              val tableTypeInfo = session.sql(s"describe formatted $hiveSchema.$table").as[HiveDescribe].collect().toList
              val tableType = tableTypeInfo.toList.exists(x => x.data_type.equalsIgnoreCase("EXTERNAL"))
              logger.warn(s"Is $table external $tableType")
              if (tableType) {
                // Compare schema
                val location = tableTypeInfo.find(x => x.col_name.equalsIgnoreCase("Location")).get
                val schemaHive = session.sql(s"describe $hiveSchema.$table").as[Schema].collect().toList
                val schemaParquet = session.read.parquet(location.data_type).schema.toList.map(x => Schema(x.name, x.dataType.simpleString, ""))
                val availableInParquet = schemaParquet.filter(x => !schemaHive.exists(p => p.col_name.equalsIgnoreCase(x.col_name) && p.data_type.equalsIgnoreCase(x.data_type)))
                val availableInHive = schemaHive.filter(x => !schemaParquet.exists(p => p.col_name.equalsIgnoreCase(x.col_name) && p.data_type.equalsIgnoreCase(x.data_type)))
                val resultFromParquet = availableInParquet.map(x => (x.col_name, x.data_type, schemaHive.find(p => p.col_name.equalsIgnoreCase(x.col_name)).map(_.data_type).getOrElse(""))).map(v => s"$table\t\t${v._1}\t\t${v._2}\t\t${v._3}").mkString("\n")
                val resultFromHive = availableInHive.map(x => (x.col_name, x.data_type, schemaParquet.find(p => p.col_name.equalsIgnoreCase(x.col_name)).map(_.data_type).getOrElse(""))).map(v => s"$table\t\t${v._1}\t\t${v._2}\t\t${v._3}").mkString("\n")

                if (!resultFromParquet.isEmpty) {
                  logger.warn(s"\nTable\t\tParquet column\t\tParquet datatype\t\tHive datatype\n$resultFromParquet")
                }
                if (!resultFromHive.isEmpty) {
                  logger.warn(s"\nTable\t\tHive column\t\tHive datatype\t\tParquet datatype\n$resultFromHive")
                }
              }

              // issue select * from schema.table limit 1
              logger.warn(s"Issuing select against $table")
              session.sql(s"Select * From $hiveSchema.$table limit 1").show(false)
            }
          }
          catch {
            case ex: Exception => {
              logger.warn(s"Unable to process $table")
              println(ex)
            }
          }
        }
      }

      Await.result(result, Duration.Inf)
    })
  }

  def pathExists(fullPath: String, config: Configuration = new Configuration()): Boolean = {
    val path = new Path(fullPath)
    val fs = path.getFileSystem(config)
    fs.exists(path)
  }
}

case class ETLValidatorInput(jdbcHost: String,
                             jdbcUser: String,
                             jdbcPassword: String,
                             dbName: String,
                             oracleSchema: String,
                             hiveSchema: String,
                             tables: Option[String] = None,
                             baseHdfsPath: String,
                             countOnly: Boolean = false,
                             schemaOnly: Boolean = false,
                             allTablesInHiveSchema: Boolean = false) {

  implicit val executionContext = ExecutionContext.fromExecutorService(Executors.newFixedThreadPool(2))
  val jdbcAdapter = new OracleDriver(jdbcHost, dbName, jdbcUser, jdbcPassword)
}

case class HiveCount(total: BigInt)
case class Schema(col_name: String, data_type: String, comment: String)
case class HiveDescribe(col_name: String, data_type: String, comment: String)
case class HiveTables(database: String, tableName: String, isTemporary: Boolean)
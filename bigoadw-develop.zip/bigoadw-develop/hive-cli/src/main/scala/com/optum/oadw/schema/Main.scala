package com.optum.oadw.schema

import com.optum.oadw.schema.deploy.lib.OADWSchemaDeployer
import com.optum.oadw.schema.validate.lib.{ETLValidator, ETLValidatorInput}
import com.optum.oadw.utils.{OADWSchemaInput, VersionManager}
import com.optum.oap.constants.II
import com.optum.oap.sparklib.SparkUtils
import com.optum.oap.utils.Resource.using
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.SparkSession
import org.rogach.scallop.{ScallopConf, ScallopOption, Subcommand}

import java.io.IOException

class Conf(arguments: Seq[String]) extends ScallopConf(arguments) {
  val validate = new Subcommand("validate") {
    val userName: ScallopOption[String] = opt[String](required = true, name = "userName", argName = "userName", descr = "hadoop-mercury or individual's racload03 credentials")
    val password: ScallopOption[String] = opt[String](
      required = false,
      name = "password",
      argName = "password",
      descr =
        "Password & PasswordFile options are mutually exclusive. When using individual racload03 username then use --password option. But if you are using common hadoop_mercury username then use --passwordFile option."
    )
    val passwordFile: ScallopOption[String] = opt[String](
      required = false,
      name = "passwordFile",
      argName = "passwordFile",
      descr = "Hdfs path of the password file e.g. hdfs://somhorton1/optum/mercury/mercury_hadoop.oracle. Use this option when using hadoop-mercury user for connecting CDR/OADW schema."
    )
    val jdbcHost: ScallopOption[String]     = opt[String](required = true, name = "jdbcHost", argName = "jdbcHost", descr = "racload03 host e.g. som-racload03.humedica.net")
    val dbName: ScallopOption[String]       = opt[String](required = true, name = "dbName", argName = "dbName", descr = "Database name. sid in case of Oracle e.g. engr")
    val oracleSchema: ScallopOption[String] = opt[String](required = true, name = "oracleSchema", argName = "oracleSchema", descr = "Oracle schema e.g. GME_DID3_CDR_TRAINING_H704847")
    val hiveSchema: ScallopOption[String]   = opt[String](required = true, name = "hiveSchema", argName = "hiveSchema", descr = "Oracle schema e.g. pawan_hive")
    val tables: ScallopOption[String]       = opt[String](required = false, name = "tables", argName = "tables", descr = "List of table to validate")
    val baseHdfsPath: ScallopOption[String] = opt[String](
      required = true,
      name = "baseHdfsPath",
      argName = "baseHdfsPath",
      descr = "base hdfs path e.g. hdfs://somhorton1/optum-dev/oadw/scratch_workspace/pmishra/outputDir/outputDir"
    )
    val countOnly: ScallopOption[Boolean]  = opt[Boolean](required = false, name = "countOnly", argName = "countOnly", descr = "Compare oracle vs hive count")
    val schemaOnly: ScallopOption[Boolean] = opt[Boolean](required = false, name = "schemaOnly", argName = "schemaOnly", descr = "Compare hive vs parquet schema")
    val allTablesInHiveSchema: ScallopOption[Boolean] =
      opt[Boolean](required = false, name = "allTablesInHiveSchema", argName = "allTablesInHiveSchema", descr = "Run comparison against all tables in provided hive schema")
  }

  val deploy = new Subcommand("deploy") {
    val protocol: ScallopOption[String]       = opt[String](required = true, name = "protocol", argName = "protocol", descr = "s3 or hdfs")
    val hostOrBucket: ScallopOption[String]   = opt[String](required = true, name = "hostOrBucket", argName = "hostOrBucket", descr = "somhorton1 or bucket name")
    val refBucket: ScallopOption[String]      = opt[String](required = false, name = "refBucket", argName = "refBucket", descr = "ref bucket name")
    val clientId: ScallopOption[String]       = opt[String](required = true, name = "clientId", argName = "clientId", descr = "Client Id")
    val env: ScallopOption[String]            = opt[String](required = false, name = "env", argName = "env", descr = "Environment: prd|stg|dev")
    val dryRun: ScallopOption[Boolean]        = opt[Boolean](required = false, name = "dryRun", argName = "dryRun", descr = "Write converted script into temporary file")
    val updateCurrent: ScallopOption[Boolean] = opt[Boolean](required = false, name = "updateCurrent", argName = "updateCurrent", descr = "When present, updates the non-instanced hive dbs")
    val iiDateStamp: ScallopOption[String]    = opt[String](required = false, name = "iiDateStamp", argName = "iiDateStamp", descr = "II datestamp (optiona). Format is yyyyMMdd")
    val iiProcessId: ScallopOption[String]    = opt[String](required = false, name = "iiProcessId", argName = "iiProcessId", descr = "II process id (optional)")
    val instance: ScallopOption[String] = opt[String](
      required = true,
      name = "instance",
      argName = "instance",
      descr = "Instance identifier string for parquet path and hive table names; should match eCDR daily identifier"
    )
    val streamId: ScallopOption[String] = opt[String](required = false, name = "streamId", argName = "streamId", descr = "Stream identifier string for parquet path and hive table names;")
    val cdrCycle: ScallopOption[String] = opt[String](required = true, name = "cdrCycle", argName = "cdrCycle", descr = "subdir containing the daily or monthly CDR drops (e.g. CDR_DELTA_201901)")
    val cdrLevel: ScallopOption[String] = opt[String](required = true, name = "cdrLevel", argName = "cdrLevel", descr = "Possible values: 'cdr_be' or 'ecdr'")
    val oadwRefVersion: ScallopOption[String] = opt[String](
      required = false,
      default = Option(VersionManager.RefVersion),
      name = "oadwRefVersion",
      argName = "oadwRefVersion",
      descr = "Oadw Reference version override for parquet location"
    )
  }
  addSubcommand(validate)
  addSubcommand(deploy)
  verify()
}

object Main {

  private val S3              = "s3"
  private val HDFS            = "hdfs"
  private val VALID_PROTOCOLS = Seq(S3, HDFS)

  def parseArgsAndDeploy(args: Array[String], sparkSession: SparkSession): Unit ={
    val conf = new Conf(args)
    conf.subcommand match {
      case Some(conf.validate) =>
        val passwordFile = conf.validate.passwordFile.toOption
        val passwordText = conf.validate.password.toOption
        val password = if (passwordText.isDefined) {
          passwordText.get
        } else {
          loadPassword(passwordFile.get)
        }
        val input = ETLValidatorInput(
          conf.validate.jdbcHost(),
          conf.validate.userName(),
          password,
          conf.validate.dbName(),
          conf.validate.oracleSchema(),
          conf.validate.hiveSchema(),
          conf.validate.tables.toOption,
          conf.validate.baseHdfsPath(),
          conf.validate.countOnly.toOption.getOrElse(false),
          conf.validate.schemaOnly.toOption.getOrElse(false),
          conf.validate.allTablesInHiveSchema.toOption.getOrElse(false)
        )
        ETLValidator.validate(input)
      case Some(conf.deploy) =>
        if (!VALID_PROTOCOLS.contains(conf.deploy.protocol())) {
          throw new IllegalArgumentException(s"${conf.deploy.protocol()} is not a valid protocol. Valid protocols are ${VALID_PROTOCOLS.mkString(", ")}")
        }
        if (conf.deploy.protocol() == "s3" && conf.deploy.refBucket.isEmpty){
          throw new IllegalArgumentException(s"ref bucket needs to be defined with 's3' protocol")
        }
        val schemaInput = OADWSchemaInput(
          clientId = conf.deploy.clientId(),
          environment = conf.deploy.env(),
          instance = conf.deploy.instance(),
          streamId = conf.deploy.streamId.toOption.getOrElse("default"),
          cdrCycle = conf.deploy.cdrCycle(),
          cdrLevel = conf.deploy.cdrLevel(),
          dryRun = conf.deploy.dryRun(),
          updateCurrent = conf.deploy.updateCurrent(),
          iiDateStamp = conf.deploy.iiDateStamp.toOption.getOrElse(II.DEFAULT_DATESTAMP),
          iiProcessId = conf.deploy.iiProcessId.toOption.getOrElse(II.DEFAULT_PROCESSID),
          oadwRefVersion = conf.deploy.oadwRefVersion.toOption.getOrElse(VersionManager.RefVersion),
          protocol = conf.deploy.protocol(),
          bucket = conf.deploy.hostOrBucket.getOrElse(""),
          refBucket = conf.deploy.refBucket.getOrElse("")
        )
        new OADWSchemaDeployer(schemaInput).deploy(sparkSession)
      case _ => println("Invalid command!!")
    }
  }

  def main(args: Array[String]): Unit = {
    lazy val sparkSession: SparkSession = SparkUtils.createSparkSession("OADW-schema-deployment", verboseLogging = false, logWarnings = true)
    parseArgsAndDeploy(args,sparkSession)

  }

  def loadPassword(passwordFilePath: String, config: Configuration = new Configuration()): String = {
    val path = new Path(passwordFilePath)
    val fs   = path.getFileSystem(config)
    if (!fs.exists(path))
      throw new IOException("The provided password file " + path + " does not exists!")

    using(fs.open(path))(inputStream => {
      val byteArray = scala.io.Source.fromInputStream(inputStream).map(_.toByte).toArray
      byteArray.map(_.toChar).mkString
    })
  }
}

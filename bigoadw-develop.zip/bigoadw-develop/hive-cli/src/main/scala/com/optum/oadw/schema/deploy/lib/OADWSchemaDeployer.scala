package com.optum.oadw.schema.deploy.lib

import com.optum.oadw.constants.OADWSchema
import com.optum.oadw.utils.OADWSchemaInput
import com.optum.oap.schema.deploy.lib.SchemaDeployer
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

class OADWSchemaDeployer(input: OADWSchemaInput) extends SchemaDeployer {
  import input._

  private val log =  LoggerFactory.getLogger(this.getClass)
  private val dropOADWDDb = "DROP DATABASE IF EXISTS {{db_name}} CASCADE"
  val createDb = "CREATE DATABASE IF NOT EXISTS {{db_name}} LOCATION '{{basePath}}/{{env}}/oadw/{{cdr_cycle}}/{{instance}}/{{stream_id}}/do_not_modify/'"


  override protected def getDatabases: Seq[String] = Seq(getOadwDbName)

  // Executes the statement return same statement if it fails otherwise it returns empty
  def runQuery(session: SparkSession, statement: String, throwException: Boolean = false): String = {
    val trimmedStmt = statement.split("(?i)\\s+as\\s+")(0)
    try{
      session.sql(statement)
      log.warn(s"Finished Running: $trimmedStmt")
      ""
    } catch {
      case e: Exception =>
        log.warn(s"Failed $trimmedStmt, ${e.getMessage}")
        if(throwException){
          throw e
        }
        statement
    }
  }

  def runQueries(statements: List[String], session: SparkSession): List[String] = {
    statements.map(stmt=>{
      runQuery(session, stmt)
    }).filter(_.nonEmpty)
  }

  def runPatternFilteredQueries(statements: String, session: SparkSession): Unit = {
    val filteredStatements = getTableViewStatements(statements)
    var failedStatements = runQueries(filteredStatements, session)
    for(retryCount <- 1 to 350){
      // Sleep for 1 minute on every retry
      // If the OADW ETL is writing to parquet, it blocks hive to create a table or view depended on that parquet location
      // This should solve the issue with long running ETLs.
      // This is edge case, happens rarely
      if(failedStatements.nonEmpty){
        log.warn(s"============== Retrying failed statements for $retryCount times ================")
        if (retryCount< 50){
          Thread.sleep(2000)
        } else {
          Thread.sleep(60000)
        }
        failedStatements = runQueries(failedStatements, session)
      }
    }
  }

  private def getTableViewStatements(statements: String): List[String] = {
    val tablePattern = "(?i)create\\s+external\\s+table"
    val viewPattern = "(?i)create\\s+view"
    val finalStatements = input.replace(statements)
    val filteredStatements = finalStatements.split(";").map(_.trim).filter(x => {
      val tableMatchItem = tablePattern.r.findFirstMatchIn(x).getOrElse("")
      val viewMatchItem = viewPattern.r.findFirstMatchIn(x).getOrElse("")
      tableMatchItem.toString != "" || viewMatchItem.toString != ""
    })
    filteredStatements.toList
  }

  final def deploy(session: SparkSession): Unit = {

      val oadwSchema = ResourceHelper.readLinesFromStream(OADWSchema.OADW_COMBINED_SCHEMA)
      val epsilonOADWSchema = ResourceHelper.readLinesFromStream(OADWSchema.EPSILON_OADW_SCHEMA)
      log.warn("Dropping and Recreating database.")
      for(retryCount <- 1 to 10){
        if(session.catalog.databaseExists(input.getOadwDbName)){
          log.warn(s"Retrying drop database: $retryCount")
          runQuery(session, input.replace(dropOADWDDb))
          // Sleep for 15 seconds to avoid situation where hive db doesn't get deleted for a while after throwing error while deleting database.
          Thread.sleep(15000)
        }
      }

      // check if drop database is succeed
      if(session.catalog.databaseExists(input.getOadwDbName)){
        throw new Exception("Couldn't drop existing database")
      }

      runQuery(session, input.replace(createDb), true)

      log.warn("Creating Tables and Views.")
      val statements = if (cdrLevel != "ecdr") {
        log.warn("Preparing statements for OADW hive db.")
        List(oadwSchema)
      } else {
        log.warn("Preparing statements for eOADW hive db.")
        List(epsilonOADWSchema)
      }
      runPatternFilteredQueries(statements.mkString("\n"), session)
  }

  override protected def getReplacementParams: Map[String, String] = {
    replacementMap
  }
}

object ResourceHelper {
  def readLinesFromStream(resourceName: String): String = {
    val resourceStream = this.getClass.getClassLoader.getResourceAsStream(resourceName)
    scala.io.Source.fromInputStream(resourceStream).getLines().mkString("\n")
  }
}
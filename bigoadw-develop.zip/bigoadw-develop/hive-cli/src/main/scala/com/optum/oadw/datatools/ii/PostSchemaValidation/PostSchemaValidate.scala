package com.optum.oadw.datatools.ii.PostSchemaValidation

import com.optum.oadw.constants.{II => oadwConstant}
import com.optum.oadw.datatools.ii.iiUtils.IIValidationException
import com.optum.oap.constants.II
import com.optum.oap.sparklib.SparkUtils
import com.optum.oap.utils.{CliUtils, ExitCode}
import org.apache.spark.sql.SparkSession
import org.rogach.scallop.{ScallopConf, ScallopOption, Subcommand}
import org.slf4j.LoggerFactory

class Conf(arguments: Seq[String]) extends ScallopConf(arguments) {
  val postDeployValidate = new Subcommand("postDeployValidate") {
    val clientId = opt[String](required = true, name = "clientId", argName = "clientId", descr = "Define the client id")
    val env = opt[String](required = true, name = "env", argName = "env", descr = "Define the environment. Valid values are dev, qa, stg, prd")
    val product = opt[String](required = true, name = "product", argName = "product", descr = "Define the product. Valid values are oadw, cdr, fdr, etc.")
    val configFile = opt[String](required = false, name = "configFile", argName = "configFile", descr = "Define the config file for files metadata")
    val cdrCycle = opt[String](required = true, name = "cdrCycle", argName = "cdrCycle", descr = "Define the cdr cycle (i.e. cdr_201903)")
    val instance = opt[String](required = true, name = "instance", argName = "instance", descr = "Define the instance")
    val streamId = opt[String](required = false, name = "streamId", argName = "streamId", descr = "Define the streamId")
    val processId = opt[String](required = false, name = "processId", argName = "processId", descr = "Define the processid to fetch data", default = Option(II.DEFAULT_PROCESSID))
    val dateStamp = opt[String](required = false, name = "dateStamp", argName = "dateStamp", descr = "Define the dateStamp. Format - yyyyMMdd", default = Option(II.DEFAULT_DATESTAMP))
    val models: ScallopOption[String] = opt[String](required = false, name = "models", argName = "models", descr = "Comma separated list of II L1 model names to process.")
    val excludeModels: ScallopOption[String] = opt[String](required = false, name = "excludeModels", argName = "excludeModels", descr = "Comma separated list of II L1 model names to exclude.")
    val isCountValidation = opt[Boolean](required = false, name = "countsValidate", argName = "countsValidate", descr = "Validate bz2 and parquet counts", default = Option(false))
    val bucket: ScallopOption[String]  = opt[String](required = false, name = "bucket", argName = "bucket", descr = "Client bucket")
    val storageProtocol = opt[String](required = false, name = "storageProtocol", argName = "storageProtocol", descr = "Define big data storage protocol. Acceptable values are s3 and hdfs only")
  }
  addSubcommand(postDeployValidate)
  verify()
}

object PostSchemaValidate extends App {

  def parseArgsAndValidate(args: Array[String], sparkSession: SparkSession): Unit = {
    val conf = new Conf(args)

    conf.subcommand match {
      case Some(conf.postDeployValidate) => {
        val models = CliUtils.getOptionalSeq(conf.postDeployValidate.models)
        val excludeModels = CliUtils.getOptionalSeq(conf.postDeployValidate.excludeModels)

        if (conf.postDeployValidate.storageProtocol.isDefined && !conf.postDeployValidate.storageProtocol().equals("s3")
          && !conf.postDeployValidate.storageProtocol().equals("hdfs")) {
          throw IIValidationException(s"storageProtocol can only be s3 or hdfs")
        }

        val input = PostSchemaValidateInput(
          excludeModels,
          models,
          env = conf.postDeployValidate.env(),
          clientId = conf.postDeployValidate.clientId(),
          product = conf.postDeployValidate.product(),
          configFile = conf.postDeployValidate.configFile.toOption.getOrElse(""),
          cdrCycle = conf.postDeployValidate.cdrCycle(),
          instance = conf.postDeployValidate.instance(),
          streamId = conf.postDeployValidate.streamId.toOption.getOrElse("default"),
          processid = conf.postDeployValidate.processId(),
          datestamp = conf.postDeployValidate.dateStamp(),
          countsValidate = conf.postDeployValidate.isCountValidation(),
          storageProtocol = conf.postDeployValidate.storageProtocol.toOption.getOrElse("hdfs"),
          bucket = conf.postDeployValidate.bucket.toOption
        )

        val exitCode = validate(sparkSession,input)
        if (exitCode != ExitCode.SUCCESS) {
          throw IIValidationException(s"Failure code thrown by post schema deploy validation command: ${exitCode.code}")
        }
      }
      case _ => throw IIValidationException("Invalid command!!")
    }
  }

  private val skipIIL2 = Set(
    "l2_ii_map_contract"
  )
  private val logger = LoggerFactory.getLogger(this.getClass)

  lazy val sparkSession: SparkSession = SparkUtils.createSparkSession("OADW-IIExternal-PostSchema-Validator", verboseLogging = false, logWarnings = true)
  parseArgsAndValidate(args,sparkSession)


  private def validate(session: SparkSession, input: PostSchemaValidateInput): ExitCode = {

    val ii_path = input.storageProtocol.toLowerCase match {
      case "s3" => s"s3://${input.bucket.get}/${input.env}/external/ii/${input.processid}/${input.datestamp}/data/II_DB_VERSION"
      case "hdfs" => s"/optum/data_factory/${input.clientId}/${input.env}/external/ii/${input.processid}/${input.datestamp}/data/II_DB_VERSION"
      case invalidProtocol => throw new IllegalArgumentException(s"Invalid protocol $invalidProtocol")
    }

    println(s"reading the II_DB_version from path: ${ii_path}")

    // read it from the ii_db_version table for config File
    import session.implicits._
    val iiConfigVer = session.read.format("parquet").load(ii_path).where($"module" === "PE").select($"major", $"minor").collect().head
    val major = iiConfigVer.getInt(0)
    val minor = iiConfigVer.getInt(1)
    val version = s"$major.$minor"

    if (version != oadwConstant.VERSION)
      throw IIValidationException(s"ii_db_version: ${version} in the parquet, is not supported by the current II: ${oadwConstant.VERSION} version in OADW")
    ExitCode.SUCCESS
  }
}

case class PostSchemaValidateInput(excludeModels: Option[Seq[String]], models: Option[Seq[String]], env: String,
                                   clientId: String, product: String, configFile: String, cdrCycle: String,
                                   instance: String, streamId: String, processid: String, datestamp: String, countsValidate: Boolean,
                                   storageProtocol: String, bucket: Option[String] = None)

case class Schema(col_name: String, data_type: String, comment: String)
CREATE OR REPLACE VIEW L2_patient_info
AS
SELECT * FROM (SELECT groupid AS client_id,
    CAST(proceduredate AS DATE) AS procedure_dtm,
    CASE
        WHEN codetype = 'REV' AND LENGTH(REGEXP_REPLACE(mappedcode, '[^0-9]')) = 3 THEN LPAD(REGEXP_REPLACE(mappedcode, '[^0-9]'), 4, '0')
        WHEN codetype = 'REV' THEN NULL
        WHEN codetype = 'HCPCS' AND substr(UPPER(mappedcode), 1, 1) NOT IN ('A', 'B', 'C', 'D', 'E', 'G', 'H', 'J', 'K', 'L', 'M', 'P', 'Q', 'R', 'S', 'T', 'V') THEN NULL
        ELSE UPPER(mappedcode) END AS mappedcode,
        CAST(actualprocdate AS DATE) AS actualproc_dtm,
        CAST(proc_end_date AS DATE) AS proc_end_dtm,
        orig_mappedcode, orig_codetype
    FROM l1_proceduredo WHERE 1 = 1) AS a0 WHERE mappedcode IS NOT NULL;
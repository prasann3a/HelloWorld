CREATE MATERIALIZED VIEW L4_dict_month AS SELECT month_id ,   TO_CHAR (day_dt, 'fmMonth') AS month_name ,
TO_CHAR (day_dt, 'fmMon')   AS month_short_name ,   TO_CHAR (day_dt, 'fmMonth YYYY') AS month_year_name ,
TO_CHAR (day_dt, 'fmMon YYYY') AS month_year_short_name ,   quarter_id ,   year_id ,
TO_NUMBER (TO_CHAR (prev_month_day_dt, 'YYYYMM')) AS prev_month_id ,   TO_NUMBER (TO_CHAR (prev_quarter_day_dt, 'YYYYMM'))
AS prev_quarter_month_id ,   TO_NUMBER (TO_CHAR (prev_year_day_dt, 'YYYYMM')) AS prev_year_month_id FROM L4_dict_day
WHERE  EXTRACT (DAY FROM day_dt) = 1;
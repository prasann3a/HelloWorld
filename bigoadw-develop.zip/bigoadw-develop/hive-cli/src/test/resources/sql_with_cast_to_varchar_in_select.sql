CREATE OR REPLACE VIEW L1_map_pat_type_tos
AS
SELECT inst_prof,patient_type_cui,CAST(tos_i_5 AS VARCHAR2(9)) AS tos_i_5,dts_version
FROM L1_map_pat_type_tos;
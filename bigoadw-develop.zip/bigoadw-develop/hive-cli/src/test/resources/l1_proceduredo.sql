CREATE OR REPLACE VIEW L1_PROCEDUREDO
AS
SELECT datasrc,facilityid,encounterid,patientid,sourceid
FROM (
SELECT groupid AS client_id,datasrc,facilityid,encounterid,patientid,sourceid,performingproviderid,referproviderid
       ,CAST(proceduredate AS DATE) AS procedure_dtm
       ,localcode,localname,codetype,procseq
       ,CASE WHEN codetype = 'REV' AND LENGTH(REGEXP_REPLACE(mappedcode,'[^0-9]')) = 3 THEN LPAD(REGEXP_REPLACE(mappedcode,'[^0-9]'),4,'0')
             WHEN codetype = 'REV' THEN NULL
             WHEN codetype = 'HCPCS' AND substr(UPPER(mappedcode),1,1) not in ('A','B','C','D','E','G','H','J','K','L','M','P','Q','R','S','T','V') THEN NULL
             ELSE UPPER(mappedcode) END AS mappedcode
       ,localbillingproviderid,orderingproviderid,client_ds_id,hgpid,grp_mpi AS mpi,localprincipleindicator,hosp_px_flag,performing_mstrprovid
       ,CAST(actualprocdate AS DATE) AS actualproc_dtm
       ,CAST(proc_end_date AS DATE) AS proc_end_dtm
       ,orig_mappedcode,orig_codetype
FROM L1_proceduredo
WHERE groupid  = '&client_id'
) WHERE mappedcode IS NOT NULL;

------------------------------------------------------------------------
--combination of CDR patient_summary_grp_mpi, patientaddr_summary, and patientcontact_summary (with latest for addr and contact)
--Need a maxvalue partition if we're going to store NULLs
CREATE TABLE L2_patient_info (
       client_id          VARCHAR2(16) NOT NULL,
       abc                NUMBER(19, 2),
       last_updt_dtm      DATE DEFAULT SYSDATE NOT NULL,
       mpi                VARCHAR2(32) NOT NULL,
       mrn                VARCHAR2(20),
       ssn                VARCHAR2(9),
       first_name         VARCHAR2(30),
       last_name          VARCHAR2(50),
       middle_name        VARCHAR2(30),
       dob                DATE,
       dod                DATE,
       gender_cui         VARCHAR2(8), -- NOT NULL?
       race_cui           VARCHAR2(8),
       ethnicity_cui      VARCHAR2(8),
       death_ind_cui      VARCHAR2(8),
       marital_status_cui VARCHAR2(8),
       language_cui       VARCHAR2(8),
       addr_line_1        VARCHAR2(100),
       addr_line_2        VARCHAR2(100),
       city               VARCHAR2(50),
       state              VARCHAR2(2),
       postal_cd          VARCHAR2(5),
       home_phone         VARCHAR2(30),
       work_phone         VARCHAR2(30),
       mobile_phone       VARCHAR2(30),
       email              VARCHAR2(100),
       religion           VARCHAR2(100)
) PCTFREE 0 NOLOGGING COMPRESS
PARTITION BY RANGE(dob)
(PARTITION P_pre1940 VALUES LESS THAN (to_date('19400101','YYYYMMDD'))
,PARTITION P_1940s VALUES LESS THAN (to_date('19500101','YYYYMMDD'))
,PARTITION P_1950s VALUES LESS THAN (to_date('19600101','YYYYMMDD'))
,PARTITION P_1960s VALUES LESS THAN (to_date('19700101','YYYYMMDD'))
,PARTITION P_1970s VALUES LESS THAN (to_date('19800101','YYYYMMDD'))
,PARTITION P_1980s VALUES LESS THAN (to_date('19900101','YYYYMMDD'))
,PARTITION P_1990s VALUES LESS THAN (to_date('20000101','YYYYMMDD'))
,PARTITION P_pre2020 VALUES LESS THAN (to_date('20200101','YYYYMMDD'))
,PARTITION P_MAX VALUES LESS THAN (MAXVALUE)
);
ALTER TABLE L2_patient_info ADD CONSTRAINT L2_patient_info_pk PRIMARY KEY (client_id,mpi) USING INDEX PCTFREE 0 NOLOGGING;

--------------------------
-- FMP @ignoreReadBeforeWrite(L2_PATIENT_INFO)
CREATE OR REPLACE VIEW L2_patient_info
AS
SELECT client_id,mpi,mrn,ssn,first_name,last_name,middle_name,dob,dod
       ,gender_cui,race_cui,ethnicity_cui,death_ind_cui,marital_status_cui,language_cui
       ,addr_line_1,addr_line_2,city,state,postal_cd
       ,home_phone,work_phone,mobile_phone,email,religion
       ,last_updt_dtm
FROM L2_patient_info;

--Create Synonymns to the CDR tables to provider for a level of indirection and to rename to OADW standard
--OADW Schema Setup
DEFINE src_schema=&1

CREATE OR REPLACE SYNONYM L1_ALLERGY FOR &src_schema..ALLERGY;

CREATE OR REPLACE SYNONYM L1_APPOINTMENT FOR &src_schema..APPOINTMENT;

CREATE OR REPLACE SYNONYM L1_CLAIM FOR &src_schema..CLAIM;

CREATE OR REPLACE SYNONYM L1_CLINICALENCOUNTER FOR &src_schema..CLINICALENCOUNTER;
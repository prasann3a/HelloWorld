--------------------------------------------------------------------------------------------------
-- Procedure
-- Need to accomodate claim-style stuff like modifiers and POS
--Do we need an unknown partition, if we assume only normalized values flow to L2?
-- TBD: proc end dates, provider ids.
---We should consider whether we wish to include the P_UNKNOWN partition, I think not.
CREATE TABLE L2_pat_proc (
       modifier_3                 VARCHAR2(2),
       modifier_4                 VARCHAR2(2),
       modifier_1_excld           NUMBER(1) GENERATED ALWAYS AS (CASE WHEN modifier_1 in ('1P','2P','3P','8P') THEN 1 ELSE 0 END) VIRTUAL,
       modifier_2_excld           NUMBER(1) GENERATED ALWAYS AS (CASE WHEN modifier_2 in ('1P','2P','3P','8P') THEN 1 ELSE 0 END) VIRTUAL,
       modifier_3_excld           NUMBER(1) GENERATED ALWAYS AS (CASE WHEN modifier_3 in ('1P','2P','3P','8P') THEN 1 ELSE 0 END) VIRTUAL,
       modifier_4_excld           NUMBER(1) GENERATED ALWAYS AS (CASE WHEN modifier_4 in ('1P','2P','3P','8P') THEN 1 ELSE 0 END) VIRTUAL
)PCTFREE 0 NOLOGGING COMPRESS
PARTITION BY LIST(code_type) SUBPARTITION BY RANGE (PROC_DTM)
SUBPARTITION TEMPLATE (
  &date_range_subparts
  ,SUBPARTITION P_DEFAULT VALUES LESS THAN ( MAXVALUE )
)
(PARTITION P_NULL VALUES (NULL)
);


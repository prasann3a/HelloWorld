CREATE OR REPLACE VIEW L1_WHERE_CLAUSE
AS
SELECT groupid AS client_id, client_ds_id, datasrc, patientid, hgpid, grp_mpi AS mpi, appointmentid, appointmentdate AS appointment_dtm, locationid, providerid, mstrprovid, local_appt_type, appointment_reason FROM l1_appointment WHERE groupid = '&client_id' and datasrc = 'abc';
CREATE OR REPLACE VIEW l4_dict_day
AS
SELECT
    month_id,
    TO_CHAR(day_dt, 'fmMonth') AS month_name,
    TO_NUMBER(TO_CHAR(prev_month_day_dt, 'YYYYMM')) AS prev_month_id
FROM l4_dict_day
WHERE EXTRACT(DAY FROM day_dt) = 1;
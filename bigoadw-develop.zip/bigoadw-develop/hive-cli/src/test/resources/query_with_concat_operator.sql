CREATE OR REPLACE VIEW L1_FACILITY_ROLLUP
AS
WITH fac_rollup
AS
(
    SELECT f.client_id, f.facilityid facility_id, f.client_ds_id
      ,COALESCE(fr.siteofcare_id, f.client_ds_id||'.'||f.facilityid) AS siteofcare_cd
      ,COALESCE(fr.siteofcare_name, f.facilityname, 'unknown or n/a') AS siteofcare_name
      ,CASE WHEN fr.siteofcare_id IS NULL THEN f.facilitypostalcd ELSE fr.siteofcare_postalcd END AS siteofcare_postalcd
      ,fr.master_facility_id, fr.master_facility_name, fr.enctr_grp_flag, fr.facilitypostalcd, fr.soc_rollup_flag
      ,MAX(fr.dts_version) OVER (PARTITION BY f.client_id) AS dts_version
      , fr.patient_type_cui
      ,CASE WHEN fr.siteofcare_id IS NOT NULL THEN 1 ELSE 0 END AS soc_mapped_ind
    FROM L1_facility F
    LEFT JOIN L1_FACILITY_ROLLUP FR ON (f.client_id = fr.groupid AND f.client_ds_id = fr.client_ds_id AND f.facilityid = fr.facility_id)
)
SELECT client_id, facility_id, client_ds_id, siteofcare_cd
      ,CASE WHEN soc_mapped_ind = 1 OR COUNT(*) OVER (PARTITION BY UPPER(siteofcare_name)) = 1 THEN siteofcare_name
            ELSE siteofcare_name||' ('||siteofcare_cd||')'
       END AS siteofcare_name
      ,siteofcare_postalcd, master_facility_id AS master_facility_cd
      ,master_facility_name, enctr_grp_flag, facilitypostalcd
      ,soc_rollup_flag, dts_version, patient_type_cui
      , ROWNUM AS hgmasterfacid
FROM fac_rollup;
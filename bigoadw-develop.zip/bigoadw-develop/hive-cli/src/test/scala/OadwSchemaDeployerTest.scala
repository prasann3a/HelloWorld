import com.optum.oadw.schema.deploy.lib.OADWSchemaDeployer
import com.optum.oadw.utils.OADWSchemaInput
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class OadwSchemaDeployerTest extends FlatSpec{
  val schemaInput : OADWSchemaInput = {
    OADWSchemaInput(
      clientId = "H10000",
      environment = "stg",
      instance = "1",
      streamId = "default",
      cdrCycle = "cdr_202003",
      cdrLevel = "cdr_be",
      iiProcessId = "1111",
      iiDateStamp = "20200704",
      oadwRefVersion = "2_2",
      protocol = "hdfs",
      bucket = ""
    )
  }

  new OADWSchemaDeployer(schemaInput).runQuery(null, "sql")

}

package com.optum.oadw.etl.L3

import com.optum.oadw.definedfunctions.BitOrAggFunction
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

/**
 *
 * SELECT  client_id, mpi,score_id, elig_cds_id, timeframe_id,  bucket_id
 * ,MAX(requirement_satisfied) AS bucket_req_satisfied
 * ,bitoragg(demog_default_flg) AS demog_default_flg                                                                                                                                                                                                   --added in
 * FROM (
 * SELECT pats.client_id
 * ,pats.mpi
 * ,tri.timeframe_id
 * ,tri.score_id
 * ,tri.score_population_id
 * ,tri.elig_cds_id
 * , req.BUCKET_ID
 * , req.SCORE_REQ_TYPE_ID
 * ,CASE WHEN reqtype.SCORE_REQ_TYPE_DESC = 'Age Requirement' THEN pats.age_default_flg
 * WHEN reqtype.SCORE_REQ_TYPE_DESC = 'Gender Requirement' THEN pats.gender_default_flg
 * WHEN reqtype.SCORE_REQ_TYPE_DESC = 'Race Requirement' THEN pats.race_default_flg
 * ELSE 0 END AS demog_default_flg --these are the defaults that were used in determining the population
 * ,CASE WHEN reqtype.SCORE_REQ_TYPE_DESC IS NULL THEN 1 --When there are no population requirements for a given Score, then the requirements are all satisfied
 * WHEN reqtype.SCORE_REQ_TYPE_DESC = 'Age Requirement' AND pats.age BETWEEN req.REQ_MIN_AGE AND req.REQ_MAX_AGE THEN 1
 * WHEN reqtype.SCORE_REQ_TYPE_DESC = 'Gender Requirement' AND req.REQ_GENDER=pats.gender THEN 1
 * WHEN reqtype.SCORE_REQ_TYPE_DESC = 'Race Requirement' AND req.REQ_RACE = pats.race THEN 1
 * ELSE 0 --the race/gender/age requirement was not satisfied
 * END AS requirement_satisfied
 * FROM temp_score_pats_demog pats
 * INNER JOIN TEMP_SCORE_TRIPLET tri ON (pats.timeframe_id = tri.timeframe_id)
 * LEFT OUTER JOIN L3_MAP_SCORE_POPULATION_REQ req ON (tri.SCORE_POPULATION_ID=req.SCORE_POPULATION_ID)
 * LEFT OUTER JOIN L3_DICT_SCORE_REQ_TYPE reqtype ON (req.SCORE_REQ_TYPE_ID=reqtype.SCORE_REQ_TYPE_ID)
 * WHERE reqtype.SCORE_REQ_TYPE_DESC in ('Age Requirement','Gender Requirement','Race Requirement') OR reqtype.SCORE_REQ_TYPE_DESC IS NULL
 * ) v
 * GROUP BY client_id, mpi,score_id, elig_cds_id, timeframe_id, bucket_id
 *
 */

case class temp_score_pat_pop_data(client_id: String, mpi: String, score_id: java.lang.Integer, elig_cds_id: java.lang.Integer,
                                   timeframe_id: java.lang.Integer, bucket_id: java.lang.Integer, bucket_req_satisfied: java.lang.Integer,
                                   demog_default_flg: java.lang.Integer)

object TEMP_SCORE_PAT_POP extends TableInfo[temp_score_pat_pop_data] {
  override def name: String = "TEMP_SCORE_PAT_POP"

  override def dependsOn: Set[String] =
    Set(
      "TEMP_SCORE_PATS_DEMOG",
      "TEMP_SCORE_TRIPLET",
      "L3_MAP_SCORE_POPULATION_REQ",
      "L3_DICT_SCORE_REQ_TYPE"
    )

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempScorePatPop = loadedDependencies("TEMP_SCORE_PATS_DEMOG")
    val tempScoreTriplet = loadedDependencies("TEMP_SCORE_TRIPLET")
    val l3MapScorePopulationReq = broadcast(loadedDependencies("L3_MAP_SCORE_POPULATION_REQ"))
    val l3DictScoreReqType = broadcast(loadedDependencies("L3_DICT_SCORE_REQ_TYPE"))

    val bitoragg = BitOrAggFunction.bitOrAgg

    tempScorePatPop.as("pats")
      .join(tempScoreTriplet.as("tri"), $"pats.timeframe_id" === $"tri.timeframe_id", "inner")
      .join(l3MapScorePopulationReq.as("req"), $"tri.score_population_id" === $"req.score_population_id", "left_outer")
      .join(l3DictScoreReqType.as("reqtype"), $"req.score_req_type_id" === $"reqtype.score_req_type_id", "left_outer")
      .where($"reqtype.score_req_type_desc".isin("Age Requirement", "Gender Requirement", "Race Requirement") || $"reqtype.score_req_type_desc".isNull)
      .select($"pats.client_id", $"pats.mpi", $"tri.timeframe_id", $"tri.score_id", $"tri.score_population_id", $"tri.elig_cds_id",
        $"req.bucket_id", $"req.score_req_type_id",
        when($"reqtype.score_req_type_desc" === "Age Requirement", $"pats.age_default_flg")
          .when($"reqtype.score_req_type_desc" === "Gender Requirement", $"pats.gender_default_flg")
          .when($"reqtype.score_req_type_desc" === "Race Requirement", $"pats.race_default_flg")
          .otherwise(lit(0)).as("demog_default_flg"),
        when($"reqtype.score_req_type_desc".isNull, lit(1))
          .when($"reqtype.score_req_type_desc" === "Age Requirement" && $"pats.age" >= $"req.req_min_age" && $"pats.age" <= $"req.req_max_age", lit(1))
          .when($"reqtype.score_req_type_desc" === "Gender Requirement" && $"req.req_gender" === $"pats.gender", lit(1))
          .when($"reqtype.score_req_type_desc" === "Race Requirement" && $"req.req_race" === $"pats.race", lit(1))
          .otherwise(lit(0)).as("requirement_satisfied")
      )
      .groupBy($"pats.client_id", $"pats.mpi", $"tri.score_id", $"tri.elig_cds_id", $"tri.timeframe_id", $"req.bucket_id")
      .agg(max($"requirement_satisfied").as("bucket_req_satisfied"),
        bitoragg($"demog_default_flg").as("demog_default_flg"))
      .toDF()
  }
}
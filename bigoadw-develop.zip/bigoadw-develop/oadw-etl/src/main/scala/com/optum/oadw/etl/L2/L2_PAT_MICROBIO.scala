package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_pat_microbio
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_PAT_MICROBIO extends QueryAndMetadata[l2_pat_microbio] {
  override def name: String = "L2_PAT_MICROBIO"

  override def sparkSql: String = """
select client_id,
 	mpi,
 	result_dtm,
 	organism_cui,
 	antibiotic_loinc,
 	sensitivity_cui,
 	clinical_event_id,
 	org_exclude_cui,
 	culture_growth_cui,
 	culture_value_cui,
 	culture_unit_cui,
 	specimen_source_cui,
  cds_grp,
 	order_dtm, NVL(clinical_event_id,0) as clinical_evt_key, cast((NVL2(coalesce(order_dtm,result_dtm),1,0)) as int) as has_dt, cast(0 as int) as inferred_ind, cast(0 as int) as sensitive_ind from (
SELECT  a.client_id
,a.mpi							AS mpi
,a.available_dtm 				AS result_dtm
,a.organism_found_cui 			AS organism_cui
,a.antibiotic_loinc 		    	AS antibiotic_loinc
,a.sens_result_cui 				AS sensitivity_cui
,MIN(cee.encounter_grp_num) 	    AS clinical_event_id
,MIN(a.org_exclude_cui) 			AS org_exclude_cui
,MIN(a.culture_growth_cui) 		AS culture_growth_cui
,MIN(a.culture_val_cui) 			AS culture_value_cui
,MIN(a.culture_unit_cui) 		AS culture_unit_cui
,MIN (mbo.hts_specimen_source) 	AS specimen_source_cui
,listagg(mcf.client_ds_id) as cds_grp
,mbo.ordered_dtm  				AS order_dtm
FROM L1_mbresult a
INNER JOIN L2_map_cds_flg mcf
on (a.client_id = mcf.client_id
AND a.client_ds_id = mcf.client_ds_id)
LEFT OUTER JOIN L1_clinical_event_encounter cee
ON (cee.client_id = a.client_id
AND a.client_ds_id = a.client_ds_id
AND cee.encounterid = a.encounterid
AND cee.mpi = a.mpi)
LEFT OUTER JOIN L1_mborder mbo
ON (mbo.mbprocorderid = a.mbprocorderid
AND mbo.encounterid = a.encounterid)
WHERE a.mpi IS NOT NULL
AND (a.result_status_cui =  'CH002333'
OR	 a.result_status_cui IS NULL)
AND nvl(a.organism_found_cui,'CH999999')  != 'CH999999'
group by a.client_id
,a.mpi
,mbo.ordered_dtm
,a.available_dtm
,a.organism_found_cui
,a.antibiotic_loinc
,a.sens_result_cui
,mcf.data_grp_flg ) xyz"""

  override def dependsOn: Set[String] = Set("L2_MAP_CDS_FLG","MD_OADW_INSTANCE","L1_MBRESULT","L1_CLINICAL_EVENT_ENCOUNTER","L1_MBORDER")

  def originalSql: String = """/*=====================================================================*/
/* Build updated 2018/01/09 based on the JIRA Task OADW-503            */
/*=====================================================================*/

INSERT /*+ APPEND */ INTO L2_pat_microbio
(
	client_id,
	mpi,
	result_dtm,
	organism_cui,
	antibiotic_loinc,
	sensitivity_cui,
	clinical_event_id,
	org_exclude_cui,
	culture_growth_cui,
	culture_value_cui,
	culture_unit_cui,
	specimen_source_cui,
	order_dtm
)
WITH oadw_data_thru AS
(   SELECT /*+ CARDINALITY(1) */
         TO_DATE (attribute_value, 'YYYYMMDD')  AS data_thru_dt
    FROM MD_oadw_instance
    WHERE
        attribute_name='DATA_THRU'
)
SELECT /*+ &parallel_hint */ a.client_id
       ,a.mpi							AS mpi
       ,a.available_dtm 				AS result_dtm
       ,a.organism_found_cui 			AS organism_cui
       ,a.antibiotic_loinc 		    	AS antibiotic_loinc
       ,a.sens_result_cui 				AS sensitivity_cui
       ,MIN(cee.encounter_grp_num) 	    AS clinical_event_id
       ,MIN(a.org_exclude_cui) 			AS org_exclude_cui
       ,MIN(a.culture_growth_cui) 		AS culture_growth_cui
       ,MIN(a.culture_val_cui) 			AS culture_value_cui
       ,MIN(a.culture_unit_cui) 		AS culture_unit_cui
       ,MIN (mbo.hts_specimen_source) 	AS specimen_source_cui
	   ,mbo.ordered_dtm  				AS order_dtm
FROM L1_mbresult a
INNER JOIN L2_map_cds_flg mcf
	on (a.client_id = mcf.client_id
	AND a.client_ds_id = mcf.client_ds_id)
LEFT OUTER JOIN L1_clinical_event_encounter cee
	ON (cee.client_id = a.client_id
	AND a.client_ds_id = a.client_ds_id
	AND cee.encounterid = a.encounterid
	AND cee.mpi = a.mpi)
LEFT OUTER JOIN L1_mborder mbo
	ON (mbo.mbprocorderid = a.mbprocorderid
	AND mbo.encounterid = a.encounterid)
WHERE a.mpi IS NOT NULL
	AND (a.result_status_cui =  'CH002333'
	OR	 a.result_status_cui IS NULL)
--AND a.available_dtm < ( SELECT data_thru_dt + 1 /* day */ FROM oadw_data_thru )
AND nvl(a.organism_found_cui,'CH999999')  != 'CH999999'
group by a.client_id
       ,a.mpi
	   ,mbo.ordered_dtm
       ,a.available_dtm
       ,a.organism_found_cui
       ,a.antibiotic_loinc
       ,a.sens_result_cui
	   ,mcf.data_grp_flg
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("client_id",None,None), OutputColumn("mpi",None,None), OutputColumn("result_dtm",None,None), OutputColumn("organism_cui",None,None),
    OutputColumn("antibiotic_loinc",None,None), OutputColumn("sensitivity_cui",None,None), OutputColumn("clinical_event_id",None,None), OutputColumn("org_exclude_cui",None,None), OutputColumn("culture_growth_cui",None,None),
    OutputColumn("culture_value_cui",None,None), OutputColumn("culture_unit_cui",None,None), OutputColumn("specimen_source_cui",None,None), OutputColumn("cds_grp",None,None), OutputColumn("order_dtm",None,None), OutputColumn("clinical_evt_key",None,None),
    OutputColumn("has_dt",None,None), OutputColumn("inferred_ind",None,None), OutputColumn("sensitive_ind",None,None)))

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_pat_microbio_build.sql"
}

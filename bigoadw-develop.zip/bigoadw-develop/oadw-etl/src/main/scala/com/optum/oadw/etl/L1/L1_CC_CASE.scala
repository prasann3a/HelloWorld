
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_cc_case, cc_case}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_CC_CASE extends TableInfo[l1_cc_case]{
  override def dependsOn: Set[String] = Set("CC_CASE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CC_CASE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ccCase = loadedDependencies("CC_CASE").as[cc_case]

    ccCase
    .select(
			$"care_coord_assgnd_dt",
			$"care_coord_start_dt",
			$"care_plan_subtype",
			$"care_plan_type",
			$"care_plan_type_opt_out_dt",
			$"care_plan_type_opt_out_ind",
			$"care_tier",
			$"case_billing_diag_cd",
			$"case_close_rsn",
			$"case_closed_by_id",
			$"case_closed_dt",
			$"case_closed_sys_dtm",
			$"case_created_by_id",
			$"case_created_dt",
			$"case_desc",
			$"case_last_mod_dtm",
			$"case_last_task_edit_dt",
			$"case_nbr",
			$"case_origin_cat",
			$"case_origin_dtl",
			$"case_owner_id",
			$"case_priority",
			$"case_rsn",
			$"case_status",
			$"case_status_before_closed",
			$"case_subject",
			$"cc_case_id",
			$"client_ds_id",
			$"consent_given_dt",
			$"consent_mode",
			$"consent_notes",
			$"consent_status",
			$"datasrc",
			$"groupid".as("client_id"),
			$"grp_mpi".as("mpi"),
			$"hgpid",
			$"patient_enrolled_dt",
			$"patient_enrolled_ind",
			$"patientid",
			$"record_type_id"
    )
  }
}


package com.optum.oadw.etl.L2
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_pat_clinical_hosp_s1_data(client_id: String = null, mpi: String = null, trunc_start_dtm: java.sql.Date = null, trunc_end_dtm: java.sql.Date = null, event_type_cui: String = null)

object TEMP_PAT_CLINICAL_HOSP_S1 extends QueryAndMetadata[temp_pat_clinical_hosp_s1_data] {
  override def name: String = "TEMP_PAT_CLINICAL_HOSP_S1"

  override def sparkSql: String = """SELECT   hosp.client_id, hosp.mpi,  to_date(date_format(hosp.evt_start_dtm, 'yyyy-MM-dd'))  as trunc_start_dtm,  to_date(date_format(hosp.evt_end_dtm, 'yyyy-MM-dd'))  as trunc_end_dtm, hosp.event_type_cui
FROM L2_pat_clinical_event hosp
WHERE hosp.event_type_cui IN ('CH000106', 'CH000107', 'CH000109', 'CH003030', 'CH000795', 'CH003031', 'CH003032')"""

  override def dependsOn: Set[String] = Set("L2_PAT_CLINICAL_EVENT")

  def originalSql: String = """-- Temp table to capture pre-truncated dates used in next two queries.
CREATE TABLE TEMP_PAT_CLINICAL_HOSP_S1 PCTFREE 0 NOLOGGING COMPRESS AS
SELECT /*+ parallel(4) */  hosp.client_id, hosp.mpi, TRUNC(hosp.evt_start_dtm) as trunc_start_dtm, TRUNC(hosp.evt_end_dtm) as trunc_end_dtm, hosp.event_type_cui
FROM L2_pat_clinical_event hosp
WHERE hosp.event_type_cui IN ('CH000106', 'CH000107', 'CH000109', 'CH003030', 'CH000795', 'CH003031', 'CH003032')"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_assess_build.sql"
}

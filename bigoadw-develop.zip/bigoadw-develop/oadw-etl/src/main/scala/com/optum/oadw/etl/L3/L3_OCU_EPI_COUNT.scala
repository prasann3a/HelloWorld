package com.optum.oadw.etl.L3


import com.optum.oadw.oadwModels.l3_ocu_epi_count
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata


object L3_OCU_EPI_COUNT extends QueryAndMetadata[l3_ocu_epi_count] {
  override def name: String = "L3_OCU_EPI_COUNT"

  override def sparkSql: String = """select cast(a.NEW_MEM_ATTR_ID as long) as NEW_MEM_ATTR_ID,a.year_mth_id, b.ia_time, a.etg_id, a.sev_level,
a.tx_ind, a.outlier, a.complete, sum(epi_qty) as epi_qty
from l2_ii_ocu_epi_count_ext a
join L2_II_MAP_DATE_RANGE b on a.year_mth_id=b.year_mth_id
join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
group by a.NEW_MEM_ATTR_ID,a.year_mth_id, b.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2,a.etg_id, a.sev_level,
a.tx_ind, a.outlier, a.complete"""

  override def dependsOn: Set[String] = Set("L2_II_OCU_EPI_COUNT_EXT","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR_EXT")

  def originalSql: String = """



----episodes
insert /*+ append*/ into l3_ocu_epi_count(NEW_MEM_ATTR_ID,YEAR_MTH_ID,IA_TIME,ETG_ID,SEV_LEVEL,TX_IND
,OUTLIER,COMPLETE,EPI_QTY)
select a.NEW_MEM_ATTR_ID,a.year_mth_id, b.ia_time, a.etg_id, a.sev_level,
       a.tx_ind, a.outlier, a.complete, sum(epi_qty) as epi_qty
  from l2_ii_ocu_epi_count_ext a
  join L2_II_MAP_DATE_RANGE b on a.year_mth_id=b.year_mth_id
  join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
 group by a.NEW_MEM_ATTR_ID,a.year_mth_id, b.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2,a.etg_id, a.sev_level,
       a.tx_ind, a.outlier, a.complete"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("NEW_MEM_ATTR_ID",None,None), OutputColumn("YEAR_MTH_ID",None,None), OutputColumn("IA_TIME",None,None), OutputColumn("ETG_ID",None,None), OutputColumn("SEV_LEVEL",None,None), OutputColumn("TX_IND",None,None), OutputColumn("OUTLIER",None,None), OutputColumn("COMPLETE",None,None), OutputColumn("EPI_QTY",None,None)))

  def directoryLevel: String = "L3"





  val originalSqlFileName: String = "L3_II_ocu_build.sql"
}


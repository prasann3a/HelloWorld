package com.optum.oadw.etl.L2

import com.optum.oadw.etl.constants.OADW
import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.definedfunctions.ListAgg
import org.apache.spark.sql.functions.{lit, substring_index, when}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * WITH tmp AS (SELECT /*+ parallel(8) */ DISTINCT account_id, contract_id FROM l2_ii_mem_attr_member_contract)
  * SELECT
  *   c.client_id
  * , SUBSTR(b.account_id, 1, INSTR(b.account_id,'$')-1) AS account_id
  * , b.account_desc
  * , b.account_lv2
  * , b.account_lv2_desc
  * , b.account_lv1
  * , b.account_lv1_desc
  * , CASE WHEN b.biz_segment_id='Unspecified$UNK' THEN NULL ELSE SUBSTR(b.biz_segment_id, 1, INSTR(b.biz_segment_id,'$')-1) END AS biz_segment_id
  * , b.industry
  * FROM tmp a
  * JOIN l2_ii_map_account b ON a.account_id=b.account_id
  * JOIN l1_contract_rollup c ON c.contract_id=SUBSTR(a.contract_id, 1, INSTR(a.contract_id,'$')-1)
  * JOIN l2_map_cds_flg d ON c.client_ds_id=d.client_ds_id
  * WHERE b.account_id!='Unspecified$UNK'
  * GROUP BY c.client_id, b.account_id, b.account_desc, b.account_lv2, b.account_lv2_desc, b.account_lv1, b.account_lv1_desc, b.biz_segment_id, b.industry ;
  */
object L2_DICT_ACCOUNT extends TableInfo[l2_dict_account] {
  override def name: String = "L2_DICT_ACCOUNT"

  override def dependsOn: Set[String] = Set("L2_II_MAP_ACCOUNT", "L2_II_MEM_ATTR_MEMBER_CONTRACT", "L1_CONTRACT_ROLLUP", "L2_MAP_CDS_FLG")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMemAttrMemberContract = loadedDependencies("L2_II_MEM_ATTR_MEMBER_CONTRACT").as[l2_ii_mem_attr_member_contract]
      .select($"account_id", $"contract_id").distinct // a
    val l2IiMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT").as[l2_ii_map_account] // b
    val l1ContractRollup = loadedDependencies("L1_CONTRACT_ROLLUP").as[l1_contract_rollup]  // c
    val l2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg] // d
    val listAgg = new ListAgg()

    l2IiMemAttrMemberContract.as("a")
      .join(l2IiMapAccount.as("b"), Seq("account_id"), "inner")
      .join(l1ContractRollup.as("c"), $"c.contract_id" === substring_index($"a.contract_id", "$", 1) , "inner")
      .join(l2MapCdsFlg.as("d"), Seq("client_ds_id"), "inner")
      .where($"account_id" =!= lit(OADW.UNSPECIFIED_UNK))
      .groupBy($"c.client_id",
        substring_index($"account_id", "$", 1).as("account_id"),
        $"b.account_desc",
        $"b.account_lv2",
        $"b.account_lv2_desc",
        $"b.account_lv1",
        $"b.account_lv1_desc",
        when($"b.biz_segment_id"=== lit(OADW.UNSPECIFIED_UNK), null)
          .otherwise(substring_index($"b.biz_segment_id", "$", 1)).as("biz_segment_id"),
        $"b.industry"
      ).agg(
        listAgg($"client_ds_id").as("cds_grp")
      )
  }
}


/**
  * auto-generated code
*/
package com.optum.oadw.etl.L2

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_er_confinements_data(conf_num: java.lang.Long)

object TEMP_ER_CONFINEMENTS extends QueryAndMetadata[temp_er_confinements_data] {
  override def name: String = "TEMP_ER_CONFINEMENTS"

  override def sparkSql: String = """select distinct conf_num
from (
select  conf_num from L2_II_SERVICES_MED where er_conf = 1
union all
select  conf_num from L2_II_SERVICES_INP where er_conf = 1
)"""

  override def dependsOn: Set[String] = Set("L2_II_SERVICES_MED","L2_II_SERVICES_INP")

  def originalSql: String = """

create table temp_er_confinements pctfree 0 nologging as
select distinct conf_num
  from (
select  conf_num from L2_II_SERVICES_MED where er_conf = 1
union all
select  conf_num from L2_ii_services_inp where er_conf = 1
)"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}


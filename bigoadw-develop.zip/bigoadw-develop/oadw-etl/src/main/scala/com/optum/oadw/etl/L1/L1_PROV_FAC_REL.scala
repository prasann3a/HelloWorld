
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_fac_rel, prov_fac_rel}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_FAC_REL extends TableInfo[l1_prov_fac_rel]{
  override def dependsOn: Set[String] = Set("PROV_FAC_REL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_FAC_REL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val provFacRel = loadedDependencies("PROV_FAC_REL").as[prov_fac_rel]

    provFacRel
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"providerid",
			$"facilityid",
			$"localrelshipcode",
			$"startdate".as("start_dt"),
			$"enddate".as("end_dt"),
			$"mstrprovid",
			$"client_ds_id"
    )
  }
}


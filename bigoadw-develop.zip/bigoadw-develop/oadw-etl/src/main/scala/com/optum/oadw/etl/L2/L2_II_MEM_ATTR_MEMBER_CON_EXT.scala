package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l2_ii_mem_attr_member_con_ext, l2_ii_mem_attr_member_contract, l2_ii_mem_attr_con_ext}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{when, _}
import org.apache.spark.sql.types.{IntegerType, LongType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_II_MEM_ATTR_MEMBER_CON_EXT extends TableInfo[l2_ii_mem_attr_member_con_ext] {
  override def name: String = "L2_II_MEM_ATTR_MEMBER_CON_EXT"

  override def dependsOn: Set[String] = Set("L2_II_MEM_ATTR_MEMBER_CONTRACT", "L2_II_MEM_ATTR_CON_EXT")

  def directoryLevel: String = "L2"


  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2iiMemAttrMemberCon = loadedDependencies("L2_II_MEM_ATTR_MEMBER_CONTRACT").as[l2_ii_mem_attr_member_contract]
    val l2iiMemAttrConExt = loadedDependencies("L2_II_MEM_ATTR_CON_EXT").as[l2_ii_mem_attr_con_ext]

    l2iiMemAttrMemberCon.as("mem")
      .join(l2iiMemAttrConExt.as("dict"),
          $"dict.age_cat2" === $"mem.age_cat2" &&
            $"dict.sex" === $"mem.sex" &&
            $"dict.zip" === $"mem.zip" &&
            $"dict.account_id" === $"mem.account_id" &&
            $"dict.product_id" === $"mem.product_id" &&
            $"dict.contract_id" === $"mem.contract_id" &&
            $"dict.at_risk_status_id" === $"mem.at_risk_status_id" &&
            $"dict.mem_userdef_1_id" === $"mem.mem_userdef_1_id" &&
            $"dict.mem_userdef_2_id" === $"mem.mem_userdef_2_id" &&
            $"dict.mem_userdef_3_id" === $"mem.mem_userdef_3_id" &&
            $"dict.mem_userdef_4_id" === $"mem.mem_userdef_4_id" &&
            $"dict.cat_status" === $"mem.cat_status" &&
            $"dict.cat_status_cost3" === $"mem.cat_status_cost3" &&
            coalesce($"dict.pcp_assign", lit("")) === coalesce($"mem.pcp_assign", lit(""))
          , "inner")
      .select(
         $"mem.account_id"
        , $"mem.age".cast(LongType).as("age")
        , $"mem.age_cat2"
        , $"mem.at_risk_status_id"
        , $"mem.benefit_plan_id"
        , $"mem.biz_segment_id"
        , $"mem.cat_status"
        , $"mem.cat_status_cost3"
        , $"mem.contract_id"
        , $"mem.contract_type_id"
        , $"mem.county_id".cast(LongType).as("county_id")
        , $"mem.coverage_class"
        , $"mem.coverage_status_id"
        , $"mem.ia_time"
        , when($"mem.iatime_lag" === true, lit(1)).when($"mem.iatime_lag" === false, lit(0)).as("iatime_lag")
        , $"mem.industry"
        , when($"mem.last_enroll" === true, lit(1)).when($"mem.last_enroll" === false, lit(0)).as("last_enroll")
        , when($"mem.med" === true, lit(1)).when($"mem.med" === false, lit(0)).as("med")
        , when($"mem.med_qual" === true, lit(1)).when($"mem.med_qual" === false, lit(0)).as("med_qual")
        , $"mem.mem_eff_dt"
        , $"mem.mem_end_dt"
        , $"mem.mem_userdef_1_id"
        , $"mem.mem_userdef_2_id"
        , $"mem.mem_userdef_3_id"
        , $"mem.mem_userdef_4_id"
        , $"mem.member"
        , $"mem.member_attr_id".cast(LongType).as("member_attr_id")
        , $"mem.mm"
        , $"mem.mm_rx"
        , $"mem.mpg_def_id".cast(LongType).as("mpg_def_id")
        , $"dict.new_mem_attr_con_id"
        , $"mem.pcp_assign"
        , $"mem.pcp_imp"
        , when($"mem.phm_qual" === true, lit(1)).when($"mem.phm_qual" === false, lit(0)).as("phm_qual")
        , $"mem.premium_tot"
        , $"mem.prisk"
        , $"mem.product_id"
        , $"mem.rrisk"
        , when($"mem.rx" === true, lit(1)).when($"mem.rx" === false, lit(0)).as("rx")
        , when($"mem.sex" === true, lit(1)).when($"mem.sex" === false, lit(0)).as("sex")
        , $"mem.sub_eff_dt"
        , $"mem.sub_end_dt"
        , $"mem.subscr_months"
        , $"mem.subscriber_id"
        , $"mem.year_mth_id"
        , $"mem.zip"
      )
  }
}

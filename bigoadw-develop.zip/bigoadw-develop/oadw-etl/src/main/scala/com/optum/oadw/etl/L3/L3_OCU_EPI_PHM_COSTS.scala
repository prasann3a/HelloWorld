package com.optum.oadw.etl.L3


import com.optum.oadw.oadwModels.l3_ocu_epi_phm_costs
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L3_OCU_EPI_PHM_COSTS extends QueryAndMetadata[l3_ocu_epi_phm_costs] {
  override def name: String = "L3_OCU_EPI_PHM_COSTS"

  override def sparkSql: String = """select a.year_mth_id, a.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2, a.network_paid_status_id,
a.provider_status_id, a.gbo, a.channel, a.formulary, a.tos_i_5, a.etg_id, A.SEV_LEVEL, a.tx_ind,
a.outlier,a.complete, sum(amt_req) as amt_req, sum(amt_eqv) as amt_eqv, sum(amt_pay) as amt_pay, sum(amt_np) as amt_np,
cast(sum(scripts) as int) as scripts, cast(sum(days_sup) as int) as days_sup, cast(sum(generic) as int) as generic,
cast(sum(script_gen) as int) as script_gen
from L2_II_OCU_EPI_PHM_COSTS_ext a
join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
group by a.year_mth_id, a.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2, a.network_paid_status_id,
a.provider_status_id, a.gbo, a.channel, a.formulary,a.tos_i_5, a.etg_id, A.SEV_LEVEL, a.tx_ind, a.outlier, a.complete"""

  override def dependsOn: Set[String] = Set("L2_II_OCU_EPI_PHM_COSTS_EXT","L2_II_MEM_ATTR_EXT")

  def originalSql: String = """
---pharmacy episode cost and util

insert /*+ append */ into l3_ocu_epi_phm_costs(
  YEAR_MTH_ID,IA_TIME,PCP_ASSIGN,PRODUCT_ID,SEX,AGE_CAT2,NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,GBO,
  CHANNEL,FORMULARY,TOS_I_5,ETG_ID,SEV_LEVEL,TX_IND,OUTLIER,COMPLETE,amt_req,amt_eqv,amt_pay,AMT_NP,
  SCRIPTS,DAYS_SUP,GENERIC,SCRIPT_GEN)
select a.year_mth_id, a.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2, a.network_paid_status_id,
       a.provider_status_id, a.gbo, a.channel, a.formulary, a.tos_i_5, a.etg_id, A.SEV_LEVEL, a.tx_ind,
       a.outlier,a.complete, sum(amt_req), sum(amt_eqv), sum(amt_pay), sum(amt_np),
       sum(scripts) as scripts, sum(days_sup) as days_sup, sum(generic) as generic,
       sum(script_gen) as script_gen
  from L2_II_OCU_EPI_PHM_COSTS_ext a
  join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
 group by a.year_mth_id, a.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2, a.network_paid_status_id,
      a.provider_status_id, a.gbo, a.channel, a.formulary,a.tos_i_5, a.etg_id, A.SEV_LEVEL, a.tx_ind, a.outlier, a.complete
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("YEAR_MTH_ID",None,None), OutputColumn("IA_TIME",None,None), OutputColumn("PCP_ASSIGN",None,None), OutputColumn("PRODUCT_ID",None,None), OutputColumn("SEX",None,None), OutputColumn("AGE_CAT2",None,None), OutputColumn("NETWORK_PAID_STATUS_ID",None,None), OutputColumn("PROVIDER_STATUS_ID",None,None), OutputColumn("GBO",None,None), OutputColumn("CHANNEL",None,None), OutputColumn("FORMULARY",None,None), OutputColumn("TOS_I_5",None,None), OutputColumn("ETG_ID",None,None), OutputColumn("SEV_LEVEL",None,None), OutputColumn("TX_IND",None,None), OutputColumn("OUTLIER",None,None), OutputColumn("COMPLETE",None,None), OutputColumn("amt_req",None,None), OutputColumn("amt_eqv",None,None), OutputColumn("amt_pay",None,None), OutputColumn("AMT_NP",None,None), OutputColumn("SCRIPTS",None,None), OutputColumn("DAYS_SUP",None,None), OutputColumn("GENERIC",None,None), OutputColumn("SCRIPT_GEN",None,None)))

  def directoryLevel: String = "L3"





  val originalSqlFileName: String = "L3_II_ocu_build.sql"
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_bmi_followup, map_bmi_followup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_BMI_FOLLOWUP extends TableInfo[l1_map_bmi_followup]{
  override def dependsOn: Set[String] = Set("MAP_BMI_FOLLOWUP")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_BMI_FOLLOWUP"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapBmiFollowup = loadedDependencies("MAP_BMI_FOLLOWUP").as[map_bmi_followup]

    mapBmiFollowup
    .select(
			$"groupid".as("client_id"),
			$"localcode".as("local_code"),
			$"cui",
			$"dts_version"
    )
  }
}


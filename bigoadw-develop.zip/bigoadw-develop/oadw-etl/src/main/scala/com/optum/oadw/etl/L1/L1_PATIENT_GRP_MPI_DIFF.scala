
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patient_grp_mpi_diff, patient_grp_mpi_diff}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENT_GRP_MPI_DIFF extends TableInfo[l1_patient_grp_mpi_diff]{
  override def dependsOn: Set[String] = Set("PATIENT_GRP_MPI_DIFF")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENT_GRP_MPI_DIFF"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientGrpMpiDiff = loadedDependencies("PATIENT_GRP_MPI_DIFF").as[patient_grp_mpi_diff]

    patientGrpMpiDiff
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"patientid",
			$"hgpid",
			$"new_grp_mpi".as("new_mpi"),
			$"old_grp_mpi".as("old_mpi"),
			$"mpi_status"
    )
  }
}


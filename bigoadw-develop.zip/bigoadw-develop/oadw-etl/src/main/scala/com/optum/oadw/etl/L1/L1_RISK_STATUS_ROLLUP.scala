
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_risk_status_rollup, risk_status_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_RISK_STATUS_ROLLUP extends TableInfo[l1_risk_status_rollup]{
  override def dependsOn: Set[String] = Set("RISK_STATUS_ROLLUP")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_RISK_STATUS_ROLLUP"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val riskStatusRollup = loadedDependencies("RISK_STATUS_ROLLUP").as[risk_status_rollup]

    riskStatusRollup
    .select(
			$"groupid".as("client_id"),
			$"at_risk_status",
			$"at_risk_status_desc",
			$"at_risk_status_lv2",
			$"at_risk_status_lv2_desc",
			$"at_risk_status_lv1",
			$"at_risk_status_lv1_desc",
			$"at_risk_rollup",
			$"client_ds_id",
			$"datasrc"
    )
  }
}


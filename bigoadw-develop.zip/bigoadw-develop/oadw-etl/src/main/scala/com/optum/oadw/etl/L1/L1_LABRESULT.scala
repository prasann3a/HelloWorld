
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_labresult, labresult}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object L1_LABRESULT extends TableInfo[l1_labresult]{
  override def dependsOn: Set[String] = Set("LABRESULT")

	override def partitions: Int = 128
	override def skipCoalesce: Boolean = true
	override def name: String = "L1_LABRESULT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val labresult = loadedDependencies("LABRESULT").as[labresult]

    labresult
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"labresultid",
			$"laborderid",
			$"facilityid",
			$"encounterid",
			$"patientid",
			$"datecollected".as("collected_dtm"),
			$"dateavailable".as("available_dtm"),
			$"resultstatus",
			$"localresult",
			$"localcode",
			$"localname",
			$"normalrange",
			$"localunits",
			$"statuscode",
			$"mappedcode",
			$"mappedname",
			$"localresult_numeric",
			$"localresult_inferred",
			when($"resulttype" === lit("CH999990"),$"resulttype").otherwise(null).as("resulttype"),
			$"relativeindicator",
			$"localunits_inferred",
			$"mappedunits",
			$"normalizedvalue",
			$"localspecimentype",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"localtestname",
			$"labordereddate".as("ordered_dtm"),
			$"locallisresource",
			$"mappedloinc",
			$"mapped_qual_code",
			$"local_loinc_code"
    )
  }
}


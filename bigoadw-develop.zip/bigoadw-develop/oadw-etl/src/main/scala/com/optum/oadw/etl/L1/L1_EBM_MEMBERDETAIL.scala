
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ebm_memberdetail, ebm_memberdetail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_EBM_MEMBERDETAIL extends TableInfo[l1_ebm_memberdetail]{
  override def dependsOn: Set[String] = Set("EBM_MEMBERDETAIL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_EBM_MEMBERDETAIL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ebmMemberdetail = loadedDependencies("EBM_MEMBERDETAIL").as[ebm_memberdetail]

    ebmMemberdetail
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi".as("mpi"),
			$"birth_date",
			$"gender",
			$"pcp1",
			$"pcp1_spec",
			$"pcp1_flag",
			$"pcp2",
			$"pcp2_spec",
			$"pcp2_flag",
			$"pcp3",
			$"pcp3_spec",
			$"pcp3_flag",
			$"imp_prov",
			$"imp_prov_spec",
			$"imp_prov_flag",
			$"imp_ob_prov",
			$"imp_ob_prov_spec",
			$"imp_ob_prov_flag",
			$"age",
			$"age_in_months",
			$"report_per_end".as("report_per_end_dt"),
			$"med",
			$"rx",
			$"file_processing_month".as("file_processing_month_dt"),
			$"process"
    )
  }
}


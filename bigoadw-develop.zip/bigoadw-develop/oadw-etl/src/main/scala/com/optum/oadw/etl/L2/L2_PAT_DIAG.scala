package com.optum.oadw.etl.L2

import java.sql.Timestamp

import com.optum.oadw.definedfunctions.{ BitOrAgg, ListAgg }
import com.optum.oadw.etl.constants.Precursors
import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{ DataFrame, Dataset, SparkSession }

object L2_PAT_DIAG extends TableInfo[l2_pat_diag] {
  import com.optum.oadw.utils.DataframeExtensions._

  def directoryLevel = "L2"

  override def name = "L2_PAT_DIAG"

  override def dependsOn =
    Set(
      "MD_OADW_INSTANCE",
      "L1_MAP_ADMIT_DIAG",
      "L2_MAP_CDS_FLG",
      "L1_DIAGNOSIS",
      "L1_MAP_ACTIVE_DIAG_IND",
      "L1_MAP_CLIENT_DATASRC_TYPE",
      "L1_CLINICAL_EVENT_ENCOUNTER",
      "L1_MAP_DISCHARGE_DIAG",
      "L1_MAP_DIAGNOSIS_STATUS",
      "L1_MAP_PROB_LIST",
      "L2_DICT_DIAG"
    )

  override def createDataFrame(
    sparkSession: SparkSession,
    loadedDependencies: Map[String, DataFrame],
    udfMap: Map[String, UserDefinedFunctionForDataLoader],
    runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val tMdOadwInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]

    val dataThru =
      tMdOadwInstance
        .where($"attribute_name" === lit("DATA_THRU"))
        .select(to_date($"attribute_value", "yyyyMMdd"))
        .as[Timestamp]
        .collect()
        .head

    val l1Diagnosis = loadedDependencies("L1_DIAGNOSIS")
      .as[l1_diagnosis]
      .alias("l1Diagnosis")
      .where(
        $"codetype".isin("ICD9", "ICD10")
        && $"mpi".isNotNull
        && $"mappeddiagnosis".isNotNull
        && to_date($"diag_dtm", "yyyyMMdd") <= dataThru)

    val l1MapClientDatasrcType = loadedDependencies("L1_MAP_CLIENT_DATASRC_TYPE").as[l1_map_client_datasrc_type].alias("l1MapClientDatasrcType")
    val tL2MapCdsFlg           = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg].alias("tL2MapCdsFlg")
    val tL2DictDiag            = loadedDependencies("L2_DICT_DIAG").as[l2_dict_diag].alias("tL2DictDiag")
    val l1MapAdmitDiag         = loadedDependencies("L1_MAP_ADMIT_DIAG").as[l1_map_admit_diag].as("l1MapadmitDiag")
    val l1MapDiagStatus        = loadedDependencies("L1_MAP_DIAGNOSIS_STATUS").as[l1_map_diagnosis_status].alias("l1MapDiagStatus")
    val l1MapDischargeDiag     = loadedDependencies("L1_MAP_DISCHARGE_DIAG").castToLong(Set("dts_version")).as[l1_map_discharge_diag].alias("l1MapDischargeDiag")
    val l1MapActiveDiagInd     = loadedDependencies("L1_MAP_ACTIVE_DIAG_IND").as[l1_map_active_diag_ind].alias("l1MapActiveDiagInd")
    val l1MapProbList          = loadedDependencies("L1_MAP_PROB_LIST").as[l1_map_prob_list].alias("l1MapProbList")
    val tl1ClinEventEnc        = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").as[l1_clinical_event_encounter].alias("tl1ClinEventEnc")

    val PatDiag = createL2PatDiag(
      sparkSession,
      l1Diagnosis,
      tL2MapCdsFlg,
      tL2DictDiag,
      l1MapClientDatasrcType,
      l1MapAdmitDiag,
      l1MapDiagStatus,
      l1MapDischargeDiag,
      l1MapActiveDiagInd,
      l1MapProbList,
      tl1ClinEventEnc
    )
    PatDiag
  }

  private def createL2PatDiag(
    sparkSession: SparkSession,
    l1Diagnosis: Dataset[l1_diagnosis],
    tL2MapCdsFlg: Dataset[l2_map_cds_flg],
    tL2DictDiag: Dataset[l2_dict_diag],
    l1MapClientDatasrcType: Dataset[l1_map_client_datasrc_type],
    l1MapAdmitDiag: Dataset[l1_map_admit_diag],
    l1MapDiagStatus: Dataset[l1_map_diagnosis_status],
    l1MapDischargeDiag: Dataset[l1_map_discharge_diag],
    l1MapActiveDiagInd: Dataset[l1_map_active_diag_ind],
    l1MapProbList: Dataset[l1_map_prob_list],
    tl1ClinEventEnc: Dataset[l1_clinical_event_encounter]) = {

    import sparkSession.implicits._

    val listAgg  = new ListAgg()

    val l2PatDiag = l1Diagnosis
      .join(
        broadcast(tL2MapCdsFlg),
        $"l1Diagnosis.client_id" === $"tL2MapCdsFlg.client_id" &&
        $"l1Diagnosis.client_ds_id" === $"tL2MapCdsFlg.client_ds_id",
        "inner")
      .join(
        broadcast(tL2DictDiag),
        $"l1Diagnosis.codetype" === $"tL2DictDiag.code_type" &&
        $"l1Diagnosis.mappeddiagnosis" === $"tL2DictDiag.diag_cd",
        "inner")
      .join(
        broadcast(l1MapClientDatasrcType),
        $"l1Diagnosis.client_ds_id" === $"l1MapClientDatasrcType.client_ds_id" &&
        $"l1Diagnosis.datasrc" === $"l1MapClientDatasrcType.datasrc",
        "left_outer"
      )
      .join(
        broadcast(l1MapAdmitDiag),
        $"l1Diagnosis.client_id" === $"l1MapAdmitDiag.client_id" &&
        $"l1Diagnosis.localadmitflg" === $"l1MapAdmitDiag.local_code",
        "left_outer"
      )
      .join(
        broadcast(l1MapDischargeDiag),
        $"l1Diagnosis.client_id" === $"l1MapDischargeDiag.client_id" &&
        $"l1Diagnosis.localdischargeflg" === $"l1MapDischargeDiag.local_code",
        "left_outer"
      )
      .join(
        broadcast(l1MapDiagStatus),
        $"l1Diagnosis.client_id" === $"l1MapDiagStatus.client_id" &&
        $"l1Diagnosis.localdiagnosisstatus" === $"l1MapDiagStatus.local_code",
        "left_outer"
      )
      .join(
        broadcast(l1MapActiveDiagInd),
        $"l1Diagnosis.client_id" === $"l1MapActiveDiagInd.client_id" &&
        $"l1Diagnosis.localactiveind" === $"l1MapActiveDiagInd.local_code",
        "left_outer"
      )
      .join(
        broadcast(l1MapProbList),
        $"l1Diagnosis.client_id" === $"l1MapProbList.client_id" &&
        $"l1Diagnosis.datasrc" === $"l1MapProbList.datasrc",
        "left_outer")
      .join(
        tl1ClinEventEnc,
        $"l1Diagnosis.encounterid" === $"tl1ClinEventEnc.encounterid" &&
        $"l1Diagnosis.client_id" === $"tl1ClinEventEnc.client_id" &&
        $"l1Diagnosis.mpi" === $"tl1ClinEventEnc.mpi" &&
        $"l1Diagnosis.client_ds_id" === $"tl1ClinEventEnc.client_ds_id",
        "left_outer"
      )
      .select(
        $"l1Diagnosis.client_id",
        $"l1Diagnosis.mpi",
        $"l1Diagnosis.mappeddiagnosis".as("diag_cd"),
        $"l1Diagnosis.codetype".as("code_type"),
        to_date(date_format($"l1Diagnosis.diag_dtm", "yyyy-MM-dd")).as("diag_dt"),
        to_date(date_format($"l1Diagnosis.resolution_dt", "yyyy-MM-dd")).as("resolution_dt"),
        $"tL2MapCdsFlg.client_ds_id".as("client_ds_id"),
        $"tl1ClinEventEnc.encounter_grp_num".as("clinical_event_id"),
        when($"l1Diagnosis.localdiagnosisstatus".isNotNull, lit(1)).otherwise(lit(0)).as("flg"),
        coalesce($"l1MapDiagStatus.cui", lit(Precursors.CUI_INVALID)).as("status_cui"),
        when($"l1Diagnosis.mappedpresentonadmission" === lit(Precursors.POA_CUI_PRESENT_ON_ADMISSION), lit("AA1"))
          .when($"l1Diagnosis.mappedpresentonadmission" === lit(Precursors.POA_CUI_PRESENT_ON_ADMISSION_UNDETERMINED), lit("AA2"))
          .when($"l1Diagnosis.mappedpresentonadmission" === lit(Precursors.POA_CUI_NOT_PRESENT_ON_ADMISSION), lit("AA3"))
          .when($"l1Diagnosis.mappedpresentonadmission" === lit(Precursors.POA_CUI_PRESENT_ON_ADMISSION_UNKNOWN), lit("AA4"))
          .when($"l1Diagnosis.mappedpresentonadmission" === lit(Precursors.POA_CUI_PRESENT_ON_ADMISSION_EXEMPT), lit("AA5"))
          .when($"l1Diagnosis.mappedpresentonadmission" === lit(Precursors.CUI_NULL), lit("AA6"))
          .when($"l1Diagnosis.mappedpresentonadmission" === lit(Precursors.CUI_INVALID), lit("AA7"))
          .otherwise($"l1Diagnosis.mappedpresentonadmission")
          .as("poa_cui"),
        coalesce($"l1Diagnosis.primarydiagnosis", lit(0)).as("primary_ind"),
        lit(0).as("inferred_ind").cast(IntegerType),
        when($"l1MapadmitDiag.cui" === "CH001387", lit(1)).otherwise(lit(0)).as("admit_ind"),
        when($"l1MapDischargeDiag.cui".isin("CH001557", "CH001585"), lit(1)).otherwise(lit(0)).as("discharge_ind"),
        when($"l1Diagnosis.hosp_dx_flag" === lit("Y"), lit(1)).otherwise(lit(0)).as("hosp_dx_ind"),
        when($"l1MapProbList.is_problemlist" === lit("Y"), lit(1)).otherwise(lit(0)).as("problemlist_ind"),
        $"tL2DictDiag.sensitive_ind",
        when($"tL2MapCdsFlg.source_type_flg".isin(1, 2), lit(1)) // type is Payer or Billing
          .when(
            $"tL2MapCdsFlg.source_type_flg" === lit(8)
            && $"l1MapClientDatasrcType.cui" === "CH002126",
            lit(1)) // type is Mixed (EMR+Billing, like Epic),  'CH002126' indicates the datasrc is Billing
          .otherwise(lit(0))
          .as("bill_claim_ind"),
        when($"l1Diagnosis.hosp_dx_flag" === lit("Y") && $"l1Diagnosis.primarydiagnosis" === lit(1), lit(1)).otherwise(lit(0)).as("primary_hosp_dx_ind")
      )
      .groupBy(
        $"client_id",
        $"mpi",
        $"diag_cd",
        $"code_type",
        to_date(date_format($"diag_dt", "yyyy-MM-dd")).as("diag_dt"),
        $"clinical_event_id",
        $"inferred_ind"
      )
      .agg(
        min($"resolution_dt").as("resolution_dt"),
        min($"status_cui").as("status_cui"),
        max($"flg").as("flg"),
        min($"poa_cui").as("poa_cui"),
        listAgg($"client_ds_id").as("cds_grp"),
        max($"primary_ind").as("primary_ind"),
        max($"admit_ind").cast(IntegerType).as("admit_ind"),
        max($"discharge_ind").cast(IntegerType).as("discharge_ind"),
        max($"hosp_dx_ind").cast(IntegerType).as("hosp_dx_ind"),
        max($"problemlist_ind").cast(IntegerType).as("problemlist_ind"),
        max($"sensitive_ind").cast(IntegerType).as("sensitive_ind"),
        max($"bill_claim_ind").cast(IntegerType).as("bill_claim_ind"),
        max($"primary_hosp_dx_ind").cast(IntegerType).as("primary_hosp_dx_ind")
      )
      .select(
        $"client_id",
        $"mpi",
        $"diag_cd",
        $"code_type",
        to_timestamp($"resolution_dt", "yyyy-MM-dd").as("resolution_dt"),
        to_timestamp($"diag_dt", "yyyy-MM-dd").as("diag_dt"),
        $"clinical_event_id",
        when($"clinical_event_id".isNull, 0).otherwise($"clinical_event_id").as("clinical_evt_key"),
        $"inferred_ind",
        when($"flg" === lit(1), $"status_cui").otherwise(lit(Precursors.CUI_NULL)).as("status_cui"),
        when($"poa_cui" === lit("AA1"), lit(Precursors.POA_CUI_PRESENT_ON_ADMISSION))
          .when($"poa_cui" === lit("AA2"), lit(Precursors.POA_CUI_PRESENT_ON_ADMISSION_UNDETERMINED))
          .when($"poa_cui" === lit("AA3"), lit(Precursors.POA_CUI_NOT_PRESENT_ON_ADMISSION))
          .when($"poa_cui" === lit("AA4"), lit(Precursors.POA_CUI_PRESENT_ON_ADMISSION_UNKNOWN))
          .when($"poa_cui" === lit("AA5"), lit(Precursors.POA_CUI_PRESENT_ON_ADMISSION_EXEMPT))
          .when($"poa_cui" === lit("AA6"), lit(Precursors.CUI_NULL))
          .when($"poa_cui" === lit("AA7"), lit(Precursors.CUI_INVALID))
          .otherwise($"poa_cui")
          .as("poa_cui"),
        $"cds_grp",
        $"primary_ind",
        $"admit_ind",
        $"discharge_ind",
        $"hosp_dx_ind",
        $"problemlist_ind",
        $"sensitive_ind",
        $"bill_claim_ind",
        $"primary_hosp_dx_ind"
      )

    l2PatDiag
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_observation, map_observation}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_OBSERVATION extends TableInfo[l1_map_observation]{
  override def dependsOn: Set[String] = Set("MAP_OBSERVATION")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_OBSERVATION"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapObservation = loadedDependencies("MAP_OBSERVATION").as[map_observation]

    mapObservation
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"localcode".as("local_code"),
			$"obstype",
			$"cui",
			$"obsregex",
			$"localunit",
			$"dts_version",
			$"zero_to_null",
			$"local_name",
			$"localunit_cui"
    )
  }
}


package com.optum.oadw.etl.L2

import com.optum.oadw.definedfunctions.{BitOrAggFunction, ListAggFunction}
import java.sql.Timestamp
import java.util.NoSuchElementException

import org.apache.spark.sql.functions._
import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_PATIENT_ATTR extends TableInfo[l2_patient_attr] {
  override def name: String = "L2_PATIENT_ATTR"

  override def dependsOn: Set[String] = Set("L1_PATIENT_ATTRIBUTE","L2_MAP_CDS_FLG")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1PatientAttribute = loadedDependencies("L1_PATIENT_ATTRIBUTE").as[l1_patient_attribute].as("pat")
    val tL2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg].as("mcf")

    val bitoragg = BitOrAggFunction.bitOrAgg
    val listAgg = ListAggFunction.listAgg

    val tempWithDates = l1PatientAttribute
      .where(   ($"mpi".isNotNull) && ($"attribute_type_cui".isNotNull) && ($"attribute_value".isNotNull)
             && not($"attribute_type_cui".isin("CH003517", "CH003514", "CH003513"))
      )
      .join(tL2MapCdsFlg, $"pat.client_id" === $"mcf.client_id" &&
        $"pat.client_ds_id" === $"mcf.client_ds_id")
      .groupBy(
        $"pat.client_id",
        $"pat.mpi",
        $"pat.attribute_type_cui".as("attr_cui"),
        $"pat.attribute_value".as("attr_value"),
        $"pat.eff_date".as("attr_start_dt"),
        $"pat.end_date".as("attr_end_dt"))
      .agg(listAgg($"mcf.client_ds_id").as("cds_grp")
      )

    val lastIndWindow = Window.partitionBy($"client_id", $"mpi", $"attr_cui" )

    val tempWithWindowCols = tempWithDates
      .withColumn("last_ind_window_no_null",
      row_number.over(lastIndWindow.orderBy($"attr_end_dt".desc_nulls_first,
        $"attr_start_dt".desc_nulls_last,
        $"attr_value".desc))
      )
      .withColumn("last_ind_window_with_null",
        row_number.over(lastIndWindow.orderBy($"attr_start_dt".desc_nulls_last,
          $"attr_end_dt".desc_nulls_first,
          $"attr_value".desc))
      )
      .withColumn("has_null_start",
        when($"attr_start_dt".isNull, lit(1)).otherwise(lit(0))
      )

    val colOrder = Seq($"client_id", $"mpi", $"attr_cui", $"attr_value", $"cds_grp", $"attr_start_dt",
      $"attr_end_dt", $"last_ind")

    tempWithWindowCols
      .withColumn("last_ind",
        when(max($"has_null_start").over(lastIndWindow) === lit(0),
          when($"last_ind_window_no_null" === lit(1), lit(1)).otherwise(lit(0))
        ).otherwise(
          when($"last_ind_window_with_null" === lit(1), lit(1)).otherwise(lit(0))
        )
      ).select(colOrder: _*)

  }
}

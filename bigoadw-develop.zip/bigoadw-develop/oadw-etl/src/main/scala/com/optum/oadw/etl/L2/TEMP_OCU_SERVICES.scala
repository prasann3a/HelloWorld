package com.optum.oadw.etl.L2

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_ocu_services_data(year_mth_id: java.lang.Integer, year_mth_pd: java.lang.Integer, new_mem_attr_id: java.lang.Integer,
                                  provider_id: String, pos_i: java.lang.Integer, prv_sp_4: java.lang.Integer, dis_rel: java.lang.Integer,
                                  drg_id: String, admit_source: java.lang.Integer, tos_i_5: java.lang.Integer,
                                  network_paid_status_id: String, provider_status_id: String, episode_id: java.lang.Long,
                                  sev_level: java.lang.Integer, etg_id: java.lang.Integer, encounter: scala.math.BigDecimal,
                                  em_svc_flag: java.lang.Integer, rad_util: scala.math.BigDecimal, lab_util: scala.math.BigDecimal,
                                  mri_util: scala.math.BigDecimal, er_util: scala.math.BigDecimal, los: java.lang.Integer,
                                  admit: java.lang.Integer, script: scala.math.BigDecimal, amt_req: scala.math.BigDecimal, amt_eqv: scala.math.BigDecimal,
                                  amt_ded: scala.math.BigDecimal, amt_coin: scala.math.BigDecimal, amt_cop: scala.math.BigDecimal,
                                  amt_liab: scala.math.BigDecimal, amt_cap_pay: scala.math.BigDecimal, amt_pay: scala.math.BigDecimal,
                                  amt_np: scala.math.BigDecimal)

object TEMP_OCU_SERVICES extends QueryAndMetadata[temp_ocu_services_data] {
  override def name: String = "TEMP_OCU_SERVICES"

  override def sparkSql: String = """SELECT MD1.YEAR_MTH_ID as YEAR_MTH_ID,MD2.YEAR_MTH_ID as  YEAR_MTH_PD, OM.NEW_MEM_ATTR_ID,
CF.PROVIDER_ID, CF.POS_I, CF.PRV_SP_4,
case when CF.DISREL between 1 and 70 then disrel else 0 end as dis_rel,/*only want key set of diease ids*/
cf.drg_id,nvl2(conf1.conf_num,1,0) admit_source,CF.TOS_I_5, NETWORK_PAID_STATUS_ID, PROVIDER_STATUS_ID,CF.EPISODE_ID, CF.SEV_LEVEL, CF.ETG_ID,
CF.ENCOUNTER, 0 as EM_SVC_FLAG, 0   as RAD_UTIL, 0 as LAB_UTIL, 0 as MRI_UTIL, 0 as ER_UTIL,
nvl(CF.LOS,0) AS LOS,
case when CF.ADMIT = true then 1 when cf.admit = false then 0 else 0 end as ADMIT,
0   as SCRIPT, nvl(CF.AMT_REQ,0) AS AMT_REQ,
nvl(CF.AMT_EQV,0) AS AMT_EQV,  nvl(CF.AMT_DED,0) AS AMT_DED,nvl(CF.AMT_COIN,0) AS AMT_COIN,
nvl(CF.AMT_COP,0) AS AMT_COP, nvl(CF.AMT_LIAB,0) AS AMT_LIAB,  nvl(CF.AMT_CAP_PAY,0) AS AMT_CAP_PAY,
nvl(CF.AMT_PAY,0) AS AMT_PAY, nvl(CF.AMT_NP,0) AS AMT_NP
FROM L2_II_CONFINEMENTS CF
JOIN L2_II_MAP_DATE_RANGE MD1 ON MD1.MONTH_VAL = date_format(CF.BEG_DT,'MM') AND MD1.YEAR_VAL = date_format(CF.BEG_DT,'yyyy')
JOIN L2_II_MAP_DATE_RANGE MD2 ON MD2.MONTH_VAL = date_format(CF.PAY_DT,'MM') AND MD2.YEAR_VAL = date_format(CF.PAY_DT,'yyyy')
JOIN l2_ii_mem_attr_member_ext OM ON CF.MEMBER = OM.MEMBER AND OM.YEAR_MTH_ID = MD1.YEAR_MTH_ID
AND CF.BEG_DT BETWEEN OM.MEM_EFF_DT AND OM.MEM_END_DT
AND CF.BEG_DT BETWEEN OM.SUB_EFF_DT AND OM.SUB_END_DT
left join temp_er_confinements conf1 on conf1.conf_num = cf.conf_num
WHERE CF.EXCLUDE = 0
OR (CF.IA_TIME =  0 AND CF.NOENR_DOS = 0)
 UNION ALL
SELECT MD1.YEAR_MTH_ID as YEAR_MTH_ID, MD2.YEAR_MTH_ID as  YEAR_MTH_PD, OM.NEW_MEM_ATTR_ID,
SM.PROVIDER_ID, SM.POS_I, SM.PRV_SP_4,
case when SM.DISREL between 1 and 70 then disrel else 0 end as dis_rel,/*only want key set of diease ids*/'Unsp$UNK', 0 admit_source,
SM.TOS_I_5, NETWORK_PAID_STATUS_ID, PROVIDER_STATUS_ID,SM.EPISODE_ID, SM.SEV_LEVEL, SM.ETG_ID,
SM.ENCOUNTER,
case when SM.EM_SVC_FLAG = true then 1 when SM.EM_SVC_FLAG = false then 0 else null end AS EM_SVC_FLAG,
nvl(SM.RAD_UTIL,0) AS RAD_UTIL,
nvl(SM.LAB_UTIL,0) AS LAB_UTIL, nvl(SM.MRI_UTIL,0) AS MRI_UTIL, nvl(SM.ER_UTIL,0) AS ER_UTIL, 0 as LOS,
0 as ADMIT, 0 as SCRIPT,  nvl(SM.AMT_REQ,0) AS AMT_REQ, nvl(SM.AMT_EQV,0) AS AMT_EQV,nvl(SM.AMT_DED,0) AS AMT_DED,
nvl(SM.AMT_COIN,0) AS AMT_COIN,   nvl(SM.AMT_COP,0) AS AMT_COP, nvl(SM.AMT_LIAB,0) AS AMT_LIAB,
nvl(SM.AMT_CAP_PAY,0) AS AMT_CAP_PAY,nvl(SM.AMT_PAY,0) AS AMT_PAY, nvl(SM.AMT_NP,0) AS AMT_NP
FROM L2_II_SERVICES_MED SM
JOIN L2_II_MAP_DATE_RANGE MD1 ON MD1.MONTH_VAL = date_format(SM.DOS,'MM') AND MD1.YEAR_VAL = date_format(SM.DOS,'yyyy')
JOIN L2_II_MAP_DATE_RANGE MD2 ON MD2.MONTH_VAL = date_format(SM.PAY_DT,'MM') AND MD2.YEAR_VAL = date_format(SM.PAY_DT,'yyyy')
JOIN l2_ii_mem_attr_member_ext OM ON SM.MEMBER = OM.MEMBER AND OM.YEAR_MTH_ID = MD1.YEAR_MTH_ID
AND SM.DOS BETWEEN OM.MEM_EFF_DT AND OM.MEM_END_DT AND SM.DOS
BETWEEN OM.SUB_EFF_DT AND OM.SUB_END_DT
WHERE SM.EXCLUDE = 0
OR (SM.IA_TIME =  0 AND SM.NOENR_DOS = 0 AND SM.PSEUDO = 0)
 UNION ALL
SELECT MD1.YEAR_MTH_ID as YEAR_MTH_ID, MD2.YEAR_MTH_ID as  YEAR_MTH_PD, OM.NEW_MEM_ATTR_ID, SR.PROVIDER_ID, 99 as POS_I,
SR.PRV_SP_4, case when SR.DISREL between 1 and 70 then disrel else 0 end as dis_rel,
'Unsp$UNK' as DRG_ID,0 admit_source,SR.TOS_I_5, NETWORK_PAID_STATUS_ID, PROVIDER_STATUS_ID,SR.EPISODE_ID, SR.SEV_LEVEL, SR.ETG_ID,
SR.ENCOUNTER,0 as EM_SVC_FLAG, 0 as RAD_UTIL, 0 as LAB_UTIL, 0 as MRI_UTIL,
0 as ER_UTIL, 0 AS LOS,  0 AS ADMIT, nvl(SR.SCRIPT,0) AS SCRIPT,  nvl(SR.AMT_REQ,0) AS AMT_REQ,
nvl(SR.AMT_EQV,0) AS AMT_EQV,  nvl(SR.AMT_DED,0) AS AMT_DED, nvl(SR.AMT_COIN,0) AS AMT_COIN,
nvl(SR.AMT_COP,0) AS AMT_COP, nvl(SR.AMT_LIAB,0) AS AMT_LIAB,  0 AS AMT_CAP_PAY, nvl(SR.AMT_PAY,0) AS AMT_PAY,
nvl(SR.AMT_NP,0) AS AMT_NP
FROM L2_II_SERVICES_RX SR
JOIN L2_II_MAP_DATE_RANGE MD1 ON MD1.MONTH_VAL = date_format(SR.DOS,'MM')AND MD1.YEAR_VAL = date_format(SR.DOS,'yyyy')
JOIN L2_II_MAP_DATE_RANGE MD2 ON MD2.MONTH_VAL = date_format(SR.PAY_DT,'MM') AND MD2.YEAR_VAL = date_format(SR.PAY_DT,'yyyy')
JOIN l2_ii_mem_attr_member_ext OM ON SR.MEMBER = OM.MEMBER AND OM.YEAR_MTH_ID = MD1.YEAR_MTH_ID
AND SR.DOS BETWEEN OM.MEM_EFF_DT AND OM.MEM_END_DT
AND SR.DOS BETWEEN OM.SUB_EFF_DT AND OM.SUB_END_DT
WHERE SR.EXCLUDE = 0
OR (SR.IA_TIME = 0 AND SR.NOENR_DOS = 0 AND SR.PSEUDO = 0)"""

  override def dependsOn: Set[String] = Set("L2_II_CONFINEMENTS","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR_MEMBER_EXT","TEMP_ER_CONFINEMENTS","L2_II_SERVICES_MED","L2_II_SERVICES_RX")

  def originalSql: String = """

insert /*+ append */ into temp_ocu_services
SELECT MD1.YEAR_MTH_ID as YEAR_MTH_ID, MD2.YEAR_MTH_ID as  YEAR_MTH_PD, OM.NEW_MEM_ATTR_ID, SR.PROVIDER_ID, 99 as POS_I,
SR.PRV_SP_4, case when SR.DISREL between 1 and 70 then disrel else 0 end as dis_rel,/*only want key set of diease ids*/
'Unsp$UNK' as DRG_ID,0 admit_source,SR.TOS_I_5, NETWORK_PAID_STATUS_ID, PROVIDER_STATUS_ID,SR.EPISODE_ID, SR.SEV_LEVEL, SR.ETG_ID,
SR.ENCOUNTER,0 as EM_SVC_FLAG, 0 as RAD_UTIL, 0 as LAB_UTIL, 0 as MRI_UTIL,
0 as ER_UTIL, 0 AS LOS,  0 AS ADMIT, nvl(SR.SCRIPT,0) AS SCRIPT,  nvl(SR.AMT_REQ,0) AS AMT_REQ,
nvl(SR.AMT_EQV,0) AS AMT_EQV,  nvl(SR.AMT_DED,0) AS AMT_DED, nvl(SR.AMT_COIN,0) AS AMT_COIN,
nvl(SR.AMT_COP,0) AS AMT_COP, nvl(SR.AMT_LIAB,0) AS AMT_LIAB,  0 AS AMT_CAP_PAY, nvl(SR.AMT_PAY,0) AS AMT_PAY,
nvl(SR.AMT_NP,0) AS AMT_NP
FROM L2_II_SERVICES_RX SR
JOIN L2_II_MAP_DATE_RANGE MD1 ON MD1.MONTH_VAL = to_char(SR.DOS,'mm')AND MD1.YEAR_VAL = to_char(SR.DOS,'yyyy')
JOIN L2_II_MAP_DATE_RANGE MD2 ON MD2.MONTH_VAL = to_char(SR.PAY_DT,'mm') AND MD2.YEAR_VAL = to_char(SR.PAY_DT,'yyyy')
JOIN l2_ii_mem_attr_member_ext OM ON SR.MEMBER = OM.MEMBER AND OM.YEAR_MTH_ID = MD1.YEAR_MTH_ID
AND SR.DOS BETWEEN OM.MEM_EFF_DT AND OM.MEM_END_DT
AND SR.DOS BETWEEN OM.SUB_EFF_DT AND OM.SUB_END_DT
WHERE SR.EXCLUDE = 0
OR (SR.IA_TIME = 0 AND SR.NOENR_DOS = 0 AND SR.PSEUDO = 0)"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"





  override def partitions: Int = 128

  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}

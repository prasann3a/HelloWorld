package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels._
import com.optum.oadw.oadw_ref.models.{ l2_map_sensitive_category }
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{ DataFrame, SparkSession }

object L2_DICT_POS extends TableInfo[l2_dict_pos] {
  override def name = "L2_DICT_POS"

  override def dependsOn = Set("L1_REF_IMAP_POS", "L2_MAP_SENSITIVE_CATEGORY")

  def directoryLevel = "L2"

  override def createDataFrame(
    sparkSession: SparkSession,
    loadedDependencies: Map[String, DataFrame],
    udfMap: Map[String, UserDefinedFunctionForDataLoader],
    runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l1RefImapPos           = loadedDependencies("L1_REF_IMAP_POS").as[l1_ref_imap_pos]
    val l2MapSensitiveCategory = broadcast(loadedDependencies("L2_MAP_SENSITIVE_CATEGORY").as[l2_map_sensitive_category])

    l1RefImapPos
      .join(l2MapSensitiveCategory.as("sc"), expr("UPPER(POS_DESC) LIKE CONCAT('%', UPPER(sc.sensitive_text), '%')"), "left_outer")
      .select(
        $"pos_i".cast(IntegerType),
        lpad($"pos_i", 2, "0").as("place_of_svc"),
        $"pos_desc",
        $"sensitive_ind",
        when($"sensitive_ind" === lit(1), coalesce($"sc.sensitive_cat_id", lit(999)))
          .otherwise(lit(1))
          .as("sensitive_cat_id"),
        when($"sensitive_ind" === lit(1), row_number().over(Window.partitionBy($"pos_i").orderBy($"sensitive_hierarchy")))
          .otherwise(lit(1))
          .as("order")
      )
      .where($"order" === 1)
      .drop("order")
  }
}

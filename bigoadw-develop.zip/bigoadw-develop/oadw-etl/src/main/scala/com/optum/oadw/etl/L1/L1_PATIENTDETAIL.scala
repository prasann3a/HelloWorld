
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patientdetail, patientdetail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENTDETAIL extends TableInfo[l1_patientdetail]{
  override def dependsOn: Set[String] = Set("PATIENTDETAIL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENTDETAIL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientdetail = loadedDependencies("PATIENTDETAIL").as[patientdetail]

    patientdetail
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"facilityid",
			$"patientid",
			$"encounterid",
			$"patientdetailtype",
			$"patientdetailqual",
			$"localvalue",
			$"patdetail_timestamp".as("patdetail_dtm"),
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi")
    )
  }
}


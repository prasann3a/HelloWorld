
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_v_provider_master, zh_v_provider_master}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_V_PROVIDER_MASTER extends TableInfo[l1_v_provider_master]{
  override def dependsOn: Set[String] = Set("ZH_V_PROVIDER_MASTER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_V_PROVIDER_MASTER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhVProviderMaster = loadedDependencies("ZH_V_PROVIDER_MASTER").as[zh_v_provider_master]

    zhVProviderMaster
    .select(
			$"groupid".as("client_id"),
			$"master_hgprovid".as("prov_id"),
			$"npi",
			$"providername",
			$"localprimaryspecialty",
			$"primaryfacilityid",
			$"primaryspecialty",
			$"primspecname",
			$"primspecgrp",
			$"primspecgroupname",
			$"npiprimarycode",
			$"npiprimaryspecialty",
			$"npiprimspecname",
			$"npiprimspecgroup",
			$"npiprimspecgroupname",
			$"providerexclusionflag",
			$"mappedcredentialtype"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_bpo_provider_detail_spans, pp_bpo_provider_detail_spans}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_BPO_PROVIDER_DETAIL_SPANS extends TableInfo[l1_bpo_provider_detail_spans]{
  override def dependsOn: Set[String] = Set("PP_BPO_PROVIDER_DETAIL_SPANS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_BPO_PROVIDER_DETAIL_SPANS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ppBpoProviderDetailSpans = loadedDependencies("PP_BPO_PROVIDER_DETAIL_SPANS").as[pp_bpo_provider_detail_spans]

    ppBpoProviderDetailSpans
    .select(
			$"cust_prov_attr1",
			$"cust_prov_attr10",
			$"cust_prov_attr11",
			$"cust_prov_attr12",
			$"cust_prov_attr13",
			$"cust_prov_attr14",
			$"cust_prov_attr15",
			$"cust_prov_attr16",
			$"cust_prov_attr17",
			$"cust_prov_attr18",
			$"cust_prov_attr19",
			$"cust_prov_attr2",
			$"cust_prov_attr20",
			$"cust_prov_attr3",
			$"cust_prov_attr4",
			$"cust_prov_attr5",
			$"cust_prov_attr6",
			$"cust_prov_attr7",
			$"cust_prov_attr8",
			$"cust_prov_attr9",
			$"final_flag",
			$"final_network_flag",
			$"groupid".as("client_id"),
			$"npi",
			$"pcpflag",
			$"prov_effective_dt".as("prov_eff_dt"),
			$"prov_end_dt",
			$"prov_geo_lat",
			$"prov_geo_lon",
			$"prov_userdef_1",
			$"prov_userdef_2",
			$"provaddress1",
			$"provaddress2",
			$"provaffiliationid",
			$"provcity",
			$"provemail",
			$"provider_status",
			$"providerfirstname",
			$"providerid".as("prov_id"),
			$"providerlastname",
			$"providername",
			$"provphone",
			$"provstate",
			$"provzip",
			$"secondaryspecialty",
			$"sec_provider_id".as("sec_prov_id"),
			$"specialty"
    )
  }
}


package com.optum.oadw.etl.L2

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_pat_assess_qual
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_PAT_ASSESS_QUAL extends TableInfo[l2_pat_assess_qual] {
  override def name: String = "L2_PAT_ASSESS_QUAL"

  override def dependsOn: Set[String] = Set("TEMP_L2_PAT_ASSESS_BUILD_COMMON_OBS", "TEMP_L2_PAT_ASSESS_BUILD_COMMON_LAB", "L2_DICT_ASSESSMENT")

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_assess_build.sql"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val patAssessCommonObs = loadedDependencies("TEMP_L2_PAT_ASSESS_BUILD_COMMON_OBS").alias("patAssessCommonObs")
    val patAssessCommonLab = loadedDependencies("TEMP_L2_PAT_ASSESS_BUILD_COMMON_LAB").alias("patAssessCommonLab")
    val dictAssess = loadedDependencies("L2_DICT_ASSESSMENT")

    val result = getResultsFromCommonObs(sparkSession, patAssessCommonObs).union(getResultsFromCommonLab(sparkSession, patAssessCommonLab))
    result.withColumn("clinical_evt_key", expr("nvl(clinical_event_id, 0)")).toDF()
      .as("result")
      .join(broadcast(dictAssess).as("dict"), $"dict.assessment_cui" === $"result.assessment_cui", "left_outer")
      .select(
        $"result.assessment_cui",
        $"result.assessment_dtm",
        $"result.cds_grp",
        $"result.client_id",
        $"result.clinical_event_id",
        $"result.clinical_evt_key",
        $"result.hosp_ind",
        $"result.inferred_ind",
        $"result.mpi",
        $"result.nlp_ind",
        coalesce($"dict.sensitive_ind", $"result.sensitive_ind").as("sensitive_ind"),
        $"result.value_cui"
      ).distinct()
  }

  private def getResultsFromCommonObs(sparkSession: SparkSession,
                                    patAssessCommonObs: DataFrame): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    patAssessCommonObs.where($"value_cui".isNotNull)
      .select(
        $"client_id",
        $"mpi",
        $"assessment_dtm",
        $"cds_grp",
        $"assessment_cui",
        $"value_cui",
        $"clinical_event_id",
        $"nlp_ind",
        $"hosp_ind",
        lit(0).as("sensitive_ind"),
        lit(0).as("inferred_ind"))
  }

  private def getResultsFromCommonLab(sparkSession: SparkSession,
                                    patAssessCommonLab: DataFrame): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    patAssessCommonLab.where($"numeric_value".isNull && $"result_type".isin("CH003060", "CH003061"))
      .select(
        $"client_id",
        $"mpi",
        $"assessment_dtm",
        $"cds_grp",
        $"assessment_cui",
        $"qual_value".as("value_cui"),
        $"clinical_event_id",
        $"nlp_ind",
        $"hosp_ind",
        lit(0).as("sensitive_ind"),
        lit(0).as("inferred_ind")
      )
  }
}

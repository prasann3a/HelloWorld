package com.optum.oadw.etl.L1

import com.optum.oadw.common.models.OADWRuntimeVariables
import com.optum.oadw.oadwModels.l1_iqiindividual
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.{DecimalType, IntegerType, LongType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.net.URI
import org.apache.hadoop.fs.{FileSystem, Path}

object L1_IQIINDIVIDUAL extends TableInfo[l1_iqiindividual]{
  override def dependsOn: Set[String] = Set()

  override def name: String = "L1_IQIINDIVIDUAL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val oadwRuntimeVariables = OADWRuntimeVariables(runtimeVariables)

    val filePath = oadwRuntimeVariables.protocol match {

      case "s3" => s"s3://${oadwRuntimeVariables.bucket.get}/${oadwRuntimeVariables.environment}/external/ahrq/${oadwRuntimeVariables.cdrCycle}/${oadwRuntimeVariables.instance}/IQIINDIVIDUAL"
      case "hdfs" => s"hdfs://somhorton1/optum/data_factory/${oadwRuntimeVariables.clientId}/${oadwRuntimeVariables.environment}/external/ahrq/${oadwRuntimeVariables.cdrCycle}/${oadwRuntimeVariables.instance}/IQIINDIVIDUAL"
      case "test" => s"${oadwRuntimeVariables.extras.get("filePath").head}"
      case "" => return Seq.empty[l1_iqiindividual].toDF  // no protocol for query testing framework
      case _ => throw new IllegalArgumentException
    }

    val fs: FileSystem = FileSystem.get(URI.create(filePath), sparkSession.sparkContext.hadoopConfiguration)

    if (!fs.exists(new Path(filePath))){
      return Seq.empty[l1_iqiindividual].toDF
    }

    val iqiIndividual = sparkSession.read
      .format("csv")
      .option("header", "true")
      .load(filePath)

    iqiIndividual
      .select(
        $"key".cast(LongType).as("encounter_grp_num"),
        $"age".cast(IntegerType),
        $"sex".cast(IntegerType),
        $"hospid".cast(LongType),
        $"drg".cast(IntegerType),
        $"year".cast(IntegerType),
        $"dqtr".cast(IntegerType),
        $"mdc".cast(IntegerType),
        $"apr_drg".cast(IntegerType),
        $"aprdrg_risk_mortality".cast(IntegerType),
        $"paycat".cast(IntegerType),
        $"racecat".cast(IntegerType),
        $"agecat".cast(IntegerType),
        $"sexcat".cast(IntegerType),
        $"tpiq08".cast(IntegerType),
        $"tpiq09".cast(IntegerType),
        $"tpiq09_with_cancer".cast(IntegerType),
        $"tpiq09_without_cancer".cast(IntegerType),
        $"tpiq11".cast(IntegerType),
        $"tpiq11_open_ruptured".cast(IntegerType),
        $"tpiq11_open_unruptured".cast(IntegerType),
        $"tpiq11_endo_ruptured".cast(IntegerType),
        $"tpiq11_endo_unruptured".cast(IntegerType),
        $"tpiq12".cast(IntegerType),
        $"tpiq15".cast(IntegerType),
        $"tpiq16".cast(IntegerType),
        $"tpiq17".cast(IntegerType),
        $"tpiq17_hemstroke_subarach".cast(IntegerType),
        $"tpiq17_hemstroke_intracer".cast(IntegerType),
        $"tpiq17_ischemstroke".cast(IntegerType),
        $"tpiq18".cast(IntegerType),
        $"tpiq19".cast(IntegerType),
        $"tpiq20".cast(IntegerType),
        $"tpiq30".cast(IntegerType),
        $"tpiq31".cast(IntegerType),
        $"tpiq33".cast(IntegerType),
        $"trnsfer".cast(IntegerType),
        $"tpiqmhat08".cast(DecimalType(18,10)),
        $"tpiqmhat09_with_cancer".cast(DecimalType(18,10)),
        $"tpiqmhat09_without_cancer".cast(DecimalType(18,10)),
        $"tpiqmhat11_open_ruptured".cast(DecimalType(18,10)),
        $"tpiqmhat11_open_unruptured".cast(DecimalType(18,10)),
        $"tpiqmhat11_endo_ruptured".cast(DecimalType(18,10)),
        $"tpiqmhat11_endo_unruptured".cast(DecimalType(18,10)),
        $"tpiqmhat12".cast(DecimalType(18,10)),
        $"tpiqmhat15".cast(DecimalType(18,10)),
        $"tpiqmhat16".cast(DecimalType(18,10)),
        $"tpiqmhat17_hemstroke_subarach".cast(DecimalType(18,10)),
        $"tpiqmhat17_hemstroke_intracer".cast(DecimalType(18,10)),
        $"tpiqmhat17_ischemstroke".cast(DecimalType(18,10)),
        $"tpiqmhat18".cast(DecimalType(18,10)),
        $"tpiqmhat19".cast(DecimalType(18,10)),
        $"tpiqmhat20".cast(DecimalType(18,10)),
        $"tpiqmhat30".cast(DecimalType(18,10)),
        $"tpiqmhat31".cast(DecimalType(18,10))
      )
  }

}

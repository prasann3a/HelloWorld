
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ebm_drugadherence, ebm_drugadherence}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_EBM_DRUGADHERENCE extends TableInfo[l1_ebm_drugadherence]{
  override def dependsOn: Set[String] = Set("EBM_DRUGADHERENCE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_EBM_DRUGADHERENCE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ebmDrugadherence = loadedDependencies("EBM_DRUGADHERENCE").as[ebm_drugadherence]

    ebmDrugadherence
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi".as("mpi"),
			$"report_case_id",
			$"event",
			$"report_rule_id",
			$"drug_class",
			$"class_type",
			$"ndc",
			$"fill_beg".as("fill_beg_dt"),
			$"fill_end".as("fill_end_dt"),
			$"first_unique_rec_id",
			$"last_unique_rec_id",
			$"first_fill".as("first_fill_dt"),
			$"last_fill".as("last_fill_dt"),
			$"prov",
			$"prov_spec",
			$"prov_part_code",
			$"poss_ratio",
			$"elapsed_days",
			$"days_sup",
			$"script_cnt",
			$"calc_type",
			$"file_processing_month",
			$"process"
    )
  }
}


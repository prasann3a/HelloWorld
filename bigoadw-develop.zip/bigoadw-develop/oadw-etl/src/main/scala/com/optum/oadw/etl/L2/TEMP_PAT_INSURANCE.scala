package com.optum.oadw.etl.L2

import java.sql.Timestamp

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_pat_insurance_data(client_id: String, client_ds_id: java.lang.Integer, mpi: String, source_type_flg: java.lang.Integer,
                                   contract_hier: java.lang.Integer, encounterid_ind: java.lang.Integer, insuranceorder: java.lang.Integer,
                                   enrollend_dt: Timestamp, enrollstart_dt: Timestamp, payer_cnt: java.lang.Long,
                                   lob_cui: String, payer_cui: String, startdate: java.sql.Date, enddate: java.sql.Date, no_enc_ind: java.lang.Integer,
                                   plancode: String, planname: String )

object TEMP_PAT_INSURANCE extends QueryAndMetadata[temp_pat_insurance_data] {
  override def name: String = "TEMP_PAT_INSURANCE"

  override def sparkSql: String = """SELECT
i.client_id, i.client_ds_id, i.mpi, i.plancode, i.planname,
CASE WHEN cds.source_type_flg = 1 THEN 1 --payer
WHEN cds.source_type_flg = 2 THEN 2 --standalone billing
WHEN cds.source_type_flg = 8 THEN 3 --mixed billing and emr
WHEN cds.source_type_flg = 4 THEN 4 --emr alone
ELSE 5
END source_type_flg
,nvl(rlp.contract_hier,999) contract_hier
,CASE WHEN cds.source_type_flg != 1 THEN NVL2(encounterid,0,1)
ELSE 0
END encounterid_ind
,insuranceorder
,CASE WHEN cds.source_type_flg = 1 THEN i.enrollend_dt
ELSE NULL
END enrollend_dt
,CASE WHEN cds.source_type_flg = 1 THEN i.enrollstart_dt
ELSE NULL
END enrollstart_dt
,COUNT(*) OVER (PARTITION BY i.client_id, i.mpi,  trunc(NVL(enrollstart_dt, insurance_dt), 'MONTH'), COALESCE(fc.cui, mappedplanfincode, 'CH999999'), NVL(mappedpayorcode, 'CH999999')) AS payer_cnt
,COALESCE(fc.cui, mappedplanfincode, 'CH999999') AS lob_cui
,NVL(mappedpayorcode, 'CH999999') AS payer_cui
, trunc(NVL(enrollstart_dt, insurance_dt), 'MONTH') AS startdate
,NVL2(enrollstart_dt, LAST_DAY(coalesce(enrollend_dt, smry.date_of_death, data_end_dt)), LAST_DAY(insurance_dt)) AS enddate
,NVL2(encounterid,0,1) AS no_enc_ind
FROM L1_INSURANCE i
INNER JOIN L2_map_cds_flg cds on (i.client_id = cds.client_id AND i.client_ds_id = cds.client_ds_id)
LEFT JOIN L1_MAP_FINANCIAL_CLASS fc ON (i.client_id = fc.client_id AND i.plantype = fc.local_code)
CROSS JOIN (SELECT * FROM L4_TIMEFRAME WHERE TIMEFRAME_ID = 7) O
JOIN L1_PATIENT_SUMMARY_GRP_MPI smry on (smry.mpi = i.mpi)
LEFT OUTER JOIN L1_MAP_EMPLOYER bpo on (bpo.client_ds_id = i.client_ds_id)
LEFT OUTER JOIN L1_CONTRACT_ROLLUP rlp on (rlp.client_ds_id = i.client_ds_id and coalesce(i.contract_id,bpo.employeraccountid) = rlp.contract_id)
WHERE COALESCE(CUI, MAPPEDPLANFINCODE, MAPPEDPAYORCODE) IS NOT NULL
AND i.mpi IS NOT NULL"""

  override def dependsOn: Set[String] = Set("L4_TIMEFRAME","L2_MAP_CDS_FLG","L1_MAP_FINANCIAL_CLASS","L1_INSURANCE", "L1_PATIENT_SUMMARY_GRP_MPI", "L1_MAP_EMPLOYER", "L1_CONTRACT_ROLLUP")

}


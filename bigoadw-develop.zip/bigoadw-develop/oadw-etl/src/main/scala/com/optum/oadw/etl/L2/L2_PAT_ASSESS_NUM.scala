package com.optum.oadw.etl.L2

import com.optum.oadw.definedfunctions.ListAggFunction
import com.optum.oadw.etl.constants.Patients
import com.optum.oadw.oadwModels.l2_pat_assess_num
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_PAT_ASSESS_NUM extends TableInfo[l2_pat_assess_num] {
  override def name: String = "L2_PAT_ASSESS_NUM"

  override def dependsOn: Set[String] = Set("TEMP_L2_PAT_ASSESS_NUM_TEMP", "TEMP_L2_PAT_ASSESS_NUM_MORD", "TEMP_L2_PAT_ASSESS_NUM_MAYO", "L2_DICT_ASSESSMENT", "TEMP_L2_PAT_ASSESS_NUM_CKDEPI")

  def directoryLevel: String = "L2"

  override def partitions: Int = 64

  val originalSqlFileName: String = "L2_assess_build.sql"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempPatAssessNum = loadedDependencies("TEMP_L2_PAT_ASSESS_NUM_TEMP").alias("tempPatAssessNum")
    val patAssessMayo = loadedDependencies("TEMP_L2_PAT_ASSESS_NUM_MAYO").alias("patAssessMayo")
    val patAssessMord = loadedDependencies("TEMP_L2_PAT_ASSESS_NUM_MORD").alias("patAssessMord")
    val patAssessCkd = loadedDependencies("TEMP_L2_PAT_ASSESS_NUM_CKDEPI")
    val dictAssess = loadedDependencies("L2_DICT_ASSESSMENT")

    val result = tempPatAssessNum.union(patAssessMayo).union(patAssessMord).union(patAssessCkd).withColumn("clinical_evt_key", expr("nvl(clinical_event_id, 0)"))
    result
      .as("result")
      .join(broadcast(dictAssess).as("dict"), $"dict.assessment_cui" === $"result.assessment_cui", "left_outer")
      .select(
        $"result.assessment_cui",
        $"result.assessment_dtm",
        $"result.cds_grp",
        $"result.client_id",
        $"result.clinical_event_id",
        $"result.clinical_evt_key",
        $"result.hosp_ind",
        $"result.inferred_ind",
        $"result.mpi",
        $"result.nlp_ind",
        coalesce($"dict.sensitive_ind", $"result.sensitive_ind").as("sensitive_ind"),
        $"result.numeric_value"
      ).distinct()
  }
}

case class temp_l2_pat_assess_num_temp_data(client_id: String, mpi: String, assessment_dtm: java.sql.Timestamp,
                                              cds_grp: String, assessment_cui: String, numeric_value: java.lang.Double,
                                              clinical_event_id: java.lang.Long, nlp_ind: java.lang.Integer,
                                              hosp_ind: java.lang.Integer, sensitive_ind: java.lang.Integer,
                                              inferred_ind: java.lang.Integer)

object TEMP_L2_PAT_ASSESS_NUM_TEMP extends TableInfo[temp_l2_pat_assess_num_temp_data] {
  override def name: String = "TEMP_L2_PAT_ASSESS_NUM_TEMP"

  override def dependsOn: Set[String] = Set("TEMP_L2_PAT_ASSESS_BUILD_COMMON_OBS", "TEMP_L2_PAT_ASSESS_BUILD_COMMON_LAB")

  def directoryLevel: String = "L2"

  override def partitions: Int = 64

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val patAssessCommonObs = loadedDependencies("TEMP_L2_PAT_ASSESS_BUILD_COMMON_OBS").alias("patAssessCommonObs")
    val patAssessCommonLab = loadedDependencies("TEMP_L2_PAT_ASSESS_BUILD_COMMON_LAB").alias("patAssessCommonLab")
    val result = getResultsFromCommonObs(sparkSession, patAssessCommonObs).union(getResultsFromCommonLab(sparkSession, patAssessCommonLab))
    result
  }

  private def getResultsFromCommonObs(sparkSession: SparkSession,
                                      patAssessCommonObs: DataFrame): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    patAssessCommonObs.where($"numeric_value".isNotNull)
      .select(
        $"client_id",
        $"mpi",
        $"assessment_dtm",
        $"cds_grp",
        $"assessment_cui",
        $"numeric_value",
        $"clinical_event_id",
        $"nlp_ind",
        $"hosp_ind",
        lit(0).as("sensitive_ind"),
        lit(0).as("inferred_ind"))
  }

  private def getResultsFromCommonLab(sparkSession: SparkSession,
                                      patAssessCommonLab: DataFrame): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    patAssessCommonLab.where($"numeric_value".isNotNull && $"result_type".isin("CH003059","CH003061"))
      .select(
        $"client_id",
        $"mpi",
        $"assessment_dtm",
        $"cds_grp",
        $"assessment_cui",
        $"numeric_value",
        $"clinical_event_id",
        $"nlp_ind",
        $"hosp_ind",
        lit(0).as("sensitive_ind"),
        lit(0).as("inferred_ind")
      )
  }
}

object TEMP_L2_PAT_ASSESS_NUM_MORD extends TableInfo[temp_l2_pat_assess_num_temp_data] {
  override def name: String = "TEMP_L2_PAT_ASSESS_NUM_MORD"

  override def dependsOn: Set[String] = Set("TEMP_L2_PAT_ASSESS_NUM_TEMP", "L2_PATIENT_INFO")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatAssessNumTemp = loadedDependencies("TEMP_L2_PAT_ASSESS_NUM_TEMP").alias("tL2PatAssessNumTemp")
    val tl2PatientInfo = loadedDependencies("L2_PATIENT_INFO").alias("tl2PatientInfo")

    val tempDataset = tL2PatAssessNumTemp
      .join(tl2PatientInfo, tL2PatAssessNumTemp("mpi") === tl2PatientInfo("mpi"))
      .withColumn("ageAsOf", floor(months_between(to_date(date_format(tL2PatAssessNumTemp("assessment_dtm"), "yyyy-MM-dd")), to_date(date_format(tl2PatientInfo("dob"), "yyyy-MM-dd"))) / 12))
      .where($"assessment_cui" === lit("CH000660") && $"numeric_value" > 0 && $"dob".isNotNull && $"ageAsOf" >= lit(18)).alias("tempDataset")
      .withColumn("assessment_cui",explode(typedLit(List("CH003713","CH004572"))))


    tempDataset
      .select(
        tL2PatAssessNumTemp("client_id"),
        tL2PatAssessNumTemp("mpi"),
        tL2PatAssessNumTemp("assessment_dtm"),
        tL2PatAssessNumTemp("cds_grp"),
        $"assessment_cui",
        round(lit(175) * pow($"numeric_value", -1.154) * pow($"ageAsOf", -0.203) * when($"race_cui" === lit("CH000053") && $"assessment_cui" === lit("CH003713"), 1.212).otherwise(1.000) * when($"gender_cui" === lit(Patients.GENDER_CUI_MALE), 1.00).otherwise(0.742), 2)
          .as("numeric_value"),
        tL2PatAssessNumTemp("clinical_event_id"),
        tL2PatAssessNumTemp("nlp_ind"),
        tL2PatAssessNumTemp("hosp_ind"),
        lit(0).as("sensitive_ind"),
        lit(0).as("inferred_ind"))
  }
}

object TEMP_L2_PAT_ASSESS_NUM_MAYO extends TableInfo[temp_l2_pat_assess_num_temp_data] {
  override def name: String = "TEMP_L2_PAT_ASSESS_NUM_MAYO"

  override def dependsOn: Set[String] = Set("TEMP_L2_PAT_ASSESS_NUM_TEMP", "L2_PATIENT_INFO")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatAssessNumTemp = loadedDependencies("TEMP_L2_PAT_ASSESS_NUM_TEMP").alias("tL2PatAssessNumTemp")
    val tl2PatientInfo = loadedDependencies("L2_PATIENT_INFO").alias("tl2PatientInfo")

    val tempDataset = tL2PatAssessNumTemp
      .join(tl2PatientInfo, tL2PatAssessNumTemp("mpi") === tl2PatientInfo("mpi"))
      .withColumn("ageAsOf", floor(months_between(to_date(date_format(tL2PatAssessNumTemp("assessment_dtm"), "yyyy-MM-dd")), to_date(date_format(tl2PatientInfo("dob"), "yyyy-MM-dd"))) / 12))
      .where($"assessment_cui" === lit("CH000660") && $"numeric_value" > 0 && $"dob".isNotNull && $"ageAsOf" >= lit(18)).alias("tempDataset")
      .select(
        tL2PatAssessNumTemp("client_id"),
        tL2PatAssessNumTemp("mpi"),
        tL2PatAssessNumTemp("assessment_dtm"),
        tL2PatAssessNumTemp("cds_grp"),
        tL2PatAssessNumTemp("clinical_event_id"),
        tL2PatAssessNumTemp("nlp_ind"),
        tL2PatAssessNumTemp("hosp_ind"),
        tl2PatientInfo("gender_cui"),
        $"ageAsOf",
        when($"numeric_value" > 0.8, $"numeric_value").otherwise(0.8).as("result_for_gfr"))

    tempDataset
      .select(
        tempDataset("client_id"),
        tempDataset("mpi"),
        tempDataset("assessment_dtm"),
        tempDataset("cds_grp"),
        round(exp(lit(1.911) + (lit(5.249) / $"result_for_gfr") - (lit(2.114) / ($"result_for_gfr" * $"result_for_gfr")) - (lit(0.00686) * $"ageAsOf") - (lit(0.205) * when($"gender_cui" === lit(Patients.GENDER_CUI_MALE), lit(0)).otherwise(lit(1)))), 2)
          .as("mayo_egfr"),
        tempDataset("clinical_event_id"),
        tempDataset("nlp_ind"),
        tempDataset("hosp_ind")
      )
      .groupBy(
        $"client_id",
        $"mpi",
        $"assessment_dtm",
        $"clinical_event_id",
        $"mayo_egfr"
      )
      .agg(
        ListAggFunction.listAgg($"cds_grp").as("cds_grp"),
        when(max($"nlp_ind") === 0 && min($"nlp_ind") === 0, 0)
          .when(max($"nlp_ind") === 2 && min($"nlp_ind") === 2, 2)
          .otherwise(lit(1)).as("nlp_ind"),
        max($"hosp_ind").as("hosp_ind")
      )
      // Note: We need the select after the agg. Otherwise, the columns will not be in the correct order w.r.t.
      // temp_l2_pat_assess_num_temp_data and QueryIntegrationTest will fail because of wrong column type(s).
      .select(
      $"client_id",
      $"mpi",
      $"assessment_dtm",
      $"cds_grp",
      lit("CH003714").as("assessment_cui"),
      $"mayo_egfr".as("numeric_value"),
      $"clinical_event_id",
      $"nlp_ind",
      $"hosp_ind",
      lit(0).as("sensitive_ind"),
      lit(0).as("inferred_ind")
    )

  }
}

object TEMP_L2_PAT_ASSESS_NUM_CKDEPI extends TableInfo[temp_l2_pat_assess_num_temp_data] {
  override def name: String = "TEMP_L2_PAT_ASSESS_NUM_CKDEPI"

  override def dependsOn: Set[String] = Set("TEMP_L2_PAT_ASSESS_NUM_TEMP", "L2_PATIENT_INFO")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatAssessNumTemp = loadedDependencies("TEMP_L2_PAT_ASSESS_NUM_TEMP").alias("tL2PatAssessNumTemp")
    val tl2PatientInfo = loadedDependencies("L2_PATIENT_INFO").alias("tl2PatientInfo")

    //    genderval: 1 for female, 2 for male

    val getKvalue = typedLit(Map(
      1 -> 0.7d,
      2 -> 0.9d))

    val tempDataset = tL2PatAssessNumTemp
      .join(tl2PatientInfo, tL2PatAssessNumTemp("mpi") === tl2PatientInfo("mpi"))
      .withColumn("ageAsOf", floor(months_between(to_date(date_format(tL2PatAssessNumTemp("assessment_dtm"), "yyyy-MM-dd")), to_date(date_format(tl2PatientInfo("dob"), "yyyy-MM-dd"))) / 12))
      .where($"assessment_cui" === lit("CH000660") && $"numeric_value" > 0 && $"dob".isNotNull && $"ageAsOf" >= lit(18)).alias("tempDataset")
      .drop("assessment_cui")
      .withColumn("genderval",when($"gender_cui" === lit(Patients.GENDER_CUI_MALE),lit(2)).otherwise(lit(1)))
      .select(
        tL2PatAssessNumTemp("client_id"),
        tL2PatAssessNumTemp("mpi"),
        tL2PatAssessNumTemp("assessment_dtm"),
        tL2PatAssessNumTemp("cds_grp"),
        tL2PatAssessNumTemp("clinical_event_id"),
        tL2PatAssessNumTemp("nlp_ind"),
        tL2PatAssessNumTemp("hosp_ind"),
        $"ageAsOf",
        $"race_cui",
        $"gender_cui",
        ($"numeric_value"/getKvalue($"genderval")).as("numeric_value"),
        $"genderval"
      )

    val get2009Avalue = typedLit(Map(
      1 -> -0.329d,
      2 -> -0.411d))

    val get2009GenderMultiplier = typedLit(Map(
      1 -> 1.018d,
      2 -> 1.00d))

    val CKDEPI2009 = tempDataset
      .select(
        tL2PatAssessNumTemp("client_id"),
        tL2PatAssessNumTemp("mpi"),
        tL2PatAssessNumTemp("assessment_dtm"),
        tL2PatAssessNumTemp("cds_grp"),
        explode(typedLit(List("CH004573","CH004574"))).as("assessment_cui"),
        round(
          lit(141) *
          when($"numeric_value" < 1,pow($"numeric_value", get2009Avalue($"genderval")))
          .when($"numeric_value" > 1,pow($"numeric_value", -1.209))
            .otherwise(1) *
          pow(0.993,$"ageAsOf") *
          get2009GenderMultiplier($"genderval") *
          when($"race_cui" === lit("CH000053") && $"assessment_cui" === lit("CH004573"), 1.159)
            .otherwise(1.000)
          , 2).as("numeric_value"),
        tL2PatAssessNumTemp("clinical_event_id"),
        tL2PatAssessNumTemp("nlp_ind"),
        tL2PatAssessNumTemp("hosp_ind"),
        lit(0).as("sensitive_ind"),
        lit(0).as("inferred_ind"))

    val get2021Avalue = typedLit(Map(
      1 -> -0.241d,
      2 -> -0.302d))

    val get2021GenderMultiplier = typedLit(Map(
      1 -> 1.012d,
      2 -> 1.000d))

    val CKDEPI2021 = tempDataset
      .select(
        tL2PatAssessNumTemp("client_id"),
        tL2PatAssessNumTemp("mpi"),
        tL2PatAssessNumTemp("assessment_dtm"),
        tL2PatAssessNumTemp("cds_grp"),
        lit("CH004665").as("assessment_cui"),
        round(
          lit(142) *
            when($"numeric_value" < 1,pow($"numeric_value", get2021Avalue($"genderval")))
              .when($"numeric_value" > 1,pow($"numeric_value", -1.200))
              .otherwise(1) *
            pow(0.9938,$"ageAsOf") *
            get2021GenderMultiplier($"genderval")
          , 2).as("numeric_value"),
        tL2PatAssessNumTemp("clinical_event_id"),
        tL2PatAssessNumTemp("nlp_ind"),
        tL2PatAssessNumTemp("hosp_ind"),
        lit(0).as("sensitive_ind"),
        lit(0).as("inferred_ind"))

    CKDEPI2009.union(CKDEPI2021)
  }
}

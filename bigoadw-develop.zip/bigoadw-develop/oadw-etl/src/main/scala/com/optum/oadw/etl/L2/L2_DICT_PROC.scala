package com.optum.oadw.etl.L2
import com.optum.oadw.oadwModels._
import com.optum.oadw.oadw_ref.models.l2_map_sensitive_category
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_DICT_PROC extends TableInfo[l2_dict_proc] {

  override def name: String = "L2_DICT_PROC"

  override def dependsOn: Set[String] = Set("L1_REF_ICD9_PX","L1_REF_CPT4","L1_REF_HCPCS","L1_REF_HCPCS_SPECIALTY_MED","L1_REF_SENSITIVE_PROC","L1_REF_CUST_PROC_MAPPED_VAL","L1_REF_UB04_REV_CODES","L1_REF_ICD0_PX","L2_MAP_SENSITIVE_CATEGORY")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1RefIcd9Px = loadedDependencies("L1_REF_ICD9_PX").as[l1_ref_icd9_px]
    val l1RefCpt4 = loadedDependencies("L1_REF_CPT4").as[l1_ref_cpt4]
    val l1RefHcpcs = loadedDependencies("L1_REF_HCPCS").as[l1_ref_hcpcs]
    val l1RefHcpcsSpecialityMed = loadedDependencies("L1_REF_HCPCS_SPECIALTY_MED").as[l1_ref_hcpcs_specialty_med]
    val l1RefSensitiveProc = loadedDependencies("L1_REF_SENSITIVE_PROC").as[l1_ref_sensitive_proc]
    val l1RefCustProcMappedVal = loadedDependencies("L1_REF_CUST_PROC_MAPPED_VAL").as[l1_ref_cust_proc_mapped_val]
    val l1RefUb04RevCodes = loadedDependencies("L1_REF_UB04_REV_CODES").as[l1_ref_ub04_rev_codes]
    val l1RefIcd0Px = loadedDependencies("L1_REF_ICD0_PX").as[l1_ref_icd0_px]
    val l2MapSensitiveCategory = loadedDependencies("L2_MAP_SENSITIVE_CATEGORY").as[l2_map_sensitive_category]

    val window = Window.partitionBy($"code_type",$"proc_cd").orderBy($"sensitive_hierarchy")


     val cpt = l1RefHcpcs.as("t").join(l1RefHcpcsSpecialityMed.as("s"),Seq("procedure_code"),"left")
      .withColumn("specialty_med_ind",$"s.specialty_ind".cast(IntegerType))

    cpt
      .join(l1RefCpt4.as("b"),Seq("procedure_code"),"fullouter")
      .select(
       when($"procedure_code".rlike("^[A-Z]{1}.{4}"),"HCPCS").otherwise("CPT4").as("code_type"),
       $"procedure_code".as("proc_cd"),
       coalesce($"t.short_description",$"b.short_description").as("code_name"),
       substring(coalesce(cpt.col("t.long_description"),l1RefCpt4.col("long_description")),1,500).as("code_desc"),
       coalesce($"specialty_med_ind",lit(0)).as("specialty_med_ind"))
      .union(
        l1RefIcd0Px.select(
        lit("ICD10").as("code_type"),
        $"procedure_code".as("proc_cd"),
        $"short_description".as("code_name"),
        $"long_description".as("code_desc"),
        lit(0).as("specialty_med_ind")
        )
      ).union(
        l1RefIcd9Px.select(
          lit("ICD9").as("code_type"),
        $"procedure_code".as("proc_cd"),
        $"short_description".as("code_name"),
        $"long_description".as("code_desc"),
        lit(0).as("specialty_med_ind")
        )
      ).union(
        l1RefUb04RevCodes.select(
          lit("REV").as("code_type"),
          $"rev_code".as("proc_cd"),
          substring($"short_desc",1,1000).as("code_name"),
          $"long_desc".as("code_desc"),
          lit(0).as("specialty_med_ind")
         )
      ).union(
        l1RefCustProcMappedVal.select(
          lit("CUSTOM").as("code_type"),
          $"mappedvalue".as("proc_cd"),
          $"description".as("code_name"),
          $"description".as("code_desc"),
          lit(0).as("specialty_med_ind")
        )
      ).union(
        Seq((
          "TOS",
          "ENCOUNTER",
          "Encounter without coded Procedures",
          "Encounter without coded Procedures",
          0)).toDF("code_type","proc_cd","code_name","code_desc","specialty_med_ind")
      ).join(l1RefSensitiveProc, Seq("code_type","proc_cd"),"left_outer")
       .join(l2MapSensitiveCategory, expr("UPPER(code_desc) LIKE CONCAT('%', UPPER(sensitive_text), '%')"), "left")
       .withColumn("row_num",rank() over window).where($"row_num" === lit(1))
       .withColumn("sensitive_ind", coalesce($"sensitive_ind", lit(0)))
       .select(
          $"code_type",
          $"proc_cd",
          coalesce($"code_name",concat($"code_type" , lit("-") , $"proc_cd")).as("code_name"),
          $"code_desc",
          $"sensitive_ind",
          when($"sensitive_ind" === lit(1), coalesce($"sensitive_cat_id", lit(999))).otherwise(lit(1)).as("sensitive_cat_id"),
          coalesce($"specialty_med_ind", lit(0)).cast(IntegerType).as("specialty_med_ind")
        )

  }

  def directoryLevel: String = "L2"


  val originalSqlFileName: String = "L2_dict_proc_build.sql"
}


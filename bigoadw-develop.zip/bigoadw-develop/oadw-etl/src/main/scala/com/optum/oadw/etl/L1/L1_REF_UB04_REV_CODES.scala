
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ref_ub04_rev_codes, ref_ub04_rev_codes}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object L1_REF_UB04_REV_CODES extends TableInfo[l1_ref_ub04_rev_codes]{
  override def dependsOn: Set[String] = Set("REF_UB04_REV_CODES")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_REF_UB04_REV_CODES"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val refUb04RevCodes = loadedDependencies("REF_UB04_REV_CODES").as[ref_ub04_rev_codes]

    refUb04RevCodes
    .select(
			$"rev_code",
			$"description".substr(1,100).as("short_desc"),
			$"description".as("long_desc")
    )
  }
}


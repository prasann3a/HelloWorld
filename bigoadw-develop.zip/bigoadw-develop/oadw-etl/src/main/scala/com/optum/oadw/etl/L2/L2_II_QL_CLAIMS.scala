package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{ DataFrame, SparkSession }
import org.apache.spark.sql.functions._

object L2_II_QL_CLAIMS extends TableInfo[l2_ii_ql_claims] {
  override def name: String = "L2_II_QL_CLAIMS"

  override def dependsOn: Set[String] = Set("L1_II_QL_CLAIMS", "L2_II_MEM_ATTR_MEMBER")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1IIQlClaims      = loadedDependencies("L1_II_QL_CLAIMS").as[l1_ii_ql_claims]
    val l1IIMemAttrMember = loadedDependencies("L2_II_MEM_ATTR_MEMBER").as[l2_ii_mem_attr_member]

    val l2IIMemAttr = l1IIMemAttrMember
      .select(
        $"member",
        $"contract_id",
        $"mem_eff_dt",
        $"mem_end_dt",
        $"at_risk_status_id"
      )
      .distinct()

    val tempL2IIQlClaims =
      l1IIQlClaims
        .select(
          $"member",
          $"contract_id",
          $"from_dt"
        )
        .distinct()

    val atRiskCalculation =
      tempL2IIQlClaims
        .as("c")
        .join(l2IIMemAttr.as("m"), $"m.member" === $"c.member" && $"m.contract_id" === $"c.contract_id", "left")
        .select(
          $"c.member",
          $"c.contract_id",
          $"c.from_dt",
          when($"c.from_dt" >= $"m.mem_eff_dt" && $"c.from_dt" <= $"m.mem_end_dt", $"m.at_risk_status_id").otherwise(null).as("at_risk_status_id")
        )

    val window = Window
      .partitionBy(
        $"member",
        $"contract_id",
        $"from_dt"
      )
      .orderBy($"at_risk_status_id".desc_nulls_last)

    val aggregratedRiskCalculation = atRiskCalculation.withColumn("rank", row_number().over(window)).where($"rank" === lit(1)).drop("rank")

    l1IIQlClaims
      .as("c")
      .join(aggregratedRiskCalculation.as("m"), $"m.member" === $"c.member" && $"m.contract_id" === $"c.contract_id" && $"m.from_dt" === $"c.from_dt", "left")
      .select(
        $"c.account_id",
        $"c.age",
        $"c.amt_req",
        $"c.amt_req_k",
        $"c.cat_status",
        $"c.cat_status_cost3",
        $"c.claim_id",
        $"c.clm_exclude",
        $"c.clm_id_n",
        $"c.clm_type",
        $"c.conf_num",
        $"c.contract_id",
        $"c.cost1",
        $"c.cost1_k",
        $"c.cost2",
        $"c.cost2_k",
        $"c.cost3",
        $"c.cost3_k",
        $"c.cost4",
        $"c.cost4_k",
        $"c.cost5",
        $"c.cost5_k",
        $"c.cost6",
        $"c.cost6_k",
        $"c.days_sup",
        $"c.diag1",
        $"c.diag10",
        $"c.diag2",
        $"c.diag3",
        $"c.diag4",
        $"c.diag5",
        $"c.diag6",
        $"c.diag7",
        $"c.diag8",
        $"c.diag9",
        $"c.encounter",
        $"c.enc_k",
        $"c.episode_id",
        $"c.etg_id",
        $"c.from_dt",
        $"c.ia_time",
        $"c.icd_version",
        $"c.line_nat",
        $"c.map_srce_n",
        $"c.member",
        $"c.mem_userdef_1_id",
        $"c.mem_userdef_2_id",
        $"c.mod_n",
        $"c.network_paid_status_id",
        $"c.network_status",
        $"c.pay_dt",
        $"c.poa1".as("poa"),
        $"c.pos_i",
        $"c.proc_srv",
        $"c.proc_srv_desc",
        $"c.product_id",
        $"c.provider_id",
        $"c.provider_status_id",
        $"c.prv_sp_4",
        $"c.qlc_id",
        $"c.sev_level",
        $"c.sex",
        $"c.svc_grp",
        $"c.svc_qty",
        $"c.svc_qty_k",
        $"c.tos_i_5",
        $"c.to_dt",
        $"c.zip",
        $"m.at_risk_status_id"
      )
  }
}


/**
  * auto-generated code
*/
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.l1_map_diagnosis_cui
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata


object L1_MAP_DIAGNOSIS_CUI extends QueryAndMetadata[l1_map_diagnosis_cui] {
  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_DIAGNOSIS_CUI"

  override def sparkSql: String = """SELECT CASE WHEN icd_version = '9' then 'ICD9' else 'ICD10' end as codetype
, icd_cm_code as mappedcode
, cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_ccs_multi_dx on (mappedcode = ccs_lvl_2)
WHERE codetype = 'CCS'
UNION
SELECT CASE WHEN icd_version = '9' THEN 'ICD9' ELSE 'ICD10' END as codetype
, icd_cm_code as mappedcode
, cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_ccs_multi_dx on (mappedcode = ccs_lvl_3)
WHERE codetype = 'CCS'
UNION
SELECT CASE WHEN icd_version = '9' THEN 'ICD9' ELSE 'ICD10' END as codetype
, icd_cm_code as mappedcode
, cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_ccs_multi_dx on (mappedcode = ccs_lvl_4)
WHERE codetype = 'CCS'
UNION
SELECT CASE WHEN icd_version = '9' THEN 'ICD9' ELSE 'ICD10' END as codetype
, icd_cm_code as mappedcode
, cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_map_ccs_icdx_dx on (mappedcode = ccs_category)
WHERE codetype = 'CCS_CAT'
UNION
SELECT DISTINCT codetype
, diagnosis_code as mappedcode
, cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_icd9_dx on (diagnosis_code = mappedcode)
WHERE codetype = 'ICD9'
AND (INSTR (mappedcode, '_') = 0 AND INSTR (mappedcode, '%') = 0) -- Not a pattern
UNION
SELECT DISTINCT codetype
, diagnosis_code as mappedcode
, cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_icd9_dx on (diagnosis_code like mappedcode)
WHERE codetype = 'ICD9'
AND NOT (INSTR (mappedcode, '_') = 0 AND INSTR (mappedcode, '%') = 0) -- a LIKE pattern
UNION
SELECT DISTINCT codetype
, diagnosis_code as mappedcode
, cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_icd0_dx on (diagnosis_code = mappedcode)
WHERE codetype = 'ICD10'
AND (INSTR (mappedcode, '_') = 0 AND INSTR (mappedcode, '%') = 0) -- Not a pattern
UNION
SELECT DISTINCT codetype
, diagnosis_code as mappedcode
, cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_icd0_dx on (diagnosis_code like mappedcode)
WHERE codetype = 'ICD10'
AND NOT (INSTR (mappedcode, '_') = 0 AND INSTR (mappedcode, '%') = 0) -- a LIKE pattern
UNION
SELECT DISTINCT codetype
, mappedcode
, cui
FROM L1_map_diagnosis
WHERE codetype = 'SNOMED'"""

  override def dependsOn: Set[String] = Set("L1_REF_ICD9_DX","L1_MAP_DIAGNOSIS","L1_REF_CCS_MULTI_DX","L1_REF_ICD0_DX","L1_REF_MAP_CCS_ICDX_DX")

  def originalSql: String = """
-- do we want to partition by codetype?  Not sure how big the sets are

--add in codes

INSERT /*+ APPEND PARALLEL(4) */ INTO L1_map_diagnosis_cui (codetype, mappedcode, cui)
SELECT CASE WHEN icd_version = '9' then 'ICD9' else 'ICD10' end as codetype
  , icd_cm_code as mappedcode
  , cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_ccs_multi_dx on (mappedcode = ccs_lvl_2)
WHERE codetype = 'CCS'
UNION
SELECT CASE WHEN icd_version = '9' THEN 'ICD9' ELSE 'ICD10' END as codetype
  , icd_cm_code as mappedcode
  , cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_ccs_multi_dx on (mappedcode = ccs_lvl_3)
WHERE codetype = 'CCS'
UNION
SELECT CASE WHEN icd_version = '9' THEN 'ICD9' ELSE 'ICD10' END as codetype
  , icd_cm_code as mappedcode
  , cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_ccs_multi_dx on (mappedcode = ccs_lvl_4)
WHERE codetype = 'CCS'
UNION
SELECT CASE WHEN icd_version = '9' THEN 'ICD9' ELSE 'ICD10' END as codetype
  , icd_cm_code as mappedcode
  , cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_map_ccs_icdx_dx on (mappedcode = ccs_category)
WHERE codetype = 'CCS_CAT'
UNION
SELECT DISTINCT codetype
  , diagnosis_code as mappedcode
  , cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_icd9_dx on (diagnosis_code = mappedcode)
WHERE codetype = 'ICD9'
AND (INSTR (mappedcode, '_') = 0 AND INSTR (mappedcode, '%') = 0) -- Not a pattern
UNION
SELECT DISTINCT codetype
  , diagnosis_code as mappedcode
  , cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_icd9_dx on (diagnosis_code like mappedcode)
WHERE codetype = 'ICD9'
AND NOT (INSTR (mappedcode, '_') = 0 AND INSTR (mappedcode, '%') = 0) -- a LIKE pattern
UNION
SELECT DISTINCT codetype
  , diagnosis_code as mappedcode
  , cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_icd0_dx on (diagnosis_code = mappedcode)
WHERE codetype = 'ICD10'
AND (INSTR (mappedcode, '_') = 0 AND INSTR (mappedcode, '%') = 0) -- Not a pattern
UNION
SELECT DISTINCT codetype
  , diagnosis_code as mappedcode
  , cui
FROM L1_map_diagnosis
INNER JOIN L1_ref_icd0_dx on (diagnosis_code like mappedcode)
WHERE codetype = 'ICD10'
AND NOT (INSTR (mappedcode, '_') = 0 AND INSTR (mappedcode, '%') = 0) -- a LIKE pattern
UNION
SELECT DISTINCT codetype
  , mappedcode
  , cui
FROM L1_map_diagnosis
WHERE codetype = 'SNOMED'
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("codetype",None,None), OutputColumn("mappedcode",None,None), OutputColumn("cui",None,None)))

  def directoryLevel: String = "L1"





  val originalSqlFileName: String = "L1_map_diagnosis_cui.sql"
}


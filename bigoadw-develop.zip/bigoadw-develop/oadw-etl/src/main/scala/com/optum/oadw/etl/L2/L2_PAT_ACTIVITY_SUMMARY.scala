
package com.optum.oadw.etl.L2

import java.util.NoSuchElementException
import com.optum.oadw.oadwModels.{l2_pat_activity_month, l2_pat_activity_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.etl.constants.Activity
import com.optum.oadw.definedfunctions.{BitOrAggFunction,ListAggFunction}
import com.optum.oadw.oadw_ref.models.l2_dict_activity_type
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}


object L2_PAT_ACTIVITY_SUMMARY extends TableInfo[l2_pat_activity_summary] {

  override def name: String = "L2_PAT_ACTIVITY_SUMMARY"

  override def dependsOn: Set[String] = Set("L2_PAT_ACTIVITY_MONTH", "L2_DICT_ACTIVITY_TYPE", "MD_OADW_INSTANCE")

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_pat_activity_summary_build.sql"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val patActivityMonth = loadedDependencies("L2_PAT_ACTIVITY_MONTH").as[l2_pat_activity_month].alias("patActivityMonth")
    val dictActivityType = broadcast(loadedDependencies("L2_DICT_ACTIVITY_TYPE").as[l2_dict_activity_type]).alias("dictActivityType")
    val mdInstance = loadedDependencies("MD_OADW_INSTANCE").alias("mdInstance")

    val dataThruDate = mdInstance
      .select(to_date(date_format(from_unixtime(unix_timestamp($"attribute_value", "yyyyMMdd")), "yyyy-MM-dd")).as("sDate"))
      .where($"attribute_name" === lit("DATA_THRU"))

    val fortyEightMonthsOld = try {
      dataThruDate.select(concat(date_format(add_months($"sDate", -48), "yyyy"), lit("01")).cast(IntegerType)).as[Integer].collect().head
    } catch {
      case e: NoSuchElementException => throw new IllegalStateException("MD_OADW_INSTANCE.DATA_THRU date missing, cannot continue ETL")
    }
    val thirtyNineMonthsOld = try {
      dataThruDate.select(date_format(add_months($"sDate", -39), "yyyyMM").cast(IntegerType)).as[Integer].collect().head
    } catch {
      case e: NoSuchElementException => throw new IllegalStateException("MD_OADW_INSTANCE.DATA_THRU date missing, cannot continue ETL")
    }

    val result = patActivityMonth
      .join(dictActivityType, Seq("activity_type_cd"))
      .groupBy(
        patActivityMonth("client_id"),
        patActivityMonth("mpi")
      ).agg(
      ListAggFunction.listAgg(patActivityMonth("cds_grp")).as("cds_grp"),
      max(when(patActivityMonth("activity_yr_month") >= lit(200601)
        && !patActivityMonth("activity_type_cd").isin(Activity.ELIG_ALL, Activity.ELIG_RX, Activity.ELIG_MED), lit(1)).otherwise(lit(0))).as("class_1_ind"),
      max(when(patActivityMonth("activity_yr_month") > lit(fortyEightMonthsOld)
        && patActivityMonth("activity_type_cd").isin(Activity.ELIG_ALL, Activity.ELIG_RX, Activity.ELIG_MED), lit(1)).otherwise(lit(0))).as("elig_ind"),
      max(when(patActivityMonth("activity_yr_month") > lit(fortyEightMonthsOld)
        && !patActivityMonth("activity_type_cd").isin(Activity.ELIG_ALL, Activity.ELIG_RX, Activity.ELIG_MED), lit(1)).otherwise(lit(0))).as("activity_ind"),
      max(when(patActivityMonth("activity_yr_month") > lit(thirtyNineMonthsOld)
        && patActivityMonth("activity_type_cd").isin(Activity.ELIG_ALL, Activity.ELIG_RX, Activity.ELIG_MED), lit(1)).otherwise(lit(0))).as("recent_elig"),
      max(when(patActivityMonth("activity_yr_month") > lit(thirtyNineMonthsOld)
        && patActivityMonth("activity_type_cd") === lit(Activity.QUALEVT), lit(1)).otherwise(lit(0))).as("recent_qual_evt"),
      BitOrAggFunction.bitOrAgg(dictActivityType("activity_type_flg")).as("all_act_type_flg")
    ).select(
      $"client_id",
      $"mpi",
      $"cds_grp",
      $"class_1_ind",
      greatest($"elig_ind", $"activity_ind").as("class_2_ind"),
      greatest($"recent_elig", $"recent_qual_evt").as("class_3_ind"),
      $"all_act_type_flg"
    )
    result
  }
}


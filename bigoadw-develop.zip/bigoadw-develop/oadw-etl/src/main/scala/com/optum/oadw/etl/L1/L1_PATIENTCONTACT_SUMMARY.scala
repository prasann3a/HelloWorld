
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patientcontact_summary, patientcontact_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENTCONTACT_SUMMARY extends TableInfo[l1_patientcontact_summary]{
  override def dependsOn: Set[String] = Set("PATIENTCONTACT_SUMMARY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENTCONTACT_SUMMARY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientcontactSummary = loadedDependencies("PATIENTCONTACT_SUMMARY").as[patientcontact_summary]

    patientcontactSummary
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"grp_mpi".as("mpi"),
			$"home_phone",
			$"work_phone",
			$"cell_phone",
			$"work_email",
			$"personal_email",
			$"multiple_values",
			$"record_date".as("record_dtm")
    )
  }
}


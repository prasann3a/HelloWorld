package com.optum.oadw.etl.L2
import com.optum.oadw.oadwModels.l2_map_cds_flg
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_MAP_CDS_FLG extends QueryAndMetadata[l2_map_cds_flg] {
  override def name: String = "L2_MAP_CDS_FLG"

  override def sparkSql: String = """
WITH cds_grps_roll AS (
  SELECT a.client_id
  ,a.client_data_src_id
  ,a.data_src_id
  ,a.client_data_src_name
  ,a.data_src_name
  ,a.display_name
  ,CASE WHEN  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (16 AS INT))  = 16 THEN 1 --Payer
        WHEN  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (3 AS INT))  != 0 AND  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (12 AS INT))  != 0 THEN 8 --Mixed
        WHEN  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (3 AS INT))  != 0 THEN 4 -- EMR
        WHEN  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (12 AS INT))  != 0 THEN 2 -- Billing
        WHEN  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (128 AS INT)) = 128 THEN 16 -- Care Coordination
        ELSE 0 END AS source_type_flg

  ,CASE WHEN  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (16 AS INT))  = 16 then CONCAT ('CDS:' , a.CLIENT_DATA_SRC_ID)
        WHEN  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (3 AS INT))  > 0 then CONCAT('EMR',COALESCE(display_name,client_data_src_name,data_src_name))
        WHEN  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (12 AS INT))  > 0 then CONCAT('BILL',COALESCE(display_name,client_data_src_name,data_src_name))
        WHEN  (CAST (a.INCLUDED_DATA_TYPES AS INT) & CAST (128 AS INT))  = 128 then CONCAT('EMR',COALESCE(display_name,client_data_src_name,data_src_name))
        ELSE 'OTHER' END AS grp_name
  FROM MD_client_data_src a
  INNER JOIN MD_client b ON (a.client_id = b.client_id)
  WHERE a.data_src_id NOT IN (381,82)
  AND nvl(b.is_retired,'No') != 'Yes'
  AND nvl(a.status_cd,'NULL') != 'OBS'
),
distinct_sources as(
  select count(distinct client_data_src_id) data_src_cnt
  from cds_grps_roll
  where source_type_flg != 0
),
cds_grps as
(
  select cg.*,
    case
      when ds.data_src_cnt > 15 and cg.source_type_flg in (4, 8, 16) then 'EMR'
      when ds.data_src_cnt > 15 and cg.source_type_flg = 2 then 'BILL'
    else cg.grp_name end grouping_name
  from cds_grps_roll cg
    cross join distinct_sources ds
),
bit_val as
(
    SELECT a.*
       ,dense_rank() OVER (PARTITION BY client_id ORDER BY grouping_name) AS set_nbr
       ,COUNT(*) OVER (PARTITION BY grouping_name) as cds_in_grp
    FROM cds_grps a
),
combined_emr as
(
    SELECT
        v.client_id,
        cast(v.client_data_src_id as long) as client_ds_id,
        cast(power(2, (set_nbr - 1)) as int) AS data_grp_flg,
        CASE
            WHEN cds_in_grp = 1 THEN coalesce(v.display_name,v.data_src_name,v.client_data_src_name,v.grouping_name)
            ELSE grouping_name
        END AS data_grp_name,
        cast(source_type_flg as int) as source_type_flg,
        coalesce(v.display_name,v.data_src_name,v.client_data_src_name,v.grouping_name) AS client_ds_name
    from bit_val v
),
cds_with_individual_emr as
(
  SELECT
  v.client_id,
  cast(v.client_data_src_id as long) as client_ds_id
  , CAST(power(2, (set_nbr - 1)) AS INT) AS data_grp_flg
  , CASE WHEN cds_in_grp = 1 THEN COALESCE(v.display_name,v.data_src_name,v.client_data_src_name,v.grouping_name) ELSE grouping_name END AS data_grp_name
  , cast(source_type_flg as INT) as source_type_flg
  , COALESCE(v.display_name,v.data_src_name,v.client_data_src_name,v.grouping_name) AS client_ds_name
  FROM (
  SELECT a.*
         ,dense_rank() OVER (PARTITION BY client_id ORDER BY source_type_flg,min_cds,grouping_name) AS set_nbr
         ,COUNT(*) OVER (PARTITION BY grouping_name) AS cds_in_grp
  FROM (SELECT x.*
              ,MIN(client_data_src_id) OVER (PARTITION BY grouping_name) AS min_cds
        FROM cds_grps x) a
  ) v
)
select *
from combined_emr
where (select data_src_cnt from distinct_sources) > 15
union
select * from cds_with_individual_emr
where (select data_src_cnt from distinct_sources) <= 15"""


  override def dependsOn: Set[String] = Set("MD_CLIENT_DATA_SRC","MD_CLIENT")

  def originalSql: String = """-- FMP @nonEmpty
INSERT /*+ APPEND */ INTO L2_map_cds_flg(client_id,client_ds_id,data_grp_flg,data_grp_name,source_type_flg,client_ds_name)
WITH cds_grps AS (SELECT a.client_id
       ,a.client_data_src_id
       ,a.data_src_id
       ,a.client_data_src_name
       ,a.data_src_name
       ,a.display_name
       ,CASE WHEN BITAND(a.INCLUDED_DATA_TYPES,16) = 16 THEN 1 --Payer
             WHEN BITAND(a.INCLUDED_DATA_TYPES,3) != 0 AND BITAND(a.INCLUDED_DATA_TYPES,12) != 0 THEN 8 --Mixed
             WHEN BITAND(a.INCLUDED_DATA_TYPES,3) != 0 THEN 4 -- EMR
             WHEN BITAND(a.INCLUDED_DATA_TYPES,12) != 0 THEN 2 -- Billing
             ELSE 0 END AS source_type_flg

       ,CASE WHEN BITAND(a.INCLUDED_DATA_TYPES,16) = 16 then 'CDS:' || a.CLIENT_DATA_SRC_ID
             WHEN BITAND(a.INCLUDED_DATA_TYPES,3) > 0 then 'EMR'
             WHEN BITAND(a.INCLUDED_DATA_TYPES,12) > 0 then 'BILL'
             else 'OTHER' end AS grouping_name
FROM MD_client_data_src a
INNER JOIN MD_client b ON (a.client_id = b.client_id)
WHERE a.data_src_id NOT IN (381,82)
-- AND a.final_release IS NULL
AND nvl(b.is_retired,'No') != 'Yes'
AND nvl(a.status_cd,'NULL') != 'OBS'
)
SELECT v.client_id,v.client_data_src_id
       ,POWER(2,(set_nbr - 1)) AS bitval
       ,CASE WHEN cds_in_grp = 1 THEN COALESCE(v.display_name,v.data_src_name,v.client_data_src_name,v.grouping_name)
             ELSE grouping_name END AS data_grp_name
       ,source_type_flg
       ,COALESCE(v.display_name,v.data_src_name,v.client_data_src_name,v.grouping_name) AS client_ds_name
FROM (
SELECT a.*
       ,dense_rank() OVER (PARTITION BY client_id ORDER BY grouping_name) AS set_nbr
       ,COUNT(*) OVER (PARTITION BY grouping_name) as cds_in_grp
FROM cds_grps a
) v"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("client_id",None,None), OutputColumn("client_ds_id",None,None), OutputColumn("data_grp_flg",None,None), OutputColumn("data_grp_name",None,None), OutputColumn("source_type_flg",None,None), OutputColumn("client_ds_name",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_map_cds_flg_build.sql"
}

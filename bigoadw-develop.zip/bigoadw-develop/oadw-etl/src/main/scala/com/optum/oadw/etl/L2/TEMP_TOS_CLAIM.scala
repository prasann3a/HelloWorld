package com.optum.oadw.etl.L2

import java.sql.Timestamp

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels._
import com.optum.oadw.utils.DataframeExtensions._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

case class temp_tos_claim_data(client_id: String, client_ds_id: Integer, mpi: String, encounterid: String,
                               mappedcpt: String, mappedhcpcs: String, service_dtm: Timestamp, claim_mstrprovid: String,
                               pos: String, tos_i_5: java.lang.Integer, mappedcptmod1: String, mappedcptmod2: String,
                               mappedcptmod3: String, mappedcptmod4: String, mappedrev: String)

object TEMP_TOS_CLAIM extends TableInfo[temp_tos_claim_data] {
  override def name: String = "TEMP_TOS_CLAIM"

  override def dependsOn: Set[String] = Set("L1_CLAIM", "L1_REF_UB04_REV_CODES", "L1_MAP_TOS_TYPE",
    "L1_REF_IMAP_TOS_PROC", "TEMP_TOS_ENC_PROV", "TEMP_PROVIDER_CUI_SPEC")

  override def partitions: Int = 256

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l1Claim = loadedDependencies("L1_CLAIM").castToBigDecimal(Set("CHARGE", "ALLOWEDAMOUNT", "CAPITATION_AMT", "COINSURANCE_AMT", "COORD_BENEFITS_AMT", "COPAY_AMT", "COSTAMOUNT", "DEDUCTIBLE_AMT", "FEE_FOR_SERVICE_AMT", "PAIDAMOUNT", "PAT_LIABILITY_AMT", "WITHHOLD_AMT")).as[l1_claim]

    val l1RefUb04RevCodes = loadedDependencies("L1_REF_UB04_REV_CODES").as[l1_ref_ub04_rev_codes]

    val tL1MapTostype = loadedDependencies("L1_MAP_TOS_TYPE").as[l1_map_tos_type]

    val l1RefImapTosProcMappedCd = loadedDependencies("L1_REF_IMAP_TOS_PROC")
      .withColumnRenamed("anes_tos", "anes_tos_a")
      .withColumnRenamed("map_code", "map_code_a")
      .withColumnRenamed("pcc_type", "pcc_type_a")
      .withColumnRenamed("prof_tos", "prof_tos_a")
      .withColumnRenamed("pcc_psc_cat2_id", "pcc_psc_cat2_id_a")
      .withColumnRenamed("op_tos", "op_tos_a")

    val l1RefImapTosProcMappedRev = loadedDependencies("L1_REF_IMAP_TOS_PROC")
      .withColumnRenamed("anes_tos", "anes_tos_b")
      .withColumnRenamed("map_code", "map_code_b")
      .withColumnRenamed("pcc_type", "pcc_type_b")
      .withColumnRenamed("prof_tos", "prof_tos_b")
      .withColumnRenamed("pcc_psc_cat2_id", "pcc_psc_cat2_id_b")
      .withColumnRenamed("op_tos", "op_tos_b")

    val tempTosEncProv = loadedDependencies("TEMP_TOS_ENC_PROV")

    val tempProviderCuiSpec = loadedDependencies("TEMP_PROVIDER_CUI_SPEC")

    createTempTosClaim(sparkSession, l1Claim, l1RefUb04RevCodes, tempTosEncProv, tempProviderCuiSpec, tL1MapTostype, l1RefImapTosProcMappedCd, l1RefImapTosProcMappedRev)

  }

  private def createTempTosClaim(sparkSession: SparkSession,
                                 l1Claim: Dataset[l1_claim],
                                 l1RefUb04RevCodes: Dataset[l1_ref_ub04_rev_codes],
                                 tempTosEncProv: DataFrame,
                                 tempProviderCuiSpec: DataFrame,
                                 tL1MapTostype: Dataset[l1_map_tos_type],
                                 l1RefImapTosProcMappedCd: DataFrame,
                                 l1RefImapTosProcMappedRev: DataFrame): DataFrame = {
    import sparkSession.implicits._
    l1Claim.as("c")
      .repartition(1024)
      .join(tempTosEncProv.as("t"), $"t.encounterid" === $"c.encounterid" and $"t.client_ds_id" === $"c.client_ds_id", "left_outer")
      .join(tempProviderCuiSpec.as("pcs"), $"pcs.prov_id" === $"c.claim_mstrprovid", "left_outer")
      .join(broadcast(l1RefUb04RevCodes).as("rc"), $"rc.rev_code" === $"c.localrev", "left_outer")
      .withColumn("mappedcode", coalesce($"c.mappedcpt", $"c.mappedhcpcs"))
      .withColumn("spec_code", coalesce($"pcs.ii_code", $"t.spec_code"))
      .withColumn("inst_prof", when(
        $"spec_code".between("100", "199"), "I"
      ).when(
        $"rc.rev_code".isNotNull and not($"spec_code".isin("700", "710", "711", "712")), "I"
      ).when(
        coalesce($"pcs.facility_ind", $"t.facility_ind") === 1, "I"
      ).otherwise("P")
      )
      .select(
        $"c.*", $"t.patient_type_cui", $"mappedcode", $"spec_code", $"inst_prof"
      ).as("t")
      .withColumn("posCui", coalesce($"t.pos", $"t.patient_type_cui"))
      .join(tL1MapTostype.as("mt1"), $"mt1.spec_code" === $"t.spec_code" and $"posCui" === $"mt1.pos", "left_outer")
      .join(tL1MapTostype.as("mt2"), $"mt2.spec_code" === $"t.spec_code" and $"posCui" === $"mt2.patient_type_cui", "left_outer")
      .join(tL1MapTostype.as("mt3"), $"mt3.spec_code" === $"t.spec_code" and $"posCui" === $"mt3.pos" and $"t.inst_prof" === "I" and not($"mt3.spec_code".startsWith("5")), "left_outer")
      .join(tL1MapTostype.as("mt4"), $"mt4.spec_code" === $"t.spec_code" and $"posCui" === $"mt4.patient_type_cui" and $"t.inst_prof" === "I" and not($"mt4.spec_code".startsWith("5")), "left_outer")
      .join(broadcast(l1RefImapTosProcMappedCd).as("p1"), $"p1.map_code_a" === $"t.mappedcode", "left_outer")
      .join(broadcast(l1RefImapTosProcMappedRev).as("p2"),  $"p2.map_code_b" === $"t.mappedrev", "left_outer")
      .select(
        $"t.*",
        $"mt1.tos_map_type".as("tos_map_type_a"),
        $"mt2.tos_map_type".as("tos_map_type_b"),
        $"mt3.tos_map_type".as("tos_map_type_c"),
        $"mt4.tos_map_type".as("tos_map_type_d"),
        coalesce($"mt1.tos_map_type", $"mt2.tos_map_type", $"mt3.tos_map_type", $"mt4.tos_map_type", lit("0")).as("tos_type"),
        $"p1.prof_tos_a".as("prof_tos_a"),
        $"p2.prof_tos_b".as("prof_tos_b"),
        $"p1.anes_tos_a".as("anes_tos_a"),
        $"p2.anes_tos_b".as("anes_tos_b"),
        $"p1.op_tos_a".as("op_tos_a"),
        $"p2.op_tos_b".as("op_tos_b")
      )
      .distinct()
      .as("v")
      .withColumn("tos_i_5", when(
        $"v.tos_type" === "0", coalesce($"v.prof_tos_a", $"v.prof_tos_b", lit(5264))
        ).when(
          $"v.tos_type" === "1", coalesce($"v.anes_tos_a", $"v.anes_tos_b", $"v.prof_tos_a", lit(5264))
        ).when(
          $"v.tos_type" === "3", coalesce($"v.op_tos_a", $"v.op_tos_b", $"v.prof_tos_a", lit(3393))
        ).when(
          $"v.tos_type" === "2",
          when($"v.spec_code".isin("101", "102") and ($"v.pos" === "61" or $"v.patient_type_cui" === "CH003031"), 2002)
            .when($"v.spec_code".isin("101", "102") or $"v.pos".isin("13", "14", "31", "32", "33", "34") or $"v.patient_type_cui".isin("CH003033", "CH000795", "CH002903"), 2001)
            .when($"v.spec_code" === "103" or $"v.pos" === "51" or $"v.patient_type_cui" === "CH003032", 2003)
            .otherwise(2000)
        ).otherwise(null).cast(IntegerType)
      ).select(
        $"v.client_id", $"v.client_ds_id", $"v.mpi", $"v.encounterid", $"v.mappedcpt", $"v.mappedhcpcs",
        $"v.service_dtm", $"v.claim_mstrprovid", $"v.pos", $"v.mappedcptmod1", $"v.mappedcptmod2", $"v.mappedcptmod3",
        $"v.mappedcptmod4", $"v.mappedrev", $"tos_i_5"
      )
  }

  def directoryLevel: String = "L2"
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_client_rel, prov_client_rel}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_CLIENT_REL extends TableInfo[l1_prov_client_rel]{
  override def dependsOn: Set[String] = Set("PROV_CLIENT_REL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_CLIENT_REL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val provClientRel = loadedDependencies("PROV_CLIENT_REL").as[prov_client_rel]

    provClientRel
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"providerid",
			$"localrelshipcode",
			$"startdate".as("start_dt"),
			$"enddate".as("end_dt"),
			$"mstrprovid",
			$"client_ds_id",
			$"prov_status_id"
    )
  }
}


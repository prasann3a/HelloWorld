package com.optum.oadw.etl.L3

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l3_pat_score_grp_precur, l4_timeframe, l4_dict_elig_cds, l1_sre_marker_profile, l3_map_score_grp_precur}
import com.optum.oadw.oadw_ref.models.{l3_map_score_grp_hier, l3_map_score_grp, l3_map_precursor_sre, l3_dict_score_grp,
 l4_dict_score, l3_dict_precursor, l3_map_score_grp_threshold}
import com.optum.oadw.utils.DataframeExtensions._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType, TimestampType}
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import scala.reflect.runtime.universe._

object L3_PAT_SCORE_GRP_PRECUR extends TableInfo[l3_pat_score_grp_precur] {
  override def name: String = "L3_PAT_SCORE_GRP_PRECUR"

  override def dependsOn: Set[String] = Set(
    "TEMP_SCORE_PREC_TIMINGHIER",
    "L3_MAP_SCORE_GRP_HIER",
    "L4_TIMEFRAME",
    "L3_MAP_SCORE_GRP",
    "L3_MAP_PRECURSOR_SRE",
    "L4_DICT_ELIG_CDS",
    "L3_DICT_SCORE_GRP",
    "REFERENCE_SCHEMA_L4_DICT_SCORE",
    "L3_DICT_PRECURSOR",
    "L1_SRE_MARKER_PROFILE",
    "L3_MAP_SCORE_GRP_THRESHOLD",
    "L3_MAP_SCORE_GRP_PRECUR",
    "TEMP_TTR_CALC",
    "TEMP_SCORE_POPULATION"
  )

  // this was consistently running out of memory on H743123 cdr_201905. Overriding partition count to 128 from 32...
  override def partitions: Int = 128

  def directoryLevel: String = "L3"

  def collectListFromType[A <: Product with Serializable : TypeTag](sparkSession: SparkSession): Column = {
    import sparkSession.implicits._
    collect_list(struct(typeOf[A].members.sorted.collect {
      case m: MethodSymbol if m.isCaseAccessor => m
    }.map(m => $"${m.name}"): _*))
  }

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempScorePrecTimingHier = loadedDependencies("TEMP_SCORE_PREC_TIMINGHIER")
    val tL3MapScoreGrpHier = loadedDependencies("L3_MAP_SCORE_GRP_HIER").as[l3_map_score_grp_hier].collect()
    val tL4Timeframe = loadedDependencies("L4_TIMEFRAME").as[l4_timeframe]
    val tL3MapScoreGrp = loadedDependencies("L3_MAP_SCORE_GRP").as[l3_map_score_grp]
    val tL3MapPrecursorSre = loadedDependencies("L3_MAP_PRECURSOR_SRE").as[l3_map_precursor_sre]
    val tL4DictEligCds = loadedDependencies("L4_DICT_ELIG_CDS").as[l4_dict_elig_cds]
    val tL3DictScoreGrp = broadcast(loadedDependencies("L3_DICT_SCORE_GRP")).as[l3_dict_score_grp]
    val tL4DictScore = loadedDependencies("REFERENCE_SCHEMA_L4_DICT_SCORE").as[l4_dict_score]
    val tL3DictPrecursor = loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor]
    val l1SreMarkerProfile = loadedDependencies("L1_SRE_MARKER_PROFILE").as[l1_sre_marker_profile]
    val tL3MapScoreGrpThreshold = loadedDependencies("L3_MAP_SCORE_GRP_THRESHOLD").castToBigDecimal(Set("threshold_max", "threshold_min")).as[l3_map_score_grp_threshold]
    val l3MapScoreGrpPrecur = loadedDependencies("L3_MAP_SCORE_GRP_PRECUR").as[l3_map_score_grp_precur]
    val tempTtrCalc = loadedDependencies("TEMP_TTR_CALC")
    val tempScorePopulation = loadedDependencies("TEMP_SCORE_POPULATION")

    /**
      * SELECT c.*
         FROM L3_map_score_grp_hier hier
         INNER JOIN TEMP_SCORE_PREC_TIMINGHIER c ON (hier.GRP_ID=c.GRP_ID AND hier.PRECURSOR_ID_EXCLUDE=c.PRECURSOR_ID)
         INNER JOIN TEMP_SCORE_PREC_TIMINGHIER d ON (hier.GRP_ID=d.GRP_ID AND hier.PRECURSOR_ID_EXISTS=d.PRECURSOR_ID
         AND c.CLIENT_ID=d.CLIENT_ID AND c.MPI=d.MPI AND c.GRP_ID=d.GRP_ID
         AND c.TIMEFRAME_ID=d.TIMEFRAME_ID AND c.ELIG_CDS_ID=d.ELIG_CDS_ID)
    */

    val dfExceptUnionOne = tempScorePrecTimingHier.groupBy($"client_id", $"mpi", $"grp_id", $"timeframe_id", $"elig_cds_id")
      .agg(collectListFromType[temp_score_prec_timinghier_without_identifier](sparkSession).as("grouped")).as[grouped_timinghier]
      .flatMap(groupedRow => {

        val group = groupedRow.grouped
        val relevantEntries = tL3MapScoreGrpHier.filter(_.grp_id == groupedRow.grp_id)
        val (excluded, nonExcluded) = group.partition(g => {
          relevantEntries.exists(re => re.precursor_id_exclude == g.precursor_id)
        })
        val excludedPrecursorIds = excluded.map(_.precursor_id).toSet
        val relevantExcludedButExistsEntries = relevantEntries.filter(re => excludedPrecursorIds.contains(re.precursor_id_exclude) && group.exists(g => g.precursor_id == re.precursor_id_exists))
        val nonExcludedAndNonExisting = excluded.filterNot(g => relevantExcludedButExistsEntries.exists(re => re.precursor_id_exclude == g.precursor_id))

        (nonExcluded ++ nonExcludedAndNonExisting)
          .map(filteredRow => temp_score_prec_timinghier_data(
            groupedRow.client_id,
            groupedRow.mpi,
            groupedRow.grp_id,
            groupedRow.timeframe_id,
            groupedRow.elig_cds_id,
            filteredRow.precursor_id,
            filteredRow.precursor_min_dt,
            filteredRow.precursor_max_dt,
            filteredRow.precursor_domain,
            filteredRow.precursor_type,
            filteredRow.precursor_value,
            filteredRow.precursor_cds_grp,
            filteredRow.sensitive_ind))
          .distinct
      }).toDF

    /**
      * select
         client_id
         , mpi
         , a.grp_id
         , (SELECT t.timeframe_id FROM L4_timeframe t WHERE t.timeframe_type='SRE') AS timeframe_id
         , (select elig_cds_id FROM  L4_dict_elig_cds WHERE elig_cds_desc='Claims') AS elig_cds_id
         , precursor_id
         , cast(null as date) as precursor_min_dt
         , cast(null as date) as precursor_max_dt
         , 'SRE' as precursor_domain
         , marker_type as precursor_type
         , cast(null as string) as precursor_value
         , case when sensitive_ind is not null then sensitive_ind else 0 end as sensitive_ind
        from l1_sre_marker_profile
        join l3_map_precursor_sre using (marker_id)
        join l3_dict_precursor using (precursor_id)
        CROSS JOIN (SELECT grp_id, max(active_ind) as active_ind
        from l3_dict_score_grp
        join l3_map_score_grp using (grp_id)
        join l4_dict_score using (score_id)
        where grp_name='SRE Markers'
        group by grp_id) a
        where a.active_ind=1
      */
    val timeframe_id = tL4Timeframe.where(tL4Timeframe("timeframe_type") === lit("SRE")).as[l4_timeframe].collect().headOption.map(_.timeframe_id).getOrElse(new Integer(0))
    val elig_cds_id = tL4DictEligCds.where(tL4DictEligCds("elig_cds_desc") === lit("Claims")).as[l4_dict_elig_cds].collect().headOption.map(_.elig_cds_id).getOrElse(new Integer(0))
    val dfCrossJoin = tL3DictScoreGrp
      .join(broadcast(tL3MapScoreGrp), tL3DictScoreGrp("grp_id") === tL3MapScoreGrp("grp_id"))
      .join(broadcast(tL4DictScore), tL3MapScoreGrp("score_id") === tL4DictScore("score_id"))
      .where(tL3DictScoreGrp("grp_name") === lit("SRE Markers")).groupBy(tL3DictScoreGrp("grp_id")).agg(max(tL4DictScore("active_ind")).as("active_ind"))
    val dfUnionTwo = l1SreMarkerProfile
      .join(broadcast(tL3MapPrecursorSre), l1SreMarkerProfile("marker_id") === tL3MapPrecursorSre("marker_id"))
      .join(broadcast(tL3DictPrecursor), tL3MapPrecursorSre("precursor_id") === tL3DictPrecursor("precursor_id"))
      .crossJoin(dfCrossJoin.as("a")).where($"a.active_ind" === lit(1))
      .select(
        l1SreMarkerProfile("client_id"),
        l1SreMarkerProfile("mpi"),
        $"a.grp_id",
        lit(timeframe_id).as("timeframe_id"),
        lit(elig_cds_id).as("elig_cds_id"),
        tL3DictPrecursor("precursor_id"),
        lit(null).cast(TimestampType).as("precursor_min_dt"),
        lit(null).cast(TimestampType).as("precursor_max_dt"),
        lit("SRE").as("precursor_domain"),
        l1SreMarkerProfile("marker_type").as("precursor_type"),
        lit(null).cast(StringType).as("precursor_value"),
        lit(null).as("precursor_cds_grp"),
        when(tL3DictPrecursor("sensitive_ind").isNotNull, tL3DictPrecursor("sensitive_ind")).otherwise(lit(0)).as("sensitive_ind")
      )

    /**
      * SELECT
          tmp.CLIENT_ID,
          tmp.MPI,
          grp.GRP_ID,
          tmp.TIMEFRAME_ID,
          tmp.ELIG_CDS_ID,
          prec.PRECURSOR_ID
          , cast(null as date) as precursor_min_dt
          , cast(null as date) as precursor_max_dt
          , dict.PRECURSOR_DOMAIN_CD AS PRECURSOR_DOMAIN
          , dict.PRECURSOR_DOMAIN_CD AS PRECURSOR_TYPE
          , ttr.SCORE AS PRECURSOR_VALUE
          , case when dict.SENSITIVE_IND is not null then dict.SENSITIVE_IND else 0 end as SENSITIVE_IND
        FROM temp_score_population tmp
        JOIN temp_ttr_calc ttr ON (tmp.CLIENT_ID=ttr.CLIENT_ID AND tmp.MPI=ttr.MPI AND tmp.TIMEFRAME_ID=ttr.TIMEFRAME_ID AND tmp.ELIG_CDS_ID=ttr.ELIG_CDS_ID)
        JOIN L3_MAP_SCORE_GRP grp ON (tmp.SCORE_ID=grp.SCORE_ID)
        JOIN L3_MAP_SCORE_GRP_THRESHOLD thres ON ((ttr.SCORE<=thres.THRESHOLD_MAX OR thres.THRESHOLD_MAX IS NULL) AND (ttr.SCORE>=thres.THRESHOLD_MIN OR thres.THRESHOLD_MIN IS NULL))
        JOIN L3_MAP_SCORE_GRP_PRECUR prec ON (prec.GRP_ID=grp.GRP_ID AND prec.GRP_PRECURSOR_DESC='Labile INR: Time in Therapeutic Range < 60%')
        JOIN L3_DICT_PRECURSOR dict ON (dict.PRECURSOR_ID=prec.PRECURSOR_ID)
        CROSS JOIN (SELECT SCORE_ID FROM L4_DICT_SCORE WHERE SCORE_NAME='HAS-BLED') bled
        WHERE bled.SCORE_ID=tmp.SCORE_ID --select rows that pertain to HAS-BLED Score
        AND tmp.ALL_REQUIREMENTS_SATISFIED=1
      */
    val dfCrossJoin2 = tL4DictScore.where(tL4DictScore("score_name") === lit("HAS-BLED")).select(tL4DictScore("score_id"))

    val dfUnionThree = tempScorePopulation.as("tmp").where($"tmp.all_requirements_satisfied" === lit(1))
      .join(tempTtrCalc.as("ttr"), $"tmp.client_id" === $"ttr.client_id" and $"tmp.mpi" === $"ttr.mpi"
        and $"tmp.timeframe_id" === $"ttr.timeframe_id" and $"tmp.elig_cds_id" === $"ttr.elig_cds_id")
      .join(broadcast(tL3MapScoreGrp).as("grp"), $"tmp.score_id" === $"grp.score_id")
      .join(broadcast(tL3MapScoreGrpThreshold).as("thres"), ($"ttr.score" <= $"thres.threshold_max" or $"thres.threshold_max".isNull)
        and ($"ttr.score" >= $"thres.threshold_min" or $"thres.threshold_min".isNull))
      .join(broadcast(l3MapScoreGrpPrecur).as("prec"), $"prec.grp_id" === $"grp.grp_id" and $"prec.grp_precursor_desc" === lit("Labile INR: Time in Therapeutic Range < 60%"))
      .join(broadcast(tL3DictPrecursor).as("dict"), $"dict.precursor_id" === $"prec.precursor_id")
      .join(dfCrossJoin2.as("bled"), $"bled.score_id" === $"tmp.score_id")
      .select(
        $"tmp.client_id",
        $"tmp.mpi",
        $"grp.grp_id",
        $"tmp.timeframe_id",
        $"tmp.elig_cds_id",
        $"prec.precursor_id",
        lit(null).cast(TimestampType).as("precursor_min_dt"),
        lit(null).cast(TimestampType).as("precursor_max_dt"),
        $"dict.precursor_domain_cd".as("precursor_domain"),
        $"dict.precursor_domain_cd".as("precursor_type"),
        $"ttr.score".as("precursor_value"),
        when($"ttr.ttr_cds_grp".isNotNull, $"ttr.ttr_cds_grp").otherwise(lit("0")).as("precursor_cds_grp"),
        when($"dict.sensitive_ind".isNotNull, $"dict.sensitive_ind").otherwise(lit(0)).as("sensitive_ind")
      )

    dfExceptUnionOne
      .union(dfUnionTwo)
      .union(dfUnionThree)
  }
}

case class grouped_timinghier(client_id: String = null, mpi: String = null, grp_id: java.lang.Integer = null, timeframe_id: java.lang.Integer = null,
                              elig_cds_id: java.lang.Integer = null, grouped: Seq[temp_score_prec_timinghier_without_identifier] = null)

case class temp_score_prec_timinghier_without_identifier(precursor_id: java.lang.Integer = null, precursor_min_dt: java.sql.Date = null,
                                                         precursor_max_dt: java.sql.Date = null, precursor_domain: String = null, precursor_type: String = null, precursor_value: String = null,
                                                         precursor_cds_grp: String = null, sensitive_ind: java.lang.Integer = null)

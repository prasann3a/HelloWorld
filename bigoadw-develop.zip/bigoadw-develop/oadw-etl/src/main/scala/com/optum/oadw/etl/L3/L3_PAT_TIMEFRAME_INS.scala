
package com.optum.oadw.etl.L3


import com.optum.oadw.oadwModels.l3_pat_timeframe_ins
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata


object L3_PAT_TIMEFRAME_INS extends QueryAndMetadata[l3_pat_timeframe_ins] {
  override def name: String = "L3_PAT_TIMEFRAME_INS"

  override def sparkSql: String = """SELECT  p.client_id
, p.mpi
, t.timeframe_id
, i.payer_cui
, NVL(i.lob_cui,'CH999999') AS lob_cui
FROM L2_patient_info p
INNER JOIN L4_Timeframe t ON (p.dob <= t.END_DT AND (p.dod >= t.START_DT or p.dod is NULL)) --have to be alive to be insured
INNER JOIN L2_pat_insurance i ON (p.mpi = i.mpi
AND i.yr_month <=  CAST (date_format(t.end_dt,'yyyyMM') AS INT)
AND i.yr_month >=  CAST (date_format(t.start_dt,'yyyyMM') AS INT)
)
WHERE i.primary_ind = 1
GROUP BY p.client_id
, p.mpi
, t.timeframe_id
, i.payer_cui
, i.lob_cui"""

  override def dependsOn: Set[String] = Set("L2_PATIENT_INFO","L4_TIMEFRAME","L2_PAT_INSURANCE")

  def originalSql: String = """INSERT /*+ APPEND */ INTO L3_pat_timeframe_ins(client_id,mpi,timeframe_id,payer_cui,lob_cui)
SELECT /*+ PARALLEL(4) */ p.client_id
    , p.mpi
    , t.timeframe_id
    , i.payer_cui
    , NVL(i.lob_cui,'CH999999') AS lob_cui
FROM L2_patient_info p
INNER JOIN L4_Timeframe t ON (p.dob <= t.END_DT AND (p.dod >= t.START_DT or p.dod is NULL)) --have to be alive to be insured
INNER JOIN L2_pat_insurance i ON (p.mpi = i.mpi
                                          AND i.yr_month <= TO_NUMBER(TO_CHAR(t.end_dt,'YYYYMM'))
                                          AND i.yr_month >= TO_NUMBER(TO_CHAR(t.start_dt,'YYYYMM'))
                                   )
WHERE i.primary_ind = 1
GROUP BY p.client_id
    , p.mpi
    , t.timeframe_id
    , i.payer_cui
    , i.lob_cui
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("client_id",None,None), OutputColumn("mpi",None,None), OutputColumn("timeframe_id",None,None), OutputColumn("payer_cui",None,None), OutputColumn("lob_cui",None,None)))

  def directoryLevel: String = "L3"





  val originalSqlFileName: String = "L3_pat_timeframe_ins_build.sql"
}


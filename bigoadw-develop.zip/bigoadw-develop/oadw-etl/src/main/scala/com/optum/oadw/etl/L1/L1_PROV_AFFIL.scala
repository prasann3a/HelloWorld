
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_affil, prov_affil}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_AFFIL extends TableInfo[l1_prov_affil]{
  override def dependsOn: Set[String] = Set("PROV_AFFIL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_AFFIL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val provAffil = loadedDependencies("PROV_AFFIL").as[prov_affil]

    provAffil
    .select(
			$"groupid".as("client_id"),
			$"prov_affil_id",
			$"localproviderid",
			$"eff_date",
			$"end_date",
			$"client_ds_id",
			$"datasrc",
			$"master_hgprovid"
    )
  }
}


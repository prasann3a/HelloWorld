package com.optum.oadw.etl.L2

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l1_map_cui_ii_spec, l1_map_specialty, l1_provider_master, l1_ref_cmsnpi}
import org.apache.spark.sql.functions.{coalesce, when}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

case class temp_provider_cui_spec_data(client_id: String, prov_id: String, npi: String, prim_spec_cui: String, prim_loc_spec_cui: String,
                                       facility_ind: java.lang.Integer, ii_code: String)

object TEMP_PROVIDER_CUI_SPEC extends TableInfo[temp_provider_cui_spec_data] {
  override def name: String = "TEMP_PROVIDER_CUI_SPEC"

  override def dependsOn: Set[String] = Set("L1_PROVIDER_MASTER", "L1_MAP_SPECIALTY", "L1_REF_CMSNPI", "L1_MAP_CUI_II_SPEC")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l1ProviderMaster = loadedDependencies("L1_PROVIDER_MASTER").as[l1_provider_master]

    val l1MapSpecialty = loadedDependencies("L1_MAP_SPECIALTY").as[l1_map_specialty]

    val l1RefCmsNpi = loadedDependencies("L1_REF_CMSNPI").as[l1_ref_cmsnpi]

    val l1MapCuiIISpec = loadedDependencies("L1_MAP_CUI_II_SPEC").as[l1_map_cui_ii_spec]

    createTempProviderCuiSpec(sparkSession, l1ProviderMaster, l1MapSpecialty, l1RefCmsNpi, l1MapCuiIISpec)

  }

  private def createTempProviderCuiSpec(sparkSession: SparkSession,
                                        l1ProviderMaster: Dataset[l1_provider_master],
                                        l1MapSpecialty: Dataset[l1_map_specialty],
                                        l1RefCmsNpi: Dataset[l1_ref_cmsnpi],
                                        l1MapCuiIISpec: Dataset[l1_map_cui_ii_spec]): DataFrame = {
    import sparkSession.implicits._

    l1ProviderMaster.as("provmaster")
      .join(l1MapSpecialty.as("ms"), $"provmaster.client_id" === $"ms.client_id" and $"provmaster.localprimaryspecialty" === $"ms.local_code", "left_outer")
      .join(l1RefCmsNpi.as("cms"), $"provmaster.npi" === $"cms.npi", "left_outer")
      .withColumn("prim_spec_cui", coalesce($"ms.cui", when($"provmaster.localprimaryspecialty".isNotNull, "CH999990").otherwise("CH999999")))
      .join(l1MapCuiIISpec.as("cuispec"), $"cuispec.hts_cui" === $"prim_spec_cui", "left_outer")
      .select(
        $"provmaster.client_id", $"provmaster.master_hgprovid".as("prov_id"),
        $"provmaster.npi", $"prim_spec_cui", $"prim_spec_cui".as("prim_loc_spec_cui"),
        when($"cms.entity_type_code" === 2, 1).otherwise(0).as("facility_ind"),
        $"cuispec.ii_code"
      )
  }

  def directoryLevel: String = "L2"
}

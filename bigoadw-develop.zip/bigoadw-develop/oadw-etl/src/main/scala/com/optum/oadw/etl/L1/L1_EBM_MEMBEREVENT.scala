
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ebm_memberevent, ebm_memberevent}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_EBM_MEMBEREVENT extends TableInfo[l1_ebm_memberevent]{
  override def dependsOn: Set[String] = Set("EBM_MEMBEREVENT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_EBM_MEMBEREVENT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ebmMemberevent = loadedDependencies("EBM_MEMBEREVENT").as[ebm_memberevent]

    ebmMemberevent
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi".as("mpi"),
			$"report_case_id",
			$"event",
			$"event_from_date".as("event_from_dt"),
			$"episode_from_date".as("episode_from_dt"),
			$"episode_thru_date".as("episode_thru_dt"),
			$"event_thru_date".as("event_thru_dt"),
			$"unique_recid",
			$"care_cat",
			$"age",
			$"age_months",
			$"episode_provider",
			$"episode_prov_spec",
			$"file_processing_month".as("file_processing_month_dt"),
			$"process"
    )
  }
}


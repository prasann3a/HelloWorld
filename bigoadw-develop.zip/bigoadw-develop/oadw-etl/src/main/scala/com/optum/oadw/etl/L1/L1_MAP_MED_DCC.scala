
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_med_dcc, zh_med_map_dcc}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_MED_DCC extends TableInfo[l1_map_med_dcc]{
  override def dependsOn: Set[String] = Set("ZH_MED_MAP_DCC")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_MED_DCC"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhMedMapDcc = loadedDependencies("ZH_MED_MAP_DCC").as[zh_med_map_dcc]

    zhMedMapDcc
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"client_ds_id",
			$"localmedcode",
			$"map_used",
			$"hum_med_key",
			$"hum_gen_med_key",
			$"hts_generic",
			$"hts_generic_ext",
			$"hts_gpi",
			$"top_ndc",
			$"dcc",
			$"dts_version",
			$"rxnorm_code"
    )
  }
}


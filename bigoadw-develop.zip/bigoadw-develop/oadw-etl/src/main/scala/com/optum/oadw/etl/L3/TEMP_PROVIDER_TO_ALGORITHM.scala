package com.optum.oadw.etl.L3


import java.sql.Timestamp
import java.time.LocalDateTime

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels._
import com.optum.oadw.oadw_ref.models.{l3_dict_elig_prov, l3_map_elig_prov_code}
import org.apache.spark.sql.functions.{date_format, lit, not, to_date}
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object TEMP_PROVIDER_TO_ALGORITHM extends TableInfo[providerToAlgorithm] {
  override def name: String = "TEMP_PROVIDER_TO_ALGORITHM"

  override def dependsOn: Set[String] = Set("TEMP_PROVIDER_ATTRIBUTION_ALGORITHM_DATA", "REFERENCE_SCHEMA_L3_DICT_ELIG_PROV",
    "REFERENCE_SCHEMA_L3_MAP_ELIG_PROV_CODE", "L2_PROVIDER_INFO", "L1_PROV_CLIENT_REL", "MD_OADW_INSTANCE")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempProvAttribPrecur = loadedDependencies("TEMP_PROVIDER_ATTRIBUTION_ALGORITHM_DATA").as[precursorAlgorithmData]
    val tL3DictEligProv = loadedDependencies("REFERENCE_SCHEMA_L3_DICT_ELIG_PROV").as[l3_dict_elig_prov]
    val tL3MapEligProvCode = loadedDependencies("REFERENCE_SCHEMA_L3_MAP_ELIG_PROV_CODE").as[l3_map_elig_prov_code]
    val providerInfo = loadedDependencies("L2_PROVIDER_INFO").as[l2_provider_info]
    val l1ProvClientRel = loadedDependencies("L1_PROV_CLIENT_REL").as[l1_prov_client_rel]
    val tMOADWInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]

    val dataThruDt = getDataThruDt(sparkSession, tMOADWInstance)

    val tempProvAttribDomesticProv = createListOfDomesticProviders(sparkSession, l1ProvClientRel, dataThruDt)

    createPrecursorToProviderMapping(sparkSession, tempProvAttribPrecur, tL3DictEligProv, tL3MapEligProvCode, providerInfo, tempProvAttribDomesticProv).toDF()
  }

  private def getDataThruDt(sparkSession: SparkSession, tMOADWInstance: Dataset[md_oadw_instance]): Timestamp = {
    import sparkSession.implicits._
    tMOADWInstance.where($"attribute_name" === lit("DATA_THRU")).select(to_date($"attribute_value", "yyyyMMdd").as("data_thru_dt")).as[Timestamp].collect().headOption.getOrElse(Timestamp.valueOf(LocalDateTime.now()))
  }

  private def createListOfDomesticProviders(sparkSession: SparkSession, l1ProvClientRel: Dataset[l1_prov_client_rel], dataThru: Timestamp): Dataset[String] = {

    import sparkSession.implicits._

    l1ProvClientRel.withColumn("data_thru_dt", lit(dataThru))
      .where($"LOCALRELSHIPCODE" === "IN_NETWORK"
        and ($"data_thru_dt" between(to_date(date_format($"START_DT", "yyyy-MM-dd")).cast(TimestampType), to_date(date_format($"END_DT", "yyyy-MM-dd")).cast(TimestampType))))
      .select($"MSTRPROVID")
      .distinct()
      .as[String]
  }

  private def createPrecursorToProviderMapping(sparkSession: SparkSession,
                                               tempProvAttribPrecur: Dataset[precursorAlgorithmData],
                                               tL3DictEligProv: Dataset[l3_dict_elig_prov],
                                               tL3MapEligProvCode: Dataset[l3_map_elig_prov_code],
                                               l2ProviderInfo: Dataset[l2_provider_info],
                                               mstrProvIdDF: Dataset[String]): Dataset[providerToAlgorithm] = {
    import sparkSession.implicits._
    val distinctAttribPrecur = tempProvAttribPrecur.select($"PROV_ATTRIB_PRECURSOR_ID", $"ELIG_PROV_ID", $"PROV_ATTRIB_PRECUR_TYPE_ID")

    val baseDF = distinctAttribPrecur.as("prec")
      .join(tL3DictEligProv.select($"ELIG_PROV_ID", $"USE_PCP_IND", $"DOMESTIC_ONLY_IND").as("dict"), "ELIG_PROV_ID")
      .join(tL3MapEligProvCode.select($"ELIG_PROV_ID", $"CODE_TYPE", $"CODE").as("mepc"), Seq("ELIG_PROV_ID"), "left_outer")

    val prov = l2ProviderInfo.select($"PCP_IND", $"SPECIALTY_ID", $"PROV_ID").as("prov")

    val eligProvId1Or2 = baseDF.where($"prec.ELIG_PROV_ID" === 1 or $"prec.ELIG_PROV_ID" === 2).crossJoin(prov)
    val pcpInd1 = baseDF.where($"dict.USE_PCP_IND" === 1).crossJoin(prov.where($"prov.PCP_IND" === 1))
    val specialtyInd = baseDF.where($"mepc.CODE_TYPE" === "SPECIALTY_ID").join(prov, $"mepc.CODE" === $"prov.SPECIALTY_ID")

    eligProvId1Or2.union(pcpInd1).union(specialtyInd)
      .join(mstrProvIdDF.as("pcr"), $"prov.PROV_ID" === $"pcr.MSTRPROVID", "left_outer")
      .where(not($"dict.DOMESTIC_ONLY_IND" === lit(1) and $"pcr.MSTRPROVID".isNull))
      .select("PROV_ATTRIB_PRECURSOR_ID", "PROV_ID", "PROV_ATTRIB_PRECUR_TYPE_ID")
      .distinct()
      .as[providerToAlgorithm]
  }
}

case class providerToAlgorithm(prov_id: String, prov_attrib_precursor_id: java.lang.Integer, prov_attrib_precur_type_id: Int)

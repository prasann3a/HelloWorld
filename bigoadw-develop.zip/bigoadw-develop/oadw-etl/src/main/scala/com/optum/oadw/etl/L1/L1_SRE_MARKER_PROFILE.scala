
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_sre_marker_profile, sre_marker_profile}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_SRE_MARKER_PROFILE extends TableInfo[l1_sre_marker_profile]{
  override def dependsOn: Set[String] = Set("SRE_MARKER_PROFILE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_SRE_MARKER_PROFILE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val sreMarkerProfile = loadedDependencies("SRE_MARKER_PROFILE").as[sre_marker_profile]

    sreMarkerProfile
    .select(
			$"groupid".as("client_id"),
			$"family_id".as("mpi"),
			$"patient_id",
			$"marker_id",
			$"marker_type",
      $"marker_value"
    )
  }
}



/**
  * auto-generated code
*/
package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_map_upload_rules
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata


object L2_MAP_UPLOAD_RULES extends QueryAndMetadata[l2_map_upload_rules] {
  override def name: String = "L2_MAP_UPLOAD_RULES"

  override def sparkSql: String = """SELECT
client_id,
client_ds_id,
rule_type,
id_type,
id_sub_type,
ds_display_name,
regex,
datasource,
is_default_datasource,
dts_version
FROM L1_map_upload_rules"""

  override def dependsOn: Set[String] = Set("L1_MAP_UPLOAD_RULES")

  def originalSql: String = """--this table is directly referenced by OPrime (and OADW)
INSERT /*+ APPEND */ INTO L2_map_upload_rules
(
  client_id,
  client_ds_id,
  rule_type,
  id_type,
  id_sub_type,
  ds_display_name,
  regex,
  datasource,
  is_default_datasource,
  dts_version
)
SELECT /*+ parallel(4) */
  client_id,
  client_ds_id,
  rule_type,
  id_type,
  id_sub_type,
  ds_display_name,
  regex,
  datasource,
  is_default_datasource,
  dts_version
FROM L1_map_upload_rules
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("client_id",None,None), OutputColumn("client_ds_id",None,None), OutputColumn("rule_type",None,None), OutputColumn("id_type",None,None), OutputColumn("id_sub_type",None,None), OutputColumn("ds_display_name",None,None), OutputColumn("regex",None,None), OutputColumn("datasource",None,None), OutputColumn("is_default_datasource",None,None), OutputColumn("dts_version",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_map_upload_rules_build.sql"
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_appointment, appointment}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_APPOINTMENT extends TableInfo[l1_appointment]{
  override def dependsOn: Set[String] = Set("APPOINTMENT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_APPOINTMENT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("APPOINTMENT").as[appointment]

    cdrTbl
    .select(
		$"groupid".as("client_id"),
		$"client_ds_id",
		$"datasrc",
		$"patientid",
		$"hgpid",
		$"grp_mpi".as("mpi"),
		$"appointmentid",
		$"appointmentdate".as("appointment_dtm"),
		$"locationid",
		$"providerid",
		$"mstrprovid",
		$"local_appt_type",
		$"appointment_reason"
    )
  }
}


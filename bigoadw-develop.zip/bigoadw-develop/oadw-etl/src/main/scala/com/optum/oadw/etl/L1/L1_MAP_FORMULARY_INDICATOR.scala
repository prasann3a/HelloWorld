
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_formulary_indicator, map_formulary_indicator}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_FORMULARY_INDICATOR extends TableInfo[l1_map_formulary_indicator]{
  override def dependsOn: Set[String] = Set("MAP_FORMULARY_INDICATOR")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_FORMULARY_INDICATOR"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapFormularyIndicator = loadedDependencies("MAP_FORMULARY_INDICATOR").as[map_formulary_indicator]

    mapFormularyIndicator
    .select(
			$"groupid".as("client_id"),
			$"localcode",
			$"cui",
			$"dts_version"
    )
  }
}


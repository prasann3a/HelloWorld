package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{ l1_ref_imap_pos, l1_ii_map_pos, l2_ii_map_pos }
import com.optum.oadw.oadw_ref.models.l2_map_sensitive_category
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{ DataFrame, SparkSession }

object L2_II_MAP_POS extends TableInfo[l2_ii_map_pos] {
  override def name      = "L2_II_MAP_POS"
  override def dependsOn = Set("L1_II_MAP_POS", "L2_MAP_SENSITIVE_CATEGORY", "L1_REF_IMAP_POS")

  override def createDataFrame(
    sparkSession: SparkSession,
    loadedDependencies: Map[String, DataFrame],
    udfMap: Map[String, UserDefinedFunctionForDataLoader],
    runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1IIMapPos             = loadedDependencies("L1_II_MAP_POS").as[l1_ii_map_pos]
    val l1RefImapPos           = loadedDependencies("L1_REF_IMAP_POS").as[l1_ref_imap_pos]
    val l2MapSensitiveCategory = loadedDependencies("L2_MAP_SENSITIVE_CATEGORY").as[l2_map_sensitive_category]

    l1IIMapPos
      .as("mp")
      .join(l1RefImapPos.as("rip"), $"mp.pos_i" === $"rip.pos_i", "left_outer")
      .join(l2MapSensitiveCategory.as("sc"), expr("UPPER(mp.pos_desc) LIKE CONCAT('%', UPPER(sc.sensitive_text), '%')"), "left_outer")
      .select(
        $"mp.pos_i".cast(IntegerType),
        $"mp.pos_desc",
        coalesce($"rip.sensitive_ind", lit(0)).as("sensitive_ind"),
        when($"rip.sensitive_ind" === lit(1), coalesce($"sc.sensitive_cat_id", lit(999)))
          .otherwise(lit(1))
          .as("sensitive_cat_id"),
        when($"sensitive_ind" === lit(1), row_number().over(Window.partitionBy($"mp.pos_i").orderBy($"sensitive_hierarchy")))
          .otherwise(lit(1))
          .as("order")
      )
      .where($"order" === 1)
      .drop("order")
  }
}

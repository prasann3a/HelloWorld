
/**
  * auto-generated code
*/
package com.optum.oadw.etl.L2

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_etg_qual_evt_ind_data(clinical_event_id: java.lang.Long = null)

object TEMP_ETG_QUAL_EVT_IND extends QueryAndMetadata[temp_etg_qual_evt_ind_data] {
  override def name: String = "TEMP_ETG_QUAL_EVT_IND"

  override def sparkSql: String = """SELECT DISTINCT pp.clinical_event_id
FROM L2_PAT_PROC pp
INNER JOIN L3_MAP_PROC_ETG_ELIG ee ON (pp.code_type = ee.code_type and pp.proc_cd = ee.proc_cd)"""

  override def dependsOn: Set[String] = Set("L2_PAT_PROC","L3_MAP_PROC_ETG_ELIG")

  def originalSql: String = """-- Note that L2_PAT_PROC doesnt have the clinical_event_id column populated yet, so this will be an
-- empty table until that is populated.
-- FMP @noParse (READ:L2_PAT_PROC,L3_MAP_PROC_ETG_ELIG WRITE:temp_etg_qual_evt_ind)
CREATE TABLE temp_etg_qual_evt_ind PCTFREE 0 NOLOGGING PARTITION BY HASH (clinical_event_id)
AS
SELECT DISTINCT pp.clinical_event_id
FROM L2_PAT_PROC pp
INNER JOIN L3_MAP_PROC_ETG_ELIG ee ON (pp.code_type = ee.code_type and pp.proc_cd = ee.proc_cd)"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_pat_clinical_event_build.sql"
}


package com.optum.oadw.etl.L2
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_provider_info
import com.optum.oadw.etlContract.OutputColumn
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_PROVIDER_INFO extends TableInfo[l2_provider_info] {
  override def name: String = "L2_PROVIDER_INFO"

  override def dependsOn: Set[String] = Set("L1_PROV_CONTACT_SUMMARY","L1_REF_CMSNPI","L2_MAP_CDS_FLG","L1_FACILITY_EXT",
    "L1_V_PROVIDER_MASTER","L1_MAP_PROVIDER_TAXONOMY","L1_MAP_CUI_II_SPEC","L2_MAP_AMB_SITE","L2_II_PROVINFO","L1_PROV_FAC_REL_SUMMARY","L1_PROVIDER")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (name, df) => df.createOrReplaceTempView(name)
    }

    sparkSession.sql(sparkSql)
  }

  def sparkSql: String =
    """
       with amb_site as (
        select mstrprovid, master_siteofcare_id as amb_site_id from (
        select a.*, master_siteofcare_id, row_number() over(partition by mstrprovid order by end_dt desc nulls first, start_dt desc) as rank
        from l1_prov_fac_rel_summary  a
        inner join L1_FACILITY_EXT fr on (a.client_id = fr.client_id and a.client_ds_id = fr.client_ds_id and a.facilityid = fr.facilityid) --- BOBH groupid to client_id
        where localrelshipcode='PRIMARY'
      )
      where rank=1
      ),
      zh_prov as(
      select a.client_id
      , '1' as datasrc
      ,a.prov_id
      ,a.npi
      ,null as sec_provider_id
      ,a.providername
      ,CAST(null AS DECIMAL(3)) as ii_spec
      ,  CAST (c.ii_code AS INT)  as npi_spec
      ,  CAST (d.ii_code AS INT)  as local_spec --requires  to_number  function installed
      ,COALESCE(b.address_line1, f.prov_first_line_bus_mail_addr) as address_line1
      ,case when b.address_line1 is null then f.prov_bus_mail_addr_city else b.city end as city
      ,case when b.address_line1 is null then f.prov_bus_mail_addr_state else b.state end as state
      ,substr(case when b.address_line1 is null then f.prov_bus_mail_addr_postalcode else b.zipcode end,1,20) as zipcode
      ,case when f.entity_type_code = 2 then 1 else 0 end as npi_fac_ind
      ,case when COALESCE(  CAST (c.ii_code AS DOUBLE) ,  CAST (d.ii_code AS DOUBLE) ) between 100 and 199 then 1 else 0 end as spec_fac_ind  -- BOBH REMOVED USER REFERENCE
      ,CAST(null AS INT) as pcp_ind
      ,null as prov_affil_id
      ,amb_site_id
      from L1_v_provider_master a
      LEFT JOIN (SELECT pcs.*
      ,ROW_NUMBER() OVER (PARTITION BY pcs.master_hgprovid
      ORDER BY CASE WHEN mapped_contact_type = 'CH003087' THEN 1
      WHEN mapped_contact_type = 'CH003203' THEN 2
      WHEN mapped_contact_type = 'CH003088' THEN 3
      WHEN mapped_contact_type = 'CH003089' THEN 4
      ELSE 5 END
      ) AS rownbr
      FROM L1_prov_contact_summary pcs
      ) b ON (a.prov_id=b.master_hgprovid AND b.rownbr = 1)
      left join L1_MAP_PROVIDER_TAXONOMY c on a.npiprimarycode=c.taxonomy_code
      left join L1_map_cui_ii_spec d on a.primaryspecialty=d.hts_cui
      left join amb_site e on a.prov_id=e.mstrprovid --uses AMB_STE CTE query
      left join L1_ref_cmsnpi f on a.npi=f.npi
      where a.prov_id is not null
      ),
      ii_prov as(
      select
      '2' as datasrc
      ,a.provider_id --=master_hgprovid
      ,null as npi --sec_provider_id?
      ,sec_provider_id
      ,provider_name
      ,prv_sp_4 as ii_spec
      ,null as npi_spec
      ,null as local_spec
      , case when length(regexp_extract(address, '(^[a-zA-Z0-9 ]+)', 1)) = 0 then null else regexp_extract(address, '(^[a-zA-Z0-9 ]+)', 1) end as address_line1
      ,a.prov_city as city
      ,state_n
      ,zip
      ,case when prv_sp_4 between 100 and 199 then 1 else 0 end as spec_fac_ind
      , CAST (pcp_indicator AS INT)  as pcp_indicator
      ,affil_id as prov_affil_id
      ,null as amb_site_id
      ,cust_prv_1
      ,cust_prv_2
      ,cust_prv_3
      ,cust_prv_4
      ,cust_prv_5
      ,cust_prv_6
      ,cust_prv_7
      ,cust_prv_8
      ,cust_prv_9
      ,cust_prv_10
      ,cust_prv_11
      ,cust_prv_12
      ,cust_prv_13
      ,cust_prv_14
      ,cust_prv_15
      ,cust_prv_16
      ,cust_prv_17
      ,cust_prv_18
      ,cust_prv_19
      ,cust_prv_20
      ,prov_userdef_1
      ,prov_userdef_2_id
      ,sec_provider_id_2
      from l2_ii_provinfo  a
      where provider_id is not null
      ),
      cds_flg_agg as (
      SELECT p.master_hgprovid PROV_ID, listagg(mcf.client_ds_id) as cds_grp
      FROM L1_v_provider_master a
      INNER JOIN l1_provider p on a.client_id = p.client_id and p.master_hgprovid = a.prov_id
      INNER JOIN L2_MAP_CDS_FLG MCF ON(p.CLIENT_ID = mcf.CLIENT_ID AND p.CLIENT_DS_ID = MCF.CLIENT_DS_ID)
      GROUP BY p.master_hgprovid
      )
      select a.client_id
      ,cf.cds_grp
      ,COALESCE(a.prov_id,b.provider_id) as prov_id
      ,a.npi
      ,cast(COALESCE(b.ii_spec,a.npi_spec,a.local_spec,590) as long) as specialty_id
      ,COALESCE(a.npi_fac_ind,b.spec_fac_ind,a.spec_fac_ind,0) as facility_ind
      ,COALESCE(b.pcp_indicator,a.pcp_ind,0) as pcp_ind
      ,b.sec_provider_id
      ,upper(COALESCE(b.provider_name,a.providername,'UNKNOWN')) as provider_name
      ,case when b.address_line1 is null then a.address_line1 else b.address_line1 end as address
      ,case when b.address_line1 is null then a.city else b.city end as city --do we need city?
      ,case when b.address_line1 is null then (case when length(a.state)>2 then null else a.state end) else b.state_n end as state
      ,case when b.address_line1 is null then a.zipcode else b.zip end as zipcode
      ,b.prov_affil_id
      ,coalesce(a.amb_site_id, 0) as amb_site_id
      ,b.cust_prv_1
      ,b.cust_prv_2
      ,b.cust_prv_3
      ,b.cust_prv_4
      ,b.cust_prv_5
      ,b.cust_prv_6
      ,b.cust_prv_7
      ,b.cust_prv_8
      ,b.cust_prv_9
      ,b.cust_prv_10
      ,b.cust_prv_11
      ,b.cust_prv_12
      ,b.cust_prv_13
      ,b.cust_prv_14
      ,b.cust_prv_15
      ,b.cust_prv_16
      ,b.cust_prv_17
      ,b.cust_prv_18
      ,b.cust_prv_19
      ,b.cust_prv_20
      ,b.prov_userdef_1
      ,b.prov_userdef_2_id
      ,b.sec_provider_id_2
      from zh_prov a
      full outer join ii_prov b on a.prov_id=b.provider_id
      join cds_flg_agg cf on cf.prov_id = a.prov_id
    """

  def originalSql: String = """-- Format is trying to stay very close to reference in Wiki

INSERT /*+ APPEND */ INTO L2_PROVIDER_INFO (
      CLIENT_ID, PROV_ID, NPI, SPECIALTY_ID, FACILITY_IND, PCP_IND, SEC_PROVIDER_ID, PROVIDER_NAME,
      ADDRESS, CITY, STATE, ZIPCODE, PROV_AFFIL_ID, AMB_SITE_ID )
-- Global replace "a.master_hgprovid" with "a.prov_id"
with amb_site as (
    select mstrprovid, CAST(master_siteofcare_id AS INT) as amb_site_id from (
        select a.*, master_siteofcare_id, row_number() over(partition by mstrprovid order by end_dt desc nulls first, start_dt desc) as rank
        from L1_prov_fac_rel_summary  a
        inner join L1_FACILITY_EXT fr on (a.client_id = fr.client_id and a.client_ds_id = fr.client_ds_id and a.facilityid = fr.facilityid) --- BOBH groupid to client_id
        where localrelshipcode='PRIMARY'
    )
    where rank=1
),
zh_prov as(
    select a.client_id
           , '1' as datasrc
            ,a.prov_id
            ,a.npi
            ,null as sec_provider_id
            ,a.providername
            ,CAST(null AS NUMBER(3)) as ii_spec
            ,safe_to_number(c.ii_code) as npi_spec
            ,safe_to_number(d.ii_code) as local_spec --requires SAFE_TO_NUMBER function installed
            ,COALESCE(b.address_line1, f.prov_first_line_bus_mail_addr) as address_line1
            ,case when b.address_line1 is null then f.prov_bus_mail_addr_city else b.city end as city
            ,case when b.address_line1 is null then f.prov_bus_mail_addr_state else b.state end as state
            ,substr(case when b.address_line1 is null then f.prov_bus_mail_addr_postalcode else b.zipcode end,1,20) as zipcode
            ,case when f.entity_type_code = 2 then 1 else 0 end as npi_fac_ind
            ,case when COALESCE(safe_to_number(c.ii_code),safe_to_number(d.ii_code)) between 100 and 199 then 1 else 0 end as spec_fac_ind  -- BOBH REMOVED USER REFERENCE
            ,CAST(null AS NUMBER(1)) as pcp_ind
            ,null as prov_affil_id
            ,amb_site_id
    from L1_v_provider_master a
    LEFT JOIN (SELECT pcs.*
                      ,ROW_NUMBER() OVER (PARTITION BY pcs.master_hgprovid
                                          ORDER BY CASE WHEN mapped_contact_type = 'CH003087' THEN 1
                                                        WHEN mapped_contact_type = 'CH003203' THEN 2
                                                        WHEN mapped_contact_type = 'CH003088' THEN 3
                                                        WHEN mapped_contact_type = 'CH003089' THEN 4
                                                        ELSE 5 END
                                          ) AS rownbr
              FROM L1_prov_contact_summary pcs
              ) b ON (a.prov_id=b.master_hgprovid AND b.rownbr = 1)
    left join L1_MAP_PROVIDER_TAXONOMY c on a.npiprimarycode=c.taxonomy_code
    left join L1_map_cui_ii_spec d on a.primaryspecialty=d.hts_cui
    left join amb_site e on a.prov_id=e.mstrprovid --uses AMB_STE CTE query
    left join L1_ref_cmsnpi f on a.npi=f.npi
    where a.prov_id is not null
),
ii_prov as(
select /*+ parallel (4) */
            '2' as datasrc
            ,a.provider_id --=master_hgprovid
            ,null as npi --sec_provider_id?
            ,sec_provider_id
            ,provider_name
            ,prv_sp_4 as ii_spec
            ,null as npi_spec
            ,null as local_spec
            ,regexp_substr(address, '^[a-zA-Z0-9 ]+') as address_line1
            ,ltrim(regexp_substr(address, '[^,]*$')) as city
            ,state_n
            ,zip
             --,case when c.entity_type_code = 2 then 1 else 0 end as npi_fac_ind
            ,case when prv_sp_4 between 100 and 199 then 1 else 0 end as spec_fac_ind
            ,safe_to_number(pcp_indicator) as pcp_indicator
            ,affil_id as prov_affil_id
            ,null as amb_site_id
    from l2_ii_provinfo  a
    where provider_id is not null
),
cds_flg_agg as (
    SELECT p.master_hgprovid PROV_ID
    FROM L1_v_provider_master a
    INNER JOIN l1_provider p on a.client_id = p.client_id and p.master_hgprovid = a.prov_id
    INNER JOIN L2_MAP_CDS_FLG MCF ON(p.CLIENT_ID = mcf.CLIENT_ID AND p.CLIENT_DS_ID = MCF.CLIENT_DS_ID)
    GROUP BY p.master_hgprovid
)
select a.client_id
        ,COALESCE(a.prov_id,b.provider_id) as prov_id
        ,a.npi
        ,COALESCE(b.ii_spec,a.npi_spec,a.local_spec,590) as specialty_id --590 = other
        ,COALESCE(a.npi_fac_ind,b.spec_fac_ind,a.spec_fac_ind,0) as facility_ind
        ,COALESCE(b.pcp_indicator,a.pcp_ind,0) as pcp_ind
        ,b.sec_provider_id
        ,upper(COALESCE(b.provider_name,a.providername,'UNKNOWN')) as name
        ,case when b.address_line1 is null then a.address_line1 else b.address_line1 end as address
        ,case when b.address_line1 is null then a.city else b.city end as city --do we need city?
        ,case when b.address_line1 is null then (case when length(a.state)>2 then null else a.state end) else b.state_n end as state
        ,case when b.address_line1 is null then a.zipcode else b.zip end as zipcode
        ,b.prov_affil_id
        ,nvl(a.amb_site_id,'0')
from zh_prov a
full outer join ii_prov b on a.prov_id=b.provider_id
join cds_flg_agg cf on cf.prov_id = a.prov_id"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("CLIENT_ID",None,None), OutputColumn("CDS_GRP",None,None), OutputColumn("PROV_ID",None,None), OutputColumn("NPI",None,None), OutputColumn("SPECIALTY_ID",None,None), OutputColumn("FACILITY_IND",None,None), OutputColumn("PCP_IND",None,None), OutputColumn("SEC_PROVIDER_ID",None,None), OutputColumn("PROVIDER_NAME",None,None), OutputColumn("ADDRESS",None,None), OutputColumn("CITY",None,None), OutputColumn("STATE",None,None), OutputColumn("ZIPCODE",None,None), OutputColumn("PROV_AFFIL_ID",None,None), OutputColumn("AMB_SITE_ID",None,None)))

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_provider_info_build.sql"
}

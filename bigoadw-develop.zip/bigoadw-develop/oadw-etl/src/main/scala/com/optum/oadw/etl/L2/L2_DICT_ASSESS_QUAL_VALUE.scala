
/**
  * auto-generated code
*/
package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_dict_assess_qual_value
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata


object L2_DICT_ASSESS_QUAL_VALUE extends QueryAndMetadata[l2_dict_assess_qual_value] {
  override def name: String = "L2_DICT_ASSESS_QUAL_VALUE"

  override def sparkSql: String = """SELECT a.cui as value_cui
, b.concept_name as value_name
, a.map_cui as assessment_cui
FROM l1_map_assessment_cui a
INNER JOIN md_domain_concept b ON (a.cui = b.concept_cui)
UNION
SELECT a.qual_result_code as value_cui
, d.concept_name as value_name
, b.cui as assessment_cui
FROM L1_map_qual_text_result a
INNER JOIN md_domain_concept d ON (a.qual_result_code = d.concept_cui AND d.domain_cui = 'CH001294')
INNER JOIN l1_map_lab b ON (a.lab_code = b.cui AND b.validated_ind = 1)"""

  override def dependsOn: Set[String] = Set("L1_MAP_ASSESSMENT_CUI","MD_DOMAIN_CONCEPT","L1_MAP_QUAL_TEXT_RESULT","L1_MAP_LAB")

  def originalSql: String = """INSERT /*+ APPEND */ INTO L2_dict_assess_qual_value(value_cui,value_name,assessment_cui)
SELECT a.cui as value_cui
       , b.concept_name as value_name
       , a.map_cui as assessment_type
FROM L1_map_assessment_cui a
INNER JOIN md_domain_concept b ON (a.cui = b.concept_cui)
UNION
SELECT a.qual_result_code as value_cui
       , d.concept_name as value_name
       , b.cui as assessment_type
FROM L1_map_qual_text_result a
INNER JOIN md_domain_concept d ON (a.qual_result_code = d.concept_cui AND d.domain_cui = 'CH001294')
INNER JOIN l1_map_lab b ON (a.lab_code = b.cui AND b.validated_ind = 1)
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("value_cui",None,None), OutputColumn("value_name",None,None), OutputColumn("assessment_cui",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_dict_assess_qual_value_build.sql"
}



/**
  * auto-generated code
*/
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.l1_ref_sensitive_proc
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata


object L1_REF_SENSITIVE_PROC extends QueryAndMetadata[l1_ref_sensitive_proc] {
  override def skipCoalesce: Boolean = true
	override def name: String = "L1_REF_SENSITIVE_PROC"

  override def sparkSql: String = """SELECT DISTINCT 'CPT4' AS code_type, cpt_code AS proc_cd, 1 AS sensitive_ind
FROM L1_REF_SENSITIVE_CPT
UNION ALL
SELECT DISTINCT 'HCPCS' AS code_type, code AS proc_cd, 1 AS sensitive_ind
FROM L1_ref_sensitive_hcpcs
UNION ALL
SELECT DISTINCT 'ICD9' AS code_type, proc_code AS proc_cd, 1 AS sensitive_ind
FROM L1_ref_sensitive_icd9_px
UNION ALL
SELECT DISTINCT 'ICD10' AS code_type, proc_code AS proc_cd, 1 AS sensitive_ind
FROM L1_ref_sensitive_icd0_px
UNION ALL
SELECT DISTINCT 'REV' as code_type,sr.rev_code,1 AS sensitive_ind
FROM L1_REF_SENSITIVE_REVENUE sr
UNION ALL
SELECT distinct 'CUSTOM', mappedvalue, sensitive_ind
 FROM l1_ref_cust_proc_mapped_val val
WHERE sensitive_ind = 1
"""

  override def dependsOn: Set[String] = Set("L1_REF_SENSITIVE_REVENUE","L1_REF_SENSITIVE_CPT","L1_REF_SENSITIVE_ICD9_PX","L1_REF_SENSITIVE_ICD0_PX","L1_REF_SENSITIVE_HCPCS","L1_REF_CUST_PROC_MAPPED_VAL")

  def originalSql: String = """

------------------------
INSERT /*+ APPEND */ INTO L1_ref_sensitive_proc (code_type, proc_cd, sensitive_ind)
SELECT DISTINCT 'CPT4' AS code_type, cpt_code AS proc_cd, 1 AS sensitive_ind
FROM L1_REF_SENSITIVE_CPT
UNION ALL
SELECT DISTINCT 'HCPCS' AS code_type, code AS proc_cd, 1 AS sensitive_ind
FROM L1_ref_sensitive_hcpcs
UNION ALL
SELECT DISTINCT 'ICD9' AS code_type, proc_code AS proc_cd, 1 AS sensitive_ind
FROM L1_ref_sensitive_icd9_px
UNION ALL
SELECT DISTINCT 'ICD10' AS code_type, proc_code AS proc_cd, 1 AS sensitive_ind
FROM L1_ref_sensitive_icd0_px
UNION ALL
SELECT DISTINCT 'REV' as code_type,sr.rev_code,1 AS sensitive_ind
FROM L1_Ref_Sensitive_Revenue sr
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("code_type",None,None), OutputColumn("proc_cd",None,None), OutputColumn("sensitive_ind",None,None)))

  def directoryLevel: String = "L1"





  val originalSqlFileName: String = "L1_ref_sensitive_proc.sql"
}


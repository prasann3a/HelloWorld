
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_generic_status, map_generic_status}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_GENERIC_STATUS extends TableInfo[l1_map_generic_status]{
  override def dependsOn: Set[String] = Set("MAP_GENERIC_STATUS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_GENERIC_STATUS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapGenericStatus = loadedDependencies("MAP_GENERIC_STATUS").as[map_generic_status]

    mapGenericStatus
    .select(
			$"groupid".as("client_id"),
			$"localcode",
			$"cui",
			$"dts_version"
    )
  }
}


package com.optum.oadw.etl.L3

import com.optum.oadw.etl.constants.Procedures
import com.optum.oadw.oadwModels._
import com.optum.oadw.oadw_ref.models.{l3_map_proc_etg, l3_map_proc_peg}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, when}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}


/**
  * Algorithm specification: https://wiki.humedica.net/display/Data/OADW+Tables+-+Domain+Maps+and+Dictionaries+-+MAP_PROC_GROUP
  */
object L3_MAP_PROC_GROUP extends TableInfo[l3_map_proc_group] {
  override def name: String = "L3_MAP_PROC_GROUP"
  override def dependsOn: Set[String] = Set("L1_MAP_PROCEDURE_CUI", "REFERENCE_SCHEMA_L3_MAP_PROC_ETG", "L3_MAP_PROC_PEG", "L1_REF_IMAP_PCPSERV_CAT", "L1_REF_IMAP_EM_PROC", "L3_DICT_PROC_GROUP")
  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val tL1mapProcedureCui = loadedDependencies("L1_MAP_PROCEDURE_CUI").as[l1_map_procedure_cui]
    val tL3mapProcEtgTx = loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PROC_ETG").as[l3_map_proc_etg]
    val tL3mapProcPeg = loadedDependencies("L3_MAP_PROC_PEG").as[l3_map_proc_peg]
    val tL3DictProcGroup = loadedDependencies("L3_DICT_PROC_GROUP").as[l3_dict_proc_group]
    val tL1RefImapPcpservCat = loadedDependencies("L1_REF_IMAP_PCPSERV_CAT").as[l1_ref_imap_pcpserv_cat]
    val tL1RefImapEMProc = loadedDependencies("L1_REF_IMAP_EM_PROC").as[l1_ref_imap_em_proc]
    calculateTL3MapProcGroup(sparkSession, tL1mapProcedureCui, tL3mapProcEtgTx, tL1RefImapPcpservCat, tL1RefImapEMProc, tL3DictProcGroup, tL3mapProcPeg)
      .select($"proc_cd", $"code_type", $"proc_group_id")
  }

  private def calculateTL3MapProcGroup(sparkSession: SparkSession,
                                       tL1mapProcedureCui: Dataset[l1_map_procedure_cui],
                                       tL3mapProcEtgTx: Dataset[l3_map_proc_etg],
                                       tL1RefImapPcpservCat: Dataset[l1_ref_imap_pcpserv_cat],
                                       tL1RefImapEMProc: Dataset[l1_ref_imap_em_proc],
                                       tL3DictProcGroup: Dataset[l3_dict_proc_group],
                                       mapProcPeg: Dataset[l3_map_proc_peg]): Dataset[l3_map_proc_group] = {
    import sparkSession.implicits._


    val cui = tL1mapProcedureCui
      .join(tL3DictProcGroup, $"proc_group_set" === lit( Procedures.PROC_GROUP_SET_CUI) && $"cui" === $"external_code")
      .select($"mappedcode".as("proc_cd"), $"codetype".as("code_type"), $"proc_group_id")

    val peg = mapProcPeg
      .join(tL3DictProcGroup, $"proc_group_set" === lit( Procedures.PROC_GROUP_SET_PEG) && $"peg_id" === $"external_code")
      .select($"proc_cd".as("proc_cd"), $"code_type".as("code_type"), $"proc_group_id")

    val etg = tL3mapProcEtgTx
      .join(tL3DictProcGroup, $"proc_group_set" === lit( Procedures.PROC_GROUP_SET_ETG_TX) && $"etg_cd" === $"external_code")
      .select($"proc_cd".as("PROC_CD"), $"code_type".as("code_type"), $"proc_group_id")

    val wideGroupId = tL3DictProcGroup
      .where(
        $"proc_group_set" === Procedures.PROC_GROUP_SET_II and $"external_code" === Procedures.EXTERNAL_CODE_PCC
      ).collect().head.proc_group_id

    val iiWide = tL1RefImapPcpservCat
      .where($"pcc" === 1)
      .select(
        $"proccode".as("proc_cd"),
        when($"proccode" rlike Procedures.REGEXP_CPT4_CODE_MATCH, lit(Procedures.CODE_TYPE_CPT4))
          .when($"proccode" rlike Procedures.REGEXP_HCPCS_CODE_MATCH, lit(Procedures.CODE_TYPE_HCPCS))
          .otherwise(Procedures.CODE_TYPE_REV)
          .as("code_type"),
        lit(wideGroupId).as("proc_group_id")
      )

    val narrowGroupId = tL3DictProcGroup
      .where(
        $"proc_group_set" === Procedures.PROC_GROUP_SET_II and $"external_code" === Procedures.EXTERNAL_CODE_PCCEM
      ).collect().head.proc_group_id

    val iiNarrow = tL1RefImapPcpservCat
      .where($"pccem" === 1)
      .select(
        $"proccode".as("proc_cd"),
        when($"proccode" rlike Procedures.REGEXP_CPT4_CODE_MATCH, lit(Procedures.CODE_TYPE_CPT4))
          .when($"proccode" rlike Procedures.REGEXP_HCPCS_CODE_MATCH, lit(Procedures.CODE_TYPE_HCPCS))
          .otherwise(Procedures.CODE_TYPE_REV)
          .as("code_type"),
        lit(narrowGroupId).as("proc_group_id")
      )

    val EMGroupId = tL3DictProcGroup
      .where(
        $"proc_group_set" === Procedures.PROC_GROUP_SET_II and $"external_code" === Procedures.EXTERNAL_CODE_EM_PX
      ).collect().head.proc_group_id

    val iiEM = tL1RefImapEMProc
      .select(
        $"proccode".as("proc_cd"),
        when($"proccode" rlike Procedures.REGEXP_CPT4_CODE_MATCH, lit(Procedures.CODE_TYPE_CPT4))
          .when($"proccode" rlike Procedures.REGEXP_HCPCS_CODE_MATCH, lit(Procedures.CODE_TYPE_HCPCS))
          .otherwise(Procedures.CODE_TYPE_REV)
          .as("code_type"),
        lit(EMGroupId).as("proc_group_id")
      )

    val TeleId = tL3DictProcGroup
      .where(
        $"proc_group_set" === Procedures.PROC_GROUP_SET_II and $"external_code" === Procedures.EXTERNAL_CODE_EM_TELE
      ).collect().head.proc_group_id

    val iiTele = tL1mapProcedureCui.as("mpc").where($"mpc.cui".isin(Procedures.TELE_OFF_EXLCUDE:_*))
      .join(tL1RefImapEMProc.as("ri"), $"mpc.mappedcode" === $"ri.proccode", "fullouter")
      .select(
        $"ri.proccode".as("proc_cd"),
        when($"ri.proccode" rlike Procedures.REGEXP_CPT4_CODE_MATCH, lit(Procedures.CODE_TYPE_CPT4))
          .when($"ri.proccode" rlike Procedures.REGEXP_HCPCS_CODE_MATCH, lit(Procedures.CODE_TYPE_HCPCS))
          .otherwise(Procedures.CODE_TYPE_REV)
          .as("code_type"),
        lit(TeleId).as("proc_group_id")
      )
      .where($"ri.proccode".isNotNull && $"mpc.mappedcode".isNull)

    val OffId = tL3DictProcGroup
      .where(
        $"proc_group_set" === Procedures.PROC_GROUP_SET_II and $"external_code" === Procedures.EXTERNAL_CODE_EM_OFF
      ).collect().head.proc_group_id

    val iiOff = tL1mapProcedureCui.as("mpc").where($"mpc.cui".isin(Procedures.TELE_OFF_EXLCUDE:_*))
      .join(tL1RefImapEMProc.as("ri"), $"mpc.mappedcode" === $"ri.proccode", "fullouter")
      .select(
        $"ri.proccode".as("proc_cd"),
        when($"ri.proccode" rlike Procedures.REGEXP_CPT4_CODE_MATCH, lit(Procedures.CODE_TYPE_CPT4))
          .when($"ri.proccode" rlike Procedures.REGEXP_HCPCS_CODE_MATCH, lit(Procedures.CODE_TYPE_HCPCS))
          .otherwise(Procedures.CODE_TYPE_REV)
          .as("code_type"),
        lit(OffId).as("proc_group_id")
      )
      .where($"ri.proccode".isNotNull && $"mpc.mappedcode".isNull)

    cui.union(peg).union(etg).union(iiWide).union(iiNarrow).union(iiEM).union(iiTele).union(iiOff).as[l3_map_proc_group]
  }
}

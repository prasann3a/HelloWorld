
/**
  * auto-generated code
*/
package com.optum.oadw.etl.L3


import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

case class temp_pat_score_grp_intn_3_data(client_id: String, mpi: String, grp_id: java.lang.Integer, timeframe_id: java.lang.Integer,
                                          elig_cds_id: java.lang.Integer, interaction_id: java.lang.Integer, coef_multiplier: java.lang.Double,
                                          sensitive_ind: java.lang.Integer)

object TEMP_PAT_SCORE_GRP_INTN_3 extends TableInfo[temp_pat_score_grp_intn_3_data] {
  override def name: String = "TEMP_PAT_SCORE_GRP_INTN_3"

  override def dependsOn: Set[String] = Set(
    "TEMP_PAT_SCORE_GRP_INTN_2",
    "TEMP_SCORE_PATS_DEMOG",
    "L3_MAP_SCORE_GRP_AGE"
  )

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempPatScoreGrpIntn2 = loadedDependencies("TEMP_PAT_SCORE_GRP_INTN_2")
    val tempScorePatsDemog = loadedDependencies("TEMP_SCORE_PATS_DEMOG")
    val tL3MapScoreGrpAge = broadcast(loadedDependencies("L3_MAP_SCORE_GRP_AGE"))

    tempPatScoreGrpIntn2
      .as("tmp")
      .where($"tmp.precursor1" === 1 && $"tmp.precursor2" === 1)
      .join(
        tempScorePatsDemog.as("age"),
        $"tmp.client_id" === $"age.client_id" && $"tmp.mpi" === $"age.mpi" && $"tmp.timeframe_id" === $"age.timeframe_id"
      )
      .where(
        $"tmp.AGE_INTERACTION_IND" === 0 ||
        ($"tmp.AGE_INTERACTION_IND" === 1 && $"age.age" >= $"tmp.age_range_min" && $"age.age" <= $"tmp.age_range_max" ) ||
          ($"tmp.AGE_INTERACTION_IND" === 1 &&  $"tmp.age_range_min".isNull && $"age.age"<=$"tmp.age_range_max") ||
          ($"tmp.AGE_INTERACTION_IND" === 1 && $"tmp.age_range_max".isNull && $"age.age">=$"tmp.age_range_min") ||
          ($"tmp.AGE_INTERACTION_IND" === 1 && $"tmp.age_range_min".isNull && $"tmp.age_range_max".isNull)
      )
      .join(
        tL3MapScoreGrpAge.as("msga"),
        $"tmp.grp_id" === $"msga.grp_id" && $"age.age" >= $"msga.age_range_min" &&  $"age.age" <= $"msga.age_range_max",
        "left"
      )
      .withColumn(
        "coef_multiplier",
        expr(
          """
            |CASE
            | WHEN tmp.age_interaction_ind = 1   THEN msga.coef_multiplier
            | ELSE 1
            |END * tmp.precursor1_contribution * CASE
            | WHEN tmp.precursor_id_2 IS NULL THEN 1
            | ELSE tmp.precursor2_contribution
            |END
            |""".stripMargin)
      )
      .select(
        $"tmp.client_id",
        $"tmp.mpi",
        $"tmp.grp_id",
        $"tmp.timeframe_id",
        $"tmp.elig_cds_id",
        $"tmp.interaction_id",
        $"coef_multiplier",
        $"tmp.sensitive_ind"
      )
      .distinct()
  }
}


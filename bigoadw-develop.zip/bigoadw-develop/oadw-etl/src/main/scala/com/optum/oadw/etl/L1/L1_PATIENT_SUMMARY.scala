
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patient_summary, patient_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENT_SUMMARY extends TableInfo[l1_patient_summary]{
  override def dependsOn: Set[String] = Set("PATIENT_SUMMARY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENT_SUMMARY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientSummary = loadedDependencies("PATIENT_SUMMARY").as[patient_summary]

    patientSummary
    .select(
			$"groupid".as("client_id"),
			$"patientid",
			$"hgpid",
			$"yob",
			$"mob",
			$"dob",
			$"local_gender",
			$"local_ethnicity",
			$"local_race",
			$"local_zipcode",
			$"first_name",
			$"last_name",
			$"mapped_gender",
			$"mapped_ethnicity",
			$"mapped_race",
			$"mapped_zipcode",
			$"local_death_ind",
			$"mapped_death_ind",
			$"date_of_death",
			$"local_dod",
			$"ssdi_dod",
			$"ssdi_name_match",
			$"medicalrecordnumber",
			$"display_id",
			$"client_ds_id",
			$"grp_mpi".as("mpi"),
			$"local_language",
			$"mapped_language",
			$"local_marital_status",
			$"mapped_marital_status",
			$"middle_name",
			$"inactive_flag",
			$"religion",
			$"mrace_infer_ind"
    )
  }
}


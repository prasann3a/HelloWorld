
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_laborder, laborder}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_LABORDER extends TableInfo[l1_laborder]{
  override def dependsOn: Set[String] = Set("LABORDER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_LABORDER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val laborder = loadedDependencies("LABORDER").as[laborder]

    laborder
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"laborderid",
			$"facilityid",
			$"encounterid",
			$"patientid",
			$"dateordered".as("ordered_dtm"),
			$"localtestname",
			$"localtestdescription",
			$"statuscode",
			$"specimincollecttime".as("specimen_collect_dtm"),
			$"mappedtestname",
			$"mappedtestdescription",
			$"localspecimentype",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"orderingproviderid",
			$"mstrprovid"
    )
  }
}


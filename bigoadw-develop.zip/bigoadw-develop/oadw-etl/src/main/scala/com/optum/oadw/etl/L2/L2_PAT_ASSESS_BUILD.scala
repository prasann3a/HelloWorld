package com.optum.oadw.etl.L2

import java.sql.Timestamp
import java.time.LocalDateTime

import com.optum.oadw.definedfunctions.{BitOrAggFunction, ListAggFunction}
import com.optum.oadw.etl.constants.{MetaData, Precursors}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.{DoubleType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

case class temp_l2_pat_assess_build_common_obs_data(client_id: String, mpi: String, assessment_dtm: Timestamp,
                                                      cds_grp: String, assessment_cui: String, numeric_value: java.lang.Double,
                                                      value_cui: String, clinical_event_id: java.lang.Long, nlp_ind: java.lang.Integer,
                                                      hosp_ind: java.lang.Integer, sensitive_ind: java.lang.Integer, inferred_ind: java.lang.Integer)

object TEMP_L2_PAT_ASSESS_BUILD_COMMON_OBS extends TableInfo[temp_l2_pat_assess_build_common_obs_data] {
  override def name: String = "TEMP_L2_PAT_ASSESS_BUILD_COMMON_OBS"

  override def dependsOn: Set[String] = Set("L1_OBSERVATION", "L2_MAP_CDS_FLG", "L1_MAP_OBSTYPE", "L1_MAP_ASSESSMENT_CUI", "L1_CLINICAL_EVENT_ENCOUNTER", "TEMP_PAT_CLINICAL_HOSP_S1", "MD_DOMAIN_CONCEPT", "MD_OADW_INSTANCE")

  def directoryLevel: String = "L2"

  override def partitions: Int = 48

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val l1Observation = loadedDependencies("L1_OBSERVATION").alias("l1Observation")
    val tL2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").alias("tL2MapCdsFlg")
    val l1MapObsType = loadedDependencies("L1_MAP_OBSTYPE").alias("l1MapObsType")
    val l1MapAssessQui = loadedDependencies("L1_MAP_ASSESSMENT_CUI").alias("l1MapAssessQui")
    val tL1ClinicEvtEncounter = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").alias("tL1ClinicEvtEncounter")
    val tempClinicalHosp = loadedDependencies("TEMP_PAT_CLINICAL_HOSP_S1").alias("tempClinicalHosp")
    val mdDomainConcept = loadedDependencies("MD_DOMAIN_CONCEPT").alias("mdDomainConcept")
    val mdInstance = loadedDependencies("MD_OADW_INSTANCE").alias("mdInstance")
    val domainCuis = mdDomainConcept.select($"concept_cui").where($"domain_cui" === lit("CH003534")).collect().map(row => row.getString(0))

    val dataThruDtmPlus1Day = mdInstance.where($"attribute_name" === lit("DATA_THRU"))
      .select(date_add(to_date($"attribute_value", "yyyyMMdd"), 1))
      .as[Timestamp]
      .collect()
      .head

    l1Observation
      .join(tL2MapCdsFlg, l1Observation("client_id") === tL2MapCdsFlg("client_id") && l1Observation("client_ds_id") === tL2MapCdsFlg("client_ds_id"))
      .join(broadcast(l1MapObsType), l1Observation("obstype") === l1MapObsType("obstype"))
      .join(l1MapAssessQui, l1Observation("client_id") === l1MapAssessQui("client_id") && l1Observation("obsresult") === l1MapAssessQui("local_code") && l1MapObsType("obstype_cui") === l1MapAssessQui("map_cui"), "leftouter")
      .join(tL1ClinicEvtEncounter, l1Observation("client_id") === tL1ClinicEvtEncounter("client_id") && l1Observation("client_ds_id") === tL1ClinicEvtEncounter("client_ds_id") &&
        l1Observation("encounterid") === tL1ClinicEvtEncounter("encounterid") && l1Observation("mpi") === tL1ClinicEvtEncounter("mpi"), "leftouter")
      .join(tempClinicalHosp, l1Observation("client_id") === tempClinicalHosp("client_id") && l1Observation("mpi") === tempClinicalHosp("mpi") &&
        to_date(date_format(when(l1Observation("datasrc").isin("foam","nlp"), coalesce(l1Observation("result_dt"), l1Observation("observation_dtm")))
          .otherwise(l1Observation("observation_dtm")), "yyyy-MM-dd")).between(tempClinicalHosp("trunc_start_dtm"), tempClinicalHosp("trunc_end_dtm")),
        "leftouter")
      .where(l1Observation("mpi").isNotNull && l1Observation("obsresult").isNotNull &&
        coalesce(l1Observation("result_dt"), l1Observation("observation_dtm")) < dataThruDtmPlus1Day &&
        l1Observation("observation_dtm") < dataThruDtmPlus1Day && l1MapObsType("validated_ind") === lit(1) &&
        !l1MapObsType("obstype_cui").isin(domainCuis: _*))
      .groupBy(
        l1Observation("client_id").as("client_id"),
        l1Observation("mpi").as("mpi"),
        when(l1Observation("datasrc").isin("foam","nlp"), coalesce(l1Observation("result_dt"), l1Observation("observation_dtm"))).otherwise(l1Observation("observation_dtm")).as("assessment_dtm"),
        l1MapObsType("obstype_cui").as("assessment_cui"),
        when(l1MapObsType("datatype").isin("P", "N"), format_number(l1Observation("obsresult").cast(DoubleType), 10)).otherwise(null).cast(DoubleType).as("numeric_value"),
        when(l1MapObsType("datatype").isin("CV"), l1MapAssessQui("cui")).otherwise(null).as("value_cui"),
        when(l1Observation("datasrc").isin("foam","nlp"), lit(2)).otherwise(lit(0)).as("nlp_ind_temp")
      )
      .agg(
        ListAggFunction.listAgg(tL2MapCdsFlg("client_ds_id")).as("cds_grp"),
        min(tL1ClinicEvtEncounter("encounter_grp_num")).as("clinical_event_id"),
        max(when(tempClinicalHosp("client_id").isNotNull, lit(1)).otherwise(lit(0))).as("hosp_ind"))
      .groupBy(
        $"client_id",
        $"mpi",
        $"assessment_dtm",
        $"cds_grp",
        $"assessment_cui",
        $"numeric_value",
        $"value_cui",
        $"clinical_event_id",
        $"hosp_ind"
      ).agg(
      when(max($"nlp_ind_temp") === 0 && min($"nlp_ind_temp") === 0, 0)
        .when(max($"nlp_ind_temp") === 2 && min($"nlp_ind_temp") === 0, 1)
        .when(max($"nlp_ind_temp") === 2 && min($"nlp_ind_temp") === 2, 2).as("nlp_ind")
    ).select(
      $"client_id",
      $"mpi",
      $"assessment_dtm",
      $"cds_grp",
      $"assessment_cui",
      $"numeric_value",
      $"value_cui",
      $"clinical_event_id",
      $"nlp_ind",
      $"hosp_ind",
      lit(0).as("sensitive_ind"),
      lit(0).as("inferred_ind"))
  }
}

case class temp_l2_pat_assess_build_common_lab_data(client_id: String = null, mpi: String = null, assessment_dtm: Timestamp = null,
                                                      cds_grp: String, assessment_cui: String = null, numeric_value: java.lang.Double = null,
                                                      qual_value: String = null, result_type: String = null,
                                                      clinical_event_id: java.lang.Long = null, nlp_ind: java.lang.Integer = null,
                                                      hosp_ind: java.lang.Integer = null, sensitive_ind: java.lang.Integer = null, inferred_ind: java.lang.Integer = null)

object TEMP_L2_PAT_ASSESS_BUILD_COMMON_LAB extends TableInfo[temp_l2_pat_assess_build_common_lab_data] {
  override def name: String = "TEMP_L2_PAT_ASSESS_BUILD_COMMON_LAB"

  override def dependsOn: Set[String] = Set("L1_LABRESULT", "L2_MAP_CDS_FLG", "L1_MAP_LAB", "L1_CLINICAL_EVENT_ENCOUNTER", "TEMP_PAT_CLINICAL_HOSP_S1", "MD_OADW_INSTANCE")

  def directoryLevel: String = "L2"

  override def partitions: Int = 48

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val l1LabResult = loadedDependencies("L1_LABRESULT").alias("l1LabResult")
    val tL2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").alias("tL2MapCdsFlg")
    val mdLab = loadedDependencies("L1_MAP_LAB").alias("mdLab")
    val tL1ClinicEvtEncounter = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").alias("tL1ClinicEvtEncounter")
    val mdInstance = loadedDependencies("MD_OADW_INSTANCE").alias("mdInstance")
    val tempClinicalHosp = loadedDependencies("TEMP_PAT_CLINICAL_HOSP_S1").alias("tempClinicalHosp")

    val dataThruDtmPlus1Day = mdInstance.where($"attribute_name" === lit("DATA_THRU"))
      .select(date_add(to_date($"attribute_value", "yyyyMMdd"), 1))
      .as[Timestamp]
      .collect()
      .head

    l1LabResult
      .join(broadcast(mdLab), l1LabResult("mappedcode") === mdLab("cui"))
      .join(tL2MapCdsFlg, l1LabResult("client_id") === tL2MapCdsFlg("client_id") && l1LabResult("client_ds_id") === tL2MapCdsFlg("client_ds_id"))
      .join(tL1ClinicEvtEncounter, l1LabResult("client_id") === tL1ClinicEvtEncounter("client_id") && l1LabResult("client_ds_id") === tL1ClinicEvtEncounter("client_ds_id") &&
        l1LabResult("encounterid") === tL1ClinicEvtEncounter("encounterid") && l1LabResult("mpi") === tL1ClinicEvtEncounter("mpi"), "leftouter")
      .join(tempClinicalHosp, l1LabResult("client_id") === tempClinicalHosp("client_id") && l1LabResult("mpi") === tempClinicalHosp("mpi") &&
        expr("to_date(date_format(coalesce(l1LabResult.collected_dtm, l1LabResult.available_dtm), 'yyyy-MM-dd')) between tempClinicalHosp.trunc_start_dtm and tempClinicalHosp.trunc_end_dtm"), "leftouter")
      .where(
        l1LabResult("mappedcode").isNotNull &&
          l1LabResult("mpi").isNotNull &&
          coalesce(l1LabResult("resulttype"), lit(Precursors.CUI_NULL)) =!= lit(Precursors.CUI_INVALID) &&
          coalesce(l1LabResult("normalizedvalue").cast(StringType), l1LabResult("mapped_qual_code")).isNotNull &&
          coalesce(l1LabResult("collected_dtm"), l1LabResult("available_dtm")) < dataThruDtmPlus1Day &&
          mdLab("validated_ind") === lit(1))
      .groupBy(
        l1LabResult("client_id").as("client_id"),
        l1LabResult("mpi").as("mpi"),
        coalesce(l1LabResult("collected_dtm"), l1LabResult("available_dtm")).as("assessment_dtm"),
        l1LabResult("mappedcode").as("assessment_cui"),
        l1LabResult("normalizedvalue").as("numeric_value"),
        l1LabResult("mapped_qual_code").as("qual_value"),
        mdLab("result_type").as("result_type"),
        when(l1LabResult("datasrc").isin("foam","nlp"), lit(2)).otherwise(lit(0)).as("nlp_ind_temp")
      )
      .agg(
        ListAggFunction.listAgg(tL2MapCdsFlg("client_ds_id")).as("cds_grp"),
        min(tL1ClinicEvtEncounter("encounter_grp_num")).as("clinical_event_id"),
        max(when(tempClinicalHosp("client_id").isNotNull, lit(1)).otherwise(lit(0))).as("hosp_ind"))
      .groupBy(
        $"client_id",
        $"mpi",
        $"assessment_dtm",
        $"cds_grp",
        $"assessment_cui",
        $"numeric_value",
        $"qual_value",
        $"result_type",
        $"clinical_event_id",
        $"hosp_ind"
      ).agg(
      when(max($"nlp_ind_temp") === 0 && min($"nlp_ind_temp") === 0, 0)
        .when(max($"nlp_ind_temp") === 2 && min($"nlp_ind_temp") === 0, 1)
        .when(max($"nlp_ind_temp") === 2 && min($"nlp_ind_temp") === 2, 2).as("nlp_ind")
    ).select(
      $"client_id",
      $"mpi",
      $"assessment_dtm",
      $"cds_grp",
      $"assessment_cui",
      $"numeric_value",
      $"qual_value",
      $"result_type",
      $"clinical_event_id",
      $"nlp_ind",
      $"hosp_ind",
      lit(0).as("sensitive_ind"),
      lit(0).as("inferred_ind")
    )
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_lab_codes, map_lab_codes}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_LAB_CODES extends TableInfo[l1_map_lab_codes]{
  override def dependsOn: Set[String] = Set("MAP_LAB_CODES")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_LAB_CODES"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapLabCodes = loadedDependencies("MAP_LAB_CODES").as[map_lab_codes]

    mapLabCodes
    .select(
		$"groupid".as("client_id"),
		$"mnemonic".as("local_code"),
		$"cui",
		$"dts_version",
		$"client_ds_id",
		$"mapping_context"
    )
  }
}



/**
  * auto-generated code
*/
package com.optum.oadw.etl.L3


import com.optum.oadw.oadwModels.{l3_map_score_grp_intn, l3_pat_score_grp_precur, l3_map_score_grp_precur}
import com.optum.oadw.oadw_ref.models.l3_map_score_grp_intn_precur
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

case class temp_pat_score_grp_intn_2_data(client_id: String, mpi: String, grp_id: java.lang.Integer, timeframe_id: java.lang.Integer,
                                          elig_cds_id: java.lang.Integer, interaction_id: java.lang.Integer, precursor_id_2: java.lang.Integer,
                                          age_interaction_ind: java.lang.Integer, age_range_min: java.lang.Integer,
                                          age_range_max: java.lang.Integer, sensitive_ind: java.lang.Integer, precursor1: java.lang.Integer,
                                          precursor2: java.lang.Integer, precursor1_contribution: java.lang.Double,
                                          precursor2_contribution: java.lang.Double)

object TEMP_PAT_SCORE_GRP_INTN_2 extends TableInfo[temp_pat_score_grp_intn_2_data] {
  override def name: String = "TEMP_PAT_SCORE_GRP_INTN_2"

  override def dependsOn: Set[String] = Set(
    "L3_MAP_SCORE_GRP_INTN_PRECUR",
    "L3_PAT_SCORE_GRP_PRECUR",
    "L3_MAP_SCORE_GRP_PRECUR",
    "L3_MAP_SCORE_GRP_INTN"
  )

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL3MapScoreGrpIntnPrecur = broadcast(loadedDependencies("L3_MAP_SCORE_GRP_INTN_PRECUR").as[l3_map_score_grp_intn_precur])
    val tL3PatScoreGrpPrecur = loadedDependencies("L3_PAT_SCORE_GRP_PRECUR").as[l3_pat_score_grp_precur]
    val tL3MapScoreGrpPrecur = broadcast(loadedDependencies("L3_MAP_SCORE_GRP_PRECUR").as[l3_map_score_grp_precur])
    val l3MapScoreGrpIntn = broadcast(loadedDependencies("L3_MAP_SCORE_GRP_INTN").as[l3_map_score_grp_intn])

    tL3PatScoreGrpPrecur.as("prec")
      .join(tL3MapScoreGrpPrecur.as("msp"), $"prec.grp_id" === $"msp.grp_id" && $"prec.precursor_id" === $"msp.precursor_id")
      .join(tL3MapScoreGrpIntnPrecur.as("msip"), $"prec.grp_id" === $"msip.grp_id")
      .join(l3MapScoreGrpIntn.as("msi"), $"msip.grp_id" === $"msi.grp_id" && $"msip.interaction_id" === $"msi.interaction_id")
      .groupBy(
        $"prec.client_id",
        $"prec.mpi",
        $"prec.grp_id",
        $"prec.timeframe_id",
        $"prec.elig_cds_id",
        $"msip.interaction_id",
        $"msip.precursor_id_2",
        $"msi.age_interaction_ind",
        $"msi.age_range_min",
        $"msi.age_range_max",
        $"msi.sensitive_ind"
      )
      .agg(
        max(when($"prec.precursor_id" === $"msip.precursor_id_1", 1).otherwise(0)).as("precursor1"),
        max(when($"prec.precursor_id" === $"msip.precursor_id_2" || $"msip.precursor_id_2".isNull, 1).otherwise(0)).as("precursor2"),
        expr(
          """
            | MAX(CASE
            |     WHEN prec.precursor_id = msip.precursor_id_1
            |          AND msp.coef_mult_is_1_ind = 1 THEN 1
            |     WHEN prec.precursor_id = msip.precursor_id_1
            |          AND msp.coef_mult_is_1_ind = 0 THEN CAST(prec.precursor_value AS double)
            |     ELSE NULL
            | END)
            |""".stripMargin).as("precursor1_contribution"),
        expr(
          """
            | MAX(CASE
            |     WHEN prec.precursor_id = msip.precursor_id_2
            |          AND msp.coef_mult_is_1_ind = 1 THEN 1
            |     WHEN prec.precursor_id = msip.precursor_id_2
            |          AND msp.coef_mult_is_1_ind = 0 THEN CAST(prec.precursor_value AS double)
            |     ELSE NULL
            | END)
            |""".stripMargin).as("precursor2_contribution")
      )

  }
}


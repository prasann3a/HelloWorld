
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_observation, observation}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_OBSERVATION extends TableInfo[l1_observation]{
  override def dependsOn: Set[String] = Set("OBSERVATION")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_OBSERVATION"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val observation = loadedDependencies("OBSERVATION").as[observation]

    observation
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"facilityid",
			$"encounterid",
			$"patientid",
			$"obsdate".as("observation_dtm"),
			$"localcode",
			$"obstype",
			$"obsresult",
			$"statuscode",
			$"localresult",
			$"resultdate".as("result_dt"),
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"local_obs_unit",
			$"std_obs_unit"
    )
  }
}


package com.optum.oadw.etl.L3


import java.sql.Timestamp
import java.time.temporal.TemporalAdjusters

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadw_ref.models.{l4_dict_prov_attrib, l3_dict_prov_attrib_precur}
import com.optum.oadw.oadwModels._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
  *
  * Provides a month-only calendar based on NUM_YR_MONTHS from L4_DICT_PROV_ATTRIB
  * Algorithm specification: https://wiki.humedica.net/display/Data/OADW+Concept+Specification+-+Provider+Attribution
  *
  */
object TEMP_PROV_ATTRIB_YRMONTH extends TableInfo[yr_month] {
  override def name: String = "TEMP_PROV_ATTRIB_YRMONTH"

  override def dependsOn: Set[String] = Set("REFERENCE_SCHEMA_L4_DICT_PROV_ATTRIB", "REFERENCE_SCHEMA_L3_DICT_PROV_ATTRIB_PRECUR", "MD_OADW_INSTANCE")

  def directoryLevel: String = "L3"

  override def saveDataFrameToParquet: Boolean = false

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val tL4DictProvAttrib = loadedDependencies("REFERENCE_SCHEMA_L4_DICT_PROV_ATTRIB").as[l4_dict_prov_attrib]
    val tL3DictProvAttribPrecur = loadedDependencies("REFERENCE_SCHEMA_L3_DICT_PROV_ATTRIB_PRECUR").as[l3_dict_prov_attrib_precur]
    val tMOADWInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]

    val tL4NumYears = tL4DictProvAttrib.where($"ACTIVE_IND" === lit(1) and $"PRECALC_IND" === lit(0)).select($"NUM_YR_MONTHS")
    val tL3NumYears = tL3DictProvAttribPrecur.where($"ACTIVE_IND" === lit(1)).select($"NUM_YR_MONTHS")

    val maxNumMonths = tL4NumYears.union(tL3NumYears).select(max($"NUM_YR_MONTHS").cast(IntegerType).as("NUM")).as[Option[Int]].collect().head

    if (maxNumMonths.isEmpty) {
      Seq.empty[yr_month].toDF()
    } else {
      val oadwDate = tMOADWInstance.where($"attribute_name" === lit("DATA_THRU")).select(trunc(to_date($"ATTRIBUTE_VALUE", "yyyyMMdd"), "month")).as[Timestamp].first().toLocalDateTime

      val seq = for (months <- 0 until maxNumMonths.get) yield {
        val currentDate = oadwDate.minusMonths(months)

        yr_month(month_number = months + 1,
          start_month_dt = Timestamp.valueOf(currentDate),
          end_month_dt = Timestamp.valueOf(currentDate.`with`(TemporalAdjusters.lastDayOfMonth())),
          YR_MONTH = currentDate.getYear * 100 + currentDate.getMonthValue
        )
      }

      broadcast(seq.toDF())
    }
  }
}

case class yr_month(month_number: Int, end_month_dt: Timestamp, start_month_dt: Timestamp, YR_MONTH: Int)

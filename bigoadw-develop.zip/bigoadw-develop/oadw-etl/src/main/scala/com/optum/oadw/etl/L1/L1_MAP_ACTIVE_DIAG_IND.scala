
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_active_diag_ind, map_active_diag_ind}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_ACTIVE_DIAG_IND extends TableInfo[l1_map_active_diag_ind]{
  override def dependsOn: Set[String] = Set("MAP_ACTIVE_DIAG_IND")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_ACTIVE_DIAG_IND"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapActiveDiagInd = loadedDependencies("MAP_ACTIVE_DIAG_IND").as[map_active_diag_ind]

    mapActiveDiagInd
    .select(
			$"groupid".as("client_id"),
			$"localcode".as("local_code"),
			$"cui",
			$"dts_version"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ref_imap_tos_proc, ref_imap_tos_proc}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_REF_IMAP_TOS_PROC extends TableInfo[l1_ref_imap_tos_proc]{
  override def dependsOn: Set[String] = Set("REF_IMAP_TOS_PROC")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_REF_IMAP_TOS_PROC"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val refImapTosProc = loadedDependencies("REF_IMAP_TOS_PROC").as[ref_imap_tos_proc]

    refImapTosProc
    .select(
			$"map_code",
			$"proftos".as("prof_tos"),
			$"anestos".as("anes_tos"),
			$"optos".as("op_tos"),
			$"pcc_type",
			$"pcc_psc_cat2_id"
    )
  }
}


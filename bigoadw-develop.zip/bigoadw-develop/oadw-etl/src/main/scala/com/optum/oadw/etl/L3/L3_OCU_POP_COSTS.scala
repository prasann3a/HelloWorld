package com.optum.oadw.etl.L3


import com.optum.oadw.oadwModels.l3_ocu_pop_costs
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L3_OCU_POP_COSTS extends QueryAndMetadata[l3_ocu_pop_costs] {
  override def name: String = "L3_OCU_POP_COSTS"

  override def sparkSql: String =
    """
       select
        a.year_mth_id,
        cast(a.NEW_MEM_ATTR_ID as int) as NEW_MEM_ATTR_ID,
        b.ia_time,
        c.pcp_assign,
        c.contract_id,
        c.product_id,
        c.sex,
        c.age_cat2,
        c.cat_status_cost3,
        c.mem_userdef_1_id,
        c.at_risk_status_id,
        c.zip,
        a.year_mth_pd,
        a.network_paid_status_id,
        a.provider_status_id,
        a.provider_id,
        a.prv_sp_4,
        a.tos_i_5,
        disrel,
        drg_id,
        a.admit_source,
        a.pos_i,
        cast(sum(amt_req) as decimal(38,10)) as amt_req,
        cast(sum(amt_eqv) as decimal(38,10)) as amt_eqv,
        cast(sum(amt_pay) as decimal(38,10)) as amt_pay,
        cast(sum(amt_np) as decimal(38,10)) as amt_np,
        cast(sum(encounter) as decimal(38,10)) as enc,
        cast(sum(admit) as int) as admits,
        cast(sum(los) as int) as los,
        cast(sum(script) as int) as scripts,
        cast(sum(rad_util) as decimal(38,10)) as rad_util,
        cast(sum(lab_util) as decimal(38,10)) as lab_util,
        cast(sum(er_util) as decimal(38,10)) as er_util,
        cast(sum(mri_util) as decimal(38,10)) as mri_util,
        cast(sum(em_svc_flag) as decimal(38, 10)) as em_svc_util
from l2_ii_ocu_pop_costs_ext a
join L2_II_MAP_DATE_RANGE b on a.year_mth_id=b.year_mth_id
join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
group by a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id, c.sex, c.age_cat2, c.cat_status_cost3,
c.mem_userdef_1_id, c.at_risk_status_id, c.zip, a.year_mth_pd, a.network_paid_status_id, a.provider_status_id, a.provider_id, a.prv_sp_4,
a.tos_i_5,disrel,admit_source, drg_id,a.pos_i"""

  override def dependsOn: Set[String] = Set("L2_II_OCU_POP_COSTS_EXT","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR_EXT")

  def originalSql: String = """insert /*+ append */ into l3_ocu_pop_costs(year_mth_id,NEW_MEM_ATTR_ID,ia_time,pcp_assign,contract_id,product_id,sex,age_cat2,
    cat_status_cost3,mem_userdef_1_id,zip,year_mth_pd,network_paid_status_id,provider_status_id,provider_id,prv_sp_4,
    tos_i_5,disrel,drg_id,admit_source,pos_i,amt_req,amt_eqv,amt_pay,amt_np,enc,admits,los,scripts,rad_util,lab_util,er_util,
    mri_util,em_svc_util
)
select a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id, c.sex, c.age_cat2, c.cat_status_cost3,
      c.mem_userdef_1_id, c.zip, a.year_mth_pd, a.network_paid_status_id, a.provider_status_id, a.provider_id, a.prv_sp_4,
      a.tos_i_5, disrel, drg_id,a.admit_source, a.pos_i, sum(amt_req), sum(amt_eqv), sum(amt_pay), sum(amt_np),
      sum(encounter) as enc, sum(admit) as admits, sum(los) as los,
      sum(script) as scripts, sum(rad_util) as rad_util, sum(lab_util) as lab_util, sum(er_util) as er_util,
      sum(mri_util) as mri_util, sum(em_svc_flag) as   em_svc_util
from l2_ii_ocu_pop_costs_ext a
join L2_II_MAP_DATE_RANGE b on a.year_mth_id=b.year_mth_id
join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
group by a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id, c.sex, c.age_cat2, c.cat_status_cost3,
          c.mem_userdef_1_id, c.zip, a.year_mth_pd, a.network_paid_status_id, a.provider_status_id, a.provider_id, a.prv_sp_4,
          a.tos_i_5,disrel,admit_source, drg_id,a.pos_i"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(
    OutputColumn("year_mth_id",None,None),
    OutputColumn("NEW_MEM_ATTR_ID",None,None),
    OutputColumn("ia_time",None,None),
    OutputColumn("pcp_assign",None,None),
    OutputColumn("contract_id",None,None),
    OutputColumn("product_id",None,None),
    OutputColumn("sex",None,None),
    OutputColumn("age_cat2",None,None),
    OutputColumn("cat_status_cost3",None,None),
    OutputColumn("mem_userdef_1_id",None,None),
    OutputColumn("at_risk_status_id",None,None),
    OutputColumn("zip",None,None),
    OutputColumn("year_mth_pd",None,None),
    OutputColumn("network_paid_status_id",None,None),
    OutputColumn("provider_status_id",None,None),
    OutputColumn("provider_id",None,None),
    OutputColumn("prv_sp_4",None,None),
    OutputColumn("tos_i_5",None,None),
    OutputColumn("disrel",None,None),
    OutputColumn("drg_id",None,None),
    OutputColumn("admit_source",None,None),
    OutputColumn("pos_i",None,None),
    OutputColumn("amt_req",None,None),
    OutputColumn("amt_eqv",None,None),
    OutputColumn("amt_pay",None,None),
    OutputColumn("amt_np",None,None),
    OutputColumn("enc",None,None),
    OutputColumn("admits",None,None),
    OutputColumn("los",None,None),
    OutputColumn("scripts",None,None),
    OutputColumn("rad_util",None,None),
    OutputColumn("lab_util",None,None),
    OutputColumn("er_util",None,None),
    OutputColumn("mri_util",None,None),
    OutputColumn("em_svc_util",None,None)))

  def directoryLevel: String = "L3"





  override def partitions: Int = 128

  val originalSqlFileName: String = "L3_II_ocu_build.sql"
}

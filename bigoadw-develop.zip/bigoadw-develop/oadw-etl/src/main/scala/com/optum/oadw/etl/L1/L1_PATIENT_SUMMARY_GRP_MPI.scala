
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patient_summary_grp_mpi, patient_summary_grp_mpi}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENT_SUMMARY_GRP_MPI extends TableInfo[l1_patient_summary_grp_mpi]{
  override def dependsOn: Set[String] = Set("PATIENT_SUMMARY_GRP_MPI")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENT_SUMMARY_GRP_MPI"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientSummaryGrpMpi = loadedDependencies("PATIENT_SUMMARY_GRP_MPI").as[patient_summary_grp_mpi]

    patientSummaryGrpMpi
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi".as("mpi"),
			$"yob",
			$"mob",
			$"dob",
			$"first_name",
			$"middle_name",
			$"last_name",
			$"mapped_gender",
			$"mapped_ethnicity",
			$"mapped_race",
			$"mapped_zipcode",
			$"mapped_death_ind",
			$"date_of_death",
			$"local_dod",
			$"ssdi_dod",
			$"ssdi_name_match",
			$"display_id",
			$"patientid_cnt",
			$"mapped_language",
			$"mapped_marital_status",
			$"inactive_flag",
			$"religion",
			$"mrace_infer_ind"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_allergy_status, map_allergy_status}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_ALLERGY_STATUS extends TableInfo[l1_map_allergy_status]{
  override def dependsOn: Set[String] = Set("MAP_ALLERGY_STATUS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_ALLERGY_STATUS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapAllergyStatus = loadedDependencies("MAP_ALLERGY_STATUS").as[map_allergy_status]

    mapAllergyStatus
    .select(
			$"groupid".as("client_id"),
			$"mnemonic".as("local_code"),
			$"cui",
			$"dts_version"
    )
  }
}


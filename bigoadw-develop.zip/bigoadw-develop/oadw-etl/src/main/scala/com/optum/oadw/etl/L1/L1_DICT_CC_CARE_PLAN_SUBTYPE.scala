
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_dict_cc_care_plan_subtype, zh_cc_care_plan_subtype}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_DICT_CC_CARE_PLAN_SUBTYPE extends TableInfo[l1_dict_cc_care_plan_subtype]{
  override def dependsOn: Set[String] = Set("ZH_CC_CARE_PLAN_SUBTYPE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_DICT_CC_CARE_PLAN_SUBTYPE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhCcCarePlanSubtype = loadedDependencies("ZH_CC_CARE_PLAN_SUBTYPE").as[zh_cc_care_plan_subtype]

    zhCcCarePlanSubtype
    .select(
			$"care_plan_subtype",
			$"care_plan_subtype_nm",
			$"client_ds_id",
			$"datasrc",
			$"groupid".as("client_id")
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_mborder, mborder}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MBORDER extends TableInfo[l1_mborder]{
  override def dependsOn: Set[String] = Set("MBORDER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MBORDER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mborder = loadedDependencies("MBORDER").as[mborder]

    mborder
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"facilityid",
			$"encounterid",
			$"patientid",
			$"mbprocorderid",
			$"datecollected".as("collected_dtm"),
			$"datereceived".as("received_dtm"),
			$"dateordered".as("ordered_dtm"),
			$"localspecimensource",
			$"localspecimenname",
			$"localorderstatus",
			$"localordercode",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"localorderdesc",
			$"hts_specimen_source"
    )
  }
}


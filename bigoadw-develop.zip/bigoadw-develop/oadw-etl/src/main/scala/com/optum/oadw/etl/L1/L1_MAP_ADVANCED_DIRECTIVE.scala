
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_advanced_directive, map_advanced_directive}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_ADVANCED_DIRECTIVE extends TableInfo[l1_map_advanced_directive]{
  override def dependsOn: Set[String] = Set("MAP_ADVANCED_DIRECTIVE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_ADVANCED_DIRECTIVE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapAdvancedDirective = loadedDependencies("MAP_ADVANCED_DIRECTIVE").as[map_advanced_directive]

    mapAdvancedDirective
    .select(
			$"groupid".as("client_id"),
			$"local_code",
			$"cui",
			$"dts_version"
    )
  }
}


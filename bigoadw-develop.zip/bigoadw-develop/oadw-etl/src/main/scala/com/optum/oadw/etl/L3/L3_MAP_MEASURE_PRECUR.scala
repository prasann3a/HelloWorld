package com.optum.oadw.etl.L3

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.measures.enums.KeepPrecursorTypes
import com.optum.oadw.measures.models.MeasureDefinition
import com.optum.oadw.measures.rules.{Bmi, BmiPrecursor, Criterion, FilterGroup, IfThen, NewPrecursor, Or, Precursor, PrecursorFilter}
import com.optum.oadw.measures.xml.MeasuresResourceLocator
import com.optum.oadw.oadwModels.{l3_map_measure_precur, l4_dict_measure}
import com.optum.oadw.oadw_ref.models.{l3_dict_precursor, l3_map_measure_precur => ref_l3_map_measure_precur}
import org.apache.spark.sql.functions.{greatest, lit, when}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object L3_MAP_MEASURE_PRECUR {
  def apply(alternateMeasures: Option[Set[String]] = None) = new L3_MAP_MEASURE_PRECUR(alternateMeasures)
}

class L3_MAP_MEASURE_PRECUR(optionallyAlternateMeasures: Option[Set[String]] = None) extends TableInfo[l3_map_measure_precur] {
  override def name: String = "L3_MAP_MEASURE_PRECUR"
  override def dependsOn: Set[String] = Set("REFERENCE_SCHEMA_L3_MAP_MEASURE_PRECUR", "L3_DICT_PRECURSOR", "L4_DICT_MEASURE")
  def directoryLevel: String = "LR"

  def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    if (optionallyAlternateMeasures.isDefined && optionallyAlternateMeasures.get.isEmpty)
      logger.warn("NO XML MEASURES WERE FOUND IN THE ETL PROCESS! Expect No Measure Results in the resulting data-set")

    val staticMeasures = loadedDependencies("REFERENCE_SCHEMA_L3_MAP_MEASURE_PRECUR")
      .select($"denominator_ind", $"measure_id", $"measure_precursor_desc", $"numerator_ind",
        $"precursor_flg", $"precursor_id", $"sensitive_ind")
      .as[ref_l3_map_measure_precur]
    val tL3DictPrecursor = loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor]
    val l4DictMeasure = loadedDependencies("L4_DICT_MEASURE").as[l4_dict_measure]
    val measureResources = MeasuresResourceLocator.getMeasureFileInputSources(optionallyAlternateMeasures)
    //logger.warn("MEASURE RESOURCES IN L3_MAP_MEASURE_PRECUR" + measureResources.toString())
    val xmlMeasureDefinitions = measureResources.map({
      case (file, inputSource) => {
        logger.warn("Processing xml measure file: " + file)
        (file, MeasureDefinition.parse(inputSource))
      }
    }).values.toSeq

    calculateMapMeasurePrecur(sparkSession, staticMeasures, tL3DictPrecursor, l4DictMeasure, xmlMeasureDefinitions)
  }

  private def calculateMapMeasurePrecur(sparkSession: SparkSession,
                                        staticMeasures: Dataset[ref_l3_map_measure_precur],
                                        tL3DictPrecursor: Dataset[l3_dict_precursor],
                                        l4DictMeasure: Dataset[l4_dict_measure],
                                        definitions: Seq[MeasureDefinition]): DataFrame = {
    import sparkSession.implicits._
    val xmlSourcedData = definitions.flatMap(parsePrecursorMapFromDefinition).toList.toDS
    val measuresWithSensitivityInd = xmlSourcedData.as("xsd")
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .select(
        $"denominator_ind",
        $"measure_id",
        $"measure_precursor_desc",
        $"numerator_ind",
        $"precursor_flg",
        $"precursor_id",
        $"dp.sensitive_ind"
      ).distinct.as[ref_l3_map_measure_precur]

    val unionedSet = staticMeasures.union(measuresWithSensitivityInd)

    unionedSet.as("un")
      .join(tL3DictPrecursor.as("dp2"), Seq("precursor_id"))
      .join(l4DictMeasure.as("dm"), Seq("measure_id"))
      .select(
        $"denominator_ind",
        $"measure_id",
        $"measure_precursor_desc",
        $"numerator_ind",
        $"precursor_flg",
        $"precursor_id",
        greatest($"un.sensitive_ind", $"dm.sensitive_ind").as("sensitive_ind"),
        when(greatest($"un.sensitive_ind", $"dm.sensitive_ind") === lit(0), lit(1))
          .when(greatest($"un.sensitive_ind", $"dm.sensitive_ind") === lit(1) && $"dm.sensitive_ind" === lit(1), $"dm.sensitive_cat_id")
          .when(greatest($"un.sensitive_ind", $"dm.sensitive_ind") === lit(1) && $"dm.sensitive_ind" === lit(0), $"dp2.sensitive_cat_id")
          .as("sensitive_cat_id"))
      .toDF
  }

  private def parsePrecursorMapFromDefinition(measureDefinition: MeasureDefinition): Seq[l3_map_measure_precur] = {
    val measureId = measureDefinition.id
    Seq(
      measureDefinition.populationCriteria.flatMap(parseMapMeasurePrecursorFromCriterion(measureId, _)),
      measureDefinition.populationAppliedCriteria.flatMap(parseMapMeasurePrecursorFromCriterion(measureId, _))
    ).flatten.distinct
  }

  private def parseMapMeasurePrecursorFromCriterion(measureId: Integer, criterion: Criterion): Seq[l3_map_measure_precur] = {
    criterion match {
      case pf: PrecursorFilter => pf.precursors.flatMap(generateMapMeasurePrecur(measureId, _))
      case bmi: Bmi => bmi.bmiRangePrecursors.flatMap(generateMapMeasurePrecur(measureId, _))
      case fg: FilterGroup => fg.criteria.flatMap(parseMapMeasurePrecursorFromCriterion(measureId, _))
      case it: IfThen => it.thenCriteria.flatMap(parseMapMeasurePrecursorFromCriterion(measureId, _))
      case or: Or =>
        or.leftCriteria.flatMap(parseMapMeasurePrecursorFromCriterion(measureId, _)) ++
          or.rightCriteria.flatMap(parseMapMeasurePrecursorFromCriterion(measureId, _))
      case np: NewPrecursor => np.newPrecursors.flatMap(generateMapMeasurePrecur(measureId, _))
      case _ => Seq.empty
    }
  }

  private def generateMapMeasurePrecur(measureId: Integer, precursor: Precursor): Option[l3_map_measure_precur] = {
    if (precursor.keep == KeepPrecursorTypes.NONE) None else
      Some(l3_map_measure_precur(
        measure_id = measureId,
        denominator_ind = if (precursor.denominatorIndicator) 1 else 0,
        measure_precursor_desc = precursor.measurePrecursorDescription,
        numerator_ind = if (precursor.numeratorIndicator) 1 else 0,
        precursor_flg = precursor.precursorFlg,
        precursor_id = if (precursor.replaceId.nonEmpty) precursor.replaceId.get else precursor.id
      ))
  }

  private def generateMapMeasurePrecur(measureId: Integer, precursor: BmiPrecursor): Option[l3_map_measure_precur] = {
    Some(l3_map_measure_precur(
      measure_id = measureId,
      denominator_ind = if (precursor.denominatorIndicator) 1 else 0,
      measure_precursor_desc = precursor.measurePrecursorDescription,
      numerator_ind = if (precursor.numeratorIndicator) 1 else 0,
      precursor_flg = precursor.precursorFlg,
      precursor_id = precursor.id
    ))
  }
}

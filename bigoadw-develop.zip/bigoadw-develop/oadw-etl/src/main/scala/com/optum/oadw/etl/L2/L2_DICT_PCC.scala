package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_dict_pcc
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_DICT_PCC extends TableInfo[l2_dict_pcc] {
  override def name: String           = "L2_DICT_PCC"
  override def dependsOn: Set[String] = Set("L2_DICT_DCC","L2_MAP_SENSITIVE_CATEGORY")

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val tL2DictDcc = loadedDependencies("L2_DICT_DCC")
    val l2MapSensitiveCategory = loadedDependencies("L2_MAP_SENSITIVE_CATEGORY")

    val window = Window.partitionBy($"pcc").orderBy($"sensitive_hierarchy".asc)

    tL2DictDcc
      .groupBy($"pcc")
      .agg(
        min($"pcc_name").as("pcc_name"),
        min($"tcc").as("tcc"),
        min($"tcc_name").as("tcc_name"),
        min($"sensitive_ind").as("sensitive_ind")
      ).as("agg")
      .join(l2MapSensitiveCategory.as("msc"), expr("UPPER(pcc_name) LIKE CONCAT('%', UPPER(sensitive_text), '%')"), "left")
      .withColumn("row_num",row_number() over window).where($"row_num" === lit(1))
      .select(
        $"agg.pcc",
        $"agg.pcc_name",
        $"agg.tcc",
        $"agg.tcc_name",
        $"agg.sensitive_ind",
        when($"sensitive_ind" === 1,coalesce($"msc.sensitive_cat_id",lit(999))).otherwise(lit(1)).as("sensitive_cat_id")
      )
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ebm_memcondfile, ebm_memcondfile}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_EBM_MEMCONDFILE extends TableInfo[l1_ebm_memcondfile]{
  override def dependsOn: Set[String] = Set("EBM_MEMCONDFILE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_EBM_MEMCONDFILE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ebmMemcondfile = loadedDependencies("EBM_MEMCONDFILE").as[ebm_memcondfile]

    ebmMemcondfile
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi".as("mpi"),
			$"report_case_id",
			$"cond_conf_qual",
			$"file_processing_month".as("file_processing_month_dt"),
			$"process"
    )
  }
}


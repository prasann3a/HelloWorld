
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_cc_case_tier_history, cc_case_tier_history}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_CC_CASE_TIER_HISTORY extends TableInfo[l1_cc_case_tier_history]{
  override def dependsOn: Set[String] = Set("CC_CASE_TIER_HISTORY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CC_CASE_TIER_HISTORY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("CC_CASE_TIER_HISTORY").as[cc_case_tier_history]

    cdrTbl
    .select(
		$"case_tier",
		$"case_tier_created_by_id",
		$"case_tier_elapsed_dy",
		$"case_tier_end_dt",
		$"case_tier_nm",
		$"case_tier_start_dt",
		$"cc_case_id",
		$"cc_case_tier_hist_id",
		$"client_ds_id",
		$"datasrc",
		$"groupid".as("client_id"),
		$"grp_mpi".as("mpi"),
		$"hgpid",
		$"patientid"
    )
  }
}


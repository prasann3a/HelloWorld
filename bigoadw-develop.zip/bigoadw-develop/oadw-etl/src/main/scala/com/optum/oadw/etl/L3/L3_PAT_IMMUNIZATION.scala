package com.optum.oadw.etl.L3

import com.optum.oadw.definedfunctions.{BitOrAggFunction, ListAggFunction, ListAndFunction}
import com.optum.oadw.oadwModels.{l1_map_hts_dcc, l1_map_procedure_cui, l2_map_cds_flg, l2_pat_immunization, l3_pat_immunization}
import com.optum.oadw.oadw_ref.models.{l3_dict_immunization, l3_map_immunization_cui}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType

object L3_PAT_IMMUNIZATION extends TableInfo[l3_pat_immunization]{
  override def name: String = "L3_PAT_IMMUNIZATION"
  override def dependsOn: Set[String] = Set("L2_PAT_IMMUNIZATION","L2_MAP_CDS_FLG","REFERENCE_SCHEMA_L3_MAP_IMMUNIZATION_CUI","L1_MAP_HTS_DCC","L1_MAP_PROCEDURE_CUI","REFERENCE_SCHEMA_L3_DICT_IMMUNIZATION")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tl2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg]
    val tL2PatImmunization = loadedDependencies("L2_PAT_IMMUNIZATION").as[l2_pat_immunization]
    val tL3MapImmunizationCui = loadedDependencies("REFERENCE_SCHEMA_L3_MAP_IMMUNIZATION_CUI").as[l3_map_immunization_cui]
    val tL1MapHtsDcc = loadedDependencies("L1_MAP_HTS_DCC").as[l1_map_hts_dcc]
    val tL1MapProcedureCui = loadedDependencies("L1_MAP_PROCEDURE_CUI").as[l1_map_procedure_cui]
    val tL3DictImmunization = loadedDependencies("REFERENCE_SCHEMA_L3_DICT_IMMUNIZATION").as[l3_dict_immunization]

    val procDccMap = tL1MapHtsDcc
      .select(
        lit("DCC").as("codetype"),
        $"hts_cui".as("cui"),
        $"dcc".as("mappedcode")
      )
      .union(tL1MapProcedureCui.select($"codetype",$"cui",$"mappedcode"))
      .as("mp")
      .join(tL3MapImmunizationCui.as("imm_map"), $"mp.cui" === $"imm_map.immunization_cui")


    val immMaps = tL2PatImmunization.as("imm")
        .join(procDccMap.as("mp"), $"mp.mappedcode" === $"imm.imm_cd" and $"mp.codetype" === $"imm.code_type","left_outer")
        .select(
          $"imm.client_id",
          $"imm.mpi",
          $"imm.imm_dt",
          $"imm.cds_grp",
          $"imm.clinical_event_id",
          $"imm.pat_reported_ind",
          $"imm.rxadmin_ind",
          $"imm.rxorder_ind",
          $"imm.immunization_ind",
          $"imm.procedure_ind",
          $"imm.code_type",
          $"imm.imm_cd",
          $"imm.sensitive_ind",
          coalesce($"mp.immunization_cui", when($"imm.code_type" === lit("DCC"),lit("CH999993")).otherwise(lit("CH999999"))).as("cui"),
          coalesce($"mp.immunization_id",lit(999)).as("immunization_id")
        )

    val tempImm = immMaps.as("imm")
      .join(tl2MapCdsFlg.as("cdsflg"), ListAndFunction.listAnd($"imm.cds_grp", $"cdsflg.client_ds_id") =!= 0, "left_outer")
      .groupBy(
        $"imm.client_id",
        $"imm.mpi",
        $"imm.imm_dt",
        $"imm.cds_grp",
        $"imm.clinical_event_id",
        $"imm.pat_reported_ind",
        $"imm.rxadmin_ind",
        $"imm.rxorder_ind",
        $"imm.immunization_ind",
        $"imm.procedure_ind",
        $"imm.code_type",
        $"imm.imm_cd",
        $"imm.cui",
        $"immunization_id",
        $"imm.sensitive_ind"
      )
      .agg(
        min(
          when($"cdsflg.source_type_flg".isin(4, 8), 1)
            .when($"cdsflg.source_type_flg" === 2, 2)
            .when($"cdsflg.source_type_flg" === 1, 3)
            .otherwise(4)
        ).as("source_priority"),
        min(
          when($"imm.code_type" === "DCC", 1)
            .when($"imm.code_type" === "CPT4", 2)
            .when($"imm.code_type" === "HCPCS", 3)
            .when($"imm.code_type" === "ICD10", 4)
            .when($"imm.code_type" === "ICD9", 5)
            .when($"imm.code_type" === "CUSTOM", 6)
            .otherwise(7)
        ).as("code_priority")
      )

    val partitionClause = Window.partitionBy($"imm.mpi",$"imm.imm_dt",$"imm.immunization_id")

    val orderClause = Seq($"imm.sensitive_ind".asc_nulls_last,$"imm.source_priority".asc_nulls_last,$"imm.code_priority".asc_nulls_last,$"imm.imm_cd".desc_nulls_last,$"imm.cui".desc_nulls_last)

    tempImm.as("imm")
        .join(tL3DictImmunization.as("dict"),$"imm.immunization_id" === $"dict.immunization_id")
        .select(
          $"imm.client_id",
          $"imm.mpi",
          $"imm.imm_dt",
          $"imm.immunization_id",
          ListAggFunction.listAgg($"imm.cds_grp").over(partitionClause).as("cds_grp"),
          first($"imm.imm_cd").over(partitionClause.orderBy(orderClause:_*).rangeBetween(Window.unboundedPreceding,Window.unboundedFollowing)).as("imm_cd"),
          first($"imm.code_type").over(partitionClause.orderBy(orderClause:_*).rangeBetween(Window.unboundedPreceding,Window.unboundedFollowing)).as("code_type"),
          max($"imm.pat_reported_ind").over(partitionClause).as("pat_reported_ind"),
          max($"imm.rxadmin_ind").over(partitionClause).as("rxadmin_ind"),
          max($"imm.rxorder_ind").over(partitionClause).as("rxorder_ind"),
          max($"imm.immunization_ind").over(partitionClause).as("immunization_ind"),
          max($"imm.procedure_ind").over(partitionClause).as("procedure_ind"),
          when(greatest(first($"imm.sensitive_ind").over(partitionClause.orderBy(orderClause:_*).rangeBetween(Window.unboundedPreceding,Window.unboundedFollowing)),$"dict.sensitive_ind") === 1,1).otherwise(0).as("sensitive_ind")
        ).distinct()

  }
}

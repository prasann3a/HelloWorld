
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_depression_followup, map_depression_followup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_DEPRESSION_FOLLOWUP extends TableInfo[l1_map_depression_followup]{
  override def dependsOn: Set[String] = Set("MAP_DEPRESSION_FOLLOWUP")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_DEPRESSION_FOLLOWUP"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapDepressionFollowup = loadedDependencies("MAP_DEPRESSION_FOLLOWUP").as[map_depression_followup]

    mapDepressionFollowup
    .select(
			$"groupid".as("client_id"),
			$"localcode".as("local_code"),
			$"cui",
			$"dts_version"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_provider_contact, zh_provider_contact}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROVIDER_CONTACT extends TableInfo[l1_provider_contact]{
  override def dependsOn: Set[String] = Set("ZH_PROVIDER_CONTACT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROVIDER_CONTACT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhProviderContact = loadedDependencies("ZH_PROVIDER_CONTACT").as[zh_provider_contact]

    zhProviderContact
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"local_provider_id",
			$"address_line1",
			$"address_line2",
			$"city",
			$"state",
			$"zipcode",
			$"work_phone",
			$"email_address",
			$"update_date".as("update_dt"),
			$"master_hgprovid",
			$"local_contact_type",
			$"mapped_contact_type"
    )
  }
}


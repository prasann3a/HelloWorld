
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patient_care_pathway, patient_care_pathway}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENT_CARE_PATHWAY extends TableInfo[l1_patient_care_pathway]{
  override def dependsOn: Set[String] = Set("PATIENT_CARE_PATHWAY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENT_CARE_PATHWAY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientCarePathway = loadedDependencies("PATIENT_CARE_PATHWAY").as[patient_care_pathway]

    patientCarePathway
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"patientid",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"cp_library_id",
			$"cp_id",
			$"prog_id",
			$"owner_id",
			$"owner_name",
			$"provider_npi",
			$"status",
			$"status_date".as("status_dt"),
			$"create_date".as("create_dt"),
			$"reg_mem_create_date".as("reg_mem_create_dt"),
			$"updated_date".as("updated_dt"),
			$"first_completed_task_dt",
			$"closed_date".as("closed_dt"),
			$"cc_assignment_date".as("cc_assignment_dt")
    )
  }
}



package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l1_ref_hts_dcc_current, l2_dict_dcc}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadw_ref.models.l2_map_sensitive_category
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.sql.functions._


object L2_DICT_DCC extends TableInfo[l2_dict_dcc] {
  override def name: String = "L2_DICT_DCC"

  override def dependsOn: Set[String] = Set("L1_REF_HTS_DCC_CURRENT","L2_MAP_SENSITIVE_CATEGORY")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1RepHitsDccCurrent = loadedDependencies("L1_REF_HTS_DCC_CURRENT").as[l1_ref_hts_dcc_current]
    val l2MapSensitiveCategory = loadedDependencies("L2_MAP_SENSITIVE_CATEGORY").as[l2_map_sensitive_category]

    val window = Window.partitionBy($"dcc").orderBy($"sensitive_hierarchy")

    l1RepHitsDccCurrent
      .withColumn("sensitive_ind", when($"is_sensitive" === "Y",lit(1)).otherwise(lit(0)))
      .join(l2MapSensitiveCategory, expr("UPPER(genericname) LIKE CONCAT('%', UPPER(sensitive_text), '%')"), "left")
      .withColumn("row_num",rank() over window).where($"row_num" === lit(1))
      .select($"dcc",
      $"genericname".as("dcc_name"),
      $"pcc".as("pcc"),
      $"pcc_label".as("pcc_name"),
      $"tcc",
      $"tcc_label".as("tcc_name"),
      $"sensitive_ind",
      when($"sensitive_ind" === 1,coalesce($"sensitive_cat_id",lit(999))).otherwise(lit(1)).as("sensitive_cat_id"),
      when($"is_vaccine" === "Y",lit(1)).otherwise(lit(0)).as("vaccine_ind"),
      when($"isspecialtydrug" === "Y",lit(1)).otherwise(lit(0)).as("specialty_ind"),
      when($"harmful_geriatric_med" === "Y",lit(1)).otherwise(lit(0)).as("harmful_geriatric_med")
    )
  }

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_dict_dcc_build.sql"
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_bp_followup, map_bp_followup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_BP_FOLLOWUP extends TableInfo[l1_map_bp_followup]{
  override def dependsOn: Set[String] = Set("MAP_BP_FOLLOWUP")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_BP_FOLLOWUP"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("MAP_BP_FOLLOWUP").as[map_bp_followup]

    cdrTbl
    .select(
		$"groupid".as("client_id"),
		$"localcode".as("local_code"),
		$"cui",
		$"dts_version"
    )
  }
}


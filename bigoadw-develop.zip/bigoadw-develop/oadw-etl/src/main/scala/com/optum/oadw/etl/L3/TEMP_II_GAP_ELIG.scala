package com.optum.oadw.etl.L3


import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_ii_gap_elig_data(member: String, conf_num: java.lang.Long, elig_end_dt: java.sql.Timestamp)

object TEMP_II_GAP_ELIG extends QueryAndMetadata[temp_ii_gap_elig_data] {
  override def name: String = "TEMP_II_GAP_ELIG"

  override def sparkSql: String = """SELECT member,conf_num,MIN(lag_dt) elig_end_dt
FROM (
SELECT conf.member,conf.conf_num,
mem.eff_dt,
lag(mem.end_dt,1,mem.eff_dt) over (partition BY conf.conf_num ORDER BY mem.eff_dt) lag_dt
FROM L2_II_CONFINEMENTS conf
JOIN L2_II_MEM_ENROLL mem ON conf.member = mem.member AND mem.end_dt >= conf.end_dt
) WHERE datediff(eff_dt, lag_dt) > 1
GROUP BY member,conf_num"""

  override def dependsOn: Set[String] = Set("L2_II_CONFINEMENTS","L2_II_MEM_ENROLL")

  def originalSql: String = """

---Inserting II data
--patients with the gap in the coverage
CREATE TABLE temp_ii_gap_elig pctfree 0 nologging AS
SELECT member,conf_num,MIN(lag_dt) elig_end_dt
  FROM (
SELECT conf.member,conf.conf_num,
       mem.eff_dt,
       lag(mem.end_dt,1,mem.eff_dt) over (partition BY conf.conf_num ORDER BY mem.eff_dt) lag_dt
FROM l2_ii_confinements conf
JOIN l2_ii_mem_enroll mem ON conf.member = mem.member AND mem.end_dt >= conf.end_dt
) WHERE eff_dt-lag_dt > 1
GROUP BY member,conf_num"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L3"

  override def saveDataFrameToParquet: Boolean = false

  val originalSqlFileName: String = "L3_event_readmission_build.sql"
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_dict_cc_case_status, zh_cc_case_status}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_DICT_CC_CASE_STATUS extends TableInfo[l1_dict_cc_case_status]{
  override def dependsOn: Set[String] = Set("ZH_CC_CASE_STATUS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_DICT_CC_CASE_STATUS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhCcCaseStatus = loadedDependencies("ZH_CC_CASE_STATUS").as[zh_cc_case_status]

    zhCcCaseStatus
    .select(
			$"case_status",
			$"case_status_nm",
			$"client_ds_id",
			$"datasrc",
			$"groupid".as("client_id")
    )
  }
}


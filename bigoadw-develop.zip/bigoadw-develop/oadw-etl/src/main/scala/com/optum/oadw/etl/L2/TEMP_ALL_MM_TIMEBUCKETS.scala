package com.optum.oadw.etl.L2

import java.sql.Timestamp

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_all_mm_timebuckets_data(yr_month: String, month_dt: java.sql.Date, end_dt: java.sql.Date)

object TEMP_ALL_MM_TIMEBUCKETS extends QueryAndMetadata[temp_all_mm_timebuckets_data] {
  override def name: String = "TEMP_ALL_MM_TIMEBUCKETS"

  override def sparkSql: String = """SELECT date_format(ADD_MONTHS(t.start_dt,c.level-1),'yyyyMM') AS yr_month
                                           , add_months(t.start_dt,c.level-1) AS month_dt
                                           ,last_day(add_months(t.start_dt,c.level-1)) as end_dt
                                      FROM ( SELECT start_dt,end_dt FROM l4_timeframe WHERE timeframe_id=7) t
                                     CROSS JOIN (SELECT SERIAL_NUM as level FROM CALENDAR) c
                                     WHERE c.level <= CEIL(MONTHS_BETWEEN(t.end_dt,t.start_dt))"""

  override def dependsOn: Set[String] = Set("L4_TIMEFRAME", "CALENDAR")

}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_pat_risk_attrib, pat_risk_attrib}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PAT_RISK_ATTRIB extends TableInfo[l1_pat_risk_attrib]{
  override def dependsOn: Set[String] = Set("PAT_RISK_ATTRIB")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PAT_RISK_ATTRIB"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patRiskAttrib = loadedDependencies("PAT_RISK_ATTRIB").as[pat_risk_attrib]

    patRiskAttrib
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"patientid",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"contract",
			$"start_date".as("start_dt"),
			$"end_date".as("end_dt"),
			$"providerid",
			$"mstrprovid",
			$"contract_id",
			$"at_risk_status"
    )
  }
}


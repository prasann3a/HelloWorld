
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patientcontact, patientcontact}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENTCONTACT extends TableInfo[l1_patientcontact]{
  override def dependsOn: Set[String] = Set("PATIENTCONTACT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENTCONTACT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientcontact = loadedDependencies("PATIENTCONTACT").as[patientcontact]

    patientcontact
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"patientid",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"update_dt".as("update_dtm"),
			$"home_phone",
			$"work_phone",
			$"cell_phone",
			$"work_email",
			$"personal_email"
    )
  }
}


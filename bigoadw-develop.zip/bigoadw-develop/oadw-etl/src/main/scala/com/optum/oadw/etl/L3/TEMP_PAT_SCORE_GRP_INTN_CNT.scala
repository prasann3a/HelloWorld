package com.optum.oadw.etl.L3

import com.optum.oadw.oadwModels.{l3_pat_score_grp_precur, l3_map_score_grp_intn}
import com.optum.oadw.oadw_ref.models.l3_map_score_grp_intn_cnt
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType

case class temp_pat_score_grp_intn_cnt_data(client_id: String, mpi: String, grp_id: java.lang.Integer, timeframe_id: java.lang.Integer,
                                          elig_cds_id: java.lang.Integer, interaction_id: java.lang.Integer, coef_multiplier: java.lang.Double,
                                          sensitive_ind: java.lang.Integer)

object TEMP_PAT_SCORE_GRP_INTN_CNT extends TableInfo[temp_pat_score_grp_intn_cnt_data] {
  override def name: String = "TEMP_PAT_SCORE_GRP_INTN_CNT"

  override def dependsOn: Set[String] = Set(
    "L3_PAT_SCORE_GRP_PRECUR",
    "L3_MAP_SCORE_GRP_INTN_CNT",
    "L3_MAP_SCORE_GRP_INTN"
  )

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL3PatScoreGrpPrecur = loadedDependencies("L3_PAT_SCORE_GRP_PRECUR").as[l3_pat_score_grp_precur]
    val tL3MapScoreGrpIntnCnt = broadcast(loadedDependencies("L3_MAP_SCORE_GRP_INTN_CNT").as[l3_map_score_grp_intn_cnt])
    val l3MapScoreGrpIntn = broadcast(loadedDependencies("L3_MAP_SCORE_GRP_INTN").as[l3_map_score_grp_intn])

    // get valid grp_ids for count interactions
    val eligGrpIdsDf = l3MapScoreGrpIntn
      .where($"cnt_interaction_ind" === 1)
      .select($"grp_id", $"cnt_grp_id", $"sensitive_ind")
      .distinct()

    val eligPrecsDf = eligGrpIdsDf.as("egi")
      .join(tL3MapScoreGrpIntnCnt.as("msgic"), $"egi.cnt_grp_id" === $"msgic.cnt_grp_id")
      .select(
        $"grp_id",
        $"msgic.cnt_grp_id",
        $"msgic.precursor_id",
        $"egi.sensitive_ind"
      )

    val tempPrecCntDf = tL3PatScoreGrpPrecur.as("patgp")
        .join(eligPrecsDf.as("ep"), $"ep.grp_id" === $"patgp.grp_id" && $"ep.precursor_id" === $"patgp.precursor_id")
        .groupBy($"patgp.client_id",
          $"patgp.mpi",
          $"patgp.grp_id",
          $"patgp.timeframe_id",
          $"patgp.elig_cds_id",
          $"ep.cnt_grp_id",
          $"ep.sensitive_ind"
        )
        .agg(
          count($"patgp.precursor_id").as("prec_cnt")
        )

    tempPrecCntDf.as("tmp")
      .join(l3MapScoreGrpIntn.as("msgi"), $"tmp.grp_id" === $"msgi.grp_id" && $"tmp.cnt_grp_id" === $"msgi.cnt_grp_id" &&
      $"msgi.cnt_interaction_ind" === lit(1) && $"tmp.prec_cnt" >= $"msgi.cnt_range_min" && $"tmp.prec_cnt" <= $"msgi.cnt_range_max")
      .select(
        $"tmp.client_id",
        $"tmp.mpi",
        $"tmp.grp_id",
        $"tmp.timeframe_id",
        $"tmp.elig_cds_id",
        $"msgi.interaction_id",
        lit(1).cast(DoubleType).as("coef_multiplier"),
        $"tmp.sensitive_ind"
      )

  }
}

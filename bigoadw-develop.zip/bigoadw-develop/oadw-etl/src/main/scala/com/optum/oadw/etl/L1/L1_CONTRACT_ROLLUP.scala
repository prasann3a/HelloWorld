
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_contract_rollup, contract_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_CONTRACT_ROLLUP extends TableInfo[l1_contract_rollup]{
  override def dependsOn: Set[String] = Set("CONTRACT_ROLLUP")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CONTRACT_ROLLUP"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val contractRollup = loadedDependencies("CONTRACT_ROLLUP").as[contract_rollup]

    contractRollup
    .select(
			$"groupid".as("client_id"),
			$"contract_id",
			$"contract_desc",
			$"contract_lv2",
			$"contract_lv2_desc",
			$"contract_lv1",
			$"contract_lv1_desc",
			$"contract_hier",
			$"client_ds_id",
			$"datasrc"
    )
  }
}


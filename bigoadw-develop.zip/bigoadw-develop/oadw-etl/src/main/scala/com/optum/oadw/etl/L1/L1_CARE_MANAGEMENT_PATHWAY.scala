
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_care_management_pathway, care_management_pathway}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_CARE_MANAGEMENT_PATHWAY extends TableInfo[l1_care_management_pathway]{
  override def dependsOn: Set[String] = Set("CARE_MANAGEMENT_PATHWAY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CARE_MANAGEMENT_PATHWAY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("CARE_MANAGEMENT_PATHWAY").as[care_management_pathway]

    cdrTbl
    .select(
		$"groupid".as("client_id"),
		$"client_ds_id",
		$"datasrc",
		$"cp_library_id",
		$"cp_library_name",
		$"cp_attribute",
		$"cp_value",
		$"prog_id",
		$"updated_date".as("updated_dtm")
    )
  }
}


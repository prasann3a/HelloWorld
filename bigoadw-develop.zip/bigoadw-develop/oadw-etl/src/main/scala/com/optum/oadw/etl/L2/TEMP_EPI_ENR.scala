package com.optum.oadw.etl.L2
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_epi_enr_data(sub_end_dt: java.sql.Timestamp, enroll_order: java.lang.Integer, rn: java.lang.Integer,
                             episode_id: java.lang.Long, subscriber_id: String, sub_eff_dt: java.sql.Timestamp,
                             epi_date: java.sql.Timestamp, member: String, sub_enroll_order: java.lang.Integer,
                             mem_eff_dt: java.sql.Timestamp, mem_end_dt: java.sql.Timestamp, epi_from: java.sql.Date,
                             epi_to: java.sql.Date)

object TEMP_EPI_ENR extends QueryAndMetadata[temp_epi_enr_data] {
  override def name: String = "TEMP_EPI_ENR"

  override def sparkSql: String = """
                                   with tempIIEpisodes as (Select EPISODE_ID, MEMBER, to_date(date_format(EPI_TO, 'yyyy-MM-dd')) as EPI_TO,
                                      to_date(date_format(EPI_FROM, 'yyyy-MM-dd')) as EPI_FROM from L2_II_EPISODES)
                                   select *
                                    from (
                                    SELECT e.*,
                                      case
                                        when enroll_order=1 then epi_to
                                        when enroll_order=2 then epi_from
                                        when enroll_order in (3,4) then mem_eff_dt
                                        else mem_end_dt
                                      end epi_date,
                                      ROW_NUMBER ()   OVER (PARTITION BY EPISODE_ID, MEMBER ORDER BY EPISODE_ID,MEMBER, ENROLL_ORDER, SUB_ENROLL_ORDER, MEM_EFF_DT,
                                      MEM_END_DT DESC,SUB_EFF_DT, SUB_END_DT DESC) rn
                                    FROM (
                                      SELECT EPISODE_ID, E.MEMBER, E.EPI_TO, E.EPI_FROM, ME.EFF_DT MEM_EFF_DT,ME.END_DT    MEM_END_DT,
                                      S.SUBSCRIBER_ID, S.EFF_DT SUB_EFF_DT, S.END_DT SUB_END_DT,
                                    CASE
                                      WHEN (EPI_TO BETWEEN to_date(date_format(ME.EFF_DT, 'yyyy-MM-dd')) AND to_date(date_format(ME.END_DT, 'yyyy-MM-dd'))) THEN 1
                                      WHEN (E.EPI_FROM BETWEEN to_date(date_format(ME.EFF_DT, 'yyyy-MM-dd')) AND to_date(date_format(ME.END_DT, 'yyyy-MM-dd'))) THEN 2
                                      WHEN (E.EPI_TO BETWEEN date_sub(ME.EFF_DT,cds.code) AND ME.END_DT) THEN 3
                                      WHEN (E.EPI_TO BETWEEN ME.EFF_DT AND date_sub(ME.END_DT,cds.code)) THEN 4
                                      WHEN (E.EPI_FROM BETWEEN date_sub(ME.EFF_DT,cds.code) AND ME.END_DT) THEN 5
                                    ELSE 6
                                      END ENROLL_ORDER,
                                    CASE WHEN (EPI_TO BETWEEN to_date(date_format(S.EFF_DT, 'yyyy-MM-dd')) AND to_date(date_format(S.END_DT, 'yyyy-MM-dd'))) THEN 1
                                      WHEN (EPI_FROM BETWEEN to_date(date_format(S.EFF_DT, 'yyyy-MM-dd')) AND to_date(date_format(S.END_DT, 'yyyy-MM-dd'))) THEN 2
                                      WHEN (E.EPI_TO BETWEEN date_sub(S.EFF_DT,cds.code) AND S.END_DT) THEN 3
                                      WHEN (E.EPI_TO BETWEEN S.EFF_DT AND date_add(S.END_DT,cds.code)) THEN 4
                                      WHEN (E.EPI_FROM BETWEEN date_sub(S.EFF_DT,cds.code) AND S.END_DT) THEN 5
                                    ELSE 6
                                      END SUB_ENROLL_ORDER
                                    FROM tempIIEpisodes E
                                      cross join (select * from L2_II_IMAP_CODES where codetype_id = 166) cds
                                      INNER JOIN L2_II_MEM_ENROLL ME ON ME.MEMBER = E.MEMBER
                                        AND ((E.EPI_TO BETWEEN date_sub(ME.EFF_DT,cds.code) AND date_add(ME.END_DT,cds.code))
                                        OR (EPI_FROM BETWEEN date_sub(ME.EFF_DT,cds.code) AND date_add(ME.END_DT,cds.code)))
                                      INNER JOIN L2_II_SUBSCRIBER S ON ME.SUBSCRIBER_ID = S.SUBSCRIBER_ID
                                        AND ((E.EPI_TO BETWEEN date_sub(S.EFF_DT,cds.code) AND date_add(S.END_DT,cds.code))
                                        OR (EPI_FROM BETWEEN date_sub(S.EFF_DT,cds.code) AND date_add(S.END_DT,cds.code)))) E
                                    ) EE  WHERE rn = 1"""

  override def dependsOn: Set[String] = Set("L2_II_EPISODES","L2_II_IMAP_CODES","L2_II_MEM_ENROLL","L2_II_SUBSCRIBER")

  def originalSql: String = """


---episodes

CREATE TABLE TEMP_EPI_ENR PCTFREE 0 NOLOGGING AS
select *
 from (
SELECT e.*,
       case
            when enroll_order=1 then epi_to
            when enroll_order=2 then epi_from
            when enroll_order in (3,4) then mem_eff_dt
            else mem_end_dt
        end epi_date,
    ROW_NUMBER ()   OVER (PARTITION BY EPISODE_ID, MEMBER ORDER BY EPISODE_ID,MEMBER, ENROLL_ORDER, SUB_ENROLL_ORDER, MEM_EFF_DT,
                                       MEM_END_DT DESC,SUB_EFF_DT, SUB_END_DT DESC) rn
FROM (SELECT EPISODE_ID, E.MEMBER, E.EPI_TO, E.EPI_FROM, ME.EFF_DT MEM_EFF_DT,ME.END_DT    MEM_END_DT,
             S.SUBSCRIBER_ID, S.EFF_DT SUB_EFF_DT, S.END_DT SUB_END_DT,
             CASE WHEN (EPI_TO BETWEEN ME.EFF_DT AND ME.END_DT) THEN 1
                  WHEN (E.EPI_FROM BETWEEN ME.EFF_DT AND ME.END_DT) THEN 2
                  WHEN (E.EPI_TO BETWEEN ME.EFF_DT-cds.code AND ME.END_DT) THEN 3
                  WHEN (E.EPI_TO BETWEEN ME.EFF_DT AND ME.END_DT+cds.code) THEN 4
                  WHEN (E.EPI_FROM BETWEEN ME.EFF_DT-cds.code AND ME.END_DT)THEN 5
                  ELSE 6
              END ENROLL_ORDER,
              CASE WHEN (EPI_TO BETWEEN S.EFF_DT AND S.END_DT) THEN 1
                   WHEN (EPI_FROM BETWEEN S.EFF_DT AND S.END_DT) THEN 2
                   WHEN (E.EPI_TO BETWEEN S.EFF_DT-cds.code AND S.END_DT) THEN 3
                   WHEN (E.EPI_TO BETWEEN S.EFF_DT AND S.END_DT+cds.code) THEN 4
                   WHEN (E.EPI_FROM BETWEEN S.EFF_DT-cds.code AND S.END_DT) THEN 5
                   ELSE 6
              END SUB_ENROLL_ORDER
         FROM L2_II_EPISODES E
         inner join l2_ii_imap_codes cds on cds.codetype_id = 166 and  1=1
         INNER JOIN L2_II_MEM_ENROLL ME ON ME.MEMBER = E.MEMBER
                                                                 AND ((E.EPI_TO BETWEEN ME.EFF_DT-cds.code AND ME.END_DT+cds.code)
                                                                  OR (EPI_FROM BETWEEN ME.EFF_DT-cds.code AND ME.END_DT+cds.code)
                                                                 )
        INNER JOIN L2_II_SUBSCRIBER S ON ME.SUBSCRIBER_ID = S.SUBSCRIBER_ID
                                                 AND ((E.EPI_TO BETWEEN S.EFF_DT-cds.code AND S.END_DT+cds.code)
                                                       OR (EPI_FROM BETWEEN S.EFF_DT-cds.code AND S.END_DT+cds.code)
                                                      )
        ) E
        ) EE  WHERE rn = 1
        """

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"




}


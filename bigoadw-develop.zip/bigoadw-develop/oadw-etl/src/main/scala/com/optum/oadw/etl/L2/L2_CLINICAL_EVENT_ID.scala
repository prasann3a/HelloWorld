
/**
  * auto-generated code
*/
package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_clinical_event_id
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_CLINICAL_EVENT_ID extends QueryAndMetadata[l2_clinical_event_id] {
  override def name: String = "L2_CLINICAL_EVENT_ID"

  override def sparkSql: String = """SELECT  DISTINCT a.client_id
, cast(a.encounter_grp_num as long) as clinical_event_id
,a.client_ds_id
,b.id_type as id_type
,a.encounterid as id_value
FROM L1_encounter_encounter_grp a
INNER JOIN L2_map_upload_rules b on (a.client_id = b.client_id AND a.client_ds_id = b.client_ds_id AND b.id_type = 'NON_ALT')
WHERE b.rule_type = 'Encounter ID'
AND length(a.encounterid) <= 50 --looking at whether there is value in the long ids.  Might need to revisit the column size
 UNION ALL
SELECT  DISTINCT a.client_id
, cast(a.encounter_grp_num as long) as clinical_event_id
,a.client_ds_id
,c.id_type as id_type
,b.alt_encounterid as id_value
FROM L1_encounter_encounter_grp a
INNER JOIN L1_Clinicalencounter b ON (a.client_id = b.client_id AND a.client_ds_id = b.client_ds_id AND a.encounterid = b.encounterid)
INNER JOIN L2_map_upload_rules c on (a.client_id = c.client_id AND a.client_ds_id = c.client_ds_id AND c.id_type = 'ALT')
WHERE c.rule_type = 'Encounter ID'
AND b.alt_encounterid IS NOT NULL
AND length(b.alt_encounterid) <= 50 --looking at whether there is value in the long ids.  Might need to revisit the column size"""

  override def dependsOn: Set[String] = Set("L1_ENCOUNTER_ENCOUNTER_GRP","L2_MAP_UPLOAD_RULES","L1_CLINICALENCOUNTER")

  def originalSql: String = """


INSERT /*+ APPEND */ INTO L2_clinical_event_id(client_id,clinical_event_id,client_ds_id,id_type,id_value)
SELECT /*+ parallel(4) */ DISTINCT a.client_id
       ,a.encounter_grp_num as clinical_event_id
       ,a.client_ds_id
       ,c.id_type as id_type
       ,b.alt_encounterid
FROM L1_encounter_encounter_grp a
INNER JOIN L1_Clinicalencounter b ON (a.client_id = b.client_id AND a.client_ds_id = b.client_ds_id AND a.encounterid = b.encounterid)
INNER JOIN L2_map_upload_rules c on (a.client_id = c.client_id AND a.client_ds_id = c.client_ds_id AND c.id_type = 'ALT')
WHERE c.rule_type = 'Encounter ID'
AND b.alt_encounterid IS NOT NULL
AND length(b.alt_encounterid) <= 50 --looking at whether there is value in the long ids.  Might need to revisit the column size
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("client_id",None,None), OutputColumn("clinical_event_id",None,None), OutputColumn("client_ds_id",None,None), OutputColumn("id_type",None,None), OutputColumn("id_value",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_clinical_event_id_build.sql"
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_techorprof, map_techorprof}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_TECHORPROF extends TableInfo[l1_map_techorprof]{
  override def dependsOn: Set[String] = Set("MAP_TECHORPROF")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_TECHORPROF"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapTechorprof = loadedDependencies("MAP_TECHORPROF").as[map_techorprof]

    mapTechorprof
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"cui",
			$"dts_version"
    )
  }
}


package com.optum.oadw.etl.L2


import java.sql.Timestamp

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

case class temp_tos_enc_prov_data(encounterid: String, client_ds_id: Integer, patient_type_cui: String, spec_code: String, facility_ind: Integer, mpi: String, client_id: String, encounter_dtm: Timestamp, prov_id: String, npi: String)

object TEMP_TOS_ENC_PROV extends TableInfo[temp_tos_enc_prov_data] {
  override def name: String = "TEMP_TOS_ENC_PROV"

  override def dependsOn: Set[String] = Set("L1_CLINICALENCOUNTER", "L1_MAP_PATIENT_TYPE", "L1_MAP_PROVIDER_ROLE",
    "L1_PROVIDER_ROLE_RANK", "L1_ENCOUNTERPROVIDER", "TEMP_PROVIDER_CUI_SPEC")

  override def partitions: Int = 64

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1ClinicalEncounter = loadedDependencies("L1_CLINICALENCOUNTER").as[l1_clinicalencounter]

    val l1MapPatientType = loadedDependencies("L1_MAP_PATIENT_TYPE").as[l1_map_patient_type]

    val l1MapProviderRole = loadedDependencies("L1_MAP_PROVIDER_ROLE").as[l1_map_provider_role]

    val l1ProviderRoleRank = loadedDependencies("L1_PROVIDER_ROLE_RANK").as[l1_provider_role_rank]

    val l1EncounterProvider = loadedDependencies("L1_ENCOUNTERPROVIDER").as[l1_encounterprovider]

    val tempProviderCuiSpec = loadedDependencies("TEMP_PROVIDER_CUI_SPEC")

    createTempTosEncProv(sparkSession, l1ClinicalEncounter, l1MapPatientType, l1MapProviderRole, l1ProviderRoleRank, l1EncounterProvider, tempProviderCuiSpec)
  }

  private def createTempTosEncProv(sparkSession: SparkSession,
                                   l1ClinicalEncounter: Dataset[l1_clinicalencounter],
                                   l1MapPatientType: Dataset[l1_map_patient_type],
                                   l1MapProviderRole: Dataset[l1_map_provider_role],
                                   l1ProviderRoleRank: Dataset[l1_provider_role_rank],
                                   l1EncounterProvider: Dataset[l1_encounterprovider],
                                   tempProviderCuiSpec: DataFrame): DataFrame = {
    import sparkSession.implicits._
    import org.apache.spark.sql.functions._

    val cePatient = l1ClinicalEncounter.as("ce")
      .join(l1MapPatientType.as("m"), $"m.client_id" === $"ce.client_id" and $"m.local_code" === $"ce.localpatienttype", "left_outer")
      .select(
        $"ce.client_id", $"ce.mpi", $"ce.encounterid", $"ce.client_ds_id", $"ce.inferred_pat_type", $"m.cui",
        $"ce.arrival_dtm", $"ce.admit_dtm"
      )

    val epRoleRank = l1MapProviderRole.as("mpr")
      .join(l1ProviderRoleRank.as("prr"), $"prr.provider_role_cui" === $"mpr.cui")
      .select($"mpr.local_code", $"prr.rank")


    cePatient.as("cl")
      .join(l1EncounterProvider.as("ep"), $"ep.mpi" === $"cl.mpi" and $"ep.encounterid" === $"cl.encounterid" and $"ep.client_ds_id" === $"cl.client_ds_id", "left_outer")
      .join(tempProviderCuiSpec.as("pi"), $"pi.prov_id" === $"ep.mstrprovid", "left_outer")
      .join(broadcast(epRoleRank).as("err"), $"err.local_code" === $"ep.providerrole", "left_outer")
      .withColumn("encounter_dtm", coalesce($"cl.arrival_dtm", $"cl.admit_dtm"))
      .select(
        $"cl.client_id", $"cl.client_ds_id", $"cl.mpi", $"cl.encounterid",
        coalesce($"cl.inferred_pat_type", $"cl.cui").as("patient_type_cui"),
        $"encounter_dtm",
        $"ep.mstrprovid".as("prov_id"), $"pi.npi",
        $"pi.ii_code".as("spec_code"), $"pi.facility_ind",
        row_number().over(Window.partitionBy($"ep.client_id", $"cl.client_ds_id", $"ep.mpi", $"cl.encounterid").orderBy($"err.rank".asc_nulls_last, $"encounter_dtm".desc_nulls_last, $"ep.mstrprovid".asc_nulls_last)).as("rn")
      )
      .where($"rn" === 1)
      .drop($"rn")
  }

  def directoryLevel: String = "L2"
}

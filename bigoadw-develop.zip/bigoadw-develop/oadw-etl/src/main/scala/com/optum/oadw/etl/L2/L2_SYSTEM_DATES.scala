package com.optum.oadw.etl.L2

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_pat_clinical_event, l2_system_dates, l4_map_cds_grp}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, IntegerType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_SYSTEM_DATES extends TableInfo[l2_system_dates] {
  override def name: String = "L2_SYSTEM_DATES"

  override def dependsOn: Set[String] = Set("L2_PAT_CLINICAL_EVENT", "L4_MAP_CDS_GRP")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2PatClinicalEvent = loadedDependencies("L2_PAT_CLINICAL_EVENT").as[l2_pat_clinical_event]
    val l4MapCdsGrp = loadedDependencies("L4_MAP_CDS_GRP").as[l4_map_cds_grp]

    l2PatClinicalEvent
      .select("client_id", "cds_grp", "evt_start_dtm", "clinical_event_id")
      .join(l4MapCdsGrp, Seq("client_id", "cds_grp"))
      .withColumn("client_ds_id", col("client_ds_id").cast(IntegerType))
      .groupBy("client_id","client_ds_id")
      .agg(
      min(col("evt_start_dtm")).cast(DateType) as "clinical_event_min_dt",
      callUDF("percentile_approx", $"evt_start_dtm", lit(0.25)).cast(DateType).as("clinical_event_perc_25_dt"),
      callUDF("percentile_approx", $"evt_start_dtm", lit(0.50)).cast(DateType).as("clinical_event_perc_50_dt"),
      callUDF("percentile_approx", $"evt_start_dtm", lit(0.75)).cast(DateType).as("clinical_event_perc_75_dt"),
      max(col("evt_start_dtm")).cast(DateType) as "clinical_event_max_dt",
      count(col("clinical_event_id")).cast(IntegerType) as "clinical_event_cnt")
      .select(
        "client_id",
        "client_ds_id",
        "clinical_event_min_dt",
        "clinical_event_perc_25_dt",
        "clinical_event_perc_50_dt",
        "clinical_event_perc_75_dt",
        "clinical_event_max_dt",
        "clinical_event_cnt"
      )
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_marital_status, map_marital_status}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_MARITAL_STATUS extends TableInfo[l1_map_marital_status]{
  override def dependsOn: Set[String] = Set("MAP_MARITAL_STATUS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_MARITAL_STATUS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapMaritalStatus = loadedDependencies("MAP_MARITAL_STATUS").as[map_marital_status]

    mapMaritalStatus
    .select(
			$"groupid".as("client_id"),
			$"local_code",
			$"cui",
			$"dts_version"
    )
  }
}


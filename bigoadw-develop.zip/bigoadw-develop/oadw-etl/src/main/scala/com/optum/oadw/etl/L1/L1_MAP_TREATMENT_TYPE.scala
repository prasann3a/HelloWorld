
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_treatment_type, map_treatment_type}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_TREATMENT_TYPE extends TableInfo[l1_map_treatment_type]{
  override def dependsOn: Set[String] = Set("MAP_TREATMENT_TYPE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_TREATMENT_TYPE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapTreatmentType = loadedDependencies("MAP_TREATMENT_TYPE").as[map_treatment_type]

    mapTreatmentType
    .select(
			$"groupid".as("client_id"),
			$"local_code",
			$"local_unit",
			$"hts_code",
			$"dts_version"
    )
  }
}


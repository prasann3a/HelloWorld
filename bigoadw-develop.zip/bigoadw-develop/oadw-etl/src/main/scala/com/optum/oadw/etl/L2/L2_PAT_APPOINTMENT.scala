package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_pat_appointment
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_PAT_APPOINTMENT extends QueryAndMetadata[l2_pat_appointment] {
  override def name: String = "L2_PAT_APPOINTMENT"

  //   dummy subquery is to concat_ws on collect_list of ordered "appointment_reason" column (max lenght first)
  //   then dummy_2nd subquery is to rank (using ROW_NUMBER()) all concatted "appointment_reason" rows, so we only select rn=1 row later
  //   case statetment is used to remove "; " if it is at the end

  override def sparkSql: String = """
                                   select location_key, prov_id_key, client_id, cds_grp, mpi, appointment_dtm, prov_id, appointment_location,
                                   CASE
                                      WHEN right(appointment_reason, 2) = '; ' THEN substr(left(appointment_reason, length(appointment_reason) -2), 1, 249)
                                      ELSE substr(appointment_reason, 1, 249)
                                   END as appointment_reason
                                   from (
                                   select cast(NVL(appointment_location,'NULL') as string) as location_key, cast(NVL(prov_id,'0') as string) as prov_id_key,
                                   client_id, cds_grp, mpi, appointment_dtm, prov_id, appointment_location,
                                   appointment_reason,
                                   ROW_NUMBER() OVER (PARTITION BY client_id, mpi,appointment_dtm,prov_id,appointment_location ORDER BY length(appointment_reason) DESC, appointment_reason ASC ) as rn
                                   from (
                                   SELECT
a.client_id
,listagg(mcf.client_ds_id) as cds_grp
,a.mpi
,a.appointment_dtm
,concat_ws('; ', COLLECT_LIST(a.appointment_reason) OVER (PARTITION BY a.client_id, a.mpi, a.appointment_dtm, a.mstrprovid, loc.locationname ORDER BY length(a.appointment_reason) DESC, appointment_reason ASC ) ) as appointment_reason
,a.mstrprovid AS prov_id
,loc.locationname AS appointment_location
FROM L1_appointment a
LEFT OUTER JOIN L1_APPT_LOCATION loc on (a.client_id = loc.client_id AND a.client_ds_id = loc.client_ds_id AND a.locationid = loc.locationid)
LEFT OUTER JOIN L2_map_cds_flg mcf on (a.client_id = mcf.client_id AND a.client_ds_id = mcf.client_ds_id)
WHERE a.mpi IS NOT NULL
GROUP BY a.client_id,a.mpi,a.appointment_dtm,a.appointment_reason,a.mstrprovid,loc.locationname) dummy
) dummy_2nd
WHERE rn =1  """

  override def dependsOn: Set[String] = Set("L1_APPOINTMENT","L1_APPT_LOCATION","L2_MAP_CDS_FLG")

  def originalSql: String = """INSERT /*+ APPEND */ INTO L2_pat_appointment (client_id,mpi,appointment_dtm,prov_id,appointment_location)
SELECT /*+ parallel(4) */
         a.client_id
        ,a.mpi
        ,a.appointment_dtm
        ,a.mstrprovid AS prov_id
        ,loc.locationname AS appointment_location
FROM L1_appointment a
LEFT OUTER JOIN L1_APPT_LOCATION loc on (a.client_id = loc.client_id AND a.client_ds_id = loc.client_ds_id AND a.locationid = loc.locationid)
LEFT OUTER JOIN L2_map_cds_flg mcf on (a.client_id = mcf.client_id AND a.client_ds_id = mcf.client_ds_id)
WHERE a.mpi IS NOT NULL
GROUP BY a.client_id,a.mpi,a.appointment_dtm,a.mstrprovid,loc.locationname"""

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_pat_appointment.sql"
}


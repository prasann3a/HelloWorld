
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_bpo_physician_key, pp_bpo_physician_key}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_BPO_PHYSICIAN_KEY extends TableInfo[l1_bpo_physician_key]{
  override def dependsOn: Set[String] = Set("PP_BPO_PHYSICIAN_KEY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_BPO_PHYSICIAN_KEY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("PP_BPO_PHYSICIAN_KEY").as[pp_bpo_physician_key]

    cdrTbl
    .select(
		$"groupid".as("client_id"),
		$"providerid".as("prov_id"),
		$"providerkey",
		$"specialty"
    )
  }
}


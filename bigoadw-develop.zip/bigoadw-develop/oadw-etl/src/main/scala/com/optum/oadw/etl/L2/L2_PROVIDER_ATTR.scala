package com.optum.oadw.etl.L2

import org.apache.spark.sql.functions._
import com.optum.oadw.oadwModels._
import com.optum.oadw.definedfunctions.{BitOrAggFunction, ListAggFunction}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Select client_id, prov_id, cds_grp, attr_cui, attr_value, cast(eff_dt as timestamp) as attr_start_dt, cast(end_dt as timestamp) as attr_end_dt from (
  * select prov.client_id as client_id, prov.eff_dt, prov.end_dt,
  * prov.master_hgprovid as prov_id, listagg(mcf.client_ds_id) as cds_grp, attribute_type_cui as attr_cui,
  * attribute_value as attr_value from l1_prov_attribute prov
  * join l2_map_cds_flg mcf on prov.client_id=mcf.client_id and prov.client_ds_id=mcf.client_ds_id
  * WHERE prov.master_hgprovid is not null
  * AND   prov.attribute_type_cui is not null
  * AND   prov.attribute_value is not null
  * group by prov.client_id,prov.master_hgprovid,prov.attribute_type_cui,prov.attribute_value,prov.eff_dt, prov.end_dt) aa
  */

object L2_PROVIDER_ATTR extends TableInfo[l2_provider_attr] {
  override def name: String = "L2_PROVIDER_ATTR"

  override def dependsOn: Set[String] = Set("L1_PROV_ATTRIBUTE","L2_MAP_CDS_FLG")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1ProvideAttribute = loadedDependencies("L1_PROV_ATTRIBUTE").as[l1_prov_attribute].as("prov")
    val tL2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg].as("mcf")
    val listAgg = ListAggFunction.listAgg

    l1ProvideAttribute
      .where(($"master_hgprovid".isNotNull) && ($"attribute_type_cui".isNotNull) && ($"attribute_value".isNotNull))
      .join(tL2MapCdsFlg, $"prov.client_id" === $"mcf.client_id" && $"prov.client_ds_id" === $"mcf.client_ds_id")
      .groupBy(
        $"prov.client_id",
        $"prov.master_hgprovid",
        $"prov.attribute_type_cui",
        $"prov.attribute_value",
        $"prov.eff_dt",
        $"prov.end_dt")
      .agg(listAgg($"mcf.client_ds_id").as("cds_grp"))
      .select ($"client_id",
        $"master_hgprovid".as("prov_id"),
        $"attribute_type_cui".as("attr_cui"),
        $"attribute_value".as("attr_value"),
        $"cds_grp",
        $"eff_dt".cast(TimestampType).as("attr_start_dt"),
        $"end_dt".cast(TimestampType).as("attr_end_dt")
      )
  }
}
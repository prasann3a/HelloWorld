package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, TimestampType}

object L1_PROCEDUREDO extends TableInfo[l1_proceduredo] {
	override def name: String = "L1_PROCEDUREDO"

  override def dependsOn: Set[String] = Set("PROCEDUREDO")

  protected def createDataFrame(
    sparkSession: SparkSession,
    loadedDependencies: Map[String, DataFrame],
    udfMap: Map[String, UserDefinedFunctionForDataLoader],
    mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL1Proceduredo = loadedDependencies("PROCEDUREDO").as[proceduredo]
    tL1Proceduredo.withColumn("mappedcode", expr(
        """
          CASE
          WHEN codetype = 'REV'
            AND length(regexp_replace(mappedcode,'[^0-9]','') ) = 3 THEN lpad(regexp_replace(mappedcode,'[^0-9]',''),4,'0')
            WHEN codetype = 'REV'
            AND length(regexp_replace(mappedcode,'[^0-9]','') ) = 4 THEN regexp_replace(mappedcode,'[^0-9]','')
            WHEN codetype = 'REV' THEN NULL
              WHEN codetype = 'HCPCS'
            AND substr(upper(mappedcode),1,1) NOT IN (
              'A',
              'B',
              'C',
              'D',
              'E',
              'G',
              'H',
              'J',
              'K',
              'L',
              'M',
              'P',
              'Q',
              'R',
              'S',
              'T',
              'U',
              'V'
            ) THEN NULL
            ELSE upper(mappedcode)
          END AS mappedcode"""))
      .where($"mappedcode".isNotNull)
      .select(
        $"groupid".as("client_id"),
        $"datasrc",
        $"facilityid",
        $"encounterid",
        $"patientid",
        $"sourceid",
        $"performingproviderid",
        $"referproviderid",
        $"proceduredate".cast(TimestampType).as("procedure_dtm"),
        $"localcode",
        $"localname",
        $"codetype",
        $"procseq",
        $"mappedcode",
        $"localbillingproviderid",
        $"orderingproviderid",
        $"client_ds_id",
        $"hgpid",
        $"grp_mpi".as("mpi"),
        $"localprincipleindicator",
        $"hosp_px_flag",
        $"performing_mstrprovid".cast(StringType).as("performing_mstrprovid"),
        $"actualprocdate".cast(TimestampType).as("actualproc_dtm"),
        $"proc_end_date".as("proc_end_dtm"),
        $"orig_mappedcode",
        $"orig_codetype"
    )
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_appt_location, zh_appt_location}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_APPT_LOCATION extends TableInfo[l1_appt_location]{
  override def dependsOn: Set[String] = Set("ZH_APPT_LOCATION")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_APPT_LOCATION"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhApptLocation = loadedDependencies("ZH_APPT_LOCATION").as[zh_appt_location]

    zhApptLocation
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"locationid",
			$"locationname"
    )
  }
}


package com.optum.oadw.etl.L2

import com.optum.oadw.common.models._
import com.optum.oadw.oadwModels.l2_ii_ocu_epi_phm_costs_ext
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.{QueryAndMetadata, RuntimeVariables}

object L2_II_OCU_EPI_PHM_COSTS_EXT extends QueryAndMetadata[l2_ii_ocu_epi_phm_costs_ext] {
  override def name: String = "L2_II_OCU_EPI_PHM_COSTS_EXT"

  override def sparkSql: String =
    """
       SELECT
       MDR.IA_TIME,
       MDR.YEAR_MTH_ID,
       cast(MA.NEW_MEM_ATTR_ID as int) as new_mem_attr_id,
       cast(OS.ETG_ID as long) as ETG_ID,
       OS.SEV_LEVEL,
       E.TX_IND,
       cast(OS.TOS_I_5 as long) as TOS_I_5,
       OS.GBO,
       cast(OS.CHANNEL as long) as CHANNEL,
       OS.FORMULARY,
       E.OUTLIER,
       CASE WHEN e.EPI_TYPE IN (0, 1, 2, 3) THEN 1 ELSE 0 END COMPLETE,
       OS.NETWORK_PAID_STATUS_ID,
       OS.PROVIDER_STATUS_ID,
       cast(SUM(amt_req) as decimal(38, 10)) as amt_req,
       cast(SUM(amt_eqv) as decimal(38, 10)) as amt_eqv,
       cast (SUM(amt_pay) as decimal(38, 10)) as amt_pay,
       cast(SUM(amt_np) as decimal(38, 10)) as amt_np,
       cast(sum(script) as int) as scripts,
       cast(sum(days_sup) as int) as days_sup,
       cast(sum(generic) as int) as generic,
       cast(sum(script_gen) as int) as script_gen
          FROM temp_OCU_RX_SERVICES OS
          INNER JOIN L2_II_EPISODES E ON OS.EPISODE_ID = E.EPISODE_ID
          INNER JOIN TEMP_EPI_MEM_ENROLL ENR ON E.EPISODE_ID = ENR.EPISODE_ID
          INNER JOIN L2_II_MAP_DATE_RANGE MDR ON MDR.MONTH_VAL =  MONTH ( ENR.EPI_DATE) AND MDR.YEAR_VAL = YEAR ( ENR.EPI_DATE)
          INNER JOIN l2_ii_mem_attr_member_ext MA ON ENR.MEMBER = MA.MEMBER AND MDR.YEAR_MTH_ID = MA.YEAR_MTH_ID
          AND MA.MEM_EFF_DT = ENR.MEM_EFF_DT AND MA.MEM_END_DT = ENR.MEM_END_DT AND MA.SUB_EFF_DT = ENR.SUB_EFF_DT
          AND MA.SUB_END_DT = ENR.SUB_END_DT
          inner JOIN (select max(year_mth_id) max_mth from L2_II_MAP_DATE_RANGE) q ON 1=1
          WHERE (MDR.YEAR_MTH_ID BETWEEN (q.MAX_MTH - {{PARM_OCU_MONTHS}}  + 1) AND q.MAX_MTH )
          GROUP BY MDR.IA_TIME, MDR.YEAR_MTH_ID, MA.NEW_MEM_ATTR_ID, OS.ETG_ID, OS.SEV_LEVEL, E.TX_IND, OS.TOS_I_5, OS.GBO, OS.CHANNEL,
          OS.FORMULARY, E.OUTLIER, CASE WHEN e.EPI_TYPE IN (0, 1, 2, 3) THEN 1 ELSE 0 END, OS.NETWORK_PAID_STATUS_ID, OS.PROVIDER_STATUS_ID
    """

  override def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    sparkSql.replaceAll("\\{\\{PARM_OCU_MONTHS\\}\\}", f"${OADWRuntimeVariables(runtimeVariables).parmOcuMonths}")
  }

  override def dependsOn: Set[String] = Set("TEMP_EPI_MEM_ENROLL","L2_II_EPISODES","L2_II_MEM_ATTR_MEMBER_EXT","L2_II_MAP_DATE_RANGE","TEMP_OCU_RX_SERVICES")

  def originalSql: String = """


---pharmacy episode cost and use

insert /*+ append */ into l2_ii_ocu_epi_phm_costs_ext
                (IA_TIME,YEAR_MTH_ID,NEW_MEM_ATTR_ID,ETG_ID,SEV_LEVEL,TX_IND,
                 TOS_I_5,GBO,CHANNEL,FORMULARY,OUTLIER,COMPLETE,NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,
                 amt_req,amt_eqv,amt_pay,amt_np,SCRIPTS,DAYS_SUP,GENERIC,SCRIPT_GEN)
SELECT MDR.IA_TIME, MDR.YEAR_MTH_ID, MA.NEW_MEM_ATTR_ID, OS.ETG_ID, OS.SEV_LEVEL,E.TX_IND, OS.TOS_I_5, OS.GBO,
          OS.CHANNEL, OS.FORMULARY, E.OUTLIER, CASE WHEN e.EPI_TYPE IN (0, 1, 2, 3) THEN 1 ELSE 0 END COMPLETE, OS.NETWORK_PAID_STATUS_ID, OS.PROVIDER_STATUS_ID,
          SUM(amt_req), SUM(amt_eqv), SUM(amt_pay), SUM(amt_np),sum(script) as scripts, sum(days_sup) as days_sup, sum(generic) as generic,
          sum(script_gen) as script_gen
    FROM temp_OCU_RX_SERVICES OS
    INNER JOIN L2_II_EPISODES E ON OS.EPISODE_ID = E.EPISODE_ID
    INNER JOIN TEMP_EPI_MEM_ENROLL ENR ON E.EPISODE_ID = ENR.EPISODE_ID
    INNER JOIN L2_II_MAP_DATE_RANGE MDR ON MDR.MONTH_VAL = extract (MONTH from ENR.EPI_DATE) AND MDR.YEAR_VAL = extract(YEAR from ENR.EPI_DATE)
    INNER JOIN l2_ii_mem_attr_member_ext MA ON ENR.MEMBER = MA.MEMBER AND MDR.YEAR_MTH_ID = MA.YEAR_MTH_ID
           AND MA.MEM_EFF_DT = ENR.MEM_EFF_DT AND MA.MEM_END_DT = ENR.MEM_END_DT AND MA.SUB_EFF_DT = ENR.SUB_EFF_DT
           AND MA.SUB_END_DT = ENR.SUB_END_DT
    inner JOIN (select max(year_mth_id) max_mth from L2_II_MAP_DATE_RANGE) q ON 1=1
    WHERE (MDR.YEAR_MTH_ID BETWEEN (q.MAX_MTH - &PARM_OCU_MONTHS  + 1) AND q.MAX_MTH )
GROUP BY MDR.IA_TIME, MDR.YEAR_MTH_ID, MA.NEW_MEM_ATTR_ID, OS.ETG_ID, OS.SEV_LEVEL, E.TX_IND, OS.TOS_I_5, OS.GBO, OS.CHANNEL,
      OS.FORMULARY, E.OUTLIER, CASE WHEN e.EPI_TYPE IN (0, 1, 2, 3) THEN 1 ELSE 0 END, OS.NETWORK_PAID_STATUS_ID, OS.PROVIDER_STATUS_ID
      """

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("IA_TIME",None,None), OutputColumn("YEAR_MTH_ID",None,None), OutputColumn("NEW_MEM_ATTR_ID",None,None), OutputColumn("ETG_ID",None,None), OutputColumn("SEV_LEVEL",None,None), OutputColumn("TX_IND",None,None), OutputColumn("TOS_I_5",None,None), OutputColumn("GBO",None,None), OutputColumn("CHANNEL",None,None), OutputColumn("FORMULARY",None,None), OutputColumn("OUTLIER",None,None), OutputColumn("COMPLETE",None,None), OutputColumn("NETWORK_PAID_STATUS_ID",None,None), OutputColumn("PROVIDER_STATUS_ID",None,None), OutputColumn("amt_req",None,None), OutputColumn("amt_eqv",None,None), OutputColumn("amt_pay",None,None), OutputColumn("amt_np",None,None), OutputColumn("SCRIPTS",None,None), OutputColumn("DAYS_SUP",None,None), OutputColumn("GENERIC",None,None), OutputColumn("SCRIPT_GEN",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}

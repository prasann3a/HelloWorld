
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patientaddr_summary, patientaddr_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENTADDR_SUMMARY extends TableInfo[l1_patientaddr_summary]{
  override def dependsOn: Set[String] = Set("PATIENTADDR_SUMMARY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENTADDR_SUMMARY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientaddrSummary = loadedDependencies("PATIENTADDR_SUMMARY").as[patientaddr_summary]

    patientaddrSummary
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"grp_mpi".as("mpi"),
			$"address_type",
			$"address_line1",
			$"address_line2",
			$"city",
			$"state",
			$"zipcode",
			$"multiple_values",
			$"record_date".as("record_dtm")
    )
  }
}


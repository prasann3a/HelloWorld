package com.optum.oadw.etl.L3

import java.sql.Timestamp

import com.optum.oadw.etl.models.temp_l3_pat_condition_precursor_individual_common
import com.optum.oadw.oadwModels.{l3_pat_precursor, l4_timeframe, md_oadw_instance, l3_dict_condition_rule}
import com.optum.oadw.oadw_ref.models.{l3_map_cond_precur_rule, l4_dict_condition}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_L3_PAT_CONDITION_INDIVIDUAL_COMMON extends TableInfo[temp_l3_pat_condition_precursor_individual_common]  {


  override def name: String = "TEMP_L3_PAT_CONDITION_INDIVIDUAL_COMMON"

  override def dependsOn: Set[String] = Set("L4_TIMEFRAME", "L3_PAT_PRECURSOR", "L3_DICT_CONDITION_RULE","REFERENCE_SCHEMA_L3_MAP_COND_PRECUR_RULE", "REFERENCE_SCHEMA_L4_DICT_CONDITION", "MD_OADW_INSTANCE")


  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL3PatPrecursor = loadedDependencies("L3_PAT_PRECURSOR").as[l3_pat_precursor]

    val l3DictConditionRule = broadcast(loadedDependencies("L3_DICT_CONDITION_RULE").as[l3_dict_condition_rule])

    val tL3MapConditionPrecurRule = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_COND_PRECUR_RULE").as[l3_map_cond_precur_rule])

    val tL4Dictcond = broadcast(loadedDependencies("REFERENCE_SCHEMA_L4_DICT_CONDITION").as[l4_dict_condition].where($"active_ind" === lit(1)))
    val allTimeFrameStartDtm = broadcast(loadedDependencies("L4_TIMEFRAME").as[l4_timeframe].where($"timeframe_type" === lit("ALL")))
      .select($"start_dt").as[Timestamp].head()

    val dataThruDtm = broadcast(loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]
      .where($"attribute_name" === lit("DATA_THRU")))
      .select(date_add(to_date($"attribute_value", "yyyyMMdd"), 1).as("data_thru_dtm"))
      .as[Timestamp].collect().headOption.get

    // identify the records which are not belongs to family
    val individualPrecursors = l3DictConditionRule.as("dcr").where($"precursor_family_cnt".isNull)

    //for exclusion added - 365 days extra in the timerange
    val commonDF=tL3PatPrecursor.as("p").where(($"p.precursor_dtm").lt(dataThruDtm) and date_trunc("DD", $"p.precursor_dtm").geq(lit(Timestamp.valueOf(allTimeFrameStartDtm.toLocalDateTime.plusDays(-365)))))
      .join(tL3MapConditionPrecurRule.as("mcpr"), $"p.precursor_id" === $"mcpr.precursor_id", "inner")
      .join(individualPrecursors.as("idcr"), $"mcpr.condition_id" === $"idcr.condition_id" and $"mcpr.rule_id" === $"idcr.rule_id" , "inner")
      .join(tL4Dictcond.as("dc"), $"mcpr.condition_id" === $"dc.condition_id", "inner").select($"p.client_id", $"p.mpi" ,$"mcpr.condition_id",$"mcpr.rule_id",
      $"mcpr.precursor_id",$"p.precursor_dtm", $"p.precursor_domain",
      $"p.precursor_type",$"p.precursor_cds_grp",
      $"p.precursor_value",$"p.precursor_modifier_flg", $"p.sensitive_ind".as("sensitive_ind_precur"),$"idcr.sensitive_ind".as("sensitive_ind_dc"),
      $"mcpr.precursor_cnt",$"mcpr.precursor_cnt_min_days",$"mcpr.precursor_cnt_max_days").withColumn("final_sensitive_ind",
      greatest($"sensitive_ind_precur", $"sensitive_ind_dc")).
      drop("sensitive_ind_dc").withColumnRenamed("final_sensitive_ind","sensitive_ind")

    commonDF
  }
  }

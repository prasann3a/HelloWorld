
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ref_hcpcs_specialty_med, ref_hcpcs_specialty_med_curr}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object L1_REF_HCPCS_SPECIALTY_MED extends TableInfo[l1_ref_hcpcs_specialty_med]{
  override def dependsOn: Set[String] = Set("REF_HCPCS_SPECIALTY_MED_CURR")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_REF_HCPCS_SPECIALTY_MED"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val refHcpcsSpecialtyMedCurr = loadedDependencies("REF_HCPCS_SPECIALTY_MED_CURR").as[ref_hcpcs_specialty_med_curr]

    refHcpcsSpecialtyMedCurr
    .select(
			$"procedurecode".as("procedure_code"),
			$"fulldescription".as("long_description"),
			$"dcc",
			when(lower($"isspecialtydrug").isin("1","true"),"1")
        .otherwise("0").as("specialty_ind")
    )
  }
}


package com.optum.oadw.etl.L2
import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.definedfunctions.{BitOrAggFunction, ListAggFunction}
import com.optum.oadw.oadw_ref.models.l3_map_proc_etg_elig
import org.apache.spark.sql.functions.{lit, least}
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_L2_PAT_ACTIVITY_MONTH_DIAG extends TableInfo[l2_pat_activity_month] {
  override def name: String = "TEMP_L2_PAT_ACTIVITY_MONTH_DIAG"

  override def dependsOn: Set[String] = Set("L2_PAT_DIAG")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatDiag = loadedDependencies("L2_PAT_DIAG").as[l2_pat_diag].alias("tL2PatDiag")
    tL2PatDiag
      .groupBy($"client_id", $"mpi", date_format($"diag_dt", "yyyyMM").cast(IntegerType).as("activity_yr_month"))
      .agg(
        ListAggFunction.listAgg($"cds_grp").as("cds_grp"),
        lit("DIAG").as("activity_type_cd"),
        countDistinct(to_date(date_format($"diag_dt", "yyyy-MM-dd"))).cast(IntegerType).as("activity_count"))
  }
}

object TEMP_L2_PAT_ACTIVITY_MONTH_MED extends TableInfo[l2_pat_activity_month] {
  override def name: String = "TEMP_L2_PAT_ACTIVITY_MONTH_MED"

  override def dependsOn: Set[String] = Set("L2_PAT_MED")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatMed = loadedDependencies("L2_PAT_MED").as[l2_pat_med].alias("tL2PatMed")
    tL2PatMed
      .groupBy($"client_id", $"mpi", date_format($"rx_dtm", "yyyyMM").cast(IntegerType).as("activity_yr_month"))
      .agg(
        ListAggFunction.listAgg($"cds_grp").as("cds_grp"),
        lit("MED").as("activity_type_cd"),
        countDistinct(to_date(date_format($"rx_dtm", "yyyy-MM-dd"))).cast(IntegerType).as("activity_count"))
  }
}

object TEMP_L2_PAT_ACTIVITY_MONTH_PROC extends TableInfo[l2_pat_activity_month] {
  override def name: String = "TEMP_L2_PAT_ACTIVITY_MONTH_PROC"

  override def dependsOn: Set[String] = Set("L2_PAT_PROC")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatProc = loadedDependencies("L2_PAT_PROC").as[l2_pat_proc].alias("tL2PatProc")
    tL2PatProc
      .groupBy($"client_id", $"mpi", date_format($"proc_dtm", "yyyyMM").cast(IntegerType).as("activity_yr_month"))
      .agg(
        ListAggFunction.listAgg($"cds_grp").as("cds_grp"),
        lit("PROC").as("activity_type_cd"),
        countDistinct(to_date(date_format($"proc_dtm", "yyyy-MM-dd"))).cast(IntegerType).as("activity_count"))
  }
}

object TEMP_L2_PAT_ACTIVITY_MONTH_MICROBIO extends TableInfo[l2_pat_activity_month] {
  override def name: String = "TEMP_L2_PAT_ACTIVITY_MONTH_MICROBIO"

  override def dependsOn: Set[String] = Set("L2_PAT_MICROBIO")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatMicrobio = loadedDependencies("L2_PAT_MICROBIO").as[l2_pat_microbio].alias("tL2PatMicrobio")
    tL2PatMicrobio
      .groupBy($"client_id", $"mpi", date_format($"result_dtm", "yyyyMM").cast(IntegerType).as("activity_yr_month"))
      .agg(
        ListAggFunction.listAgg($"cds_grp").as("cds_grp"),
        lit("MICROBIO").as("activity_type_cd"),
        countDistinct(to_date(date_format($"result_dtm", "yyyy-MM-dd"))).cast(IntegerType).as("activity_count"))
  }
}

object TEMP_L2_PAT_ACTIVITY_MONTH_ASSESSMENT extends TableInfo[l2_pat_activity_month] {
  override def name: String = "TEMP_L2_PAT_ACTIVITY_MONTH_ASSESSMENT"

  override def dependsOn: Set[String] = Set("L2_PAT_ASSESS_NUM", "L2_PAT_ASSESS_QUAL")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val patAssessNum = loadedDependencies("L2_PAT_ASSESS_NUM").alias("patAssessNum")
    val patAssessQual = loadedDependencies("L2_PAT_ASSESS_QUAL").alias("patAssessQual")
    val unionAssess = patAssessNum.select($"client_id", $"mpi", $"cds_grp", $"assessment_dtm").union(patAssessQual.select($"client_id", $"mpi", $"cds_grp", $"assessment_dtm")).distinct()
    unionAssess
      .groupBy($"client_id", $"mpi", date_format($"assessment_dtm", "yyyyMM").cast(IntegerType).as("activity_yr_month"))
      .agg(
        ListAggFunction.listAgg($"cds_grp").as("cds_grp"),
        lit("ASSESS").as("activity_type_cd"),
        countDistinct(to_date(date_format($"assessment_dtm", "yyyy-MM-dd"))).cast(IntegerType).as("activity_count")
      )
  }
}

object TEMP_L2_PAT_ACTIVITY_MONTH_QUAL_EVENT extends TableInfo[l2_pat_activity_month] {
  override def name: String = "TEMP_L2_PAT_ACTIVITY_MONTH_QUAL_EVENT"

  override def dependsOn: Set[String] = Set("L2_PAT_CLINICAL_EVENT", "L2_PAT_PROC", "L3_MAP_PROC_ETG_ELIG")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val clinicalEvent = loadedDependencies("L2_PAT_CLINICAL_EVENT").as[l2_pat_clinical_event].alias("clinicalEvent")
    val patProc = loadedDependencies("L2_PAT_PROC").as[l2_pat_proc].alias("patProc")
    val mapProcEtgElig = loadedDependencies("L3_MAP_PROC_ETG_ELIG").as[l3_map_proc_etg_elig].alias("mapProcEtgElig")

    val groupedEvent = clinicalEvent
      .groupBy($"client_id", $"mpi", date_format($"evt_start_dtm", "yyyyMM").cast(IntegerType).as("activity_yr_month"))
      .agg(
        ListAggFunction.listAgg($"cds_grp").as("cds_grp"),
        countDistinct($"clinical_event_id").cast(IntegerType).as("activity_count"),
        countDistinct(when($"etg_qual_evt_ind" === lit(1), $"clinical_event_id").otherwise(null)).as("qual_evt_cnt")
      )

    val eligProcsForQualevt = patProc.as("pc")
      .join(mapProcEtgElig.as("mpee"), $"pc.proc_cd" === $"mpee.proc_cd" && $"pc.code_type" === $"mpee.code_type", "inner")
      .select($"pc.client_id", $"pc.mpi", $"pc.cds_grp", date_format($"pc.proc_dtm", "yyyyMM").cast(IntegerType).as("activity_yr_month"), to_date(date_format($"pc.proc_dtm", "yyyy-MM-dd")).as("activity_date"), $"pc.prov_id")
      .distinct

    val datesWithMultipleProv =
      eligProcsForQualevt.
        groupBy($"activity_date", $"mpi").agg(
        countDistinct($"prov_id").as("prov_count")
      ).where($"prov_count">1)
      .select(
        $"mpi".as("dmp_mpi"),
        $"activity_date".as("dmp_activity_date")
      )

    val qualEvent =
      eligProcsForQualevt.as("ep")
        .join(datesWithMultipleProv.as("dmp"), $"ep.activity_date" === $"dmp.dmp_activity_date"  && $"ep.mpi"===$"dmp.dmp_mpi", "left")
        .where(($"prov_id" =!= 0 && $"dmp.dmp_activity_date".isNotNull) ||  $"dmp.dmp_activity_date".isNull)
        .groupBy($"client_id", $"mpi", $"activity_yr_month")
        .agg(
          ListAggFunction.listAgg($"cds_grp").as("cds_grp"),
          lit("QUALEVT").as("activity_type_cd"),
          countDistinct($"ep.activity_date", $"prov_id").cast(IntegerType).as("activity_count")
        )

    val regularEvent = groupedEvent
      .select(
        $"client_id",
        $"mpi",
        $"activity_yr_month",
        $"cds_grp",
        lit("EVENT").as("activity_type_cd"),
        $"activity_count".cast(IntegerType).as("activity_count")
      )
    qualEvent.union(regularEvent)
  }
}

object TEMP_L2_PAT_ACTIVITY_MONTH_PAYOR extends TableInfo[l2_pat_activity_month] {
  override def name: String = "TEMP_L2_PAT_ACTIVITY_MONTH_PAYOR"

  override def dependsOn: Set[String] = Set("L2_II_MEM_ENROLL_CONTRACT", "L2_II_MAP_DATE_RANGE", "L2_II_MAP_CONTRACT", "L2_MAP_CDS_FLG")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val iiEnroll = loadedDependencies("L2_II_MEM_ENROLL_CONTRACT").where($"PCP_ID".isNotNull).as[l2_ii_mem_enroll_contract].alias("iiEnroll")
    val iiDate = loadedDependencies("L2_II_MAP_DATE_RANGE").as[l2_ii_map_date_range].alias("iiDate")
    val mapContract = loadedDependencies("L2_II_MAP_CONTRACT").as[l2_ii_map_contract].alias("mapContract")
    val tl2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg].alias("tl2MapCdsFlg")

    iiEnroll
      .join(iiDate, expr("cast(iiDate.yr_month as INT) between cast(date_format(iiEnroll.eff_dt, 'yyyyMM') as INT) and cast(date_format(iiEnroll.end_dt, 'yyyyMM') as INT)"))
      .join(mapContract, mapContract("contract_id") === iiEnroll("contract_id"))
      .join(tl2MapCdsFlg, tl2MapCdsFlg("client_ds_id") === mapContract("client_ds_id"))
      .where((iiEnroll("rx") === lit(true) || iiEnroll("med") === lit(true)) && length(iiEnroll("member")) <= lit(20))
      .groupBy(
        tl2MapCdsFlg("client_id"),
        iiEnroll("member").as("mpi"),
        iiDate("yr_month").cast(IntegerType).as("activity_yr_month")
      )
      .agg(
        ListAggFunction.listAgg(tl2MapCdsFlg("client_ds_id")).as("cds_grp"),
        lit("PYR_PCP").as("activity_type_cd"),
        lit(1).cast(IntegerType).as("activity_count")
      )
  }
}

object TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK extends TableInfo[l2_pat_activity_month] {
  override def name: String = "TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK"

  override def dependsOn: Set[String] = Set("L2_II_MEM_ENROLL_CONTRACT", "L2_II_MAP_DATE_RANGE", "L2_II_MAP_CONTRACT", "L2_MAP_CDS_FLG")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val iiEnroll = loadedDependencies("L2_II_MEM_ENROLL_CONTRACT").as[l2_ii_mem_enroll_contract].alias("iiEnroll")
    val iiDate = loadedDependencies("L2_II_MAP_DATE_RANGE").as[l2_ii_map_date_range].alias("iiDate")
    val mapContract = loadedDependencies("L2_II_MAP_CONTRACT").as[l2_ii_map_contract].alias("mapContract")
    val tl2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg].alias("tl2MapCdsFlg")

    val groupedDataSet = iiEnroll
      .join(iiDate, expr("cast(iiDate.yr_month as INT) between cast(date_format(iiEnroll.eff_dt, 'yyyyMM') as INT) and cast(date_format(iiEnroll.end_dt, 'yyyyMM') as INT)"))
      .join(mapContract, mapContract("contract_id") === iiEnroll("contract_id"))
      .join(tl2MapCdsFlg, tl2MapCdsFlg("client_ds_id") === mapContract("client_ds_id"))
        .where((iiEnroll("rx") === lit(true) || iiEnroll("med") === lit(true)) && length(iiEnroll("member")) <= lit(20))
      .groupBy(
        tl2MapCdsFlg("client_id"),
        iiEnroll("member").as("mpi"),
        iiDate("yr_month").cast(IntegerType).as("activity_yr_month")
      ).agg(
      ListAggFunction.listAgg(tl2MapCdsFlg("client_ds_id")).as("cds_grp"),
      max(iiEnroll("rx")).as("rx"),
      max(iiEnroll("med")).as("med"),
      max(when(iiEnroll("at_risk_status_id").isin("Y", concat(lit("Y$"), iiEnroll("map_srce_e"))), lit(1)).otherwise(lit(0))).as("at_risk"),
      lit(1).cast(IntegerType).as("activity_count")
    )

    val atRisk = groupedDataSet.where($"at_risk" === lit(1))
      .select(
        $"client_id",
        $"mpi",
        $"activity_yr_month",
        $"cds_grp",
        lit("ATRISK").as("activity_type_cd"),
        $"activity_count".cast(IntegerType).as("activity_count")
      )

    val remainingData = groupedDataSet
      .select(
        $"client_id",
        $"mpi",
        $"activity_yr_month",
        $"cds_grp",
        when($"rx" === lit(true) and $"med" === lit(true), lit("ELIG_ALL"))
          .when($"med" === lit(true), lit("ELIG_MED"))
          .when($"rx" === lit(true), lit("ELIG_RX")).as("activity_type_cd"),
        $"activity_count".cast(IntegerType).as("activity_count")
      )
    atRisk.union(remainingData)
  }
}

object TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK_NON_II extends TableInfo[l2_pat_activity_month] {
  override def name: String = "TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK_NON_II"

  override def dependsOn: Set[String] = Set("TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK", "CALENDAR", "L1_PAT_RISK_ATTRIB", "MD_OADW_INSTANCE", "L2_MAP_CDS_FLG")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatActivityMonthAtRisk = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK").alias("tL2PatActivityMonthAtRisk")
    val tl2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg].alias("tl2MapCdsFlg")
    val calendar = loadedDependencies("CALENDAR").alias("calendar")
    val l1PatRiskAttrib = loadedDependencies("L1_PAT_RISK_ATTRIB").as[l1_pat_risk_attrib].alias("l1PatRiskAttrib")
    val mdInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance].alias("mdInstance")

    val calLevel = calendar.select($"SERIAL_NUM".as("level"))
    val mdInstanceDate = mdInstance.select(to_date(from_unixtime(unix_timestamp($"ATTRIBUTE_VALUE", "yyyyMMdd"))).as("end_dt")).where($"attribute_name" === lit("DATA_THRU"))
    val crossedDataTemp = mdInstanceDate.crossJoin(calLevel)
      .where($"level" <= months_between($"end_dt", expr("to_date(from_unixtime(unix_timestamp('20060101', 'yyyyMMdd')))"))).alias("crossedTemp")
    val crossedData = crossedDataTemp
      .withColumn("month_st", expr("add_months(to_date(from_unixtime(unix_timestamp('20060101', 'yyyyMMdd'))), crossedTemp.level - 1)"))
      .select($"month_st", date_format($"month_st", "yyyyMM").as("yr_month")).alias("crossedData")

    l1PatRiskAttrib
      .join(crossedData, expr("crossedData.month_st between to_date(date_format(l1PatRiskAttrib.start_dt, 'yyyy-MM-dd')) and to_date(date_format(l1PatRiskAttrib.end_dt, 'yyyy-MM-dd'))"))
        .join(tl2MapCdsFlg, l1PatRiskAttrib("client_ds_id") === tl2MapCdsFlg("client_ds_id"))
      .join(tL2PatActivityMonthAtRisk, tL2PatActivityMonthAtRisk("client_id") === l1PatRiskAttrib("client_id") &&
      l1PatRiskAttrib("mpi") === tL2PatActivityMonthAtRisk("mpi") && crossedData("yr_month") === tL2PatActivityMonthAtRisk("activity_yr_month") &&
      tL2PatActivityMonthAtRisk("activity_type_cd") === lit("ATRISK"), "leftouter")
      .where(tL2PatActivityMonthAtRisk("mpi").isNull && l1PatRiskAttrib("mpi").isNotNull)
      .groupBy(
        l1PatRiskAttrib("client_id"),
        l1PatRiskAttrib("mpi"),
        crossedData("yr_month").cast(IntegerType).as("activity_yr_month")
      ).agg(
      ListAggFunction.listAgg(tl2MapCdsFlg("client_ds_id")).as("cds_grp"),
      lit("ATRISK").as("activity_type_cd"),
      lit(1).cast(IntegerType).as("activity_count")
    )
  }
}

object L2_PAT_ACTIVITY_MONTH extends TableInfo[l2_pat_activity_month] {
  override def name: String = "L2_PAT_ACTIVITY_MONTH"

  override def dependsOn: Set[String] = Set("TEMP_L2_PAT_ACTIVITY_MONTH_DIAG", "TEMP_L2_PAT_ACTIVITY_MONTH_MED", "TEMP_L2_PAT_ACTIVITY_MONTH_PROC",
  "TEMP_L2_PAT_ACTIVITY_MONTH_MICROBIO", "TEMP_L2_PAT_ACTIVITY_MONTH_ASSESSMENT", "TEMP_L2_PAT_ACTIVITY_MONTH_QUAL_EVENT", "TEMP_L2_PAT_ACTIVITY_MONTH_PAYOR",
  "TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK", "TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK_NON_II")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val monthDiag = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_DIAG").alias("monthDiag")
    val monthMed = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_MED").alias("monthMed")
    val monthProc = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_PROC").alias("monthProc")
    val monthMicrobio = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_MICROBIO").alias("monthMicrobio")
    val monthAssess = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_ASSESSMENT").alias("monthAssess")
    val monthQual = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_QUAL_EVENT").alias("monthQual")
    val monthPayor = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_PAYOR").alias("monthPayor")
    val monthRisk = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK").alias("monthRisk")
    val monthRiskII = loadedDependencies("TEMP_L2_PAT_ACTIVITY_MONTH_AT_RISK_NON_II").alias("monthRiskII")

    monthDiag
      .union(monthMed)
      .union(monthProc)
      .union(monthMicrobio)
      .union(monthAssess)
      .union(monthQual)
      .union(monthPayor)
      .union(monthRisk)
      .union(monthRiskII)
      .select(
        least($"activity_count", lit(9999)).cast(IntegerType).as("activity_count"),
        $"activity_type_cd",
        $"activity_yr_month",
        $"cds_grp",
        $"client_id",
        $"mpi"
      )
  }
}

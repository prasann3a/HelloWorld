package com.optum.oadw.etl.L3

import java.sql.Timestamp
import com.optum.oadw.definedfunctions.BitOrAgg
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

/**
 * *
 * SELECT  a.client_id
 * ,b.precursor_id
 * ,a.mpi
 * ,a.assessment_dtm
 * ,a.assessment_cui
 * ,a.numeric_value
 * ,a.cds_grp
 * ,CASE WHEN a.nlp_ind = 0
 * THEN (SELECT precursor_modifier_flg
 * FROM L3_map_precursor_modifier
 * WHERE precursor_modifier_cui = 'CH003541')
 * ELSE 0
 * END
 * + CASE WHEN a.nlp_ind = 2
 * THEN (SELECT precursor_modifier_flg
 * FROM L3_map_precursor_modifier
 * WHERE precursor_modifier_cui = 'CH003542')
 * ELSE 0
 * END
 * + CASE WHEN a.nlp_ind = 1   -- Structured+Unstructured
 * THEN (SELECT bitoragg(precursor_modifier_flg)
 * FROM L3_map_precursor_modifier
 * WHERE precursor_modifier_cui IN ('CH003541','CH003542') )
 * ELSE 0
 * END AS nlp_new
 * ,GREATEST(a.sensitive_ind, dp.sensitive_ind) AS sensitive_ind
 * FROM L2_pat_assess_num a
 * INNER JOIN L3_map_precursor_assess_cui b ON (a.assessment_cui = b.assess_cui)
 * INNER JOIN L3_dict_precursor dp ON (dp.precursor_id = b.precursor_id)
 * WHERE -- b.assess_cui IN ('CH001151', 'CH001152') AND
 * ((b.lower_bound IS NOT NULL AND b.upper_bound IS NOT NULL AND a.numeric_value BETWEEN b.lower_bound AND b.upper_bound)
 * OR (b.lower_bound IS NULL AND b.upper_bound IS NOT NULL AND a.numeric_value <= b.upper_bound)
 * OR (b.lower_bound IS NOT NULL AND b.upper_bound IS NULL AND a.numeric_value >= b.lower_bound)
 * OR (b.lower_bound IS NULL AND b.upper_bound IS NULL AND b.qualitative_val IS NULL)
 * )
 * AND  (    (b.exclude_hosp_ind = 0)
 * OR (b.exclude_hosp_ind = 1 AND a.hosp_ind = 0 )
 * )
 * AND   dp.active_ind = 1
 *
 */

case class temp_pat_precurs_s1_data(client_id: String, precursor_id: java.lang.Integer, mpi: String, assessment_dtm: Timestamp,
                                    assessment_cui: String, numeric_value: java.lang.Double,
                                    cds_grp: String, nlp_new: java.lang.Integer, sensitive_ind: java.lang.Integer)

object TEMP_PAT_PRECURS_S1 extends TableInfo[temp_pat_precurs_s1_data] {
  override def name: String = "TEMP_PAT_PRECURS_S1"

  override def dependsOn: Set[String] =
    Set(
      "L2_PAT_ASSESS_NUM",
      "L3_MAP_PRECURSOR_ASSESS_CUI",
      "L3_DICT_PRECURSOR",
      "L3_MAP_PRECURSOR_MODIFIER"
    )

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL2PatAssessNum = loadedDependencies("L2_PAT_ASSESS_NUM")
    val l3MapPrecursorAssessCui = broadcast(loadedDependencies("L3_MAP_PRECURSOR_ASSESS_CUI"))
    val tL3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").where($"active_ind" === lit(1)))
    val tL3MapPrecursorModifier = broadcast(loadedDependencies("L3_MAP_PRECURSOR_MODIFIER").where($"precursor_modifier_cui".isin("CH003541","CH003542")))

    val bitoragg = new BitOrAgg()

    val precursorModifierFlg3541 = try {
      tL3MapPrecursorModifier.where($"precursor_modifier_cui" === lit("CH003541")).select($"precursor_modifier_flg").collect.head.getInt(0)
    } catch {
      case e: Exception => throw new IllegalStateException("Error: Table L3_MAP_PRECURSOR_MODIFIER missing row for CUI CH003541")
    }

    val precursorModifierFlg3542 = try {
      tL3MapPrecursorModifier.where($"precursor_modifier_cui" === lit("CH003542")).select($"precursor_modifier_flg").collect.head.getInt(0)
    } catch {
      case e: Exception => throw new IllegalStateException("Error: Table L3_MAP_PRECURSOR_MODIFIER missing row for CUI CH003542")
    }

    val precursorModifierFlgBitoragg = try {
      tL3MapPrecursorModifier.select(bitoragg($"precursor_modifier_flg")).collect.head.getInt(0)
    } catch {
      case e: Exception => throw new IllegalStateException("Error: Table L3_MAP_PRECURSOR_MODIFIER missing rows for CUI CH003541 and CH003542")
    }

    tL2PatAssessNum.as("a")
      .join(l3MapPrecursorAssessCui.as("b"), $"a.assessment_cui" === $"b.assess_cui", "inner")
      .where(
        (      ($"b.lower_bound".isNotNull && $"b.upper_bound".isNotNull && $"a.numeric_value" >= $"b.lower_bound" && $"a.numeric_value" <= $"b.upper_bound")
          || ($"b.lower_bound".isNull && $"b.upper_bound".isNotNull && $"a.numeric_value" <= $"b.upper_bound")
          || ($"b.lower_bound".isNotNull && $"b.upper_bound".isNull && $"a.numeric_value" >= $"b.lower_bound")
          || ($"b.lower_bound".isNull && $"b.upper_bound".isNull && $"b.qualitative_val".isNull)
          )
          &&
          (
            ($"b.exclude_hosp_ind" === lit(0)) || ( $"b.exclude_hosp_ind" === lit(1) && $"a.hosp_ind" === lit(0) )
            )
      )
      .join(tL3DictPrecursor.as("dp"), $"dp.precursor_id" === $"b.precursor_id", "inner")
      .select($"a.client_id", $"b.precursor_id", $"a.mpi", $"a.assessment_dtm", $"a.assessment_cui", $"a.numeric_value", $"a.cds_grp",
        (when($"a.nlp_ind" === lit(0), precursorModifierFlg3541)
          .otherwise(lit(0)).as("n1")
          + when($"a.nlp_ind" === lit(2), precursorModifierFlg3542)
          .otherwise(lit(0)).as("n2")
          + when($"a.nlp_ind" === lit(1), precursorModifierFlgBitoragg)
          .otherwise(lit(0)).as("n0")
          ).as("nlp_new"),
        greatest($"a.sensitive_ind", $"dp.sensitive_ind").as("sensitive_ind")
      )
      .toDF()
  }
}
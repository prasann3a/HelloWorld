package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_elig_contract
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_ELIG_CONTRACT extends QueryAndMetadata[l2_elig_contract] {
  override def name: String = "L2_ELIG_CONTRACT"

  override def sparkSql: String = """
      with t as (
        select distinct month_date, Year_Mth_Id
        from L2_II_MAP_DATE_RANGE
      )
      Select contract_id,mem_userdef_1_id,at_risk_status_id,
        case when med = true then 1 when med = false then 0 else null end as med,
        case when rx = true then 1 when rx = false then 0 else null end as rx,
        pcp_id as pcp_assign,member,t.Year_Mth_Id
      From L2_II_MEM_ENROLL_CONTRACT mbr, t
      where t.month_date between mbr.eff_dt AND mbr.end_dt
  """.stripMargin

  override def dependsOn: Set[String] = Set("L2_II_MEM_ENROLL_CONTRACT","L2_II_MAP_DATE_RANGE")

  def originalSql: String = """INSERT /*+ append */ INTO L2_elig_contract(contract_id,mem_userdef_1_id,med,rx,pcp_assign,member,year_mth_id)
 SELECT contract_id,mem_userdef_1_id,med,rx,pcp_id,member,Dt.Year_Mth_Id
 FROM L2_II_MEM_ENROLL_CONTRACT mbr
 JOIN L2_II_MAP_DATE_RANGE dt ON month_date BETWEEN eff_dt AND end_dt
 """

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(
    OutputColumn("contract_id",None,None),
    OutputColumn("mem_userdef_1_id",None,None),
    OutputColumn("at_risk_status_id",None,None),
    OutputColumn("med",None,None),
    OutputColumn("rx",None,None),
    OutputColumn("pcp_assign",None,None),
    OutputColumn("member",None,None),
    OutputColumn("year_mth_id",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_elig_contract_build.sql"
}

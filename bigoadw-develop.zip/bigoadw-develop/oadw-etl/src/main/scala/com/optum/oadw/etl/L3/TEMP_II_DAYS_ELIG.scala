package com.optum.oadw.etl.L3


import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_ii_days_elig_data(member: String, conf_num: java.lang.Long, days_elig: java.lang.Long)

object TEMP_II_DAYS_ELIG extends QueryAndMetadata[temp_ii_days_elig_data] {
  override def name: String = "TEMP_II_DAYS_ELIG"

  override def sparkSql: String = """SELECT idx.member,idx.conf_num
,sum(CASE WHEN idx.end_dt BETWEEN mem.eff_dt AND mem.end_dt THEN datediff(mem.end_dt, idx.end_dt) ELSE datediff(mem.end_dt, mem.eff_dt) + 1 END) AS days_elig
FROM L2_II_CONFINEMENTS idx
inner join L2_II_MEM_ENROLL mem ON (idx.member = mem.member and mem.end_dt >= idx.end_dt)
LEFT OUTER JOIN temp_ii_gap_elig gap ON idx.conf_num = gap.conf_num
where (elig_end_dt IS NULL OR mem.end_dt <= elig_end_dt)
GROUP BY idx.member,idx.conf_num"""

  override def dependsOn: Set[String] = Set("L2_II_CONFINEMENTS","L2_II_MEM_ENROLL","TEMP_II_GAP_ELIG")

  def originalSql: String = """
--number of eligible days of coverage after the confinement
create table temp_ii_days_elig pctfree 0 nologging AS
SELECT idx.member,idx.conf_num
,sum(CASE WHEN idx.end_dt BETWEEN mem.eff_dt AND mem.end_dt THEN mem.end_dt - idx.end_dt ELSE mem.end_dt - mem.eff_dt + 1 END) AS days_elig
FROM L2_II_CONFINEMENTS idx
 inner join L2_II_MEM_ENROLL mem ON (idx.member = mem.member and mem.end_dt >= idx.end_dt)
LEFT OUTER JOIN temp_ii_gap_elig gap ON idx.conf_num = gap.conf_num
where (elig_end_dt IS NULL OR mem.end_dt <= elig_end_dt)
GROUP BY idx.member,idx.conf_num
"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L3"





  val originalSqlFileName: String = "L3_event_readmission_build.sql"
}

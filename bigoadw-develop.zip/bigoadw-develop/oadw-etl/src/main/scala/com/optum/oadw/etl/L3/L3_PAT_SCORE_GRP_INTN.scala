package com.optum.oadw.etl.L3


import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadw_ref.models.l3_map_score_grp_intn_hier
import com.optum.oadw.oadwModels.l3_pat_score_grp_intn
import org.apache.spark.sql.{DataFrame, SparkSession}

object L3_PAT_SCORE_GRP_INTN extends TableInfo[l3_pat_score_grp_intn] {
  override def name: String = "L3_PAT_SCORE_GRP_INTN"

  override def dependsOn: Set[String] = Set("TEMP_PAT_SCORE_GRP_INTN_3","L3_MAP_SCORE_GRP_INTN_HIER", "TEMP_PAT_SCORE_GRP_INTN_CNT")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    /**
    SELECT psi.* FROM temp_pat_score_grp_intn_3 psi
      */
    val tempPatScoreGrpIntn3 = loadedDependencies("TEMP_PAT_SCORE_GRP_INTN_3")
    val tL3MapScoreGrpIntnHier = loadedDependencies("L3_MAP_SCORE_GRP_INTN_HIER").as[l3_map_score_grp_intn_hier]
    val tempPatScoreGrpIntnCnt = loadedDependencies("TEMP_PAT_SCORE_GRP_INTN_CNT")

    /**
      SELECT e1.*
      FROM L3_MAP_SCORE_GRP_INTN_HIER hier
      INNER JOIN temp_pat_score_grp_intn_3 e1 ON (hier.GRP_ID=e1.GRP_ID AND hier.INTERACTION_ID_EXCLUDE=e1.INTERACTION_ID)
      INNER JOIN temp_pat_score_grp_intn_3 e2 ON (hier.GRP_ID=e2.GRP_ID
      AND hier.INTERACTION_ID_EXISTS=e2.INTERACTION_ID
      AND e2.CLIENT_ID=e1.CLIENT_ID
      AND e2.MPI=e1.MPI
      AND e2.GRP_ID=e1.GRP_ID
      AND e2.TIMEFRAME_ID=e1.TIMEFRAME_ID
      AND e2.ELIG_CDS_ID=e1.ELIG_CDS_ID
      */
    val tempIntnDf = tempPatScoreGrpIntn3.union(tempPatScoreGrpIntnCnt)

    val subtract_df = tL3MapScoreGrpIntnHier.as("hier")
      .join(tempIntnDf.as("e1"), $"hier.GRP_ID" === $"e1.GRP_ID" and $"hier.INTERACTION_ID_EXCLUDE" === $"e1.INTERACTION_ID")
      .join(tempIntnDf.as("e2"), $"hier.GRP_ID" === $"e2.GRP_ID" and $"hier.INTERACTION_ID_EXISTS" === $"e2.INTERACTION_ID"
        and $"e2.CLIENT_ID" === $"e1.CLIENT_ID" and $"e2.MPI" === $"e1.MPI" and $"e2.GRP_ID" === $"e1.GRP_ID" and $"e2.TIMEFRAME_ID" === $"e1.TIMEFRAME_ID"
        and $"e2.ELIG_CDS_ID" === $"e1.ELIG_CDS_ID")
      .select("e1.*")

    tempIntnDf.except(subtract_df).select(
      $"client_id",
      $"mpi",
      $"grp_id",
      $"timeframe_id",
      $"elig_cds_id",
      $"interaction_id",
      $"coef_multiplier",
      $"sensitive_ind"
    )
  }

  val originalSql: String =
    """
      INSERT /*+ APPEND */ INTO L3_pat_score_grp_intn (client_id, mpi, grp_id, timeframe_id, elig_cds_id, interaction_id, coef_multiplier, sensitive_ind)
      SELECT /*+ parallel(4) */ psi.*
        FROM temp_pat_score_grp_intn_3 psi
      MINUS --applies interaction severity hierarchy rules
      (SELECT e1.*
         FROM L3_MAP_SCORE_GRP_INTN_HIER hier
           INNER JOIN temp_pat_score_grp_intn_3 e1 ON (hier.GRP_ID=e1.GRP_ID AND hier.INTERACTION_ID_EXCLUDE=e1.INTERACTION_ID)
           INNER JOIN temp_pat_score_grp_intn_3 e2 ON (hier.GRP_ID=e2.GRP_ID
                                     AND hier.INTERACTION_ID_EXISTS=e2.INTERACTION_ID
                                     AND e2.CLIENT_ID=e1.CLIENT_ID
                                     AND e2.MPI=e1.MPI
                                     AND e2.GRP_ID=e1.GRP_ID
                                     AND e2.TIMEFRAME_ID=e1.TIMEFRAME_ID
                                     AND e2.ELIG_CDS_ID=e1.ELIG_CDS_ID)
      )
    """





  val originalSqlFileName: String = "L3_pat_score_grp_intn_build.sql"
}

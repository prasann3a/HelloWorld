
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_med_form, map_med_form}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_MED_FORM extends TableInfo[l1_map_med_form]{
  override def dependsOn: Set[String] = Set("MAP_MED_FORM")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_MED_FORM"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapMedForm = loadedDependencies("MAP_MED_FORM").as[map_med_form]

    mapMedForm
    .select(
			$"groupid".as("client_id"),
			$"localcode",
			$"hts_code",
			$"dts_version"
    )
  }
}


package com.optum.oadw.etl.L2

import java.sql.Timestamp

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_epi_mem_enroll_data(episode_id: java.lang.Long, member: String, cat_member: java.lang.Integer, cat_status: java.lang.Integer,
                                    sex: java.lang.Boolean, age_cat2: java.lang.Integer, product_id: String, account_id: String, mem_userdef_1_id: String,
                                    at_risk_status_id: String, mem_userdef_2_id: String, mem_userdef_3_id: String, mem_userdef_4_id: String,
                                    mem_eff_dt: Timestamp, mem_end_dt: Timestamp, sub_eff_dt: Timestamp, sub_end_dt: Timestamp,
                                    epi_date: Timestamp)

object TEMP_EPI_MEM_ENROLL extends QueryAndMetadata[temp_epi_mem_enroll_data] {
  override def name: String = "TEMP_EPI_MEM_ENROLL"

  override def sparkSql: String = """SELECT E.EPISODE_ID, E.MEMBER,
CASE WHEN IA.PRFL_MEM = 1 THEN 1 ELSE 0 END CAT_MEMBER,
IA.CAT_STATUS, MI.SEX, MA.AGE_CAT2,
S.PRODUCT_ID, S.ACCOUNT_ID, ME.MEM_USERDEF_1_ID, ME.at_risk_status_id, ME.MEM_USERDEF_2_ID,
ME.MEM_USERDEF_3_ID, ME.MEM_USERDEF_4_ID,
MEM_EFF_DT, MEM_END_DT, SUB_EFF_DT,
SUB_END_DT, EPI_DATE
FROM L2_II_EPISODES E
JOIN L2_II_MEMINFO MI ON E.MEMBER = MI.MEMBER
JOIN L2_II_IA_TIMES IA ON E.MEMBER = IA.MEMBER AND E.IA_TIME = IA.IA_TIME
JOIN L2_II_IMAP_AGE MA ON IA.AGE = MA.AGE
JOIN TEMP_EPI_ENR EE ON E.EPISODE_ID = EE.EPISODE_ID
JOIN L2_II_MEM_ENROLL ME ON EE.MEMBER = ME.MEMBER AND EE.MEM_EFF_DT = ME.EFF_DT AND EE.MEM_END_DT = ME.END_DT
JOIN L2_II_SUBSCRIBER S ON EE.SUBSCRIBER_ID = S.SUBSCRIBER_ID AND EE.SUB_EFF_DT = S.EFF_DT AND EE.SUB_END_DT = S.END_DT"""

  override def dependsOn: Set[String] = Set("TEMP_EPI_ENR","L2_II_MEMINFO","L2_II_IMAP_AGE","L2_II_MEM_ENROLL","L2_II_SUBSCRIBER","L2_II_EPISODES","L2_II_IA_TIMES")

  def originalSql: String = """

create table TEMP_EPI_MEM_ENROLL pctfree 0 nologging as
  SELECT E.EPISODE_ID, E.MEMBER,
         CASE WHEN IA.PRFL_MEM = 1 THEN 1 ELSE 0 END CAT_MEMBER,
         IA.CAT_STATUS, MI.SEX, MA.AGE_CAT2,
         S.PRODUCT_ID, S.ACCOUNT_ID, ME.MEM_USERDEF_1_ID, ME.MEM_USERDEF_2_ID,
         ME.MEM_USERDEF_3_ID, ME.MEM_USERDEF_4_ID,
         MEM_EFF_DT, MEM_END_DT, SUB_EFF_DT,
         SUB_END_DT, EPI_DATE
    FROM L2_II_EPISODES E
    JOIN L2_II_MEMINFO MI ON E.MEMBER = MI.MEMBER
    JOIN L2_II_IA_TIMES IA ON E.MEMBER = IA.MEMBER AND E.IA_TIME = IA.IA_TIME
    JOIN L2_II_IMAP_AGE MA ON IA.AGE = MA.AGE
    JOIN TEMP_EPI_ENR EE ON E.EPISODE_ID = EE.EPISODE_ID
    JOIN L2_II_MEM_ENROLL ME ON EE.MEMBER = ME.MEMBER AND EE.MEM_EFF_DT = ME.EFF_DT AND EE.MEM_END_DT = ME.END_DT
    JOIN L2_II_SUBSCRIBER S ON EE.SUBSCRIBER_ID = S.SUBSCRIBER_ID AND EE.SUB_EFF_DT = S.EFF_DT AND EE.SUB_END_DT = S.END_DT
    """

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}

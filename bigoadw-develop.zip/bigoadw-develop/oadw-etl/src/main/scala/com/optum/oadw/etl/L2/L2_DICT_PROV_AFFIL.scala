package com.optum.oadw.etl.L2
import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

/*
  * Client-specific dictionary of most-granular(PROV_AFFIL_ID, PROV_AFFIL_DESC), middle-level(PROV_AFFIL_LV2, PROV_AFFIL_LV2_DESC)
  * and least granular(PROV_AFFIL_LV1, PROV_AFFIL_LV1_DESC) provider affiliation details.
*/

object L2_DICT_PROV_AFFIL extends TableInfo[l2_dict_prov_affil] {
  override def name: String = "L2_DICT_PROV_AFFIL"

  override def dependsOn: Set[String] = Set("L1_PROV_AFFIL_ROLLUP", "L2_PROVIDER_INFO")

  def directoryLevel = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1ProvAffilRollUp = loadedDependencies("L1_PROV_AFFIL_ROLLUP").as[l1_prov_affil_rollup]
    val l2ProviderInfo = loadedDependencies("L2_PROVIDER_INFO").as[l2_provider_info]

    l1ProvAffilRollUp.as("par")
    .join(l2ProviderInfo.as("pi"), $"pi.prov_affil_id" === $"par.prov_affil_id", "left")
    .select(
      $"par.client_id",
      $"par.prov_affil_id",
      $"par.prov_affil_desc",
      $"par.prov_affil_lv2",
      $"par.prov_affil_lv2_desc",
      $"par.prov_affil_lv1",
      $"par.prov_affil_lv1_desc"
    ).distinct()

  }
}

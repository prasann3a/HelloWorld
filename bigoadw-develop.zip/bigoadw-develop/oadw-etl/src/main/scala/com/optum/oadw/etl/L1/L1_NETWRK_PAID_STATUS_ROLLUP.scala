
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_netwrk_paid_status_rollup, netwrk_paid_status_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_NETWRK_PAID_STATUS_ROLLUP extends TableInfo[l1_netwrk_paid_status_rollup]{
  override def dependsOn: Set[String] = Set("NETWRK_PAID_STATUS_ROLLUP")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_NETWRK_PAID_STATUS_ROLLUP"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val netwrkPaidStatusRollup = loadedDependencies("NETWRK_PAID_STATUS_ROLLUP").as[netwrk_paid_status_rollup]

    netwrkPaidStatusRollup
    .select(
			$"groupid".as("client_id"),
			$"network_paid_status",
			$"network_paid_status_desc",
			$"network_paid_status_lv2",
			$"network_paid_status_lv2_desc",
			$"network_paid_status_lv1",
			$"network_paid_status_lv1_desc",
			$"network_paid_status_rollup",
			$"client_ds_id",
			$"datasrc"
    )
  }
}


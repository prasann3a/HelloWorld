
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_bpo_pharmacy_clinical, pp_bpo_pharmacy_clinical}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_BPO_PHARMACY_CLINICAL extends TableInfo[l1_bpo_pharmacy_clinical]{
  override def dependsOn: Set[String] = Set("PP_BPO_PHARMACY_CLINICAL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_BPO_PHARMACY_CLINICAL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ppBpoPharmacyClinical = loadedDependencies("PP_BPO_PHARMACY_CLINICAL").as[pp_bpo_pharmacy_clinical]

    ppBpoPharmacyClinical
    .select(
		$"administration_date".as("administration_dt"),
		$"code",
		$"code_taxonomy",
		$"groupid".as("client_id"),
		$"healthplansource",
		$"memberid".as("mpi"),
		$"pharmacy_clinical_id"
    )
  }
}


package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_map_cds_source_type_bit
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object L2_MAP_CDS_SOURCE_TYPE_BIT extends TableInfo[l2_map_cds_source_type_bit] {
  override def name: String = "L2_MAP_CDS_SOURCE_TYPE_BIT"

  override def dependsOn: Set[String] = Set("L2_MAP_CDS_FLG")

  protected def createDataFrame(sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG")

    l2MapCdsFlg
      .select($"client_id", $"source_type_flg",
        when($"source_type_flg" === lit(1), "Payer")
          .when($"source_type_flg" === lit(2), "Billing")
          .when($"source_type_flg" === lit(4), "EMR")
          .when($"source_type_flg" === lit(8), "Mixed")
          .when($"source_type_flg" === lit(16), "CC")
          .otherwise("None").as("source_type_flg_name")
      ).distinct()
  }
}
package com.optum.oadw.etl.L2
import com.optum.oadw.oadwModels.l2_ii_ocu_pop_costs_ext
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_II_OCU_POP_COSTS_EXT extends QueryAndMetadata[l2_ii_ocu_pop_costs_ext] {
  override def name: String = "L2_II_OCU_POP_COSTS_EXT"

  override def sparkSql: String =
    """
       select
        YEAR_MTH_ID,
        cast(NEW_MEM_ATTR_ID as long) as NEW_MEM_ATTR_ID,
        PROVIDER_ID,
        POS_I,
        cast(PRV_SP_4 as long) as PRV_SP_4,
        cast(TOS_I_5 as long) as TOS_I_5,
        cast(dis_rel as long) as disrel,
        drg_id,
        admit_source,
        YEAR_MTH_PD,
        NETWORK_PAID_STATUS_ID,
        PROVIDER_STATUS_ID,
        cast(ENCOUNTER as double) as ENCOUNTER,
        cast(EM_SVC_FLAG as long) as EM_SVC_FLAG,
        cast(RAD_UTIL as double) as RAD_UTIL,
        cast(LAB_UTIL as double) as LAB_UTIL,
        cast(MRI_UTIL as double) as MRI_UTIL,
        cast(ER_UTIL as double) as ER_UTIL,
        cast(LOS as long) as LOS,
        cast(ADMIT as long) as admit,
        cast(SCRIPT as long) as script,
        cast(AMT_REQ as double) as AMT_REQ,
        cast(AMT_EQV as double) as AMT_EQV,
        cast(AMT_DED as double) as AMT_DED,
        cast(AMT_COIN as double) as AMT_COIN,
        cast(AMT_COP as double) as AMT_COP,
        cast(AMT_LIAB as double) as AMT_LIAB,
        cast(AMT_CAP_PAY as double) as AMT_CAP_PAY,
        cast(AMT_PAY as double) as AMT_PAY,
        cast(AMT_NP as double) as AMT_NP,
        cast(null as integer) as sev_level,
        cast(null as string) as pcp_imp,
        cast(null as string) as pcp_assign,
        cast(null as long) as etg_id
          from (
            SELECT
              YEAR_MTH_ID,
              NEW_MEM_ATTR_ID,
              PROVIDER_ID,
              POS_I,
              PRV_SP_4,
              TOS_I_5,
              dis_rel,
              drg_id,
              admit_source,
              YEAR_MTH_PD,NETWORK_PAID_STATUS_ID,
              PROVIDER_STATUS_ID,
              SUM(ENCOUNTER) AS ENCOUNTER,
              SUM(EM_SVC_FLAG) AS EM_SVC_FLAG,
              SUM(RAD_UTIL) AS RAD_UTIL,
              SUM(LAB_UTIL) AS LAB_UTIL,
              SUM(MRI_UTIL) AS MRI_UTIL,
              SUM(ER_UTIL) AS ER_UTIL,
              SUM(LOS) AS LOS,
              SUM(ADMIT) AS ADMIT,
              SUM(SCRIPT) AS SCRIPT,
              SUM(AMT_REQ) AS AMT_REQ,
              SUM(AMT_EQV) AS AMT_EQV,
              SUM(AMT_DED) AS AMT_DED,
              SUM(AMT_COIN) AS AMT_COIN,
              SUM(AMT_COP) AS AMT_COP,
              SUM(AMT_LIAB) AS AMT_LIAB,
              SUM(AMT_CAP_PAY) AS AMT_CAP_PAY,
              SUM(AMT_PAY) AS AMT_PAY,
              SUM(AMT_NP) AS AMT_NP
            FROM temp_ocu_services
              GROUP BY YEAR_MTH_ID, NEW_MEM_ATTR_ID, PROVIDER_ID,POS_I, PRV_SP_4, TOS_I_5, dis_rel,drg_id,admit_source,YEAR_MTH_PD, NETWORK_PAID_STATUS_ID, PROVIDER_STATUS_ID
        )
    """

  override def dependsOn: Set[String] = Set("TEMP_OCU_SERVICES")

  def originalSql: String = """
insert /*+ append */ into l2_ii_ocu_pop_costs_ext (YEAR_MTH_ID,NEW_MEM_ATTR_ID,PROVIDER_ID,POS_I,PRV_SP_4,TOS_I_5,
          disrel,DRG_ID,ADMIT_SOURCE,YEAR_MTH_PD,
          NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,
          ENCOUNTER,EM_SVC_FLAG,RAD_UTIL,LAB_UTIL,MRI_UTIL,ER_UTIL,LOS,ADMIT,SCRIPT,AMT_REQ,AMT_EQV,AMT_DED,
          AMT_COIN,AMT_COP,AMT_LIAB,AMT_CAP_PAY,AMT_PAY,AMT_NP)
select YEAR_MTH_ID, NEW_MEM_ATTR_ID, PROVIDER_ID, POS_I, PRV_SP_4, TOS_I_5, dis_rel,drg_id,admit_source,YEAR_MTH_PD,
       NETWORK_PAID_STATUS_ID, PROVIDER_STATUS_ID,
       ENCOUNTER, EM_SVC_FLAG,  RAD_UTIL,
       LAB_UTIL, MRI_UTIL, ER_UTIL, LOS,  ADMIT,
       SCRIPT,AMT_REQ, AMT_EQV,  AMT_DED,AMT_COIN,
       AMT_COP,AMT_LIAB,AMT_CAP_PAY, AMT_PAY,AMT_NP
  from (
SELECT YEAR_MTH_ID, NEW_MEM_ATTR_ID, PROVIDER_ID, POS_I, PRV_SP_4, TOS_I_5, dis_rel,drg_id,admit_source,YEAR_MTH_PD,
        NETWORK_PAID_STATUS_ID, PROVIDER_STATUS_ID,
        SUM(ENCOUNTER) AS ENCOUNTER, SUM(EM_SVC_FLAG) AS EM_SVC_FLAG,  SUM(RAD_UTIL) AS RAD_UTIL,
        SUM(LAB_UTIL) AS LAB_UTIL,   SUM(MRI_UTIL) AS MRI_UTIL, SUM(ER_UTIL) AS ER_UTIL, SUM(LOS) AS LOS,  SUM(ADMIT) AS ADMIT,
        SUM(SCRIPT) AS SCRIPT,SUM(AMT_REQ) AS AMT_REQ, SUM(AMT_EQV) AS AMT_EQV,  SUM(AMT_DED) AS AMT_DED,SUM(AMT_COIN) AS AMT_COIN,
        SUM(AMT_COP) AS AMT_COP,SUM(AMT_LIAB) AS AMT_LIAB,SUM(AMT_CAP_PAY) AS AMT_CAP_PAY, SUM(AMT_PAY) AS AMT_PAY,SUM(AMT_NP) AS AMT_NP
FROM temp_ocu_services
GROUP BY YEAR_MTH_ID, NEW_MEM_ATTR_ID, PROVIDER_ID,POS_I, PRV_SP_4, TOS_I_5, dis_rel,drg_id,admit_source,YEAR_MTH_PD, NETWORK_PAID_STATUS_ID,
PROVIDER_STATUS_ID
)"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(
    OutputColumn("YEAR_MTH_ID",None,None), OutputColumn("NEW_MEM_ATTR_ID",None,None),
    OutputColumn("PROVIDER_ID",None,None), OutputColumn("POS_I",None,None), OutputColumn("PRV_SP_4",None,None),
    OutputColumn("TOS_I_5",None,None), OutputColumn("disrel",None,None), OutputColumn("DRG_ID",None,None),
    OutputColumn("ADMIT_SOURCE",None,None), OutputColumn("YEAR_MTH_PD",None,None),
    OutputColumn("NETWORK_PAID_STATUS_ID",None,None), OutputColumn("PROVIDER_STATUS_ID",None,None),
    OutputColumn("ENCOUNTER",None,None), OutputColumn("EM_SVC_FLAG",None,None), OutputColumn("RAD_UTIL",None,None),
    OutputColumn("LAB_UTIL",None,None), OutputColumn("MRI_UTIL",None,None), OutputColumn("ER_UTIL",None,None),
    OutputColumn("LOS",None,None), OutputColumn("ADMIT",None,None), OutputColumn("SCRIPT",None,None),
    OutputColumn("AMT_REQ",None,None), OutputColumn("AMT_EQV",None,None), OutputColumn("AMT_DED",None,None),
    OutputColumn("AMT_COIN",None,None), OutputColumn("AMT_COP",None,None), OutputColumn("AMT_LIAB",None,None),
    OutputColumn("AMT_CAP_PAY",None,None), OutputColumn("AMT_PAY",None,None), OutputColumn("AMT_NP",None,None),
    OutputColumn("sev_level",None,None), OutputColumn("pcp_imp",None,None), OutputColumn("pcp_assign",None,None),
    OutputColumn("etg_id",None,None)
  ))

  def directoryLevel: String = "L2"





  override def partitions: Int = 128

  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_bpo_pharmacy_claims, pp_bpo_pharmacy_claims}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_BPO_PHARMACY_CLAIMS extends TableInfo[l1_bpo_pharmacy_claims]{
  override def dependsOn: Set[String] = Set("PP_BPO_PHARMACY_CLAIMS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_BPO_PHARMACY_CLAIMS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ppBpoPharmacyClaims = loadedDependencies("PP_BPO_PHARMACY_CLAIMS").as[pp_bpo_pharmacy_claims]

    ppBpoPharmacyClaims
    .select(
			$"adjusted_rx_cnt",
			$"admin_fee_amt",
			$"allowedamount",
			$"capitated_service_ind",
			$"claimheader",
			$"claimsource",
			$"coinsamount",
			$"contract_id",
			$"coord_benefits_amt",
			$"copayamount",
			$"cust_attr_1",
			$"cust_attr_2",
			$"cust_attr_3",
			$"cust_attr_4",
			$"cust_attr_5",
			$"cust_attr_6",
			$"cust_attr_7",
			$"cust_attr_8",
			$"cust_attr_9",
			$"cust_attr_10",
			$"cust_attr_11",
			$"cust_attr_12",
			$"cust_attr_13",
			$"cust_attr_14",
			$"cust_attr_15",
			$"cust_attr_16",
			$"cust_attr_17",
			$"cust_attr_18",
			$"cust_attr_19",
			$"cust_attr_20",
			$"daw",
			$"dayssupply",
			$"deductamount",
			$"deniedflag",
			$"denied_ind",
			$"dispensingfee",
			$"employeraccountid",
			$"fillnum",
			$"formulary",
			$"genericstatus",
			$"groupid".as("client_id"),
			$"ingredientcost",
			$"memberid".as("mpi"),
			$"ndc",
			$"network_paid_status",
			$"networkstatus",
			$"not_covered_amt",
			$"other_carrier_pay_amt",
			$"other_1_amt",
			$"other_2_amt",
			$"other_3_amt",
			$"other_4_amt",
			$"paidamount",
			$"patliabamount",
			$"paymentdate".as("payment_dt"),
			$"pharmacyid",
			$"pharmacytype",
			$"prescprovider".as("presc_prov_id"),
			$"provider_status",
			$"pseudoflag",
			$"quantity",
			$"quantity_dispensed",
			$"requestedamount",
			$"rxid",
			$"sales_tax_amt",
			$"servicedate".as("service_dt"),
			$"spec_rx_ind"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_upload_rules, map_upload_rules}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_UPLOAD_RULES extends TableInfo[l1_map_upload_rules]{
  override def dependsOn: Set[String] = Set("MAP_UPLOAD_RULES")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_UPLOAD_RULES"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapUploadRules = loadedDependencies("MAP_UPLOAD_RULES").as[map_upload_rules]

    mapUploadRules
    .select(
		$"groupid".as("client_id"),
		$"client_ds_id",
		$"rule_type",
		$"id_type",
		$"id_sub_type",
		$"ds_display_name",
		$"regex",
		$"datasource",
		$"is_default_datasource",
		$"dts_version"
    )
  }
}


/**
  * auto-generated code
  */
package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_patient_grp_mpi_diff
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata


object L2_PATIENT_GRP_MPI_DIFF extends QueryAndMetadata[l2_patient_grp_mpi_diff] {
  override def name: String = "L2_PATIENT_GRP_MPI_DIFF"

  override def sparkSql: String = """SELECT client_id, client_ds_id, datasrc, patientid, hgpid, new_mpi, old_mpi, mpi_status
FROM l1_patient_grp_mpi_diff"""

  override def dependsOn: Set[String] = Set("L1_PATIENT_GRP_MPI_DIFF")

  def originalSql: String = """INSERT /*+ APPEND */ INTO l2_patient_grp_mpi_diff ( client_id, client_ds_id, datasrc, patientid, hgpid, new_mpi, old_mpi, mpi_status)
SELECT client_id, client_ds_id, datasrc, patientid, hgpid, new_mpi, old_mpi, mpi_status
FROM l1_patient_grp_mpi_diff"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("client_id",None,None), OutputColumn("client_ds_id",None,None), OutputColumn("datasrc",None,None), OutputColumn("patientid",None,None), OutputColumn("hgpid",None,None), OutputColumn("new_mpi",None,None), OutputColumn("old_mpi",None,None), OutputColumn("mpi_status",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_patient_grp_mpi_diff_build.sql"
}


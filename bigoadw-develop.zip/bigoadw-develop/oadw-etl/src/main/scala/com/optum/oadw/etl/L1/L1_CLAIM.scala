
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_claim, claim}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_CLAIM extends TableInfo[l1_claim]{
  override def dependsOn: Set[String] = Set("CLAIM")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CLAIM"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val claim = loadedDependencies("CLAIM").as[claim]

    claim
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"facilityid",
			$"claimid".as("claim"),
			$"encounterid",
			$"patientid",
			$"charge",
			$"quantity",
			$"localcpt",
			$"localcptmod1",
			$"localcptmod2",
			$"localcptmod3",
			$"localcptmod4",
			$"servicedate".as("service_dtm"),
			$"localhcpcs",
			$"localicd9",
			$"techorprof",
			$"seq",
			$"claimproviderid",
			$"mappedicd9",
			$"mappedhcpcs",
			$"mappedcpt",
			$"mappedcptmod1",
			$"mappedcptmod2",
			$"mappedcptmod3",
			$"mappedcptmod4",
			$"localbillingproviderid",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"costamount",
			$"claim_mstrprovid",
			$"allowedamount",
			$"paidamount",
			$"to_dt",
			$"post_dt",
			$"localrev",
			$"mappedrev",
			$"pos",
			$"par_flag",
			$"ein",
			$"contract_id",
			$"network_paid_status",
			$"fee_for_service_amt",
			$"copay_amt",
			$"coinsurance_amt",
			$"deductible_amt",
			$"pat_liability_amt",
			$"coord_benefits_amt",
			$"withhold_amt",
			$"capitation_amt",
			$"capitated_service_flag",
			$"denied_flag",
			$"pseudo_flag"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_client_datasrc_type, map_client_datasrc_type}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_CLIENT_DATASRC_TYPE extends TableInfo[l1_map_client_datasrc_type]{
  override def dependsOn: Set[String] = Set("MAP_CLIENT_DATASRC_TYPE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_CLIENT_DATASRC_TYPE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapClientDatasrcType = loadedDependencies("MAP_CLIENT_DATASRC_TYPE").as[map_client_datasrc_type]

    mapClientDatasrcType
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"cui",
			$"dts_version"
    )
  }
}


package com.optum.oadw.etl.L3


import com.optum.oadw.oadwModels.l1_hedis_measure_result
import com.optum.oadw.oadw_ref.models.l3_map_hedis_exception
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

case class temp_hedis_exception_data(client_id: String, version: String, measurement_end_dt: java.sql.Timestamp, mpi: String, measure_name: String,
                                episode_number: String, composite_exception: String, composite_numerator_excl: String,composite_numerator: String)


object TEMP_HEDIS_EXCEPTION extends TableInfo[temp_hedis_exception_data] {

  override def name: String = "TEMP_HEDIS_EXCEPTION"

  override def dependsOn: Set[String] = Set("L1_HEDIS_MEASURE_RESULT","L3_MAP_HEDIS_EXCEPTION")

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1HedisMeasureResult = loadedDependencies("L1_HEDIS_MEASURE_RESULT").as[l1_hedis_measure_result]
    val l3MapHedisException = loadedDependencies("L3_MAP_HEDIS_EXCEPTION").as[l3_map_hedis_exception]

      l1HedisMeasureResult.as("p")
        .join(broadcast(l3MapHedisException).as("m"), $"p.measure_name" === $"m.measure_name")
        .groupBy($"client_id",
      $"version",
      $"measurement_end_dt",
      $"mpi",
      $"p.measure_name",
      $"episode_number")
      .agg(max($"denominator_exception_flag").as("composite_exception"),
        max(when($"numerator_exclusion_flag" === lit("1") and $"numerator_flag" === lit("0"), lit("1"))
          .otherwise(lit("0"))).as("composite_numerator_excl"),
        min(when(($"measure_id" === lit("CDC2") or ($"measure_id" === lit("CDCM2"))) and $"numerator_flag" === lit("0"), lit("1"))
          .when(($"measure_id" === lit("CDC2") or ($"measure_id" === lit("CDCM2"))) and $"numerator_flag" === lit("1"), lit("0"))
          .otherwise($"numerator_flag")).as("composite_numerator")
      )
  }
}

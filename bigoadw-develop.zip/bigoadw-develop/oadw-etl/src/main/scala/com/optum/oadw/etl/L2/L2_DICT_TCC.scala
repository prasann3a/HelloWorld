package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l2_dict_dcc, l2_dict_tcc}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object L2_DICT_TCC extends TableInfo[l2_dict_tcc] {
  override def name: String = "L2_DICT_TCC"

  override def dependsOn: Set[String] = Set("L2_DICT_DCC")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2DictDcc = loadedDependencies("L2_DICT_DCC").as[l2_dict_dcc]
    l2DictDcc
      .groupBy($"tcc")
      .agg(
        min($"tcc_name").as("tcc_name")
      )
  }
}

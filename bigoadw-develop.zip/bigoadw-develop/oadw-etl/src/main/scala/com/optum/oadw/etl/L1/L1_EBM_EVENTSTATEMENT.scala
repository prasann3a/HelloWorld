
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ebm_eventstatement, ebm_eventstatement}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_EBM_EVENTSTATEMENT extends TableInfo[l1_ebm_eventstatement]{
  override def dependsOn: Set[String] = Set("EBM_EVENTSTATEMENT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_EBM_EVENTSTATEMENT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ebmEventstatement = loadedDependencies("EBM_EVENTSTATEMENT").as[ebm_eventstatement]

    ebmEventstatement
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi",
			$"report_case_id",
			$"event",
			$"report_rule_id",
			$"statement_cd",
			$"status_flg",
			$"file_processing_month"
    )
  }
}


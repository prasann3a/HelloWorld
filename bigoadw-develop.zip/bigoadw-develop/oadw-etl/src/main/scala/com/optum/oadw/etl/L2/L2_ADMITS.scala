package com.optum.oadw.etl.L2
import com.optum.oadw.oadwModels.l2_admits
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_ADMITS extends QueryAndMetadata[l2_admits] {
  override def name: String = "L2_ADMITS"

  override def sparkSql: String = """
      select cast(om.NEW_MEM_ATTR_ID as long) as NEW_MEM_ATTR_ID,MDR.IA_TIME, MDR.YEAR_MTH_ID, MDR2.YEAR_MTH_ID as END_YEAR_MTH_ID, OM.PCP_ASSIGN, c.product_id,
      case when c.sex = true then 1 when c.sex = false then 0 else null end as sex,
      c.age_cat2, c.contract_id, c.mem_userdef_1_id, c.at_risk_status_id,
      c.zip, c.cat_status_cost3, cf.provider_id, cf.drg_id, cast(cf.tos_i_5 as long) as tos_i_5, cf.drg_admittyp, cf.poa, network_paid_status_id,
      provider_status_id, cast(cf.etg_id as long) as etg_id,coalesce(av.avoidable_admit_flag, 0) AS avoidable_admit_flag, coalesce(av.pqi,0) as pqi,cast(coalesce(cf.admit,false) as int) as admit, cast(coalesce(cf.los,0) as INT) as los,
      coalesce(AMT_REQ,0) as AMT_REQ, coalesce(AMT_EQV,0) as AMT_EQV, coalesce(AMT_PAY,0) as AMT_PAY, coalesce(AMT_NP,0) as AMT_NP,
      case when cf.readmit_index_07 = true then 1 when cf.readmit_index_07 = false then 0 else null end as readmit_index_07,
      case when cf.readmit_index_30 = true then 1 when cf.readmit_index_30 = false then 0 else null end as readmit_index_30,
      case when cf.readmit_index_60 = true then 1 when cf.readmit_index_60 = false then 0 else null end as readmit_index_60,
      case when cf.readmit_index_90 = true then 1 when cf.readmit_index_90 = false then 0 else null end as readmit_index_90,
      case when cf.readmit_07 = true then 1 when cf.readmit_07 = false then 0 else null end as readmit_07,
      case when cf.readmit_30 = true then 1 when cf.readmit_30 = false then 0 else null end as readmit_30,
      case when cf.readmit_60 = true then 1 when cf.readmit_60 = false then 0 else null end as readmit_60,
      case when cf.readmit_90 = true then 1 when cf.readmit_90 = false then 0 else null end as readmit_90,
      ii.rrisk
      from l2_ii_confinements cf
      LEFT JOIN l2_ii_conf_avoidable av on cf.conf_num=av.conf_num
      JOIN l2_ii_ia_times ii on cf.member=ii.member and cf.ia_time=ii.ia_time
      JOIN l2_ii_map_date_range MDR ON MDR.MONTH_VAL = MONTH ( cf.BEG_DT) AND MDR.YEAR_VAL = YEAR ( cf.BEG_DT)
      JOIN l2_ii_mem_attr_member_ext OM ON CF.MEMBER = OM.MEMBER
        AND OM.YEAR_MTH_ID = MDR.YEAR_MTH_ID
        AND CF.BEG_DT BETWEEN OM.MEM_EFF_DT AND OM.MEM_END_DT
        AND CF.BEG_DT BETWEEN OM.SUB_EFF_DT AND OM.SUB_END_DT
      JOIN l2_ii_map_date_range MDR2 ON MDR2.MONTH_VAL = MONTH ( cf.END_DT) AND MDR2.YEAR_VAL = YEAR ( cf.END_DT)
      JOIN l2_ii_mem_attr_ext C ON OM.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
      WHERE cf.exclude=0"""

  override def dependsOn: Set[String] = Set("L2_II_CONFINEMENTS","L2_II_MEM_ATTR_EXT","L2_II_IA_TIMES","L2_II_MEM_ATTR_MEMBER_EXT","L2_II_MAP_DATE_RANGE","L2_II_CONF_AVOIDABLE")

  def originalSql: String = """

--overall Admissions
insert /*+ append */ into l2_admits(
    NEW_MEM_ATTR_ID,IA_TIME,YEAR_MTH_ID,PCP_ASSIGN,PRODUCT_ID,SEX,AGE_CAT2,CONTRACT_ID,MEM_USERDEF_1_ID,ZIP,CAT_STATUS_COST3,PROVIDER_ID,DRG_ID,TOS_I_5,DRG_ADMITTYP,
    POA,NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,etg_id,AVOIDABLE_ADMIT_FLAG,PQI,ADMIT,LOS,AMT_REQ,AMT_EQV,AMT_PAY,AMT_NP,READMIT_INDEX_07,READMIT_INDEX_30,READMIT_INDEX_60,READMIT_INDEX_90,
    READMIT_07,READMIT_30,READMIT_60,READMIT_90,rrisk)
select om.NEW_MEM_ATTR_ID,MDR.IA_TIME, MDR.YEAR_MTH_ID, OM.PCP_ASSIGN, c.product_id, c.sex, c.age_cat2, c.contract_id, c.mem_userdef_1_id, c.zip, c.cat_status_cost3, cf.provider_id, cf.drg_id, cf.tos_i_5, cf.drg_admittyp,
       cf.poa, network_paid_status_id,  provider_status_id, cf.etg_id,av.avoidable_admit_flag, coalesce(av.pqi,0) as pqi,coalesce(cf.admit,0) as admit, coalesce(cf.los,0) as los,
       coalesce(AMT_REQ,0), coalesce(AMT_EQV,0), coalesce(AMT_PAY,0), coalesce(AMT_NP,0), cf.readmit_index_07,
       cf.readmit_index_30,cf.readmit_index_60,cf.readmit_index_90,cf.readmit_07, cf.readmit_30, cf.readmit_60, cf.readmit_90,ii.rrisk
  from L2_II_CONFINEMENTS cf
  LEFT JOIN L2_II_CONF_AVOIDABLE av on    cf.conf_num=av.conf_num
  JOIN L2_II_ia_times ii on cf.member=ii.member and cf.ia_time=ii.ia_time
  JOIN L2_II_MAP_DATE_RANGE MDR ON MDR.MONTH_VAL = extract(MONTH from cf.BEG_DT) AND MDR.YEAR_VAL =   extract(YEAR from cf.BEG_DT)
  JOIN l2_ii_mem_attr_member_ext OM ON CF.MEMBER = OM.MEMBER AND OM.YEAR_MTH_ID = MDR.YEAR_MTH_ID AND CF.BEG_DT BETWEEN OM.MEM_EFF_DT AND OM.MEM_END_DT
    AND CF.BEG_DT BETWEEN OM.SUB_EFF_DT AND OM.SUB_END_DT
  JOIN l2_ii_mem_attr_ext C ON OM.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
  WHERE cf.exclude=0
  ;"""

  def directoryLevel: String = "L2"
  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}

package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_provider, zh_provider}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROVIDER extends TableInfo[l1_provider]{
  override def dependsOn: Set[String] = Set("ZH_PROVIDER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROVIDER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhProvider = loadedDependencies("ZH_PROVIDER").as[zh_provider]

    zhProvider
    .select(
			$"groupid".as("client_id"),
			$"localproviderid",
			$"npi",
			$"providername",
			$"localprimaryspecialty",
			$"primaryfacilityid",
			$"emailaddress",
			$"providerexclusionflag",
			$"client_ds_id",
			$"master_hgprovid",
			$"localclassification",
			$"first_name",
			$"last_name",
			$"middle_name",
			$"credentials",
			$"mappedcredentialtype",
			$"suffix",
			$"dob".as("dateofbirth"),
			$"gender",
			$"datasrc"
    )
  }
}


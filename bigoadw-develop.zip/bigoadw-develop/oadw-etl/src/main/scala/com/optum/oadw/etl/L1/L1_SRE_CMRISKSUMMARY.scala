package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{ l1_sre_cmrisksummary, sre_cmrisksummary }
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.{ DataFrame, SparkSession }

object L1_SRE_CMRISKSUMMARY extends TableInfo[l1_sre_cmrisksummary] {
  override def dependsOn: Set[String] = Set("SRE_CMRISKSUMMARY")

  override def skipCoalesce: Boolean = true
  override def name: String          = "L1_SRE_CMRISKSUMMARY"

  override protected def createDataFrame(
    sparkSession: SparkSession,
    loadedDependencies: Map[String, DataFrame],
    udfMap: Map[String, UserDefinedFunctionForDataLoader],
    runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("SRE_CMRISKSUMMARY").as[sre_cmrisksummary]

    cdrTbl
      .select(
        $"groupid".as("client_id"),
        $"family_id".as("mpi"),
        $"patient_id",
        $"age",
        $"gender",
        $"cm_risk",
        $"cm_ip_prob",
        $"cm_ip_rel_risk",
        $"cm_3mo_risk",
        $"cm_3mo_ip_prob",
        $"cm_3mo_ip_rel_risk",
        $"cm_lab_risk",
        $"cm_ip_risk",
        $"cm_op_risk",
        $"cm_prof_risk",
        $"cm_anc_risk",
        $"cm_rx_risk",
        $"demo_risk",
        $"input_data_type",
        $"cm_ed_prob",
        $"cm_ed_rel_risk",
        $"grouping_end_date".as("grouping_end_dt"),
        $"error_status",
        $"grouper_version",
        $"database_version",
        $"cm_enroll_length",
        $"cm_partial_enroll"
      )
  }
}

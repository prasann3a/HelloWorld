package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.definedfunctions.BitOrAggFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, TimestampType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.sql.types._


object L2_DICT_SPEC extends TableInfo[l2_dict_spec] {
  override def name = "L2_DICT_SPEC"

  override def dependsOn = Set("L1_REF_IMAP_SPEC")

  def directoryLevel = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    
    import sparkSession.implicits._

    val l1RefImapSpec = loadedDependencies("L1_REF_IMAP_SPEC").as[l1_ref_imap_spec]

    l1RefImapSpec
      .select(
        $"prv_sp_4".cast(IntegerType),
        $"prv_sp_4".as("specialty_id"),
        $"sp1_id".cast(IntegerType),
        $"sp2_id".cast(IntegerType),
        $"sp3_id".cast(IntegerType),
        $"sp1",
        $"sp2",
        $"sp3",
        $"sp4"
        )
  }
}

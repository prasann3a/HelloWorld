
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_encounter_encounter_grp, encounter_encounter_grp}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_ENCOUNTER_ENCOUNTER_GRP extends TableInfo[l1_encounter_encounter_grp]{
  override def dependsOn: Set[String] = Set("ENCOUNTER_ENCOUNTER_GRP")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_ENCOUNTER_ENCOUNTER_GRP"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val encounterEncounterGrp = loadedDependencies("ENCOUNTER_ENCOUNTER_GRP").as[encounter_encounter_grp]

    encounterEncounterGrp
    .select(
			$"groupid".as("client_id"),
			$"encounter_grp_num",
			$"client_ds_id",
			$"grp_mpi".as("mpi"),
			$"encounterid",
			$"patienttype",
			$"encounteridtype"
    )
  }
}


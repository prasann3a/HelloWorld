package com.optum.oadw.etl.L2
import java.sql.Timestamp

import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.definedfunctions.{BitOrAggFunction,ListAggFunction}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, TimestampType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object L2_PAT_ALLERGY extends TableInfo[l2_pat_allergy] {

  override def name = "L2_PAT_ALLERGY"

  override def dependsOn = Set("L2_MAP_CDS_FLG","L1_MAP_ALLERGEN","L1_MAP_ALLERGEN_TYPE", "MD_OADW_INSTANCE",
    "L1_CLINICAL_EVENT_ENCOUNTER","L1_ALLERGY","L2_DICT_DCC", "L2_DICT_PCC")

  def directoryLevel = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l1Allergy = loadedDependencies("L1_ALLERGY").as[l1_allergy].alias("l1Allergy")
    val l2MapCDSFLG = broadcast(loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg]).alias("l2MapCDSFLG")
    val l1MapAllergen = loadedDependencies("L1_MAP_ALLERGEN").as[l1_map_allergen].alias("l1MapAllergen")
    val l1MapAllergenType = loadedDependencies("L1_MAP_ALLERGEN_TYPE").as[l1_map_allergen_type].alias("l1MapAllergenType")
    val mDOADWInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance].alias("mDOADWInstance")
    val tl1ClinicalEventEncounter = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").as[l1_clinical_event_encounter].alias("tl1ClinicalEventEncounter")
    val tL2DictDCC = broadcast(loadedDependencies("L2_DICT_DCC").as[l2_dict_dcc]).alias("tL2DictDCC")
    val tL2DictPCC = broadcast(loadedDependencies("L2_DICT_PCC").as[l2_dict_pcc]).alias("tL2DictPCC")
    val oadwDataThru = createOADWDataThru(sparkSession, mDOADWInstance)

    val allergyMapping = createL1AllergyMapping(sparkSession, l1Allergy, l2MapCDSFLG, l1MapAllergen, l1MapAllergenType, tl1ClinicalEventEncounter, tL2DictDCC, tL2DictPCC, oadwDataThru)
    allergyMapping

  }

  private def createOADWDataThru(sparkSession: SparkSession,
                                 mDOADWInstance: Dataset[md_oadw_instance]): Timestamp = {
    import sparkSession.implicits._

    val oadwDataThru = mDOADWInstance.as("oadw_data_thru")
      .select(to_date($"attribute_value", "yyyyMMdd").as("data_thru_dt"))
      .where($"attribute_name" === "DATA_THRU").as[Timestamp].head()

    oadwDataThru
  }

  private def createL1AllergyMapping(sparkSession: SparkSession,
                                     l1Allergy: Dataset[l1_allergy],
                                     l2MapCDSFLG: Dataset[l2_map_cds_flg],
                                     l1MapAllergen: Dataset[l1_map_allergen],
                                     l1MapAllergenType: Dataset[l1_map_allergen_type],
                                     tl1ClinicalEventEncounter: Dataset[l1_clinical_event_encounter],
                                     tL2DictDCC: Dataset[l2_dict_dcc],
                                     tL2DictPCC: Dataset[l2_dict_pcc],
                                     oadwDataThru: Timestamp) = {

    import sparkSession.implicits._
    val bitoragg = BitOrAggFunction.bitOrAgg

    val listagg = ListAggFunction.listAgg

    val plus1Day = Timestamp.valueOf(oadwDataThru.toLocalDateTime.toLocalDate.plusDays(1).atStartOfDay())

    val l1AllergyMapping = l1Allergy
      .join(l2MapCDSFLG,
        $"l1Allergy.client_id" === $"l2MapCDSFLG.client_id" &&
          $"l1Allergy.client_ds_id" === $"l2MapCDSFLG.client_ds_id",
        "inner")
      .join(tL2DictDCC,
        $"l1Allergy.dcc" === $"tL2DictDCC.dcc" && length(l1Allergy("l1Allergy.dcc")) === 5,
        "left_outer")
      .join(tL2DictPCC,
        $"l1Allergy.dcc" === $"tL2DictPCC.pcc" && length(l1Allergy("l1Allergy.dcc")) === 3,
        "left_outer")
      .join(tl1ClinicalEventEncounter,
        $"l1Allergy.client_id" === $"tl1ClinicalEventEncounter.client_id" &&
          $"l1Allergy.client_ds_id" === $"tl1ClinicalEventEncounter.client_ds_id" &&
          $"l1Allergy.encounterid" === $"tl1ClinicalEventEncounter.encounterid" &&
          $"l1Allergy.mpi" === $"tl1ClinicalEventEncounter.mpi",
        "left_outer")
      .join(l1MapAllergenType, $"l1Allergy.client_id" === $"l1MapAllergenType.client_id" &&
        $"l1Allergy.localallergentype" === $"l1MapAllergenType.local_code",
        "left_outer")
      .join(l1MapAllergen,
        $"l1Allergy.client_id" === $"l1MapAllergen.client_id" &&
          $"l1Allergy.localallergencd" === $"l1MapAllergen.local_code",
        "left_outer")
      .where(
        $"l1Allergy.mpi".isNotNull and
          ($"tL2DictDCC.dcc".isNotNull || $"tL2DictPCC.pcc".isNotNull) and
          $"l1Allergy.onset_dt" < plus1Day)
      .select(
        lit(0).cast(IntegerType).as("inferred_ind"),
        $"l1Allergy.client_id".as("client_id"),
        $"l1Allergy.mpi".as("mpi"),
        to_date(date_format($"l1Allergy.onset_dt", "yyyy-MM-dd")).cast(TimestampType).as("onset_dt"),
        $"tl1ClinicalEventEncounter.encounter_grp_num".alias("clinical_event_id"),
        coalesce($"l1MapAllergenType.CUI", when($"l1Allergy.localallergentype".isNotNull, "CH999990").otherwise("CH999999")).as("allergentype_cui"),
        coalesce($"l1MapAllergen.CUI", when($"l1Allergy.localallergencd".isNotNull, "CH999990").otherwise("CH999999")).as("allergencd_cui"),
        coalesce($"tL2DictDCC.sensitive_ind", $"tL2DictPCC.sensitive_ind", lit(0)).cast(IntegerType).as("sensitive_ind"),
        $"tL2DictDCC.dcc",
        $"l2MapCDSFLG.data_grp_flg",
        $"l2MapCDSFLG.client_ds_id",
        when(length(l1Allergy("l1Allergy.dcc")) === 5,$"tL2DictDCC.pcc").when(length(l1Allergy("l1Allergy.dcc")) === 3,$"tL2DictPCC.pcc").as("pcc")
      )
      .groupBy(
        $"client_id",
        $"mpi",
        $"onset_dt",
        $"clinical_event_id",
        $"allergentype_cui",
        $"allergencd_cui",
        $"tL2DictDCC.dcc",
        $"inferred_ind",
        $"pcc"
      )
      .agg(listagg($"l2MapCDSFLG.client_ds_id").as("cds_grp"), max("sensitive_ind").as("sensitive_ind"))

    val dfResult = l1AllergyMapping.withColumn("clinical_evt_key", coalesce($"clinical_event_id", lit(0))).
      withColumn("allergen_key", concat(coalesce($"dcc", $"pcc"), $"allergentype_cui", $"allergencd_cui"))
    dfResult
  }
}

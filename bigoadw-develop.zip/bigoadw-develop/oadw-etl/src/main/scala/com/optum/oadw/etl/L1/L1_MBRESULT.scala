
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_mbresult, mbresult}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MBRESULT extends TableInfo[l1_mbresult]{
  override def dependsOn: Set[String] = Set("MBRESULT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MBRESULT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mbresult = loadedDependencies("MBRESULT").as[mbresult]

    mbresult
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"facilityid",
			$"encounterid",
			$"patientid",
			$"mbprocorderid",
			$"mbprocresultid",
			$"dateavailable".as("available_dtm"),
			$"localresulstatus",
			$"localorganismcode",
			$"localorganismname",
			$"localorganismtype",
			$"localantibioticcode",
			$"localsensitivity",
			$"localsensitivity_value",
			$"localantibioticname",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"hts_result_status".as("result_status_cui"),
			$"hts_organism_found".as("organism_found_cui"),
			$"hts_org_exclude".as("org_exclude_cui"),
			$"hts_culture_growth".as("culture_growth_cui"),
			$"hts_culture_val".as("culture_val_cui"),
			$"hts_culture_unit".as("culture_unit_cui"),
			$"hts_sens_result".as("sens_result_cui"),
			$"hts_sens_antibiotic".as("sens_antibiotic_dcc"),
			$"antibiotic_loinc".as("antibiotic_loinc")
    )
  }
}


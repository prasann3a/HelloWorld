package com.optum.oadw.etl.L3


import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels._
import com.optum.oadw.oadw_ref.models.{l4_dict_prov_attrib, l3_map_prov_attrib_precur, l3_dict_prov_attrib_precur,
  l3_dict_elig_prov, l3_map_elig_prov_code}
import org.apache.spark.sql.functions.{lit, when}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object TEMP_PROVIDER_ATTRIBUTION_ALGORITHM_DATA extends TableInfo[precursorAlgorithmData] {
  override def name: String = "TEMP_PROVIDER_ATTRIBUTION_ALGORITHM_DATA"

  override def dependsOn: Set[String] = Set("REFERENCE_SCHEMA_L4_DICT_PROV_ATTRIB",
    "REFERENCE_SCHEMA_L3_MAP_PROV_ATTRIB_PRECUR", "REFERENCE_SCHEMA_L3_DICT_PROV_ATTRIB_PRECUR",
    "REFERENCE_SCHEMA_L3_DICT_ELIG_PROV", "L3_MAP_PROC_GROUP", "REFERENCE_SCHEMA_L3_MAP_ELIG_PROV_CODE")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL4DictProvAttrib = loadedDependencies("REFERENCE_SCHEMA_L4_DICT_PROV_ATTRIB").as[l4_dict_prov_attrib]
    val tL3MapProvAttribPrecur = loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PROV_ATTRIB_PRECUR").as[l3_map_prov_attrib_precur]
    val tL3DictProvAttribPrecur = loadedDependencies("REFERENCE_SCHEMA_L3_DICT_PROV_ATTRIB_PRECUR").as[l3_dict_prov_attrib_precur]

    val tL3DictEligProv = loadedDependencies("REFERENCE_SCHEMA_L3_DICT_ELIG_PROV").as[l3_dict_elig_prov]
    val tL3MapProcGroup = loadedDependencies("L3_MAP_PROC_GROUP").as[l3_map_proc_group]
    val tL3MapEligProvCode = loadedDependencies("REFERENCE_SCHEMA_L3_MAP_ELIG_PROV_CODE").as[l3_map_elig_prov_code]

    createDistinctActiveProviderAttributionPrecursors(sparkSession, tL4DictProvAttrib, tL3MapProvAttribPrecur,
      tL3DictProvAttribPrecur, tL3DictEligProv, tL3MapProcGroup, tL3MapEligProvCode).toDF()
  }

  private def createDistinctActiveProviderAttributionPrecursors(sparkSession: SparkSession,
                                                                tL4DictProvAttrib: Dataset[l4_dict_prov_attrib],
                                                                tL3MapProvAttribPrecur: Dataset[l3_map_prov_attrib_precur],
                                                                tL3DictProvAttribPrecur: Dataset[l3_dict_prov_attrib_precur],
                                                                tL3DictEligProv: Dataset[l3_dict_elig_prov],
                                                                tL3MapProcGroup: Dataset[l3_map_proc_group],
                                                                tL3MapEligProvCode: Dataset[l3_map_elig_prov_code]): Dataset[precursorAlgorithmData] = {
    import sparkSession.implicits._

    tL3DictProvAttribPrecur.select($"ACTIVE_IND", $"PROV_ATTRIB_PRECURSOR_ID", $"PROC_GROUP_ID", $"ELIG_PROV_ID",
      $"LOOKBACK_MONTHS", $"PROV_ATTRIB_PRECUR_TYPE_ID", $"ELIG_SOURCE_TYPE_FLG", $"NUM_YR_MONTHS")
      .as("dict")
      .join(tL3MapProvAttribPrecur.select($"PROV_ATTRIB_PRECURSOR_ID", $"PROV_ATTRIB_ID").as("mpap"), Seq("PROV_ATTRIB_PRECURSOR_ID"), "left_outer")
      .join(tL4DictProvAttrib.select($"ACTIVE_IND", $"PRECALC_IND", $"PROV_ATTRIB_ID", $"NUM_YR_MONTHS", $"FOR_EACH_CDS_IND")
        .as("l4dict"), $"l4dict.ACTIVE_IND" === lit(1) and $"l4dict.PRECALC_IND" === lit(0) and $"l4dict.PROV_ATTRIB_ID" === $"mpap.PROV_ATTRIB_ID", "left_outer")
      .where(($"l4dict.ACTIVE_IND" === lit(1) and $"l4dict.PRECALC_IND" === lit(0)) or $"dict.ACTIVE_IND" === lit(1))
      .select(
        $"dict.PROV_ATTRIB_PRECURSOR_ID", $"dict.PROC_GROUP_ID", $"dict.ELIG_PROV_ID", $"dict.LOOKBACK_MONTHS",
        $"dict.PROV_ATTRIB_PRECUR_TYPE_ID", $"dict.ELIG_SOURCE_TYPE_FLG",
        when($"l4dict.ACTIVE_IND" === lit(1) and $"l4dict.PRECALC_IND" === lit(0), $"l4dict.FOR_EACH_CDS_IND").otherwise(lit(0)).as("FOR_EACH_CDS_IND"),
        when($"dict.ACTIVE_IND" === lit(1) and $"l4dict.ACTIVE_IND" === lit(0), $"dict.NUM_YR_MONTHS")
          .when($"dict.ACTIVE_IND" === lit(0) and $"l4dict.ACTIVE_IND" === lit(1), $"l4dict.NUM_YR_MONTHS")
          .when($"dict.NUM_YR_MONTHS" > $"l4dict.NUM_YR_MONTHS" or $"l4dict.NUM_YR_MONTHS".isNull, $"dict.NUM_YR_MONTHS")
          .otherwise($"l4dict.NUM_YR_MONTHS").as("NUM_YR_MONTHS")
      ).distinct()
      .join(tL3DictEligProv.select($"ELIG_PROV_ID", $"DOMESTIC_ONLY_IND").as("elig"), $"dict.ELIG_PROV_ID" === $"elig.ELIG_PROV_ID")
      .join(tL3MapProcGroup.select($"proc_GROUP_id", $"PROC_CD", $"CODE_TYPE").as("mpg"), $"dict.proc_GROUP_id" === $"mpg.proc_GROUP_id", "left_outer")
      .join(tL3MapEligProvCode.select($"ELIG_PROV_ID", $"CODE_TYPE", $"CODE").where($"CODE_TYPE" === lit("POS")).as("mepc"), $"dict.ELIG_PROV_ID" === $"mepc.ELIG_PROV_ID", "left_outer")
      .select(
        $"dict.PROV_ATTRIB_PRECURSOR_ID", $"dict.PROC_GROUP_ID", $"dict.ELIG_PROV_ID", $"dict.LOOKBACK_MONTHS",
        $"dict.PROV_ATTRIB_PRECUR_TYPE_ID", $"dict.ELIG_SOURCE_TYPE_FLG",
        $"FOR_EACH_CDS_IND", $"NUM_YR_MONTHS",
        $"elig.DOMESTIC_ONLY_IND",
        $"mpg.PROC_CD", $"mpg.CODE_TYPE",
        $"mepc.CODE"
      ).as[precursorAlgorithmData]
  }
}

case class precursorAlgorithmData(prov_attrib_precursor_id: java.lang.Integer, proc_group_id: java.lang.Integer, elig_prov_id: Int,
                                  lookback_months: Int, prov_attrib_precur_type_id: Int,
                                  elig_source_type_flg: Int, for_each_cds_ind: Int, num_yr_months: Int,
                                  domestic_only_ind: Integer, proc_cd: String, code_type: String, code: java.lang.Long)

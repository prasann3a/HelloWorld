
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_bpo_member_detail_ii, pp_bpo_member_detail_ii}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_BPO_MEMBER_DETAIL_II extends TableInfo[l1_bpo_member_detail_ii]{
  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL_II")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_BPO_MEMBER_DETAIL_II"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ppBpoMemberDetailIi = loadedDependencies("PP_BPO_MEMBER_DETAIL_II").as[pp_bpo_member_detail_ii]

    ppBpoMemberDetailIi
    .select(
			$"at_risk_status",
			$"benefitplan",
			$"contract_id",
			$"contracttype",
			$"coveragestatus",
			$"cust_mem_attr1",
			$"cust_mem_attr2",
			$"cust_mem_attr3",
			$"cust_mem_attr4",
			$"cust_mem_attr5",
			$"cust_mem_attr6",
			$"cust_mem_attr7",
			$"cust_mem_attr8",
			$"cust_mem_attr9",
			$"cust_mem_attr10",
			$"cust_mem_attr11",
			$"cust_mem_attr12",
			$"cust_mem_attr13",
			$"cust_mem_attr14",
			$"cust_mem_attr15",
			$"cust_mem_attr16",
			$"cust_mem_attr17",
			$"cust_mem_attr18",
			$"cust_mem_attr19",
			$"cust_mem_attr20",
			$"date_of_death",
			$"deceased_flag",
			$"dental_benefit",
			$"dob",
			$"ecds_flag",
			$"effectivedate".as("eff_dt"),
			$"emp_acct_id",
			$"employee_type",
			$"employeraccountid",
			$"enddate".as("end_dt"),
			$"ethnicity",
			$"gender",
			$"groupid".as("client_id"),
			$"healthplansource",
			$"hra_ind",
			$"hsa_ind",
			$"lineofbusinessid",
			$"medical",
			$"memberid".as("mpi"),
			$"mem_userdef_1",
			$"mem_userdef_2",
			$"mem_userdef_3",
			$"mem_userdef_4",
			$"mentalhealth",
			$"other_language",
			$"pcpid",
			$"pcp_affil",
			$"primary_coverage_flag",
			$"productcode",
			$"product_dtl_code",
			$"race",
			$"risk_type",
			$"sec_member_id_1",
			$"sec_member_id_2",
			$"spoken_language",
			$"subscriberflag",
			$"subscriberid",
			$"written_language"
    )
  }
}


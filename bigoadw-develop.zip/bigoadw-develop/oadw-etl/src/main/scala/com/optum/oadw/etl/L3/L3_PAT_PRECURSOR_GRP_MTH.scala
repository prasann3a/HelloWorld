package com.optum.oadw.etl.L3

import com.optum.oadw.oadwModels.{l3_map_precursor_grp, l3_pat_precursor, l3_pat_precursor_grp_mth}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.definedfunctions.ListAggFunction
import com.optum.oadw.oadw_ref.models.l4_dict_precursor_grp
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.{IntegerType, LongType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L3_PAT_PRECURSOR_GRP_MTH extends TableInfo[l3_pat_precursor_grp_mth] {
  override def name: String = "L3_PAT_PRECURSOR_GRP_MTH"

  override def dependsOn: Set[String] = Set("L3_PAT_PRECURSOR", "L3_MAP_PRECURSOR_GRP", "REFERENCE_SCHEMA_L4_DICT_PRECURSOR_GRP")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL3PatPrecursor = loadedDependencies("L3_PAT_PRECURSOR").as[l3_pat_precursor].alias("p")
    val tL3MapPrecursorGrp = broadcast(loadedDependencies("L3_MAP_PRECURSOR_GRP").as[l3_map_precursor_grp]).alias("mp")
    val tL4DictPrecursorGrp = broadcast(loadedDependencies("REFERENCE_SCHEMA_L4_DICT_PRECURSOR_GRP").as[l4_dict_precursor_grp]).alias("d")

    val window = Window
      .partitionBy($"p.client_id", $"mp.precursor_grp_id", $"p.mpi", $"p.precursor_id", date_format($"p.precursor_dtm", "yyyyMM").cast(IntegerType))
      .orderBy($"p.precursor_dtm".desc, $"p.sensitive_ind".asc, $"p.precursor_type".asc, $"p.precursor_value".desc)

    val tempDf = tL3PatPrecursor
      .join(tL3MapPrecursorGrp, $"p.precursor_id" === $"mp.precursor_id", "inner")
      .join(tL4DictPrecursorGrp, $"mp.precursor_grp_id" === $"d.precursor_grp_id", "inner")
      .select(
        $"p.*",
        $"mp.precursor_grp_id",
        $"d.sensitive_ind".as("d_sensitive_ind"),
        date_format($"precursor_dtm", "yyyyMM").cast(IntegerType).as("yr_month"),
        when (
          rank().over(window) === lit(1), lit(1)
        ).otherwise(lit(0)).as("ranking")
      )

    tempDf
      .groupBy($"client_id", $"mpi", $"precursor_grp_id", $"yr_month", $"precursor_id")
      .agg (
        min(to_date(date_format($"precursor_dtm", "yyyy-MM-dd"))).as("min_dt"),
        max(to_date(date_format($"precursor_dtm", "yyyy-MM-dd"))).as("max_dt"),
        max(when($"ranking" === lit(1), $"precursor_domain").otherwise(null)).as("precursor_domain"),
        max(when($"ranking" === lit(1), $"precursor_type").otherwise(null)).as("precursor_type"),
        max(when($"ranking" === lit(1), $"precursor_value").otherwise(null)).as("precursor_value"),
        ListAggFunction.listAgg($"precursor_cds_grp").as("precursor_cds_grp"),
        greatest(max(when($"ranking" === lit(1), $"sensitive_ind").otherwise(null)), max($"d_sensitive_ind")).as("sensitive_ind")
      )
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_facility, zh_facility}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_FACILITY extends TableInfo[l1_facility]{
  override def dependsOn: Set[String] = Set("ZH_FACILITY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_FACILITY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("ZH_FACILITY").as[zh_facility]

    cdrTbl
    .select(
		$"groupid".as("client_id"),
		$"facilityid",
		$"facilityname",
		$"facilitypostalcd",
		$"localfacilitytype",
		$"charge_cost_ratio",
		$"client_ds_id",
		$"npi",
		$"specialty"
    )
  }
}


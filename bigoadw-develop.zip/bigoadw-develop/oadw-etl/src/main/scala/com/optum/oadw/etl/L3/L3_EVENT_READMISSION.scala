package com.optum.oadw.etl.L3

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels._
import com.optum.oadw.utils.DataframeExtensions._
import com.optum.oadw.common.models.OADWRuntimeVariables
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.sql.functions.lit

object L3_EVENT_READMISSION extends TableInfo[l3_event_readmission] {
  override def name: String = "L3_EVENT_READMISSION"

  override def dependsOn: Set[String] = Set("L2_PAT_CLINICAL_EVENT", "L3_MAP_READMISSION","L2_MAP_APR_DRG","L2_II_CONFINEMENTS","L2_II_MAP_DRG","L2_MAP_DRG","TEMP_II_DAYS_ELIG","L2_DICT_DIAG","L2_DICT_PROC", "L1_ENCOUNTER_GRP_REL", "L2_II_MAP_TOS")

  def directoryLevel: String = "L3"

  override def partitions: Int = 256

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL2PatClinicalEvent = loadedDependencies("L2_PAT_CLINICAL_EVENT").as[l2_pat_clinical_event]
    val l3MapReadmission = loadedDependencies("L3_MAP_READMISSION").as[l3_map_readmission]
    val tL2MapAprDrg = loadedDependencies("L2_MAP_APR_DRG").as[l2_map_apr_drg]
    val l2IIConfinements = loadedDependencies("L2_II_CONFINEMENTS").as[l2_ii_confinements] //castToDouble(Set("amt_pay_cf", "amt_eqv_cf"))
    val tL2IIMapDrg = loadedDependencies("L2_II_MAP_DRG").as[l2_ii_map_drg]
    val tL2MapDrg = loadedDependencies("L2_MAP_DRG").castToBigDecimal(Set("drg_alos", "drg_gelos", "drg_weight")).as[l2_map_drg]
    val tempIIDaysElig = loadedDependencies("TEMP_II_DAYS_ELIG")
    val tL2DictDiag = loadedDependencies("L2_DICT_DIAG").as[l2_dict_diag]
    val tL2DictProc = loadedDependencies("L2_DICT_PROC").as[l2_dict_proc]
    val l1EncounterGrpRel = loadedDependencies("L1_ENCOUNTER_GRP_REL").as[l1_encounter_grp_rel]
    val l2IIMapTos = loadedDependencies("L2_II_MAP_TOS").as[l2_ii_map_tos]

    val clientId = OADWRuntimeVariables(runtimeVariables).clientId

    val iiReadmission = getIIEventReadmission(sparkSession, l3MapReadmission, tL2MapAprDrg, l2IIConfinements, tL2IIMapDrg, tL2MapDrg, tempIIDaysElig, tL2DictDiag, tL2DictProc, l2IIMapTos, clientId)
    val ceReadmission = getCEEventReadmission(sparkSession, tL2PatClinicalEvent, l1EncounterGrpRel, l3MapReadmission)
    val emVisit = getEMVisitInfo(sparkSession, ceReadmission)

    iiReadmission
      .union(emVisit)
      .toDF()
  }

  private def getEMVisitInfo(sparkSession: SparkSession,
                             ceReadmission: DataFrame): DataFrame = {

    import sparkSession.implicits._

    ceReadmission.as("ce").select($"ce.*")
  }

  private def getIIEventReadmission(sparkSession: SparkSession,
                                    l3MapReadmission: Dataset[l3_map_readmission],
                                    tL2MapAprDrg: Dataset[l2_map_apr_drg],
                                    l2IIConfinements: Dataset[l2_ii_confinements],
                                    tL2IIMapDrg: Dataset[l2_ii_map_drg],
                                    tL2MapDrg: Dataset[l2_map_drg],
                                    tempIIDaysElig: DataFrame,
                                    tL2DictDiag: Dataset[l2_dict_diag],
                                    tL2DictProc: Dataset[l2_dict_proc],
                                    l2IIMapTos : Dataset[l2_ii_map_tos],
                                    clientId: String): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempMsDrg = tL2IIMapDrg.as("iidrg")
      .join(tL2MapDrg.as("drg"), $"iidrg.drg_code" === $"drg.drg_cd" && $"iidrg.drg_version" === lit("MS") && $"drg.drg_type_cui" === lit("CH001334"), "left_outer")
      .select(
        $"iidrg.drg_id".as("ii_drg_id"),
        $"drg.drg_id".as("readm_drg_id"),
        $"drg.sensitive_ind".as("readm_drg_sensitive_ind")
      )

    // ToDo same as tempMsDrg
    val tempIIDrg = tL2IIMapDrg.as("iidrg")
      .join(tL2MapDrg.as("drg"), $"iidrg.drg_code" === $"drg.drg_cd" && $"iidrg.drg_version" === lit("MS") && $"drg.drg_type_cui" === lit("CH001334"), "left_outer")
      .select(
        $"iidrg.drg_id".as("ii_drg_id"),
        $"drg.drg_id".as("idx_drg_id"),
        $"drg.sensitive_ind".as("idx_drg_sensitive_ind")
      )

    val tempMapAprDrg = tL2IIMapDrg.as("iidrg")
      .join(tL2MapAprDrg.as("adrg"), $"iidrg.drg_code" === $"adrg.apr_drg_cd" && $"iidrg.drg_version" === lit("APR") && $"adrg.apr_drg_sev" === lit(0) && $"adrg.apr_drg_risk" === lit(0), "left_outer")
      .select(
        $"iidrg.drg_id".as("ii_drg_id"),
        $"adrg.apr_drg_id".as("idx_apr_drg_id"),
        $"adrg.sensitive_ind".as("idx_apr_drg_sensitive_ind")
      )

    // ToDo same as tempMapAprDrg
    val tempIIMapAprDrg = tL2IIMapDrg.as("iidrg")
      .join(tL2MapAprDrg.as("adrg"), $"iidrg.drg_code" === $"adrg.apr_drg_cd" && $"iidrg.drg_version" === lit("APR") && $"adrg.apr_drg_sev" === lit(0) && $"adrg.apr_drg_risk" === lit(0), "left_outer")
      .select(
        $"iidrg.drg_id".as("ii_drg_id"),
        $"adrg.apr_drg_id".as("readm_apr_drg_id"),
        $"adrg.sensitive_ind".as("readm_apr_drg_sensitive_ind")
      )

    val tL2IIConfinementsReadm = l2IIConfinements
      .withColumnRenamed("provider_id", "provider_id_readm")
      .withColumnRenamed("conf_num", "conf_num_readm")
      .withColumnRenamed("diag1", "diag1_readm")
      .withColumnRenamed("icd_version", "icd_version_readm")
      .withColumnRenamed("drg_id", "drg_id_readm")
      .withColumnRenamed("beg_dt", "beg_dt_readm")
      .select($"provider_id_readm", $"conf_num_readm", $"diag1_readm", $"icd_version_readm", $"drg_id_readm", $"beg_dt_readm")


    l2IIConfinements.as("idx")
      .join(l3MapReadmission.as("mr"), $"mr.readmission_domain" === "II" and $"idx.tos_i_5" === $"mr.tos_i_5")
      .join(tL2DictDiag.as("dx"), $"idx.diag1" === regexp_replace($"dx.diag_cd", "\\.", "") && $"dx.code_type" === when($"idx.icd_version" === lit(0), lit("ICD10")).otherwise(when($"idx.icd_version" === lit(9), lit("ICD9")).otherwise("UNKNOWN")), "left_outer")
      .join(tL2DictProc.as("px"), $"idx.iproc1" === regexp_replace($"px.proc_cd", "\\.", "") && $"px.code_type" === when($"idx.icd_version" === lit(0), lit("ICD10")).otherwise(when($"idx.icd_version" === lit(9), lit("ICD9")).otherwise("UNKNOWN")), "left_outer")
      .join(broadcast(tempIIDrg).as("iidrg"), $"idx.drg_id" === $"iidrg.ii_drg_id", "left_outer")
      .join(broadcast(tempMapAprDrg).as("iidrg3"), $"idx.drg_id" === $"iidrg3.ii_drg_id", "left_outer")
      .join(tL2IIConfinementsReadm.as("readm"), $"idx.readmit_conf_90" === $"readm.conf_num_readm", "left_outer")
      .join(tL2DictDiag.as("dx2"), $"readm.diag1_readm" === regexp_replace($"dx2.diag_cd", "\\.", "") && $"dx2.code_type" === when($"readm.icd_version_readm" === lit(0), lit("ICD10")).otherwise(when($"readm.icd_version_readm" === lit(9), lit("ICD9")).otherwise("UNKNOWN")), "left_outer")
      .join(broadcast(tempMsDrg).as("iidrg2"), $"readm.drg_id_readm" === $"iidrg2.ii_drg_id", "left_outer")
      .join(broadcast(tempIIMapAprDrg).as("iidrg4"), $"readm.drg_id_readm" === $"iidrg4.ii_drg_id", "left_outer")
      .join(tempIIDaysElig.as("elig"), $"idx.conf_num" === $"elig.conf_num", "left_outer")
      .join(l2IIMapTos.as("tos"), $"idx.tos_i_5" === $"tos.tos_i_5", "left_outer")
      .where($"idx.readmit_index_07" === lit(true) && length($"idx.member") <= 20)
      .select(
        lit(clientId).as("client_id")
        , $"idx.member".as("mpi")
        , lit("II").as("event_set_cd")
        , $"idx.conf_num".as("idx_event_id")
        , $"mr.readmission_type_cui"
        , expr("nvl2(readm.conf_num_readm, datediff(cast(TO_DATE(date_format(readm.beg_dt_readm, 'yyyy-MM-dd')) as timestamp), cast(TO_DATE(date_format(idx.end_dt, 'yyyy-MM-dd')) as timestamp)) ,null)").as("days_to_readmit")
        , $"idx.end_dt".as("idx_end_dtm")
        , lit(null).as("idx_hosp_site_id")
        , $"idx.provider_id".as("idx_prov_id")
        , $"idx_drg_id"
        , when($"iidrg.idx_drg_sensitive_ind".isNull, lit(0)).otherwise($"iidrg.idx_drg_sensitive_ind").as("idx_drg_sensitive_ind")
        , $"idx_apr_drg_id"
        , when($"iidrg3.idx_apr_drg_sensitive_ind".isNull, lit(0)).otherwise($"iidrg3.idx_apr_drg_sensitive_ind").as("idx_apr_drg_sensitive_ind")
        , when($"idx.diag1".isNull, lit(null)).otherwise(expr("nvl(dx.code_type, 'UNKNOWN')")).as("idx_prindx_codetype")
        , $"idx.diag1".as("idx_prindx")
        , when($"idx.diag1".isNull, lit(0)).otherwise(expr("nvl(dx.sensitive_ind,1)")).as("idx_prindx_sensitive_ind")
        , when($"idx.iproc1".isNull, lit(null)).otherwise(expr("nvl(px.code_type,'UNKNOWN')")).as("idx_prinpx_codetype")
        , $"idx.iproc1".as("idx_prinpx")
        , when($"idx.iproc1".isNull, lit(0)).otherwise(expr("nvl(px.sensitive_ind,1)")).as("idx_prinpx_sensitive_ind")
        , lit(null).as("idx_disch_prov_id")
        , lit("0").as("idx_cds_grp")
        , when($"days_elig" > 90, lit(90)).otherwise(expr("nvl(days_elig,0)")).cast(IntegerType).as("elig_days")
        , when($"idx.readmit_index_30" === lit(true), lit(1)).otherwise(lit(0)).as("elig_30_ind")
        , when($"idx.readmit_30" === lit(true), lit(1)).otherwise(lit(0)).as("readm_30_ind")
        , when($"idx.readmit_index_60" === lit(true), lit(1)).otherwise(lit(0)).as("elig_60_ind")
        , when($"idx.readmit_60" === lit(true), lit(1)).otherwise(lit(0)).as("readm_60_ind")
        , when($"idx.readmit_index_90" === lit(true), lit(1)).otherwise(lit(0)).as("elig_90_ind")
        , when($"idx.readmit_90" === lit(true), lit(1)).otherwise(lit(0)).as("readm_90_ind")
        , $"readm.conf_num_readm".as("readm_event_id")
        , $"readm.beg_dt_readm".as("readm_start_dtm")
        , lit(null).as("readm_hosp_site_id")
        , $"readm.provider_id_readm".as("readm_prov_id")
        , $"readm_drg_id"
        , when($"iidrg2.readm_drg_sensitive_ind".isNull, lit(0)).otherwise($"iidrg2.readm_drg_sensitive_ind").as("readm_drg_sensitive_ind")
        , $"readm_apr_drg_id"
        , when($"iidrg4.readm_apr_drg_sensitive_ind".isNull, lit(0)).otherwise($"iidrg4.readm_apr_drg_sensitive_ind").as("readm_apr_drg_sensitive_ind")
        , when($"readm.diag1_readm".isNull, lit(null)).otherwise(expr("nvl(dx2.code_type,'UNKNOWN')")).as("readm_prindx_codetype")
        , $"readm.diag1_readm".as("readm_prindx")
        , when($"readm.diag1_readm".isNull, lit(0)).otherwise(expr("nvl(dx2.sensitive_ind,1)")).as("readm_prindx_sensitive_ind")
        , lit("0").as("readm_cds_grp")
        , when($"tos.sensitive_ind".isNull, lit(0)).otherwise($"tos.sensitive_ind").as("sensitive_ind")
      )
  }


  private def getCEEventReadmission(sparkSession: SparkSession,
                                    tL2PatClinicalEvent: Dataset[l2_pat_clinical_event],
                                    l1EncounterGrpRel: Dataset[l1_encounter_grp_rel],
                                    l3MapReadmission: Dataset[l3_map_readmission]): DataFrame = {

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatClinicalEventReadm = tL2PatClinicalEvent.toDF()
      .withColumnRenamed("clinical_event_id", "clinical_event_id_readm")
      .withColumnRenamed("evt_start_dtm", "evt_start_dtm_readm")
      .withColumnRenamed("hosp_site_id", "hosp_site_id_readm")
      .withColumnRenamed("drg_id", "drg_id_readm")
      .withColumnRenamed("drg_sensitive_ind", "readm_drg_sensitive_ind")
      .withColumnRenamed("apr_drg_id", "apr_drg_id_readm")
      .withColumnRenamed("apr_drg_sensitive_ind", "readm_apr_drg_sensitive_ind")
      .withColumnRenamed("prindx_codetype", "prindx_codetype_readm")
      .withColumnRenamed("prindx", "prindx_readm")
      .withColumnRenamed("prindx_sensitive_ind", "prindx_sensitive_ind_readm")
      .withColumnRenamed("cds_grp", "cds_grp_readm")
      .select($"clinical_event_id_readm", $"evt_start_dtm_readm", $"hosp_site_id_readm",
          $"drg_id_readm", $"apr_drg_id_readm", $"prindx_codetype_readm",
          $"prindx_readm", $"prindx_sensitive_ind_readm", $"cds_grp_readm", $"readm_drg_sensitive_ind", $"readm_apr_drg_sensitive_ind")

    val l1EncounterGrpRelDedup = l1EncounterGrpRel
      .groupBy($"encounter_grp_rel_type", $"rel_encounter_grp_num")
      .agg(max($"encounter_grp_num").as("encounter_grp_num_max"))

    tL2PatClinicalEvent.as("idx")
      .join(l3MapReadmission.as("mr"), $"mr.readmission_domain" === lit("CMS") && $"idx.event_type_cui" === $"mr.event_type_cui")
      .join(l1EncounterGrpRelDedup.as("rel"), $"idx.clinical_event_id" === $"rel.encounter_grp_num_max" && $"mr.readmission_type_cui" === $"rel.encounter_grp_rel_type", "left_outer")
      .join(tL2PatClinicalEventReadm.as("readm"), $"rel.rel_encounter_grp_num" === $"readm.clinical_event_id_readm"
        && datediff(to_date(date_format($"readm.evt_start_dtm_readm", "yyyy-MM-dd")), to_date(date_format($"idx.evt_end_dtm", "yyyy-MM-dd"))).between(0, 90), "left_outer")
      .where($"idx.cms_include_ind" === lit(1))
      .select(
        $"idx.client_id".as("client_id")
        , $"idx.mpi".as("mpi")
        , lit("CE").as("event_set_cd")
        , $"idx.clinical_event_id".as("idx_event_id")
        , $"mr.readmission_type_cui".as("readmission_type_cui")
        , expr("nvl2(readm.clinical_event_id_readm, datediff(cast(TO_DATE(date_format(readm.evt_start_dtm_readm, 'yyyy-MM-dd')) as timestamp), cast(TO_DATE(date_format(idx.evt_end_dtm, 'yyyy-MM-dd')) as timestamp)) ,null)").as("days_to_readmit")
        , $"idx.evt_end_dtm".as("idx_end_dtm")
        , $"idx.hosp_site_id".as("idx_hosp_site_id")
        , lit(null).as("idx_prov_id")
        , $"idx.drg_id".as("idx_drg_id")
        , when($"idx.drg_sensitive_ind".isNull, lit(0)).otherwise($"idx.drg_sensitive_ind").as("idx_drg_sensitive_ind")
        , $"idx.apr_drg_id".as("idx_apr_drg_id")
        , when($"idx.apr_drg_sensitive_ind".isNull, lit(0)).otherwise($"idx.apr_drg_sensitive_ind").as("idx_apr_drg_sensitive_ind")
        , $"idx.prindx_codetype".as("idx_prindx_codetype")
        , $"idx.prindx".as("idx_prindx")
        , $"idx.prindx_sensitive_ind".as("idx_prindx_sensitive_ind")
        , $"idx.prinpx_codetype".as("idx_prinpx_codetype")
        , $"idx.prinpx".as("idx_prinpx")
        , $"idx.prinpx_sensitive_ind".as("idx_prinpx_sensitive_ind")
        , $"idx.disch_prov_id".as("idx_disch_prov_id")
        , $"idx.cds_grp".as("idx_cds_grp")
        , lit(90).cast(IntegerType).as("elig_days")
        , lit(1).as("elig_30_ind")
        , when($"readm.clinical_event_id_readm".isNotNull && datediff(to_date(date_format($"readm.evt_start_dtm_readm", "yyyy-MM-dd")), to_date(date_format($"idx.evt_end_dtm", "yyyy-MM-dd"))) <= lit(30), lit(1)).otherwise(lit(0)).as("readm_30_ind")
        , lit(1).as("elig_60_ind")
        , when($"readm.clinical_event_id_readm".isNotNull && datediff(to_date(date_format($"readm.evt_start_dtm_readm", "yyyy-MM-dd")), to_date(date_format($"idx.evt_end_dtm", "yyyy-MM-dd"))) <= lit(60), lit(1)).otherwise(lit(0)).as("readm_60_ind")
        , lit(1).as("elig_90_ind")
        , when($"readm.clinical_event_id_readm".isNotNull && datediff(to_date(date_format($"readm.evt_start_dtm_readm", "yyyy-MM-dd")), to_date(date_format($"idx.evt_end_dtm", "yyyy-MM-dd"))) <= lit(90), lit(1)).otherwise(lit(0)).as("readm_90_ind")
        , $"readm.clinical_event_id_readm".as("readm_event_id")
        , $"readm.evt_start_dtm_readm".as("readm_start_dtm")
        , $"readm.hosp_site_id_readm".as("readm_hosp_site_id")
        , lit(null).as("readm_prov_id")
        , $"readm.drg_id_readm".as("readm_drg_id")
        , when($"readm.readm_drg_sensitive_ind".isNull, lit(0)).otherwise($"readm.readm_drg_sensitive_ind").as("readm_drg_sensitive_ind")
        , $"readm.apr_drg_id_readm".as("readm_apr_drg_id")
        , when($"readm.readm_apr_drg_sensitive_ind".isNull, lit(0)).otherwise($"readm.readm_apr_drg_sensitive_ind").as("readm_apr_drg_sensitive_ind")
        , $"readm.prindx_codetype_readm".as("readm_prindx_codetype")
        , $"readm.prindx_readm".as("readm_prindx")
        , when($"readm.prindx_sensitive_ind_readm".isNull, lit(0)).otherwise($"readm.prindx_sensitive_ind_readm").as("readm_prindx_sensitive_ind")
        , $"readm.cds_grp_readm".as("readm_cds_grp")
        , when($"idx.sensitive_ind".isNull, lit(0)).otherwise($"idx.sensitive_ind").as("sensitive_ind")
      )

  }
}

case class event_readmission(client_id: String = null, mpi: String = null, idx_end_dtm: java.sql.Timestamp = null)
case class event_readmission_proc(client_id: String = null, mpi: String = null, idx_end_dtm: java.sql.Timestamp = null, idx_prinpx: String = null, idx_prinpx_codetype: String = null, proc_dtm: java.sql.Timestamp = null, prov_id: String = null)


/*
SELECT  '{{CLIENT_ID}}'
,idx.member as mpi
,'II' as event_set_cd
,idx.conf_num as idx_event_id
,mr.readmission_type_cui
,nvl2(readm.conf_num, datediff(cast(TO_DATE(date_format(readm.beg_dt, 'yyyy-MM-dd')) as timestamp), cast(TO_DATE(date_format(idx.end_dt, 'yyyy-MM-dd')) as timestamp)) ,null) days_to_readmit
,idx.end_dt as idx_end_dtm
,null as idx_hosp_site_id
,idx.provider_id as idx_prov_id
,idx_drg_id
,idx_apr_drg_id
,CASE WHEN idx.diag1 IS NULL THEN NULL ELSE nvl(dx.code_type,'UNKNOWN') END AS idx_prindx_codetype
,idx.diag1 as idx_prindx
,CASE WHEN idx.diag1 IS NULL THEN 0 ELSE nvl(dx.sensitive_ind,1) END AS idx_prindx_sensitive_ind
,CASE WHEN idx.iproc1 IS NULL THEN NULL ELSE nvl(px.code_type,'UNKNOWN') END AS idx_prinpx_codetype
,idx.iproc1 as idx_prinpx
,CASE WHEN idx.iproc1 IS NULL THEN 0 ELSE nvl(px.sensitive_ind,1) END AS idx_prinpx_sensitive_ind
,null as idx_disch_prov_id
,CASE WHEN days_elig > 90 then cast(90 as int) else cast(nvl(days_elig,0) as int) END AS elig_days
,idx.readmit_index_30 as elig_30
,idx.readmit_30 as readm_30
,idx.readmit_index_60 as elig_60
,idx.readmit_60 as readm_60
,idx.readmit_index_90 as elig_90
,idx.readmit_90 as readm_90
,readm.conf_num as readm_event_id
,readm.beg_dt as readm_admit_dtm
,null as readm_hosp_site_id
,readm.provider_id as readm_prov_id
,readm_drg_id
,readm_apr_drg_id
,CASE WHEN readm.diag1 IS NULL THEN NULL ELSE nvl(dx2.code_type,'UNKNOWN') END AS readm_prindx_codetype
,readm.diag1 as readm_prindx
,CASE WHEN readm.diag1 IS NULL THEN 0 ELSE nvl(dx2.sensitive_ind,1) END AS readm_prindx_sensitive_ind
FROM L2_II_CONFINEMENTS idx
JOIN L3_MAP_READMISSION mr ON (mr.readmission_domain = 'II' and idx.tos_i_5 = mr. tos_i_5)
LEFT OUTER JOIN L2_DICT_DIAG dx ON (idx.diag1 =  REGEXP_REPLACE (dx.diag_cd, '\\.', '')  and dx.code_type = CASE WHEN idx.icd_version = 0 then 'ICD10' when idx.icd_version = 9 then 'ICD9' else 'UNKNOWN' end)
LEFT OUTER JOIN L2_DICT_PROC px ON (idx.iproc1 =  REGEXP_REPLACE (px.proc_cd, '\\.', '')  and px.code_type = CASE WHEN idx.icd_version = 0 then 'ICD10' when idx.icd_version = 9 then 'ICD9' else 'UNKNOWN' end)
LEFT OUTER JOIN (SELECT iidrg.drg_id as ii_drg_id,drg.drg_id as idx_drg_id from L2_II_MAP_DRG iidrg
LEFT OUTER JOIN L2_MAP_DRG drg ON (iidrg.drg_code = drg.drg_cd and iidrg.drg_version = 'MS' and drg.drg_type_cui = 'CH001334')
) iidrg ON (idx.drg_id = iidrg.ii_drg_id)
LEFT OUTER JOIN (SELECT iidrg.drg_id as ii_drg_id,adrg.apr_drg_id as idx_apr_drg_id from L2_II_MAP_DRG iidrg
LEFT OUTER JOIN L2_MAP_APR_DRG adrg ON (iidrg.drg_code = adrg.apr_drg_cd and iidrg.drg_version = 'APR' and adrg.apr_drg_sev = 0 and adrg.apr_drg_risk = 0)
) iidrg3 ON (idx.drg_id = iidrg3.ii_drg_id)
LEFT OUTER JOIN L2_II_CONFINEMENTS readm ON (idx.readmit_conf_90 = readm.conf_num)
LEFT OUTER JOIN L2_DICT_DIAG dx2 ON (readm.diag1 =  REGEXP_REPLACE (dx2.diag_cd, '\\.', '')  and dx2.code_type = CASE WHEN readm.icd_version = 0 then 'ICD10' when readm.icd_version = 9 then 'ICD9' else 'UNKNOWN' end)
LEFT OUTER JOIN (SELECT iidrg.drg_id as ii_drg_id,drg.drg_id as readm_drg_id from L2_II_MAP_DRG iidrg
LEFT OUTER JOIN L2_MAP_DRG drg ON (iidrg.drg_code = drg.drg_cd and iidrg.drg_version = 'MS' and drg.drg_type_cui = 'CH001334')
) iidrg2 ON (readm.drg_id = iidrg2.ii_drg_id)
LEFT OUTER JOIN (SELECT iidrg.drg_id as ii_drg_id,adrg.apr_drg_id as readm_apr_drg_id from L2_II_MAP_DRG iidrg
LEFT OUTER JOIN L2_MAP_APR_DRG adrg ON (iidrg.drg_code = adrg.apr_drg_cd and iidrg.drg_version = 'APR' and adrg.apr_drg_sev = 0 and adrg.apr_drg_risk = 0)
) iidrg4 ON (readm.drg_id = iidrg4.ii_drg_id)
LEFT OUTER JOIN temp_ii_days_elig elig ON idx.conf_num = elig.conf_num
Where idx.readmit_index_07 = 1 and length(idx.member) <= 20
 */

/**
  * SELECT idx.client_id,idx.mpi
,'CE'  event_set_cd
,idx.clinical_event_id  idx_event_id
,mr.readmission_type_cui
,nvl2(readm.clinical_event_id, datediff(cast(TO_DATE(date_format(readm.evt_start_dtm, 'yyyy-MM-dd')) as timestamp), cast(TO_DATE(date_format(idx.evt_end_dtm, 'yyyy-MM-dd')) as timestamp)) ,null) days_to_readmit
,idx.evt_end_dtm  idx_end_dtm
,idx.hosp_site_id  idx_hosp_site_id
,null  idx_prov_id
,idx.drg_id  idx_drg_id
,idx.apr_drg_id  idx_apr_drg_id
,idx.prindx_codetype  idx_prindx_codetype
,idx.prindx  idx_prindx
,idx.prindx_sensitive_ind  idx_prindx_sensitive_ind
,idx.prinpx_codetype  idx_prinpx_codetype
,idx.prinpx  idx_prinpx
,idx.prinpx_sensitive_ind  idx_prinpx_sensitive_ind
,idx.disch_prov_id  idx_disch_prov_id
,cast(90 as int) as elig_days
,1 elig_30
,CASE WHEN readm.clinical_event_id is not null AND  datediff(cast(TO_DATE(date_format(readm.evt_start_dtm, 'yyyy-MM-dd')) as timestamp), cast(TO_DATE(date_format(idx.evt_end_dtm, 'yyyy-MM-dd')) as timestamp))  <= 30 then 1 else 0 end  readm_30
,1 elig_60
,CASE WHEN readm.clinical_event_id is not null AND  datediff(cast(TO_DATE(date_format(readm.evt_start_dtm, 'yyyy-MM-dd')) as timestamp), cast(TO_DATE(date_format(idx.evt_end_dtm, 'yyyy-MM-dd')) as timestamp))  <= 60 then 1 else 0 end  readm_60
,1 elig_90
,CASE WHEN readm.clinical_event_id is not null AND  datediff(cast(TO_DATE(date_format(readm.evt_start_dtm, 'yyyy-MM-dd')) as timestamp), cast(TO_DATE(date_format(idx.evt_end_dtm, 'yyyy-MM-dd')) as timestamp))  <= 90 then 1 else 0 end  readm_90
,readm.clinical_event_id  readm_event_id
,readm.evt_start_dtm  readm_start_dtm
,readm.hosp_site_id  readm_hosp_site_id
,null  readm_prov_id
,readm.drg_id  readm_drg_id
,readm.apr_drg_id  readm_apr_drg_id
,readm.prindx_codetype  readm_prindx_codetype
,readm.prindx  readm_prindx
,readm.prindx_sensitive_ind  readm_prindx_sensitive_ind
From L2_PAT_CLINICAL_EVENT idx
JOIN L3_MAP_READMISSION mr ON (mr.readmission_domain = 'CMS' AND idx.event_type_cui = mr.event_type_cui)
LEFT OUTER JOIN L1_ENCOUNTER_GRP_REL rel ON (idx.clinical_event_id = rel.encounter_grp_num AND mr.readmission_type_cui = rel.encounter_grp_rel_type)
LEFT OUTER JOIN L2_PAT_CLINICAL_EVENT readm ON (rel.rel_encounter_grp_num = readm.clinical_event_id AND  datediff(cast(TO_DATE(date_format(readm.evt_start_dtm, 'yyyy-MM-dd')) as timestamp), cast(TO_DATE(date_format(idx.evt_end_dtm, 'yyyy-MM-dd')) as timestamp)) BETWEEN 0 AND 90)
WHERE idx.cms_include_ind = 1
  */

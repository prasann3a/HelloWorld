package com.optum.oadw.etl.L2
import com.optum.oadw.etl.models.temp_l1_ref_acs_5yr_dp03_cc
import com.optum.oadw.oadwModels._
import com.optum.oadw.oadw_ref.models.l2_map_division_region
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object L2_DICT_ZIP extends TableInfo[l2_dict_zip] {
  import com.optum.oadw.utils.DataframeExtensions._

  override def name: String = "L2_DICT_ZIP"
  override def dependsOn: Set[String] = Set("L1_REF_IMAP_REGION", "TEMP_L1_REF_ACS_5YR_DP03", "L1_REF_ACS_5YR_C17002", "L1_REF_ACS_5YR_B15002", "L1_REF_COMMERCIAL_ZIPCODES", "L2_MAP_DIVISION_REGION")
  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    val _imapReg = loadedDependencies("L1_REF_IMAP_REGION").castToBigDecimal(Set("fileid")).as[l1_ref_imap_region]
    val refIncome = loadedDependencies("TEMP_L1_REF_ACS_5YR_DP03").as[temp_l1_ref_acs_5yr_dp03_cc]
    val refPoverty = loadedDependencies("L1_REF_ACS_5YR_C17002").as[l1_ref_acs_5yr_c17002]
    val refEducation = loadedDependencies("L1_REF_ACS_5YR_B15002").as[l1_ref_acs_5yr_b15002]
    val refCommercialZip = loadedDependencies("L1_REF_COMMERCIAL_ZIPCODES").castToBigDecimal(Set("latitude", "longitude")).as[l1_ref_commercial_zipcodes]
    val l2MapDivisionRegion = loadedDependencies("L2_MAP_DIVISION_REGION").as[l2_map_division_region]

    val maxRegions = _imapReg.as("max_regions").select(max($"cens_reg")).as[String].head()

    val imapReg = maxRegions match {
      case "9" => updateRegion(sparkSession, _imapReg, l2MapDivisionRegion)
      case _ => _imapReg
    }

    createTL2DictZip(sparkSession, imapReg, refIncome, refPoverty, refEducation, refCommercialZip)
      .select(
        $"zip",
        $"county_id",
        $"state_cd",
        $"cens_reg_id",
        $"median_hh_inc",
        $"median_hh_inc_numeric",
        $"per_capita_inc",
        $"per_capita_inc_numeric",
        $"pct_below_200pct_poverty",
        $"pct_grade_sch_or_less",
        $"pct_eight_grade_or_less",
        $"pct_some_hs_or_more",
        $"pct_bachelors_deg_or_more",
        $"latitude",
        $"longitude",
        $"cens_reg_desc",
        $"county_desc",
        $"state_id"
      )
  }

  /**
    * wiki link: https://wiki.humedica.net/display/Data/OADW+Tables+-+Common+Maps+and+Dictionaries+-+DICT_ZIP
    */
  private def createTL2DictZip(sparkSession: SparkSession,
                               imapReg: Dataset[l1_ref_imap_region],
                               refIncome: Dataset[temp_l1_ref_acs_5yr_dp03_cc],
                               refPoverty: Dataset[l1_ref_acs_5yr_c17002],
                               refEducation: Dataset[l1_ref_acs_5yr_b15002],
                               refCommercialZip: Dataset[l1_ref_commercial_zipcodes]) : Dataset[l2_dict_zip] = {

    import sparkSession.implicits._

    val refZip = refCommercialZip.groupBy($"zipcode").agg(
        first($"latitude").as("latitude"), first($"longitude").as("longitude"))

    val refInc = refIncome
      .withColumn("median_hh_inc", $"hc01_vc85")
      .withColumn("per_capita_inc", $"hc01_vc118")

    val refEdu = refEducation
      .withColumn("total_population", regexp_replace($"hd01_vd02","[^\\d]","").cast(LongType) + regexp_replace($"hd01_vd19","[^\\d]","").cast(LongType))
      .withColumn("bachelors_deg_or_more", regexp_replace($"hd01_vd15", "[^\\d]","").cast(LongType) + regexp_replace($"hd01_vd32", "[^\\d]","").cast(LongType)
        + regexp_replace($"hd01_vd16", "[^\\d]","").cast(LongType) + regexp_replace($"hd01_vd33", "[^\\d]","").cast(LongType)
        + regexp_replace($"hd01_vd17", "[^\\d]","").cast(LongType) + regexp_replace($"hd01_vd34", "[^\\d]","").cast(LongType)
        + regexp_replace($"hd01_vd18", "[^\\d]","").cast(LongType) + $"hd01_vd35".cast(LongType))
      .withColumn("grade_sch_or_less", regexp_replace($"hd01_vd03", "[^\\d]","").cast(LongType) + regexp_replace($"hd01_vd20", "[^\\d]","").cast(LongType)
        + regexp_replace($"hd01_vd04", "[^\\d]","").cast(LongType) + regexp_replace($"hd01_vd21", "[^\\d]","").cast(LongType))

    val dict_zip = imapReg.as("ir")
      .join(refInc.as("ri"), $"ir.zip" === $"ri.geo_id2", "left_outer")
      .join(refPoverty.as("rp"), $"ir.zip" === $"rp.geo_id2", "left_outer")
      .join(refEdu.as("re"), $"ir.zip" === $"re.geo_id2", "left_outer")
      .join(refZip.as("rz"), $"ir.zip" === $"rz.zipcode", "left_outer")


        .select(
        $"ir.zip",
        $"ir.county_id",
        $"ir.state_desc".as("state_cd"),
        $"ir.cens_reg".as("cens_reg_id"),
        $"ir.cens_reg_desc",
        $"ir.county_desc",
        $"ir.state".as("state_id"),
        $"ri.median_hh_inc",
        when($"hc01_vc85" === "-", null)
          .when($"ri.median_hh_inc" === "2,500-", 2499)
          .when($"ri.median_hh_inc" === "250,000+", 250001)
          .otherwise(regexp_replace($"ri.median_hh_inc",",","").cast(IntegerType))
          .alias("median_hh_inc_numeric"),
        $"ri.per_capita_inc",
        when($"ri.per_capita_inc" === "-" || $"ri.per_capita_inc" === "N", null)
          .otherwise(regexp_replace($"ri.per_capita_inc",",","").cast(IntegerType))
          .alias("per_capita_inc_numeric"),
          when($"rp.hd01_vd01".isNull || regexp_replace($"rp.hd01_vd01", "[^\\d]","").cast(LongType) === 0, null)
            .otherwise(round((lit(1) - (regexp_replace($"rp.hd01_vd08", "[^\\d]","").cast(LongType)
              / regexp_replace($"rp.hd01_vd01", "[^\\d]","").cast(LongType))) * lit (100),1)
              .cast(DecimalType (19,4)))
            .alias("pct_below_200pct_poverty"),
        when($"re.total_population".isNull || $"re.total_population" === 0, null)
          .otherwise(round(lit(100) * $"re.grade_sch_or_less" / $"re.total_population",1).cast(DecimalType (19,4)))
          .alias("pct_grade_sch_or_less"),
        when($"re.total_population".isNull || $"re.total_population" === 0, null)
          .otherwise(round(lit(100) * ($"re.grade_sch_or_less" + regexp_replace($"re.hd01_vd05", "[^\\d]","").cast(DecimalType (19,4))
            + regexp_replace($"re.hd01_vd22", "[^\\d]","").cast(LongType) + regexp_replace($"re.hd01_vd06", "[^\\d]","").cast(LongType)
            + regexp_replace($"re.hd01_vd23", "[^\\d]","").cast(LongType))
            / $"re.total_population",1).cast(DecimalType (19, 4)))
          .alias("pct_eight_grade_or_less"),
        when($"re.total_population".isNull || $"re.total_population" === 0, null)
          .otherwise(round(lit(100) * ((regexp_replace($"re.hd01_vd07", "[^\\d]","").cast(DecimalType(38,18)) + regexp_replace($"hd01_vd24", "[^\\d]","").cast(DecimalType(38,18))
            + regexp_replace($"re.hd01_vd08", "[^\\d]","").cast(LongType) + regexp_replace($"hd01_vd25", "[^\\d]","").cast(LongType)
            + regexp_replace($"re.hd01_vd09", "[^\\d]","").cast(LongType) + regexp_replace($"re.hd01_vd26", "[^\\d]","").cast(LongType)
            + regexp_replace($"re.hd01_vd10", "[^\\d]","").cast(LongType) + regexp_replace($"re.hd01_vd27", "[^\\d]","").cast(LongType)
            + regexp_replace($"re.hd01_vd11", "[^\\d]","").cast(LongType) + regexp_replace($"re.hd01_vd28", "[^\\d]","").cast(LongType)
            + regexp_replace($"re.hd01_vd12", "[^\\d]","").cast(LongType) + regexp_replace($"re.hd01_vd29", "[^\\d]","").cast(LongType)
            + regexp_replace($"re.hd01_vd13", "[^\\d]","").cast(LongType) + regexp_replace($"re.hd01_vd30", "[^\\d]","").cast(LongType)
            + regexp_replace($"re.hd01_vd14", "[^\\d]","").cast(LongType) + regexp_replace($"re.hd01_vd31", "[^\\d]","").cast(LongType)) + $"re.bachelors_deg_or_more")
            / $"re.total_population",1).cast(DecimalType (19,4)))
          .alias("pct_some_hs_or_more"),
        when($"re.total_population".isNull || $"re.total_population" === 0, null)
            .otherwise(round(lit(100) * $"re.bachelors_deg_or_more" / $"re.total_population",1).cast(DecimalType (19,4)))
          .alias("pct_bachelors_deg_or_more"),
          $"rz.latitude".as("latitude"),
          $"rz.longitude".as("longitude"))
    dict_zip.as[l2_dict_zip]
  }

  private def updateRegion(sparkSession: SparkSession,
                           imapReg: Dataset[l1_ref_imap_region],
                           l2MapDivisionRegion: Dataset[l2_map_division_region]): Dataset[l1_ref_imap_region] = {
    import sparkSession.implicits._
    imapReg.as("ir")
      .join(l2MapDivisionRegion.as("dr"), $"ir.cens_reg" === $"dr.cens_division", "left")
      .select($"dr.cens_reg",
        $"dr.cens_reg_desc",
        $"ir.county_desc",
        $"ir.county_id",
        $"ir.fileid",
        $"ir.state",
        $"ir.state_desc",
        $"ir.zip").as[l1_ref_imap_region]
  }
}

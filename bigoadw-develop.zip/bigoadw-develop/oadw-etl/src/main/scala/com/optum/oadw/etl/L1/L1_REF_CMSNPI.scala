
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ref_cmsnpi, ref_cmsnpi}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_REF_CMSNPI extends TableInfo[l1_ref_cmsnpi]{
  override def dependsOn: Set[String] = Set("REF_CMSNPI")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_REF_CMSNPI"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val refCmsnpi = loadedDependencies("REF_CMSNPI").as[ref_cmsnpi]

    refCmsnpi
    .select(
			$"npi",
			$"entity_type_code",
			$"replacement_npi",
			$"employer_id_num",
			$"prov_org_name_legal_bus_name",
			$"prov_lastname_legalname",
			$"prov_firstname",
			$"prov_middle_name",
			$"prov_name_prefix",
			$"prov_name_suffix",
			$"prov_credential",
			$"prov_oth_credential",
			$"prov_first_line_bus_mail_addr",
			$"prov_second_line_bus_mail_addr",
			$"prov_bus_mail_addr_city",
			$"prov_bus_mail_addr_state",
			$"prov_bus_mail_addr_postalcode",
			$"prov_bus_mail_addr_countrycode",
			$"npi_deactivation_reason_code",
			$"npi_deactivation_date".as("npi_deactivation_dt"),
			$"npi_reactivation_date".as("npi_reactivation_dt"),
			$"last_update_date".as("last_update_dt")
    )
  }
}


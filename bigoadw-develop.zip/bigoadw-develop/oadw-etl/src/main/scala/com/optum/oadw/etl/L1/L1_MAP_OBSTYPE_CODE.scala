
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_obstype_code, zcm_obstype_code}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_OBSTYPE_CODE extends TableInfo[l1_map_obstype_code]{
  override def dependsOn: Set[String] = Set("ZCM_OBSTYPE_CODE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_OBSTYPE_CODE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zcmObstypeCode = loadedDependencies("ZCM_OBSTYPE_CODE").as[zcm_obstype_code]

    zcmObstypeCode
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"obscode",
			$"obstype",
			$"obsconvfactor",
			$"obsregex",
			$"datatype",
			$"begin_range",
			$"end_range",
			$"exclude_flag",
			$"round_prec",
			$"zero_to_null",
			$"foam_restriction",
			$"prefix",
			$"cui",
			$"localunit",
			$"obstype_std_units_desc",
			$"obstype_std_units",
			$"localunit_cui",
			$"conv_fact",
			$"function_applied"
    )
  }
}



/**
  * auto-generated code
*/
package com.optum.oadw.etl.L2
import com.optum.oadw.oadwModels.l1_map_tos_type
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata


object L1_MAP_TOS_TYPE extends QueryAndMetadata[l1_map_tos_type] {
  override def name: String = "L1_MAP_TOS_TYPE"

  override def sparkSql: String = """SELECT DISTINCT cast(prv_sp_4 as int) AS spec_code, pos_i AS pos, hts_cui AS patient_type_cui, tos_map_type
FROM L1_REF_IMAP_TOS_TYPE r
LEFT JOIN L1_place_of_service z ON (r.pos_i = z.ii_code)"""

  override def dependsOn: Set[String] = Set("L1_REF_IMAP_TOS_TYPE","L1_PLACE_OF_SERVICE")

  def originalSql: String = """--Before we insert data into L2_pat_proc, we need to populate Type of Service (tos_i_5) data.
-- these temp tables are used to fugure out what values to populate

-- need to create this table , instead of using view L1_MAP_TOS_TYPE, since we need table data when doing inserts later
CREATE TABLE L1_map_tos_type PCTFREE 0 NOLOGGING AS
SELECT DISTINCT prv_sp_4 AS spec_code, pos_i AS pos, hts_cui AS patient_type_cui, tos_map_type
FROM L1_REF_IMAP_TOS_TYPE r
LEFT JOIN L1_place_of_service z ON (r.pos_i = z.ii_code)"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_pat_proc_build.sql"
}
     
     
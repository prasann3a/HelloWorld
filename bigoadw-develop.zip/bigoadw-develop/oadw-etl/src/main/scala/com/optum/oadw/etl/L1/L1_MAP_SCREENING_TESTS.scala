
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_screening_tests, map_screening_tests}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_SCREENING_TESTS extends TableInfo[l1_map_screening_tests]{
  override def dependsOn: Set[String] = Set("MAP_SCREENING_TESTS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_SCREENING_TESTS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapScreeningTests = loadedDependencies("MAP_SCREENING_TESTS").as[map_screening_tests]

    mapScreeningTests
    .select(
			$"groupid".as("client_id"),
			$"local_code",
			$"hts_code",
			$"dts_version"
    )
  }
}



package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l1_ref_hts_ndc_current, l2_dict_dcc, l2_dict_ndc}
import com.optum.oadw.etlContract.OutputColumn
import org.apache.spark.sql.functions._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.IntegerType

object L2_DICT_NDC extends TableInfo[l2_dict_ndc] {
  override def name: String = "L2_DICT_NDC"

  def directoryLevel: String = "L2"

  override def dependsOn: Set[String] = Set("L1_REF_HTS_NDC_CURRENT","L2_DICT_DCC")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1RefHtsNdcCurrent = loadedDependencies("L1_REF_HTS_NDC_CURRENT").as[l1_ref_hts_ndc_current]
    val tL2DictDcc = broadcast(loadedDependencies("L2_DICT_DCC").as[l2_dict_dcc])

    l1RefHtsNdcCurrent.as("n")
      .join(tL2DictDcc.as("d"),$"n.dcc"===$"d.dcc","left")
      .select($"ndc",
        $"gbo_ind".cast(IntegerType).as("gbo"),
        $"gbo_desc",
        when(upper($"otc").isin("TRUE","Y","YES"),lit(1)).otherwise(lit(0)).as("otc_ind"),
        $"genericname".as("generic_name"),
        $"ln".as("label_name"),
        $"gcrt_desc".as("route_desc"),
        $"gcdf_desc_short".as("doseform_desc"),
        $"str60".as("strength"),
        $"strnum".as("strength_nbr"),
        $"volun50".as("strength_unit"),
        $"n.dcc",
        $"n.pcc",
        $"pcc_label".as("pcc_desc"),
        $"n.tcc",
        $"tcc_label".as("tcc_desc"),
        when(upper($"deleted_yn").isin("TRUE","Y","YES"),lit(1)).otherwise(lit(0)).as("deleted_ind"),
        $"obsolete_flag".as("obsolete_ind"),
        when($"obsoletedate"==="00000000",null).otherwise(to_timestamp($"obsoletedate","yyyyMMdd")).as("obsolete_dt"),
        $"d.sensitive_ind",
        $"d.sensitive_cat_id"
      )


  }

  def originalSql: String = """INSERT /* APPEND */ INTO L2_dict_ndc(ndc,gbo,gbo_desc,otc_ind,generic_name,label_name,route_desc,doseform_desc,strength,strength_nbr,strength_unit
       ,dcc,pcc,pcc_desc,tcc,tcc_desc,deleted_ind,obsolete_ind,obsolete_dt)
select ndc
       ,gbo_ind AS gbo
       ,gbo_desc AS gbo_desc
       ,CASE WHEN UPPER(otc) IN ('TRUE','Y','YES') THEN 1 ELSE 0 END AS otc_ind
       ,genericname AS generic_name
       ,ln AS label_name
       ,gcrt_desc AS route_desc
       ,gcdf_desc_short AS doseform_desc
       ,str60 AS strength
       ,strnum AS strength_nbr
       ,volun50 AS strength_unit
       ,dcc
       ,pcc
       ,pcc_label AS pcc_desc
       ,tcc
       ,tcc_label as tcc_desc
       ,CASE WHEN UPPER(deleted_yn) IN ('TRUE','Y','YES') THEN 1 ELSE 0 END AS deleted_ind
       ,obsolete_flag AS obsolete_ind
       ,CASE WHEN obsoletedate = '00000000' THEN NULL ELSE to_date(obsoletedate,'YYYYMMDD') END AS obsolete_dt
from L1_REF_HTS_NDC_CURRENT a"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("ndc",None,None), OutputColumn("gbo",None,None), OutputColumn("gbo_desc",None,None), OutputColumn("otc_ind",None,None), OutputColumn("generic_name",None,None), OutputColumn("label_name",None,None), OutputColumn("route_desc",None,None), OutputColumn("doseform_desc",None,None), OutputColumn("strength",None,None), OutputColumn("strength_nbr",None,None), OutputColumn("strength_unit",None,None), OutputColumn("dcc",None,None), OutputColumn("pcc",None,None), OutputColumn("pcc_desc",None,None), OutputColumn("tcc",None,None), OutputColumn("tcc_desc",None,None), OutputColumn("deleted_ind",None,None), OutputColumn("obsolete_ind",None,None), OutputColumn("obsolete_dt",None,None)))





  val originalSqlFileName: String = "L2_dict_ndc_build.sql"
}


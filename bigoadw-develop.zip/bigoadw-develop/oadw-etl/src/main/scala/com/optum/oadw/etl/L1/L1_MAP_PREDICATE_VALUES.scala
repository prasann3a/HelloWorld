
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_predicate_values, map_predicate_values}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_PREDICATE_VALUES extends TableInfo[l1_map_predicate_values]{
  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_PREDICATE_VALUES"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values]

    mapPredicateValues
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"data_src",
			$"entity",
			$"table_name",
			$"column_name",
			$"column_value",
			$"dts_version"
    )
  }
}


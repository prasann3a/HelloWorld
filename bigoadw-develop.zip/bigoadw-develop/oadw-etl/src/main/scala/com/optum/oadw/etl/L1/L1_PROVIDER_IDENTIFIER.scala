
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_provider_identifier, zh_provider_identifier}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROVIDER_IDENTIFIER extends TableInfo[l1_provider_identifier]{
  override def dependsOn: Set[String] = Set("ZH_PROVIDER_IDENTIFIER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROVIDER_IDENTIFIER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhProviderIdentifier = loadedDependencies("ZH_PROVIDER_IDENTIFIER").as[zh_provider_identifier]

    zhProviderIdentifier
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"master_hgprovid",
			$"id_type",
			$"id_value",
			$"provider_id"
    )
  }
}


package com.optum.oadw.etl.L2

import java.sql.Timestamp

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l1_map_pat_type_tos
import org.apache.spark.sql.functions.{coalesce, lit, when}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

case class temp_tos_enc_proc_data(client_id: String, client_ds_id: Integer, mpi: String, encounterid: String, tos_i_5: java.lang.Integer, mappedcode: String, codetype: String, encounter_dtm: Timestamp)

object TEMP_TOS_ENC_PROC extends TableInfo[temp_tos_enc_proc_data] {
  override def name: String = "TEMP_TOS_ENC_PROC"

  override def dependsOn: Set[String] = Set("L1_MAP_PAT_TYPE_TOS", "TEMP_TOS_CLAIM", "TEMP_TOS_PROCEDUREDO", "TEMP_TOS_ENC_PROV")

  override def partitions: Int = 256

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val tempTosEncProv = loadedDependencies("TEMP_TOS_ENC_PROV")

    val l1MapPatTypeTos = loadedDependencies("L1_MAP_PAT_TYPE_TOS").as[l1_map_pat_type_tos]

    val tempTosClaim = loadedDependencies("TEMP_TOS_CLAIM")

    val tempTosProcedurdo = loadedDependencies("TEMP_TOS_PROCEDUREDO")

    createTempTosEncProc(sparkSession, tempTosEncProv, l1MapPatTypeTos, tempTosClaim, tempTosProcedurdo)
  }

  private def createTempTosEncProc(sparkSession: SparkSession,
                                   tempTosEncProv: DataFrame,
                                   l1MapPatTypeTos: Dataset[l1_map_pat_type_tos],
                                   tempTosClaim: DataFrame,
                                   tempTosProcedureDo: DataFrame): DataFrame = {
    import sparkSession.implicits._

    tempTosEncProv
      .withColumn("inst_prof",
        when($"spec_code".between("100", "199"), "I")
          .when($"facility_ind" === 1, "I")
          .otherwise("P")
      )
      .as("t")
      .join(l1MapPatTypeTos.as("mt"), $"mt.inst_prof" === $"t.inst_prof" and $"mt.patient_type_cui" === $"t.patient_type_cui", "left_outer")
      .join(tempTosClaim.as("c"), $"c.mpi" === $"t.mpi" and $"c.encounterid" === $"t.encounterid" and $"c.client_ds_id" === $"t.client_ds_id", "left_outer")
      .join(tempTosProcedureDo.as("r"), $"r.mpi" === $"t.mpi" and $"r.encounterid" === $"t.encounterid" and $"r.client_ds_id" === $"t.client_ds_id", "left_outer")
      .where(
        $"c.mpi".isNull and $"c.encounterid".isNull and $"c.client_ds_id".isNull and
          $"r.mpi".isNull and $"r.encounterid".isNull and $"r.client_ds_id".isNull
      )
      .select(
        //$"t.*",
        $"t.client_id", $"t.client_ds_id", $"t.mpi", $"t.encounterid", $"t.encounter_dtm",
        lit("ENCOUNTER").as("mappedcode"),
        lit("TOS").as("codetype"),
        coalesce($"mt.tos_i_5", lit(5264)).as("tos_i_5")
      ).distinct()
  }

  def directoryLevel: String = "L2"
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_treatment_type_code, zcm_treatment_type_code}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_TREATMENT_TYPE_CODE extends TableInfo[l1_map_treatment_type_code]{
  override def dependsOn: Set[String] = Set("ZCM_TREATMENT_TYPE_CODE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_TREATMENT_TYPE_CODE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zcmTreatmentTypeCode = loadedDependencies("ZCM_TREATMENT_TYPE_CODE").as[zcm_treatment_type_code]

    zcmTreatmentTypeCode
    .select(
			$"groupid".as("client_id"),
			$"local_code",
			$"treatment_type_cui",
			$"local_unit",
			$"data_type",
			$"begin_range",
			$"end_range",
			$"round_prec",
			$"tmttype_std_units_desc",
			$"treatment_type_std_units",
			$"localunit_cui",
			$"conv_fact",
			$"function_applied"
    )
  }
}


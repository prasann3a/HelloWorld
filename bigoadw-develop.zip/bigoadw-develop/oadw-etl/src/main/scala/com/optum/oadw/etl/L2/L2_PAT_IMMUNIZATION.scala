package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{max, _}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import java.sql.Date
import java.util.Calendar
import com.optum.oadw.definedfunctions.{BitOrAgg,ListAggFunction}
import com.optum.oadw.etl.constants.SpecialDomains

object L2_PAT_IMMUNIZATION extends TableInfo[l2_pat_immunization] {

  override def name = "L2_PAT_IMMUNIZATION"

  override def dependsOn: Set[String] = Set("L1_MAP_PROCEDURE_CUI","L2_MAP_CDS_FLG","MD_OADW_INSTANCE","L2_PAT_PROC","L1_CLINICAL_EVENT_ENCOUNTER","L2_PAT_MED","L2_DICT_DCC","L1_IMMUNIZATION","L1_MAP_IMMUN_DEFER_REASON", "MD_DOMAIN_CONCEPT")

  def directoryLevel = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l1MapProcedureCui = loadedDependencies("L1_MAP_PROCEDURE_CUI").as[l1_map_procedure_cui].alias("l1MapProcedureCui")

    val l2MapCDSFLG = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg].alias("l2MapCDSFLG")

    val mdDomainConcept = loadedDependencies("MD_DOMAIN_CONCEPT").as[md_domain_concept]

    val mDOADWInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance].alias("mDOADWInstance")

    val tL2PatProc = loadedDependencies("L2_PAT_PROC").as[l2_pat_proc].alias("tL2PatProc")

    val tl1ClinicalEventEncounter = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").as[l1_clinical_event_encounter].alias("tl1ClinicalEventEncounter")

    val tL2PatMed = loadedDependencies("L2_PAT_MED").as[l2_pat_med].alias("tL2PatMed")

    val tL2DictDCC = loadedDependencies("L2_DICT_DCC").as[l2_dict_dcc].alias("tL2DictDCC")

    val l1Immunization = loadedDependencies("L1_IMMUNIZATION").as[l1_immunization].alias("l1Immunization")

    val l1MapImmunDeferReason = loadedDependencies("L1_MAP_IMMUN_DEFER_REASON").as[l1_map_immun_defer_reason].alias("l1MapImmunDeferReason")

    val oadwDataThru = getDataThruLimit(sparkSession, mDOADWInstance)

    val l2PatMed_l2DictDcc = join_l2PatMed_l2DictDcc(sparkSession, tL2PatMed, tL2DictDCC)

    val l1Immun_l1MapImmunDeferReason_l2DictDcc = join_l1Immun_l1MapImmunDeferReason_l2DictDcc(sparkSession, l1Immunization, l1MapImmunDeferReason, tL2DictDCC, l2MapCDSFLG, tl1ClinicalEventEncounter)

    val patProc_mapProcCui_oadwSpcDom_mapCdsFlg_cee = join_patProc_mapProcCui_oadwSpcDom_mapCdsFlg_cee(sparkSession, tL2PatProc, l1MapProcedureCui, mdDomainConcept, l2MapCDSFLG, tl1ClinicalEventEncounter)

    val unionDf = l2PatMed_l2DictDcc
      .union(l1Immun_l1MapImmunDeferReason_l2DictDcc)
      .union(patProc_mapProcCui_oadwSpcDom_mapCdsFlg_cee)
      .where( $"mpi".isNotNull && $"imm_dt" < lit(oadwDataThru))

    unionDf
      .groupBy(
        $"client_id",
        $"mpi",
        $"imm_dt",
        $"code_type",
        $"imm_cd"
      )
      .agg(
        ListAggFunction.listAgg(coalesce($"cds_grp",lit(""))).as("cds_grp"),
        max($"clinical_event_id").as("clinical_event_id"),
        max("pat_reported_ind").as("pat_reported_ind"),
        max("rxadmin_ind").as("rxadmin_ind"),
        max("rxorder_ind").as("rxorder_ind"),
        max("immunization_ind").as("immunization_ind"),
        max("procedure_ind").as("procedure_ind"),
        max( $"sensitive_ind").as("sensitive_ind")
      )
     .select($"client_id",
      $"cds_grp",
      $"mpi",
      $"imm_dt",
      $"code_type",
      $"imm_cd",
      $"clinical_event_id",
      $"pat_reported_ind",
      $"rxadmin_ind",
      $"rxorder_ind",
      $"immunization_ind",
      $"procedure_ind",
      lit(0).as("inferred_ind"),
       $"sensitive_ind"
    )
  }

  private def getDataThruLimit(sparkSession: SparkSession,
                               mDOADWInstance: Dataset[md_oadw_instance]): Date = {
    import sparkSession.implicits._

    val dt = mDOADWInstance.as("oadw_data_thru")
      .select(to_date($"attribute_value", "yyyyMMdd").as("data_thru_dt"))
      .where($"attribute_name" === "DATA_THRU")
      .collect.head.getDate(0)

    val c = Calendar.getInstance
    c.setTime(dt)
    c.add(Calendar.DATE, 1)
    return new Date(c.getTimeInMillis)
  }

  private def join_l2PatMed_l2DictDcc(sparkSession: SparkSession,
                                      l2PatMed: Dataset[l2_pat_med],
                                      tL2DictDCC: Dataset[l2_dict_dcc]): Dataset[Row] = {
    import sparkSession.implicits._

    l2PatMed.as("pm")
      .join(tL2DictDCC.as("dd"), $"dd.dcc" === $"pm.dcc", "inner")
      .select(
        $"pm.client_id".as("client_id"),
        $"pm.cds_grp".as("cds_grp"),
        $"pm.mpi".as("mpi"),
        to_date($"pm.rx_dtm", "yyyy-MM-dd").as("imm_dt"),
        lit("DCC").as("code_type"),
        $"pm.dcc".as("imm_cd"),
        $"pm.clinical_event_id".as("clinical_event_id"),
        lit(null).as("encounterid"),
        $"pm.pat_reported_ind".as("pat_reported_ind"),
        $"pm.rxadmin_ind".as("rxadmin_ind"),
        $"pm.rxorder_ind".as("rxorder_ind"),
        lit(0).as("immunization_ind"),
        lit(0).as("procedure_ind"),
        $"pm.sensitive_ind".as("sensitive_ind")
      )
      .where($"dd.vaccine_ind" === 1)
  }

  private def join_l1Immun_l1MapImmunDeferReason_l2DictDcc(sparkSession: SparkSession,
                                                           l1Immunization: Dataset[l1_immunization],
                                                           l1MapImmunDeferReason: Dataset[l1_map_immun_defer_reason],
                                                           tL2DictDCC: Dataset[l2_dict_dcc],
                                                           mapCdsFlg: Dataset[l2_map_cds_flg],
                                                           clinicalEventEncounter: Dataset[l1_clinical_event_encounter]): Dataset[Row] = {
    import sparkSession.implicits._

    l1Immunization.as("li")
      .join(tL2DictDCC.as("dd"), $"dd.dcc" === $"li.dcc", "inner")
      .join(broadcast(l1MapImmunDeferReason).as("idr"),
        $"idr.client_id" === $"li.client_id" && $"idr.local_code" === $"li.localdeferredreason",
        "left_outer")
      .join(mapCdsFlg.as("mcf"),
        $"mcf.client_id" === $"li.client_id" && $"mcf.client_ds_id" === $"li.client_ds_id",
        "left_outer")
      .join(clinicalEventEncounter.as("cee"),
        $"cee.client_id" === $"li.client_id"
          && $"cee.client_ds_id" === $"li.client_ds_id"
          && $"cee.encounterid" === $"li.encounterid"
          && $"cee.mpi" === $"li.mpi",
        "left_outer")
      .select(
        $"li.client_id".as("client_id"),
        $"mcf.client_ds_id".as("cds_grp"),
        $"li.mpi".as("mpi"),
        to_date(coalesce($"li.admin_dtm", $"li.documented_dt"), "yyyy-MM-dd").as("imm_dt"),
        lit("DCC").as("code_type"),
        $"li.dcc".as("imm_cd"),
        $"cee.encounter_grp_num".as("clinical_event_id"),
        $"li.encounterid".as("encounterid"),
        lit(0).as("pat_reported_ind"),
        lit(0).as("rxadmin_ind"),
        lit(0).as("rxorder_ind"),
        lit(1).as("immunization_ind"),
        lit(0).as("procedure_ind"),
        $"dd.sensitive_ind".as("sensitive_ind")
      )
      .where($"dd.vaccine_ind" === 1 && $"idr.cui".isNull)
  }

  private def join_patProc_mapProcCui_oadwSpcDom_mapCdsFlg_cee(sparkSession: SparkSession,
                                                                patProc: Dataset[l2_pat_proc],
                                                                mapProcCui: Dataset[l1_map_procedure_cui],
                                                                mdDomainConcept: Dataset[md_domain_concept],
                                                                mapCdsFlg: Dataset[l2_map_cds_flg],
                                                                cee: Dataset[l1_clinical_event_encounter]): Dataset[Row] = {
    import sparkSession.implicits._

    patProc.as("pp")
      .join(mapProcCui.as("mpc"),
        $"mpc.codetype" === $"pp.code_type" && $"mpc.mappedcode" === $"pp.proc_cd",
        "inner")
      .join(broadcast(mdDomainConcept).as("mdc"),
        $"mdc.domain_cui" === SpecialDomains.VACCINE_CUI && $"mdc.concept_cui" === $"mpc.cui",
        "inner")
      .select(
        $"pp.client_id".as("client_id"),
        $"pp.cds_grp".as("cds_grp"),
        $"pp.mpi".as("mpi"),
        to_date($"pp.proc_dtm", "yyyy-MM-dd").as("imm_dt"),
        $"pp.code_type".as("code_type"),
        $"pp.proc_cd".as("imm_cd"),
        $"pp.clinical_event_id".as("clinical_event_id"),
        lit(null).as("encounterid"),
        lit(0).as("pat_reported_ind"),
        lit(0).as("rxadmin_ind"),
        lit(0).as("rxorder_ind"),
        lit(0).as("immunization_ind"),
        lit(1).as("procedure_ind"),
        $"pp.sensitive_ind".as("sensitive_ind")
      )
  }
}

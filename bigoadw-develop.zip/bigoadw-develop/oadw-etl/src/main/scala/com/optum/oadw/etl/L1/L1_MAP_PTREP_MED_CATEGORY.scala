
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_ptrep_med_category, map_ptrep_med_category}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_PTREP_MED_CATEGORY extends TableInfo[l1_map_ptrep_med_category]{
  override def dependsOn: Set[String] = Set("MAP_PTREP_MED_CATEGORY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_PTREP_MED_CATEGORY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapPtrepMedCategory = loadedDependencies("MAP_PTREP_MED_CATEGORY").as[map_ptrep_med_category]

    mapPtrepMedCategory
    .select(
			$"groupid".as("client_id"),
			$"mnemonic".as("local_code"),
			$"cui",
			$"dts_version"
    )
  }
}


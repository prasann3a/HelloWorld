
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_pft_result, pft_result}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PFT_RESULT extends TableInfo[l1_pft_result]{
  override def dependsOn: Set[String] = Set("PFT_RESULT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PFT_RESULT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val pftResult = loadedDependencies("PFT_RESULT").as[pft_result]

    pftResult
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"facilityid",
			$"encounterid",
			$"patientid",
			$"resultdate".as("result_dt"),
			$"fvc",
			$"fev1",
			$"fev1_fvc_ratio",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi")
    )
  }
}


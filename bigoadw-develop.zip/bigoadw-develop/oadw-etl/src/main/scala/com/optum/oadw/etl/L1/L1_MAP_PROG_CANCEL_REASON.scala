
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_prog_cancel_reason, map_prog_cancel_reason}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_PROG_CANCEL_REASON extends TableInfo[l1_map_prog_cancel_reason]{
  override def dependsOn: Set[String] = Set("MAP_PROG_CANCEL_REASON")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_PROG_CANCEL_REASON"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapProgCancelReason = loadedDependencies("MAP_PROG_CANCEL_REASON").as[map_prog_cancel_reason]

    mapProgCancelReason
    .select(
			$"localcode".as("local_code"),
			$"cui",
			$"dts_version"
    )
  }
}


package com.optum.oadw.etl.L3

import java.sql.Timestamp

import com.optum.oadw.etl.models.{temp_l3_pat_condition_precursor, temp_l3_pat_condition_precursor_individual_common}
import com.optum.oadw.oadwModels.{l3_pat_precursor, l4_timeframe, md_oadw_instance}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{datediff, lit, sum, when}
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_L3_PAT_CONDITION_PRECURSOR_INDIVIDUAL extends TableInfo[temp_l3_pat_condition_precursor]  {

  override def name: String = "TEMP_L3_PAT_CONDITION_PRECURSOR_INDIVIDUAL"

  override def dependsOn: Set[String] = Set("TEMP_L3_PAT_CONDITION_INDIVIDUAL_COMMON" , "L4_TIMEFRAME")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val commonDF = loadedDependencies("TEMP_L3_PAT_CONDITION_INDIVIDUAL_COMMON").as[temp_l3_pat_condition_precursor_individual_common].toDF()

    val allTimeFrameStartDtm = broadcast(loadedDependencies("L4_TIMEFRAME").as[l4_timeframe].where($"timeframe_type" === lit("ALL")))
      .select($"start_dt").as[Timestamp].head()


    // Added datathru and timeframe start filter for inclusion precursors
    val nonExclusionPrecursors = commonDF.where(date_trunc("DD", $"precursor_dtm").geq(lit(allTimeFrameStartDtm)) and $"precursor_cnt" =!= 0)

    val exclusionPrecursors = commonDF.where( $"precursor_cnt" === 0)

    // combined the non exclusions and exclusion precursors
    val CombinedPrecursors  =  nonExclusionPrecursors.as("a").join(exclusionPrecursors.as("a2") , $"a.client_id" === $"a2.client_id" and $"a.rule_id" === $"a2.rule_id" and  $"a.mpi" === $"a2.mpi" and $"a.condition_id" === $"a2.condition_id" , "left")

    val precursorsWithoutExclusions = CombinedPrecursors.where($"a2.precursor_id".isNull).select($"a.*").distinct

    val precursorsWithExclusions = CombinedPrecursors.where($"a2.precursor_id".isNotNull)

    // exclusion

    val precusorsQualifiedAfterExclusions = executeExclusionsForConditions(precursorsWithExclusions, sparkSession)

    //when precursor count = 1 - inclusion

    val activeConditionsForSinglePrecursors = precursorsWithoutExclusions.where($"precursor_cnt" === 1).union(precusorsQualifiedAfterExclusions.where($"precursor_cnt" === 1)).where($"precursor_cnt" === 1).distinct.drop("precursor_cnt","precursor_cnt_min_days","precursor_cnt_max_days")

    //Method calculate active conditions when  precursor count == 2

    val finalActiveConditionsForDoublePrecursors = qualifyConditionsWithPrecursorCountTwo(precursorsWithoutExclusions,precusorsQualifiedAfterExclusions,nonExclusionPrecursors, sparkSession)

    //Method to calculate active conditions when  precursor count == 3

    val finalActiveConditionsForthreePrecursors = qualifyConditionsWithPrecursorCountThree(precursorsWithoutExclusions,precusorsQualifiedAfterExclusions,nonExclusionPrecursors, sparkSession)

    // combine final active condition precusors outputs for  precursor count = 1 , precursor count = 2, precursor count = 3
    activeConditionsForSinglePrecursors.union(finalActiveConditionsForDoublePrecursors).union(finalActiveConditionsForthreePrecursors)

  }

  private def executeExclusionsForConditions (precursorsWithExclusions: DataFrame, sparkSession: SparkSession): DataFrame =

  {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    // Combined exclusion check for all precursor counts ( when precursor count = 1 , precursor count = 2, precursor count = 3 .. etc)

    // exclusion check when precursor_cnt_min_days is negative and precursor_cnt_max_days has values
    val precusorsQualifiedAfterExclusionsNotNull =  precursorsWithExclusions.where($"a2.precursor_cnt_min_days".isNotNull and $"a2.precursor_cnt_max_days".isNotNull ).
      withColumn("qualify", when(!(datediff($"a2.precursor_dtm", $"a.precursor_dtm").between($"a2.precursor_cnt_min_days", $"a2.precursor_cnt_max_days"))  , lit(0 )).otherwise(lit(1) ))

    // exclusion check when precursor_cnt_min_days and precursor_cnt_max_days == null
    val precusorsQualifiedAfterExclusionNulls =  precursorsWithExclusions.where($"a2.precursor_cnt_min_days".isNull and $"a2.precursor_cnt_max_days".isNull).
      withColumn("qualify", lit(1))

    // Logic to Qualify then when only it passes the exclusion check
    precusorsQualifiedAfterExclusionsNotNull.union(precusorsQualifiedAfterExclusionNulls)
      .groupBy($"a.client_id", $"a.mpi",$"a.condition_id",$"a.rule_id",
        $"a.precursor_id",$"a.precursor_dtm", $"a.precursor_domain",
        $"a.precursor_type",$"a.precursor_cds_grp",
        $"a.precursor_value",$"a.precursor_modifier_flg",$"a.sensitive_ind_precur",
        $"a.precursor_cnt",$"a.precursor_cnt_min_days",$"a.precursor_cnt_max_days",$"a.sensitive_ind").
      agg(sum($"qualify").as("qualifiedrecord")).
      where($"qualifiedrecord" === 0).
      drop("qualifiedrecord","qualify")

  }

  private def qualifyConditionsWithPrecursorCountThree (precursorsWithoutExclusions : DataFrame , precusorsQualifiedAfterExclusions :  DataFrame , nonExclusionPrecursors : DataFrame , sparkSession: SparkSession): DataFrame  ={
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    //when precursor count = 3 - inclusion

    val combinedThreePrecursorsWithAndWithoutExclusions = precursorsWithoutExclusions.where($"precursor_cnt" === 3).union(precusorsQualifiedAfterExclusions.where($"precursor_cnt" === 3)) //parent records

    val activeConditionsForthreePrecursors = combinedThreePrecursorsWithAndWithoutExclusions
      .join(nonExclusionPrecursors.where($"precursor_cnt" === 3).as("a2"), $"a.client_id" === $"a2.client_id" and $"a.rule_id" === $"a2.rule_id" and
        $"a.mpi" === $"a2.mpi" and $"a.condition_id" === $"a2.condition_id" and $"a.precursor_id" === $"a2.precursor_id" and
        $"a.precursor_dtm" =!= $"a2.precursor_dtm")
      .join(nonExclusionPrecursors.where($"precursor_cnt" === 3).as("a3"), $"a.client_id" === $"a3.client_id" and $"a.rule_id" === $"a3.rule_id" and
        $"a.mpi" === $"a3.mpi" and $"a.condition_id" === $"a3.condition_id" and $"a.precursor_id" === $"a3.precursor_id" and
        $"a.precursor_dtm" =!= $"a3.precursor_dtm" and  $"a2.precursor_dtm" =!= $"a3.precursor_dtm")


    // when precursor_cnt_max_days > 0  when required precursor_cnt ===3
    val activeConditionsForthreePrecursorsMaxdays = activeConditionsForthreePrecursors
      .where($"a.precursor_cnt_min_days" === lit(0) and // should be 0
        $"a.precursor_cnt_max_days" >= lit(0) and // null or positive value
        (datediff($"a.precursor_dtm", $"a2.precursor_dtm").lt($"a.precursor_cnt_max_days") or
          datediff($"a2.precursor_dtm", $"a3.precursor_dtm").lt($"a.precursor_cnt_max_days"))
      )

    // when precursor_cnt_max_days == null when required precursor_cnt ===3
    val activeConditionsForthreePrecursorsMaxdaysNull = activeConditionsForthreePrecursors
      .where(($"a.precursor_cnt_min_days" === lit(0) or $"a.precursor_cnt_min_days".isNull )and // should be 0
        $"a.precursor_cnt_max_days".isNull)

    val  activeConditionsForthreePrecursorsCombined = activeConditionsForthreePrecursorsMaxdays.union(activeConditionsForthreePrecursorsMaxdaysNull).distinct

    val activeConditionsForthreePrecursorsParents = activeConditionsForthreePrecursorsCombined.select($"a.*")
    val activeConditionsForthreePrecursorschild1 = activeConditionsForthreePrecursorsCombined.select($"a2.*")
    val activeConditionsForthreePrecursorschild2 = activeConditionsForthreePrecursorsCombined.select($"a3.*")

    //combined the qualified parent and child records when precursor_cnt ===3
    activeConditionsForthreePrecursorsParents.union(activeConditionsForthreePrecursorschild1).union(activeConditionsForthreePrecursorschild2).distinct.drop("precursor_cnt","precursor_cnt_min_days","precursor_cnt_max_days")

  }

  private def qualifyConditionsWithPrecursorCountTwo(precursorsWithoutExclusions : DataFrame , precusorsQualifiedAfterExclusions :  DataFrame , nonExclusionPrecursors : DataFrame, sparkSession: SparkSession): DataFrame  = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    //when precursor count = 2 - inclusion

    val combinedTwoPrecursorsWithAndWithoutExclusions = precursorsWithoutExclusions.where($"precursor_cnt" === 2).union(precusorsQualifiedAfterExclusions.where($"precursor_cnt" === 2)) //parent records

    // Logic to identify the child precursors for the parent when precursor_cnt = 2
    val activeConditionsForDoublePrecursors = combinedTwoPrecursorsWithAndWithoutExclusions.join(nonExclusionPrecursors.where($"precursor_cnt" === 2).as("a2"), $"a.client_id" === $"a2.client_id" and $"a.rule_id" === $"a2.rule_id" and
      $"a.mpi" === $"a2.mpi" and $"a.condition_id" === $"a2.condition_id" and $"a.precursor_id" === $"a2.precursor_id" and
      $"a.precursor_dtm" =!= $"a2.precursor_dtm")
      .where(
        $"a.precursor_cnt_min_days" >= lit(0) and
          $"a.precursor_cnt_max_days" > lit(0) and
          datediff($"a2.precursor_dtm", $"a.precursor_dtm").between($"a.precursor_cnt_min_days", $"a.precursor_cnt_max_days")
      )

    val activeConditionsForDoublePrecursorsParents = activeConditionsForDoublePrecursors.select($"a.*")
    val activeConditionsForDoublePrecursorschild = activeConditionsForDoublePrecursors.select($"a2.*")

    //combined the parent and child records
    activeConditionsForDoublePrecursorsParents.union(activeConditionsForDoublePrecursorschild).distinct.drop("precursor_cnt","precursor_cnt_min_days","precursor_cnt_max_days")

  }

}

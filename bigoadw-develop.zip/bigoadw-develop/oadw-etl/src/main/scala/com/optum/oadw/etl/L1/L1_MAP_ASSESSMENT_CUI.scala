package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object L1_MAP_ASSESSMENT_CUI extends TableInfo[l1_map_assessment_cui] {
  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_ASSESSMENT_CUI"

  override def dependsOn: Set[String] = Set(
    "L1_MAP_BMI_FOLLOWUP",
    "L1_MAP_BP_FOLLOWUP",
    "L1_MAP_DEPRESSION_FOLLOWUP",
    "L1_MAP_HOSPICE_IND",
    "L1_MAP_ADVANCED_DIRECTIVE",
    "L1_MAP_DIAB_EYE_EXAM",
    "L1_MAP_ALCOHOL",
    "L1_MAP_ALCOHOL_DETAIL",
    "L1_MAP_EXERCISE_LEVEL",
    "L1_MAP_SMOKING_CESSATION",
    "L1_MAP_SMOKING_STATUS",
    "L1_MAP_TOBACCO_CESSATION",
    "L1_MAP_TOBACCO_USE",
    "L1_MAP_OBSERVATION",
    "L1_MAP_OBSTYPE"
  )

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL1MapBmiFollowup = loadedDependencies("L1_MAP_BMI_FOLLOWUP").as[l1_map_bmi_followup]
    val tL1MapBpFollowup = loadedDependencies("L1_MAP_BP_FOLLOWUP").as[l1_map_bp_followup]
    val tL1MapDepressionFollowup = loadedDependencies("L1_MAP_DEPRESSION_FOLLOWUP").as[l1_map_depression_followup]
    val tL1MapHospiceInd = loadedDependencies("L1_MAP_HOSPICE_IND").as[l1_map_hospice_ind]
    val tL1MapAdvancedDirective = loadedDependencies("L1_MAP_ADVANCED_DIRECTIVE").as[l1_map_advanced_directive]
    val tL1MapDiabEyeExam = loadedDependencies("L1_MAP_DIAB_EYE_EXAM").as[l1_map_diab_eye_exam]
    val tL1MapAlcohol = loadedDependencies("L1_MAP_ALCOHOL").as[l1_map_alcohol]
    val tL1MapAlcoholDetail = loadedDependencies("L1_MAP_ALCOHOL_DETAIL").as[l1_map_alcohol_detail]
    val tL1MapExerciseLevel = loadedDependencies("L1_MAP_EXERCISE_LEVEL").as[l1_map_exercise_level]
    val tL1MapSmokingCessation = loadedDependencies("L1_MAP_SMOKING_CESSATION").as[l1_map_smoking_cessation]
    val tL1MapSmokingStatus = loadedDependencies("L1_MAP_SMOKING_STATUS").as[l1_map_smoking_status]
    val tL1MapTobaccoCessation = loadedDependencies("L1_MAP_TOBACCO_CESSATION").as[l1_map_tobacco_cessation]
    val tL1MapTobaccoUse = loadedDependencies("L1_MAP_TOBACCO_USE").as[l1_map_tobacco_use]
    val tL1MapObservation = loadedDependencies("L1_MAP_OBSERVATION").as[l1_map_observation].where($"datasrc" === lit("nlp"))
    val tL1MapObstype = loadedDependencies("L1_MAP_OBSTYPE").as[l1_map_obstype]

    val combinedDf = tL1MapBmiFollowup.selectExpr("'CH001847' AS map_cui", "client_id", "local_code", "cui")
      .union(tL1MapBpFollowup.selectExpr("'CH001939' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapDepressionFollowup.selectExpr("'CH001848' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapHospiceInd.selectExpr("'CH002104' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapAdvancedDirective.selectExpr("'CH002643' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapDiabEyeExam.selectExpr("'CH002749' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapAlcohol.selectExpr("'CH001639' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapAlcoholDetail.selectExpr("'CH001639' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapExerciseLevel.selectExpr("'CH001640' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapSmokingCessation.selectExpr("'CH001637' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapSmokingStatus.selectExpr("'CH001638' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapTobaccoCessation.selectExpr("'CH001851' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapTobaccoUse.selectExpr("'CH001850' AS map_cui", "client_id", "local_code", "cui"))
      .union(tL1MapObservation.selectExpr("'CH001254' AS map_cui", "client_id", "local_code", "cui"))   //for nlp, CH001254 is defined in L2_DICT_ASSESSMENT

    combinedDf.as("v")
      .join(tL1MapObstype.as("m"), $"v.map_cui" === $"m.obstype_cui" )
      .where($"m.validated_ind" === 1)
      .select($"client_id", $"cui", $"local_code", $"map_cui")
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_pat_rel, prov_pat_rel}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_PAT_REL extends TableInfo[l1_prov_pat_rel]{
  override def dependsOn: Set[String] = Set("PROV_PAT_REL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_PAT_REL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val provPatRel = loadedDependencies("PROV_PAT_REL").as[prov_pat_rel]

    provPatRel
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"providerid",
			$"patientid",
			$"localrelshipcode",
			$"startdate".as("start_dt"),
			$"enddate".as("end_dt"),
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"mstrprovid",
			$"contract_id"
    )
  }
}


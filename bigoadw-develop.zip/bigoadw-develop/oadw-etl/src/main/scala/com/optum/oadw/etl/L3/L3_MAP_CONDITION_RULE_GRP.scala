package com.optum.oadw.etl.L3

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l3_map_condition_rule_grp
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.oadw.oadwModels.l3_dict_condition_rule
import com.optum.oadw.oadw_ref.models.{l3_map_cond_precur_rule, l3_map_cond_precur_fam_rule}
import com.optum.oadw.definedfunctions._

object L3_MAP_CONDITION_RULE_GRP extends TableInfo[l3_map_condition_rule_grp] {

  override def name: String = "L3_MAP_CONDITION_RULE_GRP"

  override def dependsOn: Set[String] = Set("L3_DICT_CONDITION_RULE", "REFERENCE_SCHEMA_L3_MAP_COND_PRECUR_RULE", "REFERENCE_SCHEMA_L3_MAP_COND_PRECUR_FAM_RULE")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val l3DictConditionRule = loadedDependencies("L3_DICT_CONDITION_RULE").as[l3_dict_condition_rule].select($"condition_id", $"rule_id".as("rule_grp"), $"rule_id")
    val tL3MapCondPrecurRule = loadedDependencies("REFERENCE_SCHEMA_L3_MAP_COND_PRECUR_RULE").as[l3_map_cond_precur_rule]
    val tL3MapCondPrecurFamRule = loadedDependencies("REFERENCE_SCHEMA_L3_MAP_COND_PRECUR_FAM_RULE").as[l3_map_cond_precur_fam_rule]

    val filteredTL3MapCondPrecurRule = tL3MapCondPrecurRule.filter($"precursor_cnt" =!=  0)
      .select($"condition_id", $"rule_id", $"precursor_id")
    val unionCondPrecurRuleId = filteredTL3MapCondPrecurRule.union(tL3MapCondPrecurFamRule.toDF)
    unionCondPrecurRuleId
      .groupBy($"condition_id", $"precursor_id")
      .agg(collect_set($"rule_id").as("collected_ruleId"))
      .filter(size($"collected_ruleId") > 1)
      .select($"condition_id", explode(PowerSetFunction.listpset($"collected_ruleId")).as("ruleGrpSet"))
      .filter(size($"ruleGrpSet") >= 2)
      .select($"condition_id", concat_ws(".", $"ruleGrpSet").as("rule_grp"), explode($"ruleGrpSet").as("rule_id"))
      .union(l3DictConditionRule)
  }

}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_health_maintenance, health_maintenance}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_HEALTH_MAINTENANCE extends TableInfo[l1_health_maintenance]{
  override def dependsOn: Set[String] = Set("HEALTH_MAINTENANCE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_HEALTH_MAINTENANCE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val healthMaintenance = loadedDependencies("HEALTH_MAINTENANCE").as[health_maintenance]

    healthMaintenance
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"client_ds_id",
			$"facilityid",
			$"encounterid",
			$"patientid",
			$"documented_date".as("documented_dt"),
			$"localcode",
			$"hm_cui",
			$"last_satisfied_date".as("last_satisfied_dt"),
			$"next_due_date".as("next_due_dt"),
			$"hgpid",
			$"grp_mpi".as("mpi")
    )
  }
}



/**
  * auto-generated code
*/
package com.optum.oadw.etl.L3


import java.sql.Timestamp

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_hedis_event_dt_data(client_id: String, mpi: String, hedis_measure_id: String, version: String,
                                    yr: String, episode_number: String, event_dt: java.sql.Date)

object TEMP_HEDIS_EVENT_DT extends QueryAndMetadata[temp_hedis_event_dt_data] {
  override def name: String = "TEMP_HEDIS_EVENT_DT"

  override def sparkSql: String = """SELECT DISTINCT a.client_id, a.mpi, dt.hedis_measure_id, a.version, date_format(a.measurement_end_dt,'yyyy') AS yr, a.episode_identifier AS episode_number,
FIRST_VALUE( TO_DATE(SUBSTR(a.metric_value,LENGTH(a.metric_value)-9), 'yyyy-MM-dd') ) OVER (PARTITION BY a.client_id, a.mpi, dt.hedis_measure_id, a.version,
date_format(a.measurement_end_dt,'yyyy'), a.episode_identifier
ORDER BY a.measurement_end_dt DESC,
SUBSTR(a.metric_value, LENGTH(a.metric_value)-9) DESC) AS event_dt
FROM   L1_hedis_audit_output a
INNER JOIN l3_dict_hedis_metric_code dt ON (a.metric_code = dt.metric_code AND dt.metric_code_type = 'EVENT_DT')"""

  override def dependsOn: Set[String] = Set("L1_HEDIS_AUDIT_OUTPUT","L3_DICT_HEDIS_METRIC_CODE")

  def originalSql: String = """CREATE TABLE temp_hedis_event_dt PCTFREE 0 NOLOGGING AS
SELECT DISTINCT a.client_id, a.mpi, dt.hedis_measure_id, a.version, TO_CHAR(a.measurement_end_dt,'YYYY') AS yr, a.episode_identifier AS episode_number,
       FIRST_VALUE(TO_DATE(SUBSTR(a.metric_value,LENGTH(a.metric_value)-9),'YYYY-MM-DD')) OVER (PARTITION BY a.client_id, a.mpi, dt.hedis_measure_id, a.version,
                                                                                                             TO_CHAR(a.measurement_end_dt,'YYYY'), a.episode_identifier
                                                                                                ORDER BY a.measurement_end_dt DESC,
                                                                                                         SUBSTR(a.metric_value, LENGTH(a.metric_value)-9) DESC) AS event_dt
FROM   L1_hedis_audit_output a
INNER JOIN l3_dict_hedis_metric_code dt ON (a.metric_code = dt.metric_code AND dt.metric_code_type = 'EVENT_DT')"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L3"





  val originalSqlFileName: String = "L3_hedis_evt_measure_precursor_build.sql"
}


package com.optum.oadw.etl.L1

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{map_attribution_order, l1_map_attribution_order}
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_ATTRIBUTION_ORDER extends TableInfo[l1_map_attribution_order] {
  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_ATTRIBUTION_ORDER"

  override def dependsOn: Set[String] = Set("MAP_ATTRIBUTION_ORDER")

  def directoryLevel: String = "L1"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val MapAttributionOrder = loadedDependencies("MAP_ATTRIBUTION_ORDER").as[map_attribution_order]

    val l1MapAttributionOrder = MapAttributionOrder.select(
      $"attrib_hier",
      $"groupid".as("client_id"),
      $"prov_attrib_id".cast(IntegerType).as("prov_attrib_id"))

    l1MapAttributionOrder

  }
}
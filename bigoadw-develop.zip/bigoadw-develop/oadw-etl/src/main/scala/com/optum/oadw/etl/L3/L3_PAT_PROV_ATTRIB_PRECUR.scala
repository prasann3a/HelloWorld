package com.optum.oadw.etl.L3

import java.sql.Timestamp
import java.time.LocalDateTime

import com.optum.oadw.definedfunctions.{AddMonthsColumnFunction, BitOrAgg, BitOrAggFunction, ListAggFunction, ListAndFunction, ListAgg}
import com.optum.oadw.oadwModels._
import com.optum.oadw.common.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType, TimestampType}
import org.apache.spark.sql.{Column, DataFrame, Dataset, SparkSession}

/**
  *
  * Algorithm specification: https://wiki.humedica.net/display/Data/OADW+Concept+Specification+-+Provider+Attribution
  *
  */
object L3_PAT_PROV_ATTRIB_PRECUR extends TableInfo[l3_pat_prov_attrib_precur] {
  override def name: String = "L3_PAT_PROV_ATTRIB_PRECUR"

  override def dependsOn: Set[String] = Set("MD_OADW_INSTANCE", "L1_MAP_PCP_ORDER", "L2_MAP_CDS_FLG",
    "L2_II_SERVICES_MED", "L2_II_MAP_CONTRACT", "L1_PROV_CLIENT_REL", "L4_DICT_ELIG_CDS",
    "L1_PROV_PAT_REL", "TEMP_PROV_ATTRIB_YRMONTH", "L2_PAT_PROC", "TEMP_PROVIDER_ATTRIBUTION_ALGORITHM_DATA",
    "TEMP_PROVIDER_TO_ALGORITHM"
  )

  override def partitions: Int = 512

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l1ProvClientRel = broadcast(loadedDependencies("L1_PROV_CLIENT_REL").as[l1_prov_client_rel])
    val tMOADWInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]

    val dataThruDt = getDataThruDt(sparkSession, tMOADWInstance)

    val tempProvAttribDomesticProv = broadcast(createListOfDomesticProviders(sparkSession, l1ProvClientRel, dataThruDt))

    val bitOrAgg = BitOrAggFunction.bitOrAgg
    val listAgg = ListAggFunction.listAgg

    val mapPreccursorType = typedLit(Map(
      1 -> "Lowest Data Source Priority",
      2 -> "Highest Data Source Priority",
      3 -> "Latest Start Date",
      4 -> "Earliest Start Date",
      5 -> "Latest End Date",
      6 -> "Earliest End Date",
      7 -> "Most Recent Visit",
      8 -> "Visit Count",
      9 -> "Dollars (Paid)",
      10 -> "Dollars (Allowed)",
      11 -> "Dollars (Normalized)",
      12 -> "Dollars (Paid)",
      13 -> "Dollars (Allowed)",
      14 -> "Dollars (Normalized)"
    ))

    val l1MapPcpOrder = broadcast(loadedDependencies("L1_MAP_PCP_ORDER").as[l1_map_pcp_order])
    val tL2MapCdsFlg = broadcast(loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg])
    val tL4DictEligCds = broadcast(loadedDependencies("L4_DICT_ELIG_CDS").as[l4_dict_elig_cds])
    val l2IIServicesMed = loadedDependencies("L2_II_SERVICES_MED").as[l2_ii_services_med]
    val tL2IIMapContract = broadcast(loadedDependencies("L2_II_MAP_CONTRACT").as[l2_ii_map_contract])

    val colOrder = Seq($"CLIENT_ID", $"MPI", $"PROV_ID", $"YR_MONTH", $"PROV_ATTRIB_PRECURSOR_ID", $"ELIG_CDS_ID",
    $"PRECURSOR_TYPE", $"CDS_GRP", $"PRECURSOR_VALUE", $"DOMESTIC_IND")

    val yrMonth = broadcast(loadedDependencies("TEMP_PROV_ATTRIB_YRMONTH").as[yr_month])
    val l1ProvPatRel = loadedDependencies("L1_PROV_PAT_REL").as[l1_prov_pat_rel]
    val algorithms = loadedDependencies("TEMP_PROVIDER_ATTRIBUTION_ALGORITHM_DATA").as[precursorAlgorithmData]
      .where($"PROV_ATTRIB_PRECUR_TYPE_ID".between(1, 14))
      .withColumn("precursor_type",mapPreccursorType($"PROV_ATTRIB_PRECUR_TYPE_ID"))
    val providerToAlgorithmSet = loadedDependencies("TEMP_PROVIDER_TO_ALGORITHM").as[providerToAlgorithm]

    val oneToSix = calculateType1To6(sparkSession, bitOrAgg, listAgg, yrMonth, l1ProvPatRel, l1MapPcpOrder, algorithms,
      providerToAlgorithmSet, tL2MapCdsFlg, tL4DictEligCds, tempProvAttribDomesticProv, dataThruDt)
      .select(colOrder: _*)
      .toDF()

    val tL2PatProc = loadedDependencies("L2_PAT_PROC").as[l2_pat_proc]

    val sevenAndEight = calculateType7And8(sparkSession, bitOrAgg, listAgg, yrMonth, tL2PatProc, algorithms,
      providerToAlgorithmSet, tL2MapCdsFlg, tL4DictEligCds, tempProvAttribDomesticProv)
      .select(colOrder: _*)
      .toDF()

    val clientId = OADWRuntimeVariables(runtimeVariables).clientId

    val nineToFourteen = calclulateType9To14(sparkSession, bitOrAgg, listAgg, yrMonth, l2IIServicesMed,
      tL2IIMapContract, algorithms, providerToAlgorithmSet, tL2MapCdsFlg, tL4DictEligCds, tempProvAttribDomesticProv,
      clientId)
      .select(colOrder: _*)
      .toDF()

    oneToSix.union(sevenAndEight).union(nineToFourteen)
  }

  private def getDataThruDt(sparkSession: SparkSession, tMOADWInstance: Dataset[md_oadw_instance]): Timestamp = {
    import sparkSession.implicits._
    tMOADWInstance.where($"attribute_name" === lit("DATA_THRU")).select(to_date($"attribute_value", "yyyyMMdd").as("data_thru_dt")).as[Timestamp].collect().headOption.getOrElse(Timestamp.valueOf(LocalDateTime.now()))
  }

  private def createListOfDomesticProviders(sparkSession: SparkSession, l1ProvClientRel: Dataset[l1_prov_client_rel], dataThru: Timestamp): Dataset[String] = {

    import sparkSession.implicits._

    l1ProvClientRel
      .where($"LOCALRELSHIPCODE" === "IN_NETWORK"
        and lit(dataThru).between($"START_DT",$"END_DT")
      )
      .select($"MSTRPROVID")
      .distinct()
      .as[String]
  }

  private def calculateType1To6(sparkSession: SparkSession, bitOrAgg: BitOrAgg,
                                listAgg: ListAgg, yrMonthSet: Dataset[yr_month],
                                l1ProvPatRel: Dataset[l1_prov_pat_rel],
                                l1MapPcpOrder: Dataset[l1_map_pcp_order],
                                algorithms: DataFrame,
                                providerToAlgorithmSetLoaded: Dataset[providerToAlgorithm],
                                tL2MapCdsFlg: Dataset[l2_map_cds_flg],
                                tL4DictEligCds: Dataset[l4_dict_elig_cds],
                                tempProvAttribDomesticProv: Dataset[String],
                                dataThru: Timestamp): Dataset[l3_pat_prov_attrib_precur] = {

    import sparkSession.implicits._

    val count = l1MapPcpOrder.count()

    val providerToAlgorithmSet = providerToAlgorithmSetLoaded.where($"PROV_ATTRIB_PRECUR_TYPE_ID" >= 1 and $"PROV_ATTRIB_PRECUR_TYPE_ID" <= 6).toDF()

    val addMonthsColumn = AddMonthsColumnFunction.addMonthsColumn

    val algorithm_yrmonth = algorithms
      .where ($"PROV_ATTRIB_PRECUR_TYPE_ID" >= 1 and $"PROV_ATTRIB_PRECUR_TYPE_ID" <= 6)
      .as("alg")
      .join(yrMonthSet.select($"month_number",$"start_month_dt",$"end_month_dt",$"yr_month").as("yrmonth"), $"alg.num_yr_months" >= $"yrmonth.month_number")
      .select($"alg.*",$"yrmonth.*",addMonthsColumn($"yrmonth.start_month_dt", lit(1) - $"alg.lookback_months").as("addedMonths"))
      .repartition($"alg.PROC_CD", $"addedMonths", $"prov_attrib_precursor_id")

    val base7and8WithProvider = algorithm_yrmonth
      .join(providerToAlgorithmSet.as("pToA"), $"pToA.PROV_ATTRIB_PRECURSOR_ID" === $"alg.PROV_ATTRIB_PRECURSOR_ID")
      .toDF()

    val filteredPatients = l1ProvPatRel
      .select($"MSTRPROVID", $"client_id", $"client_ds_id", $"datasrc", $"localrelshipcode", $"mpi", $"start_dt", $"end_dt")
      .where($"localrelshipcode" === lit("PCP") and $"mpi".isNotNull)
      .as("ppr")
      .join(l1MapPcpOrder.select($"client_id", $"client_ds_id", $"datasrc", $"pcp_order", $"pcp_exclude_flg")
        .as("mpo"), $"ppr.client_id" === $"mpo.client_id" and $"ppr.client_ds_id" === $"mpo.client_ds_id" and $"ppr.datasrc" === $"mpo.datasrc", "left_outer")
      .where(coalesce($"pcp_exclude_flg", lit("N")) =!= lit("Y"))
      .join(tL2MapCdsFlg.select($"client_ds_id", $"DATA_GRP_FLG", $"SOURCE_TYPE_FLG", $"client_id").as("mcf"), $"ppr.client_ds_id" === $"mcf.client_ds_id")
      .join(base7and8WithProvider, $"ppr.mstrprovid" === $"pToA.PROV_ID")
      .where($"ppr.start_dt" <= $"yrmonth.end_month_dt" and coalesce($"ppr.end_dt", lit(dataThru)) >= $"addedMonths")

      filteredPatients
      .join(tL4DictEligCds.select($"FOR_EACH_CDS_IND", $"ELIG_CDS_GRP", $"ELIG_CDS_ID")
        .as("cds"),
        $"alg.FOR_EACH_CDS_IND" === 1 and
          $"cds.FOR_EACH_CDS_IND" === 1 and
          ListAndFunction.listAnd(coalesce($"cds.ELIG_CDS_GRP", lit("")), coalesce($"mcf.client_ds_id", lit(""))) =!= 0 , "left_outer")
      .where(
        not($"alg.FOR_EACH_CDS_IND" === 1 and $"cds.ELIG_CDS_ID".isNull) and
          $"mcf.SOURCE_TYPE_FLG".bitwiseAND($"alg.ELIG_SOURCE_TYPE_FLG") =!= 0
      )
      .join(tempProvAttribDomesticProv.as("dom"), $"PROV_ID" === $"dom.MSTRPROVID", "left_outer")
      .select(
        $"ppr.client_id", $"ppr.mpi", $"ppr.start_dt", $"ppr.end_dt", $"ppr.mstrprovid".as("prov_id"),
        $"mpo.pcp_order",
        $"mcf.DATA_GRP_FLG", $"mcf.source_type_flg", $"mcf.client_ds_id",
        $"cds.ELIG_CDS_ID",
        $"alg.PROV_ATTRIB_PRECURSOR_ID", $"alg.PROV_ATTRIB_PRECUR_TYPE_ID",
        when($"dom.MSTRPROVID".isNull, 0).otherwise(1).as("DOMESTIC_IND"),
        $"yrmonth.yr_month",
        $"precursor_type",
        first($"end_dt").over(Window.orderBy($"end_dt".desc_nulls_first).partitionBy( $"MPI", $"PROV_ID", $"YR_MONTH", $"alg.PROV_ATTRIB_PRECURSOR_ID", $"cds.ELIG_CDS_ID", $"alg.PROV_ATTRIB_PRECUR_TYPE_ID")).as("end_dt_desc"),
        first($"end_dt").over(Window.orderBy($"end_dt".asc_nulls_last).partitionBy($"MPI", $"PROV_ID", $"YR_MONTH", $"alg.PROV_ATTRIB_PRECURSOR_ID", $"cds.ELIG_CDS_ID", $"alg.PROV_ATTRIB_PRECUR_TYPE_ID")).as("end_dt_asc")
      )
      .groupBy($"CLIENT_ID", $"MPI", $"PROV_ID", $"YR_MONTH", $"PROV_ATTRIB_PRECURSOR_ID", $"ELIG_CDS_ID", $"PROV_ATTRIB_PRECUR_TYPE_ID", $"precursor_type", $"DOMESTIC_IND")
      .agg(
        listAgg($"client_ds_id").as("CDS_GRP"),
        when($"PROV_ATTRIB_PRECUR_TYPE_ID" === 1,
          count match {
            case 0 => // CAST(MAX(CASE WHEN mcf.source_type_flg=1 THEN 1 ELSE 2 END) AS VARCHAR(12))
              max(when($"source_type_flg" === 1, 1).otherwise(2)).cast(IntegerType).cast(StringType)
            case _ => // CAST(NVL(MAX(mpo.pcp_order),99) AS VARCHAR(12))
              coalesce(max($"pcp_order"), lit(99)).cast(StringType)
          }
        ).when($"PROV_ATTRIB_PRECUR_TYPE_ID" === 2,
          count match {
            case 0 => // CAST(MIN(CASE WHEN mcf.source_type_flg=1 THEN 1 ELSE 2 END)
              min(when($"source_type_flg" === 1, 1).otherwise(2)).cast(IntegerType).cast(StringType)
            case _ => // CAST(MIN(NVL(mpo.pcp_order,99)) AS VARCHAR(12))
              min(coalesce($"pcp_order", lit(99))).cast(StringType)
          }
        ).when($"PROV_ATTRIB_PRECUR_TYPE_ID" === 3,
          max($"start_dt").cast(StringType)
        ).when($"PROV_ATTRIB_PRECUR_TYPE_ID" === 4,
          min($"start_dt").cast(StringType)
        ).when($"PROV_ATTRIB_PRECUR_TYPE_ID" === 5,
          // MAX(ppr.end_dt) KEEP (DENSE_RANK FIRST ORDER BY END_DT DESC NULLS FIRST)
          // converted to non-Oracle by following https://stackoverflow.com/questions/29750563/convert-keep-dense-rank-from-oracle-query-into-postgres
          max($"end_dt_desc").cast(StringType)
        ).when($"PROV_ATTRIB_PRECUR_TYPE_ID" === 6,
          // MIN(ppr.end_dt) KEEP (DENSE_RANK FIRST ORDER BY END_DT ASC NULLS LAST)
          // converted to non-Oracle by following https://stackoverflow.com/questions/29750563/convert-keep-dense-rank-from-oracle-query-into-postgres
          min($"end_dt_asc").cast(StringType)
        ).as("PRECURSOR_VALUE")
      ).as[l3_pat_prov_attrib_precur]

  }

  private def calculateType7And8(sparkSession: SparkSession, bitOrAgg: BitOrAgg,
                                 listAgg: ListAgg, yrMonthSet: Dataset[yr_month],
                                 tL2PatProc: Dataset[l2_pat_proc],
                                 algorithms: DataFrame,
                                 providerToAlgorithmSetLoaded: Dataset[providerToAlgorithm],
                                 tL2MapCdsFlg: Dataset[l2_map_cds_flg],
                                 tL4DictEligCds: Dataset[l4_dict_elig_cds],
                                 tempProvAttribDomesticProv: Dataset[String]): Dataset[l3_pat_prov_attrib_precur] = {

    import sparkSession.implicits._

    val providerToAlgorithmSet = providerToAlgorithmSetLoaded.where($"prov_attrib_precur_type_id".between(7,8)).toDF()

    val tL2PatProcSelected = tL2PatProc
      .where($"MPI".isNotNull)
      .join(tempProvAttribDomesticProv.as("dom"), $"PROV_ID" === $"dom.MSTRPROVID", "left_outer")
      .select($"PROV_ID", $"MPI", $"PLACE_OF_SVC", $"PROC_CD", $"CDS_GRP", $"proc_dtm", $"CLIENT_ID", $"MPI", $"PROV_ID", $"CODE_TYPE",
        when($"dom.MSTRPROVID".isNull, 0).otherwise(1).as("DOMESTIC_IND"), to_date($"proc_dtm").cast(TimestampType).as("proc_timestamp"))
      .as("pp")

    val addMonthsColumn = AddMonthsColumnFunction.addMonthsColumn

    val algorithm_yrmonth = algorithms
      .where($"PROV_ATTRIB_PRECUR_TYPE_ID" >= 7 and $"PROV_ATTRIB_PRECUR_TYPE_ID" <= 8)
      .as("alg")
      .join(yrMonthSet.select($"month_number",$"start_month_dt",$"end_month_dt",$"yr_month").as("yrmonth"), $"alg.num_yr_months" >= $"yrmonth.month_number")
      .select($"alg.*",$"yrmonth.*",addMonthsColumn($"yrmonth.start_month_dt", lit(1) - $"alg.lookback_months").as("addedMonths"))
      .repartition($"alg.PROC_CD", $"addedMonths", $"prov_attrib_precursor_id")


    val base7and8WithProvider = algorithm_yrmonth
      .join(providerToAlgorithmSet.as("pToA"), $"pToA.PROV_ATTRIB_PRECURSOR_ID" === $"alg.PROV_ATTRIB_PRECURSOR_ID")
      .toDF()

    val base7and8WithoutProvider = algorithm_yrmonth.toDF()

    def doJoin(base7And8: DataFrame, baseJoin: Column): DataFrame = {
      tL2PatProcSelected.join(base7And8, baseJoin and ($"pp.PROC_CD" === $"alg.PROC_CD" and $"pp.CODE_TYPE" === $"alg.CODE_TYPE"))
        .where(
          $"pp.proc_timestamp".between($"addedMonths", $"yrmonth.end_month_dt") and not($"alg.DOMESTIC_ONLY_IND" === 1 and $"pp.DOMESTIC_IND" === 0)
        )
    }

    val joinOnProvId = doJoin(base7and8WithProvider, $"pToA.PROV_ID" === $"pp.PROV_ID")
    val joinOnPOS = doJoin(base7and8WithoutProvider, $"alg.CODE" === $"pp.PLACE_OF_SVC")

    val joinOnProvIdSortedCols = joinOnProvId.select("alg.*", "pp.*", "yrmonth.*")
    val joinOnPOSSortedCols = joinOnPOS.select("alg.*", "pp.*", "yrmonth.*")

    joinOnProvIdSortedCols.union(joinOnPOSSortedCols)
      .join(tL2MapCdsFlg.select($"client_ds_id", $"DATA_GRP_FLG", $"SOURCE_TYPE_FLG", $"client_id").as("mcf"), ListAndFunction.listAnd(coalesce($"pp.CDS_GRP", lit("")),coalesce($"mcf.client_ds_id", lit(""))) =!= 0)
      .join(tL4DictEligCds.select($"FOR_EACH_CDS_IND", $"ELIG_CDS_ID", $"ELIG_CDS_GRP").as("cds"),
        $"alg.FOR_EACH_CDS_IND" === lit(1) and
          $"cds.FOR_EACH_CDS_IND" === lit(1) and
       ListAndFunction.listAnd(coalesce($"cds.ELIG_CDS_GRP", lit("")),coalesce($"pp.CDS_GRP", lit(""))) =!= 0 , "left_outer")
      .where(
        not($"alg.FOR_EACH_CDS_IND" === lit(1) and $"cds.ELIG_CDS_ID".isNull) and
          $"mcf.SOURCE_TYPE_FLG".bitwiseAND($"alg.ELIG_SOURCE_TYPE_FLG") =!= 0
      )
      .groupBy($"pp.CLIENT_ID",
        $"pp.MPI",
        $"pp.PROV_ID",
        $"yrmonth.YR_MONTH",
        $"alg.PROV_ATTRIB_PRECURSOR_ID",
        $"cds.ELIG_CDS_ID",
        $"alg.PROV_ATTRIB_PRECUR_TYPE_ID",
        $"pp.DOMESTIC_IND",
        $"alg.precursor_type")
      .agg(
        listAgg($"mcf.client_ds_id").as("CDS_GRP"),
        when($"alg.PROV_ATTRIB_PRECUR_TYPE_ID" === 7,
          max($"pp.proc_timestamp").cast(StringType)
        ).when($"alg.PROV_ATTRIB_PRECUR_TYPE_ID" === 8,
          countDistinct($"pp.proc_timestamp").cast(StringType)
        ).as("PRECURSOR_VALUE")
      ).as[l3_pat_prov_attrib_precur]

  }

  private def calclulateType9To14(sparkSession: SparkSession, bitOrAgg: BitOrAgg,
                                  listAgg: ListAgg, yrMonthSet: Dataset[yr_month],
                                  l2IIServicesMed: Dataset[l2_ii_services_med],
                                  tL2IIMapContract: Dataset[l2_ii_map_contract],
                                  algorithms: DataFrame,
                                  providerToAlgorithmSetLoaded: Dataset[providerToAlgorithm],
                                  tL2MapCdsFlg: Dataset[l2_map_cds_flg],
                                  tL4DictEligCds: Dataset[l4_dict_elig_cds],
                                  tempProvAttribDomesticProv: Dataset[String],
                                  clientId: String): Dataset[l3_pat_prov_attrib_precur] = {

    import sparkSession.implicits._

    val providerToAlgorithmSet = providerToAlgorithmSetLoaded.where($"PROV_ATTRIB_PRECUR_TYPE_ID" >= 9 and $"PROV_ATTRIB_PRECUR_TYPE_ID" <= 14).toDF()

    val medPatients = l2IIServicesMed.select($"PROVIDER_ID", $"POS_I", $"REVENUE", $"PROCCODE", to_date(date_format($"DOS", "yyyy-MM-dd")).cast(TimestampType).as("DOS"),
      $"AMT_EQV", $"AMT_PAY", $"AMT_NP", $"AMT_EQV_K", $"AMT_PAY_K", $"AMT_NP_K", $"CONTRACT_ID", $"MEMBER")
      .where($"MEMBER".isNotNull)
      .as("clm")
      .join(tL2IIMapContract.select($"CONTRACT_ID", $"CLIENT_DS_ID").as("imc"), $"clm.CONTRACT_ID" === $"imc.CONTRACT_ID")

    val algColumns = Seq(
      $"alg.PROV_ATTRIB_PRECURSOR_ID", $"alg.PROC_GROUP_ID", $"alg.ELIG_PROV_ID", $"alg.LOOKBACK_MONTHS", $"alg.PROV_ATTRIB_PRECUR_TYPE_ID",
      $"alg.ELIG_SOURCE_TYPE_FLG", $"alg.FOR_EACH_CDS_IND", $"alg.NUM_YR_MONTHS", $"alg.DOMESTIC_ONLY_IND", $"alg.PROC_CD", $"alg.CODE_TYPE", $"alg.precursor_type"
    )

    val addMonthsColumn = AddMonthsColumnFunction.addMonthsColumn

    val algorithm_yrmonth = algorithms
      .where($"PROV_ATTRIB_PRECUR_TYPE_ID" >= 9 and $"PROV_ATTRIB_PRECUR_TYPE_ID" <= 14)
      .as("alg")
      .join(yrMonthSet.select($"month_number",$"start_month_dt",$"end_month_dt",$"yr_month").as("yrmonth"), $"alg.num_yr_months" >= $"yrmonth.month_number")
      .select($"alg.*",$"yrmonth.*",addMonthsColumn($"yrmonth.start_month_dt", lit(1) - $"alg.lookback_months").as("addedMonths"))
      .repartition($"alg.PROC_CD", $"addedMonths", $"prov_attrib_precursor_id")

    val algorithms9To14WithProvider = algorithm_yrmonth
      .join(providerToAlgorithmSet.as("pToA"), $"pToA.PROV_ATTRIB_PRECURSOR_ID" === $"alg.PROV_ATTRIB_PRECURSOR_ID")
      .select(
        algColumns :+  $"yrmonth.*" :+ $"PROV_ID":+ $"addedMonths": _*
      ).distinct()


    val algorithms9To14WithoutProvider = algorithm_yrmonth.toDF()

    def doJoin(base9To14: DataFrame, baseExpression: Column): DataFrame = {
      base9To14.join(medPatients, baseExpression and
        when($"alg.PROC_GROUP_ID".isNull,lit(true))
          .when($"alg.CODE_TYPE" === "REV",$"clm.REVENUE" === $"alg.PROC_CD")
          .when($"alg.CODE_TYPE".isin("CPT4", "HCPCS"),$"clm.PROCCODE" === $"alg.PROC_CD")
          .otherwise(lit(false))
      ) .where(
        $"clm.DOS".between($"addedMonths", $"yrmonth.end_month_dt")
      )

    }

    val provIdJoin = doJoin(algorithms9To14WithProvider, $"pToA.PROV_ID" === $"clm.PROVIDER_ID")

    val codeJoin = doJoin(algorithms9To14WithoutProvider, $"clm.POS_I" === $"alg.CODE")

    val provIdJoinSortedCols = provIdJoin.select("clm.*", "alg.*", "imc.*", "yrmonth.*")
    val codeJoinSortedCols = codeJoin.select($"clm.*" +: algColumns :+  $"imc.*":+ $"yrmonth.*":_*)

    val allMed = provIdJoinSortedCols.union(codeJoinSortedCols)

    val mcf = tL2MapCdsFlg.select($"client_ds_id", $"DATA_GRP_FLG", $"SOURCE_TYPE_FLG", $"client_id").as("mcf")


    allMed.join(mcf, $"imc.client_ds_id" === $"mcf.client_ds_id")
      .join(tL4DictEligCds.select($"FOR_EACH_CDS_IND", $"ELIG_CDS_ID", $"ELIG_CDS_GRP")
        .as("cds"),
        $"alg.FOR_EACH_CDS_IND" === lit(1) and
          $"cds.FOR_EACH_CDS_IND" === lit(1) and
          ListAndFunction.listAnd(coalesce($"cds.ELIG_CDS_GRP", lit("")),coalesce($"mcf.client_ds_id", lit(""))) =!= 0 , "left_outer")
      .where(
        not($"alg.FOR_EACH_CDS_IND" === lit(1) and $"cds.ELIG_CDS_ID".isNull) and
          $"mcf.SOURCE_TYPE_FLG".bitwiseAND($"alg.ELIG_SOURCE_TYPE_FLG") =!= 0
      )
      .join(tempProvAttribDomesticProv.as("dom"), $"clm.PROVIDER_ID" === $"dom.MSTRPROVID", "left_outer")
      .select(
        lit(clientId).as("client_id"), $"clm.MEMBER".as("mpi"), $"clm.PROVIDER_ID".as("PROV_ID"),
        $"yrmonth.yr_month",
        $"alg.PROV_ATTRIB_PRECURSOR_ID", $"alg.PROV_ATTRIB_PRECUR_TYPE_ID",
        $"cds.ELIG_CDS_ID",
        when($"dom.MSTRPROVID".isNull, 0).otherwise(1).as("DOMESTIC_IND"),
        $"clm.AMT_PAY_K", $"clm.AMT_EQV_K", $"clm.AMT_NP_K", $"clm.AMT_PAY", $"clm.AMT_EQV", $"clm.AMT_NP",
        $"mcf.DATA_GRP_FLG", $"precursor_type", $"mcf.client_ds_id"
      )
      .groupBy($"CLIENT_ID", $"MPI", $"PROV_ID", $"YR_MONTH", $"PROV_ATTRIB_PRECURSOR_ID", $"ELIG_CDS_ID", $"PROV_ATTRIB_PRECUR_TYPE_ID", $"DOMESTIC_IND", $"precursor_type")
      .agg(
        listAgg($"mcf.client_ds_id").as("CDS_GRP"),
        when($"alg.PROV_ATTRIB_PRECUR_TYPE_ID" === 9,
          bround(sum($"clm.AMT_PAY_K"), 2).cast(StringType)
        ).when($"alg.PROV_ATTRIB_PRECUR_TYPE_ID" === 10,
          bround(sum($"clm.AMT_EQV_K"), 2).cast(StringType)
        ).when($"alg.PROV_ATTRIB_PRECUR_TYPE_ID" === 11,
          bround(sum($"clm.AMT_NP_K"), 2).cast(StringType)
        ).when($"alg.PROV_ATTRIB_PRECUR_TYPE_ID" === 12,
          bround(sum($"clm.AMT_PAY"), 2).cast(StringType)
        ).when($"alg.PROV_ATTRIB_PRECUR_TYPE_ID" === 13,
          bround(sum($"clm.AMT_EQV"), 2).cast(StringType)
        ).when($"alg.PROV_ATTRIB_PRECUR_TYPE_ID" === 14,
          bround(sum($"clm.AMT_NP"), 2).cast(StringType)
        ).as("PRECURSOR_VALUE")
      ).as[l3_pat_prov_attrib_precur]

  }

}
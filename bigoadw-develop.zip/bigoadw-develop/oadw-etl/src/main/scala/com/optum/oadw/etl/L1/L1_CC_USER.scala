
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_cc_user, cc_user}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_CC_USER extends TableInfo[l1_cc_user]{
  override def dependsOn: Set[String] = Set("CC_USER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CC_USER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ccUser = loadedDependencies("CC_USER").as[cc_user]

    ccUser
    .select(
			$"active_ind",
			$"care_coordinator_ind",
			$"client_ds_id",
			$"datasrc",
			$"groupid".as("client_id"),
			$"last_login_dt",
			$"user_email",
			$"user_first_nm",
			$"user_id",
			$"user_last_nm",
			$"user_nm"
    )
  }
}


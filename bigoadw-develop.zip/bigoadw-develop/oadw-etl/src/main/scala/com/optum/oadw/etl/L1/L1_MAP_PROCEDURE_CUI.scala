package com.optum.oadw.etl.L1

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.etl.constants.Procedures
import com.optum.oadw.oadwModels._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


object L1_MAP_PROCEDURE_CUI extends TableInfo[l1_map_procedure_cui] {
	override def name: String = "L1_MAP_PROCEDURE_CUI"

  def directoryLevel: String = "L1"

  override def dependsOn: Set[String] = Set("L1_MAP_PROCEDURE", "L1_REF_MAP_CCS_ICDX_PX", "L1_REF_ICD9_PX",
    "L1_REF_ICD0_PX", "L3_MAP_TOS", "L1_REF_IMAP_TOS_PROC")


  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l1MapProcedure = loadedDependencies("L1_MAP_PROCEDURE").as[l1_map_procedure]

    val l1RefMapCCSICDXPx = loadedDependencies("L1_REF_MAP_CCS_ICDX_PX").as[l1_ref_map_ccs_icdx_px]

    val l1RefICD9Px = loadedDependencies("L1_REF_ICD9_PX").as[l1_ref_icd9_px]

    val l1RefICD0Px = loadedDependencies("L1_REF_ICD0_PX").as[l1_ref_icd0_px]

    val l3MapTos = loadedDependencies("L3_MAP_TOS").as[l3_map_tos]

    val l1RefImapTosProc = loadedDependencies("L1_REF_IMAP_TOS_PROC").as[l1_ref_imap_tos_proc]

    val ccsCat = l1MapProcedure.as("t").where($"t.codetype" === Procedures.CODE_TYPE_CCSCAT)
      .join(l1RefMapCCSICDXPx.as("refmap"), $"t.mappedcode" === $"refmap.ccs_category")
      .select(
        when($"refmap.icd_version" === "9", Procedures.CODE_TYPE_ICD9).otherwise(Procedures.CODE_TYPE_ICD10).as("codetype"),
        $"refmap.icd_cm_code".as("mappedcode"),
        $"t.cui"
      )

    val icd9 = l1MapProcedure.as("t").where($"t.codetype" === Procedures.CODE_TYPE_ICD9)
      .join(l1RefICD9Px.as("reficd9"), expr("reficd9.procedure_code like t.mappedcode"))
      .select(
        $"t.codetype",
        $"reficd9.procedure_code".as("mappedcode"),
        $"t.cui"
      ).distinct()

    val icd10 = l1MapProcedure.as("t").where($"t.codetype" === Procedures.CODE_TYPE_ICD10)
      .repartition($"t.mappedcode")
      .join(l1RefICD0Px.as("reficd10"), expr("reficd10.procedure_code like t.mappedcode"))
      .select(
        $"t.codetype",
        $"reficd10.procedure_code".as("mappedcode"),
        $"t.cui"
      ).distinct()

    val cpt = l1MapProcedure
      .where($"codetype".isin(Procedures.CODE_TYPE_CPT, Procedures.CODE_TYPE_CPTMOD, Procedures.CODE_TYPE_CUSTOM, Procedures.CODE_TYPE_HCPCS, Procedures.CODE_TYPE_REV))
      .select(
        when($"codetype" === Procedures.CODE_TYPE_CPT, Procedures.CODE_TYPE_CPT4).otherwise($"codetype").as("codetype"),
        $"mappedcode",
        $"cui"
      )

    val tosI3 = l1MapProcedure.as("t").where($"t.codetype" === Procedures.CODE_TYPE_TOS_I_3)
      .join(l3MapTos.as("maptos"), $"t.mappedcode" === $"maptos.tos3_id")
      .join(l1RefImapTosProc.where(length($"map_code") =!= 4).as("refimap"), $"maptos.tos5_id" === $"refimap.prof_tos")
      .select(
        when($"refimap.map_code" rlike Procedures.REGEXP_CPT4_CODE_MATCH, lit(Procedures.CODE_TYPE_CPT4))
          .when($"refimap.map_code" rlike Procedures.REGEXP_HCPCS_CODE_MATCH, lit(Procedures.CODE_TYPE_HCPCS))
          .otherwise(null).as("codetype"),
        $"refimap.map_code".as("mappedcode"),
        $"t.cui"
      )
    ccsCat.union(icd9).union(icd10).union(cpt).union(tosI3)
  }
}
     

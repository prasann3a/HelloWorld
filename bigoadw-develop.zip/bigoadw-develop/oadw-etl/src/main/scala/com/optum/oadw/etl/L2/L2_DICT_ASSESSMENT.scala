package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l1_map_assessment_cui, l1_map_obstype, l1_map_lab, l2_dict_assessment, md_domain_concept}
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oadw.oadw_ref.models.l2_map_sensitive_category
import org.apache.spark.sql.functions._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.IntegerType

object L2_DICT_ASSESSMENT extends TableInfo[l2_dict_assessment] {
  override def name: String = "L2_DICT_ASSESSMENT"

  def directoryLevel: String = "L2"

  override def dependsOn: Set[String] = Set("L1_MAP_LAB","MD_DOMAIN_CONCEPT", "L1_MAP_OBSTYPE", "L1_MAP_ASSESSMENT_CUI","L2_MAP_SENSITIVE_CATEGORY")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1MapObstype = loadedDependencies("L1_MAP_OBSTYPE").as[l1_map_obstype]
    val l1MapAssessmentCui = loadedDependencies("L1_MAP_ASSESSMENT_CUI").as[l1_map_assessment_cui].select($"map_cui").distinct()
    val tMdDomainConcept = loadedDependencies("MD_DOMAIN_CONCEPT").as[md_domain_concept]
    val mdLab = loadedDependencies("L1_MAP_LAB").as[l1_map_lab]
    val l2MapSensitiveCategory = broadcast(loadedDependencies("L2_MAP_SENSITIVE_CATEGORY").as[l2_map_sensitive_category])

    val observations = l1MapObstype.as("a")
      .join(l1MapAssessmentCui.as("b"),$"a.obstype_cui" === $"b.map_cui","left")
      .join(tMdDomainConcept.as("dc"),$"a.obstype_cui" === $"dc.concept_cui" && $"dc.domain_cui" === "CH001304")
      .join(tMdDomainConcept.as("uc"),$"a.obstype_std_units" === $"uc.concept_cui" && $"uc.domain_cui" === "CH001302","left")
      .select(
        $"a.obstype_cui".as("assessment_cui"),
        $"dc.concept_name".as("assessment_name"),
        when($"a.obstype_std_units" === "CH001218",null).otherwise($"uc.concept_name").as("assessment_units"),
        lit(0).cast(IntegerType).as("lab_ind"),
        when($"a.datatype".isin("CV") && $"b.map_cui".isNotNull,1).otherwise(0).cast(IntegerType).as("qualitative_ind"),
        when($"a.datatype".isin("P","N"),1).otherwise(0).cast(IntegerType).as("quantitative_ind"),
        when($"a.sensitive_ind" === 1 || $"dc.sensitive_ind" === 1,lit(1)).otherwise(lit(0)).as("sensitive_ind")
      )
      .where($"a.validated_ind" === 1 && ($"a.datatype".isin("P","N") || ($"a.datatype".isin("CV") && $"b.map_cui".isNotNull)))

    val labs = mdLab.as("b")
      .join(tMdDomainConcept.as("ac"),$"b.cui" === $"ac.concept_cui" && $"ac.domain_cui" === "CH001281")
      .join(tMdDomainConcept.as("uc"),$"b.unit" === $"uc.concept_cui" && $"uc.domain_cui" === "CH001302","left")
      .select(
        $"b.cui".as("assessment_cui"),
        $"ac.concept_name".as("assessment_name"),
        when($"b.unit" === "CH001218",null).otherwise($"uc.concept_name").as("assessment_units"),
        lit(1).cast(IntegerType).as("lab_ind"),
        when($"b.result_type".isin("CH003061","CH003060"),1).otherwise(0).cast(IntegerType).as("qualitative_ind"),
        when($"b.result_type".isin("CH003061","CH003059"),1).otherwise(0).cast(IntegerType).as("quantitative_ind"),
        when($"b.sensitive_ind" === 1 || $"ac.sensitive_ind" === 1,lit(1)).otherwise(lit(0)).as("sensitive_ind")
      )
      .where($"b.validated_ind" === 1)

    val calculated = tMdDomainConcept.select(
      $"concept_cui".as("assessment_cui"),
      $"concept_name".as("assessment_name"),
      lit(null).as[String].as("assessment_units"),
      lit(0).cast(IntegerType).as("lab_ind"),
      lit(0).cast(IntegerType).as("qualitative_ind"),
      lit(1).cast(IntegerType).as("quantitative_ind"),
      $"sensitive_ind"
    ).where($"domain_cui" === "CH003715")

    observations
      .union(labs)
      .union(calculated)
      .join(l2MapSensitiveCategory.select($"sensitive_text",$"sensitive_hierarchy",$"sensitive_cat_id").as("sc"), expr("UPPER(assessment_name) LIKE CONCAT('%', UPPER(sensitive_text), '%')"), "left_outer")
      .select(
        $"assessment_cui",
        $"assessment_name",
        $"assessment_units",
        $"lab_ind",
        $"qualitative_ind",
        $"quantitative_ind",
        $"sensitive_ind",
        $"sensitive_text",
        $"sensitive_hierarchy",
        when($"sensitive_ind" === 1,coalesce($"sensitive_cat_id", lit(999))).otherwise(1).as("sensitive_cat_id")
      )
      .withColumn("order",when($"sensitive_text".isNotNull,row_number().over(Window.partitionBy($"assessment_cui").orderBy($"sensitive_hierarchy")))
      .otherwise(lit(1)))
      .where($"order" === 1)
      .drop("sensitive_hierarchy","sensitive_text","order")

  }


  def originalSql: String = """

INSERT /*+ APPEND */ INTO L2_dict_assessment(assessment_cui,assessment_name,assessment_units,lab_ind,qualitative_ind,quantitative_ind)
SELECT b.cui AS assessment_cui
       ,ac.concept_name as assessment_name
       ,case when b.unit = 'CH001218' then '' else uc.concept_name end as assessment_units
       ,1 AS lab_ind
       ,CASE WHEN b.result_type IN ('CH003061','CH003060') THEN 1 ELSE 0 END AS qualitative_ind
       ,CASE WHEN b.result_type IN ('CH003061','CH003059') THEN 1 ELSE 0 END AS quantitative_ind
FROM l1_map_lab b
INNER JOIN md_domain_concept ac ON (b.cui = ac.concept_cui AND ac.domain_cui = 'CH001281')cd
LEFT OUTER JOIN md_domain_concept uc ON (b.unit = uc.concept_cui AND uc.domain_cui = 'CH001302')
WHERE b.validated_ind = 1
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(
    OutputColumn("assessment_cui",None,None),
    OutputColumn("assessment_name",None,None),
    OutputColumn("assessment_units",None,None),
    OutputColumn("lab_ind",None,None),
    OutputColumn("qualitative_ind",None,None),
    OutputColumn("quantitative_ind",None,None)))




}


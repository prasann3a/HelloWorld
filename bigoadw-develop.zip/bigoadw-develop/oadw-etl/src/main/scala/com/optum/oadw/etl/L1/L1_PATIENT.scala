
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patient, patient}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENT extends TableInfo[l1_patient]{
  override def dependsOn: Set[String] = Set("PATIENT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patient = loadedDependencies("PATIENT").as[patient]

    patient
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"patientid",
			$"facilityid",
			$"dateofbirth".as("dateofbirth"),
			$"medicalrecordnumber",
			$"hgpid",
			$"dateofdeath",
			$"client_ds_id",
			$"grp_mpi".as("mpi"),
			$"inactive_flag"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_program_status, map_program_status}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_PROGRAM_STATUS extends TableInfo[l1_map_program_status]{
  override def dependsOn: Set[String] = Set("MAP_PROGRAM_STATUS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_PROGRAM_STATUS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapProgramStatus = loadedDependencies("MAP_PROGRAM_STATUS").as[map_program_status]

    mapProgramStatus
    .select(
			$"localcode".as("local_code"),
			$"cui",
			$"dts_version"
    )
  }
}


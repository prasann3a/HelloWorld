
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_pcp_order, map_pcp_order}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_PCP_ORDER extends TableInfo[l1_map_pcp_order]{
  override def dependsOn: Set[String] = Set("MAP_PCP_ORDER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_PCP_ORDER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapPcpOrder = loadedDependencies("MAP_PCP_ORDER").as[map_pcp_order]

    mapPcpOrder
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"pcp_order",
			$"pcp_exclude_flg",
			$"dts_version"
    )
  }
}


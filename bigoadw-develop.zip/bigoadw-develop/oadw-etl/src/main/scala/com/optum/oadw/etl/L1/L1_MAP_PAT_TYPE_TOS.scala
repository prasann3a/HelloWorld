
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_pat_type_tos, map_pat_type_tos}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_PAT_TYPE_TOS extends TableInfo[l1_map_pat_type_tos]{
  override def dependsOn: Set[String] = Set("MAP_PAT_TYPE_TOS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_PAT_TYPE_TOS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapPatTypeTos = loadedDependencies("MAP_PAT_TYPE_TOS").as[map_pat_type_tos]

    mapPatTypeTos
    .select(
			$"inst_prof",
			$"patient_type_cui",
			$"tos_i_5".as("tos_i_5"),
			$"dts_version"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_encounterreason, encounterreason}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_ENCOUNTERREASON extends TableInfo[l1_encounterreason]{
  override def dependsOn: Set[String] = Set("ENCOUNTERREASON")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_ENCOUNTERREASON"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val encounterreason = loadedDependencies("ENCOUNTERREASON").as[encounterreason]

    encounterreason
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"client_ds_id",
			$"patientid",
			$"encounterid",
			$"localreasontext",
			$"reasontime".as("reason_dtm"),
			$"mappedreason",
			$"grp_mpi".as("mpi")
    )
  }
}


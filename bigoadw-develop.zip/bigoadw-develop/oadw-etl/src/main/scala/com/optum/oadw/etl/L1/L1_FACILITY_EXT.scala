
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_facility_ext, facility_ext}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_FACILITY_EXT extends TableInfo[l1_facility_ext]{
  override def dependsOn: Set[String] = Set("FACILITY_EXT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_FACILITY_EXT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val facilityExt = loadedDependencies("FACILITY_EXT").as[facility_ext]

    facilityExt
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"facilityid",
			$"siteofcare_cd",
			$"siteofcare_nm",
			$"siteofcare_postal_cd",
			$"master_facility_cd",
			$"master_facility_nm",
			$"enc_grp_ind",
			$"facility_postal_cd",
			$"patient_type_cui",
			$"hgfacid",
			$"master_hgfacid",
			$"master_siteofcare_id"
    )
  }
}


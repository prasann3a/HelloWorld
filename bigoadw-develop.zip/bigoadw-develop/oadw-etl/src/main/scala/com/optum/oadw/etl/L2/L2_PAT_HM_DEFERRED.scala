package com.optum.oadw.etl.L2

import java.sql.Timestamp

import com.optum.oadw.definedfunctions.{BitOrAggFunction, ListAggFunction}
import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}

import scala.collection.JavaConverters.collectionAsScalaIterableConverter

object L2_PAT_HM_DEFERRED extends TableInfo[l2_pat_hm_deferred] {
  override def name: String = "L2_PAT_HM_DEFERRED"

  override def dependsOn: Set[String] = Set(
    "MD_DOMAIN_CONCEPT",
    "L2_MAP_CDS_FLG",
    "L1_MAP_ACO_EXCLUSION",
    "MD_OADW_INSTANCE",
    "L1_OBSERVATION",
    "L1_MAP_OBSTYPE",
    "L1_IMMUNIZATION",
    "L1_MAP_IMMUN_DEFER_REASON",
    "L2_DICT_DCC",
    "L4_MAP_CUI_HM_TYPE"
  )

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import com.optum.oadw.utils.DataframeExtensions._
    import sparkSession.implicits._

    val mdDomainConcept = loadedDependencies("MD_DOMAIN_CONCEPT").as[md_domain_concept]
    val tL2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg]
    val l1MapAcoExclusion = loadedDependencies("L1_MAP_ACO_EXCLUSION").as[l1_map_aco_exclusion]
    val tMdOadwInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]
    val l1Observation = loadedDependencies("L1_OBSERVATION").as[l1_observation]
    val l1MapObstype = loadedDependencies("L1_MAP_OBSTYPE").castToBigDecimal(Set("end_range", "begin_range")).as[l1_map_obstype]
    val l1Immunization = loadedDependencies("L1_IMMUNIZATION").as[l1_immunization]
    val l1MapImmunDeferReason = loadedDependencies("L1_MAP_IMMUN_DEFER_REASON").as[l1_map_immun_defer_reason]
    val tL2DictDcc = loadedDependencies("L2_DICT_DCC").as[l2_dict_dcc]
    val mapCuiHmType = loadedDependencies("L4_MAP_CUI_HM_TYPE").as[l4_map_cui_hm_type]

    val dataThruDt = tMdOadwInstance.where($"attribute_name" === lit("DATA_THRU"))
      .select(to_date($"attribute_value", "yyyyMMdd").as("data_thru_dt")).as[Timestamp].collect()
      .head
    val immunizationDf = createImmunDf(sparkSession, l1Immunization, tL2MapCdsFlg, l1MapImmunDeferReason, tL2DictDcc, dataThruDt)
    val obsDf = createObsDf(sparkSession, l1Observation, tL2MapCdsFlg, l1MapObstype, l1MapAcoExclusion, dataThruDt, mdDomainConcept)
    val unionDf = immunizationDf.union(obsDf)

    unionDf
      .as("result")
      .join(broadcast(mapCuiHmType).as("map_cui"), $"map_cui.cui" === $"result.hm_type_cui", "left_outer")
      .select(
        concat(coalesce($"result.dcc",
          lit("")).cast(StringType),
          coalesce($"result.hm_type_cui",
            lit("")).cast(StringType),
          coalesce($"result.defer_rsn_cui",
            lit("")).cast(StringType)).as("hm_deferred_key"),
        coalesce($"map_cui.sensitive_ind", $"result.sensitive_ind").as("sensitive_ind"),
        $"result.client_id",
        $"result.mpi",
        $"result.deferral_dtm",
        $"result.hm_type_cui",
        $"result.defer_rsn_cui",
        $"result.dcc",
        $"result.cds_grp"
      )
  }

  private def createImmunDf(sparkSession: SparkSession,
                            l1Immunization: Dataset[l1_immunization],
                            tL2MapCdsFlg: Dataset[l2_map_cds_flg],
                            l1MapImmunDeferReason: Dataset[l1_map_immun_defer_reason],
                            tL2DictDcc: Dataset[l2_dict_dcc],
                            dataThruDt: Timestamp): DataFrame = {
    import sparkSession.implicits._

    val df = l1Immunization.as("l1Immunization")
      .join(tL2MapCdsFlg.as("tL2MapCdsFlg"), $"l1Immunization.client_id" === $"tL2MapCdsFlg.client_id" && $"l1Immunization.client_ds_id" === $"tL2MapCdsFlg.client_ds_id")
      .join(l1MapImmunDeferReason.as("l1MapImmunDeferReason"), $"l1Immunization.client_id" === $"l1MapImmunDeferReason.client_id" && $"l1Immunization.localdeferredreason" === $"l1MapImmunDeferReason.local_code")
      .join(tL2DictDcc.as("tL2DictDcc"), $"tL2DictDcc.dcc" === $"l1Immunization.dcc")
      .where($"l1Immunization.mpi".isNotNull && to_date($"l1Immunization.documented_dt","yyyyMMdd") <= dataThruDt)
        .select(
          lit(0).cast(IntegerType).as("sensitive_ind"),
          lit(null).cast(StringType).as("hm_type_cui"),
          $"l1Immunization.client_id",
          $"l1Immunization.mpi".as("mpi"),
          $"l1Immunization.documented_dt".as("deferral_dtm"),
          $"l1MapImmunDeferReason.cui".as("defer_rsn_cui"),
          $"l1Immunization.dcc",
          $"tL2MapCdsFlg.data_grp_flg",
          $"tL2MapCdsFlg.client_ds_id"
        )
      .groupBy($"sensitive_ind", $"hm_type_cui", $"l1Immunization.client_id", $"mpi", $"deferral_dtm", $"defer_rsn_cui", $"l1Immunization.dcc")
      .agg(
        ListAggFunction.listAgg($"tL2MapCdsFlg.client_ds_id").as("cds_grp")
      )
    df.select("sensitive_ind", "client_id", "mpi", "deferral_dtm", "hm_type_cui", "defer_rsn_cui", "dcc", "cds_grp")
  }

  private def createObsDf(sparkSession: SparkSession,
                          l1Observation: Dataset[l1_observation],
                          tL2MapCdsFlg: Dataset[l2_map_cds_flg],
                          l1MapObstype: Dataset[l1_map_obstype],
                          l1MapAcoExclusion: Dataset[l1_map_aco_exclusion],
                          dataThruDt: Timestamp,
                          mdDomainConcept: Dataset[md_domain_concept]): DataFrame = {
    import sparkSession.implicits._

    val conceptCuis = mdDomainConcept.where($"domain_cui" === "CH003534").select($"concept_cui").as[String].collectAsList().asScala.toArray
    val df = l1Observation.as("l1Observation")
      .join(tL2MapCdsFlg.as("tL2MapCdsFlg"), $"l1Observation.client_id" === $"tL2MapCdsFlg.client_id" && $"l1Observation.client_ds_id" === $"tL2MapCdsFlg.client_ds_id")
      .join(l1MapObstype.as("l1MapObstype"), $"l1Observation.obstype" === $"l1MapObstype.obstype")
      .join(l1MapAcoExclusion.as("l1MapAcoExclusion"), $"l1Observation.client_id" === $"l1MapAcoExclusion.client_id" && $"l1Observation.obsresult" === $"l1MapAcoExclusion.local_code")
      .where($"l1Observation.mpi".isNotNull && to_date($"l1Observation.observation_dtm", "yyyyMMdd") <= dataThruDt && $"l1MapObstype.obstype_cui".isin(conceptCuis:_*))
        .select(
          lit(0).cast(IntegerType).as("sensitive_ind"),
          lit(null).cast(StringType).as("dcc"),
          $"l1Observation.client_id",
          $"l1Observation.mpi".as("mpi"),
          $"l1Observation.observation_dtm".as("deferred_dtm"),
          $"l1MapObstype.obstype_cui".as("hm_type_cui"),
          $"l1MapAcoExclusion.cui".as("def_reason_cui"),
          $"tL2MapCdsFlg.data_grp_flg",
          $"tL2MapCdsFlg.client_ds_id"
        )
      .groupBy($"sensitive_ind", $"dcc", $"l1Observation.client_id", $"mpi", $"deferred_dtm", $"hm_type_cui", $"def_reason_cui")
      .agg(
        ListAggFunction.listAgg($"tL2MapCdsFlg.client_ds_id").as("cds_grp")
      )
    df.select("sensitive_ind", "client_id", "mpi", "deferred_dtm", "hm_type_cui", "def_reason_cui", "dcc", "cds_grp")
  }

  val sparkSql: String =
    """
        WITH oadw_data_thru AS
        (   SELECT
        TO_DATE (attribute_value, 'yyyyMMdd')  AS data_thru_dt
        FROM MD_oadw_instance
        WHERE
        attribute_name='DATA_THRU'
        )
        select concat(cast(coalesce(dcc, '') as string), cast(coalesce(hm_type_cui, '') as string), cast(coalesce(defer_rsn_cui, '') as string)) as hm_deferred_key, sensitive_ind,
        client_id, mpi, deferral_dtm, hm_type_cui, defer_rsn_cui, dcc from
        (
        SELECT
        cast(0 as int) as sensitive_ind
        ,a.client_id
        ,a.mpi AS mpi
        ,a.documented_dt AS deferral_dtm
        ,NULL AS hm_type_cui
        ,midr.cui AS defer_rsn_cui
        ,a.dcc
        FROM L1_immunization a
        INNER JOIN L2_map_cds_flg mcf ON (a.client_id = mcf.client_id AND a.client_ds_id = mcf.client_ds_id)
        INNER JOIN L1_map_immun_defer_reason midr ON (a.client_id = midr.client_id AND a.localdeferredreason = midr.local_code)
        INNER JOIN L2_dict_dcc  dcc ON dcc.dcc = a.dcc
        WHERE a.mpi IS NOT NULL
        AND   a.documented_dt < ( SELECT DATE_ADD(data_thru_dt,1)  FROM oadw_data_thru )
        GROUP BY a.client_id
        ,a.mpi
        ,a.documented_dt
        ,midr.cui
        ,a.dcc
         UNION ALL
        SELECT
         cast(0 as int) as sensitive_ind
        ,a.client_id
        ,a.mpi AS mpi
        ,a.observation_dtm AS deferred_dtm
        ,zo.obstype_cui AS hm_type_cui
        ,mae.cui AS def_reason_cui
        ,NULL AS dcc
        FROM L1_observation a
        INNER JOIN L2_map_cds_flg mcf ON (a.client_id = mcf.client_id AND a.client_ds_id = mcf.client_ds_id)
        INNER JOIN L1_map_obstype zo ON ( a.obstype = zo.obstype )
        INNER JOIN L1_map_aco_exclusion mae ON (a.client_id = mae.client_id AND a.obsresult = mae.local_code)
        WHERE a.mpi IS NOT NULL
        AND   a.observation_dtm < ( SELECT DATE_ADD(data_thru_dt,1)  FROM oadw_data_thru )
        AND   zo.obstype_cui IN (SELECT concept_cui FROM md_domain_concept WHERE domain_cui = 'CH003534')
        GROUP BY a.client_id
        ,a.mpi
        ,a.observation_dtm
        ,zo.obstype_cui
        ,mae.cui ) sparkTableAlias
    """
}

package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{ l2_ii_map_age, l2_ii_map_age_buckets }
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.{ DataFrame, SparkSession }

object L2_II_MAP_AGE_BUCKETS extends TableInfo[l2_ii_map_age_buckets] {
  override def name: String = "L2_II_MAP_AGE_BUCKETS"

  override def dependsOn: Set[String] = Set("L2_II_MAP_AGE")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val l2IIMapAge = loadedDependencies("L2_II_MAP_AGE").as[l2_ii_map_age]
    l2IIMapAge
      .select($"age_cat2", $"age_lab2")
      .distinct
  }
}

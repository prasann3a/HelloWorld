package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_ii_ocu_epi_count_ext
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_II_OCU_EPI_COUNT_EXT extends QueryAndMetadata[l2_ii_ocu_epi_count_ext] {
  override def name: String = "L2_II_OCU_EPI_COUNT_EXT"

  override def sparkSql: String = """
           SELECT
           YEAR_MTH_ID,
           cast(NEW_MEM_ATTR_ID as INT),
           cast(ETG_ID as long) as ETG_ID,
           SEV_LEVEL,
           TX_IND,
           OUTLIER,
           cast(COMPLETE as int) AS COMPLETE,
           cast(SUM(EPI_QTY) as decimal(38, 10)) AS EPI_QTY
              FROM (SELECT MDR.YEAR_MTH_ID as YEAR_MTH_ID, ES.EPISODE_ID,  MA.NEW_MEM_ATTR_ID as NEW_MEM_ATTR_ID,   ES.ETG_ID, ES.SEV_LEVEL,
              ES.TX_IND, ES.OUTLIER,
              CASE WHEN ES.EPI_TYPE IN  (0, 1, 2, 3) THEN 1 ELSE 0
              END as COMPLETE,  nvl(ES.EPI_QTY,0) AS EPI_QTY
              FROM L2_II_EPISODES ES
              JOIN TEMP_EPI_MEM_ENROLL ENR ON ES.EPISODE_ID = ENR.EPISODE_ID
              JOIN L2_II_MAP_DATE_RANGE MDR ON MDR.MONTH_VAL = month ( ENR.EPI_DATE) AND MDR.YEAR_VAL = year ( ENR.EPI_DATE)
              JOIN l2_ii_mem_attr_member_ext MA ON ENR.MEMBER = MA.MEMBER AND MDR.YEAR_MTH_ID = MA.YEAR_MTH_ID AND MA.MEM_EFF_DT = ENR.MEM_EFF_DT
              AND MA.MEM_END_DT = ENR.MEM_END_DT AND MA.SUB_EFF_DT = ENR.SUB_EFF_DT
              AND MA.SUB_END_DT = ENR.SUB_END_DT
              cross JOIN (select max(year_mth_id) max_mth from L2_II_MAP_DATE_RANGE) q
              ) TEMP_EPI
              GROUP BY YEAR_MTH_ID, NEW_MEM_ATTR_ID, ETG_ID,SEV_LEVEL, TX_IND, OUTLIER,COMPLETE
                                """

  override def dependsOn: Set[String] = Set("L2_II_EPISODES","TEMP_EPI_MEM_ENROLL","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR_MEMBER_EXT")

  def originalSql: String = """


insert /*+ append */ into l2_ii_ocu_epi_count_ext
    (YEAR_MTH_ID,NEW_MEM_ATTR_ID,ETG_ID,SEV_LEVEL,TX_IND,OUTLIER,COMPLETE,EPI_QTY)
    SELECT YEAR_MTH_ID, NEW_MEM_ATTR_ID, ETG_ID,SEV_LEVEL, TX_IND,  OUTLIER, COMPLETE, SUM(EPI_QTY) AS EPI_QTY
      FROM (SELECT MDR.YEAR_MTH_ID as YEAR_MTH_ID, ES.EPISODE_ID,  MA.NEW_MEM_ATTR_ID as NEW_MEM_ATTR_ID,   ES.ETG_ID, ES.SEV_LEVEL,
                   ES.TX_IND, ES.OUTLIER,
                    CASE WHEN ES.EPI_TYPE IN  (0, 1, 2, 3) THEN 1 ELSE 0
                    END as COMPLETE,  nvl(ES.EPI_QTY,0) AS EPI_QTY
             FROM L2_II_EPISODES ES
             JOIN TEMP_EPI_MEM_ENROLL ENR ON ES.EPISODE_ID = ENR.EPISODE_ID
             JOIN L2_II_MAP_DATE_RANGE MDR ON MDR.MONTH_VAL = extract(month from ENR.EPI_DATE) AND MDR.YEAR_VAL = extract(year from ENR.EPI_DATE)
             JOIN l2_ii_mem_attr_member_ext MA ON ENR.MEMBER = MA.MEMBER AND MDR.YEAR_MTH_ID = MA.YEAR_MTH_ID AND MA.MEM_EFF_DT = ENR.MEM_EFF_DT
                                            AND MA.MEM_END_DT = ENR.MEM_END_DT AND MA.SUB_EFF_DT = ENR.SUB_EFF_DT
                                            AND MA.SUB_END_DT = ENR.SUB_END_DT
             JOIN (select max(year_mth_id) max_mth from L2_II_MAP_DATE_RANGE) q ON 1=1
            ) TEMP_EPI
        GROUP BY YEAR_MTH_ID, NEW_MEM_ATTR_ID, ETG_ID,SEV_LEVEL, TX_IND, OUTLIER,COMPLETE
            """

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("YEAR_MTH_ID",None,None), OutputColumn("NEW_MEM_ATTR_ID",None,None), OutputColumn("ETG_ID",None,None), OutputColumn("SEV_LEVEL",None,None), OutputColumn("TX_IND",None,None), OutputColumn("OUTLIER",None,None), OutputColumn("COMPLETE",None,None), OutputColumn("EPI_QTY",None,None)))

  def directoryLevel: String = "L2"




}

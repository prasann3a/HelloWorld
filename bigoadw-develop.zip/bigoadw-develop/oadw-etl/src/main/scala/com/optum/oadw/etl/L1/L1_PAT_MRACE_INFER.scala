package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_pat_mrace_infer, pat_mrace_infer}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PAT_MRACE_INFER extends TableInfo[l1_pat_mrace_infer]{
  override def dependsOn: Set[String] = Set("PAT_MRACE_INFER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PAT_MRACE_INFER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patMraceInfer = loadedDependencies("PAT_MRACE_INFER").as[pat_mrace_infer]

		patMraceInfer.where($"grp_mpi".isNotNull)
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi".as("mpi"),
			$"client_ds_id",
			$"mapped_race"
    )
  }
}


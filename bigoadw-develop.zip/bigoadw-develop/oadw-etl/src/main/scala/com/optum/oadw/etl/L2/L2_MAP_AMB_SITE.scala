package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l2_map_amb_site, md_oadw_instance}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, _}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L2_MAP_AMB_SITE extends TableInfo[l2_map_amb_site] {
  override def name: String = "L2_MAP_AMB_SITE"
  override def dependsOn: Set[String] = Set("L1_FACILITY_EXT", "MD_OADW_INSTANCE")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val mdInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]

    val clientId = mdInstance
      .where($"attribute_name" === lit("CLIENT_ID"))
      .select($"attribute_value".as("client_id"))
    
    val tl2MapAmbSite = loadedDependencies("L1_FACILITY_EXT")
    tl2MapAmbSite
      .groupBy($"client_id", $"siteofcare_cd", $"master_siteofcare_id")
      .agg(
        max($"siteofcare_nm").as("amb_site_desc"),
        max($"siteofcare_postal_cd").as( "amb_site_zip")
      )
      .select(
        $"siteofcare_cd".as("amb_site_cd"),
        $"amb_site_desc",
        $"master_siteofcare_id".as("amb_site_id"),
        $"amb_site_zip",
        $"client_id"
      )
      .union(clientId.selectExpr(
        "'Unknown or N/A' as amb_site_cd",
        "'Unknown or N/A' as amb_site_desc",
        "0 as amb_site_id",
        "'Unknown or N/A' as amb_site_zip",
        "client_id as client_id")
      )
  }
}


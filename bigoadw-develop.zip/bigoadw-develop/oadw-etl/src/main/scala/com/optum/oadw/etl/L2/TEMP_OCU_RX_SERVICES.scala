package com.optum.oadw.etl.L2

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_ocu_rx_services_data(year_mth_id: java.lang.Integer, year_mth_pd: java.lang.Integer,
                                     new_mem_attr_id: java.lang.Integer, formulary: java.lang.Integer, channel: java.lang.Integer, gbo: java.lang.Integer,
                                     tos_i_5: java.lang.Integer, network_paid_status_id: String, provider_status_id: String,
                                     episode_id: java.lang.Long, etg_id: java.lang.Integer, sev_level: java.lang.Integer, amt_req: scala.math.BigDecimal,
                                     amt_eqv: scala.math.BigDecimal, amt_np: scala.math.BigDecimal, amt_pay: scala.math.BigDecimal,
                                     generic: java.lang.Integer, script: scala.math.BigDecimal, script_gen: java.lang.Integer,
                                     days_sup: java.lang.Integer, ndc: String, pres_prv_i: String)

object TEMP_OCU_RX_SERVICES extends QueryAndMetadata[temp_ocu_rx_services_data] {
  override def name: String = "TEMP_OCU_RX_SERVICES"

  override def sparkSql: String = """SELECT MD1.YEAR_MTH_ID as YEAR_MTH_ID, MD2.YEAR_MTH_ID as  YEAR_MTH_PD,
OM.NEW_MEM_ATTR_ID,SR.FORMULARY, SR.CHANNEL, SR.GBO, SR.TOS_I_5, NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,
SR.EPISODE_ID, SR.ETG_ID, SR.SEV_LEVEL,
sum(amt_req) as amt_req, sum(amt_eqv) AS amt_eqv, sum(amt_np)  AS amt_np,
sum(amt_pay) AS amt_pay,
case when SR.GENERIC = true then 1 when SR.GENERIC = false then 0 else 0 end AS GENERIC,
nvl(SR.SCRIPT,0) AS SCRIPT,
case when SR.SCRIPT_GEN = true then 1 else 0 end as SCRIPT_GEN,
nvl(SR.DAYS_SUP,0) AS DAYS_SUP,
sr.ndc,sr.PRES_PRV_I
FROM L2_II_SERVICES_RX SR
JOIN L2_II_MAP_DATE_RANGE MD1 ON MD1.MONTH_VAL = date_format(SR.DOS,'MM')AND MD1.YEAR_VAL = date_format(SR.DOS,'yyyy')
JOIN L2_II_MAP_DATE_RANGE MD2 ON MD2.MONTH_VAL = date_format(SR.PAY_DT,'MM') AND MD2.YEAR_VAL = date_format(SR.PAY_DT,'yyyy')
JOIN l2_ii_mem_attr_member_ext OM ON SR.MEMBER = OM.MEMBER AND OM.YEAR_MTH_ID = MD1.YEAR_MTH_ID
AND SR.DOS BETWEEN OM.MEM_EFF_DT AND OM.MEM_END_DT AND SR.DOS BETWEEN OM.SUB_EFF_DT AND OM.SUB_END_DT
WHERE SR.EXCLUDE = 0
OR (SR.IA_TIME = 0 AND SR.NOENR_DOS = 0 AND SR.PSEUDO = 0)
group by MD1.YEAR_MTH_ID, MD2.YEAR_MTH_ID,
OM.NEW_MEM_ATTR_ID,SR.FORMULARY, SR.CHANNEL, SR.GBO, SR.TOS_I_5, NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,
SR.EPISODE_ID, SR.ETG_ID, SR.SEV_LEVEL,
case when SR.GENERIC = true then 1 when SR.GENERIC = false then 0 else 0 end,
nvl(SR.SCRIPT,0),
case when SR.SCRIPT_GEN = true then 1 else 0 end,
nvl(SR.DAYS_SUP,0),sr.ndc,sr.PRES_PRV_I"""

  override def dependsOn: Set[String] = Set("L2_II_SERVICES_RX","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR_MEMBER_EXT")

  def originalSql: String = """
CREATE TABLE temp_OCU_RX_SERVICES pctfree 0 nologging as
SELECT MD1.YEAR_MTH_ID as YEAR_MTH_ID, MD2.YEAR_MTH_ID as  YEAR_MTH_PD,
       OM.NEW_MEM_ATTR_ID,SR.FORMULARY, SR.CHANNEL, SR.GBO, SR.TOS_I_5, NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,
       SR.EPISODE_ID, SR.ETG_ID, SR.SEV_LEVEL,
       sum(amt_req) as amt_req, sum(amt_eqv) AS amt_eqv, sum(amt_np)  AS amt_np,
       sum(amt_pay) AS amt_pay, nvl(SR.GENERIC,0) AS GENERIC, nvl(SR.SCRIPT,0) AS SCRIPT,
       nvl(SR.SCRIPT_GEN,0) AS SCRIPT_GEN, nvl(SR.DAYS_SUP,0) AS DAYS_SUP,sr.ndc,sr.PRES_PRV_I
  FROM L2_II_SERVICES_RX SR
  JOIN L2_II_MAP_DATE_RANGE MD1 ON MD1.MONTH_VAL = to_char(SR.DOS,'mm')AND MD1.YEAR_VAL = to_char(SR.DOS,'yyyy')
  JOIN L2_II_MAP_DATE_RANGE MD2 ON MD2.MONTH_VAL = to_char(SR.PAY_DT,'mm') AND MD2.YEAR_VAL = to_char(SR.PAY_DT,'yyyy')
  JOIN l2_ii_mem_attr_member_ext OM ON SR.MEMBER = OM.MEMBER AND OM.YEAR_MTH_ID = MD1.YEAR_MTH_ID
   AND SR.DOS BETWEEN OM.MEM_EFF_DT AND OM.MEM_END_DT AND SR.DOS BETWEEN OM.SUB_EFF_DT AND OM.SUB_END_DT
 WHERE SR.EXCLUDE = 0
    OR (SR.IA_TIME = 0 AND SR.NOENR_DOS = 0 AND SR.PSEUDO = 0)
    group by MD1.YEAR_MTH_ID, MD2.YEAR_MTH_ID,
       OM.NEW_MEM_ATTR_ID,SR.FORMULARY, SR.CHANNEL, SR.GBO, SR.TOS_I_5, NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,
       SR.EPISODE_ID, SR.ETG_ID, SR.SEV_LEVEL,nvl(SR.GENERIC,0), nvl(SR.SCRIPT,0),
       nvl(SR.SCRIPT_GEN,0), nvl(SR.DAYS_SUP,0),sr.ndc,sr.PRES_PRV_I"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}

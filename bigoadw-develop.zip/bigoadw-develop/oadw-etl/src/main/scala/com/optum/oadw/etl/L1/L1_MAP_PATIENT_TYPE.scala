
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_patient_type, map_patient_type}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_PATIENT_TYPE extends TableInfo[l1_map_patient_type]{
  override def dependsOn: Set[String] = Set("MAP_PATIENT_TYPE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_PATIENT_TYPE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapPatientType = loadedDependencies("MAP_PATIENT_TYPE").as[map_patient_type]

    mapPatientType
    .select(
			$"groupid".as("client_id"),
			$"local_code",
			$"description",
			$"cui",
			$"dts_version"
    )
  }
}


package com.optum.oadw.etl.L2

import com.optum.oadw.common.models.OADWRuntimeVariables
import com.optum.oadw.etl.constants.Precursors
import com.optum.oadw.oadwModels.l2_pat_clinical_event
import com.optum.oadw.utils.{FeatureManager, Features}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, LongType, StringType}

object L2_PAT_CLINICAL_EVENT extends TableInfo[l2_pat_clinical_event] {
  override def name: String = "L2_PAT_CLINICAL_EVENT"

  override def dependsOn: Set[String] = Set("L2_MAP_APR_DRG","TEMP_ETG_QUAL_EVT_IND","TEMP_ENCOUNTER_GRP_CDS_FLG","L1_MAP_ADMIT_SOURCE","L1_MAP_DISCHARGE_DISPOSITION","L2_MAP_DRG","L4_MAP_EVENT_TYPE","L2_MAP_AMB_SITE","L2_MAP_HOSP_SITE","L2_DICT_DIAG","L2_DICT_PROC","L1_MSDRG_OUTPUT")


  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL2MapAprDrg = loadedDependencies("L2_MAP_APR_DRG")
    val tempEtgQualEvtInd = loadedDependencies("TEMP_ETG_QUAL_EVT_IND")
    val tempEncounterGrpCdsFlg = loadedDependencies("TEMP_ENCOUNTER_GRP_CDS_FLG")
    val l1MapAdmitSource = loadedDependencies("L1_MAP_ADMIT_SOURCE")
    val l1MapDischargeDisposition = loadedDependencies("L1_MAP_DISCHARGE_DISPOSITION")
    val tL2MapDrg = loadedDependencies("L2_MAP_DRG")
    val tl4MapEventType = loadedDependencies("L4_MAP_EVENT_TYPE")
    val tL2MapAmbSite = loadedDependencies("L2_MAP_AMB_SITE")
    val tL2MapHospSite = loadedDependencies("L2_MAP_HOSP_SITE")
    val tL2DictDiag = loadedDependencies("L2_DICT_DIAG")
    val tL2DictProc = loadedDependencies("L2_DICT_PROC")
    val tL1MsdrgOtpt = loadedDependencies("L1_MSDRG_OUTPUT")


    val tempDf = tempEncounterGrpCdsFlg.as("eg")
      .join(broadcast(tl4MapEventType).as("et"), $"eg.encounter_grp_type" === $"et.event_type_cui", "inner")
      .join(broadcast(tL2MapAmbSite).as("mas"), $"eg.client_id" === $"mas.client_id" && $"eg.siteofcare_cd" === $"mas.amb_site_cd", "left")
      .join(broadcast(tL2MapHospSite).as("mhs"), $"eg.client_id" === $"mhs.client_id" && $"eg.master_facility_cd" === $"mhs.hosp_site_cd", "left")
      .join(broadcast(l1MapDischargeDisposition).as("dd"), $"eg.client_id" === $"dd.client_id" && $"eg.localdischargedisposition" === $"dd.local_code", "left")
      .join(broadcast(l1MapAdmitSource).as("ad"), $"eg.client_id" === $"ad.client_id" && $"eg.localadmitsource" === $"ad.local_code", "left")
      .join(broadcast(tL2MapDrg).as("lmd"), $"eg.drgtypecui" === $"lmd.drg_type_cui" && $"eg.drg" === $"lmd.drg_cd", "left")
      .join(broadcast(tL2MapAprDrg).as("lmad"), $"eg.aprdrg" === $"lmad.apr_drg_cd"
        && coalesce($"eg.aprdrg_sev", lit(0)) === $"lmad.apr_drg_sev"
        && coalesce($"eg.aprdrg_risk", lit(0)) === $"lmad.apr_drg_risk", "left")
      .join(broadcast(tL2DictDiag).as("dx"), $"eg.prindx" === $"dx.diag_cd" && $"eg.prindx_codetype" === $"dx.code_type", "left")
      .join(broadcast(tL2DictProc).as("px"), $"eg.prinpx" === $"px.proc_cd" && $"eg.prinpx_codetype" === $"px.code_type", "left")
      .join(tempEtgQualEvtInd.as("evt_ind"), $"evt_ind.clinical_event_id" === $"eg.encounter_grp_num", "left")
      .select(
        $"eg.client_id",
        $"eg.encounter_grp_num".cast(LongType).as("clinical_event_id"),
        $"mhs.hosp_site_id",
        $"mas.amb_site_id",
        $"eg.mpi",
        $"eg.arrival_dtm".as("evt_start_dtm"),
        $"eg.admit_dtm".as("evt_admit_dtm"),
        $"eg.discharge_dtm".as("evt_end_dtm"),
        coalesce($"eg.encounter_grp_type", lit(Precursors.CUI_NULL)).as("event_type_cui"),
        when($"eg.localdischargedisposition".isNull, lit(Precursors.CUI_NULL)).otherwise(coalesce($"dd.cui", lit(Precursors.CUI_INVALID))).as("disposition_cui"),
        when($"eg.localadmitsource".isNull, lit(Precursors.CUI_NULL)).otherwise(coalesce($"ad.cui", lit(Precursors.CUI_INVALID))).as("admitsource_cui"),
        $"lmd.drg_id".as("drg_id"),
        $"lmad.apr_drg_id".as("apr_drg_id"),
        $"dx.diag_cd".as("prindx"),
        $"dx.code_type".as("prindx_codetype"),
        coalesce($"dx.sensitive_ind", lit(0)).as("prindx_sensitive_ind"),
        $"px.proc_cd".as("prinpx"),
        $"px.code_type".as("prinpx_codetype"),
        coalesce($"px.sensitive_ind", lit(0)).as("prinpx_sensitive_ind"),
        when($"baseinclude" === lit("Y"), lit(1)).otherwise(lit(0)).as("base_include_ind"),
        when($"cmsplanned" === lit("Y"), lit(1)).otherwise(lit(0)).as("cms_planned_ind"),
        when($"cmsinclude" === lit("Y") && $"eg.encounter_grp_type" === "CH000106", lit(1)).otherwise(lit(0)).as("cms_include_ind"),
        when($"convert_ip" === lit("Y"), lit(1)).otherwise(lit(0)).as("convert_ip_ind"),
        when($"admitted_er" === lit("Y"), lit(1)).otherwise(lit(0)).as("admitted_er_ind"),
        $"eg.display_ds_id",
        $"eg.display_encounterid",
        coalesce($"encounterservice", lit(Precursors.CUI_NULL)).as("hosp_service_cui"),
        $"mappedzipcode".as("pat_zip"),
        $"eg.admittingphys_mstr_id".cast(StringType).as("admit_prov_id"),
        $"eg.lastattphys_mstr_id".cast(StringType).as("disch_prov_id"),
        $"eg.lastattteam_mstr_id".cast(StringType).as("disch_team_prov_id"),
        $"eg.prov_id".as("prov_id"),
        $"eg.cds_grp",
        when($"evt_ind.clinical_event_id".isNotNull, lit(1)).otherwise(lit(0)).as("etg_qual_evt_ind"),
        coalesce($"lmd.sensitive_ind", lit(0)).as("drg_sensitive_ind"),
        coalesce($"lmad.sensitive_ind", lit(0)).as("apr_drg_sensitive_ind"),
        coalesce($"et.sensitive_ind", lit(0)).as("sensitive_ind"),
        when($"eg.encounter_grp_type" === "CH000106" && datediff( to_date($"eg.discharge_dtm","yyyyMMdd"), to_date($"eg.admit_dtm","yyyyMMdd") ) === lit(0), lit(1))
          .when($"eg.encounter_grp_type" === "CH000106" && datediff( to_date($"eg.discharge_dtm","yyyyMMdd"), to_date($"eg.admit_dtm","yyyyMMdd") ) =!= lit(0), datediff( to_date($"eg.discharge_dtm","yyyyMMdd"), to_date($"eg.admit_dtm","yyyyMMdd") ))
          .otherwise(lit(null)).as("los"),
        when($"eg.encounter_grp_type" === "CH000106" && to_date($"eg.discharge_dtm","yyyyMMdd") === to_date($"eg.admit_dtm","yyyyMMdd"), lit(1))
          .when($"eg.encounter_grp_type" === "CH000106" && to_date($"eg.discharge_dtm","yyyyMMdd") =!= to_date($"eg.admit_dtm","yyyyMMdd"), lit(0))
          .otherwise(lit(null)).as("same_day_stay")
      )

    (FeatureManager.Instance.isEnable(Features.MSDRG) && OADWRuntimeVariables(runtimeVariables).cdrLevel == "cdr_be") match {
      case true => tempDf.as("tmp")
        .join(tL1MsdrgOtpt.as("msdrg"), $"tmp.clinical_event_id" === $"msdrg.encounter_grp_num", "left")
        .join(tL2MapDrg.as("msdrgcd"), $"msdrgcd.drg_cd" === lpad($"msdrg.drg",3,"0"), "left")
        .select($"tmp.*",
          $"msdrgcd.drg_id".as("DRG_ID_CALC")
        )
      case _ => tempDf.withColumn("DRG_ID_CALC",lit(null).cast(IntegerType))
    }

  }

  override def partitions: Int = 64
}



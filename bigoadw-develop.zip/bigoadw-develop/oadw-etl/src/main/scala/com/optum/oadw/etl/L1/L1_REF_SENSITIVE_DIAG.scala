
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.l1_ref_sensitive_diag
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L1_REF_SENSITIVE_DIAG extends QueryAndMetadata[l1_ref_sensitive_diag] {
  override def skipCoalesce: Boolean = true
	override def name: String = "L1_REF_SENSITIVE_DIAG"

  override def sparkSql: String = """SELECT DISTINCT 'ICD9' AS code_type, icd9_code AS diag_cd, cast(1 as int) AS sensitive_ind
FROM L1_ref_sensitive_icd9_dx
UNION ALL
SELECT DISTINCT 'ICD10' AS code_type, diag_code AS diag_cd, cast(1 as int) AS sensitive_ind
FROM L1_REF_SENSITIVE_ICD0_DX"""

  override def dependsOn: Set[String] = Set("L1_REF_SENSITIVE_ICD9_DX","L1_REF_SENSITIVE_ICD0_DX")

  def originalSql: String = """


INSERT /*+ APPEND */ INTO L1_ref_sensitive_diag (code_type, diag_cd, sensitive_ind)
SELECT DISTINCT 'ICD9' AS code_type, icd9_code AS diag_cd, 1 AS sensitive_ind
FROM L1_ref_sensitive_icd9_dx
UNION ALL
SELECT DISTINCT 'ICD10' AS code_type, diag_code AS diag_cd, 1 AS sensitive_ind
FROM L1_REF_SENSITIVE_ICD0_DX
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("code_type",None,None), OutputColumn("diag_cd",None,None), OutputColumn("sensitive_ind",None,None)))

  def directoryLevel: String = "L1"





  val originalSqlFileName: String = "L1_ref_sensitive_diag.sql"
}


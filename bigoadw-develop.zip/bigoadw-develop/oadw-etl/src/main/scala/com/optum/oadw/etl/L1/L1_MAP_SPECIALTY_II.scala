package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{map_specialty_ii, md_oadw_instance, l1_map_specialty_ii}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_SPECIALTY_II extends TableInfo[l1_map_specialty_ii] {

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_SPECIALTY_II"

  override def dependsOn: Set[String] = Set("MAP_SPECIALTY_II", "MD_OADW_INSTANCE")

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapSpecialtyII = loadedDependencies("MAP_SPECIALTY_II").as[map_specialty_ii]
    val mdInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]

    val clientId = mdInstance
      .where($"attribute_name" === lit("CLIENT_ID"))
      .select($"attribute_value")
      .as[String]
      .collect()
      .head

    mapSpecialtyII
      .where($"groupid" === clientId)
      .select(
        $"groupid".as("client_id"),
        $"local_code".as("local_code"),
        $"ii_code".as("specialty_id"),
        $"dts_version".as("dts_version")
      )
  }

}

package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.l1_encounter_grp_facility
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.{ DataFrame, SparkSession }
import org.apache.spark.sql.functions._

object L1_ENCOUNTER_GRP_FACILITY extends TableInfo[l1_encounter_grp_facility] {
	override def name: String           = "L1_ENCOUNTER_GRP_FACILITY"
  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP", "L1_FACILITY_EXT")
  override def partitions: Int        = 256

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL1EncounterGrp = loadedDependencies("ENCOUNTER_GRP")

    val l1FacilityExt =
      broadcast(loadedDependencies("L1_FACILITY_EXT")
        .select($"master_facility_cd", $"siteofcare_cd", $"client_id", $"facilityid", $"client_ds_id"))

    tL1EncounterGrp
      .as("eg")
      .join(l1FacilityExt.as("fe"), $"eg.groupid" === $"fe.client_id" && $"eg.facilityid" === $"fe.facilityid" && $"eg.facility_ds_id" === $"fe.client_ds_id", "left")
      .select(
        $"eg.groupid".as("client_id"),
        $"encounter_grp_num",
        $"eg.facilityid",
        $"fe.master_facility_cd",
        $"fe.siteofcare_cd",
        $"grp_mpi".as("mpi"),
        $"admittingphysician",
        $"lastattphysician",
        $"admittime".as("admit_dtm"),
        $"arrivaltime".as("arrival_dtm"),
        $"dischargetime".as("discharge_dtm"),
        $"encounter_grp_type",
        $"localdischargedisposition",
        $"localadmitsource",
        $"lastlocation",
        $"drg",
        $"drgtypecui",
        $"prindx",
        $"prinpx",
        $"charge",
        $"cost",
        $"cost_charge_ratio",
        $"clientplanned",
        $"cmsplanned",
        $"baseinclude",
        $"cmsinclude",
        $"cms_ddisp",
        $"cms_rehabp",
        $"cms_rehab",
        $"cms_psych",
        $"cms_non_surgcancer",
        $"convert_ip",
        $"admitted_er",
        $"encounterservice",
        $"finclass",
        $"aprdrg",
        $"aprdrg_sev",
        $"aprdrg_risk",
        $"mappedzipcode",
        $"facility_ds_id",
        $"admittingphys_ds_id",
        $"lastattphys_ds_id",
        $"admittingphys_mstr_id",
        $"lastattphys_mstr_id",
        $"servicecode",
        $"insuranceplan",
        $"lastattteam",
        $"lastattteam_ds_id",
        $"lastattteam_mstr_id",
        $"display_encounterid",
        $"display_ds_id",
        $"elos",
        $"display_id_type",
        $"mdc",
        $"prindx_codetype",
        $"prinpx_codetype",
        $"event_prov_id".as("prov_id")
      )
  }
}

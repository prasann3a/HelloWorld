
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patient_attribute, patient_attribute}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENT_ATTRIBUTE extends TableInfo[l1_patient_attribute]{
  override def dependsOn: Set[String] = Set("PATIENT_ATTRIBUTE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENT_ATTRIBUTE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientAttribute = loadedDependencies("PATIENT_ATTRIBUTE").as[patient_attribute]

    patientAttribute
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"patientid",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"attribute_type_cui",
			$"attribute_value",
			$"eff_date",
			$"end_date",
			$"contract_id"
    )
  }
}


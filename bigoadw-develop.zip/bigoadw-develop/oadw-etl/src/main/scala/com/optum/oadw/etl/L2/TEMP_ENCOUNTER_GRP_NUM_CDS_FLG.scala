package com.optum.oadw.etl.L2

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_encounter_grp_num_cds_flg_data(encounter_grp_num: java.lang.Long, cds_grp: java.lang.String)

object TEMP_ENCOUNTER_GRP_NUM_CDS_FLG extends QueryAndMetadata[temp_encounter_grp_num_cds_flg_data] {
  override def name: String = "TEMP_ENCOUNTER_GRP_NUM_CDS_FLG"

  override def sparkSql: String = """SELECT  encounter_grp_num, listagg(mcf.client_ds_id) AS cds_grp
FROM L1_clinical_event_encounter a
INNER JOIN L2_map_cds_flg mcf ON (a.client_id = mcf.client_id AND a.client_ds_id = mcf.client_ds_id)
GROUP BY encounter_grp_num"""

  override def dependsOn: Set[String] = Set("L1_CLINICAL_EVENT_ENCOUNTER","L2_MAP_CDS_FLG")

  def originalSql: String = """
-- FMP \


-- OADW-467: if we just replace view L1_ENCOUNTER_ENCOUNTER_GRP with table L1_CLINICAL_EVENT_ENCOUNTER
--   or L1_CLINICAL_EVENT_ENCOUNTERview, oracle query plan would use NESTED LOOPS, and the query would run
--   over night and still not finish for H303 (which has 4.2M rows in L2_pat_clinical_event). After many
--   experiements, we create these 2-step temp tables first, and then use it in the main query

CREATE TABLE temp_encounter_grp_num_cds_flg PCTFREE 0 NOLOGGING AS
SELECT  encounter_grp_num
FROM L1_clinical_event_encounter a
INNER JOIN L2_map_cds_flg mcf ON (a.client_id = mcf.client_id AND a.client_ds_id = mcf.client_ds_id)
GROUP BY encounter_grp_num"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_pat_clinical_event_build.sql"
}


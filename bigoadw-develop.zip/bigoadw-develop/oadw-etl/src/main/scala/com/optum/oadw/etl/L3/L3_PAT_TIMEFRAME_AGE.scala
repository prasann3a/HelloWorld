package com.optum.oadw.etl.L3


import com.optum.oadw.oadwModels.l3_pat_timeframe_age
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L3_PAT_TIMEFRAME_AGE extends QueryAndMetadata[l3_pat_timeframe_age] {
  override def name: String = "L3_PAT_TIMEFRAME_AGE"

  override def sparkSql: String = """SELECT  p.client_id
, p.mpi
, t.timeframe_id
, t.start_age
, t.end_age
, case when t.born_during_ind is not null then t.born_during_ind else 0 end as born_during_ind
, case when t.died_during_ind is not null then t.died_during_ind else 0 end as died_during_ind
FROM L2_patient_info p
INNER JOIN TEMP_PAT_TIME_CROSS_S1 t ON p.dob = t.dob AND (p.dod = t.dod or (p.dod is NULL and t.dod is NULL))"""

  override def dependsOn: Set[String] = Set("L2_PATIENT_INFO","TEMP_PAT_TIME_CROSS_S1")

  def originalSql: String = """

INSERT /*+ APPEND */ INTO L3_pat_timeframe_age(client_id,mpi,timeframe_id,start_age,end_age,born_during_ind,died_during_ind)
SELECT /*+ PARALLEL(4) */ p.client_id
    , p.mpi
    , t.timeframe_id
    , t.start_age
    , t.end_age
    , t.born_during_ind
    , t.died_during_ind
    --,p.dob,p.dod
    --,t.start_dt,t.end_dt
FROM L2_patient_info p
INNER JOIN TEMP_PAT_TIME_CROSS_S1 t ON p.dob = t.dob AND (p.dod = t.dod or (p.dod is NULL and t.dod is NULL))
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("client_id",None,None), OutputColumn("mpi",None,None), OutputColumn("timeframe_id",None,None), OutputColumn("start_age",None,None), OutputColumn("end_age",None,None), OutputColumn("born_during_ind",None,None), OutputColumn("died_during_ind",None,None)))

  def directoryLevel: String = "L3"





  override def partitions: Int = 128

  val originalSqlFileName: String = "L3_pat_timeframe_age_build.sql"
}

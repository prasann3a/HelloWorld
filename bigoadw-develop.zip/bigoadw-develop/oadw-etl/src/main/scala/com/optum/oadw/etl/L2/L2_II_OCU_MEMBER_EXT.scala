package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_ii_ocu_member_ext
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_II_OCU_MEMBER_EXT extends QueryAndMetadata[l2_ii_ocu_member_ext] {
  override def name: String = "L2_II_OCU_MEMBER_EXT"

  override def sparkSql: String =
    """
       SELECT
        YEAR_MTH_ID,
        NEW_MEM_ATTR_ID,
        cast(SUM(MM) as int) AS MM,
        cast(SUM(MM_RX) as int) AS MM_RX,
        cast(SUM(SUBSCR_MONTHS) as int) AS SUBSCR_MONTHS,
        cast(SUM(AGE) as int) AS AGE_TOT,
        SUM(nvl(RRISK,0)) AS RRISK,
        SUM(nvl(PRISK,0)) AS PRISK
      FROM l2_ii_mem_attr_member_ext MA GROUP BY YEAR_MTH_ID, NEW_MEM_ATTR_ID
    """

  override def dependsOn: Set[String] = Set("L2_II_MEM_ATTR_MEMBER_EXT")

  def originalSql: String = """

INSERT /*+ APPEND */ INTO L2_II_OCU_MEMBER_EXT
SELECT YEAR_MTH_ID, NEW_MEM_ATTR_ID, SUM(MM) AS MM, SUM(MM_RX) AS MM_RX, SUM(SUBSCR_MONTHS) AS SUBSCR_MONTHS, SUM(AGE) AS AGE_TOT,
       SUM(nvl(RRISK,0)) AS RRISK, SUM(nvl(PRISK,0)) AS PRISK
  FROM l2_ii_mem_attr_member_ext MA
  GROUP BY YEAR_MTH_ID, NEW_MEM_ATTR_ID
  """

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}

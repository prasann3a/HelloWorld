
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_bpo_provider_detail, pp_bpo_provider_detail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_BPO_PROVIDER_DETAIL extends TableInfo[l1_bpo_provider_detail]{
  override def dependsOn: Set[String] = Set("PP_BPO_PROVIDER_DETAIL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_BPO_PROVIDER_DETAIL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ppBpoProviderDetail = loadedDependencies("PP_BPO_PROVIDER_DETAIL").as[pp_bpo_provider_detail]

    ppBpoProviderDetail
    .select(
			$"cust_prov_attr1",
			$"cust_prov_attr10",
			$"cust_prov_attr11",
			$"cust_prov_attr12",
			$"cust_prov_attr13",
			$"cust_prov_attr14",
			$"cust_prov_attr15",
			$"cust_prov_attr16",
			$"cust_prov_attr17",
			$"cust_prov_attr18",
			$"cust_prov_attr19",
			$"cust_prov_attr2",
			$"cust_prov_attr20",
			$"cust_prov_attr3",
			$"cust_prov_attr4",
			$"cust_prov_attr5",
			$"cust_prov_attr6",
			$"cust_prov_attr7",
			$"cust_prov_attr8",
			$"cust_prov_attr9",
			$"fourth_specialty",
			$"groupid".as("client_id"),
			$"npi",
			$"pcpflag",
			$"prov_geo_lat",
			$"prov_geo_lon",
			$"prov_userdef_1",
			$"prov_userdef_2",
			$"provaddress1",
			$"provaddress2",
			$"provaffiliationid",
			$"provcity",
			$"provemail",
			$"provider_status",
			$"providerfirstname",
			$"providerid".as("prov_id"),
			$"providerlastname",
			$"providername",
			$"provphone",
			$"provstate",
			$"provzip",
			$"secondaryspecialty",
			$"sec_provider_id".as("sec_prov_id"),
			$"specialty"
    )
  }
}


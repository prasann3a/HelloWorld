package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

/*
  * Provider affiliation details
*/

object L2_PROVIDER_AFFIL extends TableInfo[l2_provider_affil] {
  override def name: String = "L2_PROVIDER_AFFIL"

  override def dependsOn: Set[String] = Set("L1_PROV_AFFIL")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2ProviderAffil = loadedDependencies("L1_PROV_AFFIL").as[l1_prov_affil]

    l2ProviderAffil.select(
      $"client_id",
      $"master_hgprovid".cast("String").as("prov_id"),
      $"prov_affil_id",
      $"eff_date".cast("Date").as("eff_dt"),
      $"end_date".cast("Date").as("end_dt")
    ).distinct()

  }
}
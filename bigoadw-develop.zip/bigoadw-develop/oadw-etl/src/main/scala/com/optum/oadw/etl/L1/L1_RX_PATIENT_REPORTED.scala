
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_rx_patient_reported, rx_patient_reported}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_RX_PATIENT_REPORTED extends TableInfo[l1_rx_patient_reported]{
  override def dependsOn: Set[String] = Set("RX_PATIENT_REPORTED")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_RX_PATIENT_REPORTED"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val rxPatientReported = loadedDependencies("RX_PATIENT_REPORTED").as[rx_patient_reported]

    rxPatientReported
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"patientid",
			$"encounterid",
			$"facilityid",
			$"localdrugdescription",
			$"localcategorycode",
			$"localdoseunit",
			$"localform",
			$"localproviderid",
			$"localactioncode",
			$"actiontime".as("action_dt"),
			$"localgpi",
			$"localndc",
			$"ndc11",
			$"localqtyofdoseunit",
			$"localroute",
			$"localstrengthperdoseunit",
			$"localstrengthunit",
			$"localtotaldose",
			$"reportedmedid",
			$"medreportedtime".as("medreported_dt"),
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"hum_gen_med_key",
			$"hts_generic",
			$"hts_generic_ext",
			$"mstrprovid",
			$"discontinuedate".as("discontinue_dt"),
			$"hum_med_key",
			$"discontinuereason",
			$"localmedcode",
			$"mappedndc",
			$"mappedgpi",
			$"map_used",
			$"dcc",
			$"rxnorm_code",
			$"active_med_flag"
    )
  }
}


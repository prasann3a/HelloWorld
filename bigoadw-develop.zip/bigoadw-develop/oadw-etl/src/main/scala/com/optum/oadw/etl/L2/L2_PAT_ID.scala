package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l2_pat_id}
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_PAT_ID extends QueryAndMetadata[l2_pat_id] {
  override def name: String = "L2_PAT_ID"

  override def sparkSql: String = """
                                   select cast(nvl2(id_subtype,1,0) as int) as id_subtype_ind, client_id,mpi,client_ds_id,id_type,id_value, id_subtype from (
                                   SELECT  DISTINCT a.client_id
,a.mpi
,a.client_ds_id
,a.idtype as id_type
,a.idvalue as id_value
,a.id_subtype as id_subtype
FROM L1_patient_id a
INNER JOIN L2_map_upload_rules b on (a.client_id = b.client_id AND a.client_ds_id = b.client_ds_id AND a.idtype = b.id_type
AND NVL(a.id_subtype,'NULL') = NVL(b.id_sub_type,'NULL'))
WHERE b.rule_type = 'Patient ID'
AND a.mpi IS NOT NULL
AND a.idvalue IS NOT NULL
AND length(idvalue) <= 50 ) aliasForSpark --looking at whether there is value in the long ids.  Might need to revisit the column size"""

  override def dependsOn: Set[String] = Set("L1_PATIENT_ID","L2_MAP_UPLOAD_RULES")

  def originalSql: String = """INSERT /*+ APPEND */ INTO L2_pat_id(client_id,mpi,client_ds_id,id_type,id_value)
SELECT /*+ parallel(4) */ DISTINCT a.client_id
       ,a.mpi
       ,a.client_ds_id
       ,a.idtype
       ,a.idvalue
FROM L1_patient_id a
INNER JOIN L2_map_upload_rules b on (a.client_id = b.client_id AND a.client_ds_id = b.client_ds_id AND a.idtype = b.id_type
                                                 AND NVL(a.id_subtype,'NULL') = NVL(b.id_sub_type,'NULL'))
WHERE b.rule_type = 'Patient ID'
AND a.mpi IS NOT NULL
AND a.idvalue IS NOT NULL
AND length(idvalue) <= 50 --looking at whether there is value in the long ids.  Might need to revisit the column size
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(
    OutputColumn("id_subtype_ind",None,None),
    OutputColumn("client_id",None,None),
    OutputColumn("mpi",None,None),
    OutputColumn("client_ds_id",None,None),
    OutputColumn("id_type",None,None),
    OutputColumn("id_value",None,None),
    OutputColumn("id_subtype",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_pat_id_build.sql"
}

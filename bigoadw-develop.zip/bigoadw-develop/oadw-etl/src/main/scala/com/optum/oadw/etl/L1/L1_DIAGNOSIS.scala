package com.optum.oadw.etl.L1

import com.optum.oadw.etl.constants.Precursors
import com.optum.oadw.oadwModels.{diagnosis, l1_diagnosis, l1_map_poa, l1_map_predicate_values}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_DIAGNOSIS extends TableInfo[l1_diagnosis] {

	override def name: String = "L1_DIAGNOSIS"

  override def dependsOn: Set[String] = Set("L1_MAP_POA", "L1_MAP_PREDICATE_VALUES", "DIAGNOSIS")

  override def partitions: Int = 512

  def directoryLevel: String = "L1"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val diagnosis = loadedDependencies("DIAGNOSIS").as[diagnosis]
    val l1MapPoa = broadcast(loadedDependencies("L1_MAP_POA").as[l1_map_poa])
    val l1MapPredicateValues = broadcast(loadedDependencies("L1_MAP_PREDICATE_VALUES").as[l1_map_predicate_values]
      .where($"data_src" === "OADW" && $"entity" === "DIAGNOSIS" && $"table_name" === "DIAGNOSIS_BL_POA" && $"column_name" === "DATASRC" ))

    diagnosis.as("diagnosis")
      .join(l1MapPoa.as("map_poa"),
        $"diagnosis.groupid" === $"map_poa.client_id" &&
          $"diagnosis.localpresentonadmission" === $"map_poa.local_code",
        "left")
      .join(l1MapPredicateValues.as("map_predicate_values"),
        $"diagnosis.client_ds_id" === $"map_predicate_values.client_ds_id" &&
          ($"map_predicate_values.column_value" === "ALL" || $"map_predicate_values.column_value" === $"diagnosis.datasrc"),
        "left")
      .select($"diagnosis.client_ds_id",
        $"diagnosis.codetype",
        $"diagnosis.datasrc",
        $"diagnosis.dx_timestamp" as "diag_dtm",
        $"diagnosis.encounterid",
        $"diagnosis.facilityid",
        $"diagnosis.groupid" as "client_id",
        $"diagnosis.grp_mpi" as "mpi",
        $"diagnosis.hgpid",
        $"diagnosis.hosp_dx_flag",
        $"diagnosis.localactiveind",
        $"diagnosis.localadmitflg",
        $"diagnosis.localdiagnosis",
        $"diagnosis.localdiagnosisproviderid",
        $"diagnosis.localdiagnosisstatus",
        $"diagnosis.localdischargeflg",
        $"diagnosis.localpresentonadmission",
        $"diagnosis.mappeddiagnosis",
        $"diagnosis.mappeddiagnosisstatus",
        $"diagnosis.modified_date",
        $"diagnosis.orig_codetype",
        $"diagnosis.orig_mappeddiagnosis",
        $"diagnosis.patientid",
        $"diagnosis.primarydiagnosis",
        $"diagnosis.resolutiondate".as("resolution_dt"),
        $"diagnosis.row_source",
        $"diagnosis.sourceid",
        when($"map_predicate_values.column_value".isNotNull || $"diagnosis.hosp_dx_flag".isNull || $"diagnosis.hosp_dx_flag".notEqual("Y"), Precursors.CUI_INVALID)
          .when($"diagnosis.localpresentonadmission".isNull, Precursors.CUI_NULL)
          .when($"diagnosis.localpresentonadmission".isNotNull && $"map_poa.cui".isNull, Precursors.CUI_INVALID)
          .otherwise($"map_poa.cui") as "mappedpresentonadmission"
      )
  }

}

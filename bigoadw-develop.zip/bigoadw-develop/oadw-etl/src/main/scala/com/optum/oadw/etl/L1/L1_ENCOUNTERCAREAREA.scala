
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_encountercarearea, encountercarearea}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_ENCOUNTERCAREAREA extends TableInfo[l1_encountercarearea]{
  override def dependsOn: Set[String] = Set("ENCOUNTERCAREAREA")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_ENCOUNTERCAREAREA"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("ENCOUNTERCAREAREA").as[encountercarearea]

    cdrTbl
    .select(
		$"groupid".as("client_id"),
		$"datasrc",
		$"patientid",
		$"encounterid",
		$"encountertime".as("encounter_dtm"),
		$"facilityid",
		$"localcareareacode",
		$"careareastarttime".as("careareastart_dtm"),
		$"careareaendtime".as("careareaend_dtm"),
		$"client_ds_id",
		$"hgpid",
		$"grp_mpi".as("mpi"),
		$"locallocationname",
		$"servicecode"
    )
  }
}


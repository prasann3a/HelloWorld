package com.optum.oadw.etl.L3

import com.optum.oadw.etl.constants.Procedures
import com.optum.oadw.oadwModels._
import com.optum.oadw.oadw_ref.models.l3_map_proc_group_detail
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.definedfunctions.{BitOrAggFunction, GetMinDateTimeWithNonZero, ListAggFunction}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.sql.functions.{lit, _}
import org.apache.spark.sql.types.{DateType, IntegerType}

/**
  * Algorithm specification: https://wiki.humedica.net/display/Data/OADW+Concept+Specification+-+Provider+Attribution
  * OADW-1804 changes based on spec https://wiki.advisory.com/display/DATAPIPE/OADW+Concept+Specification+-+Procedure+Groups
  */

object L3_PAT_PROC_GROUP extends TableInfo[l3_pat_proc_group] {
  override def name: String = "L3_PAT_PROC_GROUP"

  override def dependsOn: Set[String] = Set("L2_PAT_PROC", "L3_MAP_PROC_GROUP", "L3_DICT_PROC_GROUP", "L2_PAT_CLINICAL_EVENT", "REFERENCE_SCHEMA_L3_MAP_PROC_GROUP_DETAIL")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL2PatProc = loadedDependencies("L2_PAT_PROC").as[l2_pat_proc]
    val tL3MapProcGroup = loadedDependencies("L3_MAP_PROC_GROUP").as[l3_map_proc_group]
    val tL3DictProcGroup = loadedDependencies("L3_DICT_PROC_GROUP").as[l3_dict_proc_group]
    val tL2PatClinicalEvent = loadedDependencies("L2_PAT_CLINICAL_EVENT").as[l2_pat_clinical_event]
    val tL3MapProcGroupDetail = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PROC_GROUP_DETAIL").as[l3_map_proc_group_detail])

    val detailEventTypeCuiString = tL2PatClinicalEvent
      .where($"event_type_cui".isNotNull)
      .select($"event_type_cui").distinct().map(_.getString(0)).collect.toSeq

    val tL2PatClinicalEventWithProcGroupDetail = tL2PatClinicalEvent
      .where($"event_type_cui".isin(detailEventTypeCuiString: _*))

    calculateTL3PatProcGroup(sparkSession, tL2PatProc, tL3MapProcGroup, tL3DictProcGroup, tL3MapProcGroupDetail, tL2PatClinicalEventWithProcGroupDetail).toDF()
//      .select($"client_id",
//        $"mpi",
//        $"proc_dtm",
//        $"prov_id",
//        $"clinical_event_id",
//        $"proc_group_id",
//        $"cds_grp",
//        $"principal_ind",
//        $"sensitive_ind",
//        $"sensitive_cat_id")
  }

  private def calculateTL3PatProcGroup(sparkSession: SparkSession,
                                       tL2PatProc: Dataset[l2_pat_proc],
                                       tL3MapProcGroup: Dataset[l3_map_proc_group],
                                       tL3DictProcGroup: Dataset[l3_dict_proc_group],
                                       tL3MapProcGroupDetail: Dataset[l3_map_proc_group_detail],
                                       tL2PatClinicalEventWithProcGroupDetail: Dataset[l2_pat_clinical_event]): Dataset[l3_pat_proc_group] = {
    import sparkSession.implicits._

    val detailProcGroupId = tL3MapProcGroupDetail
      .where($"proc_group_id".isNotNull)
      .select($"proc_group_id").distinct().map(_.getInt(0)).collect.toSeq

    // "1" for rows not (! used) related to detailProcGroupId, "2" to identify rows related to detailProcGroupId

    val cptModCodes_1 = getPatProcGroupColumns(sparkSession,
      tL2PatProc.as("pp")
      .where($"code_type" === Procedures.CODE_TYPE_CPT4)
      .crossJoin(tL3MapProcGroup.as("mpg"))
      .where(!$"mpg.proc_group_id".isin(detailProcGroupId: _*) && $"mpg.code_type" === Procedures.CODE_TYPE_CPTMOD)
      .join(tL3DictProcGroup.as("dpg"), $"dpg.proc_group_id" === $"mpg.proc_group_id", "inner")
      .where($"mpg.proc_cd" isin (concat($"pp.proc_cd",lit("-"),$"pp.modifier_1"),
        concat($"pp.proc_cd",lit("-"),$"pp.modifier_2"),
        concat($"pp.proc_cd",lit("-"),$"pp.modifier_3"),
        concat($"pp.proc_cd",lit("-"),$"pp.modifier_4"))
        )
      )

    val cpt4Codes_1 = getPatProcGroupColumns(sparkSession,
      tL2PatProc.as("pp")
        .where($"code_type" === Procedures.CODE_TYPE_CPT4)
        .join(tL3MapProcGroup.where(!$"proc_group_id".isin(detailProcGroupId: _*)).as("mpg"), $"mpg.code_type" === $"pp.code_type" && $"mpg.proc_cd" === $"pp.proc_cd", "inner")
        .join(tL3DictProcGroup.as("dpg"), $"dpg.proc_group_id" === $"mpg.proc_group_id", "inner")
        .where($"mpg.proc_cd".endsWith("F") and
          not(($"pp.modifier_1".isNotNull and $"pp.modifier_1".isin(Procedures.MODIFIERS: _*))
            or ($"pp.modifier_2".isNotNull and $"pp.modifier_2".isin(Procedures.MODIFIERS: _*))
            or ($"pp.modifier_3".isNotNull and $"pp.modifier_3".isin(Procedures.MODIFIERS: _*))
            or ($"pp.modifier_4".isNotNull and $"pp.modifier_4".isin(Procedures.MODIFIERS: _*)))
        )
    )

    val otherCodeTypes_1 = getPatProcGroupColumns(sparkSession,
      tL2PatProc.as("pp")
        .where($"pp.code_type".isin(Procedures.PROCEDURE_CODE_TYPES: _*))
        .join(tL3MapProcGroup.where(!$"proc_group_id".isin(detailProcGroupId: _*)).as("mpg"), $"mpg.code_type" === $"pp.code_type" && $"mpg.proc_cd" === $"pp.proc_cd", "inner")
        .where(not($"pp.code_type" === "CPTMOD" or ($"pp.code_type" === "CPT4" and $"pp.proc_cd".endsWith("F"))))
        .join(tL3DictProcGroup.as("dpg"), $"dpg.proc_group_id" === $"mpg.proc_group_id", "inner")
    )


    val cptModCodes_2 = tL2PatProc.as("pp")
      .where($"code_type" === Procedures.CODE_TYPE_CPT4)
      .crossJoin(tL3MapProcGroup.as("mpg"))
      .where(!$"mpg.proc_group_id".isin(detailProcGroupId: _*) && $"mpg.code_type" === Procedures.CODE_TYPE_CPTMOD)
      .join(tL3DictProcGroup.as("dpg"), $"dpg.proc_group_id" === $"mpg.proc_group_id", "inner")
      .where($"mpg.proc_cd" isin (concat($"pp.proc_cd",lit("-"),$"pp.modifier_1"),
        concat($"pp.proc_cd",lit("-"),$"pp.modifier_2"),
        concat($"pp.proc_cd",lit("-"),$"pp.modifier_3"),
        concat($"pp.proc_cd",lit("-"),$"pp.modifier_4"))
        )

    val cpt4Codes_2 = tL2PatProc.as("pp")
      .where($"code_type" === Procedures.CODE_TYPE_CPT4)
      .join(tL3MapProcGroup.where($"proc_group_id".isin(detailProcGroupId: _*)).as("mpg"), $"mpg.code_type" === $"pp.code_type" && $"mpg.proc_cd" === $"pp.proc_cd", "inner")
      .join(tL3DictProcGroup.as("dpg"), $"dpg.proc_group_id" === $"mpg.proc_group_id", "inner")
      .where($"mpg.proc_cd".endsWith("F") and
        not(($"pp.modifier_1".isNotNull and $"pp.modifier_1".isin(Procedures.MODIFIERS: _*))
          or ($"pp.modifier_2".isNotNull and $"pp.modifier_2".isin(Procedures.MODIFIERS: _*))
          or ($"pp.modifier_3".isNotNull and $"pp.modifier_3".isin(Procedures.MODIFIERS: _*))
          or ($"pp.modifier_4".isNotNull and $"pp.modifier_4".isin(Procedures.MODIFIERS: _*)))
      )

    val otherCodeTypes_2 = tL2PatProc.as("pp")
      .where($"pp.code_type".isin(Procedures.PROCEDURE_CODE_TYPES: _*))
      .join(tL3MapProcGroup.where($"proc_group_id".isin(detailProcGroupId: _*)).as("mpg"), $"mpg.code_type" === $"pp.code_type" && $"mpg.proc_cd" === $"pp.proc_cd", "inner")
      .where(not($"pp.code_type" === "CPTMOD" or ($"pp.code_type" === "CPT4" and $"pp.proc_cd".endsWith("F"))))
      .join(tL3DictProcGroup.as("dpg"), $"dpg.proc_group_id" === $"mpg.proc_group_id", "inner")


    // combine all _2s
    val combined_2 = otherCodeTypes_2
      .union(cptModCodes_2)
      .union(cpt4Codes_2)

    val combined2Exclude = combined_2
      .join(tL2PatClinicalEventWithProcGroupDetail.as("pce"), $"pce.mpi" === $"pp.mpi" && $"pce.clinical_event_id" === $"pp.clinical_event_id", "left_outer")  // need outer join to take care of sample mpi "56789" case
      .join(tL3MapProcGroupDetail.as("mpgd"), $"mpgd.proc_group_id" === $"mpg.proc_group_id", "inner")
      .where(
          // case 3:
          ($"mpgd.detail_type" === "EXCLUSION" && $"mpgd.event_type_cui".isNotNull && $"mpgd.modifier".isNotNull && $"mpgd.event_type_cui" === $"pce.event_type_cui"
            && ($"mpgd.modifier" === $"pp.modifier_1" || $"mpgd.modifier" === $"pp.modifier_2" || $"mpgd.modifier" === $"pp.modifier_3" || $"mpgd.modifier" === $"pp.modifier_4")
          )
          ||
          //case 4:
          ($"mpgd.detail_type" === "EXCLUSION" && $"mpgd.event_type_cui".isNull && $"mpgd.modifier".isNotNull
            && ($"mpgd.modifier" === $"pp.modifier_1" || $"mpgd.modifier" === $"pp.modifier_2" || $"mpgd.modifier" === $"pp.modifier_3" || $"mpgd.modifier" === $"pp.modifier_4")
          )
          ||
          //case 4:
          ($"mpgd.detail_type" === "EXCLUSION" && $"mpgd.event_type_cui".isNotNull && $"mpgd.modifier".isNull && $"mpgd.event_type_cui" === $"pce.event_type_cui")
      )
      .select($"pp.client_id",
        $"pp.mpi",
        $"pp.proc_cd",
        $"pp.proc_dtm",
        $"pp.prov_id",
        $"pp.clinical_event_id",
        $"mpg.proc_group_id",
        $"pp.cds_grp",
        $"pp.principal_ind",
        $"dpg.sensitive_ind",
        $"dpg.sensitive_cat_id"
      )

    val combined2Include = combined_2
      .join(tL2PatClinicalEventWithProcGroupDetail.as("pce"), $"pce.mpi" === $"pp.mpi" && $"pce.clinical_event_id" === $"pp.clinical_event_id", "left_outer")   // need outer join to take care of sample mpi "34567" case
      .join(tL3MapProcGroupDetail.as("mpgd1"), $"mpgd1.proc_group_id" === $"mpg.proc_group_id", "inner")
      .join(tL3MapProcGroupDetail.as("mpgd2"), $"mpgd2.proc_group_id" === $"mpgd1.proc_group_id", "inner")
      .where(
          // case 1
          ($"mpgd1.detail_type" === "INCLUSION" && $"mpgd1.event_type_cui".isNotNull && $"mpgd1.modifier".isNotNull && $"mpgd1.event_type_cui" === $"pce.event_type_cui"
            && ($"mpgd1.modifier" === $"pp.modifier_1" || $"mpgd1.modifier" === $"pp.modifier_2" || $"mpgd1.modifier" === $"pp.modifier_3" || $"mpgd1.modifier" === $"pp.modifier_4")
          )
          ||
          // case 2
          ($"mpgd1.detail_type" === "INCLUSION" && $"mpgd1.event_type_cui".isNull && $"mpgd1.modifier".isNotNull
            && ($"mpgd1.modifier" === $"pp.modifier_1" || $"mpgd1.modifier" === $"pp.modifier_2" || $"mpgd1.modifier" === $"pp.modifier_3" || $"mpgd1.modifier" === $"pp.modifier_4")
          )
          ||
          // case 2
          ($"mpgd1.detail_type" === "INCLUSION" && $"mpgd1.event_type_cui".isNotNull && $"mpgd1.modifier".isNull && $"mpgd1.event_type_cui" === $"pce.event_type_cui")
          ||
          // case 3,   // if this EXCLUSION does not satisfy, we need to include it, (PROC_GROUP_ID = 3 in the example spreadsheet)
          ($"mpgd1.detail_type" === "EXCLUSION" && $"mpgd1.event_type_cui".isNotNull && $"mpgd1.modifier".isNotNull
            && (   ($"mpgd1.event_type_cui" =!= $"pce.event_type_cui")
                || ($"mpgd1.modifier" =!= $"pp.modifier_1" || $"mpgd1.modifier" =!= $"pp.modifier_2" || $"mpgd1.modifier" =!= $"pp.modifier_3" || $"mpgd1.modifier" =!= $"pp.modifier_4")
                || coalesce($"pp.modifier_1", $"pp.modifier_2", $"pp.modifier_3", $"pp.modifier_4").isNull
               )
          )
          ||
          // if this EXCLUSION does not satisfy, we need to include it, (PROC_GROUP_ID = 4 in the example spreadsheet)
          (
            ($"mpgd1.detail_type" === "EXCLUSION" && $"mpgd1.event_type_cui".isNull && $"mpgd1.modifier".isNotNull
              && (   ($"mpgd1.modifier" =!= $"pp.modifier_1" || $"mpgd1.modifier" =!= $"pp.modifier_2" || $"mpgd1.modifier" =!= $"pp.modifier_3" || $"mpgd1.modifier" =!= $"pp.modifier_4")
                  || coalesce($"pp.modifier_1", $"pp.modifier_2", $"pp.modifier_3", $"pp.modifier_4").isNull
                 )
            )
            &&
            ($"mpgd2.detail_type" === "EXCLUSION" && $"mpgd2.event_type_cui".isNotNull && $"mpgd2.modifier".isNull
               && ($"mpgd2.event_type_cui" =!= $"pce.event_type_cui")
            )
          )
          ||
          // sample mpi "34567" and "45678" case:
          ($"mpgd1.detail_type" === "EXCLUSION" && $"mpgd1.event_type_cui".isNull && $"mpgd1.modifier".isNotNull
             && (    ($"mpgd1.modifier" =!= $"pp.modifier_1" || $"mpgd1.modifier" =!= $"pp.modifier_2" || $"mpgd1.modifier" =!= $"pp.modifier_3" || $"mpgd1.modifier" =!= $"pp.modifier_4")
                  || coalesce($"pp.modifier_1", $"pp.modifier_2", $"pp.modifier_3", $"pp.modifier_4").isNull
                )
          )
          ||
          // sample mpi "34567" case:
          ($"mpgd1.detail_type" === "EXCLUSION" && $"mpgd1.event_type_cui".isNotNull && $"mpgd1.modifier".isNull
             && ($"mpgd1.event_type_cui" =!= $"pce.event_type_cui")
             && coalesce($"pp.modifier_1", $"pp.modifier_2", $"pp.modifier_3", $"pp.modifier_4").isNull
          )
      )
      .select($"pp.client_id",
        $"pp.mpi",
        $"pp.proc_cd",
        $"pp.proc_dtm",
        $"pp.prov_id",
        $"pp.clinical_event_id",
        $"mpg.proc_group_id",
        $"pp.cds_grp",
        $"pp.principal_ind",
        $"dpg.sensitive_ind",
        $"dpg.sensitive_cat_id"
      ).distinct()

    val result = combined2Include.except(combined2Exclude)  // set minus operation

    // If we have the same CLIENT_ID, MPI, PROC_DTM (not trunc) , PROC_GROUP_ID and PROV_ID, we select MIN(CLINICAL_EVENT_ID)
    val result_step2 = result
      .union(otherCodeTypes_1)
      .union(cptModCodes_1)
      .union(cpt4Codes_1)
      .as("pp")
      .groupBy($"pp.client_id",
        $"pp.mpi",
        $"pp.proc_dtm",
        $"pp.prov_id",
        $"pp.proc_group_id",
        $"pp.sensitive_ind",
        $"pp.sensitive_cat_id"
      )
      .agg(
        min($"pp.clinical_event_id").as("clinical_event_id"),
        max("pp.principal_ind").as("principal_ind"),
        ListAggFunction.listAgg($"pp.cds_grp").as("cds_grp")
      )

      // now get the first non-midnight row if there are multiple rows in TRUNC(PROC_DTM)
      val result_step3 = result_step2.as("r")
      .groupBy($"r.client_id",
        $"r.mpi",
        $"r.proc_dtm".cast(DateType).as("proc_dt"),
        $"r.prov_id",
        $"r.proc_group_id",
        $"r.sensitive_ind",
        $"r.sensitive_cat_id"
      )
      .agg(
        max("r.principal_ind").as("principal_ind"),
        ListAggFunction.listAgg($"r.cds_grp").as("cds_grp"),
        GetMinDateTimeWithNonZero.getMinDateTimeWithNonZero($"r.proc_dtm").as("proc_dtm")
      )

    // Now we need to find the CLINICAL_EVENT_ID for that first non-midnight row
    val result_final = result_step3.as("r3")
      .join(result_step2.as("r2"),$"r2.mpi" === $"r3.mpi" && $"r2.proc_dtm" === $"r3.proc_dtm" && $"r2.prov_id" === $"r3.prov_id"
        && $"r2.proc_group_id" === $"r3.proc_group_id" && $"r2.sensitive_ind" === $"r3.sensitive_ind" && $"r2.sensitive_cat_id" === $"r3.sensitive_cat_id", "inner" )
      .select ($"r3.client_id",
        $"r3.mpi",
        $"r3.proc_dtm",
        $"r3.prov_id",
        $"r2.clinical_event_id",
        $"r3.proc_group_id",
        $"r3.cds_grp",
        $"r3.principal_ind",
        $"r3.sensitive_ind",
        $"r3.sensitive_cat_id"
      ).distinct()
      .as[l3_pat_proc_group]

    result_final
}

  private def   getPatProcGroupColumns(sparkSession: SparkSession, df: DataFrame): DataFrame = {
    import sparkSession.implicits._
    df.select($"pp.client_id",
      $"pp.mpi",
      $"pp.proc_cd",
      $"pp.proc_dtm",
      $"pp.prov_id",
      $"pp.clinical_event_id",
      $"mpg.proc_group_id",
      $"pp.cds_grp",
      $"pp.principal_ind",
      $"dpg.sensitive_ind",
      $"dpg.sensitive_cat_id"
    )
  }
}

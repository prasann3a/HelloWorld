
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_admit_source, map_admit_source}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_ADMIT_SOURCE extends TableInfo[l1_map_admit_source]{
  override def dependsOn: Set[String] = Set("MAP_ADMIT_SOURCE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_ADMIT_SOURCE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapAdmitSource = loadedDependencies("MAP_ADMIT_SOURCE").as[map_admit_source]

    mapAdmitSource
    .select(
			$"groupid".as("client_id"),
			$"localcode".as("local_code"),
			$"cui",
			$"dts_version"
    )
  }
}


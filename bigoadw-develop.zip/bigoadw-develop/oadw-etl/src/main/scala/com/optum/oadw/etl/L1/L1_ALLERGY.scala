
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_allergy, allergy}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_ALLERGY extends TableInfo[l1_allergy]{
  override def dependsOn: Set[String] = Set("ALLERGY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_ALLERGY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val allergy = loadedDependencies("ALLERGY").as[allergy]

    allergy
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"client_ds_id",
			$"patientid",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"onsetdate".as("onset_dt"),
			$"encounterid",
			$"localallergentype",
			$"localallergencd",
			$"localallergendesc",
			$"localstatus",
			$"localndc",
			$"ndc11",
			$"localgpi",
			$"mappedndc",
			$"mappedgpi",
			$"hum_med_key",
			$"hum_gen_med_key",
			$"hts_generic",
			$"hts_generic_ext",
			$"map_used",
			$"dcc",
			$"rxnorm_code"
    )
  }
}


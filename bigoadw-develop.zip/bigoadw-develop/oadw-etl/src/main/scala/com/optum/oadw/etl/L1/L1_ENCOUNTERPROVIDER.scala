
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_encounterprovider, encounterprovider}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_ENCOUNTERPROVIDER extends TableInfo[l1_encounterprovider]{
  override def dependsOn: Set[String] = Set("ENCOUNTERPROVIDER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_ENCOUNTERPROVIDER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val encounterprovider = loadedDependencies("ENCOUNTERPROVIDER").as[encounterprovider]

    encounterprovider
    .select(
			$"groupid".as("client_id"),
			$"encounterid",
			$"datasrc",
			$"facilityid",
			$"patientid",
			$"providerid",
			$"providerrole",
			$"encountertime".as("encounter_dtm"),
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"mstrprovid"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_spec, prov_spec}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_SPEC extends TableInfo[l1_prov_spec]{
  override def dependsOn: Set[String] = Set("PROV_SPEC")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_SPEC"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val provSpec = loadedDependencies("PROV_SPEC").as[prov_spec]

    provSpec
    .select(
			$"groupid".as("client_id"),
			$"localproviderid",
			$"localspecialtycode",
			$"localcodesource".as("datasrc"),
			$"client_ds_id",
			$"mstrprovid",
			$"local_code_order"
    )
  }
}


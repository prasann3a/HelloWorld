
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patient_id, patient_id}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENT_ID extends TableInfo[l1_patient_id]{
  override def dependsOn: Set[String] = Set("PATIENT_ID")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENT_ID"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientId = loadedDependencies("PATIENT_ID").as[patient_id]

    patientId
    .select(
			$"groupid".as("client_id"),
			$"patientid",
			$"datasrc",
			$"idtype",
			$"idvalue",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"id_subtype"
    )
  }
}


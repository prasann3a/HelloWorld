package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_map_cds_flg_bit
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType

object L2_MAP_CDS_FLG_BIT extends TableInfo[l2_map_cds_flg_bit]{
  override def name: String = "L2_MAP_CDS_FLG_BIT"
  override def dependsOn: Set[String] = Set("L2_MAP_CDS_FLG")

  protected def createDataFrame( sparkSession: SparkSession,
                                 loadedDependencies: Map[String, DataFrame],
                                 udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                 mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG")
    tL2MapCdsFlg
      .groupBy($"client_id", $"client_ds_id", $"data_grp_name")
      .agg(
        $"client_ds_id".cast(StringType).as("cds_grp"),
        min(when($"source_type_flg" === 1, $"client_ds_name").otherwise($"data_grp_name")).as("bit_name")
      )
      .select(
        $"client_id",
        $"cds_grp",
        $"bit_name"
      )
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_alcohol_detail, map_alcohol_detail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_ALCOHOL_DETAIL extends TableInfo[l1_map_alcohol_detail]{
  override def dependsOn: Set[String] = Set("MAP_ALCOHOL_DETAIL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_ALCOHOL_DETAIL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapAlcoholDetail = loadedDependencies("MAP_ALCOHOL_DETAIL").as[map_alcohol_detail]

    mapAlcoholDetail
    .select(
			$"groupid".as("client_id"),
			$"localcode".as("local_code"),
			$"consumption_hasbled_cui".as("cui"),
			$"dts_version"
    )
  }
}


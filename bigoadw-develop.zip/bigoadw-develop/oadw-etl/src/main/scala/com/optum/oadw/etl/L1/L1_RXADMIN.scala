
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_rxadmin, rxadmin}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_RXADMIN extends TableInfo[l1_rxadmin]{
  override def dependsOn: Set[String] = Set("RXADMIN")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_RXADMIN"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val rxadmin = loadedDependencies("RXADMIN").as[rxadmin]

    rxadmin
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"rxadministrationid",
			$"patientid",
			$"rxorderid",
			$"encounterid",
			$"facilityid",
			$"administrationtime".as("administration_dtm"),
			$"dispensedtime".as("dispensed_dtm"),
			$"localinfusionduration",
			$"localinfusionrate",
			$"localinfusionvolume",
			$"localdoseunit",
			$"localdrugdescription",
			$"localform",
			$"localgpi",
			$"localmedcode",
			$"localndc",
			$"ndc11",
			$"localqtyofdoseunit",
			$"localroute",
			$"localstrengthperdoseunit",
			$"localstrengthunit",
			$"localtotaldose",
			$"localproviderid",
			$"qtydispensed",
			$"localdrugdescription_phi",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"localgenericdesc",
			$"hum_gen_med_key",
			$"hts_generic",
			$"hts_generic_ext",
			$"hum_med_key",
			$"map_used",
			$"mappedndc",
			$"mappedgpi",
			$"mstrprovid",
			$"dcc",
			$"rxnorm_code"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_pat_rel_summary, prov_pat_rel_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_PAT_REL_SUMMARY extends TableInfo[l1_prov_pat_rel_summary]{
  override def dependsOn: Set[String] = Set("PROV_PAT_REL_SUMMARY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_PAT_REL_SUMMARY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val provPatRelSummary = loadedDependencies("PROV_PAT_REL_SUMMARY").as[prov_pat_rel_summary]

    provPatRelSummary
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"providerid",
			$"localrelshipcode",
			$"startdate".as("start_dt"),
			$"enddate".as("end_dt"),
			$"client_ds_id",
			$"grp_mpi".as("mpi"),
			$"mstrprovid"
    )
  }
}


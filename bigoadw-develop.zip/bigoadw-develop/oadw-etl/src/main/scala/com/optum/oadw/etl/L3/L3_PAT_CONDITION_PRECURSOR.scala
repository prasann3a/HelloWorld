package com.optum.oadw.etl.L3

import com.optum.oadw.oadwModels.{l3_pat_condition_precursor, l3_dict_condition_precursor}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.definedfunctions.{BitOrAggFunction, ListAggFunction, ListSortFunction}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L3_PAT_CONDITION_PRECURSOR extends TableInfo[l3_pat_condition_precursor]  {
  override def name: String = "L3_PAT_CONDITION_PRECURSOR"

  override def dependsOn: Set[String] = Set("TEMP_L3_PAT_CONDITION_PRECURSOR_INDIVIDUAL", "L3_DICT_CONDITION_PRECURSOR","TEMP_L3_PAT_CONDITION_PRECURSOR_FAMILY")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val l3DictCondPrecursor = broadcast(loadedDependencies("L3_DICT_CONDITION_PRECURSOR").as[l3_dict_condition_precursor])

    val window =Window.partitionBy($"condition_id", $"mpi", $"precursor_id",to_date(date_format($"precursor_dtm", "yyyy-MM-dd")))

    val tempL3patConditionPrecursorIndividual = loadedDependencies("TEMP_L3_PAT_CONDITION_PRECURSOR_INDIVIDUAL")
      .select($"client_id", $"mpi",$"precursor_cds_grp",
        $"precursor_domain", $"precursor_dtm", $"precursor_id", $"precursor_modifier_flg", $"precursor_type",
        $"precursor_value", $"sensitive_ind", $"condition_id", $"rule_id",$"sensitive_ind_precur")

    val tempL3patConditionPrecursorFamily = loadedDependencies("TEMP_L3_PAT_CONDITION_PRECURSOR_FAMILY")
      .select($"client_id", $"mpi",$"precursor_cds_grp",
        $"precursor_domain", $"precursor_dtm", $"precursor_id", $"precursor_modifier_flg", $"precursor_type",
        $"precursor_value", $"sensitive_ind", $"condition_id", $"rule_id",$"sensitive_ind_precur")

    val combinedActivePrecursors= tempL3patConditionPrecursorIndividual.union(tempL3patConditionPrecursorFamily).distinct()

    val filteredPrecursors=combinedActivePrecursors.withColumn("row_num",row_number().over(window.orderBy($"sensitive_ind_precur", $"precursor_value".desc_nulls_last , $"precursor_type".asc_nulls_last)))
      .as("fp")
      .join(l3DictCondPrecursor.as("dcp"), $"dcp.condition_id" === $"fp.condition_id" and $"dcp.precursor_id" === $"fp.precursor_id", "inner")
      .select($"fp.*" , $"dcp.sensitive_ind")

    filteredPrecursors.select($"*",
      greatest($"fp.sensitive_ind", $"dcp.sensitive_ind").as("temp_sensitive_ind"),
      BitOrAggFunction.bitOrAgg($"precursor_modifier_flg").over(window).as("temp_precursor_modifier_flg")
    )
    .select(
      date_format($"precursor_dtm", "yyyyMM").cast(IntegerType).as("yr_month"),
      $"client_id",
      $"mpi",
      ListAggFunction.listAgg($"precursor_cds_grp").over(window).as("precursor_cds_grp"),
      concat_ws(".",ListSortFunction.listsort(collect_set($"rule_id").over(window))).as("rule_grp"),
      $"fp.condition_id",
      $"fp.precursor_id".as("precursor_id"),
      to_timestamp(date_format($"precursor_dtm", "yyyy-MM-dd")).as("precursor_dt"),
      $"precursor_domain".as("precursor_domain"),
      $"precursor_type".as("precursor_type"),
      $"precursor_value".as("precursor_value"),
      when($"temp_precursor_modifier_flg".isNotNull, $"temp_precursor_modifier_flg" ).otherwise(lit(0)).cast(IntegerType).as("precursor_modifier_flg"),
      when($"temp_sensitive_ind".isNotNull, $"temp_sensitive_ind" ).otherwise(lit(0)).as("sensitive_ind")
    )
    .where($"row_num" === lit(1))
  }

}

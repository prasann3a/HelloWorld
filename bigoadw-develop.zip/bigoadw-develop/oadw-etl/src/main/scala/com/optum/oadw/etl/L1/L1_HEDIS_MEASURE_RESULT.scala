
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_hedis_measure_result, hedis_measure_result}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_HEDIS_MEASURE_RESULT extends TableInfo[l1_hedis_measure_result]{
  override def dependsOn: Set[String] = Set("HEDIS_MEASURE_RESULT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_HEDIS_MEASURE_RESULT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val hedisMeasureResult = loadedDependencies("HEDIS_MEASURE_RESULT").as[hedis_measure_result]

    hedisMeasureResult
    .select(
			$"groupid".as("client_id"),
			$"measure_id",
			$"measure_name",
			$"stratification_id",
			$"grp_mpi".as("mpi"),
			$"result_answer",
			$"denominator_flag",
			$"denominator_exclusion_flag",
			$"denominator_exception_flag",
			$"numerator_flag",
			$"numerator_exclusion_flag",
			$"measurement_end_date".as("measurement_end_dt"),
			$"qualifying_date".as("qualifying_dt"),
			$"run_date".as("run_dt"),
			$"episode_number",
			$"expected_visit_count",
			$"actual_visit_count",
			$"member_month_count",
			$"days_count",
			$"discharge_count",
			$"services_count",
			$"surgery_weight",
			$"base_risk_weight",
			$"age_and_gender_weight",
			$"dcc_weight",
			$"comorbidity_weight",
			$"age",
			$"gender",
			$"risk_score",
			$"adjusted_probability",
			$"dcc_category",
			$"population_id",
			$"version",
			$"hum_vers_yr"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_ethnicity, map_ethnicity}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_ETHNICITY extends TableInfo[l1_map_ethnicity]{
  override def dependsOn: Set[String] = Set("MAP_ETHNICITY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_ETHNICITY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapEthnicity = loadedDependencies("MAP_ETHNICITY").as[map_ethnicity]

    mapEthnicity
    .select(
			$"groupid".as("client_id"),
			$"mnemonic".as("local_code"),
			$"description",
			$"cui",
			$"dts_version"
    )
  }
}


package com.optum.oadw.etl.L2

import java.sql.Timestamp

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l1_proceduredo, l1_ref_imap_tos_proc, l1_ref_ub04_rev_codes, l1_map_tos_type}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, LongType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

case class temp_tos_procedure_do_data(client_id: String, client_ds_id: Integer, mpi: String, encounterid: String,
                                      tos_i_5: java.lang.Integer, mappedcode: String, codetype: String, procedure_dtm: Timestamp,
                                      performing_mstrprovid: java.lang.Long, localprincipleindicator: String, hosp_px_flag: String)

object TEMP_TOS_PROCEDUREDO extends TableInfo[temp_tos_procedure_do_data] {
  override def name: String = "TEMP_TOS_PROCEDUREDO"

  override def dependsOn: Set[String] = Set("L1_REF_UB04_REV_CODES", "L1_MAP_TOS_TYPE",
    "L1_REF_IMAP_TOS_PROC", "TEMP_TOS_ENC_PROV", "TEMP_PROVIDER_CUI_SPEC", "L1_PROCEDUREDO")

  override def partitions: Int = 64

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1Proceduredo = loadedDependencies("L1_PROCEDUREDO").distinct().as[l1_proceduredo]

    val l1RefUb04RevCodes = loadedDependencies("L1_REF_UB04_REV_CODES").as[l1_ref_ub04_rev_codes]

    val tL1MapTostype = loadedDependencies("L1_MAP_TOS_TYPE").as[l1_map_tos_type]

    val l1RefImapTosProc = loadedDependencies("L1_REF_IMAP_TOS_PROC").as[l1_ref_imap_tos_proc]

    val tempTosEncProv = loadedDependencies("TEMP_TOS_ENC_PROV")

    val tempProviderCuiSpec = loadedDependencies("TEMP_PROVIDER_CUI_SPEC")

    createTempTosProceduredo(sparkSession, l1Proceduredo, l1RefUb04RevCodes, tempTosEncProv, tempProviderCuiSpec, tL1MapTostype, l1RefImapTosProc)

  }

  private def createTempTosProceduredo(sparkSession: SparkSession,
                                       l1Proceduredo: Dataset[l1_proceduredo],
                                       l1RefUb04RevCodes: Dataset[l1_ref_ub04_rev_codes],
                                       tempTosEncProv: DataFrame,
                                       tempProviderCuiSpec: DataFrame,
                                       tL1MapTostype: Dataset[l1_map_tos_type],
                                       l1RefImapTosProc: Dataset[l1_ref_imap_tos_proc]): DataFrame = {
    import sparkSession.implicits._

    l1Proceduredo.as("c")
      .where($"c.codetype".isin("CPT4", "HCPCS", "REV", "ICD9", "ICD10", "CUSTOM"))
      .join(tempTosEncProv.as("t"), $"t.encounterid" === $"c.encounterid" and $"t.client_ds_id" === $"c.client_ds_id", "left_outer")
      .join(tempProviderCuiSpec.as("pcs"), $"pcs.prov_id" === $"c.performing_mstrprovid", "left_outer")
      .join(broadcast(l1RefUb04RevCodes).as("rc"), $"rc.rev_code" === $"c.localcode" and $"c.codetype" === "REV", "left_outer")
      .withColumn("spec_code", coalesce($"pcs.ii_code", $"t.spec_code"))
      .withColumn("inst_prof",
        when($"spec_code".between("100", "199"), "I")
          .when($"rc.rev_code".isNotNull and not($"spec_code".isin("700", "710", "711", "712")), "I")
          .when(coalesce($"pcs.facility_ind", $"t.facility_ind") === 1, "I")
          .otherwise("P"))
      .select(
        $"c.*", $"t.patient_type_cui", $"spec_code", $"inst_prof"
      ).as("t1")
      .join(tL1MapTostype.as("mt"), $"mt.spec_code" === $"t1.spec_code" and $"mt.patient_type_cui" === $"t1.patient_type_cui", "left_outer")
      .join(broadcast(l1RefImapTosProc).as("p1"), $"p1.map_code" === $"t1.mappedcode", "left_outer")
      .withColumn("typeTwo", $"inst_prof" === "I" and not($"mt.spec_code".startsWith("5")))
      .withColumn("icdAndCustom", $"t1.codetype".isin("ICD9", "ICD10", "CUSTOM"))
      .withColumn("tos_map_type_a", when($"icdAndCustom" === true, null).otherwise($"mt.tos_map_type"))
      .withColumn("tos_map_type_b",
        when($"icdAndCustom" === true, null)
          .otherwise(when($"typeTwo" === true, $"mt.tos_map_type").otherwise(null))
      )
      .withColumn("tos_type", when($"icdAndCustom" === true, null).otherwise(coalesce($"mt.tos_map_type", lit("0"))))
      .withColumn("prof_tos_a", when($"icdAndCustom" === true, null).otherwise($"p1.prof_tos"))
      .withColumn("anes_tos_a", when($"icdAndCustom" === true, null).otherwise($"p1.anes_tos"))
      .withColumn("op_tos_a", when($"icdAndCustom" === true, null).otherwise($"p1.op_tos"))
      .select(
        $"t1.*", $"typeTwo", $"icdAndCustom", $"tos_map_type_a", $"tos_map_type_b", $"tos_type", $"prof_tos_a", $"anes_tos_a", $"op_tos_a"
      )
      .as("v")
      .withColumn("tos_i_5",
        when($"v.tos_type" === "0", coalesce($"v.prof_tos_a", lit(5264)))
          .when($"v.tos_type" === 1, coalesce($"v.anes_tos_a", $"v.prof_tos_a", lit(5264)))
          .when($"v.tos_type" === 3, coalesce($"v.op_tos_a", $"v.prof_tos_a", lit(3393)))
          .when($"v.tos_type" === 2, when($"v.spec_code".isin("101", "102") and $"v.patient_type_cui" === "CH003031", 2002)
          .when($"v.spec_code".isin("101", "102") or $"v.patient_type_cui".isin("CH003033", "CH000795", "CH002903"), 2001)
          .when($"v.spec_code" === "103" or $"v.patient_type_cui" === "CH003032", 2003)
          .otherwise(2000)
        ).otherwise(null).cast(IntegerType)
      )
      .select(
        $"client_id", $"client_ds_id", $"mpi", $"encounterid", $"tos_i_5", $"mappedcode", $"codetype", $"procedure_dtm",
        $"performing_mstrprovid".cast(LongType), $"localprincipleindicator", $"hosp_px_flag"
      )
  }

  def directoryLevel: String = "L2"
}

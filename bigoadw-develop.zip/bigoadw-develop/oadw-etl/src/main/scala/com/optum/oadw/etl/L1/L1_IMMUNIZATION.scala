
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_immunization, immunization}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_IMMUNIZATION extends TableInfo[l1_immunization]{
  override def dependsOn: Set[String] = Set("IMMUNIZATION")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_IMMUNIZATION"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val immunization = loadedDependencies("IMMUNIZATION").as[immunization]

    immunization
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"client_ds_id",
			$"patientid",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"admindate".as("admin_dtm"),
			$"documenteddate".as("documented_dt"),
			$"localpatreportedflg",
			$"localdeferredreason",
			$"encounterid",
			$"localimmunizationcd",
			$"localimmunizationdesc",
			$"localndc",
			$"ndc11",
			$"localgpi",
			$"hum_med_key",
			$"hum_gen_med_key",
			$"hts_generic",
			$"hts_generic_ext",
			$"map_used",
			$"mappedndc",
			$"mappedgpi",
			$"localroute",
			$"dcc",
			$"rxnorm_code"
    )
  }
}


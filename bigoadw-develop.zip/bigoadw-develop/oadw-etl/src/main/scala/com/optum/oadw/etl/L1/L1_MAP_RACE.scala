
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_race, map_race}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_RACE extends TableInfo[l1_map_race]{
  override def dependsOn: Set[String] = Set("MAP_RACE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_RACE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapRace = loadedDependencies("MAP_RACE").as[map_race]

    mapRace
    .select(
			$"groupid".as("client_id"),
			$"mnemonic".as("local_code"),
			$"description",
			$"cui",
			$"dts_version"
    )
  }
}


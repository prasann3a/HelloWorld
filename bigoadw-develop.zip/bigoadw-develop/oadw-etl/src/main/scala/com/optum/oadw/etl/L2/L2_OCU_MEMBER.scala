package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_ocu_member
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_OCU_MEMBER extends QueryAndMetadata[l2_ocu_member] {
  override def name: String = "L2_OCU_MEMBER"

  override def sparkSql: String = """select a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id, c.sex, c.age_cat2, c.cat_status_cost3, c.mem_userdef_1_id, c.at_risk_status_id, c.zip, sum(rrisk) as retrorisk, cast(sum(mm) as decimal(38, 10)) as mm, cast(sum(mm_rx) as decimal(38, 10)) as mm_rx
from L2_II_OCU_MEMBER_EXT a
join L2_II_MAP_DATE_RANGE b on a.year_mth_id=b.year_mth_id
join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
group by a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id, c.sex, c.age_cat2, c.cat_status_cost3, c.mem_userdef_1_id, c.at_risk_status_id, c.zip"""

  override def dependsOn: Set[String] = Set("L2_II_OCU_MEMBER_EXT","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR_EXT")

  def originalSql: String = """

INSERT /*+ APPEND */ INTO L2_OCU_MEMBER (YEAR_MTH_ID,NEW_MEM_ATTR_ID,IA_TIME,PCP_ASSIGN,CONTRACT_ID,PRODUCT_ID,SEX,AGE_CAT2,CAT_STATUS_COST3,MEM_USERDEF_1_ID,ZIP,RETRORISK,MM,MM_RX)
select a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id, c.sex, c.age_cat2, c.cat_status_cost3, c.mem_userdef_1_id, c.zip, sum(rrisk) as retrorisk, sum(mm) as mm, sum(mm_rx) as mm_rx
from L2_II_OCU_MEMBER_EXT a
join L2_II_MAP_DATE_RANGE b on a.year_mth_id=b.year_mth_id
join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
group by a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id, c.sex, c.age_cat2, c.cat_status_cost3, c.mem_userdef_1_id, c.zip
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(
    OutputColumn("YEAR_MTH_ID",None,None),
    OutputColumn("NEW_MEM_ATTR_ID",None,None),
    OutputColumn("IA_TIME",None,None),
    OutputColumn("PCP_ASSIGN",None,None),
    OutputColumn("CONTRACT_ID",None,None),
    OutputColumn("PRODUCT_ID",None,None),
    OutputColumn("SEX",None,None),
    OutputColumn("AGE_CAT2",None,None),
    OutputColumn("CAT_STATUS_COST3",None,None),
    OutputColumn("MEM_USERDEF_1_ID",None,None),
    OutputColumn("at_risk_status_id",None,None),
    OutputColumn("ZIP",None,None),
    OutputColumn("RETRORISK",None,None),
    OutputColumn("MM",None,None),
    OutputColumn("MM_RX",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}

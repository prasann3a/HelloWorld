package com.optum.oadw.etl.L3


import com.optum.oadw.oadwModels.l3_ocu_pop_phm_costs
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L3_OCU_POP_PHM_COSTS extends QueryAndMetadata[l3_ocu_pop_phm_costs] {
  override def name: String = "L3_OCU_POP_PHM_COSTS"

  override def sparkSql: String = """select a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id,
c.sex, c.age_cat2, c.cat_status_cost3, c.mem_userdef_1_id, c.at_risk_status_id, c.zip, a.year_mth_pd,
a.network_paid_status_id, a.provider_status_id, a.tos_i_5, a.formulary, a.gbo, a.channel,a.ndc,a.pres_prv_i as presc_prov,
sum(amt_req) as amt_req, sum(amt_eqv) as amt_eqv, sum(amt_pay) as amt_pay, sum(amt_np) as amt_np, cast(sum(script) as int) as scripts, cast(sum(days_sup) as int) as days_sup, cast(sum(generic) as int) as generic,
cast(sum(script_gen) as int) as script_gen
from l2_ii_ocu_pop_phm_costs_ext a
join L2_II_MAP_DATE_RANGE b on a.year_mth_id=b.year_mth_id
join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
group by a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id, c.sex, c.age_cat2,
c.cat_status_cost3, c.mem_userdef_1_id, c.at_risk_status_id, c.zip, a.year_mth_pd, a.network_paid_status_id, a.provider_status_id,
a.tos_i_5, a.formulary, a.gbo, a.channel,a.ndc,a.pres_prv_i"""

  override def dependsOn: Set[String] = Set("L2_II_OCU_POP_PHM_COSTS_EXT","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR_EXT")

  def originalSql: String = """
--Overall population pharmacy cost & util

insert /*+ append */ into l3_ocu_pop_phm_costs(year_mth_id,NEW_MEM_ATTR_ID,ia_time,pcp_assign,contract_id,product_id,sex,age_cat2,
    cat_status_cost3,mem_userdef_1_id,zip,year_mth_pd,network_paid_status_id,provider_status_id,tos_i_5,formulary,
    gbo,channel,ndc,presc_prov,amt_req,amt_eqv,amt_pay,amt_np,scripts,days_sup,generic,script_gen
)
select a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id,
       c.sex, c.age_cat2, c.cat_status_cost3, c.mem_userdef_1_id, c.zip, a.year_mth_pd,
       a.network_paid_status_id, a.provider_status_id, a.tos_i_5, a.formulary, a.gbo, a.channel,a.ndc,a.pres_prv_i,
       sum(amt_req), sum(amt_eqv), sum(amt_pay), sum(amt_np), sum(script) as scripts, sum(days_sup) as days_sup, sum(generic) as generic,
       sum(script_gen) as script_gen
  from l2_ii_ocu_pop_phm_costs_ext a
  join L2_II_MAP_DATE_RANGE b on a.year_mth_id=b.year_mth_id
  join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
 group by a.year_mth_id,a.NEW_MEM_ATTR_ID, b.ia_time, c.pcp_assign, c.contract_id, c.product_id, c.sex, c.age_cat2,
       c.cat_status_cost3, c.mem_userdef_1_id, c.zip, a.year_mth_pd, a.network_paid_status_id, a.provider_status_id,
       a.tos_i_5, a.formulary, a.gbo, a.channel,a.ndc,a.pres_prv_i"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(
    OutputColumn("year_mth_id",None,None),
    OutputColumn("NEW_MEM_ATTR_ID",None,None),
    OutputColumn("ia_time",None,None),
    OutputColumn("pcp_assign",None,None),
    OutputColumn("contract_id",None,None),
    OutputColumn("product_id",None,None),
    OutputColumn("sex",None,None),
    OutputColumn("age_cat2",None,None),
    OutputColumn("cat_status_cost3",None,None),
    OutputColumn("mem_userdef_1_id",None,None),
    OutputColumn("at_risk_status_id",None,None),
    OutputColumn("zip",None,None),
    OutputColumn("year_mth_pd",None,None),
    OutputColumn("network_paid_status_id",None,None),
    OutputColumn("provider_status_id",None,None),
    OutputColumn("tos_i_5",None,None),
    OutputColumn("formulary",None,None),
    OutputColumn("gbo",None,None),
    OutputColumn("channel",None,None),
    OutputColumn("ndc",None,None),
    OutputColumn("presc_prov",None,None),
    OutputColumn("amt_req",None,None),
    OutputColumn("amt_eqv",None,None),
    OutputColumn("amt_pay",None,None),
    OutputColumn("amt_np",None,None),
    OutputColumn("scripts",None,None),
    OutputColumn("days_sup",None,None),
    OutputColumn("generic",None,None),
    OutputColumn("script_gen",None,None)))

  def directoryLevel: String = "L3"





  val originalSqlFileName: String = "L3_II_ocu_build.sql"
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_rxorder, rxorder}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_RXORDER extends TableInfo[l1_rxorder]{
  override def dependsOn: Set[String] = Set("RXORDER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_RXORDER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val rxorder = loadedDependencies("RXORDER").as[rxorder]

    rxorder
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"facilityid",
			$"rxid",
			$"encounterid",
			$"patientid",
			$"localmedcode",
			$"localdescription",
			$"localproviderid",
			$"issuedate".as("issue_dtm"),
			$"discontinuedate".as("discontinue_dt"),
			$"localstrengthperdoseunit",
			$"localstrengthunit",
			$"localroute",
			$"expiredate".as("expire_dt"),
			$"quantityperfill",
			$"fillnum",
			$"signature",
			$"ordertype",
			$"orderstatus",
			$"altmedcode",
			$"mappedndc",
			$"mappedgpi",
			$"mappedndc_conf",
			$"mappedgpi_conf",
			$"venue",
			$"map_used",
			$"hum_med_key",
			$"localdaysupplied",
			$"localform",
			$"localqtyofdoseunit",
			$"localtotaldose",
			$"localdosefreq",
			$"localduration",
			$"localinfusionrate",
			$"localinfusionvolume",
			$"localinfusionduration",
			$"localndc",
			$"ndc11",
			$"localgpi",
			$"localdoseunit",
			$"localdischargemedflg",
			$"localdescription_phi",
			$"localdaw",
			$"ordervsprescription",
			$"hum_gen_med_key",
			$"hts_generic",
			$"hts_generic_ext",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"localgenericdesc",
			$"mstrprovid",
			$"discontinuereason",
			$"allowedamount",
			$"paidamount",
			$"charge",
			$"dcc",
			$"rxnorm_code",
			$"active_med_flag",
			$"contract_id",
			$"network_paid_status",
			$"generic_status",
			$"formulary_indicator",
			$"copay_amt",
			$"coinsurance_amt",
			$"deductable_amt",
			$"pat_liability_amt",
			$"denied_flag",
			$"pseudo_flag"
    )
  }
}


package com.optum.oadw.etl.L2

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_PAT_INSURANCE_LAST extends TableInfo[l2_pat_insurance_last] {

  override def name: String = "L2_PAT_INSURANCE_LAST"

  override def dependsOn: Set[String] = Set("L2_PAT_INSURANCE")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2PatInsurance = loadedDependencies("L2_PAT_INSURANCE").where($"primary_ind" === lit(1) && $"last_ind" === lit(1)).as[l2_pat_insurance]

    l2PatInsurance
      .select($"client_id", $"mpi", $"cds_grp", $"payer_cui", $"lob_cui", $"yr_month", $"primary_ind", $"no_enc_ind", $"plancode", $"planname")
  }
}


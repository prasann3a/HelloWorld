package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_pat_insurance
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_PAT_INSURANCE extends QueryAndMetadata[l2_pat_insurance] {
  override def name: String = "L2_PAT_INSURANCE"

  override def sparkSql: String = """
select client_id, mpi, lob_cui, payer_cui, yr_month, plancode, planname,
       case when insurance_order is not null then insurance_order else 0 end as insurance_order, cds_grp, last_ind, no_enc_ind,
       case when insurance_order = 1 then 1 else 0 end as primary_ind
 from (
        SELECT client_id, mpi, lob_cui, payer_cui, cast(yr_month as int) as yr_month, plancode, planname,
        cast(least(row_number() over (partition by client_id,mpi,yr_month ORDER BY insurance_order),9) as int) as insurance_order,
        cds_grp, cast(last_ind as int) as last_ind, cast(no_enc_ind as int) as no_enc_ind
        FROM (
               SELECT client_id, mpi, lob_cui, payer_cui, yr_month, cds_grp,
               MIN(insurance_order) AS insurance_order,
               CASE WHEN yr_month = MAX(yr_month) OVER (PARTITION BY client_id, mpi) THEN 1 ELSE 0 END AS last_ind,
               MIN(no_enc_ind) AS no_enc_ind,
               first(planname_sel) as planname,
               first(plancode_sel) as plancode
               FROM (
                      SELECT /*+ BROADCAST(temp_all_mm_timebuckets) */ i.client_id, mpi, lob_cui, payer_cui, yr_month, no_enc_ind, i.plancode, i.planname,
                      DENSE_RANK() OVER (PARTITION BY i.client_id, mpi, yr_month
                        ORDER BY i.source_type_flg, i.contract_hier, i.encounterid_ind, i.insuranceorder NULLS LAST, i.enrollend_dt DESC NULLS LAST,
                                 i.enrollstart_dt DESC NULLS LAST, i.payer_cnt DESC, i.lob_cui, i.payer_cui) insurance_order,
                      first(planname) over (partition by i.client_id,mpi,lob_cui, payer_cui, yr_month
                        ORDER BY i.insuranceorder nulls last, i.source_type_flg nulls last, i.planname desc, i.plancode desc nulls last) planname_sel,
                      first(plancode) over (partition by i.client_id,mpi,lob_cui, payer_cui, yr_month
                        ORDER BY i.insuranceorder nulls last, i.source_type_flg nulls last, i.planname desc, i.plancode desc nulls last) plancode_sel,
                      listagg(cds.client_ds_id) over (PARTITION BY i.client_id, mpi, yr_month, lob_cui, payer_cui)  cds_grp
                      FROM temp_pat_insurance i
                      INNER JOIN L2_map_cds_flg cds on (i.client_id = cds.client_id AND i.client_ds_id = cds.client_ds_id)
                      INNER JOIN temp_all_mm_timebuckets c ON (c.month_dt BETWEEN i.startdate AND i.enddate )
                    ) cds
               GROUP BY client_id, mpi, lob_cui, payer_cui, yr_month, cds_grp
             ) q
      ) xyz """

  override def dependsOn: Set[String] = Set("L2_MAP_CDS_FLG","TEMP_ALL_MM_TIMEBUCKETS", "TEMP_PAT_INSURANCE")

  def originalSql: String = """
INSERT /*+ APPEND */ INTO L2_pat_insurance(client_id,mpi,lob_cui,payer_cui,yr_month
                     ,insurance_order,last_ind,no_enc_ind)
SELECT /*+ PARALLEL(4) */
        client_id,mpi,lob_cui,payer_cui,yr_month,
        least(row_number() over (partition by client_id,mpi,yr_month ORDER BY insurance_order),9),
        last_ind, no_enc_ind
  FROM (
SELECT client_id, mpi
       ,lob_cui, payer_cui
       ,yr_month
       ,MIN(insurance_order) AS insurance_order
       ,CASE WHEN yr_month = MAX(yr_month) OVER (PARTITION BY client_id, mpi) THEN 1 ELSE 0 END AS last_ind
       ,MIN(no_enc_ind) AS no_enc_ind
FROM
(
        SELECT i.client_id, mpi, lob_cui, payer_cui, yr_month, no_enc_ind,
               DENSE_RANK() OVER (PARTITION BY i.client_id, mpi, yr_month
                              ORDER BY i.source_type_flg, i.contract_hier, i.encounterid_ind, i.insuranceorder NULLS LAST, i.enrollend_dt DESC NULLS LAST,
                                       i.enrollstart_dt DESC NULLS LAST,
                                       i.payer_cnt DESC, i.lob_cui, i.payer_cui) insurance_order
        FROM temp_pat_insurance i
        INNER JOIN L2_map_cds_flg cds on (i.client_id = cds.client_id AND i.client_ds_id = cds.client_ds_id)
        INNER JOIN temp_all_mm_timebuckets c ON (c.month_dt BETWEEN i.startdate AND i.enddate)
) cds
GROUP BY client_id, mpi, lob_cui, payer_cui, yr_month
) q
"""

  def directoryLevel: String = "L2"
}

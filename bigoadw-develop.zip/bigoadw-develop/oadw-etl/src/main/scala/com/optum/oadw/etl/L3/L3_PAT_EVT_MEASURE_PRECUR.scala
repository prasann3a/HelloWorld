package com.optum.oadw.etl.L3

import com.optum.oadw.oadwModels.{l3_pat_evt_measure_precur, l4_timeframe}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{broadcast, lit}
import org.apache.spark.sql.types.IntegerType

/**
  * Algorithm specification -- https://wiki.humedica.net/display/Data/OADW+Concept+Specification+-+Measures
  */
object L3_PAT_EVT_MEASURE_PRECUR {
  def apply(xmlMeasureTempEtls: Seq[TableInfo[_ <: Product with Serializable]]): L3_PAT_EVT_MEASURE_PRECUR =
    new L3_PAT_EVT_MEASURE_PRECUR(xmlMeasureTempEtls)
}

class L3_PAT_EVT_MEASURE_PRECUR(xmlMeasureTempEtls: Seq[TableInfo[_ <: Product with Serializable]]) extends TableInfo[l3_pat_evt_measure_precur] {
  override def name: String = "L3_PAT_EVT_MEASURE_PRECUR"

  override def dependsOn: Set[String] = Set(
    "TEMP_L3_PAT_EVT_MEASURE_PRECUR_HEDIS",
    "TEMP_L3_PAT_EVT_MEASURE_PRECUR_EBM",
    "TEMP_L3_PAT_EVT_MEASURE_PRECUR_AHRQ",
    "L4_TIMEFRAME"
  ) ++ xmlMeasureTempEtls.map(_.name)

  def directoryLevel: String = "L3"

  override def partitions: Int = 256

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val rowsFromHedis = loadedDependencies("TEMP_L3_PAT_EVT_MEASURE_PRECUR_HEDIS")
    val rowsFromEBM   = loadedDependencies("TEMP_L3_PAT_EVT_MEASURE_PRECUR_EBM")
    val rowsFromAHRQ   = loadedDependencies("TEMP_L3_PAT_EVT_MEASURE_PRECUR_AHRQ")
    val tL4TimeFrame = broadcast(loadedDependencies("L4_TIMEFRAME").as[l4_timeframe])
    val dynamicMeasureSet = xmlMeasureTempEtls
      .map(etl => loadedDependencies(etl.name).as("d")
        .join(tL4TimeFrame.as("t"), $"d.timeframe_id" === $"t.timeframe_id", "left_outer")
        .filter($"t.timeframe_type".notEqual("12M"))
        .select($"d.*")
      )

    val columns = Seq(
      $"client_id",
      $"mpi",
      $"measure_id",
      $"precursor_id",
      $"event_set",
      $"timeframe_id",
      $"event_dt",
      $"event_seq",
      $"precursor_dt",
      $"precursor_domain",
      $"precursor_type",
      $"precursor_value",
      $"precursor_cds_grp",
      $"sensitive_ind",
      $"event_id"
    )

    val allMeasures = dynamicMeasureSet :+ rowsFromEBM :+ rowsFromHedis :+ rowsFromAHRQ

    allMeasures.reduce((last, cur) => last.select(columns: _*).union(cur.select(columns: _*)))
  }
}

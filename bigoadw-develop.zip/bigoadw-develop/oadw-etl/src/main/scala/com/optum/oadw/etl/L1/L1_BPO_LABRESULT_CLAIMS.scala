
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_bpo_labresult_claims, pp_bpo_labresult_claims}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_BPO_LABRESULT_CLAIMS extends TableInfo[l1_bpo_labresult_claims]{
  override def dependsOn: Set[String] = Set("PP_BPO_LABRESULT_CLAIMS")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_BPO_LABRESULT_CLAIMS"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("PP_BPO_LABRESULT_CLAIMS").as[pp_bpo_labresult_claims]

    cdrTbl
    .select(
		$"claimheader",
		$"groupid".as("client_id"),
		$"healthplansource",
		$"loinc",
		$"memberid".as("mpi"),
		$"servicedate".as("service_dt"),
		$"testresultnumber",
		$"testresulttext",
		$"testresultunits"
    )
  }
}


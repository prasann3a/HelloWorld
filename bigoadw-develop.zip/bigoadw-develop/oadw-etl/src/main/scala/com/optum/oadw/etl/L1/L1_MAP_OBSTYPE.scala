
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_obstype, zcm_obstype}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object L1_MAP_OBSTYPE extends TableInfo[l1_map_obstype]{
  override def dependsOn: Set[String] = Set("ZCM_OBSTYPE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_OBSTYPE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zcmObstype = loadedDependencies("ZCM_OBSTYPE").as[zcm_obstype]

    zcmObstype
    .select(
			$"obstype",
			$"obstype_cui",
			$"obstype_std_units",
			$"datatype",
			$"begin_range",
			$"end_range",
			$"round_prec",
			$"foam_restriction",
			$"dts_version",
			coalesce($"validated_ind",lit(0)).as("validated_ind"),
			$"sensitive_ind"
    )
  }
}



/**
  * auto-generated code
*/
package com.optum.oadw.etl.L3


import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_patient_info, l4_timeframe}
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

case class temp_pat_time_cross_s1_data(dob: java.sql.Timestamp, dod: java.sql.Timestamp, start_dt: java.sql.Timestamp,
                                       end_dt: java.sql.Timestamp, timeframe_id: java.lang.Integer, start_age: java.lang.Integer,
                                       end_age: java.lang.Integer, born_during_ind: java.lang.Integer, died_during_ind: java.lang.Integer)

object TEMP_PAT_TIME_CROSS_S1 extends TableInfo[temp_pat_time_cross_s1_data] {
  override def name: String = "TEMP_PAT_TIME_CROSS_S1"

  override def dependsOn: Set[String] = Set("L2_PATIENT_INFO", "L4_TIMEFRAME")

  def directoryLevel: String = "L3"





  val originalSqlFileName: String = "L3_pat_timeframe_age_build.sql"

  /*
  def originalSql: String = """CREATE TABLE TEMP_PAT_TIME_CROSS_S1 PCTFREE 0 NOLOGGING AS
WITH  Temp_distinct_dt as (
SELECT /*+ PARALLEL(4) */ DISTINCT
     p.dob
    , p.dod
FROM L2_patient_info p )
SELECT
     p.dob
    , p.dod
    , t.start_dt
    , t.end_dt
    , t.timeframe_id
    , age_as_of(p.dob, t.start_dt) AS start_age
    , age_as_of(p.dob, t.end_dt) AS end_age
    , CASE WHEN p.dob >= t.start_dt THEN 1 ELSE 0 END AS born_during_ind
    , CASE WHEN p.dod <= t.end_dt  THEN 1 ELSE 0 END AS died_during_ind
FROM Temp_distinct_dt p
CROSS JOIN L4_Timeframe t
WHERE (p.dob <= t.END_DT AND (p.dod >= t.START_DT or p.dod is NULL))"""
*/
  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    import org.apache.spark.sql.functions._

    val patientInfo = loadedDependencies("L2_PATIENT_INFO").as[l2_patient_info]
    val timeframe = loadedDependencies("L4_TIMEFRAME").as[l4_timeframe]

    val distinctPatients = patientInfo.select($"dob", $"dod").distinct()
    val result = distinctPatients.as("p")
      .crossJoin(timeframe.as("t"))
      .where($"p.dob" <= $"t.end_dt" && ($"p.dod" >= $"t.start_dt" || $"p.dod".isNull))
      .select(
        $"p.dob",
        $"p.dod",
        $"t.start_dt",
        $"t.end_dt",
        $"t.timeframe_id",
        (floor(floor(months_between(to_date(date_format($"t.start_dt", "yyyy-MM-dd")), to_date(date_format($"p.dob", "yyyy-MM-dd")))) / 12)).cast(IntegerType).as("start_age"),
        (floor(floor(months_between(to_date(date_format($"t.end_dt", "yyyy-MM-dd")), to_date(date_format($"p.dob", "yyyy-MM-dd")))) / 12)).cast(IntegerType).as("end_age"),
        when($"p.dob" >= $"t.start_dt", lit(1)).otherwise(lit(0)).as("born_during_ind"),
        when($"p.dod" <= $"t.end_dt", lit(1)).otherwise(lit(0)).as("died_during_ind")
      )
    result
  }
}


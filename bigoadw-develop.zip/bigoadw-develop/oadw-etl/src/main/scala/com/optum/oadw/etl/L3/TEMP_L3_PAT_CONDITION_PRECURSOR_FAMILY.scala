package com.optum.oadw.etl.L3

import java.sql.Timestamp

import com.optum.oadw.etl.models.temp_l3_pat_condition_precursor
import com.optum.oadw.oadwModels.{ l3_pat_precursor, l4_timeframe, l3_dict_condition_rule, md_oadw_instance }
import com.optum.oadw.oadw_ref.models.l3_map_cond_precur_fam_rule
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{ DataFrame, SparkSession }

object TEMP_L3_PAT_CONDITION_PRECURSOR_FAMILY extends TableInfo[temp_l3_pat_condition_precursor] {

  override def name: String = "TEMP_L3_PAT_CONDITION_PRECURSOR_FAMILY"

  override def dependsOn: Set[String] = Set("L4_TIMEFRAME", "L3_PAT_PRECURSOR", "L3_DICT_CONDITION_RULE", "REFERENCE_SCHEMA_L3_MAP_COND_PRECUR_FAM_RULE", "MD_OADW_INSTANCE")

  override def createDataFrame(
    sparkSession: SparkSession,
    loadedDependencies: Map[String, DataFrame],
    udfMap: Map[String, UserDefinedFunctionForDataLoader],
    runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    //dependencies
    val tL3MapCondPrecurFamRule = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_COND_PRECUR_FAM_RULE").as[l3_map_cond_precur_fam_rule])
    val tL3PatPrecur            = loadedDependencies("L3_PAT_PRECURSOR").as[l3_pat_precursor]
    val tL4DictTimeframe        = broadcast(loadedDependencies("L4_TIMEFRAME").as[l4_timeframe])

    val familyTL3DictCondRule = broadcast(
      loadedDependencies("L3_DICT_CONDITION_RULE")
        .where($"precursor_family_cnt".isNotNull)
        .as[l3_dict_condition_rule])

    val allTimeFrameStartDtm = tL4DictTimeframe
      .where($"timeframe_type" === lit("ALL"))
      .select($"start_dt")
      .as[Timestamp]
      .head()

    val dataThruDtm = broadcast(
      loadedDependencies("MD_OADW_INSTANCE")
      .where($"attribute_name" === lit("DATA_THRU")))
      .select(date_add(to_date($"attribute_value", "yyyyMMdd"), 1).as("data_thru_dtm"))
      .as[Timestamp]
      .collect()
      .head

    //filter precursors by timeframe
    val filteredPrecursors = tL3PatPrecur
      .as("pp")
      .join(tL3MapCondPrecurFamRule.as("mpf"), $"pp.precursor_id" === $"mpf.precursor_id", "inner")
      .where( $"pp.precursor_dtm" < dataThruDtm
        and date_trunc("DD", $"pp.precursor_dtm") >= allTimeFrameStartDtm)
      .drop($"pp.precursor_id")

    //joining rules and precursors
    val precusorsMatchingConditionRules = filteredPrecursors
      .as("fp")
      .join(familyTL3DictCondRule.as("dc"), $"fp.condition_id" === $"dc.condition_id" and $"fp.rule_id" === $"dc.rule_id", "inner")
      .withColumn("sensitive_ind_final", greatest($"dc.sensitive_ind", $"fp.sensitive_ind"))
      .withColumn("sensitive_ind_precur", $"fp.sensitive_ind")
      .drop($"dc.condition_id")
      .drop($"dc.rule_id")
      .drop($"dc.sensitive_ind")
      .drop($"fp.sensitive_ind")
      .withColumnRenamed("sensitive_ind_final", "sensitive_ind")

    val precursorAndPossibleSupportingPrecursors = precusorsMatchingConditionRules
      .as("a1")
      .join(
        precusorsMatchingConditionRules.as("a2")
        , $"a1.client_id" === $"a2.client_id"
          and $"a1.mpi" === $"a2.mpi"
          and $"a1.condition_id" === $"a2.condition_id"
          and $"a1.rule_id" === $"a2.rule_id"
        , "inner"
      )
      .where(
        ($"a1.precursor_id" === $"a2.precursor_id" and $"a1.precursor_dtm" === $"a2.precursor_dtm")
        or ($"a1.precursor_family_cnt_max_days".isNotNull && datediff($"a1.precursor_dtm", $"a2.precursor_dtm").between($"a1.precursor_family_cnt_min_days", $"a1.precursor_family_cnt_max_days"))
          or ($"a1.precursor_family_cnt_max_days".isNull and $"a1.precursor_family_cnt_min_days" > 0 && datediff($"a1.precursor_dtm", $"a2.precursor_dtm") >= $"a1.precursor_family_cnt_min_days")
          or ($"a1.precursor_family_cnt_max_days".isNull and $"a1.precursor_family_cnt_min_days" === 0 )
      )

    val precursorsMatchingFamilyCriteria = getPrecursorsMatchingFamilyCriteria(precursorAndPossibleSupportingPrecursors, sparkSession)

    precursorsMatchingFamilyCriteria

  }

  private def getPrecursorsMatchingFamilyCriteria(precursorAndPossibleSupportingPrecursors: DataFrame, sparkSession: SparkSession): DataFrame = {

    import sparkSession.implicits._

    val qualifiedPrecursors = precursorAndPossibleSupportingPrecursors
      .groupBy(
        $"a1.client_id",
        $"a1.mpi",
        $"a1.condition_id",
        $"a1.rule_id",
        $"a1.precursor_id",
        $"a1.precursor_dtm"
      )
      .agg(
        countDistinct($"a2.precursor_id").as("count"),
        max($"a1.precursor_family_cnt").as("precursor_family_cnt")
      )
      .where($"count" >= $"precursor_family_cnt")

    precursorAndPossibleSupportingPrecursors
      .join(
        qualifiedPrecursors.as("a")
        , $"a1.client_id" === $"a.client_id"
          and $"a1.mpi" === $"a.mpi"
          and $"a1.condition_id" === $"a.condition_id"
          and $"a1.rule_id" === $"a.rule_id"
          and $"a1.precursor_id" === $"a.precursor_id"
          and $"a1.precursor_dtm" === $"a.precursor_dtm"
        , "inner"
      )
      .select(
        $"a2.client_id",
        $"a2.mpi",
        $"a2.precursor_cds_grp",
        $"a2.precursor_domain",
        $"a2.precursor_dtm",
        $"a2.precursor_id",
        $"a2.precursor_modifier_flg",
        $"a2.precursor_type",
        $"a2.precursor_value",
        $"a2.sensitive_ind",
        $"a2.condition_id",
        $"a2.rule_id",
        $"a2.sensitive_ind_precur"
      )
      .distinct()
  }

}

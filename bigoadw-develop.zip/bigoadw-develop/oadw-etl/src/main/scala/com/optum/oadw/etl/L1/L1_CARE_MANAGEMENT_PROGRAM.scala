
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_care_management_program, care_management_program}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_CARE_MANAGEMENT_PROGRAM extends TableInfo[l1_care_management_program]{
  override def dependsOn: Set[String] = Set("CARE_MANAGEMENT_PROGRAM")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CARE_MANAGEMENT_PROGRAM"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val careManagementProgram = loadedDependencies("CARE_MANAGEMENT_PROGRAM").as[care_management_program]

    careManagementProgram
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"prog_id",
			$"prog_name",
			$"prog_desc",
			$"prog_owner",
			$"prog_status",
			$"prog_status_st_date".as("prog_status_st_dt"),
			$"prog_status_end_date".as("prog_status_end_dt"),
			$"prog_status_reason",
			$"prog_duration"
    )
  }
}


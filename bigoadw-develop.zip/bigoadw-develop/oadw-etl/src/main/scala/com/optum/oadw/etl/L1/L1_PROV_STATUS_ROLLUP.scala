
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_status_rollup, prov_status_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_STATUS_ROLLUP extends TableInfo[l1_prov_status_rollup]{
  override def dependsOn: Set[String] = Set("PROV_STATUS_ROLLUP")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_STATUS_ROLLUP"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val provStatusRollup = loadedDependencies("PROV_STATUS_ROLLUP").as[prov_status_rollup]

    provStatusRollup
    .select(
			$"groupid".as("client_id"),
			$"prov_status_id",
			$"prov_status_desc",
			$"prov_status_lv2",
			$"prov_status_lv2_desc",
			$"prov_status_lv1",
			$"prov_status_lv1_desc",
			$"prov_status_rollup",
			$"client_ds_id",
			$"datasrc"
    )
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.common.models.OADWRuntimeVariables
import com.optum.oadw.oadwModels.{l1_sdoh_indices, md_oadw_instance}
import com.optum.oadw.utils._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{count, lit}
import org.apache.spark.sql.types.{IntegerType, TimestampType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.StringType

object L1_SDOH_INDICES extends TableInfo[l1_sdoh_indices]{

  override def name: String = "L1_SDOH_INDICES"

  override def dependsOn: Set[String] = Set("MD_OADW_INSTANCE")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    if (!FeatureManager.Instance.isEnable(Features.SDOH))
      return Seq.empty[l1_sdoh_indices].toDF

    val mdOadwInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]

    val fileName = mdOadwInstance
      .where($"attribute_name" === lit(MetaDataConstants.SDOH_FILE_ID))
      .collect()
      .headOption.getOrElse(throw new IllegalArgumentException(s"Missing attribute ${MetaDataConstants.SDOH_FILE_ID} in MD_OADW_INSATANCE"))
      .attribute_value

    val oadwRuntimeVariables = OADWRuntimeVariables(runtimeVariables)

    val basePath = oadwRuntimeVariables.protocol match {
      case "s3" => s"s3://${oadwRuntimeVariables.bucket.get}/${oadwRuntimeVariables.environment}/external/sdoh/landed"
      case "hdfs" => s"hdfs://somhorton1/optum/data_factory/${oadwRuntimeVariables.clientId}/${oadwRuntimeVariables.environment}/external/sdoh/landed"
      case "test" => s"${oadwRuntimeVariables.extras.get("filePath").head}"
      case _ => throw new IllegalArgumentException
    }

    val fullFilePath = s"${basePath}/${fileName}_CURRENT"

    val SDOHIndicesInput = sparkSession.read
      .format("csv")
      .option("delimiter", "|")
      .option("header", "true")
      .load(fullFilePath)
      .distinct()

    val columnNamesToCheck=List("SDOH_LANGUAGE", "SDOH_SOCIOECONOMIC_STATUS", "SDOH_EDUCATION_LEVEL")

    val columnsInSDOHIndices = SDOHIndicesInput.columns.toList

    val columnsNotInSDOHIndices = columnNamesToCheck diff columnsInSDOHIndices

    columnsNotInSDOHIndices.foldLeft(SDOHIndicesInput)((SDOHIndicesInput, x) => SDOHIndicesInput.withColumn(x , lit(null).cast(StringType))).
      select(
        $"MEM_ID".as("mpi"),
        $"MEM_FIRSTNAME".as("first_name"),
        $"MEM_LASTNAME".as("last_name"),
        $"MEM_DOB".cast(TimestampType).as("dob"),
        $"MEM_GENDER".as("gender"),
        $"MEM_ADDR".as("address"),
        $"MEM_CITY".as("city"),
        $"MEM_STATE".as("state"),
        $"MEM_ZIP".as("zip"),
        $"SDOH_HEALTH_OWNERSHIP_SEGMENT".as("health_ownership_segment"),
        $"SDOH_SOCIAL_ISOLATION".cast(IntegerType).as("social_isolation"),
        $"SDOH_FOOD_INSECURITY".cast(IntegerType).as("food_insecurity"),
        $"SDOH_HOUSING_INSECURITY".cast(IntegerType).as("housing_insecurity"),
        $"SDOH_FINANCIAL_INSECURITY".cast(IntegerType).as("financial_insecurity"),
        $"SDOH_TRANSPORTATION_INSECURITY".cast(IntegerType).as("transportation_insecurity"),
        $"SDOH_SOCIAL_VULNERABILITY".cast(IntegerType).as("social_vulnerability"),
        $"SDOH_EDUCATION_LEVEL".as("education_level"),
        $"SDOH_LANGUAGE".as("language_cd"),
        $"SDOH_SOCIOECONOMIC_STATUS".cast(IntegerType).as("socioeconomic_status"),
        lit(oadwRuntimeVariables.clientId).as("client_id")
      ).toDF
      .withColumn("count", count("*").over(Window.partitionBy($"mpi")))
      .where($"count" === 1)
      .drop("count")
  }
}
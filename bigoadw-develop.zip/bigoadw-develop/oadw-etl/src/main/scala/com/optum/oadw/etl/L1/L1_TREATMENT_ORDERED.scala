
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_treatment_ordered, treatment_ordered}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_TREATMENT_ORDERED extends TableInfo[l1_treatment_ordered]{
  override def dependsOn: Set[String] = Set("TREATMENT_ORDERED")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_TREATMENT_ORDERED"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val treatmentOrdered = loadedDependencies("TREATMENT_ORDERED").as[treatment_ordered]

    treatmentOrdered
    .select(
			$"groupid".as("client_id"),
			$"datasrc",
			$"client_ds_id",
			$"encounterid",
			$"patientid",
			$"order_id",
			$"order_date".as("order_dtm"),
			$"localcode",
			$"cui",
			$"ordered_quantity",
			$"local_unit",
			$"std_unit_cui",
			$"normalized_quantity",
			$"order_prov_id",
			$"master_hgprovid",
			$"hgpid",
			$"grp_mpi".as("mpi")
    )
  }
}


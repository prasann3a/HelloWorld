
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_employer, zo_bpo_map_employer}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_EMPLOYER extends TableInfo[l1_map_employer]{
  override def dependsOn: Set[String] = Set("ZO_BPO_MAP_EMPLOYER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_EMPLOYER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zoBpoMapEmployer = loadedDependencies("ZO_BPO_MAP_EMPLOYER").as[zo_bpo_map_employer]

    zoBpoMapEmployer
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"employeraccountid",
			$"employeraccountiddescription",
			$"midemployeraccount",
			$"midemployeraccountdescription",
			$"highemployeraccount",
			$"highemployeraccountdescription",
			$"bussegment",
			$"industry",
			$"mapsource",
			$"dts_version"
    )
  }
}


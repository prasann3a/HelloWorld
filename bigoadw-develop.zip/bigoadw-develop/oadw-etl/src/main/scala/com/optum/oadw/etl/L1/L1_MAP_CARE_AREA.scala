
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_care_area, map_care_area}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_CARE_AREA extends TableInfo[l1_map_care_area]{
  override def dependsOn: Set[String] = Set("MAP_CARE_AREA")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_CARE_AREA"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val mapCareArea = loadedDependencies("MAP_CARE_AREA").as[map_care_area]

    mapCareArea
    .select(
			$"groupid".as("client_id"),
			$"local_code",
			$"cui",
			$"dts_version"
    )
  }
}


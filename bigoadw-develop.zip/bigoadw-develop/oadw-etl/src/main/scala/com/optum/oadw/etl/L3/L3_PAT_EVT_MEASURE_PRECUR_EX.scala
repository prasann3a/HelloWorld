package com.optum.oadw.etl.L3

import com.optum.oadw.oadwModels.{l4_timeframe, l3_pat_evt_measure_precur_ex, l4_dict_measure}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.broadcast

/**
  * Algorithm specification -- https://wiki.advisory.com/display/DATAPIPE/OADW+Concept+Specification+-+Measure+Trending
  */
object L3_PAT_EVT_MEASURE_PRECUR_EX {
  def apply(xmlMeasureTempEtls: Seq[TableInfo[_ <: Product with Serializable]]): L3_PAT_EVT_MEASURE_PRECUR_EX = {
    new L3_PAT_EVT_MEASURE_PRECUR_EX(xmlMeasureTempEtls)
  }
}

class L3_PAT_EVT_MEASURE_PRECUR_EX(xmlMeasureTempEtls: Seq[TableInfo[_ <: Product with Serializable]]) extends TableInfo[l3_pat_evt_measure_precur_ex] {
  override def name: String = "L3_PAT_EVT_MEASURE_PRECUR_EX"

  override def dependsOn: Set[String] =
    if(xmlMeasureTempEtls.isEmpty)
      Set.empty
    else
      Set("L4_TIMEFRAME", "L4_DICT_MEASURE") ++ xmlMeasureTempEtls.map(_.name)

  def directoryLevel: String = "L3"

  override def partitions: Int = 256

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    if(xmlMeasureTempEtls.isEmpty)
      Seq.empty[l3_pat_evt_measure_precur_ex].toDF
    else {
      val tL4TimeFrame = broadcast(loadedDependencies("L4_TIMEFRAME").as[l4_timeframe])
      val l4DictMeasure = broadcast(loadedDependencies("L4_DICT_MEASURE")).as[l4_dict_measure]
      val dynamicMeasureSet = xmlMeasureTempEtls
        .map(etl => loadedDependencies(etl.name).as("m")
          .join(l4DictMeasure.as("dict"), $"dict.measure_id" === $"m.measure_id" && $"dict.trend_ind" === 1)
          .join(tL4TimeFrame.as("t"), $"m.timeframe_id" === $"t.timeframe_id", "left_outer")
          .filter($"t.timeframe_type" === "EOD" || $"t.timeframe_type" === "12M")
          .select($"m.*")
        )

      val columns = Seq(
        $"client_id",
        $"mpi",
        $"measure_id",
        $"precursor_id",
        $"event_set",
        $"timeframe_id",
        $"event_dt",
        $"event_seq",
        $"precursor_dt",
        $"precursor_domain",
        $"precursor_type",
        $"precursor_value",
        $"precursor_cds_grp",
        $"sensitive_ind",
        $"event_id"
      )

      dynamicMeasureSet.reduce((last, cur) => last.select(columns: _*).union(cur.select(columns: _*)))
    }
  }
}
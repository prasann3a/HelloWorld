
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_treatment_administered, treatment_administered}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_TREATMENT_ADMINISTERED extends TableInfo[l1_treatment_administered]{
  override def dependsOn: Set[String] = Set("TREATMENT_ADMINISTERED")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_TREATMENT_ADMINISTERED"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("TREATMENT_ADMINISTERED").as[treatment_administered]

    cdrTbl
    .select(
		$"groupid".as("client_id"),
		$"datasrc",
		$"client_ds_id",
		$"encounterid",
		$"patientid",
		$"order_id",
		$"administered_id",
		$"administered_date".as("administered_dtm"),
		$"localcode",
		$"cui",
		$"administered_quantity",
		$"local_unit",
		$"std_unit_cui",
		$"normalized_quantity",
		$"administered_prov_id",
		$"master_hgprovid",
		$"hgpid",
		$"grp_mpi".as("mpi")
    )
  }
}


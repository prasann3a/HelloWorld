
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_attribute, zh_prov_attribute}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_ATTRIBUTE extends TableInfo[l1_prov_attribute]{
  override def dependsOn: Set[String] = Set("ZH_PROV_ATTRIBUTE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_ATTRIBUTE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhProvAttribute = loadedDependencies("ZH_PROV_ATTRIBUTE").as[zh_prov_attribute]

    zhProvAttribute
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"localproviderid",
			$"master_hgprovid",
			$"attribute_type_cui",
			$"attribute_value",
			$"eff_date".as("eff_dt"),
			$"end_date".as("end_dt")
    )
  }
}


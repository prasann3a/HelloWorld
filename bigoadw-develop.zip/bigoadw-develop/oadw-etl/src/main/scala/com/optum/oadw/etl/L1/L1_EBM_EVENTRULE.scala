
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ebm_eventrule, ebm_eventrule}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_EBM_EVENTRULE extends TableInfo[l1_ebm_eventrule]{
  override def dependsOn: Set[String] = Set("EBM_EVENTRULE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_EBM_EVENTRULE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ebmEventrule = loadedDependencies("EBM_EVENTRULE").as[ebm_eventrule]

    ebmEventrule
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi",
			$"report_case_id",
			$"event",
			$"report_rule_id",
			$"status_flg",
			$"file_processing_month"
    )
  }
}


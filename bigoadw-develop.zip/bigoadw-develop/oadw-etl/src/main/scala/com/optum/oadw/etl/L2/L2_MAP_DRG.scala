package com.optum.oadw.etl.L2
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadw_ref.models.l2_map_sensitive_category
import com.optum.oadw.oadwModels._
import com.optum.oadw.utils.DataframeExtensions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object L2_MAP_DRG extends TableInfo[l2_map_drg] {

  override def name: String = "L2_MAP_DRG"

  override def dependsOn: Set[String] = Set("L2_MAP_DRG_ENCOUNTER_GRP", "L2_II_CONFINEMENTS", "L2_II_MAP_DRG")

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_map_drg_build.sql"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIConfinements = loadedDependencies("L2_II_CONFINEMENTS").as[l2_ii_confinements].alias("l2IIConfinements")
    val tl2IIMapDrg = loadedDependencies("L2_II_MAP_DRG").as[l2_ii_map_drg].alias("tl2IIMapDrg")
    val encounterGrpBasedDrg = loadedDependencies("L2_MAP_DRG_ENCOUNTER_GRP").as[l2_map_drg].as("tempMapDrg")
    val finalDrg = getIIConfinementBasedDrg(sparkSession, l2IIConfinements, tl2IIMapDrg, encounterGrpBasedDrg)
    val result = encounterGrpBasedDrg.union(finalDrg).distinct()

    val finalResult = result.select(
      $"drg_alos",
      $"drg_cd",
      $"drg_description",
      $"drg_gelos",
      $"drg_id",
      $"drg_type_cui",
      $"drg_weight",
      $"sensitive_cat_id",
      $"sensitive_ind"
    )

    finalResult
  }

  private def getIIConfinementBasedDrg(session: SparkSession,
                                       l2IIConfinements: Dataset[l2_ii_confinements],
                                       tl2IIMapDrg: Dataset[l2_ii_map_drg],
                                       tempMapDrg: Dataset[l2_map_drg]): Dataset[l2_map_drg] = {
    import org.apache.spark.sql.functions._
    import session.implicits._

    val maxDrgId = tempMapDrg.select(max($"drg_id").as("max_drg_id"))

    val data = l2IIConfinements
      .join(tl2IIMapDrg, $"l2IIConfinements.drg_id" === $"tl2IIMapDrg.drg_id")
      .join(tempMapDrg, $"tl2IIMapDrg.drg_code" === $"tempMapDrg.drg_cd", "left_outer")
      .select(
        $"tl2IIMapDrg.drg_code".as("drg_cd"),
        lit("CH999990").as("drg_type_cui"),
        concat(lit("DRG "), $"tl2IIMapDrg.drg_code", lit(": Not Supported")).as("drg_description"),
        lit(1).as("sensitive_ind"))
      .where($"tl2IIMapDrg.drg_version" === lit("MS") && $"tl2IIMapDrg.drg_code".isNotNull && $"tempMapDrg.drg_id".isNull && $"tl2IIMapDrg.drg_code" =!= lit("Unsp"))
      .distinct()

    val crossedData = data.crossJoin(maxDrgId).alias("crossedData")
    val window = Window.orderBy("drg_cd")
    val result = crossedData
      .withColumn("drg_row_id", row_number().over(window) + $"max_drg_id")
      .select(
        lit(0).as("drg_alos"),
        $"drg_cd",
        $"drg_description",
        lit(0).as("drg_gelos"),
        $"drg_row_id".as("drg_id"),
        $"drg_type_cui",
        lit(0).as("drg_weight"),
        lit(2).as("sensitive_cat_id"),
        $"sensitive_ind").as[l2_map_drg]
    result
  }
}

object L2_MAP_DRG_SEED extends TableInfo[l2_map_drg] {
  override def name: String = "L2_MAP_DRG_SEED"

  override def dependsOn: Set[String] = Set("L1_REF_VW_REF_DRG_REFERENCE", "L1_REF_SENSITIVE_DRG", "L2_MAP_SENSITIVE_CATEGORY")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1RefVWRefDrgReference = loadedDependencies("L1_REF_VW_REF_DRG_REFERENCE").castToBigDecimal(Set("alos", "gelos", "weight")).as[l1_ref_vw_ref_drg_reference].alias("l1RefVWRefDrgReference")
    val l1RefSensitiveDrg = loadedDependencies("L1_REF_SENSITIVE_DRG").as[l1_ref_sensitive_drg].alias("l1RefSensitiveDrg")
    val tL2MapSensitiveCategory = loadedDependencies("L2_MAP_SENSITIVE_CATEGORY").as[l2_map_sensitive_category].alias("tL2MapSensitiveCategory")

    val seedDf = getSeedData(sparkSession)
    val initialDataSet = getDrgRefData(sparkSession, l1RefVWRefDrgReference, l1RefSensitiveDrg, tL2MapSensitiveCategory)
    val seedInitialUnion = seedDf.union(initialDataSet).distinct().alias("seedInitialUnion")
    seedInitialUnion.toDF()
  }

  private def getSeedData(implicit session: SparkSession): Dataset[l2_map_drg] = {
    import session.implicits._
    dataframe(
      l2_map_drg(drg_id = 0, drg_type_cui = "CH001334", drg_cd = " ", drg_description = " ", drg_weight = 0.0, drg_gelos = 0.0, drg_alos = 0.0, sensitive_ind = 0, sensitive_cat_id = 1)
    ).as[l2_map_drg]
  }

  private def getDrgRefData(session: SparkSession,
                            l1RefVWRefDrgReference: Dataset[l1_ref_vw_ref_drg_reference],
                            l1RefSensitiveDrg: Dataset[l1_ref_sensitive_drg],
                            tL2MapSensitiveCategory: Dataset[l2_map_sensitive_category]): Dataset[l2_map_drg] = {
    import org.apache.spark.sql.functions._
    import session.implicits._

    val data = l1RefVWRefDrgReference
      .join(l1RefSensitiveDrg, $"l1RefVWRefDrgReference.drg" === $"l1RefSensitiveDrg.drg", "left_outer")
      .join(tL2MapSensitiveCategory, expr("UPPER(l1RefVWRefDrgReference.drg_description) LIKE CONCAT('%', UPPER(tL2MapSensitiveCategory.sensitive_text), '%') AND l1RefSensitiveDrg.drg IS NOT NULL"), "left")
      .select(
        $"l1RefVWRefDrgReference.drg".as("drg_cd"),
        $"l1RefVWRefDrgReference.drg_type_cui",
        $"l1RefVWRefDrgReference.drg_description",
        $"weight".as("drg_weight"),
        $"gelos".as("drg_gelos"),
        $"alos".as("drg_alos"),
        expr("nvl2(l1RefSensitiveDrg.drg, 1, 0)").as("sensitive_ind"),
        first($"tL2MapSensitiveCategory.sensitive_cat_id", true).over(Window.partitionBy($"l1RefVWRefDrgReference.drg").orderBy($"tL2MapSensitiveCategory.sensitive_hierarchy")).as("sensitive_cat_id"))
      .where($"l1RefVWRefDrgReference.drg_type_cui" === lit("CH001334"))
      .orderBy($"drg_cd")
      .distinct()

    val window = Window.orderBy("drg_cd")
    val dataset = data
      .withColumn("drg_id", row_number().over(window) + 1000)
      .select(
        $"drg_alos",
        $"drg_cd",
        $"drg_description",
        $"drg_gelos",
        $"drg_id",
        $"drg_type_cui",
        $"drg_weight",
        when($"sensitive_ind" === lit(1), expr("nvl(sensitive_cat_id, 999)")).otherwise(lit(1)).as("sensitive_cat_id"),
        $"sensitive_ind").as[l2_map_drg]
    dataset
  }
}

object L2_MAP_DRG_ENCOUNTER_GRP extends TableInfo[l2_map_drg] {
  override def name: String = "L2_MAP_DRG_ENCOUNTER_GRP"

  override def dependsOn: Set[String] = Set("L2_MAP_DRG_SEED", "L1_ENCOUNTER_GRP_FACILITY")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1EncounterGrp = loadedDependencies("L1_ENCOUNTER_GRP_FACILITY").castToLong(Set("admittingphys_mstr_id", "admittingphys_ds_id", "lastattphys_ds_id", "lastattphys_mstr_id")).as[l1_encounter_grp_facility].alias("l1EncounterGrp")
    val seedInitialUnion = loadedDependencies("L2_MAP_DRG_SEED").as[l2_map_drg].alias("seedInitialUnion")
    val encounterGrpBasedDrg = getEncounterGrpDrg(sparkSession, l1EncounterGrp, seedInitialUnion)
    val encounterUnionSeed = seedInitialUnion.union(encounterGrpBasedDrg).distinct()
    encounterUnionSeed.toDF()
  }

  private def getEncounterGrpDrg(session: SparkSession,
                                 l1EncounterGrp: Dataset[l1_encounter_grp_facility],
                                 seedInitialUnion: Dataset[l2_map_drg]): Dataset[l2_map_drg] = {
    import org.apache.spark.sql.functions._
    import session.implicits._

    val maxDrgId = seedInitialUnion.select(max($"drg_id").as("max_drg_id"))

    val data = l1EncounterGrp
      .join(seedInitialUnion, $"l1EncounterGrp.drg" === $"seedInitialUnion.drg_cd" && $"l1EncounterGrp.drgtypecui" === $"seedInitialUnion.drg_type_cui", "left_outer")
      .select(
        $"l1EncounterGrp.drg".as("drg_cd"),
        expr("nvl(l1EncounterGrp.drgtypecui, 'CH999990')").as("drg_type_cui"),
        concat(lit("DRG "), $"l1EncounterGrp.drg", lit(": Not Supported")).as("drg_description"),
        lit(1).as("sensitive_ind"))
      .where($"l1EncounterGrp.drg".isNotNull && $"seedInitialUnion.drg_id".isNull)
      .distinct().alias("data")

    val crossedData = data.crossJoin(maxDrgId).alias("crossedData")
    val window = Window.orderBy("drg_cd")
    val result = crossedData
      .withColumn("drg_row_id", row_number().over(window) + $"max_drg_id")
      .select(
        lit(0).as("drg_alos"),
        $"drg_cd",
        $"drg_description",
        lit(0).as("drg_gelos"),
        $"drg_row_id".as("drg_id"),
        $"drg_type_cui",
        lit(0).as("drg_weight"),
        lit(2).as("sensitive_cat_id"),
        $"sensitive_ind").as[l2_map_drg]
    result
  }
}

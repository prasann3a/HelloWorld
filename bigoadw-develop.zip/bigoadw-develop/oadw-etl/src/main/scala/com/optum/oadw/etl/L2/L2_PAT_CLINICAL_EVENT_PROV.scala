package com.optum.oadw.etl.L2

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import com.optum.oadw.definedfunctions.{BitOrAgg, ListAgg}
import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{TableInfo, RuntimeVariables}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

/**
  * SELECT  ep.CLIENT_ID
  * , cee.encounter_grp_num AS CLINICAL_EVENT_ID
  * , ep.mstrprovid AS prov_id
  * , NVL(pr.cui,'CH999999') AS prov_role_cui
  * , ep.encounter_dtm as prov_role_dtm
  * FROM L1_ENCOUNTERPROVIDER ep
  * INNER JOIN L1_CLINICAL_EVENT_ENCOUNTER cee ON (ep.client_id = cee.client_id and ep.client_ds_id = cee.client_ds_id and ep.encounterid = cee.encounterid)
  * INNER JOIN L2_map_cds_flg mcf ON (ep.client_id = mcf.client_id AND ep.client_ds_id = mcf.client_ds_id)
  * LEFT OUTER JOIN L1_map_provider_role pr ON (ep.CLIENT_ID = pr.client_id and ep.providerrole = pr.local_code)
  * WHERE ep.mstrprovid IS NOT NULL
  * GROUP BY ep.CLIENT_ID,cee.encounter_grp_num
  * , ep.mstrprovid
  * , NVL(pr.cui,'CH999999')
  * , ep.encounter_dtm;
  */

object L2_PAT_CLINICAL_EVENT_PROV extends TableInfo[l2_pat_clinical_event_prov] {
  override def name: String = "L2_PAT_CLINICAL_EVENT_PROV"

  override def dependsOn: Set[String] = Set("L1_ENCOUNTERPROVIDER", "L1_CLINICAL_EVENT_ENCOUNTER", "L2_MAP_CDS_FLG", "L1_MAP_PROVIDER_ROLE")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1EncounterProvider = loadedDependencies("L1_ENCOUNTERPROVIDER").as[l1_encounterprovider]
    val l1ClinicalEventEncounter = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").as[l1_clinical_event_encounter]
    val l2MapCdsFlg = broadcast(loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg])
    val l1MapProviderRole = broadcast(loadedDependencies("L1_MAP_PROVIDER_ROLE").as[l1_map_provider_role])

    val listAgg = new ListAgg()

    l1EncounterProvider.as("ep").where($"ep.mstrprovid".isNotNull)
      .join(l1ClinicalEventEncounter.as("cee"), $"ep.client_id" === $"cee.client_id" && $"ep.client_ds_id" === $"cee.client_ds_id" && $"ep.encounterid" === $"cee.encounterid", "inner")
      .join(l2MapCdsFlg.as("mcf"), $"ep.client_id" === $"mcf.client_id" && $"ep.client_ds_id" === $"mcf.client_ds_id", "inner")
      .join(l1MapProviderRole.as("pr"), $"ep.client_id" === $"pr.client_id" && $"ep.providerrole" === $"pr.local_code", "leftouter")
      .groupBy($"ep.client_id",
        $"cee.encounter_grp_num".as("clinical_event_id"),
        $"ep.mstrprovid".as("prov_id"),
        expr("nvl(pr.cui, 'CH999999')").as("prov_role_cui"),
        $"ep.encounter_dtm".as("prov_role_dtm")
      ).agg(
        listAgg($"mcf.client_ds_id").as("cds_grp")
      )
  }
}

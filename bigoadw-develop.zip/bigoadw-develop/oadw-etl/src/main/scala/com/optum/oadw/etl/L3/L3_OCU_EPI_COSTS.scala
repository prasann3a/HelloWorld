package com.optum.oadw.etl.L3

import com.optum.oadw.oadwModels.l3_ocu_epi_costs
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L3_OCU_EPI_COSTS extends QueryAndMetadata[l3_ocu_epi_costs] {
  override def name: String = "L3_OCU_EPI_COSTS"

  override def sparkSql: String = """select a.NEW_MEM_ATTR_ID,a.year_mth_id, a.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2, a.network_paid_status_id,
a.provider_status_id, a.provider_id, a.prv_sp_4, a.tos_i_5, a.pos_i, a.etg_id, a.etg_resp_prov, A.SEV_LEVEL, a.tx_ind,
a.outlier, a.complete, c.contract_id, sum(AMT_EQV) as AMT_EQV, sum(AMT_PAY) as AMT_PAY, sum(AMT_NP) as AMT_NP, cast(sum(encounter) as decimal(38,10)) as enc,
cast(sum(admit) as int) as admits, cast(sum(los) as int) as los, cast(sum(script) as int) as scripts, sum(rad_util) as rad_util, sum(lab_util) as lab_util,
sum(er_util) as   er_util, sum(mri_util) as mri_util, cast(sum(em_svc_flag) as decimal(38,10)) as em_svc_util
from l2_ii_ocu_epi_costs_ext a
join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
group by a.NEW_MEM_ATTR_ID,a.year_mth_id, a.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2,a.network_paid_status_id,
a.provider_status_id, a.provider_id, a.prv_sp_4, a.tos_i_5, a.pos_i, a.etg_id, a.etg_resp_prov, A.SEV_LEVEL, a.tx_ind, a.outlier,
a.complete, c.contract_id"""

  override def dependsOn: Set[String] = Set("L2_II_OCU_EPI_COSTS_EXT","L2_II_MEM_ATTR_EXT")

  def originalSql: String = """
insert /*+ append */ into L3_OCU_EPI_COSTS
     (NEW_MEM_ATTR_ID,YEAR_MTH_ID,IA_TIME,PCP_ASSIGN,PRODUCT_ID,SEX,AGE_CAT2,NETWORK_PAID_STATUS_ID,
      PROVIDER_STATUS_ID,PROVIDER_ID,PRV_SP_4,TOS_I_5,POS_I,ETG_ID,SEV_LEVEL,TX_IND,OUTLIER,COMPLETE,contract_id,
      AMT_EQV,AMT_PAY,AMT_NP,ENC,ADMITS,LOS,SCRIPTS,RAD_UTIL,LAB_UTIL,ER_UTIL,MRI_UTIL,EM_SVC_UTIL
     )
 select a.NEW_MEM_ATTR_ID,a.year_mth_id, a.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2, a.network_paid_status_id,
        a.provider_status_id, a.provider_id, a.prv_sp_4, a.tos_i_5, a.pos_i, a.etg_id, A.SEV_LEVEL, a.tx_ind,
        a.outlier, a.complete, c.contract_id, sum(AMT_EQV) as cost1, sum(AMT_PAY) as cost2, sum(AMT_NP) as cost3,sum(encounter) as enc,
        sum(admit) as admits, sum(los) as los, sum(script) as scripts, sum(rad_util) as rad_util, sum(lab_util) as lab_util,
        sum(er_util) as   er_util, sum(mri_util) as mri_util, sum(em_svc_flag) as em_svc_util
   from l2_ii_ocu_epi_costs_ext a
   join l2_ii_mem_attr_ext c on a.NEW_MEM_ATTR_ID=c.NEW_MEM_ATTR_ID
 group by a.NEW_MEM_ATTR_ID,a.year_mth_id, a.ia_time, c.pcp_assign, c.product_id, c.sex, c.age_cat2,a.network_paid_status_id,
          a.provider_status_id, a.provider_id, a.prv_sp_4, a.tos_i_5, a.pos_i, a.etg_id, A.SEV_LEVEL, a.tx_ind, a.outlier,
          a.complete, c.contract_id
"""

  def directoryLevel: String = "L3"
  val originalSqlFileName: String = "L3_II_ocu_build.sql"
}

package com.optum.oadw.etl.L2

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_system_contract_dates
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataType, StringType, TimestampType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_SYSTEM_CONTRACT_DATES extends TableInfo[l2_system_contract_dates] {
  override def name: String = "L2_SYSTEM_CONTRACT_DATES"

  override def dependsOn: Set[String] = Set("L2_II_SERVICES_INP","L2_II_SERVICES_MED","L2_II_SERVICES_RX")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    // put the loadedDependencies into the sparkSession so that the sparksql works
    loadedDependencies.foreach {
      case (name, df) => df.createOrReplaceTempView(name)
    }

    val input = sparkSession.sql("""
select *
from (
select CONTRACT_ID, from_dt,pay_dt,'INP' type from L2_II_SERVICES_INP
union all --as data getting aggregated in the outer query, using union all for perf
select CONTRACT_ID, dos,pay_dt,'MED' type from L2_II_SERVICES_MED
UNION all
select CONTRACT_ID, dos,pay_dt,'RX' type from L2_II_SERVICES_RX
)
""".stripMargin)

    val pivotedDF = input.groupBy("CONTRACT_ID").pivot("TYPE").agg(
      min($"FROM_DT").alias("MIN_SVC_DT"),
      max($"FROM_DT").alias("MAX_SVC_DT"),
      min($"PAY_DT").alias("MIN_PD_DT"),
      max($"PAY_DT").alias("MAX_PD_DT")
    )

    val columnsToEnsure = Map(
      "CONTRACT_ID" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(StringType, "CONTRACT_ID"),
      "INP_MIN_SVC_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MIN_SVC_DT_INP"),
      "INP_MAX_SVC_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MAX_SVC_DT_INP"),
      "INP_MIN_PD_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MIN_PD_DT_INP"),
      "INP_MAX_PD_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MAX_PD_DT_INP"),
      "MED_MIN_SVC_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MIN_SVC_DT_MED"),
      "MED_MAX_SVC_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MAX_SVC_DT_MED"),
      "MED_MIN_PD_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MIN_PD_DT_MED"),
      "MED_MAX_PD_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MAX_PD_DT_MED"),
      "RX_MIN_SVC_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MIN_SVC_DT_RX"),
      "RX_MAX_SVC_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MAX_SVC_DT_RX"),
      "RX_MIN_PD_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MIN_PD_DT_RX"),
      "RX_MAX_PD_DT" -> L2_SYSTEM_CONTRACT_DATES_ColumnInfo(TimestampType, "MAX_PD_DT_RX")
    )

    val columnsToAdd = columnsToEnsure.filter(colAndType => !pivotedDF.columns.exists(c => c.equalsIgnoreCase(colAndType._1))).
      map(colAndType => lit("null").as(columnsToEnsure(colAndType._1).intendedColumnName).cast(colAndType._2.dataType))
    val dfCols = pivotedDF.columns.map(dfColName => col(dfColName).as(columnsToEnsure(dfColName).intendedColumnName))

    val finalColumns = dfCols ++ columnsToAdd
    pivotedDF.select(finalColumns: _*)
  }

  val originalSQL = """
insert *+ append * into L2_SYSTEM_CONTRACT_DATES
 (CONTRACT_ID,MIN_SVC_DT_INP,MAX_SVC_DT_INP,MIN_PD_DT_INP,MAX_PD_DT_INP,
 MIN_SVC_DT_MED,MAX_SVC_DT_MED,MIN_PD_DT_MED,MAX_PD_DT_MED,
 MIN_SVC_DT_RX,MAX_SVC_DT_RX,MIN_PD_DT_RX,MAX_PD_DT_RX)
 select contract_id,inp_min_svc_dt,inp_max_svc_dt,inp_min_pd_dt,inp_max_pd_dt,
 med_min_svc_dt,med_max_svc_dt,med_min_pd_dt,med_max_pd_dt,
 rx_min_svc_dt,rx_max_svc_dt,rx_min_pd_dt,rx_max_pd_dt
 from (
 select CONTRACT_ID, from_dt,pay_dt,''INP'' type from L2_II_SERVICES_INP
 union all --as data getting aggregated in the outer query, using union all for perf
 select CONTRACT_ID, dos,pay_dt,''MED'' type from L2_II_SERVICES_MED
 UNION all
  select CONTRACT_ID, dos,pay_dt,''RX'' type from L2_II_SERVICES_RX
  )
  pivot (
  min(from_dt) min_svc_dt,
  max(from_dt) max_svc_dt,
  min(pay_dt) min_pd_dt,
  max(pay_dt) max_pd_dt
  for type in (''INP'' as "INP",''MED'' AS "MED",''RX'' AS "RX")
  )
  ;
""".stripMargin

  def directoryLevel: String = "L2"

}

case class L2_SYSTEM_CONTRACT_DATES_ColumnInfo(dataType: DataType, intendedColumnName: String)

package com.optum.oadw.etl.L3

import com.optum.oadw.definedfunctions.BitOrAggFunction.bitOrAgg
import com.optum.oadw.definedfunctions.ListAggFunction.listAgg
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.etl.constants._
import com.optum.oadw.oadwModels.{l3_map_precursor_assess_cui, l3_map_precursor_dcc, l3_map_precursor_evt_detail, l3_map_precursor_proc, _}
import com.optum.oadw.oadw_ref.models.{l3_dict_precursor, l3_map_precur_cui, l3_map_precur_diag_hccfilter, l3_map_precur_hm_defer, l3_map_precur_pcc, l3_map_precur_pos, l3_map_precur_spec, l3_map_precursor_diag, l3_map_precursor_evt_type, l3_map_precursor_modifier, l3_map_proc_etg_elig, l3_map_proc_hcc_elig}
import com.optum.oadw.utils.DataframeExtensions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, IntegerType, LongType, StringType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

import scala.math.{max => scalaMax}

/**
 * Spec: https://wiki.humedica.net/display/Data/OADW+Concept+Specification+-+Precursors
 */
object L3_PAT_PRECURSOR extends TableInfo[l3_pat_precursor] {
  override def name: String = "L3_PAT_PRECURSOR"

  def directoryLevel: String = "L3"

  override def partitions: Int = 2048

  override def dependsOn: Set[String] = Set("TEMP_L3_PAT_PRECURSOR_DIAG", "TEMP_L3_PAT_PRECURSOR_ASSESS_NUM",
    "TEMP_L3_PAT_PRECURSOR_ASSESS_QUAL", "TEMP_L3_PAT_PRECURSOR_MED", "TEMP_L3_PAT_PRECURSOR_PROC",
    "TEMP_L3_PAT_PRECURSOR_EVT", "TEMP_L3_PAT_PRECURSOR_SPEC", "TEMP_L3_PAT_PRECURSOR_OTHERS", "TEMP_L3_PAT_PRECURSOR_POS")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempL3PatPrecursorDiag = loadedDependencies("TEMP_L3_PAT_PRECURSOR_DIAG").as[l3_pat_precursor]
    val tempL3PatPrecursorAssessNum = loadedDependencies("TEMP_L3_PAT_PRECURSOR_ASSESS_NUM").as[l3_pat_precursor]
    val tempL3PatPrecursorAssessQual = loadedDependencies("TEMP_L3_PAT_PRECURSOR_ASSESS_QUAL").as[l3_pat_precursor]
    val tempL3PatPrecursorMed = loadedDependencies("TEMP_L3_PAT_PRECURSOR_MED").as[l3_pat_precursor]
    val tempL3PatPrecursorProc = loadedDependencies("TEMP_L3_PAT_PRECURSOR_PROC").as[l3_pat_precursor]
    val tempL3PatPrecursorEvt = loadedDependencies("TEMP_L3_PAT_PRECURSOR_EVT").as[l3_pat_precursor]
    val tempL3PatPrecursorSpec = loadedDependencies("TEMP_L3_PAT_PRECURSOR_SPEC").as[l3_pat_precursor]
    val tempL3PatPrecursorPos = loadedDependencies("TEMP_L3_PAT_PRECURSOR_POS").as[l3_pat_precursor]
    val tempL3PatPrecursorOthers = loadedDependencies("TEMP_L3_PAT_PRECURSOR_OTHERS").as[l3_pat_precursor]

    tempL3PatPrecursorDiag
      .union(tempL3PatPrecursorAssessNum)
      .union(tempL3PatPrecursorAssessQual)
      .union(tempL3PatPrecursorMed)
      .union(tempL3PatPrecursorProc)
      .union(tempL3PatPrecursorEvt)
      .union(tempL3PatPrecursorOthers)
      .union(tempL3PatPrecursorSpec)
      .union(tempL3PatPrecursorPos)
      .toDF
      .repartition($"precursor_id")
  }

  def columnSelect(df: DataFrame, precursorSource: String, sparkSession: SparkSession): DataFrame = {
    import sparkSession.implicits._

    df.select(
      $"client_id",
      $"mpi",
      $"precursor_cds_grp",
      lit(precursorSource).as("precursor_domain"),
      $"precursor_dtm",
      $"precursor_end_dtm",
      $"precursor_id",
      $"precursor_modifier_flg",
      $"precursor_type",
      when($"precursor_value".cast("Double") === lit(0), lit("0")).otherwise($"precursor_value".cast(StringType)).as("precursor_value"),
      $"sensitive_ind"
    )
  }
}

case class grouped_pat_diag(client_id: String, diag_dt: java.sql.Timestamp, code_type: String,
                            diag_cd: String, cds_grp: String, primary_ind: Integer, problemlist_ind: Integer,
                            bill_claim_ind: Integer, sensitive_ind: Integer, poa_cui: String, hosp_dx_ind: Integer,
                            primary_hosp_dx_ind: Integer)
case class grouped_pat_proc(proc_cd: String, code_type: String, tos_i_5: java.lang.Long)
case class grouped_pat_clinical_event(event_type_cui: String)
case class mpi_event(mpi: String, clinical_event_id: java.lang.Long, diags: Option[Seq[grouped_pat_diag]], procs:
Option[Seq[grouped_pat_proc]], clinicalEvts: Option[Seq[grouped_pat_clinical_event]])
case class mapped_precursor_diag(code_type: String, diag_cd: String, precursor_ids: Seq[Integer])
case class mapped_diagnosis_cui(codetype: String, mappedcode: String, cuis: Seq[String])
case class mapped_precursor_cui(cui: String, precursor_ids: Seq[Integer])
case class mapped_tos(tosI5: Integer, tosI1s: Seq[Integer])
object TEMP_L3_PAT_PRECURSOR_DIAG extends TableInfo[l3_pat_precursor] {
  override def name: String = "TEMP_L3_PAT_PRECURSOR_DIAG"

  override def partitions: Int = 128

  override def dependsOn: Set[String] = Set("L3_DICT_PRECURSOR", "L2_PAT_PROC", "L2_PAT_DIAG", "L3_MAP_PROC_ETG_ELIG",
    "L3_MAP_PROC_HCC_ELIG", "L3_MAP_PRECUR_DIAG_HCCFILTER", "L3_MAP_PRECURSOR_DIAG",
    "REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI", "L3_MAP_PRECURSOR_MODIFIER", "L1_MAP_DIAGNOSIS_CUI", "L2_PAT_CLINICAL_EVENT")

  def directoryLevel: String = "L3"

  private def commonPrecursorModifierFlgs(diag: grouped_pat_diag, precursorModifierFlgLookup: Map[String, Integer]): Integer = {
    val nullOrPOAExemptCuis = Set(
      Precursors.POA_CUI_PRESENT_ON_ADMISSION_EXEMPT,
      Precursors.CUI_NULL)

    val diagBillClaim: Int = if (diag.bill_claim_ind == 1) precursorModifierFlgLookup(Precursors.MODIFIER_CUI_DIAG_BILL_CLAIM) else 0
    val cuiDiagPrimary: Int = if (diag.primary_ind == 1) precursorModifierFlgLookup(Precursors.MODIFIER_CUI_DIAG_PRIMARY) else 0
    val poa: Int = if (diag.primary_hosp_dx_ind == 0 && diag.hosp_dx_ind == 1 && diag.poa_cui == Precursors.POA_CUI_PRESENT_ON_ADMISSION)
      precursorModifierFlgLookup(Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION) else 0
    val primaryDiagInstitutionalPoa: Int = if (diag.primary_hosp_dx_ind == 1 && diag.poa_cui == Precursors.POA_CUI_PRESENT_ON_ADMISSION)
      precursorModifierFlgLookup(Precursors.MODIFIER_CUI_PRIMARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION) else 0
    val cuiNotPoa: Int = if (diag.primary_hosp_dx_ind == 0 && diag.hosp_dx_ind == 1 && diag.poa_cui == Precursors.POA_CUI_NOT_PRESENT_ON_ADMISSION)
      precursorModifierFlgLookup(Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_NOT_PRESENT_ON_ADMISSION) else 0
    val poaUndetermined: Int = if (diag.primary_hosp_dx_ind == 0 && diag.hosp_dx_ind == 1 && diag.poa_cui == Precursors.POA_CUI_PRESENT_ON_ADMISSION_UNDETERMINED)
      precursorModifierFlgLookup(Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION_UNDETERMINED) else 0
    val poaNotReported: Int = if (diag.primary_hosp_dx_ind == 0 && diag.hosp_dx_ind == 1 && nullOrPOAExemptCuis.contains(diag.poa_cui))
      precursorModifierFlgLookup(Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION_NOT_REPORTED) else 0
    val primaryDiagInstitutional: Int = if (diag.primary_hosp_dx_ind == 1) precursorModifierFlgLookup(Precursors.MODIFIER_CUI_PRIMARY_DIAG_INSTITUTIONAL) else 0
    val secondaryDiagPoaUnknown: Int = if (diag.primary_hosp_dx_ind == 0 && diag.hosp_dx_ind == 1 && diag.poa_cui == Precursors.POA_CUI_PRESENT_ON_ADMISSION_UNKNOWN)
      precursorModifierFlgLookup(Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION_UNKNOWN) else 0

    diagBillClaim + cuiDiagPrimary + poa + primaryDiagInstitutionalPoa + cuiNotPoa + poaUndetermined + poaNotReported + primaryDiagInstitutional + secondaryDiagPoaUnknown
  }

  private def precursorRow(diag: grouped_pat_diag, event: mpi_event, precursorId: Integer, precursorModifierFlg: Integer, dictPrecursorSensitivity: Integer): l3_pat_precursor = {
    l3_pat_precursor(
      client_id = diag.client_id,
      mpi = event.mpi,
      precursor_cds_grp = diag.cds_grp,
      precursor_domain = Precursors.DOMAIN_DIAG,
      precursor_dtm = diag.diag_dt,
      precursor_end_dtm = diag.diag_dt,
      precursor_id = precursorId,
      precursor_modifier_flg = precursorModifierFlg,
      precursor_type = diag.code_type,
      precursor_value = diag.diag_cd,
      sensitive_ind = scalaMax(diag.sensitive_ind, dictPrecursorSensitivity)
    )
  }

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor].where($"active_ind" === lit(1)))
    val tL2PatProc = loadedDependencies("L2_PAT_PROC").as[l2_pat_proc]
    val tL2PatDiag = loadedDependencies("L2_PAT_DIAG").as[l2_pat_diag]
    val tL3MapProcEtgElig = broadcast(loadedDependencies("L3_MAP_PROC_ETG_ELIG").as[l3_map_proc_etg_elig])
    val tL3MapProcHccElig = broadcast(loadedDependencies("L3_MAP_PROC_HCC_ELIG").as[l3_map_proc_hcc_elig])
    val tL3MapPrecurDiagHccFilter = broadcast(loadedDependencies("L3_MAP_PRECUR_DIAG_HCCFILTER").as[l3_map_precur_diag_hccfilter])
    val tL3MapPrecursorDiag = broadcast(loadedDependencies("L3_MAP_PRECURSOR_DIAG").as[l3_map_precursor_diag])
    val tL3MapPrecurCui = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI").as[l3_map_precur_cui])
    val tL3MapPrecursorModifier = broadcast(loadedDependencies("L3_MAP_PRECURSOR_MODIFIER").as[l3_map_precursor_modifier])
    val tL1MapDiagnosisCui = broadcast(loadedDependencies("L1_MAP_DIAGNOSIS_CUI").as[l1_map_diagnosis_cui])
    val tL2PatClinicalEvent = loadedDependencies("L2_PAT_CLINICAL_EVENT").as[l2_pat_clinical_event]

    val evtTypeCuiSet1 = Set(
      Precursors.EVT_TYPE_CUI_INPATIENT,
      Precursors.EVT_TYPE_CUI_INPATIENT_PSYCH,
      Precursors.EVT_TYPE_CUI_INPATIENT_REHAB
    )

    val evtTypeCuiSet2 = Set(
      Precursors.EVT_TYPE_CUI_OBSERVATION,
      Precursors.EVT_TYPE_CUI_ED,
      Precursors.EVT_TYPE_CUI_OFFICE,
      Precursors.EVT_TYPE_CUI_OTHER,
      Precursors.EVT_TYPE_CUI_AMB_PAT_SVCS,
      Precursors.EVT_TYPE_CUI_URGENT_CARE
    )

    // In Memory Lookups
    val precursorModifierFlgLookup = tL3MapPrecursorModifier.where($"precursor_modifier_cui".isin(
      Precursors.MODIFIER_CUI_DIAG_PRIMARY,
      Precursors.MODIFIER_CUI_DIAG_BILL_CLAIM,
      Precursors.MODIFIER_CUI_DIAG_PROBLEM_LIST,
      Precursors.MODIFIER_CUI_PRIMARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION,
      Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_NOT_PRESENT_ON_ADMISSION,
      Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION_UNDETERMINED,
      Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION_NOT_REPORTED,
      Precursors.MODIFIER_CUI_PRIMARY_DIAG_INSTITUTIONAL,
      Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION_UNKNOWN,
      Precursors.MODIFIER_CUI_SECONDARY_DIAG_INSTITUTIONAL_PRESENT_ON_ADMISSION)
    ).select($"precursor_modifier_cui", $"precursor_modifier_flg")
    .collect.map(row => (row.getString(0), new Integer(row.getInt(1)))).toMap

    val mapPrecursorDiag = tL3MapPrecursorDiag
      .groupBy($"diag_cd", $"code_type")
      .agg(collect_list($"precursor_id").as("precursor_ids"))
      .as[mapped_precursor_diag].collect.map(mpd => ((mpd.code_type, mpd.diag_cd), mpd.precursor_ids)).toMap

    val mapPrecurDiagHccFilter = tL3MapPrecurDiagHccFilter.select($"precursor_id").collect.map(_.get(0)).toSet

    val mapProcHccElig = tL3MapProcHccElig.select($"proc_cd", $"code_type").collect.map(row => (row.get(0),row.get(1))).toSet
    val mapProcEtgElig = tL3MapProcEtgElig.select($"proc_cd", $"code_type").collect.map(row => (row.get(0),row.get(1))).toSet

    val mapDiagnosisCui = tL1MapDiagnosisCui
      .groupBy($"mappedcode", $"codetype")
      .agg(collect_list($"cui").as("cuis")).as[mapped_diagnosis_cui]
      .collect.map(row => ((row.codetype, row.mappedcode), row.cuis)).toMap

    val activePrecursors = tL3DictPrecursor.select($"precursor_id", $"sensitive_ind")
      .collect.map(row => (row.getInt(0),row.getInt(1))).toMap

    val mapPrecurCui = tL3MapPrecurCui
      .where($"precursor_domain_cd" === Precursors.DOMAIN_DIAG)
      .groupBy($"cui").agg(collect_list($"precursor_id").as("precursor_ids")).as[mapped_precursor_cui]
      .collect.map(row => (row.cui, row.precursor_ids)).toMap

    // repartition data into event/mpi grouped rows
    val groupedPatDiag = tL2PatDiag.as("pd")
      .groupBy($"pd.mpi", $"pd.clinical_event_id")
      .agg(collect_list(struct(classOf[grouped_pat_diag].getDeclaredFields.toList.withFilter(!_.isSynthetic).map(f => $"${f.getName}"): _*)).as("diags"))
    val groupedPatProc = tL2PatProc
      .groupBy($"mpi", $"clinical_event_id")
      .agg(collect_list(struct(classOf[grouped_pat_proc].getDeclaredFields.toList.withFilter(!_.isSynthetic).map(f => $"${f.getName}"): _*)).as("procs"))
    val groupedClinicalEvts = tL2PatClinicalEvent
      .groupBy($"mpi", $"clinical_event_id")
      .agg(collect_list(struct(classOf[grouped_pat_clinical_event].getDeclaredFields.toList.withFilter(!_.isSynthetic).map(f => $"${f.getName}"): _*)).as("clinicalEvts"))
    val mpiEvents = groupedPatDiag
      .join(groupedPatProc, Seq("clinical_event_id", "mpi"), "left")
      .join(groupedClinicalEvts, Seq("clinical_event_id", "mpi"), "left").as[mpi_event]

    // for each event, determine precursors
    val result = mpiEvents.repartition(2048, $"clinical_event_id", $"mpi")
      .mapPartitions(events => {
        events.flatMap(event => {

          val eventIsHccQualified = if (event.clinical_event_id == null) false else {
            event.procs.getOrElse(Seq.empty[grouped_pat_proc]).exists(proc => {
              mapProcHccElig.contains((proc.proc_cd, proc.code_type))
            })
          }

          val eventHasEligibleEvtCuiSet1 = if (event.clinical_event_id == null) false else {
            event.clinicalEvts.getOrElse(Seq.empty[grouped_pat_clinical_event]).exists(clinEvt => {
              val event_type_cui = Option(clinEvt.event_type_cui)
              event_type_cui.isDefined && evtTypeCuiSet1.contains(event_type_cui.get)
            })
          }

          val eventHasEligibleEvtCuiSet2 = if (event.clinical_event_id == null) false else {
            event.clinicalEvts.getOrElse(Seq.empty[grouped_pat_clinical_event]).exists(clinEvt => {
              val event_type_cui = Option(clinEvt.event_type_cui)
              event_type_cui.isDefined && evtTypeCuiSet2.contains(event_type_cui.get)
            })
          }

          val eventIsEtgQualified = if (event.clinical_event_id == null) false else
            event.procs.getOrElse(Seq.empty[grouped_pat_proc]).exists(proc => {
            val procCode = (proc.proc_cd, proc.code_type)

            mapProcEtgElig.contains(procCode)
          })

          val elligibleDiagCodes = event.diags.getOrElse(Seq.empty[grouped_pat_diag])
            .filter(diag => {
              val diagCode = (diag.code_type, diag.diag_cd)
              val diagCodeMapped = mapPrecursorDiag.contains(diagCode)
              val precursorIsActive = diagCodeMapped && activePrecursors.keySet.exists(mapPrecursorDiag(diagCode).contains)

              diagCodeMapped && precursorIsActive
            }
          )

          val hccEtgRows: Seq[l3_pat_precursor] = elligibleDiagCodes.flatMap(diag => {
            if (diag.problemlist_ind == 1) Seq.empty[l3_pat_precursor] else {
              val relevantPrecursorIds = mapPrecursorDiag.get((diag.code_type, diag.diag_cd))
                relevantPrecursorIds.getOrElse(Seq.empty[Integer]).flatMap(precursor_id => {
                  val precursorModifierFlg: java.lang.Integer = commonPrecursorModifierFlgs(diag, precursorModifierFlgLookup)
                  val isHccFiltered = mapPrecurDiagHccFilter.contains(precursor_id)
                  if (isHccFiltered) {
                    val hospDxInd = diag.hosp_dx_ind
                    if((1 == hospDxInd && eventHasEligibleEvtCuiSet1) ||
                       (1 == hospDxInd && eventHasEligibleEvtCuiSet2 && eventIsHccQualified) ||
                       (0 == hospDxInd && eventIsHccQualified)) {
                      Seq(
                        precursorRow(diag, event, precursor_id, precursorModifierFlg, activePrecursors(precursor_id))
                      )
                    } else {
                      Seq.empty[l3_pat_precursor]
                    }
                  }else if (!isHccFiltered && eventIsEtgQualified) Seq(
                    precursorRow(diag, event, precursor_id, precursorModifierFlg, activePrecursors(precursor_id))
                  )
                  else Seq.empty[l3_pat_precursor]
                })
            }
          })

          val problemRows = elligibleDiagCodes.filter(_.problemlist_ind == 1).flatMap(diag => {
            val precursorModifierFlg: java.lang.Integer = commonPrecursorModifierFlgs(diag, precursorModifierFlgLookup) +
              precursorModifierFlgLookup(Precursors.MODIFIER_CUI_DIAG_PROBLEM_LIST)

            mapPrecursorDiag((diag.code_type, diag.diag_cd)).map(precursor_id =>
              precursorRow(diag, event, precursor_id, precursorModifierFlg, activePrecursors(precursor_id))
            )
          })

          val unfilteredRows =
            event.diags.getOrElse(Seq.empty[grouped_pat_diag]).flatMap(diag => {
              val diagCode = (diag.code_type, diag.diag_cd)
              val mappedDiagnosisCuis = mapDiagnosisCui.get(diagCode)
              val mappedPrecursors =
                mappedDiagnosisCuis.getOrElse(Seq.empty[String]).flatMap(mdc =>
                  if (mapPrecurCui.contains(mdc)) mapPrecurCui(mdc) else Seq.empty[Integer]
                )
              if (mappedPrecursors.nonEmpty) {
                val problemsListFlg: Int = if (diag.problemlist_ind == 1)
                  precursorModifierFlgLookup(Precursors.MODIFIER_CUI_DIAG_PROBLEM_LIST) else 0
                val precursorModifierFlg = commonPrecursorModifierFlgs(diag, precursorModifierFlgLookup) +
                  problemsListFlg

                mappedPrecursors.map( precursor_id => precursorRow(diag, event, precursor_id, precursorModifierFlg, activePrecursors(precursor_id)) )
              } else Seq.empty[l3_pat_precursor]
            })

          hccEtgRows ++ problemRows ++ unfilteredRows
        })
      })

    val aggregatedResult =
      result
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"client_id", $"mpi", $"precursor_dtm", $"precursor_id")
          .orderBy($"sensitive_ind".asc, $"precursor_value".desc))
      )
      .groupBy($"client_id", $"mpi", $"precursor_id", $"precursor_dtm")
      .agg(
        first($"precursor_end_dtm").as("precursor_end_dtm"),
        max(when($"precedence_rank" === lit(1), $"sensitive_ind").otherwise(null)).as("sensitive_ind"),
        max(when($"precedence_rank" === lit(1), $"precursor_value").otherwise(null)).as("precursor_value"),
        max(when($"precedence_rank" === lit(1), $"precursor_type").otherwise(null)).as("precursor_type"),
        bitOrAgg($"precursor_modifier_flg").as("precursor_modifier_flg"),
        listAgg($"precursor_cds_grp").as("precursor_cds_grp")
      )

      L3_PAT_PRECURSOR.columnSelect(aggregatedResult, Precursors.DOMAIN_DIAG, sparkSession)

  }

  private def diagnosisSelect(sparkSession: SparkSession, df: DataFrame): DataFrame = {
    import sparkSession.implicits._

    df.select($"client_id", $"mpi", $"cds_grp".as("precursor_cds_grp"),
      $"diag_dt".as("precursor_dtm"), $"diag_dt".as("precursor_end_dtm"), $"precursor_id",
      $"code_type".as("precursor_type"), $"diag_cd".as("precursor_value"),
      $"sensitive_ind", $"primary_ind", $"bill_claim_ind", $"problemlist_ind", $"precursor_modifier_flg")
  }
}

case class precursor_modifier_cui_to_nlp_ind(nlp_ind: java.lang.Integer, precursor_modifier_cui: String)

trait AssessmentPrecursorHelper {
  val VALUE_FILTER_ID_MAX = 3
  val VALUE_FILTER_ID_MIN = 2
  val VALUE_FILTER_ID_ALL_DATE = 5
  val VALUE_FILTER_ID_ALL_DATETIME = 1
  val VALUE_FILTER_ID_AVG = 4

  protected val getNlpPrecursorModifiers: Seq[precursor_modifier_cui_to_nlp_ind] = Seq(
    precursor_modifier_cui_to_nlp_ind(nlp_ind = 0, precursor_modifier_cui = Precursors.MODIFIER_CUI_ASSESS_STRUCTURED),
    precursor_modifier_cui_to_nlp_ind(nlp_ind = 1, precursor_modifier_cui = Precursors.MODIFIER_CUI_ASSESS_STRUCTURED),
    precursor_modifier_cui_to_nlp_ind(nlp_ind = 1, precursor_modifier_cui = Precursors.MODIFIER_CUI_ASSESS_UNSTRUCTURED_NLP),
    precursor_modifier_cui_to_nlp_ind(nlp_ind = 2, precursor_modifier_cui = Precursors.MODIFIER_CUI_ASSESS_UNSTRUCTURED_NLP)
  )

  protected def getFilteredPrecursorModifierCui(sparkSession: SparkSession,
                                                tL3MapPrecursorModifier: Dataset[l3_map_precursor_modifier]
                                               ): DataFrame = {
    import sparkSession.implicits._
    broadcast(
      getNlpPrecursorModifiers.toDF
        .join(tL3MapPrecursorModifier, Seq("precursor_modifier_cui"))
        .select($"nlp_ind", $"precursor_modifier_flg", $"precursor_modifier_cui")
    )
  }
}

object TEMP_L3_PAT_PRECURSOR_ASSESS_NUM extends TableInfo[l3_pat_precursor] with AssessmentPrecursorHelper {
  override def name: String = "TEMP_L3_PAT_PRECURSOR_ASSESS_NUM"

  override def partitions: Int = 128

  override def dependsOn: Set[String] = Set("L3_DICT_PRECURSOR", "L2_PAT_ASSESS_NUM", "L3_MAP_PRECURSOR_ASSESS_CUI", "L3_MAP_PRECURSOR_MODIFIER")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor].where($"active_ind" === lit(1)))
    val l2PatAssessNum = loadedDependencies("L2_PAT_ASSESS_NUM").castToBigDecimal(Set("numeric_value")).as[l2_pat_assess_num]
    val l3MapPrecursorAssessCui = broadcast(loadedDependencies("L3_MAP_PRECURSOR_ASSESS_CUI").castToBigDecimal(Set("lower_bound", "upper_bound")).as[l3_map_precursor_assess_cui])
    val l3MapPrecursorModifier = broadcast(loadedDependencies("L3_MAP_PRECURSOR_MODIFIER").as[l3_map_precursor_modifier])

    val filteredPrecursorModifierCui = getFilteredPrecursorModifierCui(sparkSession, l3MapPrecursorModifier)

    val assessmentPrecursorMap = l2PatAssessNum.as("pan")
      .join(l3MapPrecursorAssessCui.as("mpac"), $"mpac.assess_cui" === $"pan.assessment_cui")
      .where($"mpac.exclude_hosp_ind" === lit(0) ||
        $"mpac.exclude_hosp_ind" === lit(1) && $"pan.hosp_ind" === lit(0))
      .join(l3DictPrecursor.as("dp"), "precursor_id")
      .join(filteredPrecursorModifierCui.as("fpmc"), $"fpmc.nlp_ind" === $"pan.nlp_ind")
      .groupBy($"pan.assessment_dtm", $"pan.assessment_cui", $"pan.cds_grp", $"pan.hosp_ind",
        $"pan.mpi", $"pan.client_id", $"pan.nlp_ind", $"pan.numeric_value", $"mpac.exclude_hosp_ind", $"precursor_id",
        $"mpac.lower_bound", $"mpac.upper_bound", $"mpac.value_filter_id", $"pan.sensitive_ind", $"dp.sensitive_ind")
      .agg(
        when($"pan.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind")
          .otherwise($"pan.sensitive_ind")
          .as("max_sensitive_ind"),
        bitOrAgg(when($"fpmc.precursor_modifier_flg".isNull, 0).otherwise($"fpmc.precursor_modifier_flg"))
          .as("precursor_modifier_flg")
      )
      .drop("pan.sensitive_ind", "dp.sensitive_ind")

    val assessNumsAvgByDate =
      assessmentPrecursorMap.as("apm")
        .where($"value_filter_id" === lit(VALUE_FILTER_ID_AVG))
        .groupBy($"apm.mpi", $"apm.client_id", $"apm.assessment_cui".as("precursor_type"),
          $"apm.assessment_dtm".cast(DateType).as("precursor_dtm"),
          $"apm.assessment_dtm".cast(DateType).as("precursor_end_dtm"),
          $"apm.precursor_id", $"apm.lower_bound", $"apm.upper_bound")
        .agg(
          bitOrAgg($"apm.precursor_modifier_flg").as("precursor_modifier_flg"),
          avg($"apm.numeric_value").as("precursor_value"),
          listAgg($"apm.cds_grp").as("precursor_cds_grp"),
          max($"apm.max_sensitive_ind").as("sensitive_ind")
        )
        .where(($"apm.lower_bound".isNull || $"precursor_value" >= $"apm.lower_bound") &&
          ($"apm.upper_bound".isNull || $"precursor_value" <= $"apm.upper_bound"))
        .drop("lower_bound", "upper_bound")

    val assessNumsAllByDate = assessmentPrecursorMap.as("apm")
      .where($"value_filter_id" === lit(VALUE_FILTER_ID_ALL_DATE) &&
        (($"apm.lower_bound".isNull || $"apm.numeric_value" >= $"apm.lower_bound") &&
          ($"apm.upper_bound".isNull || $"apm.numeric_value" <= $"apm.upper_bound")))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"apm.assessment_dtm".cast(DateType), $"apm.mpi", $"apm.precursor_id")
          .orderBy($"apm.max_sensitive_ind".asc, $"apm.numeric_value".desc))
      )
      .groupBy($"apm.mpi", $"apm.client_id", $"apm.assessment_cui".as("precursor_type"),
        $"apm.assessment_dtm".cast(DateType).as("precursor_dtm"),
        $"apm.assessment_dtm".cast(DateType).as("precursor_end_dtm"),
        $"apm.precursor_id")
      .agg(
        bitOrAgg($"apm.precursor_modifier_flg").as("precursor_modifier_flg"),
        max(when($"precedence_rank" === lit(1), $"apm.numeric_value")
          .otherwise(null)).as("precursor_value"),
        listAgg($"apm.cds_grp").as("precursor_cds_grp"),
        max($"apm.max_sensitive_ind").as("sensitive_ind"))

    val assessNumsAllByDateTime = assessmentPrecursorMap.as("apm")
      .where($"value_filter_id" === lit(VALUE_FILTER_ID_ALL_DATETIME) &&
        (($"apm.lower_bound".isNull || $"apm.numeric_value" >= $"apm.lower_bound") &&
          ($"apm.upper_bound".isNull || $"apm.numeric_value" <= $"apm.upper_bound")))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"apm.assessment_dtm", $"apm.mpi", $"apm.precursor_id")
          .orderBy($"apm.max_sensitive_ind".asc, $"apm.numeric_value".desc))
      )
      .groupBy($"apm.mpi", $"apm.client_id", $"apm.assessment_cui".as("precursor_type"),
        $"apm.assessment_dtm".as("precursor_dtm"),
        $"apm.assessment_dtm".as("precursor_end_dtm"),
        $"apm.precursor_id")
      .agg(
        bitOrAgg($"apm.precursor_modifier_flg").as("precursor_modifier_flg"),
        max(when($"precedence_rank" === lit(1), $"apm.numeric_value")
          .otherwise(null)).as("precursor_value"),
        listAgg($"apm.cds_grp").as("precursor_cds_grp"),
        max($"apm.max_sensitive_ind").as("sensitive_ind")
      )

    val assessNumsMaxByDate = assessmentPrecursorMap.as("apm")
      .where($"value_filter_id" === lit(VALUE_FILTER_ID_MAX))
      .withColumn("precedence_rank",
        dense_rank.over(Window.partitionBy($"apm.assessment_dtm".cast(DateType), $"apm.mpi", $"apm.precursor_id")
          .orderBy($"apm.max_sensitive_ind".asc, $"apm.numeric_value".desc))
      )
      .groupBy($"apm.mpi", $"apm.client_id", $"apm.assessment_cui".as("precursor_type"),
        $"apm.assessment_dtm".cast(DateType).as("precursor_dtm"),
        $"apm.assessment_dtm".cast(DateType).as("precursor_end_dtm"),
        $"apm.precursor_id", $"apm.lower_bound", $"apm.upper_bound")
      .agg(
        max(when($"precedence_rank" === lit(1), $"apm.precursor_modifier_flg").otherwise(null))
          .as("precursor_modifier_flg"),
        max($"apm.numeric_value").as("precursor_value"),
        listAgg(when($"precedence_rank" === lit(1), $"apm.cds_grp").otherwise(""))
          .as("precursor_cds_grp"),
        max($"apm.max_sensitive_ind").as("sensitive_ind") // grab from max/min row
      )
      .where($"precursor_value".isNotNull &&
        (($"apm.lower_bound".isNull || $"precursor_value" >= $"apm.lower_bound") &&
          ($"apm.upper_bound".isNull || $"precursor_value" <= $"apm.upper_bound"))
      )
      .drop("lower_bound", "upper_bound")
    val assessNumsMinByDate = assessmentPrecursorMap.as("apm")
      .where($"value_filter_id" === lit(VALUE_FILTER_ID_MIN))
      .withColumn("precedence_rank",
        dense_rank.over(Window.partitionBy($"apm.assessment_dtm".cast(DateType), $"apm.mpi", $"apm.precursor_id")
          .orderBy($"apm.max_sensitive_ind".asc, $"apm.numeric_value".asc))
      )
      .groupBy($"apm.mpi", $"apm.client_id", $"apm.assessment_cui".as("precursor_type"),
        $"apm.assessment_dtm".cast(DateType).as("precursor_dtm"),
        $"apm.assessment_dtm".cast(DateType).as("precursor_end_dtm"),
        $"apm.precursor_id", $"apm.lower_bound", $"apm.upper_bound")
      .agg(
        max(when($"precedence_rank" === lit(1), $"apm.precursor_modifier_flg").otherwise(null))
          .as("precursor_modifier_flg"),
        min($"apm.numeric_value").as("precursor_value"),
        listAgg(when($"precedence_rank" === lit(1), $"apm.cds_grp").otherwise(""))
          .as("precursor_cds_grp"),
        max($"apm.max_sensitive_ind").as("sensitive_ind") // grab from max/min row
      )
      .where($"precursor_value".isNotNull &&
        (($"apm.lower_bound".isNull || $"precursor_value" >= $"apm.lower_bound") &&
          ($"apm.upper_bound".isNull || $"precursor_value" <= $"apm.upper_bound"))
      )
      .drop("lower_bound", "upper_bound")

    val grouped = assessNumsAvgByDate
      .union(assessNumsMinByDate)
      .union(assessNumsMaxByDate)
      .union(assessNumsAllByDateTime)
      .union(assessNumsAllByDate)
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"precursor_dtm", $"mpi", $"precursor_id")
          .orderBy($"sensitive_ind".asc, $"precursor_value".desc, $"precursor_type".desc))
      )
      .groupBy($"mpi", $"client_id", $"precursor_dtm", $"precursor_end_dtm", $"precursor_id")
      .agg(
        bitOrAgg($"precursor_modifier_flg").as("precursor_modifier_flg"),
        max(when($"precedence_rank" === lit(1), $"precursor_value").otherwise(null))
          .as("precursor_value"),
        max(when($"precedence_rank" === lit(1), $"precursor_type").otherwise(null)).as("precursor_type"),
        listAgg($"precursor_cds_grp").as("precursor_cds_grp"),
        max($"sensitive_ind").as("sensitive_ind")
      )

    L3_PAT_PRECURSOR.columnSelect(grouped, Precursors.DOMAIN_ASSESS, sparkSession)
  }
}

object TEMP_L3_PAT_PRECURSOR_ASSESS_QUAL extends TableInfo[l3_pat_precursor] with AssessmentPrecursorHelper {
  override def name: String = "TEMP_L3_PAT_PRECURSOR_ASSESS_QUAL"

  override def partitions: Int = 128

  override def dependsOn: Set[String] = Set("L2_PAT_ASSESS_QUAL", "L3_DICT_PRECURSOR", "L3_MAP_PRECURSOR_MODIFIER", "L3_MAP_PRECURSOR_ASSESS_CUI")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2PatAssessQual = loadedDependencies("L2_PAT_ASSESS_QUAL").as[l2_pat_assess_qual]
    val l3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor].where($"active_ind" === lit(1)))
    val l3MapPrecursorModifier = broadcast(loadedDependencies("L3_MAP_PRECURSOR_MODIFIER").as[l3_map_precursor_modifier])
    val l3MapPrecursorAssessCui = broadcast(loadedDependencies("L3_MAP_PRECURSOR_ASSESS_CUI").castToBigDecimal(Set("lower_bound", "upper_bound")).where($"lower_bound".isNull && $"upper_bound".isNull).as[l3_map_precursor_assess_cui])

    import sparkSession.implicits._

    val filteredPrecursorModifierCui = getFilteredPrecursorModifierCui(sparkSession, l3MapPrecursorModifier)

    val assessPrecursorMap = l2PatAssessQual.as("pan")
      .join(l3MapPrecursorAssessCui.as("mpac"), $"mpac.assess_cui" === $"pan.assessment_cui")
      .join(l3DictPrecursor.as("dp"), "precursor_id")
      .join(filteredPrecursorModifierCui.as("fpmc"), $"fpmc.nlp_ind" === $"pan.nlp_ind")
      .where(($"mpac.exclude_hosp_ind" === lit(0) ||
        $"mpac.exclude_hosp_ind" === lit(1) && $"pan.hosp_ind" === lit(0))
        && ($"pan.value_cui" === $"mpac.qualitative_val" || $"mpac.qualitative_val".isNull)
      )
      .groupBy($"pan.assessment_dtm", $"pan.assessment_cui".as("precursor_type"), $"pan.cds_grp", $"pan.hosp_ind",
        $"pan.mpi", $"pan.client_id", $"pan.nlp_ind", $"pan.value_cui".as("precursor_value"), $"mpac.exclude_hosp_ind", $"precursor_id",
        $"mpac.value_filter_id", $"pan.sensitive_ind", $"dp.sensitive_ind", $"pan.assessment_dtm".as("precursor_dtm"), $"pan.value_cui", $"mpac.qualitative_val")
      .agg(
        when($"pan.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind")
          .otherwise($"pan.sensitive_ind")
          .as("max_sensitive_ind"),
        bitOrAgg(when($"fpmc.precursor_modifier_flg".isNull, 0).otherwise($"fpmc.precursor_modifier_flg"))
          .as("precursor_modifier_flg")
      )

    val assessQualsByDate = assessPrecursorMap.as("apm")
      .where($"apm.value_filter_id" === lit(VALUE_FILTER_ID_ALL_DATE))
      .groupBy($"apm.mpi", $"apm.client_id", $"apm.precursor_dtm".cast(DateType).as("precursor_dtm"), $"apm.precursor_id",$"precursor_type")
      .agg(
        first($"max_sensitive_ind").as("sensitive_ind"),
        max($"precursor_value").as("precursor_value"),
        bitOrAgg(when($"precursor_modifier_flg".isNull, lit(0)).otherwise($"precursor_modifier_flg")).as("precursor_modifier_flg"),
        listAgg($"cds_grp").as("precursor_cds_grp")
      )
      .withColumn("precursor_end_dtm", $"precursor_dtm")

    val assessQualsByDateTime = assessPrecursorMap.as("apm")
      .where($"value_filter_id" === lit(VALUE_FILTER_ID_ALL_DATETIME))
      .groupBy($"apm.mpi", $"apm.client_id", $"apm.precursor_dtm", $"precursor_id",$"precursor_type")
      .agg(
        first($"max_sensitive_ind").as("sensitive_ind"),
        max($"precursor_value").as("precursor_value"),
        bitOrAgg(when($"precursor_modifier_flg".isNull, lit(0)).otherwise($"precursor_modifier_flg")).as("precursor_modifier_flg"),
        listAgg($"cds_grp").as("precursor_cds_grp")
      )
      .withColumn("precursor_end_dtm", $"precursor_dtm")

    val assessQual = assessQualsByDate
      .union(assessQualsByDateTime)
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"precursor_dtm", $"mpi", $"precursor_id")
          .orderBy($"sensitive_ind".asc, $"precursor_value".desc, $"precursor_type".desc))
      )
      .groupBy($"mpi", $"client_id", $"precursor_dtm", $"precursor_end_dtm", $"precursor_id")
      .agg(
        bitOrAgg($"precursor_modifier_flg").as("precursor_modifier_flg"),
        max(when($"precedence_rank" === lit(1), $"precursor_value").otherwise(null))
          .as("precursor_value"),
        max(when($"precedence_rank" === lit(1), $"precursor_type").otherwise(null)).as("precursor_type"),
        listAgg($"precursor_cds_grp").as("precursor_cds_grp"),
        max($"sensitive_ind").as("sensitive_ind")
      )

      L3_PAT_PRECURSOR.columnSelect(assessQual, Precursors.DOMAIN_ASSESS, sparkSession)
  }
}

object TEMP_L3_PAT_PRECURSOR_MED extends TableInfo[l3_pat_precursor] {
  override def name: String = "TEMP_L3_PAT_PRECURSOR_MED"

  override def partitions: Int = 128

  override def dependsOn: Set[String] = Set("L2_PAT_MED", "L3_MAP_PRECURSOR_DCC", "L3_DICT_PRECURSOR", "L2_DICT_DCC",
    "REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI", "L3_MAP_PRECURSOR_MODIFIER", "L1_MAP_HTS_DCC")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL2PatMed = loadedDependencies("L2_PAT_MED").as[l2_pat_med]
    val l3MapPrecursorDcc = broadcast(loadedDependencies("L3_MAP_PRECURSOR_DCC").as[l3_map_precursor_dcc])
    val tL3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor].where($"active_ind" === lit(1)))
    val tL2DictDcc = broadcast(loadedDependencies("L2_DICT_DCC").as[l2_dict_dcc])
    val tL3MapPrecurCui = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI").as[l3_map_precur_cui])
    val tL3MapPrecursorModifier = broadcast(loadedDependencies("L3_MAP_PRECURSOR_MODIFIER").as[l3_map_precursor_modifier])
    val tL1MapHtsDcc = broadcast(loadedDependencies("L1_MAP_HTS_DCC").as[l1_map_hts_dcc])

    val dccRollup = tL2PatMed.as("pm")
      .join(l3MapPrecursorDcc.as("mpd"), Seq("dcc"))
      .join(tL2DictDcc.as("dd"), Seq("dcc"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .join(tL3MapPrecursorModifier,
        ($"pm.rxorder_ind" === lit(1) && $"precursor_modifier_cui" === Precursors.MODIFIER_CUI_MED_ORDERED) ||
          ($"pat_reported_ind" === lit(1) && $"precursor_modifier_cui" === Precursors.MODIFIER_CUI_MED_PATIENT_REPORTED) ||
          ($"pm.rxadmin_ind" === lit(1) && $"precursor_modifier_cui" === Precursors.MODIFIER_CUI_MED_ADMINISTERED),
        "left"
      )
      .where(
        ($"pm.rxorder_ind" === lit(1) || $"pm.pat_reported_ind" === lit(1) || $"pm.rxadmin_ind" === lit(1)) &&
          ($"mpd.exclude_hosp_ind" === lit(0) ||
            $"mpd.exclude_hosp_ind" === lit(1) && $"pm.hosp_ind" === lit(0))
      )
      .withColumn("max_sensitive_ind", when($"pm.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind").otherwise($"pm.sensitive_ind"))
      .drop("sensitive_ind")
      .select($"client_id", $"mpi", $"cds_grp".as("precursor_cds_grp"),
        $"rx_dtm".as("precursor_dtm"), $"rx_dtm".as("precursor_end_dtm"), $"precursor_id", $"precursor_modifier_flg",
        $"dcc".as("precursor_value"), $"max_sensitive_ind".as("sensitive_ind"))

    val cuiRollup = tL2PatMed.as("pm")
      .join(tL2DictDcc.as("dd"), Seq("dcc"))
      .join(tL1MapHtsDcc.as("mhd"), Seq("dcc"))
      .join(tL3MapPrecurCui.as("mpd"), $"mhd.hts_cui" === $"mpd.cui")
      .join(tL3DictPrecursor.where($"precursor_domain_cd" === lit(Precursors.DOMAIN_MED)).as("dp"), Seq("precursor_id"))
      .join(tL3MapPrecursorModifier,
        ($"rxorder_ind" === lit(1) && $"precursor_modifier_cui" === Precursors.MODIFIER_CUI_MED_ORDERED) ||
          ($"pat_reported_ind" === lit(1) && $"precursor_modifier_cui" === Precursors.MODIFIER_CUI_MED_PATIENT_REPORTED)||
          ($"rxadmin_ind" === lit(1) && $"precursor_modifier_cui" === Precursors.MODIFIER_CUI_MED_ADMINISTERED),
        "left"
      )
      .where(
        ($"pm.rxorder_ind" === lit(1) || $"pm.pat_reported_ind" === lit(1) || $"rxadmin_ind" === lit(1)) &&
          ($"mpd.exclude_hosp_ind" === lit(0) ||
            $"mpd.exclude_hosp_ind" === lit(1) && $"pm.hosp_ind" === lit(0))
      )
      .withColumn("max_sensitive_ind", when($"pm.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind").otherwise($"pm.sensitive_ind"))
      .drop("sensitive_ind")
      .select($"client_id", $"mpi", $"cds_grp".as("precursor_cds_grp"),
        $"rx_dtm".as("precursor_dtm"), $"rx_dtm".as("precursor_end_dtm"), $"precursor_id", $"precursor_modifier_flg",
        $"dcc".as("precursor_value"), $"max_sensitive_ind".as("sensitive_ind"))

    val grouped = dccRollup.union(cuiRollup)
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"precursor_dtm", $"mpi", $"client_id", $"precursor_id")
          .orderBy($"sensitive_ind".asc, $"precursor_value".desc)))
      .groupBy($"mpi", $"client_id", $"precursor_dtm", $"precursor_id")
      .agg(
        lit(Precursors.PRECURSOR_TYPE_MED_DCC).as("precursor_type"),
        first($"precursor_end_dtm").as("precursor_end_dtm"),
        max(when($"precedence_rank" === lit(1), $"precursor_value").otherwise(null)).as("precursor_value"),
        max(when($"precedence_rank" === lit(1), $"sensitive_ind").otherwise(null)).as("sensitive_ind"),
        listAgg($"precursor_cds_grp").as("precursor_cds_grp"),
        bitOrAgg($"precursor_modifier_flg").as("precursor_modifier_flg")
      )

    L3_PAT_PRECURSOR.columnSelect(grouped, Precursors.DOMAIN_MED, sparkSession)
  }
}

object TEMP_L3_PAT_PRECURSOR_PROC extends TableInfo[l3_pat_precursor] {
  override def name: String = "TEMP_L3_PAT_PRECURSOR_PROC"

  override def partitions: Int = 128

  override def dependsOn: Set[String] = Set("L3_MAP_PRECURSOR_PROC", "REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI",
    "L1_MAP_PROCEDURE_CUI", "L2_PAT_PROC", "L3_MAP_PRECURSOR_MODIFIER", "L3_DICT_PRECURSOR")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL3MapPrecursorProc = broadcast(loadedDependencies("L3_MAP_PRECURSOR_PROC").as[l3_map_precursor_proc])
    val tL3MapPrecurCui = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI").as[l3_map_precur_cui])
    val tL1MapProcedureCui = broadcast(loadedDependencies("L1_MAP_PROCEDURE_CUI").as[l1_map_procedure_cui])
    val tL2PatProc = loadedDependencies("L2_PAT_PROC").as[l2_pat_proc]
    val tL3MapPrecursorModifier = broadcast(loadedDependencies("L3_MAP_PRECURSOR_MODIFIER").as[l3_map_precursor_modifier])
    val tL3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor])

    val precursorModifierFlgLookup = tL3MapPrecursorModifier
      .where($"precursor_modifier_cui" === lit(Precursors.MODIFIER_CUI_PRINCIPAL_PROCEDURE))
      .select($"precursor_modifier_cui", $"precursor_modifier_flg").collect.map(row => (row.get(0), row.get(1))).toMap

    val tL2PatProcWithModifiers = tL2PatProc.flatMap(row => {
      val modifiers = List(Option(row.modifier_1), Option(row.modifier_2), Option(row.modifier_3), Option(row.modifier_4)).flatten
      if (row.code_type == Procedures.CODE_TYPE_CPT4 && modifiers.nonEmpty) {
        modifiers.map(modifier => row.copy(proc_cd = row.proc_cd + "-" + modifier, code_type = Procedures.CODE_TYPE_CPTMOD)) :+ row
      } else Seq(row)
    })
      .withColumn("precursor_modifier_flg", when($"principal_ind" === lit(1),
        lit(precursorModifierFlgLookup.getOrElse(Precursors.MODIFIER_CUI_PRINCIPAL_PROCEDURE,0))).otherwise(0)
      )

    val mapPrecurProcSource = proceduresFilter(sparkSession, precursorModifierFlgLookup,
      tL2PatProcWithModifiers.as("ppwm")
        .join(tL3MapPrecursorProc.as("mpp"), Seq("code_type", "proc_cd"))
        .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
        .withColumn("greatest_sensitive_ind", greatest($"dp.sensitive_ind", $"ppwm.sensitive_ind"))
    )

    val mapPrecurCuiSource = proceduresFilter(sparkSession, precursorModifierFlgLookup, tL2PatProcWithModifiers.as("ppwm")
      .join(tL1MapProcedureCui.as("mprocc"),
        $"ppwm.proc_cd" === $"mprocc.mappedcode" && $"ppwm.code_type" === $"mprocc.codetype")
      .join(tL3MapPrecurCui.as("mprecc").where($"precursor_domain_cd" === lit(Precursors.DOMAIN_PROC)), Seq("cui"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .withColumn("greatest_sensitive_ind", greatest($"dp.sensitive_ind", $"ppwm.sensitive_ind")))

    val combinedSources = mapPrecurProcSource.union(mapPrecurCuiSource)
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"precursor_dtm", $"precursor_end_dtm")
          .orderBy($"sensitive_ind".asc, $"precursor_value".desc))
      )
      .groupBy($"client_id", $"mpi", $"precursor_id", $"precursor_dtm", $"precursor_end_dtm")
      .agg(
        max(when($"precedence_rank" === lit(1), $"sensitive_ind").otherwise(null)).as("sensitive_ind"),
        max(when($"precedence_rank" === lit(1), $"precursor_type").otherwise(null)).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"precursor_value").otherwise(null)).as("precursor_value"),
        bitOrAgg($"precursor_modifier_flg").as("precursor_modifier_flg"),
        listAgg($"precursor_cds_grp").as("precursor_cds_grp")
      )

    L3_PAT_PRECURSOR.columnSelect(combinedSources, Precursors.DOMAIN_PROC, sparkSession)

  }

  private def proceduresFilter(sparkSession: SparkSession, precursorModifierFlgLookup: Map[Any, Any], df: DataFrame): DataFrame = {
    import sparkSession.implicits._

    df.where(
      !$"code_type".isin(Procedures.CODE_TYPE_CPTMOD, Procedures.CODE_TYPE_CPT4) ||
        (
          $"code_type" === Procedures.CODE_TYPE_CPT4
            && $"proc_cd".endsWith("F")
            && (!($"modifier_1".isNotNull && $"modifier_1".isin(Procedures.MODIFIERS:_*)
            || $"modifier_2".isNotNull && $"modifier_2".isin(Procedures.MODIFIERS:_*)
            || $"modifier_3".isNotNull && $"modifier_3".isin(Procedures.MODIFIERS:_*)
            || $"modifier_4".isNotNull && $"modifier_4".isin(Procedures.MODIFIERS:_*))
            )
          ) ||
        ($"code_type" === Procedures.CODE_TYPE_CPTMOD &&
          ($"modifier_1".isNotNull || $"modifier_2".isNotNull || $"modifier_3".isNotNull || $"modifier_4".isNotNull)) ||
        ($"code_type" === Procedures.CODE_TYPE_CPT4 && !$"proc_cd".endsWith("F"))
    ).select($"client_id", $"mpi", $"cds_grp".as("precursor_cds_grp"),
      $"proc_dtm".as("precursor_dtm"), $"proc_dtm".as("precursor_end_dtm"), $"precursor_id",
      $"code_type".as("precursor_type"), $"proc_cd".as("precursor_value"),
      $"greatest_sensitive_ind".as("sensitive_ind"), $"precursor_modifier_flg")
  }
}

object TEMP_L3_PAT_PRECURSOR_EVT extends TableInfo[l3_pat_precursor] {
  override def name: String = "TEMP_L3_PAT_PRECURSOR_EVT"

  override def partitions: Int = 128

  override def dependsOn: Set[String] = Set("L2_PAT_CLINICAL_EVENT", "L3_MAP_PRECURSOR_EVT_TYPE",
    "L3_MAP_PRECURSOR_EVT_DETAIL", "L3_MAP_PRECURSOR_PROC", "L3_MAP_PRECURSOR_DIAG", "L3_DICT_PRECURSOR",
    "L1_CLINICAL_EVENT_ENCOUNTER", "L1_DIAGNOSIS", "L2_DICT_DIAG", "L1_MAP_PREDICATE_VALUES", "L3_MAP_PRECURSOR_MODIFIER", "REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL2PatClinicalEvent = loadedDependencies("L2_PAT_CLINICAL_EVENT").as[l2_pat_clinical_event]
    val tL3MapPrecursorEvtType = broadcast(loadedDependencies("L3_MAP_PRECURSOR_EVT_TYPE").as[l3_map_precursor_evt_type])
    val l3MapPrecursorEvtDetail = broadcast(loadedDependencies("L3_MAP_PRECURSOR_EVT_DETAIL").as[l3_map_precursor_evt_detail])
    val tL3MapPrecursorProc = broadcast(loadedDependencies("L3_MAP_PRECURSOR_PROC").as[l3_map_precursor_proc])
    val tL3MapPrecursorDiag = broadcast(loadedDependencies("L3_MAP_PRECURSOR_DIAG").as[l3_map_precursor_diag])
    val tL3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor])
    val tL1ClinicalEventEncounter = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").as[l1_clinical_event_encounter]
    val l1Dignosis = loadedDependencies("L1_DIAGNOSIS").as[l1_diagnosis]
    val tL2DictDiag = loadedDependencies("L2_DICT_DIAG").as[l2_dict_diag]
    val tL1MapPredicateValues = loadedDependencies("L1_MAP_PREDICATE_VALUES").as[l1_map_predicate_values]
    val tL3MapPrecursorModifier = loadedDependencies("L3_MAP_PRECURSOR_MODIFIER").as[l3_map_precursor_modifier]
    val tL3MapPrecurCui = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI").as[l3_map_precur_cui])


    val baseEvents = tL2PatClinicalEvent.as("pce")
      .join(tL3MapPrecursorEvtType.as("mpet"), Seq("event_type_cui"))
      .where($"mpet.exclude_ip_convert_ind" === lit(0) ||
        ($"mpet.exclude_ip_convert_ind" === lit(1) && $"pce.convert_ip_ind" === 0))
      .join(l3MapPrecursorEvtDetail.as("mped"), Seq("precursor_id"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .select(
        $"pce.client_id", $"pce.mpi", $"precursor_id", $"pce.evt_start_dtm", $"pce.evt_end_dtm", $"pce.event_type_cui",
        $"pce.clinical_event_id", lit(0), $"pce.cds_grp", $"pce.disposition_cui",$"pce.admitsource_cui",$"pce.los", $"pce.hosp_site_id",
        when($"dp.sensitive_ind" > $"pce.sensitive_ind", $"dp.sensitive_ind").otherwise($"pce.sensitive_ind").as("sensitive_ind"),
        $"pce.prinpx", $"pce.prindx", $"pce.prinpx_codetype",
        $"mped.prinpx_precursor_id", $"mped.prindx_precursor_id", $"pce.prindx_codetype",
        lit(0).as("precursor_modifier_flg"), $"pce.drg_id".as("pce_drg_id"),
        $"mped.drg_id".as("mped_drg_id"), $"pce.apr_drg_id".as("pce_apr_drg_id"),
        $"mped.apr_drg_id".as("mped_apr_drg_id")
      )

    val prinpxEvents = baseEvents.as("be")
      .join(tL3MapPrecursorProc.as("mpp"), $"be.prinpx" === $"mpp.proc_cd" && $"be.prinpx_codetype" === $"mpp.code_type", "left")
      .where($"prinpx_precursor_id".isNull || $"mpp.proc_cd".isNotNull)
      .select(baseEvents.col("*"))

    val prindxEvents = baseEvents.as("be")
      .join(tL3MapPrecursorDiag.as("mpd"), $"be.prindx" === $"mpd.diag_cd" && $"be.prindx_codetype" === $"mpd.code_type", "left")
      .where($"prindx_precursor_id".isNull || $"mpd.diag_cd".isNotNull)
      .select(baseEvents.col("*"))

    val drgEvents = baseEvents
      .where(($"mped_drg_id".isNull || $"pce_drg_id" === $"mped_drg_id") && ($"mped_apr_drg_id".isNull || $"pce_apr_drg_id" === $"mped_apr_drg_id"))
      .select(baseEvents.col("*"))

    val groupedSource = prinpxEvents.union(prindxEvents).union(drgEvents).distinct()

    val eventsWithValidPoa = groupedSource.where($"event_type_cui" === lit(Precursors.EVT_TYPE_CUI_INPATIENT)).as("gs")
      .join(tL1ClinicalEventEncounter.as("cee"), $"gs.clinical_event_id" === $"cee.encounter_grp_num")
      .join(l1Dignosis.where($"hosp_dx_flag" === lit("Y")).as("diag"), Seq("encounterid","client_ds_id","mpi"))
      .join(tL2DictDiag.as("dd"), ($"dd.diag_cd" === $"diag.mappeddiagnosis") && ($"dd.code_type" === $"diag.codetype"))
      .join(tL1MapPredicateValues.as("mpv"),$"mpv.client_ds_id" === $"cee.client_ds_id" &&
        $"mpv.data_src" === lit("OADW") &&
        $"mpv.entity" === lit("DIAGNOSIS") &&
        $"mpv.table_name" === lit("DIAGNOSIS_BL_POA") &&
        $"mpv.column_name" === lit("DATASRC") &&
        (($"mpv.column_value" === lit("ALL")) || ($"mpv.column_value" === $"diag.datasrc")),
        "left"
      )
      .where($"gs.event_type_cui" === lit(Precursors.EVT_TYPE_CUI_INPATIENT) && $"mpv.column_name".isNull && $"diag.hosp_dx_flag" === lit("Y"))
      .select("clinical_event_id").distinct()
      .withColumn("valid_poa_ind", lit(1))

    val precursorModifierFlgLookup = tL3MapPrecursorModifier.where($"precursor_modifier_cui".isin(
      Precursors.MODIFIER_CUI_VALID_PRESENT_ON_ADMISSION,
      Precursors.MODIFIER_CUI_FOR_MORALITY,
      Precursors.MODIFIER_CUI_PATIENT_LEFT_AMA,
      Precursors.MODIFIER_CUI_LOS,
      Precursors.MODIFIER_CUI_ADMITSOURCE,
      Precursors.MODIFIER_CUI_TRANSFER)
    ).select($"precursor_modifier_cui", $"precursor_modifier_flg")
      .collect.map(row => (row.getString(0), new Integer(row.getInt(1)))).toMap

    val mortality_disposition_cui = tL3MapPrecurCui.where($"precursor_id" === lit(2)).select($"cui".cast(StringType)).collect.map(_.get(0)).toList

    val precursorsWithModifiers = groupedSource.as("gs1")
      .join(eventsWithValidPoa.as("ewvpoa"), Seq("clinical_event_id"), "left")
      .withColumn("precursor_modifier_flg",
          lit(when($"valid_poa_ind" === lit(1), lit(precursorModifierFlgLookup.getOrElse(Precursors.MODIFIER_CUI_VALID_PRESENT_ON_ADMISSION,0))).otherwise(0))  +
          lit(when($"disposition_cui".isin(mortality_disposition_cui:_*) && $"event_type_cui" === lit(Precursors.EVT_TYPE_CUI_INPATIENT) , lit(precursorModifierFlgLookup.getOrElse(Precursors.MODIFIER_CUI_FOR_MORALITY,0))).otherwise(0)) +
          lit(when($"disposition_cui" === lit("CH000066") && $"event_type_cui" === lit(Precursors.EVT_TYPE_CUI_INPATIENT) , lit(precursorModifierFlgLookup.getOrElse(Precursors.MODIFIER_CUI_PATIENT_LEFT_AMA,0))).otherwise(0)) +
          lit(when( $"los".gt(lit(365)) && $"event_type_cui" === lit(Precursors.EVT_TYPE_CUI_INPATIENT), lit(precursorModifierFlgLookup.getOrElse(Precursors.MODIFIER_CUI_LOS,0))).otherwise(0)) +
          lit(when( $"admitsource_cui" === lit("CH000616") && $"event_type_cui" === lit(Precursors.EVT_TYPE_CUI_INPATIENT), lit(precursorModifierFlgLookup.getOrElse(Precursors.MODIFIER_CUI_ADMITSOURCE,0))).otherwise(0))
      ).select(
      $"clinical_event_id",$"client_id", $"precursor_id",$"evt_start_dtm",$"evt_end_dtm",$"event_type_cui",$"cds_grp",$"hosp_site_id", $"sensitive_ind",$"mpi" ,$"precursor_modifier_flg"
    ).toDF()

    val inpatientPrecurosrsWithModifiers = precursorsWithModifiers.where($"event_type_cui" === lit(Precursors.EVT_TYPE_CUI_INPATIENT)).distinct

    val precursorsEligibleforTransfer = inpatientPrecurosrsWithModifiers.as("ce1")
      .join(inpatientPrecurosrsWithModifiers.select(
        $"clinical_event_id",$"client_id", $"precursor_id",$"evt_start_dtm",$"evt_end_dtm",$"mpi",$"hosp_site_id"
      ).distinct.as("ce2") ,
        ($"ce1.mpi" === $"ce2.mpi" and
          $"ce1.clinical_event_id" =!= $"ce2.clinical_event_id" and
          $"ce1.hosp_site_id" =!= $"ce2.hosp_site_id")  and
          datediff($"ce1.evt_start_dtm", $"ce2.evt_end_dtm").between(0,1) )


    val EligibleprecursorForTransferWithDifferentStartandEndDate = precursorsEligibleforTransfer.where(
                datediff( $"ce1.evt_end_dtm", $"ce2.evt_end_dtm").geq(1) ||
                  datediff( $"ce1.evt_start_dtm", $"ce2.evt_start_dtm").geq(1)  ||
                  (to_timestamp($"ce1.evt_end_dtm").cast(LongType) -  to_timestamp($"ce2.evt_end_dtm").cast(LongType)) >= 1 )
              .select($"ce1.clinical_event_id")

   val precursorWithTransferModifierForSameStartDateandEndDate =  precursorsEligibleforTransfer.where(($"ce1.evt_start_dtm" === $"ce2.evt_start_dtm" ) && ( $"ce1.evt_end_dtm" === $"ce2.evt_end_dtm") )
       .select($"ce1.clinical_event_id", $"ce2.clinical_event_id" ,$"ce1.evt_start_dtm" , $"ce2.evt_start_dtm" , $"ce1.evt_end_dtm" , $"ce2.evt_end_dtm" , $"ce1.mpi", $"ce2.mpi" )

    val precursorWithTransferModifierForSameStartDateandEndDate1 = precursorWithTransferModifierForSameStartDateandEndDate.distinct().select($"ce1.*")
    val precursorWithTransferModifierForSameStartDateandEndDate2 = precursorWithTransferModifierForSameStartDateandEndDate.distinct().select($"ce2.*")
      val EligibleprecursorForTransferWithSameStartandEndDate = precursorWithTransferModifierForSameStartDateandEndDate1.union(precursorWithTransferModifierForSameStartDateandEndDate2).distinct()
        .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"evt_start_dtm", $"evt_end_dtm" , $"mpi")
          .orderBy( $"clinical_event_id".desc))
      ).where($"precedence_rank" === lit(1)).select($"clinical_event_id")

    val precursorsWithModifierWithTransfer = EligibleprecursorForTransferWithDifferentStartandEndDate.union(EligibleprecursorForTransferWithSameStartandEndDate).distinct()

    val precursorsWithModifierwithTransferWithIndicator = precursorsWithModifierWithTransfer
        .withColumn("valid_event_for_transfer_exclusions", lit(1))


    val finalprecursors = precursorsWithModifiers.as("pwm")
      .join(precursorsWithModifierwithTransferWithIndicator, Seq("clinical_event_id"), "left")
      .withColumn("precursor_modifier_flg",
        lit(when($"valid_event_for_transfer_exclusions" === lit(1), lit($"pwm.precursor_modifier_flg") + lit(precursorModifierFlgLookup.getOrElse(Precursors.MODIFIER_CUI_TRANSFER,0))).otherwise($"pwm.precursor_modifier_flg"))  )
        .drop("pwm.precursor_modifier_flg", "valid_event_for_transfer_exclusions")

    val groupedEvents = finalprecursors
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"precursor_id", $"mpi", $"evt_start_dtm", $"evt_end_dtm")
          .orderBy($"sensitive_ind".asc, $"clinical_event_id".desc))
      )
      .groupBy($"client_id", $"precursor_id", $"mpi", $"evt_start_dtm".as("precursor_dtm"), $"evt_end_dtm".as("precursor_end_dtm"))
      .agg(
        max(when($"precedence_rank" === lit(1), $"event_type_cui").otherwise(null)).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"clinical_event_id").otherwise(null)).as("precursor_value"),
        bitOrAgg($"precursor_modifier_flg").as("precursor_modifier_flg"),
        listAgg($"cds_grp").as("precursor_cds_grp"),
        max(when($"precedence_rank" === lit(1), $"sensitive_ind").otherwise(null)).as("sensitive_ind")
      )

    L3_PAT_PRECURSOR.columnSelect(groupedEvents, Precursors.DOMAIN_EVT, sparkSession)
  }
}

object TEMP_L3_PAT_PRECURSOR_SPEC extends TableInfo[l3_pat_precursor] {
  override def name: String = "TEMP_L3_PAT_PRECURSOR_SPEC"

  override def dependsOn: Set[String] = Set("L2_PAT_PROC", "REFERENCE_SCHEMA_L3_MAP_PRECUR_SPEC",
    "L2_PAT_CLINICAL_EVENT_PROV", "L2_PROVIDER_INFO", "L2_PAT_CLINICAL_EVENT", "L3_DICT_PRECURSOR")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL2PatProc = loadedDependencies("L2_PAT_PROC").as[l2_pat_proc]
    val tL3MapPrecurSpec = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECUR_SPEC").as[l3_map_precur_spec])
    val tL2PatClinicalEventProv = loadedDependencies("L2_PAT_CLINICAL_EVENT_PROV").as[l2_pat_clinical_event_prov]
    val tL2ProviderInfo = loadedDependencies("L2_PROVIDER_INFO").as[l2_provider_info]
    val tL2PatClinicalEvent = loadedDependencies("L2_PAT_CLINICAL_EVENT").as[l2_pat_clinical_event]
    val tL3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor])

    val visitPrecursors = tL2PatClinicalEventProv.as("pcep")
      .where($"prov_role_cui" =!= Procedures.REFERRING_PROVIDER_ROLE_CUI)
      .join(tL2PatClinicalEvent.as("pce"), Seq("clinical_event_id"))
      .join(tL2ProviderInfo.as("pi"), Seq("prov_id"))
      .join(tL3MapPrecurSpec.as("mps"), Seq("specialty_id"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .select($"pcep.client_id", $"mpi", $"precursor_id", $"prov_role_dtm".as("precursor_dtm"),
        $"prov_role_dtm".as("precursor_end_dtm"), $"pcep.cds_grp".as("cds_grp"),
        lit(0).as("precursor_modifier_flg"), lit(Precursors.DOMAIN_SPEC).as("precursor_type"),
        $"specialty_id".as("precursor_value"), $"dp.sensitive_ind")

    val serviceProviderPrecursors = tL2PatProc.as("pp")
      .join(tL2ProviderInfo.as("pi"), Seq("prov_id"))
      .join(tL3MapPrecurSpec.as("mps"), Seq("specialty_id"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .select($"pp.client_id", $"mpi", $"precursor_id", $"proc_dtm".as("precursor_dtm"),
        $"proc_dtm".as("precursor_end_dtm"), $"pp.cds_grp".as("cds_grp"),
        lit(0).as("precursor_modifier_flg"), lit(Precursors.DOMAIN_SPEC).as("precursor_type"),
        $"specialty_id".as("precursor_value"), $"dp.sensitive_ind")


    val combinedSpecPrecursors = visitPrecursors.union(serviceProviderPrecursors)
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"precursor_dtm")
          .orderBy($"dp.sensitive_ind".asc, $"precursor_value".desc))
      )
      .groupBy($"client_id", $"mpi", $"precursor_id", $"precursor_dtm", $"sensitive_ind")
      .agg(
        max(when($"precedence_rank" === lit(1), $"precursor_dtm").otherwise(null)).as("precursor_end_dtm"),
        listAgg($"cds_grp").as("precursor_cds_grp"),
        lit(Precursors.DOMAIN_SPEC).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"precursor_value").otherwise(null)).as("precursor_value"),
        lit(0).as("precursor_modifier_flg")
      )

    L3_PAT_PRECURSOR.columnSelect(combinedSpecPrecursors, Precursors.DOMAIN_SPEC, sparkSession)
  }
}

object TEMP_L3_PAT_PRECURSOR_POS extends TableInfo[l3_pat_precursor] {
  override def name: String = "TEMP_L3_PAT_PRECURSOR_POS"

  override def dependsOn: Set[String] = Set("L2_PAT_PROC", "REFERENCE_SCHEMA_L3_MAP_PRECUR_POS", "L3_DICT_PRECURSOR")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL2PatProc = loadedDependencies("L2_PAT_PROC").as[l2_pat_proc]
    val tL3MapPrecurPos = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECUR_POS").as[l3_map_precur_pos])
    val tL3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor])

    val posPrecursors = tL2PatProc.as("pp")
      .join(tL3MapPrecurPos.as("mpp"), Seq("place_of_svc"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .withColumn("greatest_sensitive_ind", greatest($"dp.sensitive_ind", $"pp.place_of_svc_sensitive_ind"))
      .select($"pp.client_id", $"mpi", $"cds_grp", $"proc_dtm", $"precursor_id", $"proc_cd",
        $"pp.place_of_svc_sensitive_ind", $"pp.place_of_svc", $"greatest_sensitive_ind".as("sensitive_ind"))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"proc_dtm")
          .orderBy($"pp.place_of_svc_sensitive_ind".asc, $"pp.place_of_svc".desc))
      )
      .groupBy($"pp.client_id", $"mpi", $"precursor_id", $"proc_dtm".as("precursor_dtm"))
      .agg(
        max(when($"precedence_rank" === lit(1), $"proc_dtm").otherwise(null)).as("precursor_end_dtm"),
        listAgg($"cds_grp").as("precursor_cds_grp"),
        lit(Precursors.DOMAIN_POS).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"pp.place_of_svc").otherwise(null)).as("precursor_value"),
        lit(0).as("precursor_modifier_flg"),
        max(when($"precedence_rank" === lit(1), $"sensitive_ind").otherwise(null)).as("sensitive_ind")
      )

    L3_PAT_PRECURSOR.columnSelect(posPrecursors, Precursors.DOMAIN_POS, sparkSession)
  }
}

object TEMP_L3_PAT_PRECURSOR_OTHERS extends TableInfo[l3_pat_precursor] {
  override def name: String = "TEMP_L3_PAT_PRECURSOR_OTHERS"

  override def dependsOn: Set[String] = Set("L2_PATIENT_INFO", "L2_PAT_CLINICAL_EVENT", "L3_DICT_PRECURSOR", "REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI",
    "L1_ENCOUNTERCAREAREA", "L2_MAP_CDS_FLG", "L1_MAP_CARE_AREA", "L1_MAP_SERVICE", "L2_PAT_IMMUNIZATION", "L1_MAP_HTS_DCC",
    "L2_PAT_ALLERGY", "L2_DICT_DCC", "REFERENCE_SCHEMA_L3_MAP_PRECUR_PCC", "L2_PAT_HM_DEFERRED", "REFERENCE_SCHEMA_L3_MAP_PRECUR_HM_DEFER")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tL2PatientInfo = loadedDependencies("L2_PATIENT_INFO").as[l2_patient_info]
    val tL2PatClinicalEvent = loadedDependencies("L2_PAT_CLINICAL_EVENT").as[l2_pat_clinical_event]
    val tL3DictPrecursor = broadcast(loadedDependencies("L3_DICT_PRECURSOR").as[l3_dict_precursor])
    val tL3MapPrecurCui = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECUR_CUI").as[l3_map_precur_cui])
    val tL1EncounterCareArea = loadedDependencies("L1_ENCOUNTERCAREAREA").as[l1_encountercarearea]
    val tL2MapCdsFlg = broadcast(loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg])
    val l1MapCareArea = broadcast(loadedDependencies("L1_MAP_CARE_AREA").as[l1_map_care_area])
    val l1MapService = broadcast(loadedDependencies("L1_MAP_SERVICE").as[l1_map_service])
    val tL2PatImmunization = loadedDependencies("L2_PAT_IMMUNIZATION").as[l2_pat_immunization]
    val tL1MapHtsDcc = broadcast(loadedDependencies("L1_MAP_HTS_DCC").as[l1_map_hts_dcc])
    val tL2PatAllergy = loadedDependencies("L2_PAT_ALLERGY").as[l2_pat_allergy]
    val tL2DictDcc = broadcast(loadedDependencies("L2_DICT_DCC").as[l2_dict_dcc])
    val tL3MapPrecurPcc = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECUR_PCC").as[l3_map_precur_pcc])
    val tL2PatHmDeferred = loadedDependencies("L2_PAT_HM_DEFERRED").as[l2_pat_hm_deferred]
    val tL3MapPrecurHmDefer = broadcast(loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECUR_HM_DEFER").as[l3_map_precur_hm_defer])

    val dodPrecursors = generateDodPrecursors(sparkSession, tL2PatientInfo).as[l3_pat_precursor]
    val dispPrecursors = generateDispPrecursors(sparkSession, tL2PatClinicalEvent, tL3DictPrecursor, tL3MapPrecurCui).as[l3_pat_precursor]
    val carePrecursors = generateCarePrecursors(sparkSession, tL1EncounterCareArea, tL3MapPrecurCui, tL3DictPrecursor, tL2MapCdsFlg, l1MapCareArea).as[l3_pat_precursor]
    val hospSvcPrecursors = generateHospSvcPrecursors(sparkSession, tL1EncounterCareArea, tL3MapPrecurCui, tL3DictPrecursor, tL2MapCdsFlg, l1MapService).as[l3_pat_precursor]
    val immPrecursors = generateImmPrecursors(sparkSession, tL2PatImmunization, tL3MapPrecurCui, tL3DictPrecursor, tL1MapHtsDcc).as[l3_pat_precursor]
    val allergyMedPrecursors = generateAllergyMedPrecursors(sparkSession, tL2PatAllergy, tL3MapPrecurCui, tL3MapPrecurPcc, tL3DictPrecursor, tL2DictDcc, tL1MapHtsDcc).as[l3_pat_precursor]
    val allergyPrecursors = generateAllergyPrecursors(sparkSession, tL2PatAllergy, tL3MapPrecurCui, tL3DictPrecursor).as[l3_pat_precursor]
    val deferPrecursors = generateDeferPrecursors(sparkSession, tL2PatHmDeferred, tL3MapPrecurHmDefer, tL3DictPrecursor).as[l3_pat_precursor]

    dodPrecursors
      .union(dispPrecursors)
      .union(carePrecursors)
      .union(hospSvcPrecursors)
      .union(immPrecursors)
      .union(allergyMedPrecursors)
      .union(allergyPrecursors)
      .union(deferPrecursors)
      .toDF()
  }

  private def generateDeferPrecursors(sparkSession: SparkSession,
                                      tL2PatHmDeferred: Dataset[l2_pat_hm_deferred],
                                      tL3MapPrecurHmDefer: Dataset[l3_map_precur_hm_defer],
                                      tL3DictPrecursor: Dataset[l3_dict_precursor]): DataFrame = {
    import sparkSession.implicits._

    val dccCuis = tL2PatHmDeferred.as("phd")
      .join(tL3MapPrecurHmDefer, Seq("dcc", "defer_rsn_cui"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .select($"client_id", $"mpi", $"precursor_id", $"deferral_dtm",
        when($"phd.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind")
          .otherwise($"phd.sensitive_ind")
          .as("sensitive_ind"), $"precursor_type",
        $"defer_rsn_cui", $"cds_grp")

    val hmTypeCuis = tL2PatHmDeferred.as("phd")
      .join(tL3MapPrecurHmDefer, Seq("hm_type_cui", "defer_rsn_cui"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .select($"client_id", $"mpi", $"precursor_id", $"deferral_dtm",
        when($"phd.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind")
          .otherwise($"phd.sensitive_ind")
          .as("sensitive_ind"), $"precursor_type",
        $"defer_rsn_cui", $"cds_grp")

    val grouped = dccCuis.union(hmTypeCuis)
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"deferral_dtm")
          .orderBy($"sensitive_ind".asc, $"defer_rsn_cui".desc))
      )
      .groupBy($"client_id", $"mpi", $"precursor_id", $"deferral_dtm".as("precursor_dtm"), $"sensitive_ind")
      .agg(
        max(when($"precedence_rank" === lit(1), $"deferral_dtm").otherwise(null)).as("precursor_end_dtm"),
        listAgg($"cds_grp").as("precursor_cds_grp"),
        max(when($"precedence_rank" === lit(1), $"precursor_type").otherwise(null)).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"defer_rsn_cui").otherwise(null)).as("precursor_value"),
        lit(64).as("precursor_modifier_flg")
      )

    L3_PAT_PRECURSOR.columnSelect(grouped, Precursors.DOMAIN_DEFER, sparkSession)
  }

  private def generateAllergyPrecursors(sparkSession: SparkSession,
                                        tL2PatAllergy: Dataset[l2_pat_allergy],
                                        tL3MapPrecurCui: Dataset[l3_map_precur_cui],
                                        tL3DictPrecursor: Dataset[l3_dict_precursor]): DataFrame = {
    import sparkSession.implicits._
    val allergyPrecursors = tL2PatAllergy.as("pa")
      .join(tL3MapPrecurCui.where($"precursor_domain_cd" === lit(Precursors.DOMAIN_ALLERGY)).as("mpc"), $"pa.allergencd_cui" === $"mpc.cui")
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"onset_dt")
          .orderBy($"dp.sensitive_ind".asc, $"allergencd_cui".desc))
      )
      .groupBy($"pa.client_id", $"mpi", $"precursor_id", $"onset_dt".as("precursor_dtm"), $"dp.sensitive_ind")
      .agg(
        max(when($"precedence_rank" === lit(1), $"onset_dt").otherwise(null)).as("precursor_end_dtm"),
        listAgg($"cds_grp").as("precursor_cds_grp"),
        lit(Precursors.PRECURSOR_TYPE_CUI_ALLERGY).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"allergencd_cui").otherwise(null)).as("precursor_value"),
        lit(0).as("precursor_modifier_flg")
      )

    L3_PAT_PRECURSOR.columnSelect(allergyPrecursors, Precursors.DOMAIN_ALLERGY, sparkSession)
  }

  private def generateAllergyMedPrecursors(sparkSession: SparkSession,
                                           tL2PatAllergy: Dataset[l2_pat_allergy],
                                           tL3MapPrecurCui: Dataset[l3_map_precur_cui],
                                           tL3MapPrecurPcc: Dataset[l3_map_precur_pcc],
                                           tL3DictPrecursor: Dataset[l3_dict_precursor],
                                           tL2DictDcc: Dataset[l2_dict_dcc],
                                           tL1MapHtsDcc: Dataset[l1_map_hts_dcc]): DataFrame = {
    import sparkSession.implicits._

    val dccPccLookup = tL2DictDcc.as("dd").groupBy($"pcc").agg(max($"sensitive_ind").as("sensitive_ind"))

    val allergyMedPccPrecursors = tL2PatAllergy.as("pa")
      .join(tL3MapPrecurPcc.as("mpp"), Seq("pcc"))
      .join(dccPccLookup.as("dpl"), Seq("pcc"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"onset_dt")
          .orderBy(when($"dpl.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind")
            .otherwise($"dpl.sensitive_ind").asc, $"pcc".desc))
      )
      .groupBy($"pa.client_id", $"mpi", $"precursor_id", $"onset_dt".as("precursor_dtm"))
      .agg(
        max(when($"precedence_rank" === lit(1), $"onset_dt").otherwise(null)).as("precursor_end_dtm"),
        listAgg($"cds_grp").as("precursor_cds_grp"),
        lit(Precursors.PRECURSOR_TYPE_MED_PCC).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"pcc").otherwise(null)).as("precursor_value"),
        max(when($"precedence_rank" === lit(1),
          when($"dpl.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind").otherwise($"dpl.sensitive_ind")
        ).otherwise(null)).as("sensitive_ind"),
        lit(0).as("precursor_modifier_flg")
      )

    val allergyMedDccPrecursors = tL2PatAllergy.as("pa")
      .join(tL2DictDcc.as("dd"), Seq("dcc"))
      .join(tL1MapHtsDcc.as("mhd"), Seq("dcc"))
      .join(tL3MapPrecurCui.as("mpc").where($"precursor_domain_cd" === lit(Precursors.DOMAIN_ALLERGY_MED)), $"mhd.hts_cui" === $"mpc.cui")
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"onset_dt")
          .orderBy(when($"dd.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind")
            .otherwise($"dd.sensitive_ind").asc, $"dcc".desc))
      )
      .groupBy($"pa.client_id", $"mpi", $"precursor_id", $"onset_dt".as("precursor_dtm"))
      .agg(
        max(when($"precedence_rank" === lit(1), $"onset_dt").otherwise(null)).as("precursor_end_dtm"),
        listAgg($"cds_grp").as("precursor_cds_grp"),
        lit(Precursors.PRECURSOR_TYPE_MED_DCC).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"dcc").otherwise(null)).as("precursor_value"),
        max(when($"precedence_rank" === lit(1),
          when($"dd.sensitive_ind" < $"dp.sensitive_ind", $"dp.sensitive_ind")
            .otherwise($"dd.sensitive_ind")
        ).otherwise(null)).as("sensitive_ind"),
        lit(0).as("precursor_modifier_flg")
      )

    val combined = allergyMedDccPrecursors
      .union(allergyMedPccPrecursors)
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"precursor_dtm", $"precursor_end_dtm")
          .orderBy($"sensitive_ind".asc, $"precursor_value".desc))
      )
      .where($"precedence_rank" === lit(1))

    L3_PAT_PRECURSOR.columnSelect(combined, Precursors.DOMAIN_ALLERGY_MED, sparkSession)
  }

  private def generateImmPrecursors(sparkSession: SparkSession,
                                    tL2PatImmunization: Dataset[l2_pat_immunization],
                                    tL3MapPrecurCui: Dataset[l3_map_precur_cui],
                                    tL3DictPrecursor: Dataset[l3_dict_precursor],
                                    tL1MapHtsDcc: Dataset[l1_map_hts_dcc]): DataFrame = {
    import sparkSession.implicits._

    val immPrecursors = tL2PatImmunization.as("pi")
      .join(tL1MapHtsDcc.as("mhd"), $"mhd.dcc" === $"pi.imm_cd")
      .join(tL3MapPrecurCui.where($"precursor_domain_cd" === lit(Precursors.DOMAIN_IMM)).as("mpc"), $"mhd.hts_cui" === $"mpc.cui")
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"imm_dt")
          .orderBy($"dp.sensitive_ind".asc, $"imm_cd".desc))
      )
      .groupBy($"pi.client_id", $"mpi", $"precursor_id", $"imm_dt".as("precursor_dtm"))
      .agg(
        max(when($"precedence_rank" === lit(1), $"imm_dt").otherwise(null)).as("precursor_end_dtm"),
        listAgg($"cds_grp").as("precursor_cds_grp"),
        lit(Precursors.PRECURSOR_TYPE_MED_DCC).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"imm_cd").otherwise(null)).as("precursor_value"),
        max(when($"precedence_rank" === lit(1), $"dp.sensitive_ind").otherwise(null)).as("sensitive_ind"),
        lit(0).as("precursor_modifier_flg")
      )

    L3_PAT_PRECURSOR.columnSelect(immPrecursors, Precursors.DOMAIN_IMM, sparkSession)
  }

  private def generateHospSvcPrecursors(sparkSession: SparkSession,
                                        tL1EncounterCareArea: Dataset[l1_encountercarearea],
                                        tL3MapPrecurCui: Dataset[l3_map_precur_cui],
                                        tL3DictPrecursor: Dataset[l3_dict_precursor],
                                        tL2MapCdsFlg: Dataset[l2_map_cds_flg],
                                        l1MapService: Dataset[l1_map_service]): DataFrame = {
    import sparkSession.implicits._

    val hospSvcPrecursors = tL1EncounterCareArea.where($"mpi".isNotNull).as("eca")
      .join(l1MapService.as("ms"), $"ms.client_id" === $"eca.client_id" && $"ms.local_code" === $"eca.servicecode")
      .join(tL3MapPrecurCui.where($"precursor_domain_cd" === lit(Precursors.DOMAIN_HOSP_SVC)).as("mpc"), Seq("cui"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .join(tL2MapCdsFlg.as("mcf"), Seq("client_ds_id"))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy( $"eca.mpi", $"precursor_id", coalesce($"careareastart_dtm", $"encounter_dtm"))
          .orderBy($"sensitive_ind".asc, $"cui".desc))
      )
      .groupBy($"eca.client_id", $"mpi", $"precursor_id", coalesce($"careareastart_dtm", $"encounter_dtm").as("precursor_dtm"))
      .agg(
        max(coalesce($"careareaend_dtm", $"careareastart_dtm", $"encounter_dtm")).as("precursor_end_dtm"),
        listAgg($"eca.client_ds_id").as("precursor_cds_grp"),
        lit(Precursors.PRECURSOR_TYPE_CUI_HOSP_SVC).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"cui").otherwise(null)).as("precursor_value"),
        max(when($"precedence_rank" === lit(1), $"sensitive_ind").otherwise(null)).as("sensitive_ind"),
        lit(0).as("precursor_modifier_flg")
      )

    L3_PAT_PRECURSOR.columnSelect(hospSvcPrecursors, Precursors.DOMAIN_HOSP_SVC, sparkSession)
  }

  private def generateCarePrecursors(sparkSession: SparkSession,
                                     tL1EncounterCareArea: Dataset[l1_encountercarearea],
                                     tL3MapPrecurCui: Dataset[l3_map_precur_cui],
                                     tL3DictPrecursor: Dataset[l3_dict_precursor],
                                     tL2MapCdsFlg: Dataset[l2_map_cds_flg],
                                     l1MapCareArea: Dataset[l1_map_care_area]): DataFrame = {
    import sparkSession.implicits._

    val carePrecursors = tL1EncounterCareArea.where($"mpi".isNotNull).as("eca")
      .join(l1MapCareArea.as("mca"), $"mca.client_id" === $"eca.client_id" && $"mca.local_code" === $"eca.localcareareacode")
      .join(tL3MapPrecurCui.as("mpc").where($"precursor_domain_cd" === lit(Precursors.DOMAIN_CARE)), Seq("cui"))
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .join(tL2MapCdsFlg.as("mcf"), Seq("client_ds_id"))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", coalesce($"careareastart_dtm", $"encounter_dtm"))
          .orderBy($"sensitive_ind".asc, $"cui".desc))
      )
      .groupBy($"eca.client_id", $"mpi", $"precursor_id", coalesce($"careareastart_dtm", $"encounter_dtm").as("precursor_dtm"))
      .agg(
        max(coalesce($"careareaend_dtm", $"careareastart_dtm", $"encounter_dtm")).as("precursor_end_dtm"),
        listAgg($"eca.client_ds_id").as("precursor_cds_grp"),
        lit(Precursors.PRECURSOR_TYPE_CUI_CARE).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"cui").otherwise(null)).as("precursor_value"),
        max(when($"precedence_rank" === lit(1), $"sensitive_ind").otherwise(null)).as("sensitive_ind"),
        lit(0).as("precursor_modifier_flg")
      )

    L3_PAT_PRECURSOR.columnSelect(carePrecursors, Precursors.DOMAIN_CARE, sparkSession)
  }

  private def generateDispPrecursors(sparkSession: SparkSession,
                                     tL2PatClinicalEvent: Dataset[l2_pat_clinical_event],
                                     tL3DictPrecursor: Dataset[l3_dict_precursor],
                                     tL3MapPrecurCui: Dataset[l3_map_precur_cui]): DataFrame = {
    import sparkSession.implicits._

    val dispPrecursors = tL2PatClinicalEvent.as("pce")
      .join(tL3MapPrecurCui.where($"precursor_domain_cd" === lit(Precursors.DOMAIN_DISP)).as("mpc"), $"pce.disposition_cui" === $"mpc.cui")
      .join(tL3DictPrecursor.as("dp"), Seq("precursor_id"))
      .withColumn("precedence_rank",
        row_number.over(Window.partitionBy($"mpi", $"precursor_id", $"evt_end_dtm")
          .orderBy($"dp.sensitive_ind".asc, $"pce.disposition_cui".desc))
      )
      .groupBy($"client_id", $"mpi", $"precursor_id", $"evt_end_dtm".as("precursor_dtm"))
      .agg(
        $"evt_end_dtm".as("precursor_end_dtm"),
        listAgg($"cds_grp").as("precursor_cds_grp"),
        lit(Precursors.PRECURSOR_TYPE_CUI_DISP).as("precursor_type"),
        max(when($"precedence_rank" === lit(1), $"pce.disposition_cui").otherwise(null)).as("precursor_value"),
        max(when($"precedence_rank" === lit(1), $"dp.sensitive_ind").otherwise(null)).as("sensitive_ind"),
        lit(0).as("precursor_modifier_flg")
      )

    L3_PAT_PRECURSOR.columnSelect(dispPrecursors, Precursors.DOMAIN_DISP, sparkSession)
  }

  private def generateDodPrecursors(sparkSession: SparkSession,
                                    tL2PatientInfo: Dataset[l2_patient_info]): DataFrame = {
    import sparkSession.implicits._

    val deaths = tL2PatientInfo.where($"dod".isNotNull)
      .select(
        $"client_id", $"mpi",
        lit(Precursors.ID_DEATH).as("precursor_id"),
        $"dod".as("precursor_dtm"),
        $"dod".as("precursor_end_dtm"),
        lit(0).as("precursor_cds_grp"),
        lit(0).as("precursor_modifier_flg"),
        lit(0).as("sensitive_ind"),
        $"death_ind_cui".as("precursor_value"),
        lit(Precursors.PRECURSOR_TYPE_CUI_DOD).as("precursor_type")
      )

    L3_PAT_PRECURSOR.columnSelect(deaths, Precursors.DOMAIN_DOD, sparkSession)
  }
}

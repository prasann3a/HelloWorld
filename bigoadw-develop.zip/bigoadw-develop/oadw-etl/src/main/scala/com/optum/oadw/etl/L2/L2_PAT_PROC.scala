package com.optum.oadw.etl.L2
import java.sql.Timestamp

import com.optum.oadw.definedfunctions.{BitOrAggFunction, ListAgg}
import com.optum.oadw.oadwModels._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, IntegerType, LongType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object L2_PAT_PROC extends TableInfo[l2_pat_proc] {
  override def name: String = "L2_PAT_PROC"

  override def dependsOn: Set[String] = Set("TEMP_TOS_CLAIM", "TEMP_TOS_PROCEDUREDO", "TEMP_TOS_ENC_PROC",
    "L2_MAP_CDS_FLG", "L1_PLACE_OF_SERVICE", "L1_CLINICAL_EVENT_ENCOUNTER",
    "L2_DICT_PROC", "L3_MAP_TOS", "L2_DICT_POS", "MD_OADW_INSTANCE")

  def directoryLevel: String = "L2"

  override def partitions: Int = 128

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val tempTosClaim = loadedDependencies("TEMP_TOS_CLAIM")
    val tempTosProcedurdo = loadedDependencies("TEMP_TOS_PROCEDUREDO")
    val tempTosEncProc = loadedDependencies("TEMP_TOS_ENC_PROC")
    val tL2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg]
    val tL2DictProc = loadedDependencies("L2_DICT_PROC").as[l2_dict_proc]
    val tL1ClinicalEventEncounter = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").as[l1_clinical_event_encounter]
    val tL1PlaceOfService = loadedDependencies("L1_PLACE_OF_SERVICE").as[l1_place_of_service]
    val tL3MapTos = loadedDependencies("L3_MAP_TOS").as[l3_map_tos]
    val tL2DictPos = loadedDependencies("L2_DICT_POS").as[l2_dict_pos]
    val mdOadwInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]


    createTL2PatProc(sparkSession, tempTosClaim, tempTosProcedurdo, tempTosEncProc, tL2MapCdsFlg, tL2DictProc,
      tL1ClinicalEventEncounter, tL1PlaceOfService, mdOadwInstance).toDF()
      .as("result")
      .join(broadcast(tL3MapTos).as("map_tos"), $"map_tos.tos5_id" === $"result.tos_i_5".cast(IntegerType), "left_outer")
      .join(broadcast(tL2DictPos).as("dict_pos"), $"dict_pos.place_of_svc" === $"result.place_of_svc", "left_outer")
      .select(
        $"result.cds_grp",
        $"result.client_id",
        $"result.clinical_event_id",
        $"result.code_type",
        $"result.hosp_px_ind",
        $"result.inferred_ind",
        $"result.modifier_1",
        $"result.modifier_1_excld",
        $"result.modifier_2",
        $"result.modifier_2_excld",
        $"result.modifier_3",
        $"result.modifier_3_excld",
        $"result.modifier_4",
        $"result.modifier_4_excld",
        $"result.mpi",
        $"result.place_of_svc",
        $"result.principal_ind",
        $"result.proc_cd",
        $"result.proc_dtm",
        $"result.prov_id",
        when($"map_tos.sensitive_ind" > $"result.sensitive_ind", $"map_tos.sensitive_ind")
          .otherwise($"result.sensitive_ind")
          .alias("sensitive_ind"),
        when($"dict_pos.place_of_svc".isNotNull, $"dict_pos.sensitive_ind")
          .otherwise(lit(0))
          .alias("place_of_svc_sensitive_ind"),
        $"result.tos_i_5"
      )
  }

  private def createTL2PatProc(sparkSession: SparkSession,
                               tempTosClaim: DataFrame,
                               tempTosProcedurdo: DataFrame,
                               tempTosEncProc: DataFrame,
                               tL2MapCdsFlg: Dataset[l2_map_cds_flg],
                               tL2DictProc: Dataset[l2_dict_proc],
                               tL1ClinicalEventEncounter: Dataset[l1_clinical_event_encounter],
                               tL1PlaceOfService: Dataset[l1_place_of_service],
                               mdOadwInstance: Dataset[md_oadw_instance]): Dataset[l2_pat_proc] = {

    import sparkSession.implicits._

    val listAgg = new ListAgg()

    val dataThruDtmPlus1Day = mdOadwInstance.where($"attribute_name" === lit("DATA_THRU"))
      .select(date_add(to_date($"attribute_value","yyyyMMdd"), 1))
      .as[Timestamp]
      .collect()
      .head

    def joinLimiter(df: DataFrame): DataFrame = {
      df
        .where(
          $"mpi".isNotNull and
            $"proc_dtm" < dataThruDtmPlus1Day and
            $"proc_cd".isNotNull and
            $"code_type".isin("CPT4", "HCPCS", "ICD9", "ICD10", "CUSTOM", "REV", "TOS")
        )
        .as("prc")
        .join(tL2MapCdsFlg.as("mcf"), $"mcf.client_id" === $"prc.client_id" and $"mcf.client_ds_id" === $"prc.client_ds_id")
        .join(tL2DictProc.as("dp"), $"dp.code_type" === $"prc.code_type" and $"dp.proc_cd" === $"prc.proc_cd")
        .join(tL1ClinicalEventEncounter.as("cee"),
          $"cee.client_id" === $"prc.client_id" and $"cee.client_ds_id" === $"prc.client_ds_id" and
            $"cee.encounterid" === $"prc.encounterid" and $"cee.mpi" === $"prc.mpi", "left_outer"
        )
        .join(broadcast(tL1PlaceOfService).as("pos"), $"pos.hts_cui" === $"cee.patienttype_cui", "left_outer")
        .select(
          $"prc.client_id", $"prc.client_ds_id", $"prc.mpi", $"prc.proc_cd", $"prc.code_type", $"prc.proc_dtm", $"cee.encounter_grp_num".as("clinical_event_id"),
          $"mcf.data_grp_flg", $"dp.sensitive_ind", $"prc.prov_id", $"prc.tos_i_5", $"prc.principal_ind", $"hosp_px_ind", $"prc.place_of_svc", $"pos.ii_code",
          $"prc.modifier_1", $"prc.modifier_2", $"prc.modifier_3", $"prc.modifier_4"
        )
        .repartition($"client_id", $"mpi", $"proc_cd", $"code_type", $"proc_dtm", $"clinical_event_id")
    }

    val tempTosClaimSelect = joinLimiter(tempTosClaim
      .withColumn("proc_cd", coalesce($"mappedcpt", $"mappedhcpcs"))
      .where($"proc_cd".isNotNull and length($"proc_cd") === 5)
      .select(
        $"client_id", $"client_ds_id", $"mpi", $"proc_cd",
        when(
          $"proc_cd".rlike("^[0-9]{1}[0-9TMF]{4}$"), lit("CPT4")
        ).when(
          $"proc_cd".rlike("^[ABCDEGHJKLMPQRSTUV].{4}$"), lit("HCPCS")
        ).otherwise(lit(null)).as("code_type"),
        $"service_dtm".as("proc_dtm"), $"encounterid", $"claim_mstrprovid".as("prov_id"),
        lit(0).as("principal_ind"), lit(0).as("hosp_px_ind"),
        $"pos".as("place_of_svc"), $"tos_i_5",
        substring($"mappedcptmod1", 1, 2).as("modifier_1"),
        substring($"mappedcptmod2", 1, 2).as("modifier_2"),
        substring($"mappedcptmod3", 1, 2).as("modifier_3"),
        substring($"mappedcptmod4", 1, 2).as("modifier_4")
      ))

    val tempTosClaimSelect2 = joinLimiter(tempTosClaim.select(
      $"client_id", $"client_ds_id", $"mpi", $"mappedrev".as("proc_cd"),
      lit("REV").as("code_type"), $"service_dtm".as("proc_dtm"),
      $"encounterid", $"claim_mstrprovid".as("prov_id"),
      lit(0).as("principal_ind"), lit(1).as("hosp_px_ind"),
      $"pos".as("place_of_svc"), $"tos_i_5",
      lit(null).as("modifier_1"),
      lit(null).as("modifier_2"),
      lit(null).as("modifier_3"),
      lit(null).as("modifier_4")
    ))

    val tempTosProcedureDoSelect = joinLimiter(tempTosProcedurdo.where($"mappedcode".isNotNull)
      .select(
        $"client_id", $"client_ds_id", $"mpi", $"mappedcode".as("proc_cd"), $"codetype".as("code_type"),
        $"procedure_dtm".as("proc_dtm"), $"encounterid", $"performing_mstrprovid".as("prov_id"),
        when($"localprincipleindicator" === lit("Y"), lit(1)).otherwise(lit(0)).as("principal_ind"),
        when($"hosp_px_flag" === lit("Y"), lit(1)).otherwise(lit(0)).as("hosp_px_ind"),
        lit(null).as("place_of_svc"), $"tos_i_5",
        lit(null).as("modifier_1"),
        lit(null).as("modifier_2"),
        lit(null).as("modifier_3"),
        lit(null).as("modifier_4")
      ))

    val tempTosEncProcSelect = joinLimiter(tempTosEncProc.where($"mappedcode".isNotNull)
      .select(
        $"client_id", $"client_ds_id", $"mpi", $"mappedcode".as("proc_cd"), $"codetype".as("code_type"),
        $"encounter_dtm".as("proc_dtm"), $"encounterid", lit("0").as("prov_id"),
        lit(null).as("principal_ind"), lit(null).as("hosp_px_ind"),
        lit(null).as("place_of_svc"), $"tos_i_5",
        lit(null).as("modifier_1"),
        lit(null).as("modifier_2"),
        lit(null).as("modifier_3"),
        lit(null).as("modifier_4")
      ))

    val dsResult = tempTosClaimSelect.union(tempTosClaimSelect2).union(tempTosProcedureDoSelect).union(tempTosEncProcSelect)
      .groupBy($"client_id", $"mpi", $"proc_cd", $"code_type", $"proc_dtm", $"clinical_event_id")
      .agg(
        listAgg($"client_ds_id").as("cds_grp"),
        max($"sensitive_ind").as("sensitive_ind"),
        max($"prov_id").as("prov_id"),
        max($"tos_i_5").cast(LongType).as("tos_i_5"),
        max($"principal_ind").as("principal_ind"),
        max($"hosp_px_ind").as("hosp_px_ind"),
        max(
          when(coalesce($"place_of_svc", $"ii_code") === lit("99"), lit(null)).otherwise(coalesce($"place_of_svc", $"ii_code"))
        ).as("place_of_svc"),
        max($"modifier_1").as("modifier_1"),
        max($"modifier_2").as("modifier_2"),
        max($"modifier_3").as("modifier_3"),
        max($"modifier_4").as("modifier_4")
      )
      .select(
        $"client_id", $"mpi", $"proc_cd", $"code_type", $"proc_dtm", $"clinical_event_id".cast(LongType).as("clinical_event_id"), $"sensitive_ind", $"cds_grp",
        lit(0).as("inferred_ind"),
        coalesce($"prov_id", lit("0")).as("prov_id"),
        $"tos_i_5", $"principal_ind", $"hosp_px_ind",
        coalesce($"place_of_svc", lit("99")).as("place_of_svc"),
        lit(null: String).as("place_of_svc_sensitive_ind"),
        $"modifier_1", $"modifier_2", $"modifier_3", $"modifier_4",
        when($"modifier_1".isin("1P","2P","3P","8P"), lit(1)).otherwise(lit(0)).as("modifier_1_excld"),
        when($"modifier_2".isin("1P","2P","3P","8P"), lit(1)).otherwise(lit(0)).as("modifier_2_excld"),
        when($"modifier_3".isin("1P","2P","3P","8P"), lit(1)).otherwise(lit(0)).as("modifier_3_excld"),
        when($"modifier_4".isin("1P","2P","3P","8P"), lit(1)).otherwise(lit(0)).as("modifier_4_excld")
      ).as[l2_pat_proc]
    dsResult
  }
}

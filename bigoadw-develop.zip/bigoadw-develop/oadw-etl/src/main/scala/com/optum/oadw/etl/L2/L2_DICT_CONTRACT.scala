package com.optum.oadw.etl.L2

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_dict_contract, l2_ii_map_contract, l2_map_cds_flg}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_DICT_CONTRACT extends TableInfo[l2_dict_contract]{

  override def name: String = "L2_DICT_CONTRACT"

  override def dependsOn: Set[String] = Set("L2_II_MAP_CONTRACT","L2_MAP_CDS_FLG")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2IIMapContract = loadedDependencies("L2_II_MAP_CONTRACT").as[l2_ii_map_contract]

    val l2MapCdsFlag = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg]

    l2IIMapContract.as("c").join(l2MapCdsFlag.as("m"), $"c.client_ds_id" === $"m.client_ds_id")
      .select(
        $"m.client_id",
        $"contract_id",
        $"contract_desc",
        $"contract_lv2",
        $"contract_lv2_desc",
        $"contract_lv1",
        $"contract_lv1_desc",
        $"contract_hier",
        $"m.client_ds_id".cast(StringType).as("cds_grp")
      )
  }
}

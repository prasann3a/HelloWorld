
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_map_service_line, zh_service_line}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_MAP_SERVICE_LINE extends TableInfo[l1_map_service_line]{
  override def dependsOn: Set[String] = Set("ZH_SERVICE_LINE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_MAP_SERVICE_LINE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhServiceLine = loadedDependencies("ZH_SERVICE_LINE").as[zh_service_line]

    zhServiceLine
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"localservicecode",
			$"servicecodedesc"
    )
  }
}


package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l1_clinicalencounter, l1_clinical_event_encounter, l2_map_clinical_event_enc}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_MAP_CLINICAL_EVENT_ENC extends TableInfo[l2_map_clinical_event_enc]{
  override def dependsOn: Set[String] = Set("L1_CLINICAL_EVENT_ENCOUNTER","L1_CLINICALENCOUNTER")

  override def name: String = "L2_MAP_CLINICAL_EVENT_ENC"


  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tl1ClinicalEventEncounter = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").as[l1_clinical_event_encounter]
    val tl1ClinicalEncounter = loadedDependencies("L1_CLINICALENCOUNTER").as[l1_clinicalencounter]

    tl1ClinicalEncounter.as("enc")
      .join(tl1ClinicalEventEncounter.as("evt"), $"enc.client_id" === $"evt.client_id" and $"enc.client_ds_id" === $"evt.client_ds_id" and $"enc.encounterid" === $"evt.encounterid")
      .select(
        $"evt.client_id",
        $"evt.encounter_grp_num".as("clinical_event_id"),
        explode(when($"enc.alt_encounterid".isNotNull, typedLit(List("ALT", "NON_ALT"))).otherwise(typedLit(List("NON_ALT")))).as("id_type"),
        $"evt.client_ds_id",
        $"enc.encounterid",
        $"enc.alt_encounterid"
      ).select(
      $"client_id",
      $"clinical_event_id",
      $"id_type",
      $"client_ds_id",
      when($"id_type" === "ALT", $"alt_encounterid").otherwise($"encounterid").as("encounterid")
    ).distinct()

  }
}

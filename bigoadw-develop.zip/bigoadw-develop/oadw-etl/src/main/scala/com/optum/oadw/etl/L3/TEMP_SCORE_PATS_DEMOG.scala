
/**
  * auto-generated code
*/
package com.optum.oadw.etl.L3


import java.sql.Timestamp

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_score_pats_demog_data(client_id: String, mpi: String, timeframe_id: java.lang.Integer, dob: Timestamp,
                                      gender: String, race: String, race_default_flg: java.lang.Integer, age: java.lang.Integer,
                                      age_default_flg: java.lang.Integer, gender_default_flg: java.lang.Integer)

object TEMP_SCORE_PATS_DEMOG extends QueryAndMetadata[temp_score_pats_demog_data] {
  override def name: String = "TEMP_SCORE_PATS_DEMOG"

  override def sparkSql: String = """SELECT  pats.client_id
,pats.mpi
,age.timeframe_id
,pats.dob
,CASE WHEN pats.GENDER_CUI IN ('CH000034','CH000033') THEN pats.GENDER_CUI
ELSE 'CH000034'
END AS gender
,CASE WHEN pats.gender_cui NOT IN ('CH000033','CH000034') THEN gdf.SCORE_DEFAULT_FLG ELSE 0 END AS gender_default_flg
,CASE WHEN pats.RACE_CUI IN ('CH000051','CH000052','CH000053','CH000054','CH000055') THEN pats.RACE_CUI
ELSE 'CH000055'
END AS race
,CASE WHEN pats.race_cui NOT IN ('CH000051','CH000052','CH000053','CH000054','CH000055') THEN wrd.SCORE_DEFAULT_FLG
ELSE 0
END AS race_default_flg
,NVL(age.end_age,21) as age
,CASE WHEN age.END_AGE IS NULL THEN adf.SCORE_DEFAULT_FLG ELSE 0 END as age_default_flg
FROM temp_score_pats pats
INNER JOIN L3_Pat_Timeframe_Age age ON (pats.client_id = age.client_id and pats.mpi = age.mpi)
INNER JOIN (SELECT TIMEFRAME_ID from temp_score_triplet GROUP BY TIMEFRAME_ID) t ON (age.timeframe_id=t.timeframe_id) -- restrict to just timeframes over which we calculate scores
CROSS JOIN (SELECT SCORE_DEFAULT_FLG from L4_DICT_SCORE_DEFAULT_FLG where SCORE_DEFAULT_FLG_NAME='Male Gender Default') gdf
CROSS JOIN (SELECT SCORE_DEFAULT_FLG from L4_DICT_SCORE_DEFAULT_FLG where SCORE_DEFAULT_FLG_NAME='White Race Default') wrd
CROSS JOIN (SELECT SCORE_DEFAULT_FLG from L4_DICT_SCORE_DEFAULT_FLG WHERE SCORE_DEFAULT_FLG_NAME='21 Age Default') adf"""

  override def dependsOn: Set[String] = Set("TEMP_SCORE_PATS","L3_PAT_TIMEFRAME_AGE","TEMP_SCORE_TRIPLET","L4_DICT_SCORE_DEFAULT_FLG")

  def originalSql: String = """

--Class_3 AAP patients who are alive at some point in the timeframe of interest
-- with their relevant race, gender, and age (as well as default flgs)
-- restrict to just timeframes that are involved for scores of interest (those in temp_score_triplet)
-- NOTE: Utilized by L3_pat_score_grp_intn_build.sql script and L3_pat_score_build.sql script to determine patient's demographics
--       after assigning defaults so that the default logic doesn't have to be in more than one place
CREATE TABLE temp_score_pats_demog PCTFREE 0 NOLOGGING
AS
SELECT /*+parallel(4)*/ pats.client_id
       ,pats.mpi
       ,age.timeframe_id
       ,pats.dob
       ,CASE WHEN pats.GENDER_CUI IN ('CH000034','CH000033') THEN pats.GENDER_CUI
             ELSE 'CH000034'
        END AS gender
       ,CASE WHEN pats.gender_cui NOT IN ('CH000033','CH000034') THEN gdf.SCORE_DEFAULT_FLG ELSE 0 END AS gender_default_flg
       ,CASE WHEN pats.RACE_CUI IN ('CH000051','CH000052','CH000053','CH000054','CH000055') THEN pats.RACE_CUI
             ELSE 'CH000055'
        END AS race
       ,CASE WHEN pats.race_cui NOT IN ('CH000051','CH000052','CH000053','CH000054','CH000055') THEN wrd.SCORE_DEFAULT_FLG
             ELSE 0
        END AS race_default_flg
       ,NVL(age.end_age,21) as age
       ,CASE WHEN age.END_AGE IS NULL THEN adf.SCORE_DEFAULT_FLG ELSE 0 END as age_default_flg
FROM temp_score_pats pats
INNER JOIN L3_Pat_Timeframe_Age age ON (pats.client_id = age.client_id and pats.mpi = age.mpi)
INNER JOIN (SELECT TIMEFRAME_ID from temp_score_triplet GROUP BY TIMEFRAME_ID) t ON (age.timeframe_id=t.timeframe_id) -- restrict to just timeframes over which we calculate scores
CROSS JOIN (SELECT SCORE_DEFAULT_FLG from L4_DICT_SCORE_DEFAULT_FLG where SCORE_DEFAULT_FLG_NAME='Male Gender Default') gdf
CROSS JOIN (SELECT SCORE_DEFAULT_FLG from L4_DICT_SCORE_DEFAULT_FLG where SCORE_DEFAULT_FLG_NAME='White Race Default') wrd
CROSS JOIN (SELECT SCORE_DEFAULT_FLG from L4_DICT_SCORE_DEFAULT_FLG WHERE SCORE_DEFAULT_FLG_NAME='21 Age Default') adf
"""

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L3"





  val originalSqlFileName: String = "L3_pat_score_grp_precur_build.sql"
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_clinicalencounter, clinicalencounter}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_CLINICALENCOUNTER extends TableInfo[l1_clinicalencounter]{
  override def dependsOn: Set[String] = Set("CLINICALENCOUNTER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CLINICALENCOUNTER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val clinicalencounter = loadedDependencies("CLINICALENCOUNTER").as[clinicalencounter]

    clinicalencounter
    .select(
			$"groupid".as("client_id"),
			$"encounterid",
			$"datasrc",
			$"facilityid",
			$"patientid",
			$"admittingphysician",
			$"attendingphysician",
			$"referproviderid",
			$"admittime".as("admit_dtm"),
			$"arrivaltime".as("arrival_dtm"),
			$"dischargetime".as("discharge_dtm"),
			$"localpatienttype",
			$"localaccountstatus",
			$"localdischargedisposition",
			$"inpatientlocation",
			$"pcpid",
			$"localfinancialclass",
			$"visitid",
			$"localadmitsource",
			$"localdrg",
			$"localmdc",
			$"localdrgtype",
			$"localencountertype",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"aprdrg_cd",
			$"aprdrg_soi",
			$"aprdrg_rom",
			$"totalcost",
			$"totalcharge",
			$"wasplannedflg",
			$"elos",
			$"alt_encounterid",
			$"inferred_pat_type"
    )
  }
}


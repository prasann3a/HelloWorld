package com.optum.oadw.etl.L2
import com.optum.oadw.oadwModels.l2_patient_info
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_PATIENT_INFO extends QueryAndMetadata[l2_patient_info] {
  override def name: String = "L2_PATIENT_INFO"

  override def sparkSql: String = """SELECT  a.client_id,a.mpi
,b.cds_grp
,cast(null as string) as MRN
,cast(null as string) as SSN
,SUBSTR(a.first_name,1,30) AS first_name
,SUBSTR(a.last_name,1,50) AS last_name
,SUBSTR(a.middle_name,1,30) as middle_name
, TO_TIMESTAMP(a.dob, 'yyyyMMdd')  AS dob
,a.date_of_death AS dod
,a.mapped_gender AS gender_cui
,a.mapped_race AS race_cui
,a.mapped_ethnicity as ethnicity_cui
,CASE WHEN a.date_of_death IS NOT NULL AND a.date_of_death <  current_timestamp()  THEN 'CH001139'
WHEN a.mapped_death_ind = 'CH999999' THEN 'CH001138'
ELSE a.mapped_death_ind END AS death_ind_cui
,a.mapped_marital_status as marital_status_cui
,a.mapped_language as language_cui
,SUBSTR(c.address_line1,1,100) AS addr_line_1,SUBSTR(c.address_line2,1,100) AS addr_line_2
,SUBSTR(c.city,1,50) AS city
,SUBSTR(c.state,1,2) AS state
,SUBSTR(c.zipcode,1,5) AS postal_cd --need to decide if these are zip=4 at L2
,SUBSTR(d.home_phone,1,30) AS home_phone
,SUBSTR(d.work_phone,1,30) AS work_phone
,SUBSTR(d.cell_phone,1,30) AS mobile_phone
,COALESCE(d.personal_email ,d.work_email) as email
,a.religion
,a.mrace_infer_ind
FROM L1_Patient_Summary_Grp_Mpi a
INNER JOIN (SELECT ps.mpi
,listAgg(mcf.client_ds_id) AS cds_grp
FROM L1_Patient_Summary ps
INNER JOIN L2_map_cds_flg mcf on (ps.client_id = mcf.client_id AND ps.client_ds_id = mcf.client_ds_id)
GROUP BY ps.mpi) b ON (a.mpi = b.mpi)
LEFT OUTER JOIN L1_Patientaddr_Summary c ON (a.mpi = c.mpi)
LEFT OUTER JOIN L1_Patientcontact_Summary d ON (a.mpi = d.mpi)"""

  override def dependsOn: Set[String] = Set("L1_PATIENT_SUMMARY_GRP_MPI","L2_MAP_CDS_FLG","L1_PATIENT_SUMMARY","L1_PATIENTCONTACT_SUMMARY","L1_PATIENTADDR_SUMMARY")

  def originalSql: String = """-- FMP @nonEmpty
INSERT /*+ APPEND */ INTO L2_patient_info(client_id,mpi,cds_grp,mrn,ssn,first_name,last_name,middle_name
       ,dob,dod,gender_cui,race_cui,ethnicity_cui,death_ind_cui,marital_status_cui,language_cui
       ,addr_line_1,addr_line_2,city,state,postal_cd
       ,home_phone,work_phone,mobile_phone,email,religion)
SELECT /*+ parallel(4) */ a.client_id,a.mpi
       ,b.cds_grp
       ,null as MRN
       ,null as SSN
       ,SUBSTRB(a.first_name,1,30) AS first_name
       ,SUBSTRB(a.last_name,1,50) AS last_name
       ,SUBSTRB(a.midddle_name,1,30) as middle_name
       ,to_date(a.dob,'YYYYMMDD') AS dob
       ,a.date_of_death AS dod
       ,a.mapped_gender AS gender_cui
       ,a.mapped_race AS race_cui
       ,a.mapped_ethnicity
       ,CASE WHEN a.date_of_death IS NOT NULL AND a.date_of_death < SYSDATE THEN 'CH001139'
             WHEN a.mapped_death_ind = 'CH999999' THEN 'CH001138'
             ELSE a.mapped_death_ind END AS death_ind_cui
       ,a.mapped_marital_status
       ,a.mapped_language
       ,SUBSTR(c.address_line1,1,100) AS address_line_1,SUBSTR(c.address_line2,1,100) AS address_line_2
       ,SUBSTR(c.city,1,50) AS city
       ,SUBSTR(c.state,1,2) AS state
       ,SUBSTR(c.zipcode,1,5) AS zipcode --need to decide if these are zip=4 at L2
       -- Need some better cleaning on phone numbers
       ,SUBSTR(d.home_phone,1,30) AS home_phone
       ,SUBSTR(d.work_phone,1,30) AS work_phone
       ,SUBSTR(d.cell_phone,1,30) AS cell_phone
       ,COALESCE(d.personal_email ,d.work_email) as email
       ,a.religion
FROM L1_Patient_Summary_Grp_Mpi a
INNER JOIN (SELECT ps.mpi
                        ,listAgg(mcf.client_ds_id) AS cds_grp
     FROM L1_Patient_Summary ps
     INNER JOIN L2_map_cds_flg mcf on (ps.client_id = mcf.client_id AND ps.client_ds_id = mcf.client_ds_id)
     GROUP BY ps.mpi) b ON (a.mpi = b.mpi)
LEFT OUTER JOIN L1_Patientaddr_Summary c ON (a.mpi = c.mpi)
LEFT OUTER JOIN L1_Patientcontact_Summary d ON (a.mpi = d.mpi)
"""

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_patient_info_build.sql"
}

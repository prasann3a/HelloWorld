package com.optum.oadw.etl.L3

import com.optum.oadw.etl.constants.Procedures
import com.optum.oadw.oadwModels._
import com.optum.oadw.oadw_ref.models.l2_map_sensitive_category
import com.optum.oadw.utils.DataframeExtensions._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

/**
  * Algorithm specification: https://wiki.humedica.net/display/Data/OADW+Tables+-+Domain+Maps+and+Dictionaries+-+DICT_PROC_GROUP
  */
object L3_DICT_PROC_GROUP extends TableInfo[l3_dict_proc_group] {
  override def name: String = "L3_DICT_PROC_GROUP"
  override def dependsOn: Set[String] = Set("MD_DOMAIN_CONCEPT","L1_REF_IMAP_ETG_TX", "L1_REF_IMAP_PEG", "L2_MAP_SENSITIVE_CATEGORY")
  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tMdDomainConcept = loadedDependencies("MD_DOMAIN_CONCEPT").as[md_domain_concept]
    val tL1RefImapEtgTx = loadedDependencies("L1_REF_IMAP_ETG_TX").castToBigDecimal(Set("fileid")).as[l1_ref_imap_etg_tx]
    val tL1RefIMapPeg = loadedDependencies("L1_REF_IMAP_PEG").castToBigDecimal(Set("fileid")).as[l1_ref_imap_peg]
    val tL2MapSensitiveCategory = loadedDependencies("L2_MAP_SENSITIVE_CATEGORY").as[l2_map_sensitive_category]

    calculateTL3DictProcGroup(sparkSession, tMdDomainConcept, tL1RefImapEtgTx, tL1RefIMapPeg, tL2MapSensitiveCategory)
      .select($"proc_group_id", $"proc_group_set", $"external_code", $"description", $"sensitive_ind", $"sensitive_cat_id")
  }

  private def calculateTL3DictProcGroup(sparkSession: SparkSession,
                                        mdDomainConcept: Dataset[md_domain_concept],
                                        tL1RefImapEtgTx: Dataset[l1_ref_imap_etg_tx],
                                        tL1RefIMapPeg: Dataset[l1_ref_imap_peg],
                                        tL2MapSensitiveCategory: Dataset[l2_map_sensitive_category]): Dataset[l3_dict_proc_group] = {
    import sparkSession.implicits._

    val cuis = mdDomainConcept
      .where($"domain_cui" === Procedures.NON_SENSITIVE_PROCEDURES_DOMAIN_CUI)
      .select(
        $"concept_name", $"domain_name", $"domain_cui", $"concept_cui",
        (regexp_replace($"concept_cui", "[\\D]", "").cast(IntegerType) + Procedures.CUI_OFFSET).as("proc_group_id"),
        $"sensitive_ind".as("sensitive_ind"),
        lit(Procedures.PROC_GROUP_SET_CUI).as("proc_group_set")
      ).as("mdc")
      .join(tL2MapSensitiveCategory.as("sc"), expr("UPPER(mdc.concept_name) LIKE CONCAT('%', UPPER(sc.sensitive_text), '%')"), "left")
      .withColumn("sensitivity_rank", row_number.over(Window.partitionBy($"mdc.concept_cui").orderBy($"sensitive_hierarchy".asc)))
      .where($"sensitivity_rank" === 1)
      .select($"mdc.proc_group_id", $"mdc.proc_group_set", $"mdc.concept_cui".as("external_code"),
        $"mdc.concept_name".as("description"),
        when($"mdc.sensitive_ind" === "0", Procedures.NOT_SENSITIVE_IND)
          .when($"mdc.sensitive_ind" === "1", Procedures.SENSITIVE_IND)
          .otherwise(null)
          .as("sensitive_ind"),
        when($"mdc.sensitive_ind" === "0", Procedures.SENSITIVE_CAT_ID_NOT_SENSITIVE)
          .when($"mdc.sensitive_ind" === "1" && $"sc.sensitive_cat_id".isNull, Procedures.SENSITIVE_CAT_ID_NO_MAP)
          .when($"mdc.sensitive_ind" === "1" && $"sc.sensitive_cat_id".isNotNull, $"sc.sensitive_cat_id")
          .otherwise(null)
          .as("sensitive_cat_id"))

    val etg = tL1RefImapEtgTx
      .select(
        tL1RefImapEtgTx.col("*"),
        $"sensitive_ind",
        ($"tx_code".cast(IntegerType) + Procedures.ETG_ID_OFFSET).as("proc_group_id"),
        lit(Procedures.PROC_GROUP_SET_ETG_TX).as("proc_group_set")
      )
      .join(tL2MapSensitiveCategory.as("sc"), expr("UPPER(tx_desc) LIKE CONCAT('%', UPPER(sc.sensitive_text), '%')"), "left")
      .withColumn("sensitivity_rank", row_number.over(Window.partitionBy($"tx_code").orderBy($"sensitive_hierarchy".asc)))
      .where($"sensitivity_rank" === 1)
      .select($"proc_group_id", $"proc_group_set", $"tx_code".as("external_code"),
        $"tx_desc".as("description"),
        when($"sensitive_ind" === "0" || $"sensitive_ind".isNull, Procedures.NOT_SENSITIVE_IND)
          .when($"sensitive_ind" === "1", Procedures.SENSITIVE_IND)
          .as("sensitive_ind"),
        when($"sensitive_ind" === "0" || $"sensitive_ind".isNull, Procedures.SENSITIVE_CAT_ID_NOT_SENSITIVE)
          .when($"sensitive_ind" === "1" && $"sensitive_cat_id".isNull, Procedures.SENSITIVE_CAT_ID_NO_MAP)
          .when($"sensitive_ind" === "1" && $"sensitive_cat_id".isNotNull, $"sensitive_cat_id")
          .otherwise(null)
          .as("sensitive_cat_id"))

    val peg = tL1RefIMapPeg
      .select(
        tL1RefIMapPeg.col("*"),
        when($"sensitive_ind" === "0" || $"sensitive_ind".isNull, Procedures.NOT_SENSITIVE_IND)
          .when($"sensitive_ind" === "1", Procedures.SENSITIVE_IND)
          .as("sensitive_ind_int"),
        ($"peg_cat_id".cast(IntegerType) + Procedures.PEG_ID_OFFSET).as("proc_group_id"),
        lit(Procedures.PROC_GROUP_SET_PEG).as("proc_group_set")
      )
      .join(tL2MapSensitiveCategory.as("sc"), expr("UPPER(peg_cat_desc) LIKE CONCAT('%', UPPER(sc.sensitive_text), '%')"), "left")
      .withColumn("sensitivity_rank", row_number.over(Window.partitionBy($"peg_cat_id").orderBy($"sensitive_hierarchy".asc)))
      .where($"sensitivity_rank" === 1)
      .select($"proc_group_id", $"proc_group_set", $"peg_cat_id".as("external_code"),
        $"peg_cat_desc".as("description"), $"sensitive_ind_int".as("sensitive_ind"),
        when($"sensitive_ind" === "0" || $"sensitive_ind".isNull, Procedures.SENSITIVE_CAT_ID_NOT_SENSITIVE)
          .when($"sensitive_ind" === "1" && $"sensitive_cat_id".isNull, Procedures.SENSITIVE_CAT_ID_NO_MAP)
          .when($"sensitive_ind" === "1" && $"sensitive_cat_id".isNotNull, $"sensitive_cat_id")
          .as("sensitive_cat_id"))

    val ii = List(
      l3_dict_proc_group(
        proc_group_id=Procedures.PCCEM_PROC_GROUP_ID,
        proc_group_set=Procedures.PROC_GROUP_SET_II,
        external_code=Procedures.EXTERNAL_CODE_PCCEM,
        description=Procedures.DESCRIPTION_PCCEM,
        sensitive_ind=Procedures.NOT_SENSITIVE_IND,
        sensitive_cat_id=Procedures.SENSITIVE_CAT_ID_NOT_SENSITIVE
      ),
      l3_dict_proc_group(
        proc_group_id=Procedures.PCC_PROC_GROUP_ID,
        proc_group_set=Procedures.PROC_GROUP_SET_II,
        external_code=Procedures.EXTERNAL_CODE_PCC,
        description=Procedures.DESCRIPTION_PCC,
        sensitive_ind=Procedures.NOT_SENSITIVE_IND,
        sensitive_cat_id=Procedures.SENSITIVE_CAT_ID_NOT_SENSITIVE
      ),
      l3_dict_proc_group(
        proc_group_id=Procedures.EM_PX_PROC_GROUP_ID,
        proc_group_set=Procedures.PROC_GROUP_SET_II,
        external_code=Procedures.EXTERNAL_CODE_EM_PX,
        description=Procedures.DESCRIPTION_EM_PX,
        sensitive_ind=Procedures.NOT_SENSITIVE_IND,
        sensitive_cat_id=Procedures.SENSITIVE_CAT_ID_NOT_SENSITIVE
      ),
      l3_dict_proc_group(
        proc_group_id=Procedures.EM_OFF_PROC_GROUP_ID,
        proc_group_set=Procedures.PROC_GROUP_SET_II,
        external_code=Procedures.EXTERNAL_CODE_EM_OFF,
        description=Procedures.DESCRIPTION_EM_OFF,
        sensitive_ind=Procedures.NOT_SENSITIVE_IND,
        sensitive_cat_id=Procedures.SENSITIVE_CAT_ID_NOT_SENSITIVE
      ),
      l3_dict_proc_group(
        proc_group_id=Procedures.EM_TELE_PROC_GROUP_ID,
        proc_group_set=Procedures.PROC_GROUP_SET_II,
        external_code=Procedures.EXTERNAL_CODE_EM_TELE,
        description=Procedures.DESCRIPTION_EM_TELE,
        sensitive_ind=Procedures.NOT_SENSITIVE_IND,
        sensitive_cat_id=Procedures.SENSITIVE_CAT_ID_NOT_SENSITIVE
      )
    ).toDF().select($"proc_group_id", $"proc_group_set",$"external_code",$"description",$"sensitive_ind",$"sensitive_cat_id")

    cuis.union(peg).union(etg).union(ii).as[l3_dict_proc_group]
  }
}

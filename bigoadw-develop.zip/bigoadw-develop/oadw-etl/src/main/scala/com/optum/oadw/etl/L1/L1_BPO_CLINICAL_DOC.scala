
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_bpo_clinical_doc, pp_bpo_clinical_documentation}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_BPO_CLINICAL_DOC extends TableInfo[l1_bpo_clinical_doc]{
  override def dependsOn: Set[String] = Set("PP_BPO_CLINICAL_DOCUMENTATION")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_BPO_CLINICAL_DOC"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ppBpoClinicalDocumentation = loadedDependencies("PP_BPO_CLINICAL_DOCUMENTATION").as[pp_bpo_clinical_documentation]

    ppBpoClinicalDocumentation
    .select(
			$"clinical_document_id",
			$"code",
			$"code_taxonomy",
			$"documentation_date".as("documentation_dt"),
			$"groupid".as("client_id"),
			$"healthplansource",
			$"memberid".as("mpi"),
			$"phq9_version",
			$"result"
    )
  }
}



package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ebm_eventruleservice, ebm_eventruleservice}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_EBM_EVENTRULESERVICE extends TableInfo[l1_ebm_eventruleservice]{
  override def dependsOn: Set[String] = Set("EBM_EVENTRULESERVICE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_EBM_EVENTRULESERVICE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ebmEventruleservice = loadedDependencies("EBM_EVENTRULESERVICE").as[ebm_eventruleservice]

    ebmEventruleservice
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi",
			$"report_case_id",
			$"event",
			$"report_rule_id",
			$"uniq_rec_id",
			$"file_processing_month"
    )
  }
}



/**
  * auto-generated code
*/
package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l1_ref_icd0_dx, l1_ref_icd9_dx, l1_ref_sensitive_diag, l2_dict_diag}
import com.optum.oadw.oadw_ref.models.l2_map_sensitive_category
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


object L2_DICT_DIAG extends TableInfo[l2_dict_diag] {
  override def name: String = "L2_DICT_DIAG"

  override def dependsOn: Set[String] = Set("L1_REF_ICD0_DX","L1_REF_ICD9_DX","L1_REF_SENSITIVE_DIAG","L2_MAP_SENSITIVE_CATEGORY")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val l1RefIcd0Dx = loadedDependencies("L1_REF_ICD0_DX").as[l1_ref_icd0_dx]
    val l1RefIcd9Dx = loadedDependencies("L1_REF_ICD9_DX").as[l1_ref_icd9_dx]
    val l1RefSensitiveDiag = loadedDependencies("L1_REF_SENSITIVE_DIAG").as[l1_ref_sensitive_diag]
    val l2MapSensitiveCategory = loadedDependencies("L2_MAP_SENSITIVE_CATEGORY").as[l2_map_sensitive_category]

    val window = Window.partitionBy($"code_type", $"diag_cd").orderBy($"sensitive_hierarchy".asc)

    val icd9 = l1RefIcd9Dx.select(
      lit("ICD9").as("code_type"),
      $"diagnosis_code".as("diag_cd"),
      $"short_description".as("code_name"),
      $"long_description".as("code_desc"),
      lit(9).as("icd_version"),
      regexp_replace($"diagnosis_code", "\\.", "").as("icddx")
    ).as("icd9")
    .join(l1RefSensitiveDiag.as("rsd"),$"icd9.diag_cd" === $"rsd.diag_cd" and $"icd9.code_type" === $"rsd.code_type","left")
    .join(l2MapSensitiveCategory.as("rsc"), expr("UPPER(icd9.code_desc) LIKE CONCAT('%', UPPER(rsc.sensitive_text), '%')"), "left")
    .withColumn("row_num", rank() over Window.partitionBy($"icd9.diag_cd").orderBy($"sensitive_hierarchy"))
    .where($"row_num" === lit(1))
    .withColumn("sensitive_ind", coalesce($"rsd.sensitive_ind", lit(0)))
    .select(
      $"icd9.code_type",
      $"icd9.diag_cd",
      coalesce($"code_name", concat($"icd9.code_type", lit("-"), $"icd9.diag_cd")).as("code_name"),
      $"code_desc",
      $"sensitive_ind",
      $"icd_version",
      $"icddx",
      when($"sensitive_ind" === 1, coalesce($"rsc.sensitive_cat_id", lit(999))).otherwise(lit(1)).as("sensitive_cat_id")
    )

    val icd10 = l1RefIcd0Dx.select(
      lit("ICD10").as("code_type"),
      $"diagnosis_code".as("diag_cd"),
      $"short_description".as("code_name"),
      $"long_description".as("code_desc"),
      regexp_replace($"diagnosis_code", "\\.", "").as("icddx"),
      lit(0).as("icd_version")
    ).as("icd10")
    .join(l1RefSensitiveDiag.as("rsd"),$"icd10.diag_cd" === $"rsd.diag_cd" and $"icd10.code_type" === $"rsd.code_type","left")
          .join(l2MapSensitiveCategory.as("rsc"), expr("UPPER(icd10.code_desc) LIKE CONCAT('%', UPPER(rsc.sensitive_text), '%')"), "left")
    .withColumn("row_num",rank() over Window.partitionBy($"icd10.diag_cd").orderBy($"sensitive_hierarchy"))
    .where($"row_num" === lit(1))
    .withColumn("sensitive_ind",coalesce($"rsd.sensitive_ind",lit(0)))
    .select(
      $"icd10.code_type",
      $"icd10.diag_cd",
      coalesce($"code_name", concat($"icd10.code_type", lit("-"), $"icd10.diag_cd")).as("code_name"),
      $"code_desc",
      $"sensitive_ind",
      $"icd_version",
      $"icddx",
      when($"sensitive_ind" === 1, coalesce($"rsc.sensitive_cat_id", lit(999))).otherwise(lit(1)).as("sensitive_cat_id")
    )

    icd9.union(icd10)
  }

  def directoryLevel: String = "L2"

  val originalSqlFileName: String = "L2_dict_diag_build.sql"
}


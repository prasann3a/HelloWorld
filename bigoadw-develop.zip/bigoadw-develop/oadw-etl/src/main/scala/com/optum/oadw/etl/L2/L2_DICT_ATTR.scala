package com.optum.oadw.etl.L2

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_DICT_ATTR extends TableInfo[l2_dict_attr] {

  override def name: String = "L2_DICT_ATTR"

  override def dependsOn: Set[String] = Set("MD_DOMAIN_CONCEPT")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mdDomainConcept = loadedDependencies("MD_DOMAIN_CONCEPT").as[md_domain_concept]

    mdDomainConcept
      .where($"domain_cui" isin ("CH002774", "CH002484", "CH001301") and ($"concept_cui".isNotNull) and ($"concept_name".isNotNull))
      .select($"concept_cui".as("attr_cui"),
        $"concept_name".as("attr_desc")
      ).distinct()
  }
}


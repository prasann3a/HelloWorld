package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.md_domain_concept
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.{ DataFrame, SparkSession }

object MD_DOMAIN_CONCEPT extends TableInfo[md_domain_concept] {
  override def name: String = "MD_DOMAIN_CONCEPT"

  override def dependsOn: Set[String] = Set("L1_MV_HTS_DOMAIN_CONCEPT")

  protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val tL1MvHtsDomainConcept = loadedDependencies("L1_MV_HTS_DOMAIN_CONCEPT")
    tL1MvHtsDomainConcept
      .where($"is_valid" === "Y")
      .selectExpr(
        "concept_cui",
        "is_other",
        "domain_cui",
        "concept_name",
        "domain_name",
        "first_valid_dt",
        "last_valid_dt",
        "MAX(CASE WHEN domain_cui='CH003536' THEN 1 ELSE 0 END) OVER (PARTITION BY concept_cui) AS sensitive_ind"
      )
  }
}

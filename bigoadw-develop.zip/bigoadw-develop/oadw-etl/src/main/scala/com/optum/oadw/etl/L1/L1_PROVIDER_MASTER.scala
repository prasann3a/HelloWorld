
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_provider_master, zh_provider_master}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROVIDER_MASTER extends TableInfo[l1_provider_master]{
  override def dependsOn: Set[String] = Set("ZH_PROVIDER_MASTER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROVIDER_MASTER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhProviderMaster = loadedDependencies("ZH_PROVIDER_MASTER").as[zh_provider_master]

    zhProviderMaster
    .select(
			$"groupid".as("client_id"),
			$"master_hgprovid",
			$"providername",
			$"npi",
			$"match_cnt",
			$"localprimaryspecialty",
			$"emailaddress",
			$"primaryfacilityid",
			$"providerexclusionflag",
			$"localclassification",
			$"mappedcredentialtype"
    )
  }
}


package com.optum.oadw.etl.L3

import com.optum.oadw.oadwModels.{l4_timeframe, l2_elig_contract, l2_ii_map_date_range}
import com.optum.oadw.etl.models.temp_contract
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{broadcast, rank}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel


object TEMP_CONTRACT extends TableInfo[temp_contract] {

  override def name: String = "TEMP_CONTRACT"

  override def dependsOn: Set[String] = Set("L2_ELIG_CONTRACT", "L2_II_MAP_DATE_RANGE", "L4_TIMEFRAME")

  def directoryLevel: String = "L3"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2_elig_contract = loadedDependencies("L2_ELIG_CONTRACT").as[l2_elig_contract]
    val l2_ii_map = loadedDependencies("L2_II_MAP_DATE_RANGE").as[l2_ii_map_date_range]
    val l4_timeframe = broadcast(
      loadedDependencies("L4_TIMEFRAME")
      .as[l4_timeframe]
      .filter($"timeframe_type" === "EOD" || $"timeframe_type" === "12M")
    )

    val joined_dataset = l2_elig_contract.as("contract")
      .join(l2_ii_map.as("map"), $"map.year_mth_id" === $"contract.year_mth_id")
      .join(l4_timeframe.as("timeframe"), $"map.month_end_date".between($"timeframe.start_dt", $"timeframe.end_dt"))
      .select($"contract.member",
        $"contract.contract_id",
        $"contract.at_risk_status_id",
        $"timeframe.timeframe_id",
        $"map.month_end_date"
      )

    val qualified_members = joined_dataset
      .groupBy($"member", $"contract_id", $"timeframe_id")
      .count()
      .filter($"count" >= 11)

    val window = Window.partitionBy($"a.member", $"a.contract_id", $"a.timeframe_id").orderBy($"a.month_end_date".desc)

    joined_dataset.as("a")
      .join(qualified_members.as("b"), $"a.member" === $"b.member" &&  $"a.contract_id" === $"b.contract_id" && $"a.timeframe_id" === $"b.timeframe_id")
      .withColumn("rank", rank().over(window))
      .filter($"rank" === 1)
      .select(
        $"a.member" as "mpi",
        $"a.timeframe_id",
        $"a.contract_id",
        $"a.at_risk_status_id",
        $"a.month_end_date"
      )
  }
}

package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l2_ii_mem_attr_ext, l2_ii_mem_attr_member}
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_II_MEM_ATTR_EXT extends QueryAndMetadata[l2_ii_mem_attr_ext] {
  override def name: String = "L2_II_MEM_ATTR_EXT"

  override def sparkSql: String = """
    select
      case when sex = true then 1 else 0 end as sex,
      cat_status,cat_status_cost3,age_cat2,account_id,product_id,pcp_assign,zip,contract_id,mem_userdef_1_id,at_risk_status_id,
      mem_userdef_2_id,mem_userdef_3_id,mem_userdef_4_id,cast(row_number() over(order by now()) as INT) as NEW_MEM_ATTR_ID
    from (
      select distinct attr.sex,attr.cat_status,attr.cat_status_cost3,attr.age_cat2,attr.account_id,
        attr.product_id,attr.pcp_assign,attr.zip,attr.contract_id,attr.mem_userdef_1_id,attr.at_risk_status_id, ATTR.MEM_USERDEF_2_ID,ATTR.MEM_USERDEF_3_ID,ATTR.MEM_USERDEF_4_ID
      from L2_II_MEM_ATTR_MEMBER attr
    ) a
"""

  override def dependsOn: Set[String] = Set("L2_II_MEM_ATTR_MEMBER")

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(
    OutputColumn("sex",None,None),
    OutputColumn("cat_status",None,None),
    OutputColumn("cat_status_cost3",None,None),
    OutputColumn("age_cat2",None,None),
    OutputColumn("account_id",None,None),
    OutputColumn("product_id",None,None),
    OutputColumn("pcp_assign",None,None),
    OutputColumn("zip",None,None),
    OutputColumn("contract_id",None,None),
    OutputColumn("mem_userdef_1_id",None,None),
    OutputColumn("at_risk_status_id",None,None),
    OutputColumn("mem_userdef_2_id",None,None),
    OutputColumn("mem_userdef_3_id",None,None),
    OutputColumn("mem_userdef_4_id",None,None),
    OutputColumn("NEW_MEM_ATTR_ID",None,None)))

  def directoryLevel: String = "L2"


}
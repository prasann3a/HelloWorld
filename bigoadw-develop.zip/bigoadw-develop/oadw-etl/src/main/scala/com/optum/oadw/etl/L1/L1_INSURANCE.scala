
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_insurance, insurance}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_INSURANCE extends TableInfo[l1_insurance]{
  override def dependsOn: Set[String] = Set("INSURANCE")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_INSURANCE"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("INSURANCE").as[insurance]

    cdrTbl
    .select(
		$"groupid".as("client_id"),
		$"datasrc",
		$"facilityid",
		$"encounterid",
		$"patientid",
		$"sourceid",
		$"ins_timestamp".as("insurance_dt"),
		$"insuranceorder",
		$"payorcode",
		$"payorname",
		$"plantype",
		$"plancode",
		$"planname",
		$"groupnbr",
		$"policynumber",
		$"enrollstartdt".as("enrollstart_dt"),
		$"enrollenddt".as("enrollend_dt"),
		$"mappedpayorcode",
		$"client_ds_id",
		$"hgpid",
		$"grp_mpi".as("mpi"),
		$"mappedplanfincode",
		$"pharmacy_benefit_flag",
		$"product_code",
		$"product_name",
		$"subscriber_id",
		$"subscriber_flag",
		$"subscriber_relation",
		$"contract_id",
		$"emp_acct_id",
		$"contract_type_code",
		$"benefit_plan_code",
		$"coverage_class_code"
    )
  }
}


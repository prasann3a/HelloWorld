package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l2_map_hosp_site, md_oadw_instance}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, _}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_MAP_HOSP_SITE extends TableInfo[l2_map_hosp_site] {
  override def name: String = "L2_MAP_HOSP_SITE"
  override def dependsOn: Set[String] = Set("L1_FACILITY_EXT", "MD_OADW_INSTANCE")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val mdInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]

    val clientId = mdInstance
      .where($"attribute_name" === lit("CLIENT_ID"))
      .select($"attribute_value".as("client_id"))

    val tl2MapHospSite = loadedDependencies("L1_FACILITY_EXT")
    tl2MapHospSite
      .filter($"master_facility_cd".isNotNull)
      .groupBy($"client_id", $"master_facility_cd", $"master_hgfacid")
      .agg(
        max($"master_facility_nm").as("hosp_site_desc"),
        max($"facility_postal_cd").as( "hosp_site_zip")
      )
      .select(
        $"master_facility_cd".as("hosp_site_cd"),
        $"hosp_site_desc",
        $"master_hgfacid".as("hosp_site_id"),
        $"hosp_site_zip",
        $"client_id"
      )
      .union(clientId.selectExpr(
        "'Unknown or N/A' as hosp_site_cd",
        "'Unknown or N/A' as hosp_site_desc",
        "-1 as hosp_site_id",
        "'Unknown or N/A' as hosp_site_zip",
        "client_id as client_id")
      )
  }
}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_patientaddr, patientaddr}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PATIENTADDR extends TableInfo[l1_patientaddr]{
  override def dependsOn: Set[String] = Set("PATIENTADDR")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PATIENTADDR"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val patientaddr = loadedDependencies("PATIENTADDR").as[patientaddr]

    patientaddr
    .select(
			$"groupid".as("client_id"),
			$"client_ds_id",
			$"datasrc",
			$"patientid",
			$"hgpid",
			$"grp_mpi".as("mpi"),
			$"address_date".as("address_dtm"),
			$"address_type",
			$"address_line1",
			$"address_line2",
			$"city",
			$"state",
			$"zipcode"
    )
  }
}


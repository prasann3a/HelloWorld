package com.optum.oadw.etl.L2
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadw_ref.models.l2_map_sensitive_category
import com.optum.oadw.oadwModels._
import com.optum.oadw.utils.DataframeExtensions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object L2_MAP_APR_DRG extends TableInfo[l2_map_apr_drg] {

  def directoryLevel = "L2"

  override def name: String = "L2_MAP_APR_DRG"





  val originalSqlFileName: String = "L2_map_apr_drg_build.sql"

  override def dependsOn: Set[String] = Set("L2_MAP_APR_DRG_ENCOUNTER_GRP", "L2_II_CONFINEMENTS", "L2_II_MAP_DRG")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempMapAprDrg = loadedDependencies("L2_MAP_APR_DRG_ENCOUNTER_GRP").as[l2_map_apr_drg].alias("tempMapAprDrg")
    val l2IIConfinements = loadedDependencies("L2_II_CONFINEMENTS").as[l2_ii_confinements].alias("l2IIConfinements") //.castToDouble(Set("amt_pay_cf", "amt_eqv_cf"))
    val tl2IIMapDrg = loadedDependencies("L2_II_MAP_DRG").as[l2_ii_map_drg].alias("tl2IIMapDrg")

    createL2MapAprDrg(sparkSession, tempMapAprDrg, l2IIConfinements, tl2IIMapDrg)
  }

  private def createL2MapAprDrg(sparkSession: SparkSession,
                                tempMapAprDrg: Dataset[l2_map_apr_drg],
                                l2IIConfinements: Dataset[l2_ii_confinements],
                                tl2IIMapDrg: Dataset[l2_ii_map_drg]): DataFrame = {

    val tL2MapAprDrg = iiConfinementBasedMap(sparkSession, l2IIConfinements, tl2IIMapDrg, tempMapAprDrg)

    val finalResultSet = tempMapAprDrg.union(tL2MapAprDrg).distinct()

    finalResultSet.toDF()
  }

  private def iiConfinementBasedMap(session: SparkSession,
                                    l2IIConfinements: Dataset[l2_ii_confinements],
                                    tl2IIMapDrg: Dataset[l2_ii_map_drg],
                                    tempMapAprDrg: Dataset[l2_map_apr_drg]): Dataset[l2_map_apr_drg] = {
    import org.apache.spark.sql.functions._
    import session.implicits._

    val maxAprDrgId = tempMapAprDrg.select(max($"apr_drg_id").as("max_apr_drg_id"))

    val data = l2IIConfinements
      .join(tl2IIMapDrg, l2IIConfinements("drg_id") === tl2IIMapDrg("drg_id"), "inner")
      .join(tempMapAprDrg, tl2IIMapDrg("drg_code") === tempMapAprDrg("apr_drg_cd"), "leftouter")
      .select(
        $"tl2IIMapDrg.drg_code".as("apr_drg_cd"),
        concat(lit("APR-DRG "), $"tl2IIMapDrg.drg_code", lit(": Not Supported")).as("apr_drg_description"),
        expr("nvl(tl2IIMapDrg.drg_level, 0)").as("apr_drg_sev"),
        lit(0).as("apr_drg_risk"),
        lit(1).as("sensitive_ind"))
      .where($"tl2IIMapDrg.drg_version" === lit("APR") && $"tl2IIMapDrg.drg_code".isNotNull && $"tempMapAprDrg.apr_drg_id".isNull && $"tl2IIMapDrg.drg_code" =!= lit("Unsp") && expr("nvl(tl2IIMapDrg.drg_level, 0)") === tempMapAprDrg("apr_drg_sev"))
      .distinct()

    val crossedData = data.crossJoin(maxAprDrgId)
    val window = Window.orderBy("apr_drg_cd")
    val result = crossedData
      .withColumn("apr_drg_row_id", row_number().over(window) + $"max_apr_drg_id")
      .select(
        $"apr_drg_cd",
        $"apr_drg_description",
        $"apr_drg_row_id".as("apr_drg_id"),
        $"apr_drg_risk".cast(IntegerType),
        $"apr_drg_sev".cast(IntegerType),
        lit(2).as("sensitive_cat_id").cast(IntegerType),
        $"sensitive_ind".cast(IntegerType)).as[l2_map_apr_drg]
    result
  }
}

object L2_MAP_APR_DRG_SEED extends TableInfo[l2_map_apr_drg] {
  override def name: String = "L2_MAP_APR_DRG_SEED"

  override def dependsOn: Set[String] = Set("L1_REF_APR_DRG_3M", "L1_REF_SENSITIVE_APRDRG", "L2_MAP_SENSITIVE_CATEGORY")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1RefAprDrg3M = loadedDependencies("L1_REF_APR_DRG_3M").as[l1_ref_apr_drg_3m].alias("l1RefAprDrg3M")
    val l1RefSensitiveAprDrg = loadedDependencies("L1_REF_SENSITIVE_APRDRG").as[l1_ref_sensitive_aprdrg].alias("l1RefSensitiveAprDrg")
    val tL2MapSensitiveCategory = loadedDependencies("L2_MAP_SENSITIVE_CATEGORY").as[l2_map_sensitive_category].alias("tL2MapSensitiveCategory")

    val seedDF = getSeedDataFrame(sparkSession).alias("seedDF")

    val artificialDataset = initialDataset(sparkSession, l1RefAprDrg3M, l1RefSensitiveAprDrg, tL2MapSensitiveCategory).alias("artificialDataSet")

    val initialMapAprDrg = seedDF.union(artificialDataset).distinct().alias("initialMapAprDrg")

    initialMapAprDrg.toDF()
  }

  private def getSeedDataFrame(implicit session: SparkSession): Dataset[l2_map_apr_drg] = {
    import session.implicits._

    dataframe(
      l2_map_apr_drg(apr_drg_id = 0, apr_drg_cd = " ", apr_drg_description = "UNSPECIFIED", apr_drg_sev = 0, apr_drg_risk = 0, sensitive_ind = 0, sensitive_cat_id = 1),
      l2_map_apr_drg(apr_drg_id = 1, apr_drg_cd = "955", apr_drg_description = "PRINCIPAL DIAGNOSIS INVALID AS DISCHARGE DIAGNOSIS", apr_drg_sev = 0, apr_drg_risk = 0, sensitive_ind = 0, sensitive_cat_id = 1),
      l2_map_apr_drg(apr_drg_id = 2, apr_drg_cd = "956", apr_drg_description = "UNGROUPABLE", apr_drg_sev = 0, apr_drg_risk = 0, sensitive_ind = 0, sensitive_cat_id = 1)
    ).as[l2_map_apr_drg]
  }

  private def initialDataset(implicit session: SparkSession,
                             l1RefAprDrg3M: Dataset[l1_ref_apr_drg_3m],
                             l1RefSensitiveAprDrg: Dataset[l1_ref_sensitive_aprdrg],
                             tL2MapSensitiveCategory: Dataset[l2_map_sensitive_category]): Dataset[l2_map_apr_drg] = {
    import org.apache.spark.sql.functions._
    import session.implicits._

    val riskCounters = dataframe(
      risk(0), risk(1), risk(2), risk(3), risk(4)
    ).as[risk]

    val withoutSoi = l1RefAprDrg3M
      .filter(l1RefAprDrg3M("soi_subclass") === lit("1") && !l1RefAprDrg3M("apr_drg").isin("955", "956"))
      .join(l1RefSensitiveAprDrg, l1RefAprDrg3M("apr_drg") === l1RefSensitiveAprDrg("aprdrg"), "leftouter")
      .join(tL2MapSensitiveCategory, expr("UPPER(l1RefAprDrg3M.drg_description) LIKE CONCAT('%', UPPER(tL2MapSensitiveCategory.sensitive_text), '%') AND l1RefSensitiveAprDrg.aprdrg IS NOT NULL"), "left")
      .crossJoin(riskCounters)
      .select(
        $"apr_drg".as("apr_drg_cd"),
        lit(0).as("apr_drg_sev"),
        $"risk_counter".as("apr_drg_risk"),
        $"drg_description".as("apr_drg_description"),
        expr("nvl2(aprdrg, 1, 0)").as("sensitive_ind"),
        first($"sensitive_cat_id").over(Window.orderBy($"sensitive_hierarchy").partitionBy($"apr_drg")).as("sensitive_cat_id")).alias("withoutSoi")

    val withSoi = l1RefAprDrg3M
      .filter(!l1RefAprDrg3M("apr_drg").isin("955", "956"))
      .join(l1RefSensitiveAprDrg, l1RefAprDrg3M("apr_drg") === l1RefSensitiveAprDrg("aprdrg"), "leftouter")
      .join(tL2MapSensitiveCategory, expr("UPPER(l1RefAprDrg3M.drg_description) LIKE CONCAT('%', UPPER(tL2MapSensitiveCategory.sensitive_text), '%') AND l1RefSensitiveAprDrg.aprdrg IS NOT NULL"), "left")
      .crossJoin(riskCounters).select(
      $"apr_drg".as("apr_drg_cd"),
      $"soi_subclass".as("apr_drg_sev"),
      $"risk_counter".as("apr_drg_risk"),
      $"drg_description".as("apr_drg_description"),
      expr("nvl2(aprdrg, 1, 0)").as("sensitive_ind"),
      first($"sensitive_cat_id").over(Window.orderBy($"sensitive_hierarchy").partitionBy($"apr_drg")).as("sensitive_cat_id")).alias("withSoi")

    val window = Window.orderBy("apr_drg_cd", "apr_drg_risk", "apr_drg_sev")
    val unionDf = withoutSoi.union(withSoi).distinct().alias("unionDf")
    val dataset = unionDf
      .withColumn("apr_drg_id", row_number().over(window) + 1000)
      .select(
        $"apr_drg_cd".as("apr_drg_cd"),
        $"apr_drg_description".as("apr_drg_description"),
        $"apr_drg_id".as("apr_drg_id"),
        $"apr_drg_risk".as("apr_drg_risk"),
        $"apr_drg_sev".as("apr_drg_sev").cast(IntegerType),
        when($"sensitive_ind" === lit(1), expr("nvl(sensitive_cat_id, 999)")).otherwise(lit(1)).as("sensitive_cat_id"),
        $"sensitive_ind".as("sensitive_ind")
      ).as[l2_map_apr_drg]

    dataset
  }
}

object L2_MAP_APR_DRG_ENCOUNTER_GRP extends TableInfo[l2_map_apr_drg] {
  override def name: String = "L2_MAP_APR_DRG_ENCOUNTER_GRP"

  override def dependsOn: Set[String] = Set("L2_MAP_APR_DRG_SEED", "L1_ENCOUNTER_GRP_FACILITY")

  def directoryLevel: String = "L2"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val initialMapAprDrg = loadedDependencies("L2_MAP_APR_DRG_SEED").as[l2_map_apr_drg].alias("initialMapAprDrg")
    val l1EncounterGrp = loadedDependencies("L1_ENCOUNTER_GRP_FACILITY").castToLong(Set("admittingphys_mstr_id", "admittingphys_ds_id", "lastattphys_ds_id", "lastattphys_mstr_id")).as[l1_encounter_grp_facility].alias("l1EncounterGrp")
    val tL2MapAprDrgTemp = encounterGrpBasedMap(sparkSession, l1EncounterGrp, initialMapAprDrg)
    val tempMapAprDrg = initialMapAprDrg.union(tL2MapAprDrgTemp).distinct().alias("tempMapAprDrg")
    tempMapAprDrg.toDF()
  }

  private def encounterGrpBasedMap(session: SparkSession,
                                   l1EncounterGrp: Dataset[l1_encounter_grp_facility],
                                   initialMapAprDrg: Dataset[l2_map_apr_drg]): Dataset[l2_map_apr_drg] = {
    import org.apache.spark.sql.functions._
    import session.implicits._

    val maxAprDrgId = initialMapAprDrg.select(max($"apr_drg_id").as("max_apr_drg_id")).alias("maxAprDrgId")

    val data = l1EncounterGrp
      .join(initialMapAprDrg, $"l1EncounterGrp.aprdrg" === $"initialMapAprDrg.apr_drg_cd", "leftouter")
      .select(
        $"l1EncounterGrp.aprdrg".as("apr_drg_cd"),
        concat(lit("APR-DRG "), $"l1EncounterGrp.aprdrg", lit(": Not Supported")).as("apr_drg_description"),
        expr("nvl(l1EncounterGrp.aprdrg_sev, 0)").as("apr_drg_sev"),
        expr("nvl(l1EncounterGrp.aprdrg_risk, 0)").as("apr_drg_risk"),
        lit(1).as("sensitive_ind"))
      .where($"l1EncounterGrp.aprdrg".isNotNull && $"initialMapAprDrg.apr_drg_id".isNull && expr("nvl(l1EncounterGrp.aprdrg_sev, 0)") === expr("nvl(initialMapAprDrg.apr_drg_sev, 0)")
        && expr("nvl(l1EncounterGrp.aprdrg_risk, 0)") === expr("nvl(initialMapAprDrg.apr_drg_risk, 0)"))
      .distinct().alias("data")

    val crossedData = data.crossJoin(maxAprDrgId).alias("crossedData")

    val window = Window.orderBy("apr_drg_cd", "apr_drg_risk", "apr_drg_sev")
    crossedData
      .withColumn("apr_drg_row_id", row_number().over(window) + $"max_apr_drg_id")
      .select(
        $"apr_drg_cd",
        $"apr_drg_description",
        $"apr_drg_row_id".as("apr_drg_id"),
        $"apr_drg_risk".cast(IntegerType),
        $"apr_drg_sev".cast(IntegerType),
        lit(2).as("sensitive_cat_id").cast(IntegerType),
        $"sensitive_ind".cast(IntegerType)).as[l2_map_apr_drg]
  }
}

case class risk(risk_counter: Int)

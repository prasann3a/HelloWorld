package com.optum.oadw.etl.L3


import com.optum.oadw.etl.constants.Procedures
import com.optum.oadw.oadwModels.l3_map_proc_group
import com.optum.oadw.oadw_ref.models.l3_map_precursor_proc
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L3_MAP_PRECURSOR_PROC extends TableInfo[l3_map_precursor_proc] {
  override def name: String = "L3_MAP_PRECURSOR_PROC"

  override def dependsOn: Set[String] = Set("REFERENCE_SCHEMA_L3_MAP_PRECURSOR_PROC", "L3_MAP_PROC_GROUP")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val refMapPrecursorProc = loadedDependencies("REFERENCE_SCHEMA_L3_MAP_PRECURSOR_PROC").as[l3_map_precursor_proc]
    val mapProcGroup = loadedDependencies("L3_MAP_PROC_GROUP").as[l3_map_proc_group]

    val filteredNonProcGroups = refMapPrecursorProc.filter($"code_type" =!= lit(Procedures.CODE_TYPE_PROCEDURE_GROUP))
      .select(
        $"precursor_id",
        $"code_type",
        $"proc_cd",
        $"exclude_hosp_ind"
      )

    val filteredProcGroups =
      refMapPrecursorProc.filter($"code_type" === lit(Procedures.CODE_TYPE_PROCEDURE_GROUP))
        .as("pp")
        .join(mapProcGroup.as("pg"), $"pg.proc_group_id" === $"pp.proc_cd".cast(IntegerType), "inner")
        .select(
          $"pp.precursor_id",
          $"pg.code_type",
          $"pg.proc_cd",
          $"pp.exclude_hosp_ind"
        )

    filteredNonProcGroups
      .union(filteredProcGroups)
  }
}

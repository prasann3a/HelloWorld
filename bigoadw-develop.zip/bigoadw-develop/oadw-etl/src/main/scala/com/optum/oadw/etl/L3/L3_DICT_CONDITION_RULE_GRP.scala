package com.optum.oadw.etl.L3

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l3_map_condition_rule_grp
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.oadw.oadwModels.{l3_dict_condition_rule, l3_dict_condition_rule_grp}
import org.apache.spark.sql.expressions.Window

object L3_DICT_CONDITION_RULE_GRP extends TableInfo[l3_dict_condition_rule_grp] {

  override def name: String = "L3_DICT_CONDITION_RULE_GRP"

  override def dependsOn: Set[String] = Set("L3_DICT_CONDITION_RULE", "L3_MAP_CONDITION_RULE_GRP")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tL3DictConditionRule = loadedDependencies("L3_DICT_CONDITION_RULE").as[l3_dict_condition_rule].select($"condition_id", $"rule_id".as("rule_grp"), $"rule_id", $"condition_rule_desc")
    val tempL3DictMapCondRuleGrp = loadedDependencies("L3_MAP_CONDITION_RULE_GRP").as[l3_map_condition_rule_grp]

    tempL3DictMapCondRuleGrp.as("rg")
      .join(tL3DictConditionRule.as("dcr"), $"rg.condition_id" === $"dcr.condition_id" && $"rg.rule_id" === $"dcr.rule_id", "inner")
      .select($"rg.condition_id".as("condition_id"), $"rg.rule_grp".as("rule_grp"), $"rg.rule_id".as("rule_id"), $"dcr.condition_rule_desc".as("condition_rule_desc"))
      .select($"condition_id", $"rule_grp", collect_list($"condition_rule_desc").over(Window.partitionBy($"condition_id", $"rule_grp").orderBy($"rule_id")).as("condition_rule_desc_list"))
      .select($"condition_id", $"rule_grp", $"condition_rule_desc_list", row_number().over(Window.partitionBy($"condition_id", $"rule_grp").orderBy(size($"condition_rule_desc_list").desc)).as("row_num"))
      .filter($"row_num" === 1)
      .select($"condition_id", $"rule_grp", concat_ws("; ", $"condition_rule_desc_list").as("condition_rule_grp_desc"))
  }

}

package com.optum.oadw.etl

import com.optum.oadw.utils.{FeatureManager, Features}
import org.json4s.jackson.JsonMethods.parse

case class MeasureFilters (
  excluded_measures : Map[String, Seq[String]],
  included_measures : Map[String, Seq[String]]
)

object Filters {

  def apply(filterStr: Option[String]): MeasureFilters ={
    var exclude_measures: Map[String, Seq[String]] = Map.empty
    var include_measures:Map[String,Seq[String]] = Map.empty
    if(FeatureManager.Instance.isEnable(Features.EtlFilters)) {
      val filterMap = jsonStrToMap(filterStr.get)

      if(filterMap.contains("measures")) {
        val measure_filters: Map[String, Map[String, Seq[String]]] = filterMap("measures")
        if (measure_filters.contains("excludes"))
          exclude_measures = measure_filters("excludes")
        if (measure_filters.contains("includes"))
          include_measures =  measure_filters("includes")
      }
    }
    MeasureFilters(exclude_measures, include_measures)
  }


  def jsonStrToMap(jsonStr: String): Map[String,Map[String, Map[String, Seq[String]]]] = {
    implicit val formats = org.json4s.DefaultFormats

    parse(jsonStr).extract[Map[String,Map[String, Map[String, Seq[String]]]]]
  }
}


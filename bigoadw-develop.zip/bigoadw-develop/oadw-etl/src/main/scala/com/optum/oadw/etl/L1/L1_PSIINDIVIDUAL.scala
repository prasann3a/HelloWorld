package com.optum.oadw.etl.L1

import com.optum.oadw.common.models.OADWRuntimeVariables
import com.optum.oadw.oadwModels.l1_psiindividual
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.{DecimalType, IntegerType, LongType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.net.URI
import org.apache.hadoop.fs.{FileSystem, Path}

object L1_PSIINDIVIDUAL  extends TableInfo[l1_psiindividual]{
  override def dependsOn: Set[String] = Set()

  override def name: String = "L1_PSIINDIVIDUAL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val oadwRuntimeVariables = OADWRuntimeVariables(runtimeVariables)

    val filePath = oadwRuntimeVariables.protocol match {

      case "s3" => s"s3://${oadwRuntimeVariables.bucket.get}/${oadwRuntimeVariables.environment}/external/ahrq/${oadwRuntimeVariables.cdrCycle}/${oadwRuntimeVariables.instance}/PSIINDIVIDUAL"
      case "hdfs" => s"hdfs://somhorton1/optum/data_factory/${oadwRuntimeVariables.clientId}/${oadwRuntimeVariables.environment}/external/ahrq/${oadwRuntimeVariables.cdrCycle}/${oadwRuntimeVariables.instance}/PSIINDIVIDUAL"
      case "test" => s"${oadwRuntimeVariables.extras.get("filePath").head}"
      case "" => return Seq.empty[l1_psiindividual].toDF  // no protocol for query testing framework
      case _ => throw new IllegalArgumentException
    }

    val fs: FileSystem = FileSystem.get(URI.create(filePath), sparkSession.sparkContext.hadoopConfiguration)

    if (!fs.exists(new Path(filePath))){
      return Seq.empty[l1_psiindividual].toDF
    }

    val psiIndividual = sparkSession.read
      .format("csv")
      .option("header", "true")
      .load(filePath)

    psiIndividual
      .select(
        $"key".cast(LongType).as("encounter_grp_num"),
        $"age".cast(IntegerType),
        $"sex".cast(IntegerType),
        $"hospid".cast(LongType),
        $"los".cast(IntegerType),
        $"drg".cast(IntegerType),
        $"year".cast(IntegerType),
        $"dqtr".cast(IntegerType),
        $"mdc".cast(IntegerType),
        $"mdrg".cast(IntegerType),
        $"paycat".cast(IntegerType),
        $"racecat".cast(IntegerType),
        $"agecat".cast(IntegerType),
        $"sexcat".cast(IntegerType),
        $"tpps02".cast(IntegerType),
        $"ppps02".cast(IntegerType),
        $"tpps03".cast(IntegerType),
        $"ppps03".cast(IntegerType),
        $"tpps04".cast(IntegerType),
        $"ppps04".cast(IntegerType),
        $"tpps04_dvt_pe".cast(IntegerType),
        $"ppps04_dvt_pe".cast(IntegerType),
        $"tpps04_pneumonia".cast(IntegerType),
        $"ppps04_pneumonia".cast(IntegerType),
        $"tpps04_sepsis".cast(IntegerType),
        $"ppps04_sepsis".cast(IntegerType),
        $"tpps04_shock".cast(IntegerType),
        $"ppps04_shock".cast(IntegerType),
        $"tpps04_gihemorrhage".cast(IntegerType),
        $"ppps04_gihemorrhage".cast(IntegerType),
        $"tpps05".cast(IntegerType),
        $"ppps05".cast(IntegerType),
        $"tpps06".cast(IntegerType),
        $"ppps06".cast(IntegerType),
        $"tpps07".cast(IntegerType),
        $"ppps07".cast(IntegerType),
        $"tpps08".cast(IntegerType),
        $"ppps08".cast(IntegerType),
        $"tpps09".cast(IntegerType),
        $"ppps09".cast(IntegerType),
        $"tpps10".cast(IntegerType),
        $"ppps10".cast(IntegerType),
        $"tpps11".cast(IntegerType),
        $"ppps11".cast(IntegerType),
        $"tpps12".cast(IntegerType),
        $"ppps12".cast(IntegerType),
        $"tpps13".cast(IntegerType),
        $"ppps13".cast(IntegerType),
        $"tpps14".cast(IntegerType),
        $"ppps14".cast(IntegerType),
        $"tpps14_open".cast(IntegerType),
        $"ppps14_open".cast(IntegerType),
        $"tpps14_nonopen".cast(IntegerType),
        $"ppps14_nonopen".cast(IntegerType),
        $"tpps15".cast(IntegerType),
        $"ppps15".cast(IntegerType),
        $"tpps18".cast(IntegerType),
        $"ppps18".cast(IntegerType),
        $"tpps19".cast(IntegerType),
        $"ppps19".cast(IntegerType),
        $"chf".cast(IntegerType),
        $"valve".cast(IntegerType),
        $"pulmcirc".cast(IntegerType),
        $"perivasc".cast(IntegerType),
        $"para".cast(IntegerType),
        $"neuro".cast(IntegerType),
        $"chrnlung".cast(IntegerType),
        $"dm".cast(IntegerType),
        $"dmcx".cast(IntegerType),
        $"hypothy".cast(IntegerType),
        $"renlfail".cast(IntegerType),
        $"liver".cast(IntegerType),
        $"ulcer".cast(IntegerType),
        $"aids".cast(IntegerType),
        $"lymph".cast(IntegerType),
        $"mets".cast(IntegerType),
        $"tumor".cast(IntegerType),
        $"arth".cast(IntegerType),
        $"coag".cast(IntegerType),
        $"obese".cast(IntegerType),
        $"wghtloss".cast(IntegerType),
        $"lytes".cast(IntegerType),
        $"bldloss".cast(IntegerType),
        $"anemdef".cast(IntegerType),
        $"alcohol".cast(IntegerType),
        $"drug".cast(IntegerType),
        $"psych".cast(IntegerType),
        $"depress".cast(IntegerType),
        $"htn_c".cast(IntegerType),
        $"trnsfer".cast(IntegerType),
        $"tppsmhat02".cast(DecimalType(18,10)),
        $"tppsmhat03".cast(DecimalType(18,10)),
        $"tppsmhat04_dvt_pe".cast(DecimalType(18,10)),
        $"tppsmhat04_pneumonia".cast(DecimalType(18,10)),
        $"tppsmhat04_sepsis".cast(DecimalType(18,10)),
        $"tppsmhat04_shock".cast(DecimalType(18,10)),
        $"tppsmhat04_gihemorrhage".cast(DecimalType(18,10)),
        $"tppsmhat06".cast(DecimalType(18,10)),
        $"tppsmhat07".cast(DecimalType(18,10)),
        $"tppsmhat08".cast(DecimalType(18,10)),
        $"tppsmhat09".cast(DecimalType(18,10)),
        $"tppsmhat10".cast(DecimalType(18,10)),
        $"tppsmhat11".cast(DecimalType(18,10)),
        $"tppsmhat12".cast(DecimalType(18,10)),
        $"tppsmhat13".cast(DecimalType(18,10)),
        $"tppsmhat14_open".cast(DecimalType(18,10)),
        $"tppsmhat14_nonopen".cast(DecimalType(18,10)),
        $"tppsmhat15".cast(DecimalType(18,10))
      )
  }

}


package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_ebm_summaryresult, ebm_summaryresult}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_EBM_SUMMARYRESULT extends TableInfo[l1_ebm_summaryresult]{
  override def dependsOn: Set[String] = Set("EBM_SUMMARYRESULT")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_EBM_SUMMARYRESULT"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ebmSummaryresult = loadedDependencies("EBM_SUMMARYRESULT").as[ebm_summaryresult]

    ebmSummaryresult
    .select(
			$"groupid".as("client_id"),
			$"grp_mpi".as("mpi"),
			$"report_case_id",
			$"event",
			$"report_rule_id",
			$"task_number",
			$"rule_type_num",
			$"result_flag",
			$"ebm_flag",
			$"comp_flag",
			$"file_processing_month".as("file_processing_month_dt"),
			$"process"
    )
  }
}


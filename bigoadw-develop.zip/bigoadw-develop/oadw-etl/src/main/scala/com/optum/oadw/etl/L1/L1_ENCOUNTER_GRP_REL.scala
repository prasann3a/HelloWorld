
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_encounter_grp_rel, encounter_grp_rel}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_ENCOUNTER_GRP_REL extends TableInfo[l1_encounter_grp_rel]{
  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_ENCOUNTER_GRP_REL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val cdrTbl = loadedDependencies("ENCOUNTER_GRP_REL").as[encounter_grp_rel]

    cdrTbl
    .select(
		$"groupid".as("client_id"),
		$"encounter_grp_num",
		$"encounter_grp_rel_type",
		$"rel_encounter_grp_num"
    )
  }
}


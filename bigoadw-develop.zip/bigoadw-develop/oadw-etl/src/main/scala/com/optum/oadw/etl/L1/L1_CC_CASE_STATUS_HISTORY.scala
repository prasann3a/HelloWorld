
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_cc_case_status_history, cc_case_status_history}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_CC_CASE_STATUS_HISTORY extends TableInfo[l1_cc_case_status_history]{
  override def dependsOn: Set[String] = Set("CC_CASE_STATUS_HISTORY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CC_CASE_STATUS_HISTORY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val ccCaseStatusHistory = loadedDependencies("CC_CASE_STATUS_HISTORY").as[cc_case_status_history]

    ccCaseStatusHistory
    .select(
			$"case_owner_id",
			$"case_stat_elapsed_hr",
			$"case_stat_end_dtm",
			$"case_stat_last_mod_by_id",
			$"case_stat_nm",
			$"case_stat_start_dtm",
			$"case_status",
			$"cc_case_id",
			$"cc_case_stat_hist_id",
			$"client_ds_id",
			$"datasrc",
			$"groupid".as("client_id"),
			$"grp_mpi".as("mpi"),
			$"hgpid",
			$"patientid"
    )
  }
}


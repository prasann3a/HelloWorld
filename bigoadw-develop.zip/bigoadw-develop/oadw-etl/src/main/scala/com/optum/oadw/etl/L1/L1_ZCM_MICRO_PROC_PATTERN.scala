
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_zcm_micro_proc_pattern, zcm_micro_proc_pattern}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_ZCM_MICRO_PROC_PATTERN extends TableInfo[l1_zcm_micro_proc_pattern]{
  override def dependsOn: Set[String] = Set("ZCM_MICRO_PROC_PATTERN")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_ZCM_MICRO_PROC_PATTERN"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zcmMicroProcPattern = loadedDependencies("ZCM_MICRO_PROC_PATTERN").as[zcm_micro_proc_pattern]

    zcmMicroProcPattern
    .select(
			$"groupid".as("client_id"),
			$"txt_pattern",
			$"priority",
			$"cui",
			$"dts_version"
    )
  }
}


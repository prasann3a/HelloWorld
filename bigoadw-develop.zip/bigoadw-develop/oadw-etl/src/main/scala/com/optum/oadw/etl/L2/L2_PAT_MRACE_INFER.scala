package com.optum.oadw.etl.L2

import com.optum.oadw.definedfunctions.{ListAgg}
import com.optum.oadw.oadwModels.{l1_pat_mrace_infer, l2_pat_mrace_infer}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_PAT_MRACE_INFER extends TableInfo[l2_pat_mrace_infer]{
  override def dependsOn: Set[String] = Set("L1_PAT_MRACE_INFER")

  override def skipCoalesce: Boolean = true
	override def name: String = "L2_PAT_MRACE_INFER"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val l1PatMraceInfer = loadedDependencies("L1_PAT_MRACE_INFER").as[l1_pat_mrace_infer]
    val listAgg  = new ListAgg()

    l1PatMraceInfer
      .groupBy($"client_id", $"mpi", $"mapped_race")
      .agg(listAgg($"client_ds_id").as("cds_grp"))
  }
}


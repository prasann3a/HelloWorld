
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_contact_summary, zh_prov_contact_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_CONTACT_SUMMARY extends TableInfo[l1_prov_contact_summary]{
  override def dependsOn: Set[String] = Set("ZH_PROV_CONTACT_SUMMARY")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_CONTACT_SUMMARY"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhProvContactSummary = loadedDependencies("ZH_PROV_CONTACT_SUMMARY").as[zh_prov_contact_summary]

    zhProvContactSummary
    .select(
		$"groupid".as("client_id"),
		$"master_hgprovid",
		$"npi",
		$"specialty_code",
		$"specialty_name",
		$"address_line1",
		$"address_line2",
		$"city",
		$"state",
		$"zipcode",
		$"work_phone",
		$"email_address",
		$"local_contact_type",
		$"mapped_contact_type"
    )
  }
}


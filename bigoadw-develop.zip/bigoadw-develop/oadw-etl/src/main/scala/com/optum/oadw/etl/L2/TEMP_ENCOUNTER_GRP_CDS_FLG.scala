
package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l1_encounter_grp_facility, md_oadw_instance}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

case class temp_encounter_grp_cds_flg_data(
  display_ds_id: java.lang.Integer = null,
  admittingphys_mstr_id: java.lang.Long = null,
  cms_ddisp: String = null,
  facility_ds_id: java.lang.Integer = null,
  lastattteam: String = null,
  display_id_type: String = null,
  lastattphysician: String = null,
  admit_dtm: java.sql.Timestamp = null,
  cms_rehab: String = null,
  insuranceplan: String = null,
  cmsplanned: String = null,
  prinpx_codetype: String = null,
  discharge_dtm: java.sql.Timestamp = null,
  prov_id: String = null,
  aprdrg_risk: String = null,
  finclass: String = null,
  elos: java.lang.Double = null,
  cmsinclude: String = null,
  servicecode: String = null,
  client_id: String = null,
  aprdrg_sev: String = null,
  clientplanned: String = null,
  prindx: String = null,
  localdischargedisposition: String = null,
  aprdrg: String = null,
  encounter_grp_num: java.lang.Long = null,
  display_encounterid: String = null,
  encounterservice: String = null,
  encounter_grp_type: String = null,
  drgtypecui: String = null,
  convert_ip: String = null,
  cms_non_surgcancer: String = null,
  lastattteam_ds_id: java.lang.Integer = null,
  admitted_er: String = null,
  cost: java.lang.Double = null,
  cms_psych: String = null,
  lastlocation: String = null,
  admittingphys_ds_id: java.lang.Long = null,
  facilityid: String = null,
  master_facility_cd: String = null,
  siteofcare_cd: String = null,
  admittingphysician: String = null,
  charge: java.lang.Double = null,
  lastattphys_ds_id: java.lang.Long = null,
  baseinclude: String = null,
  localadmitsource: String = null,
  drg: String = null,
  arrival_dtm: java.sql.Timestamp = null,
  mpi: String = null,
  mappedzipcode: String = null,
  cost_charge_ratio: java.lang.Double = null,
  prinpx: String = null,
  prindx_codetype: String = null,
  cms_rehabp: String = null,
  lastattteam_mstr_id: java.lang.Integer = null,
  lastattphys_mstr_id: java.lang.Long = null,
  mdc: String = null,
  cds_grp: String = null
)

object TEMP_ENCOUNTER_GRP_CDS_FLG extends TableInfo[temp_encounter_grp_cds_flg_data] {
  private val log = LoggerFactory.getLogger(this.getClass)

  override def name: String = "TEMP_ENCOUNTER_GRP_CDS_FLG"
  override def dependsOn: Set[String] = Set("L1_ENCOUNTER_GRP_FACILITY","TEMP_ENCOUNTER_GRP_NUM_CDS_FLG","MD_OADW_INSTANCE")
  def directoryLevel: String = "L2"
  override def saveDataFrameToParquet: Boolean = true
  val originalSqlFileName: String = "L2_pat_clinical_event_build.sql" // Might be we can only add this as a comment to the object

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1EncounterGrpFacility = loadedDependencies("L1_ENCOUNTER_GRP_FACILITY").as[l1_encounter_grp_facility]
    val tempEncounterGrpNumCdsFlg = loadedDependencies("TEMP_ENCOUNTER_GRP_NUM_CDS_FLG").as[temp_encounter_grp_num_cds_flg_data]
    val mdOadwInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance]
    val DataThru = mdOadwInstance
      .select(
        to_timestamp($"attribute_value", "yyyyMMdd").as("DATA_THRU")
      )
      .where(($"attribute_name")===lit("DATA_THRU"))
      .first()
      .getTimestamp(0)
      l1EncounterGrpFacility.as("eg")
        .join(tempEncounterGrpNumCdsFlg.as("cds"), $"eg.encounter_grp_num" === $"cds.encounter_grp_num")
        .where(
          $"eg.mpi".isNotNull && to_date($"eg.admit_dtm", "yyyyMMdd") <= DataThru
        )
        .select(
          l1EncounterGrpFacility.col("*"),
          $"cds.cds_grp"
        )
  }
}
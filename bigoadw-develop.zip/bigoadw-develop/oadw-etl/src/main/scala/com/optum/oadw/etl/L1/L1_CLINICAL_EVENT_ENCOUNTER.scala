
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.l1_clinical_event_encounter
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L1_CLINICAL_EVENT_ENCOUNTER extends QueryAndMetadata[l1_clinical_event_encounter] {
  override def skipCoalesce: Boolean = true
	override def name: String = "L1_CLINICAL_EVENT_ENCOUNTER"

  override def sparkSql: String = """SELECT
                                    |a.client_id, cast(a.encounter_grp_num as long) as encounter_grp_num, a.mpi, a.client_ds_id, a.encounterid, a.patienttype as patienttype_cui, a.encounteridtype as encounteridtype_cui
                                    |FROM (SELECT /*+ BROADCAST(mpv) */
                                    |eeg.client_id, eeg.encounter_grp_num, eeg.mpi, eeg.client_ds_id, eeg.encounterid, eeg.patienttype,
                                    |eeg.encounteridtype, ROW_NUMBER() OVER (PARTITION BY eeg.client_id, eeg.client_ds_id, eeg.encounterid ORDER BY CASE WHEN mpv.client_id IS NOT NULL THEN -1 ELSE 1 END * CAST (SUBSTR(eg.encounter_grp_type,3) AS INT), eg.encounter_grp_num) AS rank
                                    |FROM  L1_encounter_encounter_grp eeg
                                    |INNER JOIN  L1_ENCOUNTER_GRP_FACILITY eg ON eeg.encounter_grp_num = eg.encounter_grp_num
                                    |LEFT OUTER JOIN (
                                    |  	SELECT DISTINCT client_id FROM L1_map_predicate_values
                                    |	WHERE data_src = 'OADW' AND entity = 'L1_CLINICAL_EVENT_ENCOUNTER' AND table_name = 'L1_CLINICAL_EVENT_ENCOUNTER'
                                    |  	AND column_name = 'EG_SORT')
                                    |mpv ON mpv.client_id = eeg.client_id) a
                                    |WHERE a.rank = 1""".stripMargin

  override def dependsOn: Set[String] = Set("L1_ENCOUNTER_ENCOUNTER_GRP","L1_ENCOUNTER_GRP_FACILITY","L1_MAP_PREDICATE_VALUES")

  def originalSql: String = """-- when mpv.client_id is not null, order by eg.encounter_grp_type desc

INSERT /*+ APPEND */ INTO L1_clinical_event_encounter
  (
    client_id, encounter_grp_num, mpi, client_ds_id, encounterid, patienttype_cui, encounteridtype_cui
  )
  SELECT
    client_id, encounter_grp_num, mpi, client_ds_id, encounterid, patienttype, encounteridtype
  FROM (SELECT /*+ parallel(4) */
          eeg.client_id,
          eeg.encounter_grp_num,
          eeg.mpi,
          eeg.client_ds_id,
          eeg.encounterid,
          eeg.patienttype,
          eeg.encounteridtype,
          ROW_NUMBER() OVER (PARTITION BY eeg.client_id, eeg.client_ds_id, eeg.encounterid
                             ORDER BY CASE WHEN mpv.client_id IS NOT NULL THEN -1 ELSE 1 END * TO_NUMBER(SUBSTR(eg.encounter_grp_type,3)),
                                      eg.encounter_grp_num ) AS rank
        FROM  L1_encounter_encounter_grp eeg
        INNER JOIN  L1_encounter_grp eg ON eeg.encounter_grp_num = eg.encounter_grp_num
        LEFT OUTER JOIN ( SELECT DISTINCT client_id
                          FROM L1_map_predicate_values
                          WHERE data_src = 'OADW'
                          AND entity = 'L1_CLINICAL_EVENT_ENCOUNTER'
                          AND table_name = 'L1_CLINICAL_EVENT_ENCOUNTER'
                          AND column_name = 'EG_SORT'
                        ) mpv ON mpv.client_id = eeg.client_id
   )
  WHERE rank = 1
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("client_id",None,None), OutputColumn("encounter_grp_num",None,None), OutputColumn("mpi",None,None), OutputColumn("client_ds_id",None,None), OutputColumn("encounterid",None,None), OutputColumn("patienttype_cui",None,None), OutputColumn("encounteridtype_cui",None,None)))

  def directoryLevel: String = "L1"





  override def partitions: Int = 64

  val originalSqlFileName: String = "L1_clinical_event_encounter_build.sql"
}
     
     

package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_prov_affil_rollup, prov_affil_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_PROV_AFFIL_ROLLUP extends TableInfo[l1_prov_affil_rollup]{
  override def dependsOn: Set[String] = Set("PROV_AFFIL_ROLLUP")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_PROV_AFFIL_ROLLUP"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val provAffilRollup = loadedDependencies("PROV_AFFIL_ROLLUP").as[prov_affil_rollup]

    provAffilRollup
    .select(
			$"groupid".as("client_id"),
			$"prov_affil_id",
			$"prov_affil_desc",
			$"prov_affil_lv2",
			$"prov_affil_lv2_desc",
			$"prov_affil_lv1",
			$"prov_affil_lv1_desc",
			$"client_ds_id",
			$"datasrc"
    )
  }
}


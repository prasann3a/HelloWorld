
package com.optum.oadw.etl.L1

import com.optum.oadw.oadwModels.{l1_labresult_qual, labresult_qual}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L1_LABRESULT_QUAL extends TableInfo[l1_labresult_qual]{
  override def dependsOn: Set[String] = Set("LABRESULT_QUAL")

  override def skipCoalesce: Boolean = true
	override def name: String = "L1_LABRESULT_QUAL"

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val labresultQual = loadedDependencies("LABRESULT_QUAL").as[labresult_qual]

    labresultQual
    .select(
			$"groupid".as("client_id"),
			$"patientid",
			$"htsresultgroup",
			$"resultdate".as("result_dtm"),
			$"htslabcode",
			$"htslabresult",
			$"qualitativeresult",
			$"client_ds_id",
			$"hgpid",
			$"grp_mpi".as("mpi")
    )
  }
}


package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.l2_ii_ocu_pop_phm_costs_ext
import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L2_II_OCU_POP_PHM_COSTS_EXT extends QueryAndMetadata[l2_ii_ocu_pop_phm_costs_ext] {
  override def name: String = "L2_II_OCU_POP_PHM_COSTS_EXT"

  override def sparkSql: String =
    """
       SELECT
        YEAR_MTH_ID,
        NEW_MEM_ATTR_ID,
        FORMULARY,
        cast(CHANNEL as long) as CHANNEL,
        GBO,
        cast(TOS_I_5 as long) as TOS_I_5,
        YEAR_MTH_PD,
        NETWORK_PAID_STATUS_ID,
        PROVIDER_STATUS_ID,
        ndc,
        PRES_PRV_I,
        cast(SUM(AMT_REQ) as decimal(38,10)) as amt_req,
        cast(SUM(amt_eqv) as decimal(38,10)) as amt_eqv,
        cast(SUM(amt_pay) as decimal(38,10)) AS amt_pay,
        cast(SUM(amt_np) as decimal(38,10)) AS amt_np,
        cast(SUM(GENERIC) as int) AS GENERIC,
        cast(SUM(SCRIPT) as int) AS SCRIPT,
        cast(SUM(SCRIPT_GEN) as int) AS SCRIPT_GEN,
        cast(SUM(DAYS_SUP) as int) AS  DAYS_SUP
      FROM temp_OCU_RX_SERVICES
      GROUP BY YEAR_MTH_ID,
      NEW_MEM_ATTR_ID,FORMULARY, CHANNEL, GBO,TOS_I_5, YEAR_MTH_PD, NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,ndc,PRES_PRV_I"""

  override def dependsOn: Set[String] = Set("TEMP_OCU_RX_SERVICES")

  def originalSql: String = """


insert /*+ append */ into l2_ii_ocu_pop_phm_costs_ext (
      YEAR_MTH_ID,NEW_MEM_ATTR_ID,FORMULARY,CHANNEL,GBO,TOS_I_5,YEAR_MTH_PD,NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,ndc,PRES_PRV_I,
      amt_req,amt_eqv,amt_pay,amt_np,GENERIC,SCRIPT,SCRIPT_GEN,DAYS_SUP)
SELECT YEAR_MTH_ID, NEW_MEM_ATTR_ID,  FORMULARY, CHANNEL, GBO, TOS_I_5, YEAR_MTH_PD, NETWORK_PAID_STATUS_ID,
       PROVIDER_STATUS_ID,ndc,PRES_PRV_I,SUM(AMT_REQ), SUM(amt_eqv), SUM(amt_pay) AS amt_pay,SUM(amt_np) AS amt_np,SUM(GENERIC) AS GENERIC, SUM(SCRIPT) AS SCRIPT,
       SUM(SCRIPT_GEN) AS SCRIPT_GEN, SUM(DAYS_SUP) AS  DAYS_SUP
  FROM temp_OCU_RX_SERVICES
GROUP BY YEAR_MTH_ID,
       NEW_MEM_ATTR_ID,FORMULARY, CHANNEL, GBO,TOS_I_5, YEAR_MTH_PD, NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,ndc,PRES_PRV_I
"""

  def outputColumns: Option[Seq[OutputColumn]] = Some(List(OutputColumn("YEAR_MTH_ID",None,None), OutputColumn("NEW_MEM_ATTR_ID",None,None), OutputColumn("FORMULARY",None,None), OutputColumn("CHANNEL",None,None), OutputColumn("GBO",None,None), OutputColumn("TOS_I_5",None,None), OutputColumn("YEAR_MTH_PD",None,None), OutputColumn("NETWORK_PAID_STATUS_ID",None,None), OutputColumn("PROVIDER_STATUS_ID",None,None), OutputColumn("ndc",None,None), OutputColumn("PRES_PRV_I",None,None), OutputColumn("amt_req",None,None), OutputColumn("amt_eqv",None,None), OutputColumn("amt_pay",None,None), OutputColumn("amt_np",None,None), OutputColumn("GENERIC",None,None), OutputColumn("SCRIPT",None,None), OutputColumn("SCRIPT_GEN",None,None), OutputColumn("DAYS_SUP",None,None)))

  def directoryLevel: String = "L2"





  val originalSqlFileName: String = "L2_II_ocu_build.sql"
}

package com.optum.oadw.etl.L3

import com.optum.oadw.oadwModels.l3_admits
import com.optum.oap.sparkdataloader.QueryAndMetadata

object L3_ADMITS extends QueryAndMetadata[l3_admits] {
  override def name: String = "L3_ADMITS"

  override def sparkSql: String =
    """
      select cast(NEW_MEM_ATTR_ID as long) as NEW_MEM_ATTR_ID,IA_TIME, YEAR_MTH_ID, END_YEAR_MTH_ID, PCP_ASSIGN, product_id, sex, age_cat2, mem_userdef_1_id, at_risk_status_id, zip,
      cat_status_cost3, contract_id, provider_id, drg_id, tos_i_5, drg_admittyp, poa, network_paid_status_id, provider_status_id, avoidable_admit_flag, pqi, etg_id,
      cast(sum(admit) as int) as admit,
      cast(sum(los) as int) as los,
      sum(AMT_REQ) as amt_req,
      sum(AMT_EQV) as amt_eqv,
      sum(AMT_PAY) as amt_pay,
      sum(AMT_NP) as amt_np,
      cast(sum(readmit_index_07) as int) as readmit_index_07,
      cast(sum(readmit_index_30) as int) as readmit_index_30,
      cast(sum(readmit_index_60) as int) as readmit_index_60,
      cast(sum(readmit_index_90) as int) as readmit_index_90,
      cast(sum(readmit_07) as int) as readmit_07,
      cast(sum(readmit_30) as int) as readmit_30,
      cast(sum(readmit_60) as int) as readmit_60,
      cast(sum(readmit_90) as int) as readmit_90
      from L2_Admits cf
      group by NEW_MEM_ATTR_ID,IA_TIME, YEAR_MTH_ID, END_YEAR_MTH_ID, PCP_ASSIGN, product_id, sex, age_cat2, mem_userdef_1_id, at_risk_status_id, zip, cat_status_cost3, contract_id, provider_id, drg_id, tos_i_5, drg_admittyp, poa,
      network_paid_status_id, provider_status_id, avoidable_admit_flag, pqi, etg_id
    """

  override def dependsOn: Set[String] = Set("L2_ADMITS")

  def originalSql: String = """
---Admissions
insert /*+ append */ into l3_admits(
    NEW_MEM_ATTR_ID,IA_TIME,YEAR_MTH_ID,PCP_ASSIGN,PRODUCT_ID,SEX,AGE_CAT2,MEM_USERDEF_1_ID,ZIP,CAT_STATUS_COST3,CONTRACT_ID,PROVIDER_ID,DRG_ID,TOS_I_5,DRG_ADMITTYP,POA,
    NETWORK_PAID_STATUS_ID,PROVIDER_STATUS_ID,AVOIDABLE_ADMIT_FLAG,PQI,ETG_ID,ADMIT,LOS,AMT_REQ,AMT_EQV,AMT_PAY,AMT_NP,READMIT_INDEX_07,READMIT_INDEX_30,READMIT_INDEX_60,
    READMIT_INDEX_90,READMIT_07,READMIT_30,READMIT_60,READMIT_90
)
  select NEW_MEM_ATTR_ID,IA_TIME, YEAR_MTH_ID, PCP_ASSIGN, product_id, sex, age_cat2, mem_userdef_1_id, zip, cat_status_cost3, contract_id, provider_id, drg_id, tos_i_5, drg_admittyp, poa,
         network_paid_status_id, provider_status_id, avoidable_admit_flag, pqi, etg_id,sum(admit) as admit, sum(los) as los, sum(AMT_REQ), sum(AMT_EQV), sum(AMT_PAY), sum(AMT_NP),
         sum(readmit_index_07) as readmit_index_07, sum(readmit_index_30) as readmit_index_30,sum(readmit_index_60) as readmit_index_60,
         sum(readmit_index_90) as readmit_index_90,sum(readmit_07) as readmit_07, sum(readmit_30) as readmit_30, sum(readmit_60) as readmit_60,sum(readmit_90) as readmit_90
    from L2_Admits cf
    group by NEW_MEM_ATTR_ID,IA_TIME, YEAR_MTH_ID, PCP_ASSIGN, product_id, sex, age_cat2, mem_userdef_1_id, zip, cat_status_cost3, contract_id, provider_id, drg_id, tos_i_5, drg_admittyp, poa,
            network_paid_status_id, provider_status_id, avoidable_admit_flag, pqi, etg_id
  """

  def directoryLevel: String = "L3"
  val originalSqlFileName: String = "L3_II_ocu_build.sql"
}

package com.optum.oadw.etl.L2

import java.sql.Timestamp

import com.optum.oadw.definedfunctions.ListAgg
import com.optum.oadw.oadwModels._
import com.optum.oadw.utils.DataframeExtensions._
import com.optum.oap.sparkdataloader.{ RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader }
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{ IntegerType, LongType }
import org.apache.spark.sql.{ DataFrame, Dataset, SparkSession }

object L2_PAT_MED extends TableInfo[l2_pat_med] {

  def directoryLevel = "L2"

  override def name = "L2_PAT_MED"

  override def partitions: Int = 64

  override def dependsOn: Set[String] =
    Set(
      "L1_REF_HTS_NDC_CURRENT",
      "L2_MAP_CDS_FLG",
      "L1_REF_HTS_DCC_CURRENT",
      "MD_OADW_INSTANCE",
      "L1_CLINICAL_EVENT_ENCOUNTER",
      "L2_DICT_DCC",
      "L1_RX_PATIENT_REPORTED",
      "L1_MAP_MED_ROUTE",
      "L1_RXADMIN",
      "L1_RXORDER"
    )

  override def createDataFrame(
    sparkSession: SparkSession,
    loadedDependencies: Map[String, DataFrame],
    udfMap: Map[String, UserDefinedFunctionForDataLoader],
    runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l1RefHtsNdcCurrent  = loadedDependencies("L1_REF_HTS_NDC_CURRENT").castToBigDecimal(Set("strnum", "volnum")).as[l1_ref_hts_ndc_current].alias("l1RefHtsNdcCurrent")
    val l1RefHtsDccCurrent  = loadedDependencies("L1_REF_HTS_DCC_CURRENT").as[l1_ref_hts_dcc_current].alias("l1RefHtsDccCurrent")
    val tL2MapCdsFlg        = loadedDependencies("L2_MAP_CDS_FLG").as[l2_map_cds_flg].alias("tL2MapCdsFlg")
    val tL2DictDcc          = loadedDependencies("L2_DICT_DCC").as[l2_dict_dcc].alias("tL2DictDcc")
    val tl1ClinEventEnc     = loadedDependencies("L1_CLINICAL_EVENT_ENCOUNTER").as[l1_clinical_event_encounter].alias("tl1ClinEventEnc")
    val l1RxPatientReported = loadedDependencies("L1_RX_PATIENT_REPORTED").as[l1_rx_patient_reported].alias("l1RxPatientReported")
    val l1RxAdmin           = loadedDependencies("L1_RXADMIN").as[l1_rxadmin].alias("l1RxAdmin")
    val l1RxOrder = loadedDependencies("L1_RXORDER")
      .castToBigDecimal(Set("charge", "paidamount", "allowedamount", "coinsurance_amt", "copay_amt", "deductable_amt", "pat_liability_amt"))
      .as[l1_rxorder]
      .alias("l1RxOrder")
    val l1MapMedRoute   = loadedDependencies("L1_MAP_MED_ROUTE").as[l1_map_med_route].alias("l1MapMedRoute")
    val tMdOadwInstance = loadedDependencies("MD_OADW_INSTANCE").as[md_oadw_instance].alias("tMdOadwInstance")

    val l2PatMed = createL2PatMed(
      sparkSession,
      l1RxOrder,
      l1RxAdmin,
      l1RxPatientReported,
      tL2MapCdsFlg,
      tL2DictDcc,
      l1RefHtsNdcCurrent,
      l1RefHtsDccCurrent,
      l1MapMedRoute,
      tl1ClinEventEnc,
      tMdOadwInstance
    )
    l2PatMed

  }

  private def createL2PatMed(
    sparkSession: SparkSession,
    l1RxOrder: Dataset[l1_rxorder],
    l1RxAdmin: Dataset[l1_rxadmin],
    l1RxPatientReported: Dataset[l1_rx_patient_reported],
    tL2MapCdsFlg: Dataset[l2_map_cds_flg],
    tL2DictDcc: Dataset[l2_dict_dcc],
    l1RefHtsNdcCurrent: Dataset[l1_ref_hts_ndc_current],
    l1RefHtsDccCurrent: Dataset[l1_ref_hts_dcc_current],
    l1MapMedRoute: Dataset[l1_map_med_route],
    tl1ClinEventEnc: Dataset[l1_clinical_event_encounter],
    tMdOadwInstance: Dataset[md_oadw_instance]) = {

    import sparkSession.implicits._

    val listAgg = new ListAgg()

    val dataThruDt = tMdOadwInstance
      .where($"attribute_name" === lit("DATA_THRU"))
      .select(to_date($"attribute_value", "yyyyMMdd").as("data_thru_dt"))
      .as[Timestamp]
      .collect()
      .head

    val tMedUnion =
      l1RxOrder
        .select(
          $"client_id",
          $"mpi",
          $"issue_dtm".as("rx_dtm"),
          $"dcc",
          $"client_ds_id",
          $"localroute",
          $"ndc11".as("ndc"),
          $"mstrprovid",
          $"encounterid",
          lit(0).as("pat_reported_ind"),
          lit(0).as("rxadmin_ind"),
          lit(1).as("rxorder_ind"),
          when($"active_med_flag" === lit("Y"), 1).otherwise(lit(0)).as("active_ind"),
          when($"venue" === lit("1"), lit(0)).otherwise(lit(1)).as("hosp_ind")
        )
        .union(l1RxAdmin
          .select(
            $"client_id",
            $"mpi",
            coalesce($"administration_dtm", $"dispensed_dtm").as("rx_dtm"),
            $"dcc",
            $"client_ds_id",
            $"localroute",
            $"ndc11".as("ndc"),
            $"mstrprovid",
            $"encounterid",
            lit(0).as("pat_reported_ind"),
            lit(1).as("rxadmin_ind"),
            lit(0).as("rxorder_ind"),
            lit(null).as("active_ind"),
            lit(1).as("hosp_ind")
          ))
        .union(l1RxPatientReported
          .select(
            $"client_id",
            $"mpi",
            $"medreported_dt".as("rx_dtm"),
            $"dcc",
            $"client_ds_id",
            lit(null).as("localroute"),
            $"ndc11".as("ndc"),
            $"mstrprovid",
            $"encounterid",
            lit(1).as("pat_reported_ind"),
            lit(0).as("rxadmin_ind"),
            lit(0).as("rxorder_ind"),
            when($"active_med_flag" === lit("Y"), 1).otherwise(lit(0)).as("active_ind"),
            lit(0).as("hosp_ind")
          ))
        .alias("tMedUnion")

    val tPatMed = tMedUnion
      .join(
        tL2MapCdsFlg,
        $"tL2MapCdsFlg.client_id" === $"tMedUnion.client_id" &&
        $"tL2MapCdsFlg.client_ds_id" === $"tMedUnion.client_ds_id",
        "inner")
      .join(tL2DictDcc, $"tL2DictDcc.dcc" === $"tMedUnion.dcc")
      .join(
        broadcast(l1MapMedRoute),
        $"l1MapMedRoute.client_id" === $"tMedUnion.client_id" &&
        $"l1MapMedRoute.local_code" === $"tMedUnion.localroute",
        "left_outer")
      .join(
        tl1ClinEventEnc,
        $"tMedUnion.encounterid" === $"tl1ClinEventEnc.encounterid" &&
        $"tMedUnion.client_id" === $"tl1ClinEventEnc.client_id" &&
        $"tMedUnion.mpi" === $"tl1ClinEventEnc.mpi" &&
        $"tMedUnion.client_ds_id" === $"tl1ClinEventEnc.client_ds_id",
        "left_outer"
      )
      .join(broadcast(l1RefHtsNdcCurrent), $"l1RefHtsNdcCurrent.ndc" === $"tMedUnion.ndc", "left_outer")
      .join(broadcast(l1RefHtsDccCurrent), $"l1RefHtsDccCurrent.dcc" === $"tMedUnion.dcc", "left_outer")
      .where($"tMedUnion.mpi".isNotNull && to_date($"tMedUnion.rx_dtm","yyyyMMdd") <= dataThruDt)
      .withColumn(
        "prov_id_rank",
        first($"tMedUnion.mstrprovid", true)
          .over(Window
            .orderBy(
              when($"tMedUnion.mstrprovid".isNotNull, lit(0)).otherwise(lit(1)),
              $"tMedUnion.rxorder_ind".desc_nulls_last,
              $"tMedUnion.rxadmin_ind".desc_nulls_last,
              $"tMedUnion.pat_reported_ind".desc_nulls_last,
              $"tMedUnion.mstrprovid".asc_nulls_last
            )
            .partitionBy($"tMedUnion.client_id", $"tMedUnion.mpi", $"tMedUnion.rx_dtm", $"tMedUnion.dcc"))
      )
      .withColumn(
        "route_cui_rank",
        first(coalesce($"l1MapMedRoute.cui", $"l1RefHtsDccCurrent.preferred_route_cui", lit("CH999999")))
          .over(Window
            .orderBy(
              when($"l1MapMedRoute.cui".isNotNull, lit(0)).otherwise(lit(1)),
              when($"l1RefHtsDccCurrent.preferred_route_cui" === $"l1MapMedRoute.cui", lit(0)).otherwise(lit(1)).asc,
              $"tMedUnion.rxorder_ind".desc_nulls_last,
              $"tMedUnion.rxadmin_ind".desc_nulls_last,
              $"tMedUnion.pat_reported_ind".desc_nulls_last,
              coalesce($"l1MapMedRoute.cui", $"l1RefHtsDccCurrent.preferred_route_cui", lit("CH999999")).asc_nulls_last
            )
            .partitionBy($"tMedUnion.client_id", $"tMedUnion.mpi", $"tMedUnion.rx_dtm", $"tMedUnion.dcc"))
      )
      .select(
        $"tMedUnion.client_id",
        $"tMedUnion.mpi",
        $"tMedUnion.rx_dtm",
        $"tMedUnion.dcc",
        $"tMedUnion.ndc",
        $"tL2MapCdsFlg.data_grp_flg",
        $"tL2MapCdsFlg.client_ds_id",
        $"l1MapMedRoute.cui".as("mmr_cui"),
        $"l1RefHtsDccCurrent.preferred_route_cui".as("preferred_route_cui"),
        $"tl1ClinEventEnc.encounter_grp_num".as("encounter_grp_num"),
        $"tMedUnion.pat_reported_ind".cast(IntegerType).as("pat_reported_ind"),
        $"tMedUnion.rxadmin_ind".cast(IntegerType).as("rxadmin_ind"),
        $"tMedUnion.rxorder_ind".cast(IntegerType).as("rxorder_ind"),
        $"tMedUnion.active_ind".cast(IntegerType).as("active_ind"),
        $"tL2DictDcc.sensitive_ind".cast(IntegerType).as("sensitive_ind"),
        $"l1RefHtsndcCurrent.gbo_ind".as("gbo_ind"),
        $"tMedUnion.hosp_ind".cast(IntegerType).as("hosp_ind"),
        $"prov_id_rank",
        $"route_cui_rank"
      )
      .groupBy($"client_id", $"mpi", $"rx_dtm", $"dcc")
      .agg(
        listAgg($"client_ds_id").as("cds_grp"),
        min($"prov_id_rank").as("prov_id"),
        min($"route_cui_rank").as("route_cui"),
        min(coalesce($"ndc", lit("CH999999"))).as("ndc"),
        min($"encounter_grp_num").as("clinical_event_id"),
        max($"pat_reported_ind").as("pat_reported_ind"),
        max($"rxadmin_ind").as("rxadmin_ind"),
        max($"rxorder_ind").as("rxorder_ind"),
        coalesce(max($"active_ind"), lit(1)).as("active_ind"),
        max($"sensitive_ind").as("sensitive_ind"),
        max($"hosp_ind").as("hosp_ind"),
        coalesce(max(when($"gbo_ind" === lit(9), lit(null)).otherwise($"gbo_ind")), lit(9)).cast(IntegerType).as("gbo_id")
      )
      .withColumn("inferred_ind", lit(0))
      .withColumn("fill_ind", lit(0))
      .withColumn("tos_i_5", concat(lit("33"), $"dcc").cast(LongType))

    tPatMed

  }

}

package com.optum.oadw.etl.L2

import com.optum.oadw.oadwModels.{l2_ii_mem_attr_member_ext, l2_ii_mem_attr_member, l2_ii_mem_attr_ext}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{when, _}
import org.apache.spark.sql.types.{IntegerType, LongType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L2_II_MEM_ATTR_MEMBER_EXT extends TableInfo[l2_ii_mem_attr_member_ext] {
  override def name: String = "L2_II_MEM_ATTR_MEMBER_EXT"

  override def dependsOn: Set[String] = Set("L2_II_MEM_ATTR_MEMBER", "L2_II_MEM_ATTR_EXT")

  def directoryLevel: String = "L2"


  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2iiMemAttrMember = loadedDependencies("L2_II_MEM_ATTR_MEMBER").as[l2_ii_mem_attr_member]
    val l2iiMemAttrExt = loadedDependencies("L2_II_MEM_ATTR_EXT").as[l2_ii_mem_attr_ext]

    l2iiMemAttrMember.as("mem")
      .join(l2iiMemAttrExt.as("dict"),
        $"dict.age_cat2" === $"mem.age_cat2" &&
          $"dict.sex" === $"mem.sex" &&
          $"dict.zip" === $"mem.zip" &&
          $"dict.account_id" === $"mem.account_id" &&
          $"dict.product_id" === $"mem.product_id" &&
          $"dict.contract_id" === $"mem.contract_id" &&
          $"dict.at_risk_status_id" === $"mem.at_risk_status_id" &&
          $"dict.mem_userdef_1_id" === $"mem.mem_userdef_1_id" &&
          $"dict.mem_userdef_2_id" === $"mem.mem_userdef_2_id" &&
          $"dict.mem_userdef_3_id" === $"mem.mem_userdef_3_id" &&
          $"dict.mem_userdef_4_id" === $"mem.mem_userdef_4_id" &&
          $"dict.cat_status" === $"mem.cat_status" &&
          $"dict.cat_status_cost3" === $"mem.cat_status_cost3" &&
          coalesce($"dict.pcp_assign", lit("")) === coalesce($"mem.pcp_assign", lit(""))
        , "inner")
      .select(
        $"mem.member"
        , $"mem.year_mth_id"
        , $"mem.member_attr_id".cast(LongType).as("member_attr_id")
        , $"mem.mpg_def_id".cast(LongType).as("mpg_def_id")
        , $"mem.pcp_assign"
        , when($"mem.rx" === true, lit(1)).when($"mem.rx" === false, lit(0)).as("rx")
        , when($"mem.med" === true, lit(1)).when($"mem.med" === false, lit(0)).as("med")
        , when($"mem.sex" === true, lit(1)).when($"mem.sex" === false, lit(0)).as("sex")
        , $"mem.zip"
        , $"mem.county_id".cast(LongType).as("county_id")
        , $"mem.age".cast(LongType).as("age")
        , $"mem.mem_eff_dt"
        , $"mem.mem_end_dt"
        , $"mem.subscriber_id"
        , $"mem.ia_time"
        , $"mem.account_id"
        , $"mem.age_cat2"
        , $"mem.biz_segment_id"
        , $"mem.benefit_plan_id"
        , $"mem.contract_id"
        , $"mem.cat_status_cost3"
        , $"mem.cat_status"
        , $"mem.contract_type_id"
        , $"mem.coverage_status_id"
        , $"mem.coverage_class"
        , $"mem.industry"
        , $"mem.product_id"
        , $"mem.mem_userdef_1_id"
        , $"mem.at_risk_status_id"
        , $"mem.mem_userdef_2_id"
        , $"mem.mem_userdef_3_id"
        , $"mem.mem_userdef_4_id"
        , $"mem.pcp_imp"
        , $"mem.sub_eff_dt"
        , $"mem.sub_end_dt"
        , when($"mem.last_enroll" === true, lit(1)).when($"mem.last_enroll" === false, lit(0)).as("last_enroll")
        , when($"mem.med_qual" === true, lit(1)).when($"mem.med_qual" === false, lit(0)).as("med_qual")
        , when($"mem.phm_qual" === true, lit(1)).when($"mem.phm_qual" === false, lit(0)).as("phm_qual")
        , when($"mem.iatime_lag" === true, lit(1)).when($"mem.iatime_lag" === false, lit(0)).as("iatime_lag")
        , $"mem.mm"
        , $"mem.mm_rx"
        , $"mem.subscr_months"
        , $"mem.premium_tot"
        , $"mem.prisk"
        , $"mem.rrisk"
        , $"dict.new_mem_attr_id"
      )
  }
}

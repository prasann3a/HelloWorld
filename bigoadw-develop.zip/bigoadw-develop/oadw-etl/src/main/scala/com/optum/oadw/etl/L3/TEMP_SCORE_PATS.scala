
/**
  * auto-generated code
*/
package com.optum.oadw.etl.L3


import java.sql.Timestamp

import com.optum.oadw.etlContract.OutputColumn
import com.optum.oap.sparkdataloader.QueryAndMetadata

case class temp_score_pats_data(client_id: String, mpi: String, dob: Timestamp, gender_cui: String, race_cui: String)

object TEMP_SCORE_PATS extends QueryAndMetadata[temp_score_pats_data] {
  override def name: String = "TEMP_SCORE_PATS"

  override def sparkSql: String = """SELECT  info.client_id
,info.mpi
,info.DOB
,info.GENDER_CUI
,info.RACE_CUI
FROM L2_PATIENT_INFO info
INNER JOIN L2_PAT_ACTIVITY_SUMMARY asum on (info.client_id = asum.client_id and info.mpi = asum.mpi)
WHERE asum.class_3_ind = 1"""

  override def dependsOn: Set[String] = Set("L2_PATIENT_INFO","L2_PAT_ACTIVITY_SUMMARY")

  def originalSql: String = """

-- Class_3 AAP patients
CREATE TABLE temp_score_pats PCTFREE 0 NOLOGGING
AS
SELECT /*+parallel(4)*/ info.client_id
       ,info.mpi
       ,info.DOB
       ,info.GENDER_CUI
       ,info.RACE_CUI
FROM L2_PATIENT_INFO info
INNER JOIN L2_PAT_ACTIVITY_SUMMARY asum on (info.client_id = asum.client_id and info.mpi = asum.mpi)
WHERE asum.class_3_ind = 1 """

  def outputColumns: Option[Seq[OutputColumn]] = None

  def directoryLevel: String = "L3"





  val originalSqlFileName: String = "L3_pat_score_grp_precur_build.sql"
}


package com.optum.oadw.definedfunctions

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner
import org.scalatest.Matchers._

@RunWith(classOf[JUnitRunner])
class CalendarFunctionTest extends FlatSpec with TestSparkSession {

  implicit val spark = sparkSession

  behavior of "calendarUDF"

  it should "create calendar table correctly" in {

    //Arrange
    CalendarFunction.registerMe(spark)

    val calOutPut = spark.sql(
      """
        |select explode(calendarUDF(to_date('1801-01-01', 'yyyy-MM-dd'), to_date('2040-01-01', 'yyyy-MM-dd')))
      """.stripMargin)

    calOutPut.createOrReplaceTempView("calendarUDFOutput")

    //Act
    val calendar = spark.sql("select col.Serial_Num, col.CAL_DT, col.DT_DAYOFMONTH, col.DT_DAY_NAME, col.DT_DAYOFWEEK, col.DT_DAYOFYEAR, col.DT_WEEKOFYEAR, col.DT_QUARTER, " +
      "col.DT_MONTH_MM, col.DT_MONTH_NAME_ABBREV, col.DT_MONTH_NAME, col.DT_YEAR, col.DT_yr_month from calendarUDFOutput")
    //Final Calendar table
    calOutPut.createOrReplaceTempView("calendar")

    //Assert
    calendar.first().getInt(0) shouldBe 1
    calendar.first().getString(1) shouldBe "1801-01-01"
    calendar.first().getString(3) shouldBe "Thursday"
    calendar.first().getString(4) shouldBe "Thu"
    calendar.first().getInt(5) shouldBe 1
    calendar.first().getString(8) shouldBe "01"
    calendar.first().getString(9) shouldBe "Jan"
    calendar.first().getString(10) shouldBe "January"
    calendar.first().getInt(11) shouldBe 1801
    calendar.first().getString(12) shouldBe "180101"
  }
}
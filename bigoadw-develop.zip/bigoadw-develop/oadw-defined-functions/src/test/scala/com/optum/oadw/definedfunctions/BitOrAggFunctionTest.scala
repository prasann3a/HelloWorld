package com.optum.oadw.definedfunctions

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner

import org.scalatest.Matchers._

@RunWith(classOf[JUnitRunner])
class BitOrAggFunctionTest extends FlatSpec with TestSparkSession {

  implicit val spark = sparkSession
  import spark.implicits._

  behavior of "BitOrAgg"

  it should "aggregate" in {
    val inputs = mkDataFrame(
      BitOrAggInputModel("a", 1),
      BitOrAggInputModel("a", 2),
      BitOrAggInputModel("b", 4)
    )

    val bitoragg = new BitOrAgg()

    val outputs = inputs
      .groupBy($"cat")
      .agg(bitoragg($"v").as("v"))
      .as[BitOrAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      BitOrAggOutputModel("a", 3),
      BitOrAggOutputModel("b", 4))
  }

  it should "aggregate with spark sql" in {
    val inputs = mkDataFrame(
      BitOrAggInputModel("a", 1),
      BitOrAggInputModel("a", 3),
      BitOrAggInputModel("b", 4)
    )

    val bitoragg = new BitOrAgg()

    spark.udf.register("bitoragg", bitoragg)
    inputs.createOrReplaceTempView("inputs")

    val outputs = spark.sql(
      """
        |select cat, bitoragg(v) as v
        |from inputs
        |group by cat
      """.stripMargin)
      .as[BitOrAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      BitOrAggOutputModel("a", 3),
      BitOrAggOutputModel("b", 4)
    )
  }

  it should "aggregate with a null value" in {
    val inputs = mkDataFrame(
      BitOrAggInputModel2("a", Some(60)),
      BitOrAggInputModel2("a", Some(13)),
      BitOrAggInputModel2("b", Some(4)),
      BitOrAggInputModel2("b", None),
      BitOrAggInputModel2("c",None)
    )

    val bitoragg = new BitOrAgg()

    val outputs = inputs
      .groupBy($"cat")
      .agg(bitoragg($"v").as("v"))
      .as[BitOrAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      BitOrAggOutputModel("a", 61),
      BitOrAggOutputModel("b", 4),
      BitOrAggOutputModel("c",0))
  }
}

case class BitOrAggInputModel(cat: String, v: Int)
case class BitOrAggInputModel2(cat: String, v: Option[Int])

case class BitOrAggOutputModel(cat: String, v: Int)

package com.optum.oadw.definedfunctions

import java.sql.Timestamp

import com.optum.oap.testutils.TestSparkSession
import org.apache.spark.sql.functions._
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class AddMonthsColumnFunctionTest extends FlatSpec with TestSparkSession {

  implicit val spark = sparkSession
  import spark.implicits._

  behavior of "AddMonthsColumn"

  it should "addMonths" in {

    val addMonthsColumn = AddMonthsColumnFunction.addMonthsColumn

    val input = Seq(
      AddMonthsInput(Timestamp.valueOf("2018-02-03 00:00:00"), 4),
      AddMonthsInput(Timestamp.valueOf("3000-01-11 00:00:00"), -4),
      AddMonthsInput(Timestamp.valueOf("1978-12-12 00:00:00"), 3),
      AddMonthsInput(Timestamp.valueOf("2016-02-29 00:00:00"), 12)
    )

    val df = input.toDS().withColumn("date", addMonthsColumn($"date", $"months"))

    val results = df.as[AddMonthsInput].collect()

    results should contain theSameElementsAs Seq(
      AddMonthsInput(Timestamp.valueOf("2018-06-03 00:00:00"), 4),
      AddMonthsInput(Timestamp.valueOf("2999-09-11 00:00:00"), -4),
      AddMonthsInput(Timestamp.valueOf("1979-03-12 00:00:00"), 3),
      AddMonthsInput(Timestamp.valueOf("2017-02-28 00:00:00"), 12)
    )
  }

  it should "addMonthsWithLit" in {
    val addMonthsColumn = AddMonthsColumnFunction.addMonthsColumn

    val input = Seq(
      AddMonthsInput(Timestamp.valueOf("2018-02-03 00:00:00"), 4),
      AddMonthsInput(Timestamp.valueOf("3000-01-11 00:00:00"), -4),
      AddMonthsInput(Timestamp.valueOf("1978-12-12 00:00:00"), 3),
      AddMonthsInput(Timestamp.valueOf("2016-02-29 00:00:00"), 12)
    )

    val df = input.toDS().withColumn("date", addMonthsColumn($"date", lit(1) - $"months"))

    val results = df.as[AddMonthsInput].collect()

    results should contain theSameElementsAs Seq(
      AddMonthsInput(Timestamp.valueOf("2017-11-03 00:00:00"), 4),
      AddMonthsInput(Timestamp.valueOf("3000-06-11 00:00:00"), -4),
      AddMonthsInput(Timestamp.valueOf("1978-10-12 00:00:00"), 3),
      AddMonthsInput(Timestamp.valueOf("2015-03-29 00:00:00"), 12)
    )
  }
}

case class AddMonthsInput(date: Timestamp, months: Long)
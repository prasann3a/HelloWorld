package com.optum.oadw.definedfunctions

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner
import org.scalatest.FlatSpec
import org.scalatest.Matchers._

@RunWith(classOf[JUnitRunner])
class ListAndFunctionTest extends FlatSpec with TestSparkSession {

  implicit val spark = sparkSession
  import spark.implicits._

  val output = Seq(
    ListAndModel("1.2.3", "2.3.4", 1),
    ListAndModel("1.2.3", "6.5.4", 0),
    ListAndModel("7.8.9", "", 0),
    ListAndModel("", "7.8.9", 0),
    ListAndModel("", "", 0),
    ListAndModel(null,null,0),
    ListAndModel(null,"7.8.9",0),
    ListAndModel(null,"",0)
  )

  val input = Seq(
    ListAndModel("1.2.3", "2.3.4"),
    ListAndModel("1.2.3", "6.5.4"),
    ListAndModel("7.8.9", ""),
    ListAndModel("", "7.8.9"),
    ListAndModel("", ""),
    ListAndModel(null,null),
    ListAndModel(null,"7.8.9"),
    ListAndModel(null,"")
  )

  behavior.of("listAnd")

  it should "and2strings" in {



    val listAndColumn = ListAndFunction.listAnd

    val df = input.toDS().withColumn("result", listAndColumn($"input1", $"input2"))

    val results = df.as[ListAndModel].collect()

    (results should contain).theSameElementsAs(output)
  }

  it should "work with sparksql" in {

    val inputsDF = mkDataFrame(input:_*)

    ListAndFunction.registerMe(spark)
    inputsDF.createOrReplaceTempView("inputs")

    val results = spark.sql(s"select input1,input2, ${ListAndFunction.name}(input1,input2) result from inputs").as[ListAndModel]
    (results.collect() should contain).theSameElementsAs(output)

  }

}

case class ListAndModel(input1: String, input2: String, result: Int = 1)

package com.optum.oadw.definedfunctions

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner
import org.scalatest.FlatSpec
import org.scalatest.Matchers._

@RunWith(classOf[JUnitRunner])
class ListOrFunctionTest extends FlatSpec with TestSparkSession {

  implicit val spark = sparkSession
  import spark.implicits._

  val input = Seq(
    StringOrInput("1.2.3", "2.3.4"),
    StringOrInput("1.2.3", "6.5.4"),
    StringOrInput("7.8.9", ""),
    StringOrInput("", "7.8.9"),
    StringOrInput("", ""),
    StringOrInput(null,null),
    StringOrInput(null,"7.8.9"),
    StringOrInput(null,""),
    StringOrInput("7.8.9",null)
  )

  val output = Seq(
    StringOrInput("1.2.3", "2.3.4", "1.2.3.4"),
    StringOrInput("1.2.3", "6.5.4", "1.2.3.4.5.6"),
    StringOrInput("7.8.9", "", "7.8.9"),
    StringOrInput("", "7.8.9", "7.8.9"),
    StringOrInput("","",""),
    StringOrInput(null, null, ""),
    StringOrInput(null,"7.8.9","7.8.9"),
    StringOrInput(null,"",""),
    StringOrInput("7.8.9",null,"7.8.9")
  )

  behavior.of("stringOR")

  it should "union2strings" in {

    val stringOrColumn = ListOrFunction.listOr

    val df = input.toDS().withColumn("result", stringOrColumn($"input1", $"input2"))

    val results = df.as[StringOrInput].collect()

    (results should contain).theSameElementsAs(output)
  }

  it should "work with sparksql" in {

    val inputsDF = mkDataFrame(input:_*)

    ListOrFunction.registerMe(spark)
    inputsDF.createOrReplaceTempView("inputs")

    val results = spark.sql(s"select input1,input2, ${ListOrFunction.name}(input1,input2) result from inputs").as[StringOrInput]
    (results.collect() should contain).theSameElementsAs(output)

  }

}

case class StringOrInput(input1: String, input2: String, result: String = null)

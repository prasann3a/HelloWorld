package com.optum.oadw.definedfunctions

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class BitAndAggFunctionTest extends FlatSpec with TestSparkSession {

  implicit val spark = sparkSession
  import spark.implicits._

  behavior of "BitAndAgg"

  it should "aggregate" in {
    val inputs = mkDataFrame(
      BitAndAggInputModel("a", 1),
      BitAndAggInputModel("a", 3),
      BitAndAggInputModel("b", 4)
    )

    val bitandagg = new BitAndAgg()

    val outputs = inputs
      .groupBy($"cat")
      .agg(bitandagg($"v").as("v"))
      .as[BitAndAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      BitAndAggOutputModel("a", 1),
      BitAndAggOutputModel("b", 4)
    )

  }

  it should "aggregate with spark sql" in {
    val inputs = mkDataFrame(
      BitAndAggInputModel("a", 1),
      BitAndAggInputModel("a", 3),
      BitAndAggInputModel("b", 4)
    )

    val bitandagg = new BitAndAgg()

    spark.udf.register("bitandagg", bitandagg)
    inputs.createOrReplaceTempView("inputs")

    val outputs = spark.sql(
      """
        |select cat, bitandagg(v) as v
        |from inputs
        |group by cat
      """.stripMargin)
      .as[BitAndAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      BitAndAggOutputModel("a", 1),
      BitAndAggOutputModel("b", 4)
    )
  }

  it should "aggregate with a null value" in {
    val inputs = mkDataFrame(
      BitAndAggInputModel2("a", Some(15)),
      BitAndAggInputModel2("a", None),
      BitAndAggInputModel2("a", Some(31)),
      BitAndAggInputModel2("b", Some(4)),
      BitAndAggInputModel2("b", None)
    )

    val bitandagg = new BitAndAgg()

    val outputs = inputs
      .groupBy($"cat")
      .agg(bitandagg($"v").as("v"))
      .as[BitAndAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      BitAndAggOutputModel("a", 15),
      BitAndAggOutputModel("b", 4))
  }

  it should "aggregate with a null value in spark sql" in {
    val inputs = mkDataFrame(
      BitAndAggInputModel2("a", Some(15)),
      BitAndAggInputModel2("a", None),
      BitAndAggInputModel2("a", Some(31)),
      BitAndAggInputModel2("b", Some(4)),
      BitAndAggInputModel2("b", None)
    )

    val bitandagg = new BitAndAgg()

    spark.udf.register("bitandagg", bitandagg)
    inputs.createOrReplaceTempView("inputs")

    val outputs = spark.sql(
      """
        |select cat, bitandagg(v) as v
        |from inputs
        |group by cat
      """.stripMargin)
      .as[BitAndAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      BitAndAggOutputModel("a", 15),
      BitAndAggOutputModel("b", 4))
  }

}

case class BitAndAggInputModel(cat: String, v: Int)

case class BitAndAggOutputModel(cat: String, v: Int)

case class BitAndAggInputModel2(cat: String, v: Option[Int])

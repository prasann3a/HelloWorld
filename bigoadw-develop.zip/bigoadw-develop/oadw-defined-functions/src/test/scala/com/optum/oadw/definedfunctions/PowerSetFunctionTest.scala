package com.optum.oadw.definedfunctions

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.apache.spark.sql.functions._

@RunWith(classOf[JUnitRunner])
class PowerSetFunctionTest extends FlatSpec with TestSparkSession {

  implicit val spark = sparkSession
  import spark.implicits._

  val input = mkDataFrame(
    CombinationInput(10, 1021, 6),
    CombinationInput(10, 1021, 12),
    CombinationInput(10, 1021, 13),
    CombinationInput(10, 1032, 21),
    CombinationInput(10, 1032, 22)
  )

  val Output = Seq(
    CombinationSetOutput(10, List(6,12,13)),
    CombinationSetOutput(10, List(6,12)),
    CombinationSetOutput(10, List(6,13)),
    CombinationSetOutput(10, List(12,13)),
    CombinationSetOutput(10, List(21, 22)),
    CombinationSetOutput(10, List(21)),
    CombinationSetOutput(10, List(22)),
    CombinationSetOutput(10,List()),
    CombinationSetOutput(10,List(13)),
    CombinationSetOutput(10,List()),
    CombinationSetOutput(10,List(6)),
    CombinationSetOutput(10,List(12))
  )

  behavior.of("PowerSetFunction")

  it should "Genarate power set" in {

    PowerSetFunction.registerMe(spark)
    val results = input.groupBy($"conditionId", $"precursorId")
      .agg(PowerSetFunction.listpset(collect_list($"ruleId")).as("ruleGroupList"))
      .select($"conditionId", explode($"ruleGroupList").as("ruleGrp")).as[CombinationSetOutput]

    (results.collect should contain).theSameElementsAs(Output)
  }

}

case class CombinationInput( conditionId : Int, precursorId: Int, ruleId: Int )
case class CombinationSetOutput(conditionId: Int, ruleGrp: List[Int] )
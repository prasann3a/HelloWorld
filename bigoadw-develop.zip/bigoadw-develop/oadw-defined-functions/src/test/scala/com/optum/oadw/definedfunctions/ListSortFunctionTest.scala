package com.optum.oadw.definedfunctions

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner
import org.scalatest.Matchers._


@RunWith(classOf[JUnitRunner])
class ListSortFunctionTest extends FlatSpec with TestSparkSession {

  implicit val spark = sparkSession
  import spark.implicits._

  val input = mkDataFrame(
    Input(Array(3,2,1))
  )

 val output =  input.select(ListSortFunction.listsort($"array")).collectAsList().get(0).toSeq.head
 val expected = Array(1,2,3)

  it should "match the expected value" in {
    output should equal (expected)
  }
}

case class Input(array: Array[Int])
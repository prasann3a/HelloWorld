package com.optum.oadw.definedfunctions

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner

import org.scalatest.Matchers._

@RunWith(classOf[JUnitRunner])
class ListAggFunctionTest extends FlatSpec with TestSparkSession {

  implicit val spark = sparkSession
  import spark.implicits._

  behavior of "ListAgg"

  it should "aggregate" in {
    val inputs = mkDataFrame(
      ListAggInputModel("a", 1L),
      ListAggInputModel("a", 2L),
      ListAggInputModel("b", 4L)
    )

    val listagg = new ListAgg()

    val outputs = inputs
      .groupBy($"cat")
      .agg(listagg($"v").as("v"))
      .as[ListAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      ListAggOutputModel("a", "1.2"),
      ListAggOutputModel("b", "4"))
  }

  it should "aggregate with spark sql" in {
    val inputs = mkDataFrame(
      ListAggInputModel("a", 1L),
      ListAggInputModel("a", 3L),
      ListAggInputModel("a", 0L),
      ListAggInputModel("b", 4L),
      ListAggInputModel("c", 0L)
    )

    val listagg = new ListAgg()

    spark.udf.register("listagg", listagg)
    inputs.createOrReplaceTempView("inputs")

    val outputs = spark.sql(
      """
        |select cat, listagg(v) as v
        |from inputs
        |group by cat
      """.stripMargin)
      .as[ListAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      ListAggOutputModel("a", "1.3"),
      ListAggOutputModel("b", "4"),
      ListAggOutputModel("c", "0")
    )
  }

  it should "aggregate with a list value" in {
    val inputs = mkDataFrame(
      ListAggInputModel2("a", Some("60.61")),
      ListAggInputModel2("a", None),
      ListAggInputModel2("a", Some("61.62")),
      ListAggInputModel2("b", Some("4")),
      ListAggInputModel2("b", Some("0")),
      ListAggInputModel2("b", Some("5.6")),
      ListAggInputModel2("c", Some("")),
      ListAggInputModel2("c", Some("0")),
      ListAggInputModel2("c", Some("0"))
    )

    val listagg = new ListAgg()

    val outputs = inputs
      .groupBy($"cat")
      .agg(listagg($"v").as("v"))
      .as[ListAggOutputModel]

    outputs.collect() should contain theSameElementsAs Seq(
      ListAggOutputModel("a", "60.61.62"),
      ListAggOutputModel("b", "4.5.6"),
      ListAggOutputModel("c", "0"))
  }
}

case class ListAggInputModel(cat: String, v: Long)
case class ListAggInputModel2(cat: String, v: Option[String])

case class ListAggOutputModel(cat: String, v: String)

package com.optum.oadw.definedfunctions

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types.{DataType, IntegerType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}

object BitAndAggFunction extends UserDefinedFunctionForDataLoader {

  val bitAndAgg = new BitAndAgg

  override def name: String = "bitandagg"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, bitAndAgg)
  }
}

class BitAndAgg extends UserDefinedAggregateFunction {
  override def inputSchema: StructType = StructType(Seq(StructField("value", IntegerType)))

  override def bufferSchema: StructType = StructType(Seq(StructField("holder", IntegerType)))

  override def dataType: DataType = IntegerType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = Int.MaxValue
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    buffer(0) = getFromBuffer(buffer) & getFromBuffer(input)
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    buffer1(0) = getFromBuffer(buffer1) & getFromBuffer(buffer2)
  }

  override def evaluate(buffer: Row): Any = buffer.getAs[Int](0)

  private def getFromBuffer(buffer: Row): Int = {

    if (buffer.isNullAt(0)) {
      Int.MaxValue
    } else {
      buffer.getInt(0)
    }
  }
}

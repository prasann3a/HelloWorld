package com.optum.oadw.definedfunctions
import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

/**
  *
  * Copyright 2020 Optum Analytics
  *
  * Date: 1/9/20
  *
  * Creator: kgubbala
  */
object ListAndFunction extends UserDefinedFunctionForDataLoader {
  override def name: String = "listand"

  val listAnd = udf { (input1: String, input2: String) =>
    {
      val getData  = (x: String) => Option(x).getOrElse("").split("\\.").filter(_.nonEmpty)
      val commonValues = getData(input1).intersect(getData(input2)).sorted.mkString(".")
      if (commonValues.isEmpty) 0 else 1
    }
  }

  override def registerMe(sparkSession: SparkSession): Unit =
    sparkSession.udf.register(name, listAnd);

}

package com.optum.oadw.definedfunctions

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import scala.collection.mutable

object PowerSetFunction extends UserDefinedFunctionForDataLoader {

  override def name: String = "listpset"

  private def powerSet[A](s: Set[A]) = s.foldLeft(Set(Set.empty[A])) { case (ss, el) => ss ++ ss.map(_ + el)}

  def listpset = udf {
    (list: mutable.WrappedArray[Int]) => { powerSet(list.toSet).map(_.toList.sorted).toList }
  }

  override def registerMe(sparkSession: SparkSession): Unit =
    sparkSession.udf.register(name, listpset)

}

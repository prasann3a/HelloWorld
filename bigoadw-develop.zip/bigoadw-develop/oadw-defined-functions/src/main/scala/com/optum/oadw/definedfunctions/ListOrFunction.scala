package com.optum.oadw.definedfunctions

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

/**
  *
  * Copyright 2020 Optum Analytics
  *
  * Date: 1/9/20
  *
  * Creator: kgubbala
  */
object ListOrFunction extends UserDefinedFunctionForDataLoader {
  override def name: String = "listor"


  val listOr = udf { (input1: String, input2: String) => {
    val getData = (x: String) => Option(x).getOrElse("").split("\\.").filter(_.nonEmpty)
    Array.concat(getData(input1), getData(input2)).distinct.sorted.mkString(".")

    }
  }

  override def registerMe(sparkSession: SparkSession): Unit =
    sparkSession.udf.register(name, listOr)

}

package com.optum.oadw.definedfunctions

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

object OADefinedFunctionsRegistry {

  private val logger = LoggerFactory.getLogger(this.getClass)

  val ADD_MONTHS_COLUMN: AddMonthsColumnFunction.type = AddMonthsColumnFunction

  val BIT_AND_AGG: BitAndAggFunction.type = BitAndAggFunction

  val BIT_OR_AGG: BitOrAggFunction.type = BitOrAggFunction

  val CALENDAR: CalendarFunction.type = CalendarFunction

  val ADD_YEAR_MONTH: AddYearMonthColumnFunction.type  = AddYearMonthColumnFunction

  val LIST_AGG: ListAggFunction.type = ListAggFunction

  val LIST_OR: ListOrFunction.type = ListOrFunction

  val LIST_AND: ListAndFunction.type = ListAndFunction

  val LIST_PSET: PowerSetFunction.type = PowerSetFunction

  val SORT_LIST: ListSortFunction.type = ListSortFunction

  val ALL_UDFS: Set[UserDefinedFunctionForDataLoader] = Set(ADD_MONTHS_COLUMN, BIT_OR_AGG, BIT_AND_AGG, CALENDAR, ADD_YEAR_MONTH, LIST_AGG, LIST_OR, LIST_AND, LIST_PSET, SORT_LIST)

  def getUdfsMap(sparkSession: SparkSession): Map[String, UserDefinedFunctionForDataLoader] = {
    OADefinedFunctionsRegistry.ALL_UDFS.map(oa => {
      logger.info(s"Registering UDF: ${oa.name}")
      oa.registerMe(sparkSession)
      oa.name -> oa
    }).toMap
  }
}

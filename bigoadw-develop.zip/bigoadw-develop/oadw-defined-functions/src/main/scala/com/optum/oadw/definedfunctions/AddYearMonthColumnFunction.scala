package com.optum.oadw.definedfunctions

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._

object AddYearMonthColumnFunction extends UserDefinedFunctionForDataLoader {

  private val formatter = DateTimeFormatter.ofPattern("yyyyMM")

  val addYearMonth: UserDefinedFunction = udf {
    (date: String, increment: Int) => {
      val year = date.substring(0, 4).toInt
      val month = date.substring(4).toInt

      val localDate = LocalDate.of(year, month, 1)

      val finalDate = localDate.plusMonths(increment)
      finalDate.format(formatter)
    }
  }

  override def name: String = "add_year_month"

  override def registerMe(sparkSession: SparkSession): Unit = {
    // No need to register. Use it directly in Spark Dataframe api
  }
}

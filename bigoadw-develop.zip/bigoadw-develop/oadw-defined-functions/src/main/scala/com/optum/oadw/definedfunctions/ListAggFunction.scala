package com.optum.oadw.definedfunctions

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.{Column, Row, SparkSession}
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types.{DataType, StringType, IntegerType, StructField, StructType}
import org.apache.spark.sql.functions._

object ListAggFunction extends UserDefinedFunctionForDataLoader {

  val listAgg = new ListAgg

  override def name: String = "listagg"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, listAgg)
  }
}

class ListAgg extends UserDefinedAggregateFunction {
  override def inputSchema: StructType = StructType(Seq(StructField("value", StringType)))

  override def bufferSchema: StructType = StructType(Seq(StructField("holder", StringType)))

  override def dataType: DataType = StringType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {
    buffer(0) = ""
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
    val b = buffer.getAs[String](0)
    val i = input.getAs[String](0)
    buffer(0) = { if(b.isEmpty) b + i else b + "." + i }
  }

  override def merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit = {
    val b1 = buffer1.getAs[String](0)
    val b2 = buffer2.getAs[String](0)
    if(!b1.isEmpty)
      buffer1(0) = (b1) ++ "." ++ (b2)
    else
      buffer1(0) = b2
  }

  override def evaluate(buffer: Row): Any = {
    // Compute your logic and return another String
    val tempList = buffer.getAs[String](0).split("\\.").distinct.filterNot(x => Set("","0","null").contains(x)).sorted
    if (tempList.isEmpty) "0" else tempList.mkString(".")
  }

}
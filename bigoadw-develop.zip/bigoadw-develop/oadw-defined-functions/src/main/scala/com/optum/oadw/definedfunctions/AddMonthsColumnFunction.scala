package com.optum.oadw.definedfunctions

import java.sql.Timestamp

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._

object AddMonthsColumnFunction extends UserDefinedFunctionForDataLoader {
  val addMonthsColumn: UserDefinedFunction = udf {
    (date: Timestamp, monthsToAdd: Long) => {
      Timestamp.valueOf(date.toLocalDateTime.plusMonths(monthsToAdd))
    }
  }

  override def name: String = "add_months_column"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, addMonthsColumn)
  }
}

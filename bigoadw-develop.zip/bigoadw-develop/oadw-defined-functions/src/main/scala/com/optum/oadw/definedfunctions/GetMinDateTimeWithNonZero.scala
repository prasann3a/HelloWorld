package com.optum.oadw.definedfunctions

import java.sql.Timestamp

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}
import org.apache.spark.sql.types.{DataType, StructType, TimestampType}

object GetMinDateTimeWithNonZero extends UserDefinedFunctionForDataLoader {

  val getMinDateTimeWithNonZero = new GetMinDateTimeWithNonZero

  override def name: String = "getMinDateTimeWithNonZero"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, getMinDateTimeWithNonZero)
  }
}

class GetMinDateTimeWithNonZero extends UserDefinedAggregateFunction {
  override def inputSchema: StructType = {
    new StructType().add("proc_dtm", TimestampType, nullable = true)
  }

  override def bufferSchema: StructType = {
    new StructType().add("min-proc_dtm", TimestampType, nullable = true)
  }

  override def dataType: DataType = TimestampType

  override def deterministic: Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): Unit = {

    buffer(0) = null
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): Unit = {
   if(buffer(0) == null) buffer(0) = input.getTimestamp(0)
   else
    buffer(0) = calculateMinProc_dtmWithNonZero(buffer.getTimestamp(0), input.getTimestamp(0))
  }

  override def merge(buffer: MutableAggregationBuffer, row: Row): Unit = {
    if(buffer(0) == null) buffer(0) = row.getTimestamp(0)
    else
    buffer(0) = calculateMinProc_dtmWithNonZero(buffer.getTimestamp(0), row.getTimestamp(0))
  }

  override def evaluate(buffer: Row): Any = {

    buffer.getTimestamp(0)
  }

  private def calculateMinProc_dtmWithNonZero(dt1:Timestamp, dt2:Timestamp):Timestamp = {
    val t1 = dt1.toString.split(" ")
    val t2 = dt2.toString.split(" ")

    if(t1(1).equals(t2(1)) && t1(1).equals("00:00:00.0")) {
      if(dt1.compareTo(dt2) == -1) dt1
      else dt2
    }
    else if(t1(1).equals("00:00:00.0")) dt2
    else if(t2(1).equals("00:00:00.0")) dt1
    else {
      if(dt1.compareTo(dt2) == -1) dt1
      else dt2
    }
  }

}

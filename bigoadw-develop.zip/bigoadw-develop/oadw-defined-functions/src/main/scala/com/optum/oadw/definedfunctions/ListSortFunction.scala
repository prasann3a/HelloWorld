package com.optum.oadw.definedfunctions

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf


import scala.collection.mutable

object ListSortFunction extends UserDefinedFunctionForDataLoader {

  override def name: String = "listsort"


  val listsort = udf { (list: mutable.WrappedArray[Int]) => {
    list.sorted
  }
  }

  override def registerMe(sparkSession: SparkSession): Unit =
    sparkSession.udf.register(name, listsort)

}

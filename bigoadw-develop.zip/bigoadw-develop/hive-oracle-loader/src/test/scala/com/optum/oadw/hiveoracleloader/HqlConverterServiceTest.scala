package com.optum.oadw.hiveoracleloader

import java.io.File
import java.util.regex.Matcher

import better.files.{File => ScalaFile, Resource => ScalaResource}
import com.optum.oap.testutils.TemporaryFolderForAll
import com.optum.oadw.hiveoracleloader.lib.common.HqlToOracleSqlConfig
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.{FlatSpec, MustMatchers}

/*
1) No comments in the output file
2) Skip OADW tables
3) Skip OADW_REF tables
4) Append partition info
5) Skip L1 tables
6) Add required L1 tables and views
7) Skip view if tables are skipped
8) Data type conversion
9) Custom data type override
10) Create table list
*/


@RunWith(classOf[JUnitRunner])
class HqlConverterServiceTest extends FlatSpec  with MustMatchers with TemporaryFolderForAll {
  behavior of "schemaParser"

  tempFolder.create()
  val inputFilePath = tempFolder.newFolder("inputs").getAbsolutePath
  val inputOadwFiles = "inputs/oadw_schema.hql,inputs/oadw_reference_schema.hql"
  val outputOadwFile = "oadw_schema_test.sql"
  val errorFile = "error.txt"
  val tableListFileName = "oadw_tables.txt"
  val synonymSchemaFileName = "create_synonyms.sql"
  val expectedOutputFilesOpaBuild = ExpectedOutputFiles(expectedOutputFile = "expectedOutputs/oadw_combined_opa_build_expected.sql",
    expectedTableListFile = "expectedOutputs/table_list_file_opa_build_expected.txt",
    expectedSynonymSchemaFile = "expectedOutputs/create_synonyms_opa_build_expected.sql")

  val expectedOutputFilesDefaultBuild = ExpectedOutputFiles(expectedOutputFile = "expectedOutputs/oadw_combined_default_build_expected.sql",
    expectedTableListFile = "expectedOutputs/table_list_file_default_build_expected.txt",
    expectedSynonymSchemaFile = "expectedOutputs/create_synonyms_default_build_expected.sql")

  testConvertHqlToOracleSql("OPA", inputOadwFiles, expectedOutputFilesOpaBuild)
  testConvertHqlToOracleSql("DEFAULT", inputOadwFiles, expectedOutputFilesDefaultBuild)


  private def testConvertHqlToOracleSql(oadwBuildType: String, inputOadwFiles: String, expectedOutputFiles: ExpectedOutputFiles): Unit = {

    val outputFilePath = tempFolder.newFolder(oadwBuildType).getAbsolutePath

    val inputFileList = inputOadwFiles.replaceAll("inputs/", Matcher.quoteReplacement(s"$outputFilePath${File.separator}"))
    copyResourcesToTempFolder(inputOadwFiles, outputFilePath)
    val hqlToOracleSqlConfig =  HqlToOracleSqlConfig(inputHqlFiles = inputFileList,
      outputFilePath = outputFilePath,
      outputSqlFileName = outputOadwFile,
      tableListFile = tableListFileName,
      errorFileName = errorFile,
      appendToOutput = false,
      createTableListOnly = false,
      tableFilterFile = "",
      createSynonymSchema = true,
      synonymSchemaFile = synonymSchemaFileName,
      oadwBuildType = oadwBuildType
    )

    HqlConverterService.appendManualSchemaFile(outputFilePath, outputOadwFile)


    HqlConverterService.convertHqlToOracleSql(hqlToOracleSqlConfig)

    it should s"generate expected schema from $inputOadwFiles for $oadwBuildType" in {

      val generatedOutput = ScalaFile(s"${outputFilePath}/${outputOadwFile}").lines.map(_.trim).mkString("\n").trim.replaceAll("\t", " ")
      val expectedOutput = ScalaResource.getAsString(expectedOutputFiles.expectedOutputFile).lines.map(_.trim).mkString("\n").trim.replaceAll("\t", " ")
      generatedOutput mustBe expectedOutput
    }

    it should s"generate export table list files for $oadwBuildType" in {
      val generatedOutput = ScalaFile(s"${outputFilePath}/${tableListFileName}").lines.map(_.trim).mkString("\n").trim.replaceAll("\t", " ")
      val expectedOutput = ScalaResource.getAsString(expectedOutputFiles.expectedTableListFile).lines.map(_.trim).mkString("\n").trim.replaceAll("\t", " ")
      generatedOutput.toSet.diff(expectedOutput.toSet) mustBe Set()
    }

    it should s"generate create synonym schema from $inputOadwFiles for $oadwBuildType" in {
      val generatedOutput = ScalaFile(s"${outputFilePath}/${synonymSchemaFileName}").lines.map(_.trim).mkString("\n").trim.replaceAll("\t", " ")
      val expectedOutput = ScalaResource.getAsString(expectedOutputFiles.expectedSynonymSchemaFile).lines.map(_.trim).mkString("\n").trim.replaceAll("\t", " ")
      generatedOutput mustBe expectedOutput
    }
  }

  private def copyResourcesToTempFolder(inputOadwFiles: String, outputPath: String): Unit = {
    inputOadwFiles.split(",").map(inputFile => {
      val fileName = new File(inputFile).getName
      val targetFile = s"${outputPath}/${fileName}"
      val content = ScalaResource.getAsString(inputFile)
      ScalaFile(targetFile).write(content)
    })
  }

}

case class ExpectedOutputFiles(expectedOutputFile: String, expectedTableListFile: String, expectedSynonymSchemaFile: String)

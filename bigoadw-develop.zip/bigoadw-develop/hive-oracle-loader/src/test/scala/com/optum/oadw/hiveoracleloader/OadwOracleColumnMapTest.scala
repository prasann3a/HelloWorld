package com.optum.oadw.hiveoracleloader

import com.optum.oadw.utils.ResourceHelper
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.FlatSpec

@RunWith(classOf[JUnitRunner])
class OadwOracleColumnMapTest extends FlatSpec {
  // VARCHAR2 (N) is not allowed anymore
  private val invalidDatatypePatterns = List{"VARCHAR\\d*\\s*\\(\\d+\\)".r}
  private val sampleBadColMap = "inputs/sample_bad_column_map.txt"

  private def testInvalidDatatypes(resourceName: String) : Unit = {
    val fileLines = ResourceHelper.readLinesFromStream(resourceName)
    for(fl <- fileLines) {
      val lineSplit = fl.split('|')
      if(lineSplit.length >= 3) {
        for (ivd <- invalidDatatypePatterns) {
          val ivdOption = ivd.findFirstIn(lineSplit(2).toUpperCase.trim)
          if (ivdOption.isDefined) {
            val tablename = lineSplit(0)
            val colName = lineSplit(1)
            throw new java.lang.IllegalStateException(s"Found invalid datatype ${ivdOption.get} for column $colName in $tablename")
          }
        }
      }
    }
  }

  it should "throw IllegalStateException for bad input" in {
    assertThrows[java.lang.IllegalStateException] {
      testInvalidDatatypes(sampleBadColMap)
    }
  }

  it should "test oadw_oracle_column_map.txt for bad datatypes" in {
    testInvalidDatatypes("oadw_oracle_column_map.txt")
  }

}

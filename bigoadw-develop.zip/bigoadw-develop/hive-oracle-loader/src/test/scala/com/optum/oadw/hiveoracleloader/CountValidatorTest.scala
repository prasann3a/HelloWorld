package com.optum.oadw.hiveoracleloader

import java.util.Properties

import com.optum.oadw.hiveoracleloader.lib.common.Constants.DEFAULT_BUILD
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner
import org.scalatest.Matchers._

@RunWith(classOf[JUnitRunner])
class CountValidatorTest extends FlatSpec {

  behavior of "CountValidator"

  it should "find matching lists valid" in {
    
    val hiveData = Seq(
      CommonStats(table_name = "md_table1", column_name = "hive_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15)
    )
    
    val oracleData = Seq(
      CommonStats(table_name = "md_table1", column_name = "hive_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15)
    )

    val hiveStats = StatsMap(hiveData)
    val oracleStats = StatsMap(oracleData)
    
    val differences = CountValidator.gatherDifferences(hiveStats, oracleStats, new Properties(), new Properties(), DEFAULT_BUILD)

    differences.isEmpty shouldBe true
  }

  it should "convert hive names to oracle names via properties map" in {
    val hiveData = Seq(
      CommonStats(table_name = "l4_table2", column_name = "hive_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "l4_table2", column_name = "hive_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "l4_table2", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "l4_table2", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_cola", null_count = 20, non_null_count = 10, total_count = 30),
      CommonStats(table_name = "md_table1", column_name = "hive_colb", null_count = 7, non_null_count = 23, total_count = 30),
      CommonStats(table_name = "md_table1", column_name = "hive_colc", null_count = 11, non_null_count = 19, total_count = 30),
      CommonStats(table_name = "md_table1", column_name = "hive_cold", null_count = 16, non_null_count = 14, total_count = 30)
    )

    val oracleData = Seq(
      CommonStats(table_name = "md_table1", column_name = "oracle_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "oracle_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "oracle_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "oracle_col4", null_count = 1, non_null_count = 14, total_count = 15),
      CommonStats(table_name = "l4_table2", column_name = "oracle_cola", null_count = 20, non_null_count = 10, total_count = 30),
      CommonStats(table_name = "l4_table2", column_name = "oracle_colb", null_count = 7, non_null_count = 23, total_count = 30),
      CommonStats(table_name = "l4_table2", column_name = "oracle_colc", null_count = 11, non_null_count = 19, total_count = 30),
      CommonStats(table_name = "l4_table2", column_name = "oracle_cold", null_count = 16, non_null_count = 14, total_count = 30)
    )

    val hiveStats = StatsMap(hiveData)
    val oracleStats = StatsMap(oracleData)

    val properties = new Properties()
    properties.setProperty("md_table1", "l4_table2")
    properties.setProperty("l4_table2", "md_table1")

    val colProperties = new Properties()
    colProperties.setProperty("hive_col1", "oracle_col1")
    colProperties.setProperty("hive_col2", "oracle_col2")
    colProperties.setProperty("hive_col3", "oracle_col3")
    colProperties.setProperty("hive_col4", "oracle_col4")
    colProperties.setProperty("hive_cola", "oracle_cola")
    colProperties.setProperty("hive_colb", "oracle_colb")
    colProperties.setProperty("hive_colc", "oracle_colc")
    colProperties.setProperty("hive_cold", "oracle_cold")

    val differences = CountValidator.gatherDifferences(hiveStats, oracleStats, properties, colProperties, DEFAULT_BUILD)

    differences should contain theSameElementsAs Seq.empty
  }

  it should "find total count differences" in {
    val hiveData = Seq(
      CommonStats(table_name = "l4_table2", column_name = "hive_col1", null_count = 15, non_null_count = 10, total_count = 25),
      CommonStats(table_name = "l4_table2", column_name = "hive_col2", null_count = 17, non_null_count = 8, total_count = 25),
      CommonStats(table_name = "l4_table2", column_name = "hive_col3", null_count = 21, non_null_count = 4, total_count = 25),
      CommonStats(table_name = "l4_table2", column_name = "hive_col4", null_count = 11, non_null_count = 14, total_count = 25),
      CommonStats(table_name = "md_table1", column_name = "hive_cola", null_count = 20, non_null_count = 10, total_count = 30),
      CommonStats(table_name = "md_table1", column_name = "hive_colb", null_count = 7, non_null_count = 23, total_count = 30),
      CommonStats(table_name = "md_table1", column_name = "hive_colc", null_count = 11, non_null_count = 19, total_count = 30),
      CommonStats(table_name = "md_table1", column_name = "hive_cold", null_count = 16, non_null_count = 14, total_count = 30)
    )

    val oracleData = Seq(
      CommonStats(table_name = "md_table1", column_name = "hive_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15),
      CommonStats(table_name = "l4_table2", column_name = "hive_cola", null_count = 21, non_null_count = 10, total_count = 31),
      CommonStats(table_name = "l4_table2", column_name = "hive_colb", null_count = 8, non_null_count = 23, total_count = 31),
      CommonStats(table_name = "l4_table2", column_name = "hive_colc", null_count = 12, non_null_count = 19, total_count = 31),
      CommonStats(table_name = "l4_table2", column_name = "hive_cold", null_count = 17, non_null_count = 14, total_count = 31)
    )

    val hiveStats = StatsMap(hiveData)
    val oracleStats = StatsMap(oracleData)

    val properties = new Properties()

    properties.setProperty("md_table1", "l4_table2")
    properties.setProperty("l4_table2", "md_table1")

    val differences = CountValidator.gatherDifferences(hiveStats, oracleStats, properties, new Properties(), DEFAULT_BUILD)

    differences should contain theSameElementsAs Seq(
      "Hive table l4_table2 count of 25 did not match Oracle table md_table1 count of 15",
      "Hive table md_table1 count of 30 did not match Oracle table l4_table2 count of 31"
    )
  }

  it should "find missing oracle tables" in {
    val hiveData = Seq(
      CommonStats(table_name = "md_table1", column_name = "hive_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15),
      CommonStats(table_name = "l4_table2", column_name = "hive_cola", null_count = 1, non_null_count = 14, total_count = 15),
      CommonStats(table_name = "invalid_table1", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15)
    )

    val oracleData = Seq(
      CommonStats(table_name = "md_table1", column_name = "hive_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15)
    )

    val hiveStats = StatsMap(hiveData)
    val oracleStats = StatsMap(oracleData)

    val differences = CountValidator.gatherDifferences(hiveStats, oracleStats, new Properties(), new Properties(), DEFAULT_BUILD)

    differences should contain theSameElementsAs Seq(
      "Could not locate Oracle table l4_table2"
    )
  }

  it should "find missing Hive and Oracle columns" in {
    val hiveData = Seq(
      CommonStats(table_name = "md_table1", column_name = "hive_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "invalid_table1", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15)
    )

    val oracleData = Seq(
      CommonStats(table_name = "md_table1", column_name = "hive_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15)
    )

    val hiveStats = StatsMap(hiveData)
    val oracleStats = StatsMap(oracleData)

    val differences = CountValidator.gatherDifferences(hiveStats, oracleStats, new Properties(), new Properties(), DEFAULT_BUILD)

    differences should contain theSameElementsAs Seq(
      "Could not locate Hive column md_table1.hive_col4",
      "Could not locate Oracle column md_table1.hive_col2"
    )
  }


  it should "find column count differences" in {
    val hiveData = Seq(
      CommonStats(table_name = "md_table1", column_name = "hive_col1", null_count = 9, non_null_count = 6, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col3", null_count = 1, non_null_count = 14, total_count = 15),
      CommonStats(table_name = "md_table1", column_name = "hive_col4", null_count = 2, non_null_count = 13, total_count = 15),
      CommonStats(table_name = "table2", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15)
    )

    val oracleData = Seq(
      CommonStats(table_name = "l4_table2", column_name = "hive_col1", null_count = 5, non_null_count = 10, total_count = 15),
      CommonStats(table_name = "l4_table2", column_name = "hive_col2", null_count = 7, non_null_count = 8, total_count = 15),
      CommonStats(table_name = "l4_table2", column_name = "hive_col3", null_count = 11, non_null_count = 4, total_count = 15),
      CommonStats(table_name = "l4_table2", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15),
      CommonStats(table_name = "table2", column_name = "hive_col4", null_count = 1, non_null_count = 14, total_count = 15)
    )

    val hiveStats = StatsMap(hiveData)
    val oracleStats = StatsMap(oracleData)

    val properties = new Properties()

    properties.setProperty("md_table1", "l4_table2")

    val differences = CountValidator.gatherDifferences(hiveStats, oracleStats, properties, new Properties(), DEFAULT_BUILD)

    differences should contain theSameElementsAs Seq(
      "Null/Non-null counts do not match for Hive column md_table1.hive_col1 (9/6) and Oracle column l4_table2.hive_col1 (5/10)",
      "Null/Non-null counts do not match for Hive column md_table1.hive_col3 (1/14) and Oracle column l4_table2.hive_col3 (11/4)",
      "Null/Non-null counts do not match for Hive column md_table1.hive_col4 (2/13) and Oracle column l4_table2.hive_col4 (1/14)"
    )
  }
}

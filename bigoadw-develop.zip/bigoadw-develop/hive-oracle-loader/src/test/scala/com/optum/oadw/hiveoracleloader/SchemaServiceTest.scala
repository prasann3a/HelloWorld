package com.optum.oadw.hiveoracleloader

import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner
import org.scalatest.Matchers._

import scala.collection.mutable.ListBuffer

@RunWith(classOf[JUnitRunner])
class SchemaServiceTest extends FlatSpec {

  import SchemaService._

  behavior of "generateDestinationSchemaName()"

  testCaseGenerateDestinationSchemaName(
    "",
    "client",
    "environment",
    "schema",
    3,
    "OADW_ENVIRONMENT_CLIENT_SCHEMA_3"
  )
  testCaseGenerateDestinationSchemaName(
    "",
    "H123456",
    "dev",
    "CDR_201811",
    420,
    "OADW_DEV_H123456_CDR_201811_420"
  )

  private def testCaseGenerateDestinationSchemaName(schemaOverride: String = "",
                                                    clientId: String = "",
                                                    environment: String = "",
                                                    schema: String = "",
                                                    sequence: Int = 1,
                                                    expected: String): Unit = {
    it should s"generate expected schema name from $schemaOverride, $clientId, $environment, $schema, $sequence" in {
      val metaDataInfo = MetadataInfo(schema, "", true)
      val actual = generateDestinationSchemaName(clientId, environment, metaDataInfo, sequence)

      actual shouldBe expected
    }
  }

  behavior of "getOracleInstance()"
  testCaseGetOracleInstance("_test", "__test")
  testCaseGetOracleInstance("test", "_test")

  private def testCaseGetOracleInstance(service: String = "", expected: String): Unit = {
    it should s"generate expected oracle service from $service" in {
      getOracleInstance(service) shouldBe expected
    }
  }

  behavior of "deriveSequenceNumber()"
  testCaseDeriveSequenceNumber(ListBuffer(), 1234, 1234)
  testCaseDeriveSequenceNumber(ListBuffer("test_whack_thirty_ass"), 1234, 1234)
  testCaseDeriveSequenceNumber(ListBuffer("test_1", "test_2", "test_3"), 1234, 4)
  testCaseDeriveSequenceNumber(ListBuffer("test_1", "test_2", "test_103"), 1234, 104)
  testCaseDeriveSequenceNumber(ListBuffer("test_432", "test_2", "test_103"), 1234, 433)

  private def testCaseDeriveSequenceNumber(schemas: ListBuffer[String], defaultSequence: Int, expected: Int): Unit = {
    it should s"generate expected sequence number given default sequence $defaultSequence schemas ${schemas.mkString(", ")}" in {
      deriveSequenceNumber(schemas, defaultSequence) shouldBe expected
    }
  }

  behavior of "getCurrentSchemaNameFrom(schemaName: String)"
  testCaseGetCurrentSchemaNameFrom("EOADW_STG_H303173_20190313_3", "EOADW_STG_H303173_CURRENT")
  testCaseGetCurrentSchemaNameFrom("OADW_PRD_H743123_CDR_201901_2", "OADW_PRD_H743123_CURRENT")
  testCaseGetCurrentSchemaNameFrom("oadw_prd_h743123_cdr_201901_2", "OADW_PRD_H743123_CURRENT")

  private def testCaseGetCurrentSchemaNameFrom(schemaName: String, expected: String): Unit = {
    it should s"create correct current schema name for $schemaName" in {
      getCurrentSchemaNameFrom(schemaName) shouldBe expected
    }
  }
}
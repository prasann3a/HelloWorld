BEGIN
  update_current_schema('{{SCHEMA_NAME}}');
END;
/

BEGIN
  grant_synonyms_select('{{LINK_READER_SCHEMA_NAME}}');
END;
/
BEGIN
grant_synonyms_to_opa_rep('{{CLIENT_ID}}', '{{ENV}}');
END;

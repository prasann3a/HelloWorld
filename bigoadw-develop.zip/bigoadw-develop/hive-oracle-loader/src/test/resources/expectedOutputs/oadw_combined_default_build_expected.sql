CREATE OR REPLACE FUNCTION safe_to_number (p_txt IN VARCHAR2
,p_format IN VARCHAR2 := NULL)
RETURN NUMBER
DETERMINISTIC
IS
v_number  number;
BEGIN
IF p_format IS NOT NULL THEN
v_number := to_number(p_txt, p_format);
ELSE
v_number := to_number(p_txt);
if to_char(v_number)='~' then
v_number := NULL;
END IF;
END IF;
RETURN v_number;
EXCEPTION WHEN value_error THEN
RETURN NULL;
END safe_to_number;
/


CREATE OR REPLACE PROCEDURE add_list_partition(p_table IN VARCHAR2,p_part_name IN VARCHAR2,p_values IN VARCHAR2)
AS
part_exists EXCEPTION;
PRAGMA EXCEPTION_INIT(part_exists, -14013);
value_exists EXCEPTION;
PRAGMA EXCEPTION_INIT(value_exists, -14312);
v_values VARCHAR2(60) := p_values;
BEGIN
if (safe_to_number(p_values) is null) then
v_values := '''' || p_values || '''';
end if;
EXECUTE IMMEDIATE 'ALTER TABLE ' || p_table || ' ADD PARTITION ' || p_part_name || ' VALUES(' || v_values || ')';
--TODO: Decide how we want to handle errors.  We should verify that if the partition exists, it has the same values.
EXCEPTION
WHEN part_exists THEN
--Check that the value is
null;
WHEN value_exists THEN
null;
END add_list_partition;
/

CREATE OR REPLACE PROCEDURE add_list_partitions(p_table IN VARCHAR2,p_part_src_tbl IN VARCHAR2, p_part_name_col IN VARCHAR2, p_part_val_col IN VARCHAR2 DEFAULT NULL
,p_part_prefix IN VARCHAR2 default 'P_'
,p_filter IN VARCHAR2 default '1=1')
AS
v_sql VARCHAR2(400);
v_part VARCHAR2(32);
v_val VARCHAR2(32); --probably needs to be large for when we support multiple values.
TYPE result_cur IS REF CURSOR;
v_cursor result_cur;
v_part_val_col VARCHAR2(100) := NVL(p_part_val_col,p_part_name_col);
BEGIN
v_sql := 'SELECT DISTINCT ' || p_part_name_col || ' AS part_nm, ' || v_part_val_col || ' AS part_val FROM ' || p_part_src_tbl || ' t ' || ' WHERE ' || p_filter || ' GROUP BY ' || p_part_name_col;
OPEN v_cursor FOR v_sql;
LOOP
FETCH v_cursor INTO v_part,v_val;
EXIT WHEN v_cursor%NOTFOUND;
add_list_partition(p_table => p_table,p_part_name => p_part_prefix || v_part,p_values => v_val);
END LOOP;
END add_list_partitions;
/

CREATE OR REPLACE FUNCTION is_bitvalue(p_val IN NUMBER) RETURN NUMBER
DETERMINISTIC
AS
BEGIN
IF (p_val <= 0) THEN
RETURN 0;
ELSE
RETURN CASE WHEN BITAND(p_val,p_val-1) = 0 THEN 1 ELSE 0 END;
END IF;
END;
/


-- The below functions were added for OADW-1749
CREATE OR REPLACE FUNCTION add_yr_month(p_yr_month IN NUMBER,p_increment IN NUMBER) RETURN NUMBER
DETERMINISTIC
IS
v_return NUMBER;
v_year NUMBER := TO_NUMBER(SUBSTR(p_yr_month,1,4));
v_month NUMBER := TO_NUMBER(SUBSTR(p_yr_month,-2));
BEGIN
v_month := v_month + p_increment;
IF (v_month = 0) THEN
v_year := v_year - 1;
v_month := 12;
ELSIF (v_month < 1) THEN
v_year := v_year + FLOOR(v_month / 12);
v_month := 12 + MOD(v_month,12);
ELSIF (v_month > 12) THEN
v_year := v_year + FLOOR(v_month / 12);
v_month := MOD(v_month , 12);
END IF;
v_return := (v_year * 100) + v_month;
RETURN(v_return);
END add_yr_month;
/
CREATE OR REPLACE FUNCTION age_as_of (birth_date in date, as_of_date in date := sysdate, unit in VARCHAR2 := 'YEAR')
--Return an age based on the birthdate and as_of_date supplied
--Age will be returned as a whole number
--If birthdate is null return null
--valid units include: YEAR or MONTH
RETURN NUMBER
DETERMINISTIC
IS
PRAGMA UDF;
age  INTEGER;
BEGIN
IF birth_date IS NULL THEN
RETURN NULL;
END IF;

-- Calculate the age in months
age := FLOOR (MONTHS_BETWEEN (TRUNC (as_of_date), TRUNC (birth_date)));

-- Calculate age in MONTHs or YEARs
CASE UPPER (unit)
WHEN 'MONTH' THEN
NULL;
WHEN 'YEAR' THEN
age := FLOOR (age / 12);
ELSE
RETURN NULL;
END CASE;

-- Return age
RETURN age;

EXCEPTION
WHEN VALUE_ERROR THEN
RETURN NULL;
END age_as_of;
/

CREATE OR REPLACE TYPE bitand_impl AS OBJECT
(
agg_bitand INTEGER,

STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitand_impl) RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitand_impl,
val  IN INTEGER) RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitand_impl,
ctx2 IN bitand_impl) RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitand_impl,
returnval OUT INTEGER,
flags     IN NUMBER) RETURN NUMBER
)
/

CREATE OR REPLACE TYPE BODY bitand_impl IS
STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitand_impl) RETURN NUMBER IS
BEGIN
ctx := bitand_impl(NULL);
RETURN ODCIConst.Success;
END ODCIAggregateInitialize;

MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitand_impl,
val  IN INTEGER) RETURN NUMBER IS
BEGIN
SELF.agg_bitand :=  bitand(NVL(SELF.agg_bitand,val), val);
RETURN ODCIConst.Success;
END ODCIAggregateIterate;

MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitand_impl,
ctx2 IN bitand_impl) RETURN NUMBER IS
BEGIN
SELF.agg_bitand := bitand(NVL(SELF.agg_bitand,ctx2.agg_bitand), ctx2.agg_bitand);
RETURN ODCIConst.Success;
END ODCIAggregateMerge;

MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitand_impl,
returnval OUT INTEGER,
flags     IN NUMBER) RETURN NUMBER IS
BEGIN
returnval := SELF.agg_bitand;
RETURN ODCIConst.Success;
END ODCIAggregateTerminate;
END;
/

CREATE OR REPLACE FUNCTION bitandagg(x IN INTEGER) RETURN INTEGER
PARALLEL_ENABLE
AGGREGATE USING bitand_impl;
/

CREATE OR REPLACE FUNCTION bitor(p_bitfield1 IN NUMBER,p_bitfield2 IN NUMBER,p_bitfield3 IN NUMBER DEFAULT 0) RETURN NUMBER
DETERMINISTIC
AS
v_f1 NUMBER := NVL(p_bitfield1,0);
v_f2 NUMBER := NVL(p_bitfield2,0);
v_f3 NUMBER := NVL(p_bitfield3,0);
v_tmp NUMBER;
BEGIN
IF (least(v_f1,v_f2,v_f3) < 0) THEN
RETURN 0;
ELSE
v_tmp := v_f1 + v_f2 - bitand(v_f1,v_f2);
v_tmp := v_tmp + v_f3 - bitand(v_tmp,v_f3);
RETURN v_tmp;
END IF;
END;
/

CREATE OR REPLACE TYPE bitor_impl AS OBJECT
(
agg_bitor INTEGER,

STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitor_impl) RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitor_impl,
val  IN INTEGER) RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitor_impl,
ctx2 IN bitor_impl) RETURN NUMBER,

MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitor_impl,
returnval OUT INTEGER,
flags     IN NUMBER) RETURN NUMBER
)
/

CREATE OR REPLACE TYPE BODY bitor_impl IS
STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitor_impl) RETURN NUMBER IS
BEGIN
ctx := bitor_impl(0);
RETURN ODCIConst.Success;
END ODCIAggregateInitialize;

MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitor_impl,
val  IN INTEGER) RETURN NUMBER IS
BEGIN
SELF.agg_bitor := SELF.agg_bitor + val - bitand(SELF.agg_bitor, val);
RETURN ODCIConst.Success;
END ODCIAggregateIterate;

MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitor_impl,
ctx2 IN bitor_impl) RETURN NUMBER IS
BEGIN
SELF.agg_bitor := SELF.agg_bitor + ctx2.agg_bitor - bitand(SELF.agg_bitor, ctx2.agg_bitor);
RETURN ODCIConst.Success;
END ODCIAggregateMerge;

MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitor_impl,
returnval OUT INTEGER,
flags     IN NUMBER) RETURN NUMBER IS
BEGIN
returnval := SELF.agg_bitor;
RETURN ODCIConst.Success;
END ODCIAggregateTerminate;
END;
/

CREATE OR REPLACE FUNCTION bitoragg(x IN INTEGER) RETURN INTEGER
PARALLEL_ENABLE
AGGREGATE USING bitor_impl;
/

CREATE OR REPLACE FUNCTION generate_date_subpartitions(p_years IN NUMBER DEFAULT 5
,p_sub_part_ind IN NUMBER DEFAULT 1
,p_years_future IN NUMBER DEFAULT 0
,p_value_type IN VARCHAR2 DEFAULT 'DATE') RETURN VARCHAR2
IS
v_result VARCHAR2(4000);
v_min_yr NUMBER;
v_max_yr NUMBER;
v_part_prefix VARCHAR2(3) := CASE WHEN p_sub_part_ind = 1 THEN 'SUB' ELSE NULL END;
v_value_expr VARCHAR2(100);
BEGIN
-- start creating following new year sub-partitions 1 month ahead. eg: create 2018 sub-partitions starting 01-dec-2017
SELECT TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')) - p_years INTO v_min_yr FROM DUAL;
SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE,1),'YYYY')) + p_years_future INTO v_max_yr FROM DUAL;

IF (p_value_type = 'NUMBER') THEN
v_value_expr := q'[YEARVAL01]';
ELSIF (p_value_type = 'DATE') THEN
v_value_expr := q'[TO_DATE('YEARVAL0101','YYYYMMDD')]';
ELSE
raise_application_error(-20001, 'Invalid p_value_type argument to generate_date_subpartitions');
END IF;

v_result := replace(v_part_prefix || 'PARTITION P_pre' || v_min_yr || q'[ VALUES LESS THAN (]' || v_value_expr || ')','YEARVAL',v_min_yr);
for yr in v_min_yr..v_max_yr
loop
v_result := v_result || chr(10) || replace(',' || v_part_prefix || 'PARTITION P_' || yr || q'[ VALUES LESS THAN (]' || v_value_expr || ')','YEARVAL',yr + 1);
end loop;

return(v_result);
end generate_date_subpartitions;
/

CREATE OR REPLACE FUNCTION generate_hash_partitions(p_cnt IN NUMBER DEFAULT 4,p_sub_part_ind IN NUMBER DEFAULT 0) RETURN VARCHAR2
IS
v_result VARCHAR2(4000);
v_part_nm VARCHAR2(8);
v_part_prefix VARCHAR2(3) := CASE WHEN p_sub_part_ind = 1 THEN 'SUB' ELSE NULL END;
BEGIN
-- create hash partitions

v_result := v_part_prefix || 'PARTITION P_01';
for pidx in 2..p_cnt
loop
v_result := v_result || chr(10) || ',' || v_part_prefix || 'PARTITION P_' || lpad(pidx,2,'0');
end loop;

return(v_result);
end generate_hash_partitions;
/

create or replace function get_ii_filename (p_client_id in varchar2,p_process_id in number ,p_script_name in varchar2 ) return varchar2
is
l_filename varchar2(100);
begin
if p_process_id = 0 then
-- no valid process_id exists, set to default values
-- these will point to an empty file so a select against the external table will succeed but return zero rows
l_filename    := 'DO_NOT_REMOVE';  -- DO_NOT_REMOVE.txt
else
-- a valid process_id exists, set to group-specific values.
l_filename    := p_process_id||'_'||p_client_id||'_'||p_script_name;  -- eg 34048_H704847_ADM_COSTS_ADMLEVEL
end if;
return(l_filename);
end ;
/

create or replace function get_ii_group_directory (p_client_id in varchar2,p_process_id in number) return varchar2
is
l_group_dir varchar2(30);
begin
if p_process_id = 0 then
-- no valid process_id exists, set to default values
-- these will point to an empty file so a select against the external table will succeed but return zero rows
l_group_dir := 'II_EXTERNAL_COMMON';  -- /misc/phiops/archive/in_ii
else
-- a valid process_id exists, set to group-specific values.
l_group_dir := p_client_id||'_LOAD_DIR_PROD';   -- eg H704847_LOAD_DIR_PROD
end if;
return(l_group_dir);
end ;
/

create or replace function get_ii_process_id (p_client_id in varchar2
,p_process_id in varchar2 := '0'
,p_cdr_schema in varchar2
,p_cdr_view in varchar2 := null
)
return number
is
c_proc_name varchar2(30) := $$PLSQL_UNIT;
l_process_id number(10) :=0;
l_cdr_view varchar2(30) := 'v_bpo_ext_table_process_id';
l_cnt pls_integer;
l_sql varchar2(1000);
p_process_num number(10);
v_where_clause varchar2(100) := '';

begin
l_cdr_view := nvl(p_cdr_view, l_cdr_view);
-- confirm view exists
select count(*)
into   l_cnt
from all_views where owner = upper(p_cdr_schema) and view_name = upper(l_cdr_view);
if l_cnt = 0 then
raise_application_error (-20000, c_proc_name||': Specified view does not exist '''||p_cdr_schema||'.'||l_cdr_view||'''');
l_process_id := 0;
end if;

-- if process_id is specified from command line, validate and use that
if p_process_id not in ('0','*') then
-- validate from view, raise error if not found
-- check if the process id is actually a valid number. if it is then return it else - exception ....
if safe_to_number(p_process_id) is null then
raise_application_error (-20009, c_proc_name||': Specified process_id '||p_process_id||' is invalid');
l_process_id := 0;
end if;
p_process_num := p_process_id;
l_sql := 'select process_id
from   '||p_cdr_schema||'.'||l_cdr_view||'
where  client_id = :clientid
and    process_id = :pid ';
begin
execute immediate l_sql into l_process_id using p_client_id, p_process_num;
exception
when no_data_found then
raise_application_error (-20001, c_proc_name||': Specified process_id '||p_process_id||' does not exist in '||p_cdr_schema||'.'||l_cdr_view||' for '||p_client_id);
end;
else
if p_process_id = '0' then
v_where_clause := ' and out_schema_name = ''' || upper(p_cdr_schema) || '''';
else
v_where_clause := '';
end if;
-- look up from view:
--   Get the most recent sendout per schema for this client_id
--   From these, select the latest send out for this source schema.  If no successful process for this schema, select the latest process_id
l_sql := 'select process_id
from   (select *
from   (select v.*
,row_number() over (partition by out_schema_name order by out_transfer_timestamp desc) as latest_procid_per_schema
from  '||p_cdr_schema||'.'||l_cdr_view||' v
where  client_id = :clientid added_where_clause
)
where latest_procid_per_schema = 1
order by decode(out_schema_name, :cdr_schm, 1, 0) desc, out_transfer_timestamp desc
)
where rownum = 1';
begin
l_sql := replace( l_sql, 'added_where_clause', v_where_clause);
execute immediate l_sql into l_process_id using p_client_id, upper(p_cdr_schema) ;
exception
when no_data_found then
l_process_id := 0;
end;
end if;
return l_process_id;
end ;
/

CREATE OR REPLACE FUNCTION is_bitvalue(p_val IN NUMBER) RETURN NUMBER
DETERMINISTIC
AS
BEGIN
IF (p_val <= 0) THEN
RETURN 0;
ELSE
RETURN CASE WHEN BITAND(p_val,p_val-1) = 0 THEN 1 ELSE 0 END;
END IF;
END;
/
CREATE OR REPLACE FUNCTION safe_to_number (p_txt IN VARCHAR2
,p_format IN VARCHAR2 := NULL)
RETURN NUMBER
DETERMINISTIC
IS
v_number  number;
BEGIN
IF p_format IS NOT NULL THEN
v_number := to_number(p_txt, p_format);
ELSE
v_number := to_number(p_txt);
if to_char(v_number)='~' then
v_number := NULL;
END IF;
END IF;
RETURN v_number;
EXCEPTION WHEN value_error THEN
RETURN NULL;
END safe_to_number;
/
CREATE OR REPLACE PROCEDURE update_current_schema (p_dest_schema IN varchar2)
AUTHID CURRENT_USER
IS
  l_cnt1               number;
  l_cnt2               number;
  l_referenced_owner   varchar2(30);
  l_sql                varchar2(2000);
  cursor c0 is select object_name from user_objects where object_type in ('VIEW');
  cursor c1 (dest_schema  varchar2) is select object_type, object_name from all_objects where owner = UPPER(dest_schema)
    and object_type in ('TABLE','VIEW') order by object_type, object_name;
  cursor c2 (dest_schema  varchar2) is select object_name from user_objects where object_type in ('SYNONYM')
    minus
    select object_name from all_objects where owner = UPPER(dest_schema) and object_type in ('TABLE','VIEW');
  cursor c3 (dest_schema  varchar2) is select object_name from user_objects where object_type in ('VIEW')
    minus
    select object_name from all_objects where owner = UPPER(dest_schema) and object_type in ('TABLE','VIEW');
BEGIN
  FOR X in c0 LOOP
    l_sql :=  'DROP VIEW ' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  FOR X in c1 (p_dest_schema) LOOP
    l_sql :=  'CREATE OR REPLACE SYNONYM ' || X.object_name || ' FOR ' || upper(p_dest_schema) || '.' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  FOR X in c2 (p_dest_schema) LOOP
    l_sql :=  'DROP SYNONYM ' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  FOR X in c3 (p_dest_schema) LOOP
    l_sql :=  'DROP VIEW ' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  select count(*)
  into l_cnt1
  from USER_DEPENDENCIES
  where REFERENCED_OWNER not in ('PUBLIC','SYS')
  and REFERENCED_OWNER not in (select user from dual)
  and type ='SYNONYM';

  select referenced_owner, count(*)
  into l_referenced_owner, l_cnt1
  from USER_DEPENDENCIES
  where REFERENCED_OWNER not in ('PUBLIC','SYS')
  and REFERENCED_OWNER not in (select user from dual)
  and type ='SYNONYM'
  group by referenced_owner;

  IF l_referenced_owner != upper(p_dest_schema) THEN
   RAISE_APPLICATION_ERROR(-20000, 'Validation Error: referenced_owner ' || l_referenced_owner || ' and dest schema ' || upper(p_dest_schema) || ' mismatch!');
  END IF;

  select count(*)
  into l_cnt2
  from ALL_OBJECTS
  where owner = UPPER(p_dest_schema)
  and object_type in ('TABLE','VIEW');

  IF l_cnt1 != l_cnt2 THEN
    RAISE_APPLICATION_ERROR(-20001, 'Validation Error: CURRENT schema synonym count ' || to_char(l_cnt1) || ' and dest schema ' || upper(p_dest_schema) || ' table/view count ' || to_char(l_cnt2) || ' mismatch!');
  END IF;
END;
/
CREATE OR REPLACE PROCEDURE grant_synonyms_select (p_link_schema IN varchar2)
IS
  l_cnt1          number;
  l_sql           varchar2(2000);
  l_schema_upper  varchar2(30);
BEGIN
  l_schema_upper := UPPER(p_link_schema);

  SELECT count(username)
  INTO l_cnt1
  FROM all_users
  WHERE UPPER(username) = l_schema_upper;

  IF l_cnt1 = 1 THEN
    FOR x IN (SELECT SYNONYM_NAME FROM user_synonyms ORDER BY SYNONYM_NAME) LOOP
       l_sql :=  'GRANT SELECT ON ' || x.SYNONYM_NAME || ' TO ' || l_schema_upper ;
       EXECUTE IMMEDIATE l_sql ;
    END LOOP;
  END IF;
END;
/
create or replace PROCEDURE grant_synonyms_to_opa_rep (client_id IN varchar2, env in varchar2)
IS
  rep_schema_pattern varchar2(30);
BEGIN
  rep_schema_pattern := UPPER('REP_%'||client_id||'%'||env||'%');
  FOR x IN (select USERNAME from all_users where username like rep_schema_pattern) LOOP
    grant_synonyms_select(x.USERNAME);
  END LOOP;
END;
/
CREATE OR REPLACE PROCEDURE set_user_columns_nullable
IS
  l_sql           varchar2(2000);
BEGIN
  FOR x IN (SELECT table_name, column_name FROM user_tab_columns where NULLABLE = 'N'
                   and table_name in (select object_name from user_objects where object_type='TABLE')
           )
  LOOP
    l_sql :=  'ALTER TABLE ' || user || '.' || x.table_name || ' MODIFY ' || x.column_name || ' NULL';
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;
END;
/
-- Auto-generated content from oadw_schema.hql
DECLARE
PROCEDURE DROP_IF_EXISTS (objectName IN VARCHAR2, objectType IN VARCHAR2 )
IS
v_counter number:=0;
BEGIN

IF (objectType = 'TABLE') THEN
select count(*) into v_counter from user_tables where table_name = upper(objectName);
if v_counter > 0 then
execute immediate 'DROP ' || objectType || ' ' || objectName || ' CASCADE CONSTRAINTS PURGE';
end if;
END IF;

IF (objectType = 'VIEW') THEN
select count(*) into v_counter from user_views where view_name = upper(objectName);
if v_counter > 0 then
execute immediate 'DROP ' || objectType || ' ' || objectName;
end if;
END IF;

commit;

END;
BEGIN

-- This table is sourced from OADW
DROP_IF_EXISTS('l1_map_tos_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_tos_type (
PATIENT_TYPE_CUI VARCHAR2 (255 CHAR),
POS VARCHAR2 (255 CHAR),
SPEC_CODE VARCHAR2 (255 CHAR),
TOS_MAP_TYPE VARCHAR2 (255 CHAR)
)
PCTFREE 0 NOLOGGING COMPRESS';

-- This table is sourced from OADW
DROP_IF_EXISTS('l1_map_med_route', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_med_route (
CLIENT_ID VARCHAR2(50 CHAR) NOT  NULL,
CUI VARCHAR2(50 CHAR) NOT NULL,
DTS_VERSION NUMBER  NOT NULL,
LOCAL_CODE VARCHAR2(150 CHAR) NOT NULL
)
PCTFREE 0 NOLOGGING COMPRESS';

-- This table is sourced from OADW
DROP_IF_EXISTS('l2_clinical_event_id', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_clinical_event_id (
client_ds_id NUMBER NOT NULL,
client_id VARCHAR2 (16 CHAR) NOT NULL,
clinical_event_id VARCHAR2 (20 CHAR) NOT NULL,
id_type VARCHAR2 (20 CHAR) NOT NULL,
id_value VARCHAR2 (50 CHAR) NOT NULL
) PARTITION BY HASH(clinical_event_id) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
PCTFREE 0 NOLOGGING COMPRESS';

-- This table is sourced from OADW
DROP_IF_EXISTS('l3_dict_prov_attrib_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_prov_attrib_precur (
elig_event_id NUMBER (10, 0),
prov_attrib_precursor_id NUMBER NOT NULL,
prov_attrib_precursor_name VARCHAR2 (250 CHAR) NOT NULL,
setting_id NUMBER (10, 0),
spec_family_id NUMBER (10, 0)
)
PCTFREE 0 NOLOGGING COMPRESS';

-- This table is sourced from OADW
DROP_IF_EXISTS('l4_dict_measure', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_measure (
active_ind NUMBER (1) NOT NULL,
invert_ind NUMBER (1) NOT NULL,
measure_cat2_id NUMBER (3) NOT NULL,
measure_cd VARCHAR2 (20 CHAR) NOT NULL,
measure_desc VARCHAR2 (400 CHAR) NULL,
measure_id NUMBER NOT NULL,
measure_set VARCHAR2 (20 CHAR) NOT NULL,
measure_steward VARCHAR2 (100 CHAR) NULL,
measure_type VARCHAR2 (2 CHAR) NOT NULL,
measure_vers VARCHAR2 (20 CHAR) NOT NULL,
sensitive_cat_id NUMBER (3) NOT NULL,
sensitive_ind NUMBER (1) NOT NULL,
typical_ind NUMBER (1) NOT NULL
)
PCTFREE 0 NOLOGGING COMPRESS';

-- This view is sourced from OADW
DROP_IF_EXISTS('l1_labresult', 'VIEW');
EXECUTE IMMEDIATE 'CREATE OR REPLACE VIEW l1_labresult
AS SELECT GROUPID AS CLIENT_ID, DATASRC, LABRESULTID, LABORDERID, FACILITYID, ENCOUNTERID, PATIENTID, CAST(DATECOLLECTED AS TIMESTAMP) AS COLLECTED_DTM, CAST(DATEAVAILABLE AS TIMESTAMP) AS AVAILABLE_DTM, RESULTSTATUS, LOCALRESULT, LOCALCODE, LOCALNAME, NORMALRANGE, LOCALUNITS, STATUSCODE, MAPPEDCODE, MAPPEDNAME, LOCALRESULT_NUMERIC, LOCALRESULT_INFERRED, CASE WHEN resulttype = ''CH999990'' THEN resulttype ELSE NULL END AS RESULTTYPE, RELATIVEINDICATOR, LOCALUNITS_INFERRED, MAPPEDUNITS, NORMALIZEDVALUE, LOCALSPECIMENTYPE, CLIENT_DS_ID, HGPID, GRP_MPI AS MPI, LOCALTESTNAME, LABORDEREDDATE AS ORDERED_DTM, LOCALLISRESOURCE, MAPPEDLOINC, MAPPED_QUAL_CODE, LOCAL_LOINC_CODE FROM l1_labresult WHERE 1 = 1';

DROP_IF_EXISTS('L2_FACILITY_ROLLUP', 'VIEW');
EXECUTE IMMEDIATE 'CREATE OR REPLACE VIEW
L2_FACILITY_ROLLUP AS WITH fac_rollup AS (SELECT f.client_id, f.facilityid facility_id, f.client_ds_id, COALESCE(fr.siteofcare_id, concat(concat(f.client_ds_id , ''.'') , f.facilityid)  ) AS siteofcare_cd, COALESCE(fr.siteofcare_name, f.facilityname, ''unknown or n/a'') AS siteofcare_name, CASE WHEN fr.siteofcare_id IS NULL THEN f.facilitypostalcd ELSE fr.siteofcare_postalcd END AS siteofcare_postalcd, fr.master_facility_id, fr.master_facility_name, fr.enctr_grp_flag, fr.facilitypostalcd, fr.soc_rollup_flag, MAX(fr.dts_version) OVER (PARTITION BY f.client_id ) AS dts_version, fr.patient_type_cui, CASE WHEN fr.siteofcare_id IS NOT NULL THEN 1 ELSE 0 END AS soc_mapped_ind FROM l2_facility F LEFT JOIN l1_facility_rollup FR ON (f.client_id = fr.groupid AND f.client_ds_id = fr.client_ds_id AND f.facilityid = fr.facility_id)) SELECT client_id, facility_id, client_ds_id, siteofcare_cd, CASE WHEN soc_mapped_ind = 1 OR COUNT(*) OVER (PARTITION BY UPPER(siteofcare_name) ) = 1 THEN siteofcare_name ELSE concat(concat(concat(siteofcare_name , '' ('') , siteofcare_cd) , '')'')   END AS siteofcare_name, siteofcare_postalcd, master_facility_id AS master_facility_cd, master_facility_name, enctr_grp_flag, facilitypostalcd, soc_rollup_flag, dts_version, patient_type_cui, ROWNUM AS hgmasterfacid FROM fac_rollup';
END;
/

-- Auto-generated content from oadw_reference_schema.hql
DECLARE
PROCEDURE DROP_IF_EXISTS (objectName IN VARCHAR2, objectType IN VARCHAR2 )
IS
v_counter number:=0;
BEGIN

IF (objectType = 'TABLE') THEN
select count(*) into v_counter from user_tables where table_name = upper(objectName);
if v_counter > 0 then
execute immediate 'DROP ' || objectType || ' ' || objectName || ' CASCADE CONSTRAINTS PURGE';
end if;
END IF;

IF (objectType = 'VIEW') THEN
select count(*) into v_counter from user_views where view_name = upper(objectName);
if v_counter > 0 then
execute immediate 'DROP ' || objectType || ' ' || objectName;
end if;
END IF;

commit;

END;
BEGIN

-- This table is sourced from OADW_REFERENCE
DROP_IF_EXISTS('l3_dict_prov_attrib_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_prov_attrib_precur (
ACTIVE_IND NUMBER (1) NOT NULL,
ELIG_PROV_ID NUMBER (3) NOT NULL,
ELIG_SOURCE_TYPE_FLG NUMBER NOT NULL,
LOOKBACK_MONTHS NUMBER (3) NOT NULL,
NUM_YR_MONTHS NUMBER (4) NOT NULL,
PROC_GROUP_ID NUMBER NULL,
PROV_ATTRIB_PRECURSOR_DESC VARCHAR2 (400 CHAR) NULL,
PROV_ATTRIB_PRECURSOR_ID NUMBER NOT NULL,
PROV_ATTRIB_PRECURSOR_NAME VARCHAR2 (250 CHAR) NOT NULL,
PROV_ATTRIB_PRECUR_TYPE_ID NUMBER (3) NOT NULL
)
PCTFREE 0 NOLOGGING COMPRESS';

-- This table is sourced from OADW_REFERENCE
DROP_IF_EXISTS('l4_dict_measure', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_measure (
ACTIVE_IND NUMBER (1) NOT NULL,
INVERT_IND NUMBER (1) NOT NULL,
MEASURE_CAT2_ID NUMBER (3) NOT NULL,
MEASURE_CD VARCHAR2 (20 CHAR) NOT NULL,
MEASURE_DESC VARCHAR2 (400 CHAR) NULL,
MEASURE_ID NUMBER NOT NULL,
MEASURE_SET VARCHAR2 (20 CHAR) NOT NULL,
MEASURE_STEWARD VARCHAR2 (100 CHAR) NULL,
MEASURE_TYPE VARCHAR2 (2 CHAR) NOT NULL,
MEASURE_VERS VARCHAR2 (20 CHAR) NOT NULL,
SENSITIVE_CAT_ID NUMBER (3) NOT NULL,
SENSITIVE_IND NUMBER (1) NOT NULL,
TYPICAL_IND NUMBER (1) NOT NULL
)
PCTFREE 0 NOLOGGING COMPRESS';
END;
/
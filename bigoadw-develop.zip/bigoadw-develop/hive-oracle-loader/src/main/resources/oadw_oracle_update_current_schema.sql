BEGIN
  update_current_schema('{{SCHEMA_NAME}}');
END;
/


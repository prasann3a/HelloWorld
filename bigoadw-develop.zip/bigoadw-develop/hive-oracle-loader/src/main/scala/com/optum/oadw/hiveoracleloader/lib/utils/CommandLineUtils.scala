package com.optum.oadw.hiveoracleloader.lib.utils

import com.optum.oap.sparklib.SparkUtils
import com.optum.oadw.hiveoracleloader.lib.utils.OADWMetaDataUtils.META_DATA_CONSTANTS._
import com.optum.oap.utils.Resource.using
import com.optum.oadw.hiveoracleloader.{ClientLevelAuditService, CountValidator, DataLoaderService, HqlConverterService, PostDataLoadService, SchemaService, SqlExecutionService}
import com.optum.oadw.hiveoracleloader.lib.common.{ClientAuditConfig, Constants, CreateOracleSchemaConfig, DropOracleSchemaConfig, ExecutePostDataLoadScriptConfig, HiveToOracleDataLoadConfig, HqlToOracleSqlConfig, SqlExecutionConfig}
import com.optum.oadw.hiveoracleloader.lib.common.Constants.{EOADW, EOADWPREREQ, LoadType, OADW, PREREQ}
import com.optum.oadw.utils.{FeatureManager, Features, MakePassword}
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

class CommandLineUtils(args: Array[String]) {
  private val conf = new CommandLineConf(args)
  private val makePassword = new MakePassword
  private val logger = LoggerFactory.getLogger(this.getClass)

  def processCommandLineArgs(): Unit = {
    conf.subcommand match {
      case Some(conf.hqlToOracleSql) => processHqlToOracleSqlArgs()
      case Some(conf.createOracleSchema) => processCreateOracleSchemaArgs()
      case Some(conf.dropOracleSchema) => processDropOracleSchemaArgs()
      case Some(conf.hiveToOracleDataLoad) => processHiveToOracleDataLoadArgs()
      case Some(conf.executePostDataLoadScript) => processExecutePostDataLoadScriptArgs()
      case Some(conf.executeScript) => processExecuteScriptArgs()
      case Some(conf.deploySynonyms) => processDeploySynonyms()
      case Some(conf.validateCounts) => processValidateCounts()
      case Some(conf.clientLevelAudit) => processClientLevelAudit()
      case invalidArg => throw InvalidCommandException(s"Cannot understand the command line argument - " + invalidArg.toString)
    }
  }

  private def processHqlToOracleSqlArgs(): Unit = {
    val cnf = conf.hqlToOracleSql
    if (!(cnf.outputSqlFileName.supplied || cnf.createTableListOnly.supplied))
      throw new IllegalArgumentException(s"Either --outputSqlFileName or --createTableListOnly is required")

    if (!cnf.createTableListOnly.supplied && !cnf.appendToOutput.getOrElse(false)) {
      HqlConverterService.appendManualSchemaFile(cnf.outputFilePath.getOrElse(Constants.DEFAULT_OUTPUT_PATH),
        cnf.outputSqlFileName.getOrElse(Constants.DEFAULT_OUTPUT_SQL_FILE_NAME))
      if (cnf.createSynonymSchema()) {
        HqlConverterService.appendManualSchemaFile(cnf.outputFilePath.getOrElse(Constants.DEFAULT_OUTPUT_PATH),
          cnf.synonymSchemaFile.getOrElse(Constants.DEFAULT_SYNONYM_FILE_NAME))
      }
    }

    HqlConverterService.convertHqlToOracleSql(HqlToOracleSqlConfig(
      cnf.inputHqlFiles(),
      cnf.outputFilePath.getOrElse(Constants.DEFAULT_OUTPUT_PATH),
      cnf.outputSqlFileName.getOrElse(Constants.DEFAULT_OUTPUT_SQL_FILE_NAME),
      cnf.tableListFile(),
      cnf.errorFileName.getOrElse(Constants.DEFAULT_ERROR_FILE_NAME),
      cnf.appendToOutput.getOrElse(true),
      cnf.createTableListOnly.getOrElse(false),
      cnf.tableFilterFile(),
      cnf.createSynonymSchema(),
      cnf.synonymSchemaFile.getOrElse(Constants.DEFAULT_SYNONYM_FILE_NAME),
      cnf.oadwBuildType()))
  }

  private def processCreateOracleSchemaArgs(): Unit = {
    val cnf = conf.createOracleSchema

    if (!((cnf.schemaName.isDefined) ^ (cnf.hiveDb.isDefined && cnf.environment.isDefined)))
      throw new IllegalArgumentException("Must use --schemaName override, or (--environment --hiveDb) exclusively")

    SchemaService.callCreateOadwUserFunction(CreateOracleSchemaConfig(
      cnf.schemaName.toOption,
      cnf.clientId(),
      cnf.oracleHost(),
      cnf.oracleService(),
      cnf.oracleUser(),
      makePassword.decrypt(cnf.oraclePassword()),
      cnf.environment.toOption,
      cnf.hiveDb.toOption), SparkUtils.createSparkSession("Hive To Oracle Loader", verboseLogging = false, logWarnings = true))
  }

  private def processDropOracleSchemaArgs(): Unit = {
    val cnf = conf.dropOracleSchema
    SchemaService.callDropOadwUserFunction(DropOracleSchemaConfig(
      cnf.schemaName(),
      cnf.oracleHost(),
      cnf.oracleService(),
      cnf.oracleUser(),
      makePassword.decrypt(cnf.oraclePassword())))
  }

  private def processHiveToOracleDataLoadArgs(): Unit = {
    val cnf = conf.hiveToOracleDataLoad

    if(cnf.disabledFeatures.toOption.isDefined && cnf.disabledFeatures.toOption.get != ""){
      FeatureManager.Instance.disable(cnf.disabledFeatures.toOption.get)
    }
    val error = new IllegalArgumentException("Need either --tables, --tablesFile or --loadType")

    if (cnf.loadType.toOption.isDefined && (cnf.tables.toOption.isDefined || cnf.tablesFile.toOption.isDefined)) {
      throw error
    }

    if (cnf.loadType.toOption.isEmpty && (cnf.tables.toOption.isDefined == cnf.tablesFile.toOption.isDefined)) {
      throw error
    }

    val loadType = getLoadTypeOpt(cnf.loadType.toOption)
    val isSchemaNameOverrideMetaData = if (loadType.isDefined) {
      loadType.get.isMetaDataSchemaNameOverride
    } else false

    using(SparkUtils.createSparkSession("Hive To Oracle Loader", verboseLogging = false, logWarnings = true))(implicit session => {
      DataLoaderService.loadHiveDataIntoOracle(HiveToOracleDataLoadConfig(
        cnf.clientId(),
        cnf.environment(),
        cnf.instance(),
        cnf.streamId(),
        cnf.cdrCycle(),
        cnf.cdrLevel(),
        cnf.iiProcessId(),
        cnf.iiDateStamp(),
        cnf.oadwRefVersion(),
        cnf.tables.toOption,
        cnf.tablesFile.toOption,
        cnf.oracleHost(),
        cnf.oracleService(),
        resolveOracleUserName(cnf.metadataDb.toOption, cnf.oracleUser.toOption, isSchemaNameOverrideMetaData, session),
        makePassword.decrypt(cnf.oraclePassword()),
        cnf.oracleBatchSize.getOrElse(Constants.BATCH_SIZE),
        cnf.executionThreads.getOrElse(Constants.SPARK_EXECUTION_THREADS),
        cnf.saveMode.getOrElse(Constants.DEFAULT_SAVE_MODE),
        cnf.truncateBeforeLoad.getOrElse(true),
        loadType), session.newSession())
    })
  }

  private def getLoadTypeOpt(loadTypeOpt: Option[String]): Option[LoadType] = {
    loadTypeOpt.map {
      case "prereq" => PREREQ
      case "oadw" => OADW
      case "eoadw" => EOADW
      case "eoadw-prereq" => EOADWPREREQ
      case invalidArg => throw new IllegalArgumentException(s"Invalid load type $invalidArg")
    }
  }

  private def processExecutePostDataLoadScriptArgs(): Unit = {
    val cnf = conf.executePostDataLoadScript
    using (SparkUtils.createSparkSession("Hive To Oracle Loader", verboseLogging = false, logWarnings = true))(implicit session => {
      val postDataLoadService = new PostDataLoadService(ExecutePostDataLoadScriptConfig(
        cnf.tables(),
        cnf.tablesFile(),
        cnf.oracleHost(),
        cnf.oracleService(),
        resolveOracleUserName(cnf.hiveDb.toOption, cnf.oracleUser.toOption, false, session.newSession()),
        makePassword.decrypt(cnf.oraclePassword()),
        cnf.executionThreadCount.getOrElse(Constants.JDBC_EXECUTION_THREADS), cnf.loadType())
      )

      if (cnf.loadType().equalsIgnoreCase( "cdr_be")) {
        postDataLoadService.processPostDataLoadScript("PostDataLoadScript.sql")
        postDataLoadService.processPostDataLoadScript("PostDataLoadScript2.sql")
      } else {
        postDataLoadService.processPostDataLoadScript("epsilon_post_data_load_script.sql")
        postDataLoadService.processPostDataLoadScript("epsilon_post_data_load_script2.sql")
      }

    })
  }

  private def processExecuteScriptArgs(): Unit = {
    val cnf = conf.executeScript

    if (cnf.oracleUser.isDefined == cnf.hiveDb.isDefined) {
      throw new IllegalArgumentException("Must use --oracleUser or --hiveDb exclusively")
    }

    using (SparkUtils.createSparkSession("Hive To Oracle Loader", verboseLogging = false, logWarnings = true))(implicit session => {
      SqlExecutionService.executeSqlScript(SqlExecutionConfig(
        cnf.script(),
        cnf.oracleHost(),
        cnf.oracleService(),
        resolveOracleUserName(cnf.hiveDb.toOption, cnf.oracleUser.toOption, false, session.newSession()),
        makePassword.decrypt(cnf.oraclePassword()),
        cnf.delimiter.getOrElse(";"),
        Map.empty[String, String]))
    })
  }

  private def processDeploySynonyms(): Unit = {
    val cnf = conf.deploySynonyms
    val replaceRegex1 = Constants.DEFAULT_SCHEMA.replace("{", "\\{").replace("}", "\\}")
    val replaceRegex2 = Constants.LINK_READER_SCHEMA.replace("{", "\\{").replace("}", "\\}")
    val replaceClientId = Constants.CLIENT_ID.replace("{", "\\{").replace("}", "\\}")
    val replaceEnv = Constants.ENV.replace("{", "\\{").replace("}", "\\}")

    using(SparkUtils.createSparkSession("Hive To Oracle Loader", verboseLogging = false, logWarnings = true))(implicit session => {
      val sourceSchemaName = resolveOracleUserName(cnf.hiveDb.toOption, cnf.sourceSchemaName.toOption, false, session)
      val grantSchemaName = resolveOracleGrantSchemaName(sourceSchemaName)
      val replaceMap = Map(
        s"${replaceRegex1}" -> s"${sourceSchemaName}",
        s"${replaceRegex2}" -> s"${grantSchemaName}",
        s"${replaceClientId}" -> s"${cnf.clientId.getOrElse("HXXXXXXX1234445")}", // adding this random client id just to make sure we don't give permission to all the clients if it is empty
        s"${replaceEnv}" -> s"${cnf.env.getOrElse("dev100")}" // adding random env which doesn't exist, in order to prevent accidental grant
      )

      SqlExecutionService.executeSqlScript(SqlExecutionConfig(
        cnf.script(),
        cnf.oracleHost(),
        cnf.oracleService(),
        resolveTargetSchemaName(cnf.targetSchemaName.toOption, sourceSchemaName),
        makePassword.decrypt(cnf.oraclePassword()),
        cnf.delimiter.getOrElse("/"),
        replaceMap))
    })
  }

  private def processValidateCounts(): Unit = {
    val cnf = conf.validateCounts
    using(SparkUtils.createSparkSession("Hive To Oracle Loader", verboseLogging = false, logWarnings = true))(implicit session => {
      CountValidator.validateHiveAndOracleCounts(
        cnf.hiveDb(),
        cnf.oracleHost(),
        cnf.oracleService(),
        resolveOracleUserName(Some(cnf.hiveDb()), cnf.oracleUser.toOption, false, session),
        makePassword.decrypt(cnf.oraclePassword()),
        cnf.oadwBuildType(), session.newSession())
    })
  }

  private def processClientLevelAudit(): Unit = {
    val cnf = conf.clientLevelAudit

    ClientLevelAuditService.upsertClientAudit(ClientAuditConfig(
      cnf.hiveDb(),
      makePassword.decrypt(cnf.oraclePassword()),
      cnf.oracleHost(),
      cnf.oracleService(),cnf.skipOracleAuditUpdate.getOrElse(false)), SparkUtils.createSparkSession("Hive To Oracle Loader", verboseLogging = false, logWarnings = true))
  }

  private def resolveOracleUserName(hiveDbOpt: Option[String], oracleSchemaOpt: Option[String], isSchemaNameOverrideMetaData: Boolean, sparkSession: SparkSession): String = {
    if (oracleSchemaOpt.isDefined) {
      if (isSchemaNameOverrideMetaData) {
        OADWMetaDataUtils.updateMetaDataModel(sparkSession, MetaDataAttribute(ORACLE_SCHEMA_NAME, oracleSchemaOpt.get, false, false), hiveDbOpt.get)
      }

      oracleSchemaOpt.get
    } else {
      val seqAttrNames = Seq(ORACLE_SCHEMA_NAME)
      OADWMetaDataUtils.getAttributesFromMetaTable(sparkSession, hiveDbOpt.get, seqAttrNames)(ORACLE_SCHEMA_NAME)
    }
  }

  private def resolveTargetSchemaName(targetSchemaNameOpt: Option[String], sourceSchemaName: String): String = {
    val targetSchema = targetSchemaNameOpt.getOrElse({
      SchemaService.getCurrentSchemaNameFrom(sourceSchemaName)
    })

    logger.warn(s"Target schema for $sourceSchemaName is $targetSchema")
    targetSchema
  }

  private def resolveOracleGrantSchemaName(sourceSchemaName: String): String = {

    // example: OADW_STG_H12345_CDR_201910_2
    val sourceSchemaNameSplitted = sourceSchemaName.split("_")
    val env = sourceSchemaNameSplitted(1)
    val env_mapped = if ( env == "PRD" ) "PROD" else env
    val clientID = sourceSchemaNameSplitted(2)

    val grantSchemaName = s"LNK_READER_MAIN_$clientID" + "_" + s"$env_mapped"

    logger.warn(s"Grant schema name is $grantSchemaName")
    grantSchemaName
  }
}

case class InvalidCommandException(message: String = "", cause: Throwable = null) extends Exception(message, cause)

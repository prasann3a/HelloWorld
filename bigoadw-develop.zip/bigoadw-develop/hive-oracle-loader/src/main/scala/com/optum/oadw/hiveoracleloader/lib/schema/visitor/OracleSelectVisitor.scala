package com.optum.oadw.hiveoracleloader.lib.schema.visitor

import net.sf.jsqlparser.statement.select._

import scala.collection.JavaConverters._

trait OracleSelectVisitor extends SelectVisitor {
  this: HiveToOracleAdapter =>

  def visit(select: PlainSelect): Unit = {
    if (select.getSelectItems != null) {
      val selectItems = select.getSelectItems.asScala
      this.processSelectItems(selectItems)
      for {
        stmt <- selectItems
      } stmt.accept(this)
    }

    if (select.getFromItem != null) {
      select.getFromItem.accept(this)
    }

    if (select.getWhere != null) {
      select.getWhere.accept(this)
    }
  }

  def visit(var1: SetOperationList): Unit = {}

  def visit(withItem: WithItem): Unit = {
    if (withItem.getWithItemList != null) {
      withItem.getWithItemList.asScala.foreach(_.accept(this))
    }

    withItem.getSelectBody.accept(this)
  }
}

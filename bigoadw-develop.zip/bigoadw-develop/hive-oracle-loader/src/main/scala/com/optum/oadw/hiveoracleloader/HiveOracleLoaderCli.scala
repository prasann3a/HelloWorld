package com.optum.oadw.hiveoracleloader

import com.optum.oadw.hiveoracleloader.lib.utils.CommandLineUtils

object HiveOracleLoaderCli {
  def main(args: Array[String]): Unit = {
    val commandLineUtils = new CommandLineUtils(args)
    commandLineUtils.processCommandLineArgs()
  }
}
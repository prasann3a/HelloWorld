package com.optum.oadw.hiveoracleloader.lib.schema.visitor

import net.sf.jsqlparser.expression.operators.relational.{ExpressionList, ItemsListVisitor, MultiExpressionList, NamedExpressionList}
import net.sf.jsqlparser.statement.select.SubSelect

import scala.collection.JavaConverters._

trait OracleItemsListVisitor extends ItemsListVisitor {
  this: HiveToOracleAdapter =>

  def visit(var1: SubSelect): Unit = {}

  def visit(expressions: ExpressionList): Unit = {
    if (expressions.getExpressions != null) {
      expressions.getExpressions.asScala.foreach(_.accept(this))
    }
  }

  def visit(var1: MultiExpressionList): Unit = {}

  def visit(namedExpressionList:NamedExpressionList): Unit = {}
}

package com.optum.oadw.hiveoracleloader.lib.common

import com.optum.oadw.hiveoracleloader.lib.common.Constants.{DEFAULT_BUILD, EPSILON_BUILD, OPADM_BUILD, OPA_BUILD, OadwBuildType}

import scala.util.matching.Regex


case class OadwBuildConfig(oadwBuildType: OadwBuildType, excludePatterns: ExcludePatterns,
                      excludeTables: Set[String], excludeExceptions: Set[String], includeTables: Set[String])

case class ExcludePatterns (excludeTablePattern: Option[Regex], fromSkipPattern: Option[Regex], joinSkipPattern: Option[Regex])

object OpaBuild {
   def apply(includeTables: Set[String]): OadwBuildConfig = {
     val excludePattern = Option("^(t_)*l1(?!_ii)_".r)
     val fromSkipPattern = Option("from\\s+[t_]*[l]1_(?!ii_)".r)
     val joinSkipPattern = Option("join\\s+[|t_]*[l]1_(?!ii_)".r)
     val excludePatterns = ExcludePatterns(excludePattern, fromSkipPattern, joinSkipPattern)
     val excludeTables: Set[String] = ConfigLists.skipTableList
     val excludeExceptions: Set[String] = ConfigLists.includeMaterializedViewsList
    OadwBuildConfig(OPA_BUILD, excludePatterns, excludeTables, excludeExceptions, includeTables)

  }
}


object OpaDmBuild {
  def apply(includeTables: Set[String]): OadwBuildConfig = {
    val excludePattern: Option[Regex] = None
    val fromSkipPattern: Option[Regex] = None
    val joinSkipPattern: Option[Regex] = None
    val excludePatterns = ExcludePatterns(excludePattern, fromSkipPattern, joinSkipPattern)
    val excludeTables: Set[String] = ConfigLists.skipTableList
    val excludeExceptions: Set[String] = ConfigLists.includeMaterializedViewsList
    OadwBuildConfig(OPADM_BUILD, excludePatterns, excludeTables, excludeExceptions, includeTables)

  }
}

object EpsilonBuild {
  def apply(includeTables: Set[String]): OadwBuildConfig = {
    val excludePattern: Option[Regex] = None
    val fromSkipPattern: Option[Regex] = None
    val joinSkipPattern: Option[Regex] = None
    val excludePatterns = ExcludePatterns(excludePattern, fromSkipPattern, joinSkipPattern)
    val excludeTables: Set[String] = ConfigLists.skipTableList
    val excludeExceptions: Set[String] = ConfigLists.includeMaterializedViewsList
    OadwBuildConfig(EPSILON_BUILD, excludePatterns, excludeTables, excludeExceptions, includeTables)

  }
}

object DefaultBuild {
  def apply(includeTables: Set[String]): OadwBuildConfig = {
    val excludePattern: Option[Regex] = None
    val fromSkipPattern: Option[Regex] = None
    val joinSkipPattern: Option[Regex] = None
    val excludePatterns = ExcludePatterns(excludePattern, fromSkipPattern, joinSkipPattern)
    val excludeTables: Set[String] = ConfigLists.skipTableList
    val excludeExceptions: Set[String] = Set.empty[String]
    OadwBuildConfig(DEFAULT_BUILD, excludePatterns, excludeTables, excludeExceptions, includeTables)

  }
}

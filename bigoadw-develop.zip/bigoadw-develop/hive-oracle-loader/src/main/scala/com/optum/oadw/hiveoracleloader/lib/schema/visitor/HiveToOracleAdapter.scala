package com.optum.oadw.hiveoracleloader.lib.schema.visitor

import java.util.Properties

import com.optum.oadw.hiveoracleloader.lib.utils.ResourceHandler
import net.sf.jsqlparser.expression.{Alias, CastExpression}
import net.sf.jsqlparser.schema.Column
import net.sf.jsqlparser.statement.create.table.ColDataType
import net.sf.jsqlparser.statement.select.{SelectExpressionItem, SelectItem, SubSelect}

import scala.collection.JavaConverters._
import scala.collection.mutable

class HiveToOracleAdapter
  extends OracleExpressionVisitor
  with OracleFromVisitor
  with OracleItemsListVisitor
  with OracleSelectVisitor
  with OracleSelectItemVisitor
  with OracleStatementVisitor {

  private val oracleKeyWord: Set[String] = Set("PARTITION", "partition", "ROWNUM", "CLASS", "class", "type", "TYPE", "CLUSTER", "cluster")
  private val replacementMap = Map(""",\s+,""" -> ",", "\\$" -> "", "\\( FROM" -> "(", """\/\*.*\*\/""" -> "", "`" -> "\"")
  val columnsToFilter = Set("last_updt_dtm", "partition_key", "parititon_key")
  val selectItemMap: mutable.Map[String, String] = mutable.Map[String, String]()

    private val columnMapProperties: Option[Properties] = Some(ResourceHandler.loadColumnNamesProperties())

  private final val MAX_VARCHAR_LEN = "255"
  private final val MAX_RAW_LEN = "2000"

  override def visit(var1: SubSelect): Unit = {
    super[OracleFromVisitor].visit(var1)
  }
  def maskColumn(column: String): String = {
    val col = column.trim.replaceAll("\\$", "")
    var content = columnMapProperties.get.getProperty(col.toUpperCase, col)
    for {
      key <- oracleKeyWord
      if content.equalsIgnoreCase(key)
    } {
      content = content.replaceAll(key, s"`${key.toUpperCase}`")
    }
    content
  }


  def hiveToOracleDataType(colDataType: ColDataType): ColDataType = {
    val mappedColDataType = new ColDataType

    colDataType.getDataType.toLowerCase match {

      case "char" | "varchar" | "string" | "nvarchar2" | "clob" if colDataType.getArgumentsStringList == null => {
        mappedColDataType.setDataType("VARCHAR2")
        mappedColDataType.setArgumentsStringList(Seq(s"$MAX_VARCHAR_LEN CHAR").asJava)
      }
      case "char" | "varchar" | "string" | "nvarchar2" | "clob" if colDataType.getArgumentsStringList.size() == 1  => {
        mappedColDataType.setDataType("VARCHAR2")
        mappedColDataType.setArgumentsStringList(Seq(s"${colDataType.getArgumentsStringList.get(0)} CHAR").asJava)
      }
      case "string" => {
        mappedColDataType.setDataType("VARCHAR2")
        mappedColDataType.setArgumentsStringList(Seq(s"$MAX_VARCHAR_LEN CHAR").asJava)
      }

      case "binary" | "raw" => {
        mappedColDataType.setDataType("RAW")
        mappedColDataType.setArgumentsStringList(Seq(MAX_RAW_LEN).asJava)
      }
      case "boolean" | "bool" => {
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq("1").asJava)
      }
      case "sdate" => mappedColDataType.setDataType("DATE")
      case "date" | "timestamp" => mappedColDataType.setDataType("TIMESTAMP")
      case "float" => {
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq("38", "10").asJava)
      }
      case "double" => {
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq("38", "10").asJava)
      }
      case "bigint" | "long" => {
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq("19", "0").asJava)
      }
      case "smallint" => {
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq("5", "0").asJava)
      }
      case "tinyint" => {
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq("3", "0").asJava)
      }
      case "integer" | "int" => {
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq("10", "0").asJava)
      }
      case "numeric" | "number" if colDataType.getArgumentsStringList == null => {
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq("38", "10").asJava)
      }
      case "decimal"  if colDataType.getArgumentsStringList == null => {
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq("38", "10").asJava)
      }
      case "decimal"  if colDataType.getArgumentsStringList.size() == 2 => {
        val scale = colDataType.getArgumentsStringList.get(0)
        val precision = colDataType.getArgumentsStringList.get(1)
        mappedColDataType.setDataType("NUMBER")
        mappedColDataType.setArgumentsStringList(Seq(scale, precision).asJava)
      }
      case _ => throw new IllegalArgumentException(s"Illegal argument $colDataType")
    }
    mappedColDataType
  }


  def postProcessing(content: String): String = {
    replacementMap.foldLeft(content) { case (stmt, (pattern, replacement)) => stmt.replaceAll(pattern, replacement)}
  }

  def processSelectItems(expression: mutable.Buffer[SelectItem]): Unit = {
    val props = columnMapProperties.get

    val filteredExpressions = expression.filter(item => {
      item match {
        case expression: SelectExpressionItem => expression.getExpression match {
          case column: Column => { columnsToFilter.contains(column.getColumnName.toLowerCase)
          }
          case _ => false
        }
        case _ => false
      }
    })
    filteredExpressions.foreach(item => expression -= item)

    expression.foreach {
      case exp: SelectExpressionItem => {
        exp.getExpression match {
          case column: Column => {
            val colName = column.getColumnName.toUpperCase

            column.setColumnName(props.getProperty(colName, colName))
          }
          case castExpression: CastExpression => {
            castExpression.getLeftExpression match {
              case column: Column => {
                column.setColumnName(column.getColumnName)
                val colName = column.getColumnName.toUpperCase
                column.setColumnName(props.getProperty(colName, colName))
              }
              case _ =>

            }
          }
          case _ =>
        }
        exp.getAlias match {
          case alias: Alias => {
            alias.setName(columnMapProperties.get.getProperty(alias.getName.toUpperCase, alias.getName.toUpperCase))
          }
          case _ =>
        }
      }
      case _ =>
    }

  }

  def processSelectExpressionItem(expression: SelectExpressionItem): Unit = {
    expression.getExpression match {
      case column: Column =>
        val columnName = columnMapProperties.get.getProperty(column.getColumnName.toUpperCase, column.getColumnName)
        val alias = if (expression.getAlias != null) expression.getAlias.getName else columnName
        selectItemMap.put(maskColumn(columnName), maskColumn(alias))
      case _ =>
        val alias = expression.getAlias.getName
        selectItemMap.put(maskColumn(alias), maskColumn(alias))
    }
  }


  /**
    * Replicating Oracle's ROWNUM functionality. See: https://docs.oracle.com/cd/B19306_01/server.102/b14200/pseudocolumns009.htm
    * & http://dwgeek.com/apache-hive-rownum-pseudo-column-equivalent.html/
    * @param expr
    */
  def formatColumn(expr: Column): Unit = {
    if (expr.getColumnName.equals("row_number() over (order by current_date())")) {
      expr.setColumnName(s"ROWNUM")
    }
  }
}

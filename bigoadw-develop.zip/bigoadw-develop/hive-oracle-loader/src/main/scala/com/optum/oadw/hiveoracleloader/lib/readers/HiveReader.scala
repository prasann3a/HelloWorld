package com.optum.oadw.hiveoracleloader.lib.readers

import org.apache.spark.sql.{DataFrame, SparkSession}

case class ColumnProperties(columnName: String, columnType: String, columnDesc: String)

object HiveReader {

  def getHiveTableList(sparkSession: SparkSession, db: String): Array[String] = {
    sparkSession.catalog.setCurrentDatabase(db)

    val tableListDF =  sparkSession.catalog.listTables().toDF
    tableListDF.select("tableName").collect().map(_.getString(0))
  }

  def getHiveTableDF(session: SparkSession, tableName: String): DataFrame = {
    session.table(tableName)
  }
}

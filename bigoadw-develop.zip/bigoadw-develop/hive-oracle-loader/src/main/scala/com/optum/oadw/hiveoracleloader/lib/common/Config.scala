package com.optum.oadw.hiveoracleloader.lib.common

import Constants.LoadType
import com.optum.oadw.constants.II

object ConfigLists {
  val includeMaterializedViewsList: Set[String] = Set(
    "l1_map_med_route",
    "l1_map_allergen_type",
    "l1_map_allergy_status",
    "md_domain_concept",
    "l1_mv_hts_domain_concept",
    "l1_rxorder",
    "l1_allergy",
    "l1_rx_patient_reported",
    "l1_map_obstype",
    "l1_map_lab",
    "l1_clinical_event_encounter",
    "l1_clinical_event_encounter",
    "l1_map_procedure_cui",
    "l1_map_procedure_cui",
    "l1_map_diagnosis_cui",
    "l1_map_diagnosis_cui"
  )
  val skipTableList = Set("track_hash_table_builds")

  // The below list specifies which overlapping tables will be loaded from the OADW_REF instance
  // We've emptied this out now because all tables will be loaded straight from the OADW HIVE DB, not the raw oadw ref.
  val excludeOadwTablesAndViews = Set.empty[String]

  // The below tables will be loaded from the OADW database
  // No need to exclude any anymore, ALL tables will be loaded from the OADW database
  val excludeOadwRefTablesAndViews = Set.empty[String]
}

object Constants {
  val BATCH_SIZE                        = "20000"
  val SPARK_EXECUTION_THREADS           = 2
  val JDBC_EXECUTION_THREADS            = 16
  val DEFAULT_SAVE_MODE                 = "Overwrite"
  val TABLE_NAMES_MAP                   = "/TableNameMap.properties"
  val COLUMN_NAMES_MAP                  = "/ColumnNameMap.properties"
  val ORACLE_MANUAL_SCHEMA_FILE         = "oadw_oracle_manual_schema.sql"
  val ORACLE_UPDATE_CURRENT_SCHEMA_FILE = "oadw_oracle_update_current_schema.sql"
  val ORACLE_GRANT_SYNONYMS_SELECT_FILE = "oadw_oracle_grant_synonyms_select.sql"
  val DEFAULT_OUTPUT_SQL_FILE_NAME      = "conversionOutput.sql"
  val DEFAULT_ERROR_FILE_NAME           = "conversionErrors.txt"
  val DEFAULT_OUTPUT_PATH               = "./"
  val DEFAULT_SCHEMA                    = "{{SCHEMA_NAME}}"
  val LINK_READER_SCHEMA                = "{{LINK_READER_SCHEMA_NAME}}"
  val CLIENT_ID                         = "{{CLIENT_ID}}"
  val ENV                               = "{{ENV}}"
  val DEFAULT_TABLES_FILE_NAME          = "table_list"
  val COLUMN_OVERRIDE_MAP_FILE          = "oadw_oracle_column_map.txt"
  val DEFAULT_SYNONYM_FILE_NAME         = "create_synonyms.sql"
  val EPSILON_FILTER_FILE               = "epsilon_filter_tables.txt"
  val OPADM_FILTER_FILE                 = "opadm_filter_tables.txt"
  val II_EXTERNAL_DATATYPE_MAP          = II.CONFIG_FILE

  trait SchemaType

  case object OADW_SCHEMA extends SchemaType

  case object OADW_REF_SCHEMA extends SchemaType

  case object OTHER_SCHEMA extends SchemaType

  trait OadwBuildType

  case object OPA_BUILD extends OadwBuildType

  case object OPADM_BUILD extends OadwBuildType

  case object EPSILON_BUILD extends OadwBuildType

  case object DEFAULT_BUILD extends OadwBuildType

  trait LoadType {
    def fileName: String

    def isMetaDataSchemaNameOverride: Boolean
  }

  case object OADW extends LoadType {
    def fileName: String = "oadw_export_tables.txt"

    def isMetaDataSchemaNameOverride = true
  }

  case object EOADW extends LoadType {
    def fileName: String = "epsilon_export_all_tables.txt"

    def isMetaDataSchemaNameOverride = false
  }

  case object PREREQ extends LoadType {
    def fileName: String = "oadw_prereq_export_tables.txt"

    def isMetaDataSchemaNameOverride = false
  }

  case object EOADWPREREQ extends LoadType {
    def fileName: String = "epsilon_oadw_prereq_export_tables.txt"

    def isMetaDataSchemaNameOverride = false
  }
}

object CustomMaps {

  // This map will add the table partition information in the Create Table statement
  lazy val TablePartitionMap: Map[String, String] = Map(
    "L2_CLINICAL_EVENT_ID"         -> "PARTITION BY HASH(clinical_event_id) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)",
    "L2_PAT_ACTIVITY_MONTH"        -> "PARTITION BY LIST(activity_type_cd) (PARTITION P_EVENT VALUES('EVENT'))",
    "L2_PAT_ACTIVITY_SUMMARY"      -> "PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)",
    "L2_PAT_ALLERGY"               -> "PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)",
    "L2_PAT_ASSESS_NUM"            -> "PARTITION BY LIST (assessment_cui) (PARTITION P_CH999999 values('CH999999'))",
    "L2_PAT_ASSESS_QUAL"           -> "PARTITION BY LIST (ASSESSMENT_CUI) (PARTITION P_CH999999 values('CH999999'))",
    "L2_PAT_CLINICAL_EVENT"        -> "PARTITION BY LIST(EVENT_TYPE_CUI) (PARTITION P_CH000000 values ('CH000000'))",
    "L2_PAT_CLINICAL_EVENT_PROV"   -> "PARTITION BY LIST (prov_role_cui) (PARTITION p_CH999999 VALUES ('CH999999'))",
    "L2_PAT_DIAG"                  -> "PARTITION BY LIST(parititon_key) (PARTITION P_ICD10_U VALUES ('ICD10_U'))",
    "L2_PAT_HM_DEFERRED"           -> "PARTITION BY HASH (mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)",
    "L2_PAT_ID"                    -> "PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)",
    "L2_PAT_IMMUNIZATION"          -> "PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)",
    "L2_PAT_INSURANCE"             -> "PARTITION BY LIST (primary_ind) (PARTITION P_PRIMARY_0 VALUES (0) ,PARTITION P_PRIMARY_1 VALUES (1))",
    "L2_PAT_MED"                   -> "PARTITION BY LIST (partition_key) (PARTITION p_dcc_0 values ('0') ,PARTITION p_dcc_1 values ('1') ,PARTITION p_dcc_2 values ('2') ,PARTITION p_dcc_3 values ('3') ,PARTITION p_dcc_4 values ('4') ,PARTITION p_dcc_5 values ('5') ,PARTITION p_dcc_6 values ('6') ,PARTITION p_dcc_7 values ('7') ,PARTITION p_dcc_8 values ('8') ,PARTITION p_dcc_9 values ('9'))",
    "L2_PAT_MICROBIO"              -> "PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)",
    "L2_PAT_PROC"                  -> "PARTITION BY LIST(code_type) (PARTITION P_NULL VALUES (NULL))",
    "L2_PATIENT_INFO"              -> "PARTITION BY RANGE(dob) (PARTITION P_pre1940 VALUES LESS THAN (to_date('19400101','YYYYMMDD')) ,PARTITION P_1940s VALUES LESS THAN (to_date('19500101','YYYYMMDD')) ,PARTITION P_1950s VALUES LESS THAN (to_date('19600101','YYYYMMDD')) ,PARTITION P_1960s VALUES LESS THAN (to_date('19700101','YYYYMMDD')) ,PARTITION P_1970s VALUES LESS THAN (to_date('19800101','YYYYMMDD')) ,PARTITION P_1980s VALUES LESS THAN (to_date('19900101','YYYYMMDD')) ,PARTITION P_1990s VALUES LESS THAN (to_date('20000101','YYYYMMDD')) ,PARTITION P_pre2020 VALUES LESS THAN (to_date('20200101','YYYYMMDD')) ,PARTITION P_MAX VALUES LESS THAN (MAXVALUE) )",
    "L3_EVENT_READMISSION"         -> "PARTITION BY LIST(readmission_type_cui) (PARTITION P_CH000000 VALUES ('CH000000'))",
    "L3_PAT_CONDITION_PRECURSOR"   -> "PARTITION BY RANGE(condition_id) INTERVAL(1) (PARTITION P_CND_0 VALUES LESS THAN (0))",
    "L3_PAT_PRECURSOR"             -> "PARTITION BY Range(precursor_id) interval(1) (PARTITION P_PCR_0 VALUES less than(0))",
    "L3_PAT_SCORE_GRP_INTN"        -> "PARTITION BY Range(grp_id) interval(1) (PARTITION P_GRP_0 VALUES less than(0))",
    "L3_PAT_SCORE_GRP_PRECUR"      -> "PARTITION BY RANGE(grp_id) INTERVAL(1) (PARTITION P_GRP_0 VALUES less than(0))",
    "L3_PAT_TIMEFRAME_AGE"         -> "PARTITION BY LIST (timeframe_id) (PARTITION P_time_0 values (0))",
    "L3_PAT_TIMEFRAME_INS"         -> "PARTITION BY RANGE (timeframe_id) INTERVAL(1) (PARTITION time_0 VALUES LESS THAN (0))",
    "L4_PAT_HCC_DROPPED"           -> "PARTITION BY RANGE(dropped_precursor_id) INTERVAL(1) (PARTITION P_DRPPRC_0 VALUES less than(0))",
    "L4_PAT_HCC_OPPORTUNITY"       -> "PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)",
    "L4_PAT_HCC_OPPRTNTY_DETAIL"   -> "PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)",
    "L4_PAT_SCORE"                 -> "PARTITION BY RANGE(score_id) INTERVAL(1) (PARTITION P_SCORE_0 VALUES LESS THAN (0))",
    "L4_PAT_SCORE_MARKERCAT"       -> "PARTITION BY RANGE(score_id) INTERVAL(1) (PARTITION P_SCORE_0 VALUES LESS THAN(0))",
    "L4_PATIENT_CONDITION"         -> "PARTITION BY RANGE(condition_id) INTERVAL(1) (PARTITION p_cond_0 VALUES LESS THAN (0))",
    "L4_PAT_CONDITION_INFERRED"    -> "PARTITION BY RANGE(condition_id) INTERVAL(1) (PARTITION P_cond_0 VALUES LESS THAN (0))",
    "L4_PATIENT_INFO"              -> "PARTITION BY RANGE(dob) (PARTITION P_pre1940 VALUES LESS THAN (to_date('19400101','YYYYMMDD')) ,PARTITION P_1940s VALUES LESS THAN (to_date('19500101','YYYYMMDD')) ,PARTITION P_1950s VALUES LESS THAN (to_date('19600101','YYYYMMDD')) ,PARTITION P_1960s VALUES LESS THAN (to_date('19700101','YYYYMMDD')) ,PARTITION P_1970s VALUES LESS THAN (to_date('19800101','YYYYMMDD')) ,PARTITION P_1980s VALUES LESS THAN (to_date('19900101','YYYYMMDD')) ,PARTITION P_1990s VALUES LESS THAN (to_date('20000101','YYYYMMDD')) ,PARTITION P_pre2020 VALUES LESS THAN (to_date('20200101','YYYYMMDD')) ,PARTITION P_MAX VALUES LESS THAN (MAXVALUE) )"
  )

  // This map will add columns to the converted Create Table statement.
  lazy val AddColumnsMap: Map[String, List[String]] = Map(
    "L2_PAT_DIAG" -> List("parititon_key VARCHAR2(100 CHAR) GENERATED ALWAYS AS (substr(code_type,1,20) || '_' ||  substr(diag_cd,1,1)) VIRTUAL"),
    "L2_PAT_MED"  -> List("partition_key VARCHAR2(1 CHAR) GENERATED ALWAYS AS (SUBSTRB(dcc,1,1)) VIRTUAL")
  )

  // This map is used to get the source DB from the input HQL file
  lazy val fileDbMap: Map[String, String] = Map("ii_external_schema.hql" -> "II", "oadw_reference_schema.hql" -> "OADW_REFERENCE", "cdr_schema.hql" -> "CDR", "oadw_schema.hql" -> "OADW", "oadw_combined_schema.hql" -> "Combined Schema")
}

case class OracleConfig(
  saveMode: String = Constants.DEFAULT_SAVE_MODE,
  oracleUserName: String,
  oraclePassword: String,
  oracleHost: String,
  oracleService: String,
  oracleBatchSize: String = Constants.BATCH_SIZE)

case class ExecutePostDataLoadScriptConfig(
  tables: String,
  tablesFile: String,
  oracleHost: String,
  oracleService: String,
  oracleUser: String,
  oraclePassword: String,
  executionThreadCount: Int,
  loadType: String)

case class HqlToOracleSqlConfig(
  inputHqlFiles: String,
  outputFilePath: String,
  outputSqlFileName: String,
  tableListFile: String,
  errorFileName: String,
  appendToOutput: Boolean,
  createTableListOnly: Boolean,
  tableFilterFile: String,
  createSynonymSchema: Boolean,
  synonymSchemaFile: String,
  oadwBuildType: String)

case class CreateOracleSchemaConfig(
  schemaName: Option[String],
  clientId: String,
  oracleHost: String,
  oracleService: String,
  oracleUser: String,
  oraclePassword: String,
  environment: Option[String],
  hiveDb: Option[String])

case class DropOracleSchemaConfig(schemaName: String, oracleHost: String, oracleService: String, oracleUser: String, oraclePassword: String)

case class HiveToOracleDataLoadConfig(
  clientId: String,
  environment: String,
  instance: String,
  streamId: String,
  cdrCycle: String,
  cdrLevel: String,
  iiProcessId: String,
  iiDateStamp: String,
  oadwRefVersion: String,
  tables: Option[String],
  tablesFile: Option[String],
  oracleHost: String,
  oracleService: String,
  oracleUser: String,
  oraclePassword: String,
  oracleBatchSize: String,
  executionThreads: Int,
  saveMode: String,
  truncateBeforeLoad: Boolean,
  loadType: Option[LoadType])

case class SqlExecutionConfig(script: String, oracleHost: String, oracleService: String, oracleUser: String, oraclePassword: String, delimiter: String, replaceMap: Map[String, String])

case class ClientAuditConfig(hiveDb: String, oraclePassword: String, oracleHost: String, oracleService: String, skipOracleUpdate: Boolean = false)

case class ColumnDataTypeOverride(tableName: String, columnName: String, dataType: String)

case class DataLoadExceptionLog(tableName: String, exception: Throwable)

package com.optum.oadw.hiveoracleloader.lib.schema

/**
  * Content handler provides an abstraction against the handling of auto-converted code.
  * SchemaParser class takes an instance of ContentHandler as input.
  */
trait ContentHandler {

  /**
    * Invoked if JSQParser is able to parse & map the input sql to either CREATE TABLE or CREATE VIEW instance.
    * @param content
    */
  def success(content: SchemaContent): Unit

  /**
    * Invoked if JSQLParser is unable to parse & map the input sql to either CREATE TABLE or CREATE VIEW instance.
    * @param content
    */
  def failed(content: SchemaContent): Unit

   /**
    * Override this method after all of the test files have been processed. You can choose to either write the content to
    * file or log the statements.
    */
  def flush: Unit
}

package com.optum.oadw.hiveoracleloader

import java.sql.Connection
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.optum.oap.jdbc.OracleDriver
import com.optum.oadw.utils.MetaDataConstants._
import com.optum.oadw.hiveoracleloader.lib.common.ClientAuditConfig
import com.optum.oadw.utils.{MdOadwInstanceHelper, MetaDataConstants}
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

/** Static table in static OADW_AUDIT schema present in rac03, opa_prod and rac_multi */
/*
CREATE TABLE OADW_AUDIT.CLIENT_AUDIT
(
  CLIENT_ID VARCHAR2(20 CHAR)
, ENVIRONMENT VARCHAR2(10 CHAR)
, ORACLE_SCHEMA VARCHAR2(35 CHAR)
, LAST_UPDATE_DTM TIMESTAMP(6)
, IS_MONTHLY NUMBER(1, 0)
, IS_LATEST NUMBER(1, 0)
, SOURCE_HIVE_SCHEMA VARCHAR2(50 BYTE)
, REF_SCHEMA VARCHAR2(100 BYTE)
, CDR_VERSION VARCHAR2(100 BYTE)
, CDR_SCHEMA VARCHAR2(100 BYTE)
, CDR_INSTANCE VARCHAR2(100 BYTE)
, OADW_VERSION VARCHAR2(100 BYTE)
, II_VERSION VARCHAR2(100 BYTE)
, OADW_CONTRACT_VERSION VARCHAR2(100 BYTE)
, II_DATE_STAMP VARCHAR2(100 BYTE)
, II_PROCESS_ID VARCHAR2(100 BYTE)
, SETUP_DTM VARCHAR2(100 BYTE)
, DATA_THRU VARCHAR2(100 BYTE)
, ORCL_DATA_SIZE_GB VARCHAR2(100 BYTE)
, ETL_START_DTM VARCHAR2(100 BYTE)
, ETL_END_DTM VARCHAR2(100 BYTE)
, ORCL_EXPORT_START_DTM VARCHAR2(100 BYTE)
, ORCL_EXPORT_END_DTM VARCHAR2(100 BYTE)
, BUILD_ENVIRONMENT VARCHAR2 (32 CHAR)
)
 */

object ClientLevelAuditService {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def updateMdOadwInstance(sparkSession: SparkSession, clientAuditConfig: ClientAuditConfig): String = {
    val formatter = DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss")
    formatter.format(LocalDateTime.now())
  }

  def readMetadataValue(metaData: Map[String, String], key: String): String =
    if (metaData.contains(key)) metaData(key) else ""

  def getOracleDbSize(oracleDriver: OracleDriver, oracleSchemaName: String): String = {
    val sel_conn     = oracleDriver.getConnection
    val dataSizeStmt = sel_conn.createStatement()

    val dataSize = try {
      val owner       = oracleSchemaName
      val selectQuery = s"select Round(SUM (bytes)/1024/1024/1024, 2) AS GB from dba_segments where owner = '$owner'"
      logger.warn(selectQuery)
      val resultSet = dataSizeStmt.executeQuery(selectQuery)
      resultSet.next()
      resultSet.getString("GB")
    } catch {
      case e: Exception =>
        logger.error("Cannot read oracle data size")
        logger.error(e.getMessage)
        ""
    } finally {
      dataSizeStmt.close()
    }
    logger.warn("Size of oracle database: " + dataSize)
    dataSize
  }

  def insertIntoMdInstance(conn: Connection, OrclSchemaName: String, attributeName: String, attributeValue: String): Unit = {
    val insertOrclMdInstance = s"INSERT INTO $OrclSchemaName.MD_OADW_INSTANCE (ATTRIBUTE_NAME, ATTRIBUTE_VALUE, LAST_UPDATE_DTM) VALUES ('%s', '%s', sysdate)"
    val insertQueryMdInstance = String.format(insertOrclMdInstance, attributeName, attributeValue)
    logger.warn(s"$insertQueryMdInstance")
    val insertMdInstance = conn.prepareStatement(insertQueryMdInstance)
    try {
      insertMdInstance.execute()
    }
    catch {
      case e: Exception =>
        logger.error(e.getMessage)
    }
    finally {
      insertMdInstance.close()
    }
  }

  def upsertClientAudit(clientAuditConfig: ClientAuditConfig, sparkSession: SparkSession): Unit = {
    // update oracle export end dtm
    val orclExportEndDtm = updateMdOadwInstance(sparkSession, clientAuditConfig)
    MdOadwInstanceHelper.addRecordInMdOadwInstance(sparkSession, clientAuditConfig.hiveDb, MetaDataConstants.ORCL_EXPORT_END_DTM, orclExportEndDtm)

    val OADW_AUDIT_SCHEMA  = "OADW_AUDIT"
    val CLIENT_AUDIT_MODEL = "CLIENT_AUDIT"

    val insertQueryTemplate = s"INSERT INTO $CLIENT_AUDIT_MODEL (CLIENT_ID, ENVIRONMENT, SOURCE_HIVE_SCHEMA, ORACLE_SCHEMA, " +
      s"LAST_UPDATE_DTM, IS_MONTHLY, IS_LATEST, REF_SCHEMA, II_DATE_STAMP, II_PROCESS_ID, SETUP_DTM, DATA_THRU, CDR_SCHEMA, " +
      s"CDR_VERSION, CDR_INSTANCE,ETL_START_DTM, ETL_END_DTM, ORCL_EXPORT_START_DTM, ORCL_EXPORT_END_DTM, OADW_VERSION, " +
      s"II_VERSION, OADW_CONTRACT_VERSION, ORCL_DATA_SIZE_GB, BUILD_ENVIRONMENT ) " +
      s"VALUES ('%s', '%s', '%s', '%s', sysdate, %s, 1,'%s', '%s', '%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')"
    logger.info(s"New fields: $REF_SCHEMA, $II_DATE_STAMP, $II_PROCESS_ID, $SETUP_DTM, $DATA_THRU, $SRC_SCHEMA, $CONTENT_VERSION, $INSTANCE, $SETUP_DTM")
    val updateQueryTemplate = s"UPDATE $CLIENT_AUDIT_MODEL SET IS_LATEST = 0 WHERE CLIENT_ID = '%s' AND ENVIRONMENT = '%s' AND IS_MONTHLY = %s"
    val metaData = MdOadwInstanceHelper.getAttributesFromMetaTable(sparkSession, clientAuditConfig.hiveDb)

    val OrclSchemaName = readMetadataValue(metaData, ORACLE_SCHEMA_NAME).toUpperCase
    val isMonthly = metaData(IS_MONTHLY_FLG).toLowerCase match {
      case "y"          => 1
      case "delta"      => 0
      case invalidEntry => throw new IllegalArgumentException(s"Invalid content $invalidEntry in md_oadw_instance for IS_MONTHLY_FLG")
    }

    val etlStartDtm = readMetadataValue(metaData, SETUP_DTM)

    val (oracleSchemaName,dataSize) = clientAuditConfig.skipOracleUpdate match {
      case false => {
        val oracleDriverMdInstance = new OracleDriver(clientAuditConfig.oracleHost, clientAuditConfig.oracleService, OrclSchemaName, clientAuditConfig.oraclePassword)
        val connMdInstance = oracleDriverMdInstance.getConnection
        //insert into oracle md_oadw_instance
        insertIntoMdInstance(connMdInstance, OrclSchemaName,  "ETL_START_DTM", etlStartDtm)
        insertIntoMdInstance(connMdInstance, OrclSchemaName,  "ORCL_EXP_END_DTM", orclExportEndDtm)
        val schemaSize = getOracleDbSize(oracleDriverMdInstance, OrclSchemaName)
        insertIntoMdInstance(connMdInstance, OrclSchemaName,  "ORCL_DATA_SIZE_GB", schemaSize)
        (readMetadataValue(metaData, ORACLE_SCHEMA_NAME).toUpperCase,schemaSize)
      }
      case true => {
        logger.warn(s"skipping the oracle update in ${OADW_AUDIT_SCHEMA}")
        ("ORACLE SCHEMA UPDATE IS SKIPPED", "0")
      }
    }

    MdOadwInstanceHelper.addRecordInMdOadwInstance(sparkSession, clientAuditConfig.hiveDb, MetaDataConstants.ORCL_DATA_SIZE_GB, dataSize)
    MdOadwInstanceHelper.addRecordInMdOadwInstance(sparkSession, clientAuditConfig.hiveDb, MetaDataConstants.ETL_START_DTM, readMetadataValue(metaData, SETUP_DTM))

    val updateQuery = String.format(updateQueryTemplate, metaData(CLIENT_ID).toUpperCase, metaData(ENVIRONMENT).toUpperCase, isMonthly.toString)
    val insertQuery = String.format(
      insertQueryTemplate,
      readMetadataValue(metaData, CLIENT_ID).toUpperCase,
      readMetadataValue(metaData, ENVIRONMENT).toUpperCase,
      clientAuditConfig.hiveDb.toLowerCase,
      oracleSchemaName,
      isMonthly.toString,
      readMetadataValue(metaData, REF_SCHEMA),
      readMetadataValue(metaData, II_DATE_STAMP),
      readMetadataValue(metaData, II_PROCESS_ID),
      readMetadataValue(metaData, SETUP_DTM),
      readMetadataValue(metaData, DATA_THRU),
      readMetadataValue(metaData, SRC_SCHEMA),
      readMetadataValue(metaData, CONTENT_VERSION),
      readMetadataValue(metaData, INSTANCE),
      readMetadataValue(metaData, SETUP_DTM),
      readMetadataValue(metaData, ETL_END_DTM),
      readMetadataValue(metaData, ORCL_EXPORT_START_DTM),
      readMetadataValue(metaData, ORCL_EXPORT_END_DTM),
      readMetadataValue(metaData, OADW_VERSION),
      readMetadataValue(metaData, PE_VERSION),
      readMetadataValue(metaData, OADW_CONTRACT_VERSION),
      dataSize,
      readMetadataValue(metaData, BUILD_ENVIRONMENT)
    )
    logger.warn("Update query: " + updateQuery)
    logger.warn("Insert query: " + insertQuery)
    val oracleDriver = new OracleDriver(clientAuditConfig.oracleHost, clientAuditConfig.oracleService, OADW_AUDIT_SCHEMA, clientAuditConfig.oraclePassword)
    val conn         = oracleDriver.getConnection

    val updateStmt = conn.prepareStatement(updateQuery)
    val insertStmt = conn.prepareStatement(insertQuery)

    try {
      conn.setAutoCommit(false)
      updateStmt.executeUpdate()
      insertStmt.execute()
      conn.commit()
    } catch {
      case e: Exception =>
        logger.error("Update or insert failed for oadw_audit")
        logger.error(e.getMessage)
        conn.rollback()
        throw e
    } finally {
      updateStmt.close()
      insertStmt.close()
      conn.close()
    }
  }
}

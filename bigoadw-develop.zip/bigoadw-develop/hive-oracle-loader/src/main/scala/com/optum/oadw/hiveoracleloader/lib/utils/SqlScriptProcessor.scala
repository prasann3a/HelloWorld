package com.optum.oadw.hiveoracleloader.lib.utils

import java.io.InputStream

import better.files.{File => ScalaFile}
import org.slf4j.LoggerFactory

import scala.collection.mutable

object SqlScriptProcessor {

  private val logger = LoggerFactory.getLogger(this.getClass)

  val tableMap = mutable.Map.empty[String, String]

  def initialize(inputFileStream: InputStream): Unit = {
    val commentRegex="""\s*--.*""".r

    tableMap.clear()
    scala.io.Source.fromInputStream(inputFileStream).getLines().foreach(line => {
      if(!line.trim.isEmpty && commentRegex.findFirstMatchIn(line).isEmpty)
        tableMap += parseLineAndGetMap(line)
    })
  }

  private def parseLineAndGetMap(line: String): (String, String) = {

    val alterTableRegex = """(?i)\s*ALTER TABLE\s+([a-zA-Z0-9_]*)""".r
    val firstMatch = alterTableRegex.findFirstMatchIn(line)
    val tableOrIndexName = if(firstMatch.isDefined) {
      firstMatch.get.group(1).toLowerCase
    } else {
      val createIndexRegex = """(?i)\s*CREATE\s+(UNIQUE)*\s*INDEX\s+([a-zA-Z0-9_]*)\s+ON\s+([a-zA-Z0-9_]*)""".r
      val createIndexMatch = createIndexRegex.findFirstMatchIn(line)
      if(createIndexMatch.isDefined)
        createIndexMatch.get.group(3).toLowerCase
      else {
        val alterIndexRegex = """(?i)\s*ALTER INDEX\s+([a-zA-Z0-9_]*)""".r
        val alterIndexMatch = alterIndexRegex.findFirstMatchIn(line)
        if (alterIndexMatch.isDefined)
          alterIndexMatch.get.group(1).toLowerCase
        else {
          logger.error(s"Unsupported SQL statement - $line")
        }
      }
    }
    val key = tableOrIndexName.asInstanceOf[String]
    val value = tableMap.getOrElse(key, "")
    val stripSemicolon = {
      if (
        """;\s*$""".r.findFirstMatchIn(line).isDefined)
        line.trim.dropRight(1)
      else line
    }
    val statement = s"EXECUTE IMMEDIATE '${stripSemicolon.replaceAll("'", "''")}';"

    key -> {if(value.isEmpty) statement else s"$value\n$statement"}
  }

  def getPostProcessScriptForTable(tableOrIndexName: String): Option[String] ={
    if(!tableMap.contains(tableOrIndexName))
      None
    val scriptHeader =
      s"""BEGIN
         |""".stripMargin
    val scriptTrailer =
      s"""
         |END;
       """.stripMargin

    Some(s"$scriptHeader${tableMap(tableOrIndexName).trim}$scriptTrailer")
  }

  def getTableListFromMap(): Set[String] = {
    val (tables, _) = tableMap.unzip
    tables.toSet
  }

  def getSql(scriptFileName: String, replaceMap: Map[String, String]): String = {

    val resourcePath = s"/oracle-schema/$scriptFileName"
    val iStream = this.getClass.getResourceAsStream(resourcePath)

    val script = scala.io.Source.fromInputStream(iStream).getLines().mkString("\n")
    if(replaceMap.isEmpty) {
      script
    } else {
      replaceMap.foldLeft(script)((a, b) => a.replaceAll(b._1, b._2))
    }
  }

}

package com.optum.oadw.hiveoracleloader.lib.utils
import com.optum.oadw.utils.VersionManager
import org.rogach.scallop.{ScallopConf, Subcommand}

class CommandLineConf(arguments: Seq[String]) extends ScallopConf(arguments) {
  banner(
    """
      |Usage: ./hive-oracle-loader.sh hiveToOracleDataLoad --hiveDb <source_hive_database>
      |        --oracleHost <destination_oracle_host>
      |        --oracleService <oracle_service> --oracleUser <oracle_user_name>
      |        --oraclePassword <oracle_password>
      |        [--tableFile <file_containing_hive_source_table_list>]
      |        [--tables <comma_separated_list_of_hive_source_tables>]
      |        [--loadType <oadw/ref/prereq>]
      |        [--saveMode <overwrite/append>]
      |        [--oracleBatchSize <batch_size>]
      |        [--executionThreads <num_threads>]
      |        [--truncateBeforeLoad]
      |        [--loadType]
      |
      |Usage: ./hive-oracle-loader.sh createOracleSchema
      |        [--schemaName <oracle_schema_name>]
      |        -OR-
      |        [--clientId <client_id>]
      |        [--environment <prd|stg|dev>]
      |        [--hiveDb <hive_db>]
      |        --oracleHost <destination_oracle_host>
      |        --oracleService <oracle_service>
      |        --oracleUser <oracle_user_name>
      |        --oraclePassword <oracle_password>
      |
      |Usage: ./hive-oracle-loader.sh dropOracleSchema
      |        --schemaName <oracle_schema_name>
      |        --oracleHost <destination_oracle_host>
      |        --oracleService <oracle_service>
      |        --oracleUser <oracle_user_name>
      |        --oraclePassword <oracle_password>
      |
      |Usage: ./hive-oracle-loader.sh hqlToOracleSql
      |        --inputHqlFiles <source_hive_database>
      |        --outputFilePath <output_path>
      |        --tableListFile <table_list_file>
      |        [--outputSqlFileName <file_containing_oracle_schema>]
      |        [--createTableListOnly]
      |        [--errorFileName <file_containing_hive_source_table_list>]
      |        [--createSynonymSchema]
      |        [--synonymSchemaFile <synonym_schema_file>]
      |        [--oadwBuildType <OPA|OPADM|EPSILON>]
      |        [--disabledFeatures <Features>]
      |
      |Usage: ./hive-oracle-loader.sh executePostDataLoadScript
      |        --postDataLoadTasksFile <post_load_script>
      |        --oracleHost <destination_oracle_host>
      |        --oracleService <oracle_service>
      |        [--oracleUser <oracle_user_name>]
      |        --oraclePassword <oracle_password>
      |        [--tableFile <file_containing_hive_source_table_list>]
      |        [--tables <comma_separated_list_of_hive_source_tables>]
      |        [--executionThreadCount <num_of_threads>]
      |        [--hiveDb <hive_db>]
      |
      |Usage: ./hive-oracle-loader.sh executeScript
      |        --script <sql_script>
      |        --oracleHost <destination_oracle_host>
      |        --oracleService <oracle_service>
      |        [--oracleUser <oracle_user_name>]
      |        --oraclePassword <oracle_password>
      |        --delimiter <delimiter_char>
      |        [--hiveDb <hive_db>]
      |
      |Usage: ./hive-oracle-loader.sh deploySynonyms
      |        --script <sql_script>
      |        --sourceSchemaName <source_schema_name>
      |        --oracleHost <destination_oracle_host>
      |        --oracleService <oracle_service>
      |        [--targetSchemaName <target_schema_name>]
      |        --oraclePassword <oracle_password>
      |        --delimiter <delimiter_char>
      |        [--hiveDb <hive_db>]
      |
      |Usage: ./hive-oracle-loader.sh validateCounts
      |        [--hiveDb <hive_db>]
      |        --oracleHost <destination_oracle_host>
      |        --oracleService <oracle_service>
      |        [--oracleUser <oracle_user_name>]
      |        --oraclePassword <oracle_password>
      |        --oadwBuildType <EPSILON/DEFAULT>
      |
      |Usage: ./hive-oracle-loader.sh clientLevelAudit
      |        --hiveDb <hive_db>
      |        --oracleHost <destination_oracle_host>
      |        --oracleService <oracle_service>
      |        --oraclePassword <oracle_password>
      |
      |""".stripMargin)


  val hqlToOracleSql = new Subcommand("hqlToOracleSql") {

    val inputHqlFiles = opt[String](required = true, name = "inputHqlFile", argName = "inputHqlFile",
      descr = "Comma separated list of input HQL file containing the HQL schema creation commands that need to be " +
        "translated to corresponding Oracle SQL commands")

    val outputFilePath = opt[String](required = true, name = "outputFilePath", argName = "outputFilePath",
      descr = "Default path where the output files will be created.")

    val outputSqlFileName = opt[String](required = false, name = "outputSqlFileName", argName = "outputSqlFileName",
      descr = "Name of the output Oracle SQL file.", default = Some(""))

    val tableListFile = opt[String](required = true, name = "tableListFile", argName = "tableListFile",
      descr = "Creates a file containing a list of all tables parsed via the HQL schema")

    val createTableListOnly = opt[Boolean](required = false, name = "createTableListOnly", argName = "createTableListOnly",
      descr = "Does not create a corresponding .sql schema file. This option is useful to get a list of tables from the input HQL schema")

    val errorFileName = opt[String](required = false, name = "errorFileName", argName = "errorFileName",
      descr = "Any conversion related errors will be redirected to this file.")

    val appendToOutput = opt[Boolean](required = false, name = "appendToOutput", argName = "appendToOutput",
      descr = "If set, the output SQL file specified by the outputSqlFileName parameter will not be overwritten")

    val tableFilterFile = opt[String](required = false, name = "tableFilterFile", argName = "tableFilterFile",
      descr = "File containing a list of tables/views to filter the complete list.", default = Some(""))

    val createSynonymSchema = opt[Boolean](required = false, name = "createSynonymSchema", argName = "createSynonymSchema",
      descr = "If set, a SQL file containing create synonym statements for each table/view will be generated",
      default = Some(false))

    val synonymSchemaFile = opt[String](required = false, name = "synonymSchemaFile", argName = "synonymSchemaFile",
      descr = "Name of the Oracle Synonym schema file to create")

    val oadwBuildType = opt[String](required = false, name = "oadwBuildType", argName = "oadwBuildType",
      descr = "OADW build profile. Choose from - OPA | OPADM | EPSILON | DEFAULT. Defaults to DEFAULT", default = Some("DEFAULT"))
  }

  val createOracleSchema = new Subcommand("createOracleSchema") {

    val schemaName = opt[String](required = false, name = "schemaName", argName = "schemaName",
      descr = "Override auto-generated new schema name")

    val clientId = opt[String](required = true, name = "clientId", argName = "clientId",
      descr = "Client ID for the user schema")

    val oracleHost = opt[String](required = true, name = "oracleHost", argName = "oracleHost",
      descr = "Oracle host name")

    val oracleService = opt[String](required = true, name = "oracleService", argName = "oracleService",
      descr = "Oracle service/SID")

    val oracleUser = opt[String](required = true, name = "oracleUser", argName = "oracleUser",
      descr = "Oracle user name")

    val oraclePassword = opt[String](required = true, name = "oraclePassword", argName = "oraclePassword",
      descr = "Oracle password")

    val environment = opt[String](required = false, name = "environment", argName = "environment",
      descr = "Environment (prd, stg, dev)")

    val hiveDb = opt[String](required = false, name = "hiveDb", argName = "hiveDb",
      descr = "Hive database sourcing the data")
  }

  val dropOracleSchema = new Subcommand("dropOracleSchema") {

    val schemaName = opt[String](required = true, name = "schemaName", argName = "schemaName",
      descr = "Schema name to drop")

    val oracleHost = opt[String](required = true, name = "oracleHost", argName = "oracleHost",
      descr = "Oracle host name")

    val oracleService = opt[String](required = true, name = "oracleService", argName = "oracleService",
      descr = "Oracle service/SID")

    val oracleUser = opt[String](required = true, name = "oracleUser", argName = "oracleUser",
      descr = "Oracle user name")

    val oraclePassword = opt[String](required = true, name = "oraclePassword", argName = "oraclePassword",
      descr = "Oracle password")
  }

  val hiveToOracleDataLoad = new Subcommand("hiveToOracleDataLoad") {

    val clientId = opt[String](required = true, name = "clientId", argName = "clientId", descr = "Client Id")

    val environment = opt[String](required = true, name = "environment", argName = "environment",
      descr = "Environment (prd, stg, dev)")

    val instance = opt[String](required = true, name = "instance", argName = "instance", descr = "Instance identifier string for parquet path and hive table names")

    val streamId = opt[String](required = true, name = "streamId", argName = "streamId", descr = "stream id name")

    val cdrCycle = opt[String](required = true, name = "cdrCycle", argName = "cdrCycle", descr = "CDR Cycle")

    val cdrLevel = opt[String](required = true, name = "cdrLevel", argName = "cdrLevel", descr = "Possible values: 'cdr_be' or 'ecdr'")

    val iiProcessId = opt[String](required = true, name = "iiProcessId", argName = "iiProcessId", descr = "Process Id from II return")

    val iiDateStamp = opt[String](required = true, name = "iiDateStamp", argName = "iiDateStamp", descr = "Date stamp for II return")

    val oadwRefVersion = opt[String](required = false, default = Option(VersionManager.RefVersion), name = "oadwRefVersion", argName = "oadwRefVersion", descr = "Oadw Reference version for parquet location")

    val tables = opt[String](required = false, name = "tables", argName = "tables",
      descr = "A comma separated list of Hive tables to load in Oracle; ignored when tablesFile if present")

    val tablesFile = opt[String](required = false, name = "tablesFile", argName = "tablesFile",
      descr = "File containing list of tables(one per line). Give full hdfs path: hdfs://somhorton1/user/user_name/oadw_import.txt")

    val oracleHost = opt[String](required = true, name = "oracleHost", argName = "oracleHost",
      descr = "Oracle host name")

    val oracleService = opt[String](required = true, name = "oracleService", argName = "oracleService",
      descr = "Oracle service/SID")

    val oracleUser = opt[String](required = false, name = "oracleUser", argName = "oracleUser",
      descr = "Oracle user name")

    val oraclePassword = opt[String](required = true, name = "oraclePassword", argName = "oraclePassword",
      descr = "Oracle password")

    val oracleBatchSize = opt[String](required = false, name = "oracleBatchSize", argName = "oracleBatchSize",
      descr = "Oracle batch size", default = Some("20000"))

    val executionThreads = opt[Int](required = false, name = "executionThreads", argName = "executionThreads",
      descr = "Number of tables to load in parallel. Set to 2 if not specified", default = Some(2))

    val saveMode = opt[String](required = false, name = "saveMode", argName = "saveMode",
      descr = "Specifies the write mode for Oracle tables. Valid values - overwrite/ append.", default = Some("Overwrite"))

    val metadataDb = opt[String](required = true, name = "metadataDb", argName = "metadataDb",
      descr = "Specifies the oadw source related to this export. It should contain MD_OADW_INSTANCE metadata for the run.")

    val truncateBeforeLoad = opt[Boolean](required = false, name = "truncateBeforeLoad", argName = "truncateBeforeLoad",
      descr = "If specified, truncates the tables before writing, even when in Append mode.", default = Some(true))

    val loadType = opt[String](required = false, name = "loadType", argName = "loadType",
      descr = "Specifies the load type for export. Valid values - oadw, ref and prereq")

    val disabledFeatures = opt[String](required = false, name = "disabledFeatures", argName = "disabledFeatures",
      descr = "Flags for disabling features", default = Some(""))

  }

  val executePostDataLoadScript = new Subcommand("executePostDataLoadScript") {

    val tables = opt[String](required = false, name = "tables", argName = "tables",
      descr = "A comma separated list of Hive tables to load in Oracle; ignored when tablesFile if present", default = Some(""))

    val tablesFile = opt[String](required = false, name = "tablesFile", argName = "tablesFile",
      descr = "File containing list of tables(one per line). Give full hdfs path: hdfs://somhorton1/user/user_name/oadw_import.txt",
      default = Some(""))

    val oracleHost = opt[String](required = true, name = "oracleHost", argName = "oracleHost",
      descr = "Oracle host name")

    val oracleService = opt[String](required = true, name = "oracleService", argName = "oracleService",
      descr = "Oracle service/SID")

    val oracleUser = opt[String](required = false, name = "oracleUser", argName = "oracleUser",
      descr = "Oracle user name")

    val oraclePassword = opt[String](required = true, name = "oraclePassword", argName = "oraclePassword",
      descr = "Oracle password")

    val executionThreadCount = opt[Int](required = false, name = "executionThreadCount", argName = "executionThreadCount",
      descr = "Number of tables to load in parallel. Set to 16 if not specified.", default = Some(16))

    val hiveDb = opt[String](required = false, name = "hiveDb", argName = "hiveDb",
      descr = "Hive database sourcing the data")

    val loadType = opt[String](required = true, name = "loadType", argName = "loadType",
      descr = "Specifies the CDR load type for export. Valid values - cdr_be, ecdr")
  }

  val executeScript = new Subcommand("executeScript") {

    val oracleHost = opt[String](required = true, name = "oracleHost", argName = "oracleHost",
      descr = "Oracle host name")

    val oracleService = opt[String](required = true, name = "oracleService", argName = "oracleService",
      descr = "Oracle service/SID")

    val oracleUser = opt[String](required = false, name = "oracleUser", argName = "oracleUser",
      descr = "Oracle user name")

    val oraclePassword = opt[String](required = true, name = "oraclePassword", argName = "oraclePassword",
      descr = "Oracle password")

    val script = opt[String](required = true, name = "script", argName = "script",
      descr =
        "Specifies the SQL script name that contains a list of SQL commands that need to be executed.")

    val delimiter = opt[String](required = false, name = "delimiter", argName = "delimiter",
      descr =
        "Specifies the SQL script that contains a list of SQL commands that need to be executed."
      , default = Some(";"))

    val hiveDb = opt[String](required = false, name = "hiveDb", argName = "hiveDb",
      descr = "Hive database sourcing the data")
  }

  val deploySynonyms = new Subcommand("deploySynonyms") {

    val sourceSchemaName = opt[String](required = false, name = "sourceSchemaName", argName = "sourceSchemaName",
      descr = "Source schema name")

    val oracleHost = opt[String](required = true, name = "oracleHost", argName = "oracleHost",
      descr = "Oracle host name")

    val oracleService = opt[String](required = true, name = "oracleService", argName = "oracleService",
      descr = "Oracle service/SID")

    val targetSchemaName = opt[String](required = false, name = "targetSchemaName", argName = "targetSchemaName",
      descr = "Target schema name")

    val oraclePassword = opt[String](required = true, name = "oraclePassword", argName = "oraclePassword",
      descr = "Oracle password")

    val script = opt[String](required = true, name = "script", argName = "script",
      descr =
        "Specifies the SQL script name that contains the schema to be deployed.")

    val delimiter = opt[String](required = false, name = "delimiter", argName = "delimiter",
      descr =
        "Specifies the SQL script that contains a list of SQL commands that need to be executed."
      , default = Some("/"))

    val hiveDb = opt[String](required = false, name = "hiveDb", argName = "hiveDb",
      descr = "Hive database sourcing the data")

    val clientId = opt[String](required = true, name = "clientId", argName = "clientId", descr = "Client Id")

    val env = opt[String](required = true, name = "env", argName = "env", descr = "Environment")
  }

  val validateCounts = new Subcommand("validateCounts") {
    val hiveDb = opt[String](required = true, name = "hiveDb", argName = "hiveDb",
      descr = "Hive database sourcing the tables")

    val oracleHost = opt[String](required = true, name = "oracleHost", argName = "oracleHost",
      descr = "Oracle host name")

    val oracleService = opt[String](required = true, name = "oracleService", argName = "oracleService",
      descr = "Oracle service/SID")

    val oracleUser = opt[String](required = false, name = "oracleUser", argName = "oracleUser",
      descr = "Oracle user name")

    val oraclePassword = opt[String](required = true, name = "oraclePassword", argName = "oraclePassword",
      descr = "Oracle password")

    val oadwBuildType = opt[String](required = false, name = "oadwBuildType", argName = "oadwBuildType",
      descr = "OADW build profile. Choose from - EPSILON | DEFAULT. Defaults to DEFAULT", default = Some("DEFAULT"))
  }

  val clientLevelAudit = new Subcommand("clientLevelAudit") {
    val hiveDb = opt[String](required = true, name = "hiveDb", argName = "hiveDb",
      descr = "Hive database sourcing the tables")

    val oracleHost = opt[String](required = true, name = "oracleHost", argName = "oracleHost",
      descr = "Oracle host name")

    val oracleService = opt[String](required = true, name = "oracleService", argName = "oracleService",
      descr = "Oracle service/SID")

    val oraclePassword = opt[String](required = true, name = "oraclePassword", argName = "oraclePassword",
      descr = "Oracle password")
    val skipOracleAuditUpdate = opt[Boolean](required = false, name = "skipOracleAuditUpdate", descr = "Set this flag if oracle info needs to be skipped when updating the audit table.", default = Some(false))
  }

  addSubcommand(hqlToOracleSql)
  addSubcommand(createOracleSchema)
  addSubcommand(dropOracleSchema)
  addSubcommand(hiveToOracleDataLoad)
  addSubcommand(executePostDataLoadScript)
  addSubcommand(executeScript)
  addSubcommand(deploySynonyms)
  addSubcommand(validateCounts)
  addSubcommand(clientLevelAudit)
  verify()
}
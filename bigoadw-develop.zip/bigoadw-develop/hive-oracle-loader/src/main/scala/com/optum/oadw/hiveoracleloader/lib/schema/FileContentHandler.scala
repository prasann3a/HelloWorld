package com.optum.oadw.hiveoracleloader.lib.schema

import better.files.{File => ScalaFile}
import com.optum.oadw.hiveoracleloader.lib.common.{Constants, OadwBuildConfig}
import org.slf4j.LoggerFactory

import scala.annotation.tailrec
import scala.collection.mutable

object FileContentHandler {
  private val logger = LoggerFactory.getLogger(this.getClass)
  val oadwContractTableOrViewPattern = "^(((t_)?l[\\d]_)|((t_)?md_)).*".r

  def apply(outputFilePath: String, outputFileName: String, errorFileName: String, appendToOutput: Boolean,
            tableListFileName: String, createTableListOnly: Boolean, oadwBuildConfig: OadwBuildConfig,
            synonymSchemaFileName: String, createSynonymSchema: Boolean): FileContentHandler =
    new FileContentHandler(outputFilePath, outputFileName, errorFileName, appendToOutput, tableListFileName,
      createTableListOnly, oadwBuildConfig, synonymSchemaFileName, createSynonymSchema)
}

class FileContentHandler(outputFilePath: String, outputFileName: String, errorFileName: String, appendToOutput: Boolean,
                         tableListFileName: String, createTableListOnly: Boolean, oadwBuildConfig: OadwBuildConfig,
                         synonymSchemaFileName: String, createSynonymSchema: Boolean) extends ContentHandler {

  import FileContentHandler._

  private lazy val errorFile: ScalaFile = {
    val f = ScalaFile(s"$outputFilePath/$errorFileName").createFileIfNotExists(createParents = true)

    if(!appendToOutput)
      f.overwrite("")

    f
  }
  private lazy val tableListFile: ScalaFile = {
    val f = ScalaFile(s"$outputFilePath/$tableListFileName").createFileIfNotExists(createParents = true)
    if(!appendToOutput)
      f.overwrite("")

    f
  }
  private lazy val synonymSchemaFile: ScalaFile = {
    val f = ScalaFile(s"$outputFilePath/$synonymSchemaFileName").createFileIfNotExists(createParents = true)

    f
  }
  private lazy val schemaFile: ScalaFile = {
    if (!createTableListOnly) {
      val f = ScalaFile(s"$outputFilePath/$outputFileName").createFileIfNotExists(createParents = true)

      f
    } else {
      ScalaFile(Constants.DEFAULT_OUTPUT_SQL_FILE_NAME)
    }
  }
  private lazy val tempTableListFile: ScalaFile = ScalaFile(s"$outputFilePath/${tableListFileName}_temp")
                                                      .createFileIfNotExists().overwrite("")
  val schemaModel = mutable.Set[String]()
  val schemaContents = mutable.ArrayBuffer[SchemaContent]()

  override def success(content: SchemaContent): Unit = {
    val schemaTemplate = new OracleSchemaTemplate
    val tableOrViewName = content.model
    if(!content.dropStmt.isEmpty) {
      if(!skipTableOrView(content)) {
        schemaContents.append(content)
      }
    } else {
      if (!skipTableOrView(content)) {
        if(!schemaModel.contains(content.model))
          tempTableListFile.append(s"""${content.model}\n""")
        schemaModel.add(content.model)
        schemaContents.append(content)
      } else {
        logger.warn(s"Skipping table or view: ${content.model}")
      }
    }
  }

  private def skipTableOrView(content: SchemaContent): Boolean = {
    val tableOrViewName = content.model.toLowerCase()

    if (oadwBuildConfig.includeTables.nonEmpty && !oadwBuildConfig.includeTables.contains(tableOrViewName.toLowerCase)) true // if there was a filter tables set and this was not part of it, then do not include
    else if (oadwBuildConfig.includeTables.nonEmpty && oadwBuildConfig.includeTables.contains(tableOrViewName.toLowerCase)) false // if using --tablesFilterFile, look no further if the table is found in it
    else if (oadwBuildConfig.excludeExceptions.contains(tableOrViewName.toLowerCase())) false // Tables has to be included if it is on this list
    else if (oadwBuildConfig.excludeTables.contains(tableOrViewName.toLowerCase())) true // Skip a table if defined in Config.skipTableList
    else if (oadwBuildConfig.excludePatterns.excludeTablePattern.isDefined &&
      oadwBuildConfig.excludePatterns.excludeTablePattern.get.findFirstMatchIn(tableOrViewName.toLowerCase).isDefined) true // skip if the table matches the skip pattern
    // this section will ensure that all the views dependent on skipped L1 tables do not get created
    else if (oadwBuildConfig.excludePatterns.fromSkipPattern.isDefined &&
        oadwBuildConfig.excludePatterns.fromSkipPattern.get.findFirstMatchIn(content.createStmt.toLowerCase).isDefined) true // Skip the view if it is using any of the L1 views in the SELECT statement
    else if (oadwBuildConfig.excludePatterns.joinSkipPattern.isDefined &&
        oadwBuildConfig.excludePatterns.joinSkipPattern.get.findFirstMatchIn(content.createStmt.toLowerCase).isDefined) true // Skip the view if it is using any of the L1 views in the SELECT statement
    else if (!FileContentHandler.oadwContractTableOrViewPattern.pattern.matcher(tableOrViewName).matches) true // filter out all non Ln_*, MD_* tables
    else false
  }

  def appendToSynonymSchemaFile(content: String): Unit = {
    if(createSynonymSchema)
      synonymSchemaFile.append(content)
  }

  override def failed(content: SchemaContent): Unit = {
   errorFile
      .createIfNotExists()
      .append(content.createStmt + "\n\n")
  }

 def error(errorString: String): Unit = {
    errorFile
      .createIfNotExists()
      .append(errorString + "\n\n")
  }

  override def flush: Unit = {

    @tailrec
    def process(data: List[SchemaContent]): Unit = {
      data match {
        case x::xs =>
          if(!x.dropStmt.isEmpty && x.createStmt.isEmpty) {
            writeDropSchema(x)
          } else {
            writeContent(x)
          }
          process(xs)
        case Nil =>
      }
    }

    process(schemaContents.toList)


   def writeDropSchema(schemaContent: SchemaContent): Unit = {
     val finalStmt = schemaContent.dropStmt

     if(!createTableListOnly)
     schemaFile
       .createIfNotExists()
       .append(finalStmt)
   }


   def writeContent(schemaContent: SchemaContent): Unit = {

    val finalStmt = schemaContent.createStmt

     if(!createTableListOnly)
      schemaFile
        .createIfNotExists()
        .append(finalStmt)
    }

  }

  def appendToSchemaFile(content: String): Unit = {
    if(!createTableListOnly)
      schemaFile
        .createIfNotExists()
        .append(content)
  }

  def appendToSchemaAndTableListFile(content: String): Unit = {
    if(!createTableListOnly)
      schemaFile
        .createIfNotExists()
        .append(content)

    tableListFile
      .append(content)
  }

  def cleanupErrorFile(): Unit ={
    val lines = errorFile.lines.toList
    if(lines.isEmpty)
      errorFile.delete()
  }

  def writeTableListFile(): Unit = {
    val lines = tempTableListFile.lines.toList.sortWith(_ < _)
    tableListFile.append(lines.mkString("\n"))
    tableListFile.append("\n")
    tempTableListFile.delete()
  }
}
package com.optum.oadw.hiveoracleloader.lib.utils

import com.optum.oadw.oadwModels.md_oadw_instance
import org.apache.spark.sql.{Dataset, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._

object OADWMetaDataUtils {
  private val logger = LoggerFactory.getLogger(this.getClass)

  object META_DATA_CONSTANTS {
    val DATA_THRU = "DATA_THRU"
    val IS_MONTHLY_FLG = "IS_MONTHLY_FLG"
    val SRC_SCHEMA = "SRC_SCHEMA"
    val CONTENT_VERSION = "CONTENT_VERSION"
    val SETUP_DTM = "SETUP_DTM"
    val II_DATE_STAMP = "II_DATE_STAMP"
    val II_PROCESS_ID = "II_PROCESS_ID"
    val CLIENT_ID = "CLIENT_ID"
    val ENVIRONMENT = "ENVIRONMENT"
    val INSTANCE = "INSTANCE"
    val ORACLE_SCHEMA_NAME = "ORACLE_SCHEMA_NAME"
    val REF_SCHEMA = "REF_SCHEMA"
  }

  def updateMetaDataModel(sparkSession: SparkSession, attr: MetaDataAttribute, hiveDb: String): Unit = {
    import sparkSession.implicits._

    val metaTable = s"$hiveDb.md_oadw_instance"

    try {
      val tMDOadwInstanceDf = sparkSession.table(metaTable).as[md_oadw_instance]
      val finalMetaDf = getFinalMetaDf(tMDOadwInstanceDf, attr, sparkSession)

      writeMetaDf(finalMetaDf, sparkSession, hiveDb)
    } catch {
      case ex: Exception =>
        logger.error("Error while processing md_oadw_instance")
        throw ex
    }
  }

  def getFinalMetaDf(ds: Dataset[md_oadw_instance], attr: MetaDataAttribute, sparkSession: SparkSession): Dataset[md_oadw_instance] = {
    import sparkSession.implicits._

    try {

      val listData = ds.collect()
      val attribute = md_oadw_instance(attr.name, attr.value)

      val finalData = if (listData.exists(t => t.attribute_name.equalsIgnoreCase(attr.name))) {
        listData.update(listData.indexWhere(t => t.attribute_name.equalsIgnoreCase(attr.name)), attribute)
        listData
      } else {
        listData :+ attribute
      }

      finalData.toSeq.toDF().as[md_oadw_instance]
    } catch {
      case e: Exception =>
        logger.error("Error while creating new dataframe for md_oadw_instance")
        throw e
    }
  }

  private def writeMetaDf(df: Dataset[md_oadw_instance], sparkSession: SparkSession, hiveDb: String): Unit = {
    import sparkSession.implicits._

    try {
      val tableTypeInfo = sparkSession.sql(s"describe formatted $hiveDb.md_oadw_instance").as[HiveDescribe].collect().toList
      val location = tableTypeInfo.find(x => x.col_name.equalsIgnoreCase("Location")).get.data_type

      df.write.mode("overwrite").parquet(location)
    } catch {
      case ex: Exception =>
        logger.error("Error while writing parquet for md_oadw_instance")
        throw ex
    }
  }

  def getAttributesFromMetaTable(sparkSession: SparkSession, hiveDb: String, seqAttrNames: Seq[String]): Map[String, String] = {
    import sparkSession.implicits._

    val metaDf = sparkSession.table(s"$hiveDb.md_oadw_instance").as[md_oadw_instance]
    val metaColl = metaDf.collect()

    seqAttrNames.map(attrName => {
      (attrName, metaColl.find(x => x.attribute_name.equalsIgnoreCase(attrName)).getOrElse(throw new IllegalArgumentException(s"Attribute $attrName is not present in md_oadw_instance")).attribute_value)
    }).toMap
  }
}

case class MetaDataAttribute(name: String , value: String, isGenerated: Boolean, isMonthly: Boolean)
case class HiveDescribe(col_name: String, data_type: String, comment: String)
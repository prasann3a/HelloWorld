package com.optum.oadw.hiveoracleloader

import java.io.FileNotFoundException
import java.util.concurrent.Executors

import com.optum.oap.jdbc.OracleDriver
import com.optum.oap.jdbc.db.JDBCConstants.DDL
import com.optum.oadw.hiveoracleloader.lib.common.{ExecutePostDataLoadScriptConfig, OracleConfig}
import com.optum.oadw.hiveoracleloader.lib.readers.TableFileReader
import com.optum.oadw.hiveoracleloader.lib.utils.SqlScriptProcessor
import org.slf4j.LoggerFactory

import scala.collection.mutable
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, ExecutionContext, ExecutionContextExecutorService, Future}
import scala.util.{Failure, Try}

class PostDataLoadService(conf: ExecutePostDataLoadScriptConfig) {
  val logger = LoggerFactory.getLogger(this.getClass)
  val executionErrors = new mutable.ArrayBuffer[String]

  def processPostDataLoadScript(file: String) = {
    val nThreads = conf.executionThreadCount
    implicit val executionContext: ExecutionContextExecutorService = ExecutionContext.fromExecutorService(Executors.newFixedThreadPool(nThreads))

    val resourcePostLoadScript = s"/oracle-schema/${file}"
    val postDataLoadStream = this.getClass.getResourceAsStream(resourcePostLoadScript)

    Try {
      SqlScriptProcessor.initialize(postDataLoadStream)
    } match {
      case Failure(ex) => {
        logger.error(s"Problem reading $resourcePostLoadScript : ${ex.getMessage}")
        throw new FileNotFoundException(s"Problem reading $resourcePostLoadScript : ${ex.getMessage}")
      }
      case _ => logger.warn(s"Successfully created post processing SQL statements map.")
    }

    val cliTablesOption = conf.tables
    val cliTablesFileOption = conf.tablesFile
    val tables: Future[Set[String]] = if (!cliTablesFileOption.isEmpty) {
      logger.warn(s"Loading tables list from $cliTablesFileOption...")
      TableFileReader.getTablesFuture(cliTablesFileOption)
    } else if (!cliTablesOption.isEmpty) {
      logger.warn("Loading cli-specified tables.")
      Future {
        cliTablesOption.split(",").toSet
      }(executionContext)
    } else {
      logger.warn(s"Neither --tables nor --tablesFile option specified. Executing everything in $resourcePostLoadScript")
      Future {
        SqlScriptProcessor.getTableListFromMap
      }
    }
    Await.result(tables, Duration.Inf)

    val oracleConfig = OracleConfig(
      oracleUserName = conf.oracleUser,
      oraclePassword = conf.oraclePassword,
      oracleHost = conf.oracleHost,
      oracleService = conf.oracleService)
    logger.warn(s"Target Oracle user is: ${oracleConfig.oracleUserName}")

    val result = tables.flatMap(tables => Future.traverse(tables) {
      tableOrIndexName =>
        Future {
          logger.warn(s"Executing post data load scripts for table or index: $tableOrIndexName...")
          val query = SqlScriptProcessor.getPostProcessScriptForTable(tableOrIndexName)
          Try {
            if (query.isDefined) {
              executeQuery(query.get, oracleConfig)
            }
          } match {
            case Failure(ex) => {
              val errorString = s"""Error processing post data load script for : $tableOrIndexName
                                   |Script: $query
                                   |Exception: ${ex.getMessage}""".stripMargin
                executionErrors.append(errorString)
              logger.error(s"Error executing script for table or index: $tableOrIndexName")
            }
            case _ => logger.warn(s"Completed post processing for: $tableOrIndexName")
          }
        }(executionContext)
    })
    Await.result(result, Duration.Inf)

    executionContext.shutdown

    if (executionErrors.nonEmpty) {
      logger.warn("Encountered below errors while executing the post data load script:")
      logger.warn(executionErrors.mkString("\n\n"))
      throw new Exception("Errors found while exporting data. Check the error log for details.")
    }
  }

  private def executeQuery(query: String, oracleConfig: OracleConfig): Unit = {

    val oracleJdbcAdapter = new OracleDriver(host = oracleConfig.oracleHost, database = oracleConfig.oracleService,
      userName = oracleConfig.oracleUserName, password = oracleConfig.oraclePassword)
    Class.forName(oracleJdbcAdapter.DRIVER_NAME)

    val connection = oracleJdbcAdapter.getConnection
    oracleJdbcAdapter.executeSql(connection = connection, query = query, queryType = DDL)
    connection.close()
  }
}

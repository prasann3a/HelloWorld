package com.optum.oadw.hiveoracleloader

import com.optum.oap.jdbc.OracleDriver
import com.optum.oadw.hiveoracleloader.lib.common.{OracleConfig, SqlExecutionConfig}
import com.optum.oadw.hiveoracleloader.lib.utils.SqlScriptProcessor
import org.slf4j.LoggerFactory

object SqlExecutionService {
  val logger = LoggerFactory.getLogger(this.getClass)

  def executeSqlScript(conf: SqlExecutionConfig): Unit = {

    val delimiter = conf.delimiter

    val oracleConfig = OracleConfig(
      oracleUserName = conf.oracleUser,
      oraclePassword = conf.oraclePassword,
      oracleHost = conf.oracleHost,
      oracleService = conf.oracleService)

    logger.warn(s"Target Oracle user is: ${oracleConfig.oracleUserName}")

    val oracleJdbcAdapter = new OracleDriver(host = oracleConfig.oracleHost, database = oracleConfig.oracleService,
      userName = oracleConfig.oracleUserName, password = oracleConfig.oraclePassword)
    Class.forName(oracleJdbcAdapter.DRIVER_NAME)

    val connection = oracleJdbcAdapter.getConnection

    val scriptNames = conf.script.split(",").map(_.trim)
    for (scriptName <- scriptNames) {

      logger.warn(s"scriptName is: ${scriptName}")
      val script = SqlScriptProcessor.getSql(scriptName, conf.replaceMap)
      logger.warn(s"script is: ${script}")

      try {
        logger.warn(s"Executing $scriptName...")
        oracleJdbcAdapter.executeScript(script, connection, delimiter, true)
      } catch {
        case e: Exception =>
          logger.error(s"Error executing - \n$script")
          throw e
      }
      logger.warn(s"Script $scriptName executed successfully.")
    }
  }
}
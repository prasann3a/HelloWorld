package com.optum.oadw.hiveoracleloader.lib.schema.visitor

import net.sf.jsqlparser.statement._
import net.sf.jsqlparser.statement.alter.Alter
import net.sf.jsqlparser.statement.comment.Comment
import net.sf.jsqlparser.statement.create.index.CreateIndex
import net.sf.jsqlparser.statement.create.table.CreateTable
import net.sf.jsqlparser.statement.create.view.{AlterView, CreateView}
import net.sf.jsqlparser.statement.delete.Delete
import net.sf.jsqlparser.statement.drop.Drop
import net.sf.jsqlparser.statement.execute.Execute
import net.sf.jsqlparser.statement.insert.Insert
import net.sf.jsqlparser.statement.merge.Merge
import net.sf.jsqlparser.statement.replace.Replace
import net.sf.jsqlparser.statement.select.Select
import net.sf.jsqlparser.statement.truncate.Truncate
import net.sf.jsqlparser.statement.update.Update
import net.sf.jsqlparser.statement.upsert.Upsert
import net.sf.jsqlparser.statement.values.ValuesStatement

import scala.collection.JavaConverters._

trait OracleStatementVisitor extends StatementVisitor {
  this: HiveToOracleAdapter =>

  def visit(var1: Commit): Unit = {}

  def visit(var1: Delete): Unit = {}

  def visit(var1: Update): Unit = {}

  def visit(var1: Insert): Unit = {}

  def visit(var1: Replace): Unit = {}

  def visit(var1: Drop): Unit = {}

  def visit(var1: Truncate): Unit = {}

  def visit(var1: CreateIndex): Unit = {}

  def visit(var1: CreateTable): Unit = {}

  def visit(var1: CreateView): Unit= {}

  def visit(var1: AlterView): Unit = {}

  def visit(var1: Alter): Unit = {}

  def visit(var1: Statements): Unit = {}

  def visit(var1: Execute): Unit = {}

  def visit(var1: SetStatement): Unit = {}

  def visit(var1: Merge): Unit = {}

  def visit(var1: Select): Unit = {
    if (var1.getWithItemsList != null) {
      var1.getWithItemsList.asScala.foreach(_.accept(this))
    }

    var1.getSelectBody.accept(this)
  }

  def visit(var1: Upsert): Unit = {}

  def visit(var1: UseStatement): Unit = {}

  def visit(aThis:ExplainStatement): Unit = {}

  def visit(describe:DescribeStatement): Unit = {}

  def visit(values:ValuesStatement): Unit = {}

  def visit(block:Block): Unit = {}

  def visit(set:ShowStatement): Unit = {}

  def visit(comment:Comment): Unit = {}
}

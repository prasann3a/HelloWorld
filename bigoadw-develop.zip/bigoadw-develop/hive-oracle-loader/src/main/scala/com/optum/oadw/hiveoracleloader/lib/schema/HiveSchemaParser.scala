package com.optum.oadw.hiveoracleloader.lib.schema

import better.files.{File => ScalaFile}
import com.optum.oadw.hiveoracleloader.lib.common.Constants.{OADW_REF_SCHEMA, OADW_SCHEMA, SchemaType}
import com.optum.oadw.hiveoracleloader.lib.common.{ConfigLists, Constants}
import net.sf.jsqlparser.JSQLParserException
import net.sf.jsqlparser.parser.CCJSqlParserUtil
import net.sf.jsqlparser.statement.create.table.CreateTable
import net.sf.jsqlparser.statement.create.view.CreateView
import net.sf.jsqlparser.statement.drop.Drop
import net.sf.jsqlparser.util.TablesNamesFinder
import org.slf4j.LoggerFactory

import scala.annotation.tailrec
import scala.util.matching.Regex

object HiveSchemaParser {

  private val logger = LoggerFactory.getLogger(this.getClass)
  private val oracleKeyWord: Set[String] = Set("INTERVAL", "interval", "EXCLUDE", "exclude", "offset", "OFFSET",
    "keep", "KEEP", "cluster", "CLUSTER", "priority", "PRIORITY", "GROUPING", "grouping")
  private val skipPattern = Seq("^--".r, "^ADD CONSTRAINT".r, "^drop table".r, "^ALTER".r, "^DEFINE".r, "^call".r, "^CREATE SYNONYM".r, "^SET ANSI_NULLS".r, "^SET QUOTED_IDENTIFIER".r,
    "^CREATE FUNCTION".r, "^DECLARE".r, "^SET".r, "^RETURNS VARCHAR".r, "^BEGIN".r, "^SET ANSI_PADDING".r, "^CREATE DATABASE".r, "^DROP DATABASE".r)
  private val dropPattern = """^DROP (TABLE|VIEW)\s+(\w+)[\s+a-zA-Z\s+&_]*..(\w+).*""".r
  private val subStringPattern = Seq("SEGMENT CREATION DEFERRED".r, "PARTITION BY RANGE".r, "PARTITION BY LIST".r, "PARTITION BY HASH".r, "organization external".r)
  private val maskContentPattern = Seq(MaskContent("--".r), MaskContent("STORED AS".r), MaskContent("""\s*LOCATION\s+'hdfs:""".r),
    MaskContent("RETURN".r), MaskContent("EXTERNAL ".r, "removePattern"), MaskContent("IF [NOT ]*EXISTS ".r, "removePattern"),
    MaskContent("\\{\\{(\\w+)\\}\\}".r, "replacePattern", "hivedb"), MaskContent("[;]+".r, "replacePattern", ";"),
    MaskContent("row_number\\(\\) over \\(order by current_date\\(\\)\\)".r, "replacePattern", "ROWNUM"),
    MaskContent(" BINARY".r, "replacePattern", " RAW"),
    MaskContent("DAY\\(".r, "replacePattern", "EXTRACT\\(DAY FROM"),
    MaskContent("MONTH\\(".r, "replacePattern", "EXTRACT\\(MONTH FROM"),
    MaskContent("YEAR\\(".r, "replacePattern", "EXTRACT\\(YEAR FROM"),
    MaskContent("(?i)DATE_FORMAT\\(".r, "replacePattern", "TO_CHAR\\("),
    MaskContent("(?i)'MMMMM([\\s']+)".r, "replacePattern", "'Month$1"),
    MaskContent("(?i)'MMM([\\s']+)".r, "replacePattern", "'Mon$1"),
    MaskContent("(FROM\\s+.*\\s+)JOIN(\\s+\\w*\\.*\\w+\\s+\\w+\\s+WHERE)".r, "replacePattern", ","))
  private val asWithRegex = """CREATE VIEW\s+.*\.(\w+)\s+AS WITH\s+.*"""
  private val initialOutputContent =
    """DECLARE
      |    PROCEDURE DROP_IF_EXISTS (objectName IN VARCHAR2, objectType IN VARCHAR2 )
      |    IS
      |    v_counter number:=0;
      |    BEGIN
      |
      |        IF (objectType = 'TABLE') THEN
      |        select count(*) into v_counter from user_tables where table_name = upper(objectName);
      |        if v_counter > 0 then
      |            execute immediate 'DROP ' || objectType || ' ' || objectName || ' CASCADE CONSTRAINTS PURGE';
      |        end if;
      |        END IF;
      |
      |        IF (objectType = 'VIEW') THEN
      |        select count(*) into v_counter from user_views where view_name = upper(objectName);
      |        if v_counter > 0 then
      |            execute immediate 'DROP ' || objectType || ' ' || objectName;
      |        end if;
      |        END IF;
      |
      |        commit;
      |
      |    END;
      |BEGIN
      |""".stripMargin

  private val finalOutputContent =
    """END;
      |/
      |
      |""".stripMargin

  private val finalOutputContentWithNull =
    """  NULL;
      |END;
      |/
      |
      |""".stripMargin

  def apply(contentHandler: FileContentHandler, targetSchema: String, sourceSchemaType: SchemaType, sourceDB: String): HiveSchemaParser = new HiveSchemaParser(contentHandler, targetSchema, sourceSchemaType: SchemaType, sourceDB: String)

}

class HiveSchemaParser(contentHandler: FileContentHandler, targetSchema: String, sourceSchemaType: SchemaType, sourceDB: String) {

  import HiveSchemaParser._

  private val tableFinder = new TablesNamesFinder

  private val schemaTemplate = new OracleSchemaTemplate
  schemaTemplate.initialize(tablePropertiesFile = Constants.TABLE_NAMES_MAP)

  def parse(file: ScalaFile): Unit = {
    contentHandler.appendToSchemaFile(initialOutputContent)
    traverse(file.lines.toList)
    if (contentHandler.schemaModel.size > 0) {
      contentHandler.flush
      contentHandler.appendToSchemaFile(finalOutputContent)
    } else {
      contentHandler.appendToSchemaFile(finalOutputContentWithNull)
    }
  }


  @tailrec
  private def traverse(data: Traversable[String]): Unit = {
    data match {
      case x :: xs if filterContent(x) => traverse(xs)
      case x :: xs if dropPattern.findFirstMatchIn(x).isDefined =>
        val content = maskContent(x.trim)
        execute(content.mkString(""))
        traverse(xs)
      case x :: xs =>
        val header = maskContent(x.trim)
        if (!x.trim.endsWith(";")) {
          val index = xs.indexWhere(_.trim.endsWith(";")) + 1
          val (head, tail) = xs.splitAt(index)
          val footer = head.map(maskContent)
          val content = Seq(header) ++ footer
          execute(content.mkString(" "))
          traverse(tail)
        } else {
          val content = maskContent(x.trim)
          execute(content.mkString(""))
          traverse(xs)
        }
      case Nil =>
    }
  }

  private def filterContent(stmt: String): Boolean = {
    if (stmt.trim.isEmpty || skipPattern.exists(_.findFirstMatchIn(stmt.trim).isDefined))
      true
    else false
  }

  private def execute(traversedLine: String): Unit = {
    val line = subStringPattern.foldLeft(traversedLine)((stmt, pattern) => {
      val matchFound = pattern.findFirstMatchIn(stmt)
      if (matchFound.isDefined) {
        stmt.substring(0, matchFound.get.start).trim
      } else {
        stmt
      }
    })

    try {
      val parsedLine = CCJSqlParserUtil.parse(line)
      parsedLine match {
        case create: CreateTable =>
          val stmt = schemaTemplate.getCreateStatement(create, targetSchema, sourceDB)
          val tableName = create.getTable.getName.toLowerCase
          if (skipTableOrView(tableName)) {
            logger.debug(s"Skipping CreateTable => ${stmt.model}")
          } else {
            contentHandler.success(stmt)
            logger.debug(s"Matched CreateTable => ${stmt.model}")
          }

        case createView: CreateView =>
          if (line.matches(asWithRegex))
            handlePatternCreateViewAsWith(line)
          else {
            val stmt = schemaTemplate.getCreateViewStatement(createView, targetSchema, sourceDB)
            //Skip the views if the tables are present in the skip list
            val selectBody = createView.getSelect.getSelectBody
            val selectStmt = CCJSqlParserUtil.parse(selectBody.toString)
            val tables = tableFinder.getTableList(selectStmt)
            val skipView = tables.toArray.foldLeft(false) { (skip, table) =>
              if (!skip)
                skipTableOrView(table.toString.split("\\.")(1))
              else
                skip
            }

            if (!skipView) {
              contentHandler.success(stmt)
              logger.debug(s"Matched Create View => ${stmt.model}")
            } else
              logger.debug(s"Skipping Create View => ${stmt.model}")
          }

        case drop: Drop =>
          val stmt = schemaTemplate.getDropStatement(drop, targetSchema)
          //contentHandler.success(stmt)
          logger.debug(s"Matched Drop ==> ${stmt.model}, not converting to SQL")
        case _ =>
          val errorStr = s"The below statement cannot be handled ==> \n$line"
          contentHandler.error(errorStr)
          logger.debug(errorStr)
      }
    } catch {
      case jsqlEx: JSQLParserException =>
        if (line.matches(asWithRegex))
          handlePatternCreateViewAsWith(line)
        else {
          val errStr = s"Failed to parse the following line ====>\n $line"
          contentHandler.error(errStr)
          logger.error(errStr)
          jsqlEx.printStackTrace()
        }
    }
  }

  private def handlePatternCreateViewAsWith(line: String): Unit = {
    var viewName = ""
    val matched = asWithRegex.r.findFirstMatchIn(line)
    matched match {
      case Some(m) =>
        viewName = m.group(1)
        val stmt = schemaTemplate.processCreateViewContainsWith(viewName, line, targetSchema)
        contentHandler.success(stmt)
      case None =>
        val errorString = s"$line does not match the CREATE VIEW AS WITH pattern"
        logger.error(errorString)
        contentHandler.error(errorString)
    }
  }

  private def maskContent(stmt: String): String = {
    val content = stmt.trim.replaceAll("\\$", "").replaceAll("\\`", "")

    val replacedContent = oracleKeyWord
      .filter(key => content.trim.split(",").flatMap(_.trim.split(" ")).contains(key))
      .foldLeft(content)((c, key) => {
        val r = s"$key(\\s+|,)".r
        r.replaceAllIn(c, s"`${key.toUpperCase}`" + "$1")

      })

    val output = maskContentPattern.foldLeft(replacedContent) {
      case (text, MaskContent(pattern, task, replacementString)) =>
        pattern.findFirstMatchIn(text) match {
          case Some(matchFound) if task == "substituteLastCharacter" => text.substring(0, matchFound.start) + text.charAt(text.length - 1)
          case Some(matchFound) if task == "removePattern" => text.substring(0, matchFound.start) + text.substring(matchFound.end, text.length)
          case Some(_) if task == "replacePattern" => pattern.replaceAllIn(text, _ match {
            case pattern(beforeJoin, afterJoin) => f"$beforeJoin$replacementString$afterJoin"
            case _ => replacementString
          })
          case Some(matchFound) if task == "truncateAfter" => text.substring(0, matchFound.end)
          case Some(matchFound) if task == "truncateBefore" => text.substring(0, matchFound.start)
          case Some(matchFound) => text.substring(0, matchFound.start)
          case None => text
        }
    }
    output.trim
  }

  private def skipTableOrView(tableName: String): Boolean = {
    (sourceSchemaType == OADW_REF_SCHEMA && ConfigLists.excludeOadwRefTablesAndViews.contains(tableName.toLowerCase)) ||
      (sourceSchemaType == OADW_SCHEMA && ConfigLists.excludeOadwTablesAndViews.contains(tableName.toLowerCase))
  }
}

case class MaskContent(pattern: Regex, task: String = "", replacementString: String = "")


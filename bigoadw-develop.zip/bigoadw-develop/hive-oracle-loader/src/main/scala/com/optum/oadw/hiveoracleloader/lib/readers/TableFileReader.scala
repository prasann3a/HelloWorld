package com.optum.oadw.hiveoracleloader.lib.readers

import com.optum.oadw.hiveoracleloader.lib.common.Constants
import com.optum.oadw.hiveoracleloader.lib.utils.ResourceHandler
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.slf4j.LoggerFactory

import scala.concurrent.{ExecutionContextExecutorService, Future}

object TableFileReader {

  private val logger = LoggerFactory.getLogger(this.getClass)

  def getTablesFuture(tablesFilePath: String)(implicit executionContext: ExecutionContextExecutorService): Future[Set[String]] = {
    logger.debug(s"Reading table file: $tablesFilePath")

    Future {
      val tablesMap = ResourceHandler.loadPropertiesAndGetReversedMap(Constants.TABLE_NAMES_MAP)
      val path = new Path(tablesFilePath)
      val fs = path.getFileSystem(new Configuration())
      val stream = fs.open(path)
      scala.io.Source.fromInputStream(stream).getLines().filter(x => !x.matches("""\s*--.*""")).map(_.trim).filter(_ != "").map(getTableNameOverride(tablesMap, _)).toSet
    }
  }

  def getTablesFromResource(resourcePath: String)(implicit executionContext: ExecutionContextExecutorService): Future[Set[String]] = {
    logger.debug(s"Reading table file: $resourcePath")

    Future {
      val tablesMap = ResourceHandler.loadPropertiesAndGetReversedMap(Constants.TABLE_NAMES_MAP)
      val iStream = this.getClass.getResourceAsStream(resourcePath)
      scala.io.Source.fromInputStream(iStream).getLines.filter(x => !x.matches("""\s*--.*""")).map(_.trim).filter(_ != "").map(getTableNameOverride(tablesMap, _)).toSet
    }
  }

  private def getTableNameOverride(map: Map[String, String], input: String): String = {
    map.getOrElse(input, input)
  }
}
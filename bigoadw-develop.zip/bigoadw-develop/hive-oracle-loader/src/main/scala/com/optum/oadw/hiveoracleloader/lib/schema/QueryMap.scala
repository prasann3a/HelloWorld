package com.optum.oadw.hiveoracleloader.lib.schema

object QueryMap {

  private val tableMap = Map.empty[String, Query]


  def getTableList(model: String, queryType: String): List[String] = {
    if (tableMap.contains(model.toLowerCase)) {
      val Query(queryTyp, tables) = tableMap(model.toLowerCase)
      if(queryType.equalsIgnoreCase(queryTyp)) {
        tables.split(",").toList
      }
    }
    List.empty
  }
}

case class Query(queryType: String, tableList: String)

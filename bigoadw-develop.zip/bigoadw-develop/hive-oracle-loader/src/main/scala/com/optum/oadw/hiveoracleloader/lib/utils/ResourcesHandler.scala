package com.optum.oadw.hiveoracleloader.lib.utils

import java.util.Properties

import better.files.{Resource => ScalaResource}
import net.sf.jsqlparser.statement.create.table.ColDataType
import org.slf4j.LoggerFactory
import com.optum.oap.utils.Resource.using
import com.optum.oadw.hiveoracleloader.lib.common.{ColumnDataTypeOverride, Constants}
import com.optum.oadw.hiveoracleloader.lib.schema.visitor.HiveToOracleAdapter

import scala.collection.JavaConverters._
import scala.collection.mutable
import scala.io.Source


class ResourceHandler {

  private val logger = LoggerFactory.getLogger(this.getClass)

  def load(propertyFile: String):Properties = {
    val prop = new Properties()

    try {

      prop.load(this.getClass.getResourceAsStream(propertyFile))

    } catch {
      case ex: Exception =>
        val url = getClass.getResource(propertyFile)
        if (url != null) {
          val source = Source.fromURL(propertyFile)

          prop.load(source.bufferedReader())
        }
        logger.error(s"Error loading property file: $propertyFile", ex)
        throw ex
    }
    prop
  }

}


object ResourceHandler {
  def loadPropertyFile(propertyFile: String): Properties = {
    val propertiesLoader = new ResourceHandler
    propertiesLoader.load(propertyFile)
  }

  def loadPropertiesAndGetReversedMap(propertyFile: String): Map[String, String] = {
    val propertiesLoader = new ResourceHandler
    val reverseMap = for((k,v) <- propertiesLoader.load(propertyFile).asScala) yield (v,k)
    reverseMap.toMap
  }

  def loadTableNamesProperties(): Properties = {
    ResourceHandler.loadPropertyFile(Constants.TABLE_NAMES_MAP)
  }

  def loadColumnNamesProperties(): Properties = {
    ResourceHandler.loadPropertyFile(Constants.COLUMN_NAMES_MAP)
  }

  def getOverrideColumnMap(): Seq[ColumnDataTypeOverride] = {
    val columnMap: mutable.Set[ColumnDataTypeOverride] = mutable.Set()
    ScalaResource.getAsString(Constants.COLUMN_OVERRIDE_MAP_FILE).split("\\r?\\n").map( line => {
      val cols = line.split("\\|")
      if(cols.length == 3) {
        columnMap += ColumnDataTypeOverride(cols(0), cols(1), cols(2).replaceAll("'", "''"))
      }
    })
    columnMap.toSeq ++ getIIExternalColumnData
  }

  def getIIExternalColumnData(): Seq[ColumnDataTypeOverride] = {
    val hiveToOracleAdapter = new HiveToOracleAdapter
    val columnMap: mutable.Set[ColumnDataTypeOverride] = mutable.Set()
    using(ScalaResource.getAsStream("ii/" + Constants.II_EXTERNAL_DATATYPE_MAP))(inputStream => {
      Source.fromInputStream(inputStream).getLines().foreach(line => {
        if(!line.contains("tableName")) {
          val cols = line.split("\\|")
          if(cols.length >= 3) {
            val colDataType = new ColDataType
            colDataType.setDataType(cols(2))
            if (cols.length == 4 && cols(3).trim != "") {
              val arguments = cols(3).split(",").map(_.trim).toList.asJava
              colDataType.setArgumentsStringList(arguments)
            }
            else
              colDataType.setArgumentsStringList(null)

            val dataType = hiveToOracleAdapter.hiveToOracleDataType(colDataType).toString
            columnMap += ColumnDataTypeOverride(cols(0), cols(1), dataType)
          }
        }
      })
    })

    columnMap.toSeq
  }

  def getOverrideColumnMapping(tableName: String, tableColumnMapping: Seq[ColumnDataTypeOverride]): Map[String, String] = {
    tableColumnMapping.filter(_.tableName.equalsIgnoreCase(tableName)).map(x => x.columnName.toUpperCase -> x.dataType).toMap
  }

}

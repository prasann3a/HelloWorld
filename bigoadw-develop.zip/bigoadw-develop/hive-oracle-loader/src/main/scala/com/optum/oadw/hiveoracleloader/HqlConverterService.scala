package com.optum.oadw.hiveoracleloader

import java.io.File

import better.files.{File => ScalaFile, Resource => ScalaResource}
import com.optum.oadw.hiveoracleloader.lib.common.Constants.{OADW_REF_SCHEMA, OADW_SCHEMA, OTHER_SCHEMA, SchemaType}
import com.optum.oadw.hiveoracleloader.lib.common.{Constants, CustomMaps, DefaultBuild, EpsilonBuild, HqlToOracleSqlConfig, OadwBuildConfig, OpaBuild, OpaDmBuild}
import com.optum.oadw.hiveoracleloader.lib.schema.{FileContentHandler, HiveSchemaParser}
import org.slf4j.LoggerFactory

import scala.io.Source

object HqlConverterService {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def convertHqlToOracleSql(conf: HqlToOracleSqlConfig): Unit = {

    val hqlFileList = conf.inputHqlFiles.split(",")
    val outputFile = conf.outputSqlFileName
    val errorFile = conf.errorFileName
    val outputFilePath = conf.outputFilePath
    var appendToOutput = conf.appendToOutput
    val tableListFileName = conf.tableListFile
    val createTableListOnly = conf.createTableListOnly
    val synonymsFile = conf.synonymSchemaFile
    val createSynonymSchema = conf.createSynonymSchema

    val filterSet = getFilterSet(conf.oadwBuildType, conf.tableFilterFile)

    val oadwBuildConfig: OadwBuildConfig = conf.oadwBuildType.toUpperCase match {
      case "OPA" => OpaBuild(filterSet)
      case "OPADM" => OpaDmBuild(filterSet)
      case "EPSILON" => EpsilonBuild(filterSet)
      case "DEFAULT" => DefaultBuild(filterSet)
    }

    hqlFileList.foreach(fileName => {
      logger.warn("Converting: " + fileName)
      val contentHandler = FileContentHandler(outputFilePath, outputFile, errorFile, appendToOutput, tableListFileName, createTableListOnly, oadwBuildConfig, synonymsFile, createSynonymSchema)
      val fileNm = new File(fileName).getName
      contentHandler.appendToSchemaAndTableListFile(s"-- Auto-generated content from $fileNm\n")

      val sourceDB = CustomMaps.fileDbMap.getOrElse(fileNm, "unknown source")
      val hiveSchemaParser = HiveSchemaParser(contentHandler, "", getSchemaTypeFromFileName(fileNm), sourceDB)

      val hqlFile: ScalaFile = ScalaFile(fileName.trim)
      hiveSchemaParser.parse(hqlFile)
      contentHandler.writeTableListFile()
      contentHandler.cleanupErrorFile()
      appendToOutput = true
    })

    if (createSynonymSchema) appendUpdateCurrentSchemaFile(outputFilePath, synonymsFile)

  }

  def appendManualSchemaFile(outputFilePath: String, outputFileName: String) = {
    val outputFile = ScalaFile(s"$outputFilePath/$outputFileName").createFileIfNotExists(createParents = true).overwrite("")
    val manualSchema = ScalaResource.getAsString(Constants.ORACLE_MANUAL_SCHEMA_FILE)
    outputFile.append(manualSchema)
  }

  def appendUpdateCurrentSchemaFile(outputFilePath: String, outputFileName: String) = {
    val outputFile = ScalaFile(s"$outputFilePath/$outputFileName").createFileIfNotExists(createParents = true).append("")
    val updateCurrentSchemaFile = ScalaResource.getAsString(Constants.ORACLE_UPDATE_CURRENT_SCHEMA_FILE)
    val updateGrantSynonymsSelectFile = ScalaResource.getAsString(Constants.ORACLE_GRANT_SYNONYMS_SELECT_FILE)
    outputFile.append(updateCurrentSchemaFile)
    outputFile.append(updateGrantSynonymsSelectFile)
  }

  private def getSchemaTypeFromFileName(fileName: String): SchemaType = {
    if (fileName.matches("^oadw_reference_schema.*"))
      OADW_REF_SCHEMA
    else if (fileName.matches("^oadw_schema.*"))
      OADW_SCHEMA
    else
      OTHER_SCHEMA
  }

  private def getFilterSet(oadwBuildType: String, tableFilterFile: String): Set[String] = {
    val filterSet =
      if (oadwBuildType.equalsIgnoreCase("OPA") && tableFilterFile.isEmpty) {
        Set.empty[String]
      } else if (!tableFilterFile.isEmpty) {
        ScalaFile(tableFilterFile).lines.map(_.trim.toLowerCase).filter(_.nonEmpty).toSet
      } else {
        oadwBuildType.toUpperCase match {
          case "OPADM" => ScalaFile(s"hive-oracle-loader/src/main/resources/${Constants.OPADM_FILTER_FILE}").lines.map(_.trim.toLowerCase).filter(_.nonEmpty).toSet
          case "EPSILON" => ScalaFile(s"hive-oracle-loader/src/main/resources/${Constants.EPSILON_FILTER_FILE}").lines.map(_.trim.toLowerCase).filter(_.nonEmpty).toSet
          case _ => Set.empty[String]
        }
      }
    filterSet
  }
}
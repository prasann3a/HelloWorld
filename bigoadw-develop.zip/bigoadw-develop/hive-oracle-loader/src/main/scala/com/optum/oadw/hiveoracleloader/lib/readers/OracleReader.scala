package com.optum.oadw.hiveoracleloader.lib.readers

import com.optum.oap.jdbc.OracleDriver
import com.optum.oadw.hiveoracleloader.lib.common.OracleConfig
import org.apache.spark.sql.{DataFrame, SparkSession}

object OracleReader {

  def getEmptyDf(sparkSession: SparkSession, oracleConfig: OracleConfig, oracleTable: String): DataFrame = {
    val host = oracleConfig.oracleHost
    val service = oracleConfig.oracleService
    val user = oracleConfig.oracleUserName
    val password = oracleConfig.oraclePassword

    val oracleJdbcAdapter = new OracleDriver(host = host, database = service,
      userName = user, password = password)
    Class.forName(oracleJdbcAdapter.DRIVER_NAME)

    val emptySelectQuery = s"(SELECT * FROM $user.${oracleTable.toUpperCase} WHERE 1 = 0)"

    val prop = new java.util.Properties
    prop.setProperty("user", user)
    prop.setProperty("password", password)

    val emptyDf = sparkSession.read
      .format("jdbc")
      .option("url", oracleJdbcAdapter.CONNECTION_URL)
      .option("driver", oracleJdbcAdapter.DRIVER_NAME)
      .option("dbtable", emptySelectQuery)
      .option("user", user)
      .option("password", password)
      .load()

    emptyDf
  }
}
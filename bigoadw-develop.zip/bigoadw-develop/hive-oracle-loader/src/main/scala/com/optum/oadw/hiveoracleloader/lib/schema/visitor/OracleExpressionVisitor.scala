package com.optum.oadw.hiveoracleloader.lib.schema.visitor

import net.sf.jsqlparser.expression._
import net.sf.jsqlparser.expression.operators.arithmetic._
import net.sf.jsqlparser.expression.operators.conditional.{AndExpression, OrExpression}
import net.sf.jsqlparser.expression.operators.relational._
import net.sf.jsqlparser.schema.Column
import net.sf.jsqlparser.statement.select.SubSelect

import scala.collection.JavaConverters._

trait OracleExpressionVisitor extends ExpressionVisitor {
  this: HiveToOracleAdapter =>

  def visit(expr: BitwiseRightShift): Unit = {}

  def visit(expr: BitwiseLeftShift): Unit = {}

  def visit(expr: NullValue): Unit = {}

  def visit(expr: Function): Unit = {

    if (expr.getParameters != null) {
      expr.getParameters.accept(this)
    }

    //this.formatFunctions(expr)
  }

  def visit(expr: SignedExpression): Unit = {}

  def visit(expr: JdbcParameter): Unit = {}

  def visit(expr: JdbcNamedParameter): Unit = {}

  def visit(expr: DoubleValue): Unit = {}

  def visit(expr: LongValue): Unit = {}

  def visit(expr: HexValue): Unit = {}

  def visit(expr: DateValue): Unit = {}

  def visit(expr: TimeValue): Unit = {}

  def visit(expr: TimestampValue): Unit = {}

  def visit(expr: Parenthesis): Unit = {}

  def visit(expr: StringValue): Unit = {}

  def visit(expr: Addition): Unit = {}

  def visit(expr: Division): Unit = {}

  def visit(expr: Multiplication): Unit = {}

  def visit(expr: Subtraction): Unit = {}

  def visit(expr: AndExpression): Unit = {
    this.visitBinaryExpression(expr)
  }

  def visit(expr: OrExpression): Unit = {
    this.visitBinaryExpression(expr)
  }

  def visit(expr: Between): Unit = {}

  def visit(expr: EqualsTo): Unit = {
    val rightExpression = expr.getRightExpression
    if (rightExpression != null && rightExpression.toString.equalsIgnoreCase("'&client_id'")) {
      expr.setLeftExpression(new DoubleValue("1"))
      expr.setRightExpression(new DoubleValue("1"))
    }
    this.visitBinaryExpression(expr)
  }

  def visit(expr: GreaterThan): Unit = {}

  def visit(expr: GreaterThanEquals): Unit = {}

  def visit(expr: InExpression): Unit = {}

  def visit(expr: IsNullExpression): Unit = {}

  def visit(expr: LikeExpression): Unit = {}

  def visit(expr: MinorThan): Unit = {}

  def visit(expr: MinorThanEquals): Unit = {}

  def visit(expr: NotEqualsTo): Unit = {}

  def visit(expr: Column): Unit = {
    this.formatColumn(expr)
  }

  def visit(expr: SubSelect): Unit = {}

  def visit(expr: CaseExpression): Unit = {

    if (expr.getSwitchExpression != null)
      expr.getSwitchExpression.accept(this)

    if (expr.getWhenClauses != null)
      expr.getWhenClauses.asScala.foreach(_.accept(this))

    if (expr.getElseExpression != null)
      expr.getElseExpression.accept(this)
  }

  def visit(expr: WhenClause): Unit = {
    if (expr.getWhenExpression != null)
      expr.getWhenExpression.accept(this)

    if (expr.getThenExpression != null)
      expr.getThenExpression.accept(this)
  }

  def visit(expr: ExistsExpression): Unit = {}

  def visit(expr: AllComparisonExpression): Unit = {}

  def visit(expr: AnyComparisonExpression): Unit = {}

  def visit(expr: Concat): Unit = {
    if (expr.getLeftExpression != null)
      expr.getLeftExpression.accept(this)

    if (expr.getRightExpression != null)
      expr.getRightExpression.accept(this)

  }

  def visit(expr: Matches): Unit = {}

  def visit(expr: BitwiseAnd): Unit = {}

  def visit(expr: BitwiseOr): Unit = {}

  def visit(expr: BitwiseXor): Unit = {}

  def visit(expr: CastExpression): Unit = {
    val colDataType = this.hiveToOracleDataType(expr.getType)
    expr.setType(colDataType)

    if (expr.getLeftExpression != null)
      expr.getLeftExpression.accept(this)
  }

  def visit(expr: Modulo): Unit = {}

  def visit(expr: AnalyticExpression): Unit = {}

  def visit(expr: ExtractExpression): Unit = {
    //this.formatExtract(expr)
  }

  def visit(expr: IntervalExpression): Unit = {}

  def visit(expr: OracleHierarchicalExpression): Unit = {}

  def visit(expr: RegExpMatchOperator): Unit = {}

  def visit(expr: JsonExpression): Unit = {}

  def visit(expr: JsonOperator): Unit = {}

  def visit(expr: RegExpMySQLOperator): Unit = {}

  def visit(expr: UserVariable): Unit = {}

  def visit(expr: NumericBind): Unit = {}

  def visit(expr: KeepExpression): Unit = {}

  def visit(expr: MySQLGroupConcat): Unit = {}

  def visit(expr: ValueListExpression): Unit = {}

  def visit(expr: RowConstructor): Unit = {}

  def visit(expr: OracleHint): Unit = {}

  def visit(expr: TimeKeyExpression): Unit = {}

  def visit(expr: DateTimeLiteralExpression): Unit = {}

  def visit(expr: NotExpression): Unit = {}

  protected def visitBinaryExpression(expr: BinaryExpression): Unit = {
    expr.getLeftExpression.accept(this)
    expr.getRightExpression.accept(this)
  }

  def visit(aThis:NextValExpression): Unit = {}

  def visit(aThis:CollateExpression): Unit = {}
}

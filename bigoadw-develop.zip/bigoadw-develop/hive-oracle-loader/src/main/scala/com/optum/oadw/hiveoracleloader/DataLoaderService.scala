package com.optum.oadw.hiveoracleloader

import java.util.concurrent.Executors

import com.optum.oap.utils.Resource.using
import com.optum.oadw.hiveoracleloader.lib.common.{CustomMaps, DataLoadExceptionLog, HiveToOracleDataLoadConfig, OracleConfig}
import com.optum.oadw.hiveoracleloader.lib.loaders.OracleLoader
import com.optum.oadw.hiveoracleloader.lib.readers.{OracleReader, TableFileReader}
import com.optum.oadw.hiveoracleloader.lib.utils.ResourceHandler
import com.optum.oadw.oadwModels.oadw_stats
import org.apache.spark.sql.{AnalysisException, DataFrame, SparkSession}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types._
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.mutable
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, ExecutionContext, ExecutionContextExecutorService, Future}
import scala.util.{Failure, Success, Try}
import com.optum.oadw.utils.{HiveParquetMapper, OADWSchemaInput}
import com.optum.oadw.utils.DataframeExtensions.TrimDataFrame
import org.apache.commons.lang3.exception.ExceptionUtils

case class HiveColumnDefinition(columns: Array[String], parquetLocation: String)

object DataLoaderService {

  private val logger: Logger = LoggerFactory.getLogger(this.getClass)

  def loadHiveDataIntoOracle(conf: HiveToOracleDataLoadConfig, sparkSession: SparkSession): Unit = {
    logger.warn(s" == Exporting to: ${conf.oracleHost}")
    logger.warn(s" == Service: ${conf.oracleService}")
    logger.warn(s" == Schema: ${conf.oracleUser}")

    val nThreads                                                   = conf.executionThreads
    implicit val executionContext: ExecutionContextExecutorService = ExecutionContext.fromExecutorService(Executors.newFixedThreadPool(nThreads))

    val schemaInput = OADWSchemaInput(
      clientId = conf.clientId,
      environment = conf.environment,
      instance = conf.instance,
      streamId = conf.streamId,
      cdrCycle = conf.cdrCycle,
      cdrLevel = conf.cdrLevel,
      iiDateStamp = conf.iiDateStamp,
      iiProcessId = conf.iiProcessId,
      oadwRefVersion = conf.oadwRefVersion,
      protocol = "hdfs",
      bucket = ""
    )
    val parquetMap = HiveParquetMapper.getTableNameToParquet(schemaInput, session = sparkSession)

    val tables: Future[Set[String]] = if (conf.tables.isDefined) {
      logger.warn(s"Loading cli-specified tables.")
      Future {
        conf.tables.get.split(",").toSet
      }
    } else if (conf.tablesFile.isDefined) {
      logger.warn(s"Loading tables list from ${conf.tablesFile.get}...")

      TableFileReader.getTablesFuture(conf.tablesFile.get)
    } else if (conf.loadType.isDefined) {
      val resourcePath = s"/oracle-schema/${conf.loadType.get.fileName}"
      logger.warn(s"Loading tables list from $resourcePath...")

      TableFileReader.getTablesFromResource(resourcePath)
    } else {
      Future.failed(new IllegalArgumentException("Need either --tables, --tablesFile or --loadType"))
    }

    val oracleConfig = OracleConfig(
      saveMode = conf.saveMode,
      oracleUserName = conf.oracleUser,
      oraclePassword = conf.oraclePassword,
      oracleHost = conf.oracleHost,
      oracleService = conf.oracleService,
      oracleBatchSize = conf.oracleBatchSize
    )

    val tableNamesMap = ResourceHandler.loadTableNamesProperties()

    using(sparkSession)(implicit session => {
      import sparkSession.implicits._

      val dataLoadExceptions = mutable.Set[DataLoadExceptionLog]()
      val tableWithVarcharIssues =  try{
        session.read.parquet(parquetMap("OADW_STATS").parquetLocation).as[oadw_stats].filter(statRow => statRow.data_type == "VARCHAR" && statRow.max_string_length > statRow.length).map(t=> t.table_name.toUpperCase).distinct.as[String].collect()
      } catch {
        case e: Exception => {
          logger.warn(s"OADW_STATS parquet not found during oracle export: ${e.getMessage}")
          Array.empty[String]
        }
      }

      logger.warn(s"Tables with varchar issues: ${tableWithVarcharIssues.mkString(",")}")

      val result = tables.flatMap(tables =>
        Future.traverse(tables) {
          tableName =>
            Future {
              logger.warn(s" === Oracle-Loading table $tableName...")
              Try {
                session.sparkContext.setJobDescription(s"Processing $tableName")
                val parquetLocation = parquetMap(tableName.toUpperCase).parquetLocation
                if (HiveParquetMapper.checkIfPathExistsInHdfs(parquetLocation)) {
                  logger.warn(s"Loading $tableName from parquet location: $parquetLocation")
                  try {
                    val sourceDf = session.read.parquet(parquetLocation).selectExpr(parquetMap(tableName.toUpperCase).columns: _*)
                    if(sourceDf.count() > 0) {
                      // Need to rename the Hive columns based on the ColumnNameMap
                      val columnNameMap = ResourceHandler.loadColumnNamesProperties()
                      val sourceDfWithRenamedColumns = sourceDf.schema.foldLeft(sourceDf) {
                        case (df, col) => df.withColumnRenamed(col.name, columnNameMap.getProperty(col.name.toUpperCase, col.name).toUpperCase)
                      }
                      val oracleTableName = tableNamesMap.getProperty(tableName, tableName)
                      val oracleDf        = OracleReader.getEmptyDf(session, oracleConfig, oracleTableName)
                      // Add missing columns from the target schema
                      val _finalDf = if (CustomMaps.AddColumnsMap.contains(tableName.toUpperCase)) sourceDfWithRenamedColumns else refineHiveDataFrame(sourceDfWithRenamedColumns, oracleDf)

                      // Trim varchar columns for tables for cdr, ref and ii tables, which has max_string_length greater than length.
                      val finalDf = if(!parquetLocation.contains("/oadw/") && (tableWithVarcharIssues.contains(tableName.toUpperCase) || conf.cdrLevel.toLowerCase == "ecdr")) _finalDf.truncateVarcharColumns(oracleTableName) else _finalDf
                      OracleLoader.load(finalDf, oracleConfig, oracleTableName, conf.truncateBeforeLoad)
                    }
                    else {
                      logger.warn(s"Skipping $tableName because rows count in table is 0.")
                    }
                  } catch {
                    case e: AnalysisException => {
                      // There are cases where underlying parquets are missing. In that case, no need to throw error, oracle table will be empty.
                      if(e.message.contains("Unable to infer schema for Parquet")){
                        logger.warn(s"Skipping $tableName because $parquetLocation doesn't have schema defined.")
                      } else {
                        dataLoadExceptions += DataLoadExceptionLog(tableName, e)
                        logger.error(s" -=- Problem Oracle-Loading $tableName : $e : ${e.getMessage}: ${ExceptionUtils.getStackTrace(e)}")
                      }
                    }
                  }
                } else {
                  logger.warn(s"Skipping $tableName because $parquetLocation/_SUCCESS doesn't exist. Either parquets are partially loaded or empty")
                }
              } match {
                case Failure(ex) => {
                  logger.error(s" -=- Problem Oracle-Loading $tableName : $ex : ${ex.getMessage}: ${ex.getStackTrace.toString}")
                  logger.warn(s" -=- Problem Oracle-Loading $tableName : $ex : ${ex.getMessage}: ${ex.getStackTraceString}")
                  dataLoadExceptions += DataLoadExceptionLog(tableName, ex)
                }
                case Success(_) => logger.warn(s" +++ Successfully Oracle-Loaded $tableName")
              }
            }
      })

      Await.result(result, Duration.Inf)
      if (dataLoadExceptions.nonEmpty) {
        val errorSet = mutable.Set[String]()
        dataLoadExceptions.foreach(dataLoadException => {
          errorSet += s"\n|\t${dataLoadException.tableName}\t|\t${dataLoadException.exception.getMessage}\t|"
        })
        val errorReport = errorSet.toSeq.mkString("")
        logger.error(errorReport)
        throw new Exception("Errors found while exporting data. Check the error log for details.")
      }
    })
  }

  private def refineHiveDataFrame(hiveDf: DataFrame, oracleDf: DataFrame): DataFrame = {

    val cleanOracleSchema = getCleanedSchema(oracleDf)
    val cleanHiveSchema   = getCleanedSchema(hiveDf)

    val diff = getSchemaDifference(cleanOracleSchema, cleanHiveSchema)

    val addColumns: List[DataFrameColumn] = diff
      .map {
        case (columnName: String, (operation: String, Some((dataType: String, _: Boolean)))) => {
          if (operation.equalsIgnoreCase("ADD"))
            DataFrameColumn(columnName, dataType)
          else DataFrameColumn("", "")
        }
      }
      .filter(_.!=())
      .toList

    val dropColumns: List[Any] = diff
      .map {
        case (columnName: String, (operation: String, Some((_: String, _: Boolean)))) => {
          if (operation.equalsIgnoreCase("DROP"))
            columnName
        }
      }
      .filter(_.!=())
      .toList

    val hiveDfWithNewCols = addColumns.foldLeft(hiveDf)((df: DataFrame, col: DataFrameColumn) => {
      if (!col.column.isEmpty) {
        df.withColumn(col.column, lit(null).cast(col.dataType))
      } else df
    })

    val hiveDfWithDroppedCols = dropColumns.foldLeft(hiveDfWithNewCols)((df: DataFrame, col: Any) => {
      if (df.schema.fieldNames.map(_.toLowerCase).contains(col.toString.toLowerCase)) {
        df.drop(col.toString)
      } else df
    })

    // Need to cast BooleanType to IntegerType explicitly as implicit casting defaults the nullability property to false.
    val finalDf = hiveDfWithDroppedCols.schema.filter(_.dataType == BooleanType).foldLeft(hiveDfWithDroppedCols) {
      case (origDf, col) => origDf.withColumn(col.name, hiveDfWithDroppedCols(col.name).cast(IntegerType))
    }

    finalDf
  }

  private def getCleanedSchema(df: DataFrame): Map[String, (String, Boolean)] =
    df.schema.map { structField: StructField =>
      structField.name.toLowerCase -> (structField.dataType.typeName, structField.nullable)
    }.toMap

  private def getSchemaDifference(oracleSchema: Map[String, (String, Boolean)], hiveSchema: Map[String, (String, Boolean)]): Map[String, (String, Option[(String, Boolean)])] =
    (oracleSchema.keys ++ hiveSchema.keys)
      .map(_.toLowerCase)
      .toList
      .distinct
      .flatMap { columnName: String =>
        val oracleSchemaFieldOpt: Option[(String, Boolean)] = oracleSchema.get(columnName)
        val hiveSchemaFieldOpt: Option[(String, Boolean)]   = hiveSchema.get(columnName)

        if (oracleSchemaFieldOpt.isDefined && hiveSchemaFieldOpt.isEmpty) {
          Some(columnName, ("ADD", oracleSchemaFieldOpt))
        } else if (oracleSchemaFieldOpt.isEmpty && hiveSchemaFieldOpt.isDefined)
          Some(columnName, ("DROP", hiveSchemaFieldOpt))
        else None

      }
      .toMap
}

case class DataFrameColumn(column: String, dataType: String)

package com.optum.oadw.hiveoracleloader

import java.sql.Connection
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import com.optum.oap.jdbc.OracleDriver
import com.optum.oap.jdbc.db.JDBCConstants.SP
import com.optum.oadw.hiveoracleloader.lib.utils.OADWMetaDataUtils.META_DATA_CONSTANTS._
import com.optum.oap.utils.Resource.using
import com.optum.oadw.hiveoracleloader.lib.common.{CreateOracleSchemaConfig, DropOracleSchemaConfig}
import com.optum.oadw.hiveoracleloader.lib.utils.{MetaDataAttribute, OADWMetaDataUtils}
import com.optum.oadw.utils.{MdOadwInstanceHelper, MetaDataConstants}
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

import scala.collection.mutable.ListBuffer
import scala.util.{Failure, Success, Try}

object SchemaService {

  private val logger = LoggerFactory.getLogger(this.getClass)
  private val queryTemplate = s"SELECT USERNAME FROM DBA_USERS WHERE USERNAME LIKE '%s' ORDER BY USERNAME ASC"

  def callCreateOadwUserFunction(conf: CreateOracleSchemaConfig, sparkSession: SparkSession): Unit = {
    // Update md_oadw_instance about the oracle export start
    val formatter = DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss")
    val oracleExportStartDtm = formatter.format(LocalDateTime.now())
    MdOadwInstanceHelper.addRecordInMdOadwInstance(sparkSession, conf.hiveDb.get, MetaDataConstants.ORCL_EXPORT_START_DTM, oracleExportStartDtm)

    val clientId = conf.clientId

    val schemaMetaData = getSchemaName(conf, sparkSession)
    val currentUser = getCurrentSchemaNameFrom(schemaMetaData.value)

    logger.warn(s"OADW USER => ${schemaMetaData.value}")
    val createUserStatement: String = s"call proxy_dba.oadw_user_management_engr.create_oadw_user(username_in=> '${schemaMetaData.value}', in_client_id=> '$clientId')"

    executeStoredProcedure(conf.oracleHost, conf.oraclePassword, conf.oracleUser, conf.oracleService, createUserStatement)

    val createCurrentUserStatement: String = s"""
      DECLARE
        currentOracleSchemaexists int:=0;
      BEGIN
          SELECT count(username) into currentOracleSchemaExists FROM all_users WHERE username = '${currentUser}' ;
          IF currentOracleSchemaExists = 0 THEN
            proxy_dba.oadw_user_management_engr.create_oadw_user(username_in=> '${currentUser}', in_client_id=> '${clientId}');
          END IF;
      END;"""

    executeStoredProcedure(conf.oracleHost, conf.oraclePassword, conf.oracleUser, conf.oracleService, createCurrentUserStatement)
    /** We only do our logging and meta data updates in case of generated names. Manual schema names provided are only for testing purposes. (There might be on hive db when creating schema without orchestration) **/
    if (schemaMetaData.isGenerated) {
      OADWMetaDataUtils.updateMetaDataModel(sparkSession, schemaMetaData, conf.hiveDb.get)
    }
  }

  private def getSchemaName(conf: CreateOracleSchemaConfig, sparkSession: SparkSession): MetaDataAttribute = {

    if (conf.schemaName.isDefined) {
      val isMonthly = getIsMonthly(conf.schemaName.get.toLowerCase)
      MetaDataAttribute(name = ORACLE_SCHEMA_NAME, value = conf.schemaName.get, isGenerated = false, isMonthly)
    } else {
      val hiveDb = if (conf.hiveDb.isDefined) conf.hiveDb.get else throw new IllegalArgumentException("Required parameter hiveDb missing")
      val environment = if (conf.environment.isDefined) conf.environment.get else throw new IllegalArgumentException("Required parameter environment missing")
      val metaDataInfo = getMetadataInfo(sparkSession, hiveDb)
      val sequence = getDestinationSequence(conf.oracleHost, conf.oraclePassword, conf.oracleUser, conf.oracleService, conf.clientId, environment, metaDataInfo)

      val generatedName = generateDestinationSchemaName(conf.clientId, environment, metaDataInfo, sequence)
      MetaDataAttribute(name = ORACLE_SCHEMA_NAME, value = generatedName, isGenerated = true, metaDataInfo.isMonthly)
    }
  }

  private def getIsMonthly(schemaName: String): Boolean = {
    schemaName match {
      case name if name.contains("eoadw") => false
      case name if name.contains("oadw") => true
      case invalidName => throw new IllegalArgumentException(s"Invalid name: $invalidName. Schema name should have 'eOADW' or 'OADW'")
    }
  }

  def getOracleInstance(oracleService: String): String = {
    s"_${oracleService.toLowerCase}"
  }

  def generateDestinationSchemaName(clientId: String, environment: String, metaDataInfo: MetadataInfo, sequence: Int): String = {
    val schemaNameTemplate = "%s_%s_%s_%s_%s"

    val schemaName = if (metaDataInfo.isMonthly) {
      String.format(schemaNameTemplate, "OADW", environment, clientId, metaDataInfo.srcSchema.toUpperCase, sequence.toString)
    } else {
      String.format(schemaNameTemplate, "EOADW", environment, clientId, metaDataInfo.dataThru, sequence.toString)
    }

    logger.warn(s"Destination Schema: $schemaName")
    schemaName.toUpperCase
  }

  private def getAdapter(user: String, password: String, host: String, database: String) = {
    new OracleDriver(userName = user, password = password, host = host, database = database)
  }

  private def executeStoredProcedure(host: String, password: String, user: String, database: String, statement: String): Unit = {
    val jdbcAdapter = getAdapter(user, password, host, database)

    Class.forName(jdbcAdapter.DRIVER_NAME)

    val connection: Connection = jdbcAdapter.getConnection
    jdbcAdapter.executeSql(connection, statement, SP)
  }

  private def getMetadataInfo(sparkSession: SparkSession, hiveDb: String): MetadataInfo = {

    val seqAttrNames = Seq(SRC_SCHEMA, DATA_THRU, IS_MONTHLY_FLG)
    val mapAttr = OADWMetaDataUtils.getAttributesFromMetaTable(sparkSession, hiveDb, seqAttrNames)

    val srcSchema = mapAttr(SRC_SCHEMA)
    val dataThru = mapAttr(DATA_THRU)
    val isMonthly = mapAttr(IS_MONTHLY_FLG).toLowerCase match {
      case "y" => true
      case "delta" => false
      case invalidEntry => throw new IllegalArgumentException(s"Invalid content $invalidEntry in md_oadw_instance for IS_MONTHLY_FLG")
    }
    MetadataInfo(srcSchema, dataThru, isMonthly)
  }

  private def getDestinationSequence(host: String, password: String, user: String, database: String, clientId: String,
                                     environment: String, metaDataInfo: MetadataInfo): Int = {

    val jdbcAdapter = getAdapter(user, password, host, database)
    val connection: Connection = jdbcAdapter.getConnection

    val replacementStr = if (metaDataInfo.isMonthly) {
      s"OADW_${environment.toUpperCase}_${clientId.toUpperCase}_${metaDataInfo.srcSchema.toUpperCase}_%"
    } else {
      s"EOADW_${environment.toUpperCase}_${clientId.toUpperCase}_${metaDataInfo.dataThru.toUpperCase}_%"
    }

    val userNameQuery = String.format(queryTemplate, replacementStr)
    val sequence = getSequence(connection, userNameQuery)

    logger.warn(s"Derived Sequence: $sequence")
    sequence
  }

  private def getSequence(connection: Connection, query: String): Int = {
    val defaultSequence = 1
    val schemasFound = getOlderSchemas(connection, query)
    deriveSequenceNumber(schemasFound, defaultSequence)
  }

  private def getOlderSchemas(connection: Connection, query: String): ListBuffer[String] = {
    using(connection.createStatement())(statement => {
      statement.execute(query)
      val resultSet = statement.getResultSet
      var foundSchemas = ListBuffer[String]()
      while (resultSet.next()) {
        foundSchemas += resultSet.getString(1)
      }
      logger.warn(foundSchemas.toString)
      foundSchemas
    })
  }

  def deriveSequenceNumber(schemas: ListBuffer[String], defaultSequence: Int): Int = {
    if (schemas.isEmpty) defaultSequence
    else {
      val latestSchema = schemas.reduceLeft((left, right) => {
        val leftSuffix = left.split("_").last
        val rightSuffix = right.split("_").last

        val leftSequence: Try[Int] = Try(leftSuffix.toInt)
        val rightSequence: Try[Int] = Try(rightSuffix.toInt)

        val leftValue = leftSequence match {
          case Success(i) => i
          case Failure(_) => -1
        }

        val rightValue = rightSequence match {
          case Success(i) => i
          case Failure(_) => -1
        }

        if (leftValue > rightValue) left else right
      })

      val winnerSuffix = latestSchema.split("_").last
      Try(winnerSuffix.toInt) match {
        case Success(i) => i + 1
        case Failure(_) => defaultSequence
      }
    }
  }

  def callDropOadwUserFunction(conf: DropOracleSchemaConfig): Unit = {
    val oadwUserName = conf.schemaName
    val dropUserStatement: String = s" call proxy_dba.oadw_user_management_engr.safe_drop_user(username_in=> '$oadwUserName')"

    executeStoredProcedure(conf.oracleHost, conf.oraclePassword, conf.oracleUser, conf.oracleService, dropUserStatement)
  }

  def getCurrentSchemaNameFrom(schemaName: String): String = {
    try {
      val sourceSplit = schemaName.split("_")
      val nameWithLevel_env_client = sourceSplit.take(3).mkString("_")
      s"${nameWithLevel_env_client}_CURRENT".toUpperCase
    } catch {
      case ex: Exception =>
        logger.error(s"$schemaName is not in correct format. The expected format for schemaName(s) are - EOADW_{env}_{clientId}_{date}_{sequence} for Epsilon schemas and OADW_{env}_{clientId}_CDR_{yearWithMonth}_{sequence} for Monthly schemas")
        throw ex
    }
  }
}

case class MetadataInfo(srcSchema: String, dataThru: String, isMonthly: Boolean)
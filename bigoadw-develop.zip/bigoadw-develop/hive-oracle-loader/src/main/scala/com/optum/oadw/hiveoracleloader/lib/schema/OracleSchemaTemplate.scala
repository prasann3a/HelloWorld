package com.optum.oadw.hiveoracleloader.lib.schema

import java.util.Properties

import com.optum.oadw.hiveoracleloader.lib.common.{Constants, CustomMaps}
import com.optum.oadw.hiveoracleloader.lib.schema.visitor.HiveToOracleAdapter
import com.optum.oadw.hiveoracleloader.lib.utils.ResourceHandler
import com.optum.oadw.metadata.OADWDataTypeMap
import net.sf.jsqlparser.parser.CCJSqlParserUtil
import net.sf.jsqlparser.statement.create.table.{ColDataType, ColumnDefinition, CreateTable}
import net.sf.jsqlparser.statement.create.view.CreateView
import net.sf.jsqlparser.statement.drop.Drop
import net.sf.jsqlparser.util.TablesNamesFinder

import scala.collection.JavaConverters._


class OracleSchemaTemplate {

  private val tableFinder = new TablesNamesFinder
  private val hiveToOracleAdapter = new HiveToOracleAdapter
  private val columnOverrideMap = ResourceHandler.getOverrideColumnMap()

  private val CREATE_TABLE =
    s"""
       |-- This table is sourced from %s
       |DROP_IF_EXISTS('%s', 'TABLE');
       |EXECUTE IMMEDIATE 'CREATE TABLE %s (
       |%s\n\t) %s\n\tPCTFREE 0 NOLOGGING COMPRESS';
    """.stripMargin
  private val DROP_TABLE =
    s"""
       |DROP_IF_EXISTS('%s', 'TABLE');""".stripMargin

  private val CREATE_VIEW =
    s"""
       |-- This view is sourced from %s
       |DROP_IF_EXISTS('%s', 'VIEW');
       |EXECUTE IMMEDIATE 'CREATE OR REPLACE VIEW %s
       |AS %s';
    """.stripMargin
  private val DROP_VIEW =
    s"""
       |DROP_IF_EXISTS('%s','VIEW');""".stripMargin

  private var tableMapProperties: Properties = _


  def initialize(tablePropertiesFile: String): Unit ={
    if(!tablePropertiesFile.isEmpty) {
      this.tableMapProperties = ResourceHandler.loadPropertyFile(tablePropertiesFile)
    }
  }

  def getDropStatement(drop: Drop, schemaName: String): SchemaContent = {
    val dropType = drop.getType
    val objectName = drop.getName.getName
    val statement = if(dropType.equalsIgnoreCase("VIEW")) {
      String.format(DROP_VIEW, objectName)
    } else {
      String.format(DROP_TABLE, objectName)
    }
    SchemaContent(objectName.toLowerCase, "", statement)
  }

  def getCreateStatement(create: CreateTable, schemaName: String, sourceDB: String): SchemaContent = {

    val schema = if(!schemaName.isEmpty) s"$schemaName." else ""

    val tableName = tableMapProperties.getProperty(create.getTable.getName.toLowerCase, create.getTable.getName.toLowerCase)
    val tableNameWithSchema = schema + tableName

    val colDefinitions = create.getColumnDefinitions.asScala
    val mappedColumns = OADWDataTypeMap.getColumnMapping(tableNameWithSchema)


    colDefinitions.foreach(column => {
      if (mappedColumns.contains(column.getColumnName.toLowerCase)) {
        val colDataType = new ColDataType
        colDataType.setDataType(mappedColumns(column.getColumnName.toLowerCase))
        colDataType.setArgumentsStringList(null)
        column.setColDataType(colDataType)
      }
    })

    val columnsToAdd = if(CustomMaps.AddColumnsMap.keySet.contains(tableName.toUpperCase())) {
      val columnList = CustomMaps.AddColumnsMap(tableName.toUpperCase)
      ",\n\t" + columnList.mkString(",\n").replaceAll("'", "''")
    } else ""

    val columns = colDefinitions
      .sortBy(_.getColumnName)
      .map(x => {
        val colSpecStrings = if(x.getColumnSpecStrings == null) ""
        else " " + x.getColumnSpecStrings.asScala.toList.mkString(" ")
        val overrideDataType = getOverrideDataType(tableName, x)
        s"\t${hiveToOracleAdapter.maskColumn(x.getColumnName.trim)} $overrideDataType$colSpecStrings"
      }).mkString(",\n") + columnsToAdd

    val partitionInfo = if(CustomMaps.TablePartitionMap.keySet.contains(tableName.toUpperCase)){
      CustomMaps.TablePartitionMap(tableName.toUpperCase).replaceAll("'", "''")
    } else ""

    val statement = hiveToOracleAdapter.postProcessing(String.format(CREATE_TABLE, sourceDB, tableNameWithSchema, tableNameWithSchema, columns, partitionInfo))
    SchemaContent(tableName.toLowerCase, statement, "")
  }

  private def getOverrideDataType(tableName: String, columnDefinition: ColumnDefinition): String = {

    val columnsMap = ResourceHandler.getOverrideColumnMapping(tableName.toUpperCase, columnOverrideMap)
    columnsMap.getOrElse(columnDefinition.getColumnName.toUpperCase, hiveToOracleAdapter.hiveToOracleDataType(columnDefinition.getColDataType).toString)
  }


  def getCreateViewStatement(createView: CreateView, schemaName: String, sourceDB: String): SchemaContent = {
    try {
      val schema = if(!schemaName.isEmpty) s"$schemaName." else ""

      val viewName = schema + tableMapProperties.getProperty(createView.getView.getName.toLowerCase, createView.getView.getName.toLowerCase)

      val selectBody = createView.getSelect.getSelectBody

      createView.getSelect.getSelectBody.accept(hiveToOracleAdapter)

      val stmt = CCJSqlParserUtil.parse(selectBody.toString)
      val tables = tableFinder.getTableList(stmt).asScala

      val replaceDbNameInView = tables.foldLeft(createView.getSelect.getSelectBody.toString)((query, table) => {

        val tableNameWithoutDB = if(table.contains(".")) {
          table.toLowerCase.split("""\.""").toList(1)
        } else {
          table
        }

        query.replaceAll(table, tableMapProperties.getProperty(tableNameWithoutDB, tableNameWithoutDB))
      })
        .replaceAll("'", "''")
        .replaceAll("""VARCHAR(\s*)\((\d+)\)""", "VARCHAR2$1($2 CHAR)")
      val statement = hiveToOracleAdapter.postProcessing(String.format(CREATE_VIEW, sourceDB, viewName, viewName, replaceDbNameInView))

      val pattern = """(FROM\s+\(SELECT.*\))\s+AS\s+[a-zA-Z0-9]+\s+(WHERE|[GROUP\s+BY])""".r
      val finalStmt = pattern.replaceAllIn(statement, _ match {
        case pattern(before, after) => f"$before $after"
      })

      val dropStmt = String.format(DROP_VIEW, viewName)
      SchemaContent(viewName.toLowerCase, finalStmt, dropStmt)
    } finally {
      hiveToOracleAdapter.selectItemMap.clear()
    }
  }

  def processCreateViewContainsWith(viewName: String, line: String, schemaName: String): SchemaContent = {

    val tableList = QueryMap.getTableList(viewName, "VIEW")
    val replaceDbNameInView = tableList.foldLeft(line)((query, table) => {
      val tableNameWithoutDB = if(table.contains(".")) {
        table.toLowerCase.split("""\.""").toList(1)
      } else {
        table
      }

      query.replaceAll(table, tableMapProperties.getProperty(tableNameWithoutDB, tableNameWithoutDB))
    })
    val replacementString =
      s"""
         |DROP_IF_EXISTS('$viewName', 'VIEW');
         |EXECUTE IMMEDIATE 'CREATE OR REPLACE VIEW
      """.stripMargin
    val statement = replaceDbNameInView.replaceAll("hivedb.", "")
      .replaceAll("'","''")
      .replace(";","';\n")
      .replace("CREATE VIEW", replacementString)
    val dropStmt = String.format(DROP_VIEW, viewName)
    SchemaContent(viewName.toLowerCase, statement, dropStmt)
  }

}

case class SchemaContent(model: String,
                         createStmt: String,
                         dropStmt: String)
case class CaseColumns(originalColumnName: String, aliasColumName: String, columnDataType: String) {
  override def toString: String = s"${aliasColumName.toLowerCase}: $columnDataType = null"
}

package com.optum.oadw.hiveoracleloader.lib.loaders

import com.optum.oap.jdbc.OracleDriver
import com.optum.oadw.hiveoracleloader.lib.common.OracleConfig
import org.apache.spark.sql.DataFrame


object OracleLoader {

  def load(df: DataFrame, oracleConfig: OracleConfig, oracleTableName: String, truncateBeforeLoad: Boolean): Unit = {

    val host = oracleConfig.oracleHost
    val service = oracleConfig.oracleService
    val user = oracleConfig.oracleUserName
    val password = oracleConfig.oraclePassword
    val batch_size = oracleConfig.oracleBatchSize

    val oracleJdbcAdapter = new OracleDriver(host = host, database = service,
      userName = user, password = password)
    Class.forName(oracleJdbcAdapter.DRIVER_NAME)

    //since we don't want Spark to ever re-create DDL
    val truncate = if (oracleConfig.saveMode.trim.equalsIgnoreCase("Overwrite")) true else truncateBeforeLoad

    val url = oracleJdbcAdapter.getConnectionURL

    val prop = new java.util.Properties
    prop.setProperty("user", user)
    prop.setProperty("password", password)
    prop.setProperty("batchsize", batch_size)
    prop.setProperty("driver",oracleJdbcAdapter.DRIVER_NAME)

    val table = oracleTableName

    df
      .write
      .option("truncate", truncate)
      .mode(saveMode = oracleConfig.saveMode)
      .jdbc(url, table, prop)
  }
}
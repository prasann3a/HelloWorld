package com.optum.oadw.hiveoracleloader.lib.schema.visitor

import net.sf.jsqlparser.expression.Alias
import net.sf.jsqlparser.schema.Table
import net.sf.jsqlparser.statement.select._

import scala.collection.JavaConverters._

trait OracleFromVisitor extends FromItemVisitor {
  this: HiveToOracleAdapter =>

  private var aliasIndex = 0

  def visit(var1: Table): Unit = {}

  def visit(subSelect: SubSelect): Unit = {

    if (subSelect.getAlias == null) {
      subSelect.setAlias(new Alias(s"a$aliasIndex"))
      aliasIndex = aliasIndex + 1
    }

    if (subSelect.getWithItemsList != null) {
      for {
        stmt <- subSelect.getWithItemsList.asScala
      } stmt.accept(this)
    }

    subSelect.getSelectBody.accept(this)
  }

  def visit(var1: SubJoin): Unit = {}

  def visit(var1: LateralSubSelect): Unit = {}

  def visit(var1: ValuesList): Unit = {}

  def visit(var1: TableFunction): Unit = {}

  def visit(var1: ParenthesisFromItem): Unit = {}
}

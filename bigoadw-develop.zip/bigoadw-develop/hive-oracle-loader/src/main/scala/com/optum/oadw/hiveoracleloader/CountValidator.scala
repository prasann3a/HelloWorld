package com.optum.oadw.hiveoracleloader

import java.sql.ResultSet
import java.util.Properties

import better.files.{Resource => ScalaResource}
import com.optum.oap.jdbc.OracleDriver
import com.optum.oap.utils.Resource.using
import com.optum.oadw.hiveoracleloader.lib.common.{ConfigLists, Constants}
import com.optum.oadw.hiveoracleloader.lib.common.Constants.{DEFAULT_BUILD, EPSILON_BUILD, OadwBuildType}
import com.optum.oadw.hiveoracleloader.lib.schema.FileContentHandler
import com.optum.oadw.hiveoracleloader.lib.utils.ResourceHandler
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

import scala.collection.JavaConverters._
import scala.collection.mutable.ArrayBuffer

object CountValidator {

  private val ignoreMissingOracleTables = Set("track_hash_table_builds", "statistics_copy")
  private val ignoreMissingOracleTableColumns = Set("l3_map_readmission.map_key")
  private val ignoreMissingHiveTableColumns = Set("l2_pat_diag.parititon_key", "l2_pat_med.partition_key",
     "l4_dict_measure_category.measure_cat2_cd")
  private val ignoreRefTableCounts = ConfigLists.excludeOadwTablesAndViews ++ ConfigLists.excludeOadwRefTablesAndViews
  private val doNotCompare = Set("'md_oadw_instance'")

  private val logger = LoggerFactory.getLogger(this.getClass)

  def validateHiveAndOracleCounts(hiveDb: String, oracleHost: String,
                                  oracleService: String, oracleUser: String,
                                  oraclePassword: String, buildType: String, sparkSession: SparkSession): Unit = {

    logger.warn(s"Target Oracle user is: $oracleUser")

    val tableNamesMap = convertPropertiesToLowerCase(ResourceHandler.loadTableNamesProperties())
    val columnNamesMap = convertPropertiesToLowerCase(ResourceHandler.loadColumnNamesProperties())

    logger.info("Gathering stats from Hive")
    val statsFromHive = using(sparkSession)(implicit sparkSession => {

      import sparkSession.implicits._
      val statsDF = sparkSession.sql(s"select * from $hiveDb.oadw_stats where table_type <> 'VIEW' and table_name not in (${doNotCompare.mkString(",")})")
        .select(
          $"table_name", $"column_name",
          // Oracle treats "" as null, so when comparing counts Hive null_count must be added to default_count IF the default_value is ""
          when($"default_value" === lit(""), $"null_count" + $"default_count").otherwise($"null_count").as("null_count"),
          // also have to subtract default_count from the non_null count
          when($"default_value" === lit(""), $"non_null_count" - $"default_count").otherwise($"non_null_count").as("non_null_count"),
          $"total_count"
        ).as[CommonStats]

      // convert all table names and column names to lower case
      statsDF.map(stats => {
        stats.copy(table_name = stats.table_name.toLowerCase(), column_name = stats.column_name.toLowerCase)
      }).collect().toList
    })

    logger.info("Gathering stats from Oracle")
    val oracleDriver = new OracleDriver(host = oracleHost, database = oracleService, userName = oracleUser, password = oraclePassword)
    val statsFromOracle = oracleDriver.doInsideConnection(s"select * from $oracleUser.ORACLE_STATS where TABLE_NAME not in (${doNotCompare.mkString(",")})", oracleDriver.getConnection, (rs: ResultSet) => {
      val outList = new ArrayBuffer[CommonStats]()
      while(rs.next()) {
        outList.append(
          CommonStats(
            table_name = rs.getString("TABLE_NAME").toLowerCase,
            column_name = rs.getString("COLUMN_NAME").toLowerCase,
            null_count = rs.getLong("NULL_COUNT"),
            non_null_count = rs.getLong("NON_NULL_COUNT"),
            total_count = rs.getLong("TOTAL_COUNT")
          )
        )
      }

      outList.toList
    })

    val hiveStatsMap = StatsMap(statsFromHive)
    val oracleStatsMap = StatsMap(statsFromOracle)

    val oadwBuildType = buildType.toUpperCase match {
      case "EPSILON" => EPSILON_BUILD
      case _ => DEFAULT_BUILD
    }
    val differences = gatherDifferences(hiveStatsMap, oracleStatsMap, tableNamesMap, columnNamesMap, oadwBuildType)

    if (differences.nonEmpty) {
      throw new IllegalStateException(s"Found the following inconsistencies between Hive DB $hiveDb and Oracle $oracleUser:\n${differences.mkString("  ", "\n  ", "")}")
    }
  }

  private def convertPropertiesToLowerCase(properties: Properties): Properties = {
    val keys = properties.keySet().asScala
    val props = new Properties()

    keys.foreach(key => {
      val strKey = key.asInstanceOf[String]
      props.setProperty(strKey.toLowerCase(), properties.getProperty(strKey).toLowerCase())
    })

    props
  }

  def gatherDifferences(hiveStatsMap: StatsMap, oracleStatsMap: StatsMap, tableNamesMap: Properties, columnNamesMap: Properties, oadwBuildType: OadwBuildType): Seq[String] = {
    logger.warn(
      s"""
         |
         |--- IGNORING THE FOLLOWING ISSUES:
         | 1. Missing Oracle tables -> ${ignoreMissingOracleTables.mkString}
         | 2. Missing columns from Hive tables -> ${ignoreMissingHiveTableColumns.mkString}
         | 3. Total count mismatches coming from REF tables -> ${ignoreRefTableCounts.mkString}
         | 4. Do not compare -> ${doNotCompare.mkString}
         | """.stripMargin
    )

    val hiveTables = hiveStatsMap.getTables
    lazy val eOadwTables = ScalaResource.getAsString(Constants.EPSILON_FILTER_FILE).split("\\r?\\n").toSet

    hiveTables.flatMap(hiveTable =>
      if (!FileContentHandler.oadwContractTableOrViewPattern.pattern.matcher(hiveTable.toLowerCase()).matches) Seq.empty[String] // Ignore tables that didn't get exported...
      else {
        val hiveColumns = hiveStatsMap.getColumns(hiveTable).map(col => columnNamesMap.getProperty(col, col).toLowerCase -> col).toMap
        val hiveTotal = hiveStatsMap.getTotalCount(hiveTable)
        val oracleName = tableNamesMap.getProperty(hiveTable, hiveTable)
        val oracleColumns = oracleStatsMap.getColumns(oracleName)
        val oracleTotalCount = oracleStatsMap.getTotalCount(oracleName)
        val allColumns = hiveColumns.keySet ++ oracleColumns

        if (hiveTotal != oracleTotalCount) Seq(
          if (oracleTotalCount == -1) {
            if (ignoreMissingOracleTables.contains(oracleName)) ""
            else if ( oadwBuildType == EPSILON_BUILD && !eOadwTables.contains(oracleName.toLowerCase())) ""
            else s"Could not locate Oracle table $oracleName"
          } else if (ignoreRefTableCounts.contains(hiveTable)) ""
          else s"Hive table $hiveTable count of $hiveTotal did not match Oracle table $oracleName count of $oracleTotalCount"
        )
        else allColumns.map(columnName => {
          val hiveCounts = hiveStatsMap.getCounts(hiveTable, hiveColumns.getOrElse(columnName, columnName))
          val oracleCounts = oracleStatsMap.getCounts(oracleName, columnName)

          if (hiveCounts.isEmpty) {
            if (ignoreMissingHiveTableColumns.contains(s"$hiveTable.$columnName")) "" else s"Could not locate Hive column $hiveTable.$columnName"
          } else if (oracleCounts.isEmpty) {
            if(ignoreMissingOracleTableColumns.contains(s"$oracleName.$columnName")) "" else s"Could not locate Oracle column $oracleName.$columnName"
          } else {
            val hiveNull = hiveCounts.get.null_count
            val hiveNonNull = hiveCounts.get.non_null_count
            val oracleNull = oracleCounts.get.null_count
            val oracleNonNull = oracleCounts.get.non_null_count

            if (!ignoreRefTableCounts.contains(hiveTable) && (hiveNull != oracleNull || hiveNonNull != oracleNonNull)) {
              s"Null/Non-null counts do not match for Hive column $hiveTable.${hiveColumns.getOrElse(columnName, columnName)} ($hiveNull/$hiveNonNull) and Oracle column $oracleName.$columnName ($oracleNull/$oracleNonNull)"
            } else ""
          }
        })
      }
    ).filter(_.nonEmpty)
  }
}

case class CommonStats(table_name: String, column_name: String, null_count: Long, non_null_count: Long, total_count: Long)
case class ColumnCounts(null_count: Long, non_null_count: Long)

object StatsMap {
  def apply(commonStatsList: Seq[CommonStats]): StatsMap = new StatsMap(commonStatsList)
}

class StatsMap(commonStatsList: Seq[CommonStats]) {

  private val countsMap = commonStatsList.map(cs => s"${cs.table_name}.${cs.column_name}" -> ColumnCounts(cs.null_count, cs.non_null_count)).toMap
  private val totalMap = commonStatsList.map(cs => cs.table_name -> cs.total_count).toMap
  private val tableToColumns = commonStatsList.groupBy(_.table_name).map(x => x._1 -> x._2.map(_.column_name).toSet)

  def getCounts(tableName: String, columnName: String): Option[ColumnCounts] = {
    countsMap.get(s"$tableName.$columnName")
  }

  def getTotalCount(tableName: String): Long = {
    totalMap.getOrElse(tableName, -1)
  }

  def getColumns(tableName: String): Set[String] = {
    tableToColumns.getOrElse(tableName, Set.empty)
  }

  def getTables: Seq[String] = {
    tableToColumns.keys.toSeq
  }
}
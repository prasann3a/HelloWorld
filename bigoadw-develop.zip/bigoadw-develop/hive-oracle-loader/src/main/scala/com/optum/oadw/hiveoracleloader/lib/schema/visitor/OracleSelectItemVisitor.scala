package com.optum.oadw.hiveoracleloader.lib.schema.visitor

import net.sf.jsqlparser.statement.select.{AllColumns, AllTableColumns, SelectExpressionItem, SelectItemVisitor}

trait OracleSelectItemVisitor extends SelectItemVisitor {
  this: HiveToOracleAdapter =>

  def visit(var1: AllColumns): Unit = {}

  def visit(var1: AllTableColumns): Unit = {}

  def visit(var1: SelectExpressionItem): Unit = {
    if (var1.getExpression != null) {
      var1.getExpression.accept(this)
    }
    this.processSelectExpressionItem(var1)
  }
}

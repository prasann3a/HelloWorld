package com.optum.oadw.utils

import scala.util.matching.Regex

object DatatypeValidatorHelper {
  private def readLinesFromStream(resourceName: String): List[String] = {
    val resourceStream = this.getClass.getClassLoader.getResourceAsStream(resourceName)
    scala.io.Source.fromInputStream(resourceStream).getLines().toList
  }

  private def groupLinesByTable[T](lines: List[T], separator: T): List[List[T]] = {
    lines.span( _ != separator) match {
      case (head, _ :: tail) => head :: groupLinesByTable(tail, separator)
      case (head, _) => List(head)
    }
  }
  def checkInvalidDatatypes(resourceName: String, invalidDatatypePatterns: List[Regex], invalidCastPatterns: List[Regex],
                           lineFilterFn:String => Boolean, tFilter: String, vFilter: String,
                            tnameFn: String => String, vnameFn: String => String) : Unit = {
    val schemaLines = readLinesFromStream(resourceName)
    val schemaGrpLines = groupLinesByTable(schemaLines, "")
    for (grpLines <- schemaGrpLines) {
      val filteredLines = grpLines.filterNot(lineFilterFn)
      if (filteredLines.nonEmpty) {
        val header = filteredLines.head.toUpperCase
        if (header.contains(tFilter)) {
          val tablename = tnameFn(header)
          val columnLines = filteredLines.tail
          // for each column line, check that there are no invalid datatypes
          for(colLine <- columnLines) {
            // For each column check if any of the invalid datatypes is present
            for(ivdPattern <- invalidDatatypePatterns) {
              val ivdOption = ivdPattern.findFirstIn(colLine.trim.toUpperCase)
              if (ivdOption.isDefined) {
                val colName = colLine.trim.split("\\s+")(0)
                throw new java.lang.IllegalStateException(s"Found invalid datatype ${ivdOption.get} for column $colName in $tablename")
              }
            }
          }
        } else if (header.contains(vFilter)) {
          val viewLines = filteredLines.tail
          for(vl <- viewLines) {
            for(ce <- invalidCastPatterns) {
              val ceOption = ce.findFirstIn(vl.toUpperCase)
              if(ceOption.isDefined) {
                val viewname = vnameFn(header)
                throw new java.lang.IllegalStateException(s"Found invalid datatype ${ceOption.get.stripPrefix("AS ")} in CAST expression in $viewname")
              }
            }
          }
        }
      }
    }
  }

}

package com.optum.oadw.utils

import com.optum.oadw.common.models.OADWRuntimeVariables
import com.optum.oadw.constants.OADWSchema
import com.optum.oadw.utils.Resource.using
import com.optum.oap.parser.DataTypeMap
import com.optum.oap.parser.hivetohive.HiveToHiveParser
import com.optum.oap.sparkdataloader.RuntimeVariables
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataTypes, IntegerType, NumericType, StringType}
import org.apache.spark.sql.{AnalysisException, DataFrame, Dataset, SparkSession}
import org.slf4j.LoggerFactory

import scala.io.Source

object OadwStatsUtils {
  private val isNullAppend       = "IsNull"
  private val isNotNullAppend    = "IsNotNull"
  private val defaultAppend      = "IsDefault"
  private val defaultValueAppend = "DefaultValue"
  private val maxStringAppend    = "MaxStringLength"

  private val logger = LoggerFactory.getLogger(this.getClass)

  def getDataFrameFromParquetLoc(sparkSession: SparkSession, parquetLocation: String): DataFrame = {
    import sparkSession.implicits._
    try {
      sparkSession.read.parquet(parquetLocation)
    } catch {
      case e: AnalysisException => {
        sparkSession.emptyDataset[EmptyParquet].toDF
      }
    }
  }

  def getDataFrame(sparkSession: SparkSession, parquetMap: Map[String, HiveColumnDefinition], table: String): DataFrame = {
    import sparkSession.implicits._
    try {
      sparkSession.read.parquet(parquetMap(table).parquetLocation).selectExpr(parquetMap(table).columns: _*)
    } catch {
      case e: AnalysisException => {
        sparkSession.emptyDataset[EmptyParquet].toDF
      }
    }
  }

  def getOadwBasePath(runtimeVariables: RuntimeVariables): String = {
    val conf = OADWRuntimeVariables(runtimeVariables)
    conf.protocol match {
      case "s3"            => s"s3://${conf.bucket}/${conf.environment}/oadw/${conf.cdrCycle}/${conf.instance}/${conf.streamId}"
      case "hdfs"          => s"/optum/data_factory/${conf.clientId}/${conf.environment}/oadw/${conf.cdrCycle}/${conf.instance}/${conf.streamId}"
      case invalidProtocol => throw new IllegalArgumentException(s"Invalid protocol $invalidProtocol")
    }
  }

  def calculateTableStats(sparkSession: SparkSession, dataFrame: DataFrame, tableName: String, tableType: String = "TABLE"): List[StatsSchemaFromDB] = {
    import sparkSession.implicits._

    val columns = dataFrame.columns
    val schema  = dataFrame.schema.fields.map(f => f.name -> f.dataType).toMap

    val selectCols = schema.flatMap {
      case (colName, dataType) =>
        val defaultSum = (dataType match {
          case DataTypes.StringType => sum(when($"$colName" === "", 1).otherwise(0))
          case _: NumericType       => sum(when($"$colName" === 0, 1).otherwise(0))
          case _                    => lit(null)
        }).as(s"$colName$defaultAppend")

        val defaultValue = (dataType match {
          case DataTypes.StringType => lit("")
          case _: NumericType       => lit("0")
          case _                    => lit(null).cast(StringType)
        }).as(s"$colName$defaultValueAppend")

        val maxStringLength = (dataType match {
          case DataTypes.StringType => max(length($"$colName"))
          case _: NumericType       => lit(null)
          case _                    => lit(null)
        }).as(s"$colName$maxStringAppend")

        Seq(
          sum(when($"$colName".isNull, 0).otherwise(1)).as(s"$colName$isNotNullAppend"),
          sum(when($"$colName".isNull, 1).otherwise(0)).as(s"$colName$isNullAppend"),
          defaultSum,
          defaultValue,
          maxStringLength
        )
    }.toSeq

    dataFrame
      .select(selectCols: _*)
      .flatMap(row => {
        columns.map(colName => {
          val nullCount    = row.getAs[Long](s"$colName$isNullAppend")
          val nonNullCount = row.getAs[Long](s"$colName$isNotNullAppend")

          val defaultValue = row.getAs[String](s"$colName$defaultValueAppend")

          val defaultIndex = row.fieldIndex(s"$colName$defaultAppend")
          val defaultSum = Option(
            if (defaultValue != null && nullCount + nonNullCount == 0) {
              // if default_value not null and 0 total_count, then default_sum needs to be set to 0 manually
              0
            } else if (row.isNullAt(defaultIndex)) {
              null.asInstanceOf[Long]
            } else {
              row.getLong(defaultIndex)
            }
          )

          val maxStringLength = row.getAs[Int](s"$colName$maxStringAppend")

          StatsSchemaFromDB(tableName.toLowerCase, colName.toLowerCase, nullCount, nonNullCount, defaultSum, defaultValue, nullCount + nonNullCount, tableType, maxStringLength)
        })
      })
      .collect
      .toList
  }

  def calculateStatsFromHql(lines: List[String]): List[StatsFromHQL] = {

    val parsedResult = getHiveParser.parse(lines).toList
    parsedResult.flatMap(content => {
      val tableType = if (content.isView) "VIEW" else "TABLE"
      val table     = content.originalModelName
      content.mappedColumnInfo.map(column => {
        StatsFromHQL(
          column_name = column.name,
          data_type = column.dataType.toUpperCase,
          length =
            if (!(column.dataTypeArgList.getOrElse(List.empty).mkString(",").contains(",")))
              if (column.dataTypeArgList.getOrElse(List.empty).mkString(",").matches("[0-9]+")) column.dataTypeArgList.getOrElse(List.empty).mkString(",").toInt else null
            else null,
          precision_value = if (column.dataTypeArgList.getOrElse(List.empty).mkString(",").contains(",")) column.dataTypeArgList.getOrElse(List.empty).mkString(",").split(",").toList(0).toInt else null,
          scale = if (column.dataTypeArgList.getOrElse(List.empty).mkString(",").contains(",")) column.dataTypeArgList.getOrElse(List.empty).mkString(",").split(",").toList(1).toInt else null,
          table_name = table,
          tableorview = tableType
        )
      })
    })
  }

  def getHiveParser: HiveToHiveParser = {
    val skipContent       = Set("^CREATE DATABASE IF NOT EXISTS".r, "^--".r)
    val postMaskKeys      = Set("class")
    val preMaskKeys       = Set("grouping", "interval", "exclude")
    val oadwDataTypeLines = ResourceHelper.readLinesFromStream(OADWSchema.OADW_DATA_TYPE_MAP)
    val dataTypemap = oadwDataTypeLines
      .filter(_.nonEmpty)
      .map(_.split("\\|"))
      .map(item => {
        val tableName    = item(0)
        val columnName   = item(1)
        val dataType     = item(2)
        val dataTypeArgs = if (item.length >= 4) Some(item(3).split(",").toSeq) else None
        val dataTypeSpec = if (item.length >= 5) Some(item(4).split(",").toSeq) else None
        DataTypeMap(tableName, columnName, dataType, dataTypeArgs, dataTypeSpec)
      })
    HiveToHiveParser(skipPattern = skipContent, postMaskKeyWords = postMaskKeys, dataTypeMap = dataTypemap, preMaskKeyWords = preMaskKeys)
  }

  def getOadwCombinedSchemaParquetMap(sparkSession: SparkSession, runtimeVariables: RuntimeVariables): Map[String, HiveColumnDefinition] = {
    val oadwRV: OADWRuntimeVariables = OADWRuntimeVariables(runtimeVariables)
    val schemaInput                  = OADWRuntimeVariables.getOadwSchemaInput(oadwRV)
    HiveParquetMapper.getTNameToParquetLoc(OADWSchema.OADW_COMBINED_SCHEMA, schemaInput, sparkSession)
  }

  def getExternalTableNames(sparkSession: SparkSession, parquetMap: Map[String, HiveColumnDefinition]) = {
    val allTables = parquetMap.keySet.toList
    val externalTables = allTables.filter(tableName => {
      val parquetLocation = parquetMap(tableName).parquetLocation.toLowerCase
      parquetLocation.contains("/ii/") || parquetLocation.contains("/cdr_be/") || parquetLocation.contains("/ecdr/") || parquetLocation.contains("/oadw_ref/")
    })
    externalTables
  }

  def combineTableAndHiveStats(sparkSession: SparkSession, tableStats: Dataset[StatsSchemaFromDB]): Dataset[StatsSchema] = {
    import sparkSession.implicits._

    val oadwLines     = ResourceHelper.readLinesFromStream(OADWSchema.OADW_COMBINED_SCHEMA)
    val resultFromHql = OadwStatsUtils.calculateStatsFromHql(oadwLines).toDF
    // logger.warn(oadwLines.mkString("\n").substring(1, 1000))
    // logger.warn(resultFromHql.collect().mkString("\n"))
    logger.warn("Number of table from hql: " + resultFromHql.collect().size)
    // find table stats with emptyParquet

    val tableNamesWithEmptyParquet = tableStats.filter(stat => stat.column_name == "empty_parquet").map(tbl => tbl.table_name).collect()
    val tableStatsWithParquet = tableStats.filter(stat => stat.column_name != "empty_parquet")


    val tableWithoutParquetCombinedStats =
      resultFromHql
        .filter($"table_name".isin(tableNamesWithEmptyParquet:_*))
        .select(
          $"column_name",
          $"table_name",
          lit("TABLE").as("table_type"),
          lit(0).as("max_string_length"),
          lit(0).as("null_count"),
          lit(0).as("non_null_count"),
          $"data_type",
          lit(0).as("default_count"),
          lit(null).as("default_value"),
          $"precision_value",
          lit(0).as("total_count"),
          $"length",
          $"scale"
        ).as[StatsSchema]

    val tablesWithParquetCombineStats = tableStatsWithParquet
      .as("rfs")
      .join(resultFromHql.as("rfh"), (lower($"rfs.table_name") === lower($"rfh.table_name")) && (lower($"rfs.column_name") === lower($"rfh.column_name")), "left")
      .select(
        $"rfs.column_name",
        $"rfs.table_name",
        $"rfs.table_type",
        $"rfs.max_string_length",
        $"rfs.null_count",
        $"rfs.non_null_count",
        $"rfh.data_type",
        $"rfs.default_count",
        $"rfs.default_value",
        $"rfh.precision_value",
        $"rfs.total_count",
        $"rfh.length",
        $"rfh.scale"
      )
      .as[StatsSchema]

    tableWithoutParquetCombinedStats.union(tablesWithParquetCombineStats).as[StatsSchema]
  }
}

case class EmptyParquet(
  empty_parquet: String
)

case class StatsSchemaFromDB(
  table_name: String,
  column_name: String,
  null_count: Long,
  non_null_count: Long,
  default_count: Option[Long],
  default_value: String,
  total_count: Long,
  table_type: String = "TABLE",
  max_string_length: java.lang.Integer = null)


case class StatsSchema(
  table_name: String,
  column_name: String,
  null_count: Long,
  non_null_count: Long,
  default_count: Option[Long],
  default_value: String,
  total_count: Long,
  table_type: String = "TABLE",
  max_string_length: java.lang.Integer = null,
  data_type: String,
  length: java.lang.Integer = null,
  precision_value: java.lang.Integer = null,
  scale: java.lang.Integer = null)

case class StatsFromHQL(
  column_name: String,
  data_type: String,
  length: java.lang.Integer = null,
  precision_value: java.lang.Integer = null,
  scale: java.lang.Integer = null,
  table_name: String = null,
  tableorview: String = null)

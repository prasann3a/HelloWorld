package com.optum.oadw.utils

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{AnalysisException, DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import scala.collection.mutable.ListBuffer

object DataVerificationUtils {

  private val logger = LoggerFactory.getLogger(this.getClass)

  def getDataFrameFromParquetLoc(sparkSession: SparkSession, parquetLocation: String): DataFrame = {
    import sparkSession.implicits._
    try {
      sparkSession.read.parquet(parquetLocation)
    } catch {
      case e: AnalysisException => {
        sparkSession.emptyDataset[EmptyParquet].toDF
      }
    }
  }

  def verifyTableDataForNullPK(sparkSession: SparkSession, dataFrame: DataFrame, tableName: String, dataVerificationConfigFileName: String): List[String] = {

    val lines = ResourceHelper.readLinesFromStream(dataVerificationConfigFileName)
    val pkVerificationIssues: ListBuffer[String] = new ListBuffer[String]

    for (line <- lines) {
      val data = line.split("\\|")
      val verificationTableName = data(0)
      val verificationColumnName = data(1)

      if (tableName.toLowerCase == verificationTableName.toLowerCase) {
        pkVerificationIssues += verifyTableColumnDataForNullPK(sparkSession, dataFrame, verificationTableName.toLowerCase, verificationColumnName.toLowerCase)
      }
    }

    // returns a seq of all Null PK data verification issues in this table
    pkVerificationIssues.filter(_.nonEmpty).toList
  }

  def verifyTableColumnDataForNullPK(sparkSession: SparkSession, dataFrame: DataFrame, tableName: String, columnName: String): String = {
    import sparkSession.implicits._

    logger.warn(s" == Processing Null PK Data Verification for $tableName on column $columnName" )
    val verification_columns = columnName.split(",").map(m => col(m)) // convert string to array then to columns
    val nullPKRowCount = dataFrame
      .select(verification_columns: _*)
      .filter(row => row.anyNull)
      .count

    // return 1 if there are null PK issues to aggregate the errors at the upper level
    if (nullPKRowCount > 0) {
      val error = s" == Data Verification Error for table ${tableName}: ${columnName} has null values!"
      logger.warn(error)
      error
    } else ""
  }

  def verifyTableDataForUniqueness(sparkSession: SparkSession, dataFrame: DataFrame, tableName: String, dataVerificationConfigFileName: String): List[String] = {

    val lines = ResourceHelper.readLinesFromStream(dataVerificationConfigFileName)
    val uniquenessVerificationIssues: ListBuffer[String] = new ListBuffer[String]

    for (line <- lines) {
      val data = line.split("\\|")
      val verificationTableName = data(0)
      val verificationColumnName = data(1)

      if (tableName.toLowerCase == verificationTableName.toLowerCase) {
        uniquenessVerificationIssues += verifyTableColumnDataForUniqueness(sparkSession, dataFrame, verificationTableName.toLowerCase, verificationColumnName.toLowerCase)
      }
    }
    // returns a set of all Uniqueness data verification issues in this table
    uniquenessVerificationIssues.filter(_.nonEmpty).toList
  }

  def verifyTableColumnDataForUniqueness(sparkSession: SparkSession, dataFrame: DataFrame, tableName: String, columnName: String): String = {
    import sparkSession.implicits._

    logger.warn(s" == Processing Uniqueness Data Verification for $tableName on column $columnName")
    val verification_columns = columnName.split(",").map(m => col(m)) // convert string to array then to columns
    val tableRowCount = dataFrame.count
    val columnDistinctRowCount = dataFrame
      .select(verification_columns: _*)
      .distinct()
      .count

    // return 1 if there are uniqueness issues to aggregate the errors at the upper level
    if (tableRowCount != columnDistinctRowCount) {
      val error = s" == Data Verification Error for table ${tableName}: ${columnName} is not unique!"
      logger.warn(error)
      error
    } else ""
  }
}

case class DataVerificationSchema(table_name: String, column_name: String)
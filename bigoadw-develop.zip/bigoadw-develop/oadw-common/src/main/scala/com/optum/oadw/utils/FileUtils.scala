package com.optum.oadw.utils

import java.io.{BufferedWriter, File, FileWriter, IOException}

import org.slf4j.LoggerFactory

object FileUtils {
  val DOCTYPE = "<!DOCTYPE html>"
  private val log =  LoggerFactory.getLogger(this.getClass)

  def getFileExtension(file: String): String = {
    val length = file.length
    file.substring(file.lastIndexOf(".") + 1, length)
  }

  def loadContentFromUrl(url: String): String = {

    log.info(s"Reading content from $url")
    val source = scala.io.Source.fromURL(url)
    try {
      val content = source.mkString
      if (content.startsWith(DOCTYPE)) {
        throw new Exception(s"$DOCTYPE not allowed in parsed content. Content downloaded from $url")
      } else {
        content
      }
    } finally {
      source.close()
    }
  }

  def getFileName(path: String): String = {
    path.split("/").last
  }

  def writeContentAsFile(content: String, fileName: String, extension: String, relativePath: String,
                         absoluteBasePath: String, isAppend: Boolean = false): Unit = {
    try {
      val url = s"${stripProtocol(ensureTrailingCharacter(absoluteBasePath, '/'))}$relativePath/$fileName.$extension"
      val file = new File(url)
      val bw = new BufferedWriter(new FileWriter(file, isAppend))
      bw.write(content)
      bw.close()
    } catch {
      case e@(_: IOException | _) =>
        log.error(s"Unable to write file $fileName.$extension", e)
        throw e
    }
  }

  def stripProtocol(location: String): String = {
    val fileProtocol = "file://"
    if (location.startsWith(fileProtocol)) {
      location.replace(fileProtocol, "")
    } else {
      location
    }
  }

    def ensureTrailingCharacter(path: String, ch: Char): String = {
    if (path.last.equals(ch)) {
      path
    } else {
      path.concat(ch.toString)
    }
  }

  def ensureNonTrailingCharacter(path: String, ch: Char): String = {
    if (path.last.equals(ch)) {
      path.dropRight(1)
    } else {
      path
    }
  }

  def replaceFileExtension(fileName: String, newExtension: String): String = {
    fileName.substring(0, fileName.lastIndexOf(".")+1).concat(newExtension)
  }

  def isFileExists(path: String): Boolean = {
    try {
      val file = new File(path)
      file.exists() && !file.isDirectory
    } catch {
      case e @ (_ : java.io.IOException | _ : Exception) =>
        log.error(s"Unable to check whether file at $path exists", e)
        throw e
    }
  }

  def getFilesMatchingPattern(pattern: String, dir: String): Array[File] = {
    try {
      val directory = new File(dir)
      directory.listFiles.filter(_.getName.startsWith(pattern))
    } catch {
      case e @ (_ : java.io.IOException | _ : Exception) =>
        log.error(s"Unable to fetch files from $dir", e)
        throw e
    }
  }

  def getParentDirPath(path: String): String = {
    path.substring(0, path.lastIndexOf("/"))
  }

  def ensureDirExists(path: String): Unit = {
    try {
      val directory = new File(path)
      directory.mkdirs()
    } catch {
      case e @ (_ : java.io.IOException | _ : Exception) =>
        log.error(s"Unable to create directory at $path", e)
        throw e
    }
  }
}
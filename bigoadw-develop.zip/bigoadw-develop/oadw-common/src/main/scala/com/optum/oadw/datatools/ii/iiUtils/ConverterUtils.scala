package com.optum.oadw.datatools.ii.iiUtils

import com.optum.oap.constants.II
import com.optum.oap.sparklib.HDFSUtils
import com.optum.oap.utils.FileUtils
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.slf4j.LoggerFactory

import java.text.SimpleDateFormat
import java.util.Date

object ConverterUtils {
  private val log = LoggerFactory.getLogger(this.getClass)

  def readAllConfig(resourcePath: String): Map[String, Seq[ColumnDataTypeMapping]] = {
    log.warn("Resource path: " + resourcePath)
    val iStream = this.getClass.getResourceAsStream(resourcePath)
    scala.io.Source.fromInputStream(iStream).getLines.foldLeft(Map.empty[String, Seq[ColumnDataTypeMapping]]) {
      case (mapResult, configLine) =>
        if (configLine.isEmpty || configLine.startsWith("/**") || configLine.startsWith("tableName")) {
          mapResult
        } else {
          val configParts = configLine.split("\\|")

          val tableName = configParts(0).trim.toLowerCase
          val columnName = configParts(1).replaceAll("`", "").trim.toLowerCase
          val dataType = configParts(2).trim.toLowerCase

          val dataTypeSpec = if (configParts.size == 4 && configParts(3).trim.nonEmpty) {
            try {
              configParts(3).trim.split(",").map(_.trim.toInt).toSeq
            } catch {
              case e: Exception =>
                log.error("Error while reading config: " + tableName + " : " + columnName)
                throw e
            }
          } else List.empty[Int]

          val col = ColumnDataTypeMapping(columnName, dataType, dataTypeSpec)

          val fullList = mapResult.get(tableName).map(l => l :+ col).getOrElse(Seq(col))

          mapResult + (tableName -> fullList)
        }
    }
  }

  def getIIFileNameNormalized(fileName: String): String = {
    if (fileName.startsWith("t_")) fileName.split("_").drop(3).mkString("_") else fileName.split("_").drop(2).mkString("_")
  }

  def getBZ2FileNameNormalized(fileName: String): String = {
    fileName.split("_").drop(2).mkString("_").split("\\.").head
  }

  def stripFileExtension(fullFileName: String): String = {
    fullFileName.split("\\.").head
  }

  def getLatestDateDir(allDateDirsUnderProcessId: Map[String, String]): Option[(String, String)] = {
    if (allDateDirsUnderProcessId.isEmpty) {
      None
    } else {
      val latestDate = allDateDirsUnderProcessId.map(dateDir => (dateDir._1, strToDate(dateDir._1))).toSeq.maxBy(f => f._2)
      Some(latestDate._1, allDateDirsUnderProcessId(latestDate._1))
    }
  }

  private def strToDate(strDate: String): Date = {
    val sdf = new SimpleDateFormat("yyyyMMdd")
    sdf.parse(strDate)
  }

  def getEmptyParquetFilesPath(basePath: String, clientIdOrBucket: String, env: String): String = {
    val client = if (clientIdOrBucket.size == 7) clientIdOrBucket.toUpperCase else clientIdOrBucket
    s"${FileUtils.ensureTrailingCharacter(basePath, '/')}${client}/$env/external/ii/${II.DEFAULT_PROCESSID}/${II.DEFAULT_DATESTAMP}"
  }

  def clearTargetDir(pathForBZ2Files: String, fs: FileSystem): Unit = {
    val targetPath = pathForBZ2Files.split("/").dropRight(1).mkString("/").concat("/data")
    log.warn(s"Clearing out $targetPath")
    HDFSUtils.deleteFrom(targetPath, isRecursive = true, fs)
  }

  def getDestinationDirForModelFromBz2Location(bz2filePath: String, modelName: String): String = {
    bz2filePath.split("/").dropRight(2).mkString("", "/", "/").concat("data/").concat(modelName)
  }

  /** path convention -> /basePath/clientId/env/external/ii/processId/dateStamp/landed */
  def getBz2HDFSPathForProcessIdAndInstance(basePath: String, clientId: String, env: String, processId: String, dateStamp: String): Option[String] = {
    Some(s"${getBz2HDFSPathForProcessId(basePath, clientId, env, processId)}$dateStamp/landed")
  }

  def getBz2HDFSPathForProcessId(basePath: String, clientId: String, env: String, processId: String): String = {
    s"${getBasePathClient(basePath, clientId, env)}$processId/"
  }

  def getBasePathClient(basePath: String, clientId: String, env: String): String = {
    s"${getClientDirPath(basePath, clientId)}$env/external/ii/"
  }

  def getClientDirPath(basePath: String, clientId: String): String = {
    s"${FileUtils.ensureTrailingCharacter(basePath, '/')}${clientId.toUpperCase}/"
  }

  def getFilePathForProcessIdOnly(basePath: String, clientId: String, env: String, processId: String, fs: FileSystem): Option[String] = {
    val pIdPath = getBz2HDFSPathForProcessId(basePath, clientId, env, processId)
    val allDateDirsUnderProcessId = HDFSUtils.getAllSubDirs(fs, pIdPath)
    val latestDateDir = getLatestDateDir(allDateDirsUnderProcessId)

    if (latestDateDir.isEmpty) {
      throw IIParquetConversionException(s"There are no date directories under $pIdPath")
    }

    Some(s"$pIdPath${latestDateDir.get._1}/landed")
  }

  def getFilePathForInstanceOnly(dateStamp: String, regexPathAllPIDs: String, fs: FileSystem): Option[String] = {
    val datePath = HDFSUtils.getHDFSPathsForPattern(fs, regexPathAllPIDs).flatten(pathTuple => {
      HDFSUtils.getAllSubDirsWithModificationDate(fs, pathTuple._2).filter(p => p._1.equalsIgnoreCase(dateStamp)).values
    }).maxBy(m => m._2)._1

    Some(s"$datePath/landed")
  }

  def getBz2HDFSPathNoArgs(regexPathAllPIDs: String, fs: FileSystem): Option[String] = {
    val fullPath = HDFSUtils.getHDFSPathsForPattern(fs, regexPathAllPIDs).flatten(pathTuple => {
      HDFSUtils.getAllSubDirsWithModificationDate(fs, pathTuple._2).values
    }).maxBy(m => m._2)._1

    if (HDFSUtils.ifPathExists(fs, fullPath)) {
      Some(s"$fullPath/landed")
    } else {
      None
    }
  }

  def getModelSchema(modelColumns: Seq[ColumnDataTypeMapping]): StructType = {
    StructType(
      modelColumns.map(colConfig => {
        getStructFieldForColumn(colConfig)
      })
    )
  }

  private def getStructFieldForColumn(colConfig: ColumnDataTypeMapping): StructField = {
    try {
      StructField(colConfig.columnName.toLowerCase, getSparkDataTypeFromColConfig(colConfig.dataType, colConfig.dataTypeSpec))
    } catch {
      case e: Exception => throw IIParquetConversionException(s"Error creating struct field for column ${colConfig.columnName.toLowerCase} and type ${colConfig.dataType}")
    }
  }

  def getSparkDataTypeFromColConfig(dataType: String, dataTypeSpec: Seq[Int]): DataType = {
    dataType.toLowerCase match {
      case "int" => IntegerType
      case "decimal" => if (dataTypeSpec.nonEmpty) {
        val arg1 = dataTypeSpec.head
        val arg2 = if (dataTypeSpec.lengthCompare(2) == 0) dataTypeSpec(1) else 0
        DecimalType(arg1, arg2)
      } else throw new IllegalArgumentException("Decimal type should at least have precision")
      case "boolean" => BooleanType
      case "string" => StringType
      case "timestamp" => TimestampType
      case "date" => DateType
      case "bigint" => LongType
      case "float" => FloatType
      case "double" => DoubleType
      case "varchar" => StringType
      case invalidDataType => throw new IllegalArgumentException(s"Invalid datatype $invalidDataType")
    }
  }

  def getDataFrameForDoublePipeBz2(filePath: String, sparkSession: SparkSession, schema: StructType): Option[DataFrame] = {
    import sparkSession.implicits._
    val df = sparkSession.read
      .option("header", "true")
      .option("inferSchema", "false")
      .option("delimiter", "\t")
      .option("quote", "")
      .csv(sparkSession.sparkContext.textFile(filePath, 1)
        .map(line => line.replace("\t", " ").replace("||", "\t")).toDS()) // split doesn't allow empty string between ||

    val lowerCaseColsDF = df.toDF(df.columns.map(_.toLowerCase.replaceAll("\\$", "")): _*)

    val validationResult = Validation.validateSchema(lowerCaseColsDF.schema, schema, filePath)

    if (validationResult) {
      val colMap = schema.map(s => (s.name, s.dataType)).map(sf => functions.col(sf._1).cast(sf._2).as(sf._1))
      Some(lowerCaseColsDF.select(colMap: _*))
    } else None
  }

  def getConfigMap(configFile: String, models: Option[Seq[String]], excludeModels: Option[Seq[String]]): Map[String, Seq[ColumnDataTypeMapping]] = {
    val allConfig = readAllConfig(s"/ii/$configFile")

    val includeModels = models.getOrElse(allConfig.keySet).map(m => m.toLowerCase).toSeq
    val excludeWithModels = excludeModels.getOrElse(Seq.empty[String]).map(m => m.toLowerCase)

    allConfig
      .filter(kv => includeModels.contains(kv._1))
      .filter(kv => !excludeWithModels.contains(kv._1))
  }

  def getBz2Files(filesMap: Map[String, String], models: Option[Seq[String]], excludeModels: Option[Seq[String]], dropTokenCount: Int): Map[String, String] = {
    val includeModels = models.getOrElse(filesMap.keySet).map(f => f.toLowerCase.split("_").drop(dropTokenCount).mkString("_").split("\\.").head).toSeq
    val excludeWithModels = excludeModels.getOrElse(Seq.empty[String]).map(f => f.toLowerCase.split("_").drop(dropTokenCount).mkString("_").split("\\.").head)

    filesMap
      .filter(kv => includeModels.contains(kv._1.toLowerCase.split("_").drop(dropTokenCount).mkString("_").split("\\.").head))
      .filter(kv => !excludeWithModels.contains(kv._1.toLowerCase.split("_").drop(dropTokenCount).mkString("_").split("\\.").head))
  }

  def getSynonymMap(configFile: String): Map[String, String] = {
    val iiSynonymFile = "/ii/ii_synonyms-" + configFile.split("-").drop(1).mkString("-")
    val inputStream = this.getClass().getResourceAsStream(iiSynonymFile)
    scala.io.Source.fromInputStream(inputStream).getLines.filter(_.nonEmpty).map(_.split("\\|")).filter(_.length == 2).map(item => item(1).split("_").drop(2).mkString("_").toLowerCase -> item(0).toLowerCase).toMap
  }

  def getReverseSynonymMap(configFile: String): Map[String, String] = {
    val iiSynonymFile = "/ii/ii_synonyms-" + configFile.split("-").drop(1).mkString("-")
    val inputStream = this.getClass().getResourceAsStream(iiSynonymFile)
    scala.io.Source.fromInputStream(inputStream).getLines.filter(_.nonEmpty).map(_.split("\\|")).filter(_.length == 2).map(item => item(0).toLowerCase -> item(1).split("_").drop(2).mkString("_").toLowerCase).toMap
  }
}

case class TableColumnDataTypeMapping(tableName: String, columnName: String, dataType: String, dataTypeSpec: List[Int] = List.empty[Int])
case class ColumnDataTypeMapping(columnName: String, dataType: String, dataTypeSpec: Seq[Int] = Seq.empty[Int])

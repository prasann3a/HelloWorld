package com.optum.oadw.utils

object Resource {
  def using[A <: AutoCloseable, B](resource: A)(f: A => B): B = {
    try {
      f(resource)
    }
    finally {
      resource match {
        case c : AutoCloseable => c.close()
        case null =>
      }
    }
  }

  def using[A, B](resource: A)(closer: A => Unit)(f: A => B): B = {
    try {
      f(resource)
    }
    finally {
      if(resource != null) {
        closer(resource)
      }
    }
  }
}
package com.optum.oadw.utils

import java.io.{File, PrintWriter}

import scala.io.Source



object ResourceHelper {
  def readLinesFromStream(resourceName: String): List[String] = {
    val resourceStream = this.getClass.getClassLoader.getResourceAsStream(resourceName)
    scala.io.Source.fromInputStream(resourceStream).getLines().toList
  }

  def readSqlBlocksFromStream(resourceName: String, separator: String): List[String] = {
    val resourceStream = this.getClass.getClassLoader.getResourceAsStream(resourceName)
    scala.io.Source.fromInputStream(resourceStream).getLines().filterNot(_.startsWith("--")).mkString("\n").split(separator).toList
  }

  def groupLinesByTable[T](lines: List[T], separator: T): List[List[T]] = {
    lines.span( _ != separator) match {
      case (head, _ :: tail) => head :: groupLinesByTable(tail, separator)
      case (head, _) => List(head)
    }
  }

  def cleanFileBySearchItem(inputFilePath: String, searchString: String): Unit = {
    val inputFile = Source.fromFile(inputFilePath)
    val fileContents = inputFile.mkString
    val fileContentsCleansed = fileContents.replaceAll(searchString, "")

    val newFilePath = s"${inputFilePath}_Temp.txt"
    val newFile = new PrintWriter(new File(newFilePath))

    newFile.println(fileContentsCleansed.trim())
    newFile.close()
    inputFile.close()

    new File(newFilePath).renameTo(new File(inputFilePath))
  }

  def deleteLinesBySearchItem(inputFilePath: String, searchString: String): Unit = {
    val inputFile = Source.fromFile(inputFilePath)
    val newFilePath = s"${inputFilePath}_Temp.txt"
    val newFile = new PrintWriter(new File(newFilePath))

    inputFile
      .getLines
      .filter(l => (l.toLowerCase.equals(l.toLowerCase.replaceAll(searchString.toLowerCase, ""))))
      .foreach(newFile.println(_))

    newFile.close()
    inputFile.close()

    new File(newFilePath).renameTo(new File(inputFilePath))
  }

  def getTablesAndViews(line: List[String]): List[String] = {
    line.map(_.trim).filterNot(_.isEmpty)
      .filterNot(_.matches("(?i)CREATE\\s+DATABASE\\s+IF\\s+NOT\\s+EXISTS\\s+.*|.*--.*"))
      .filter(_.matches("(?i)CREATE\\s+EXTERNAL\\s+TABLE\\s+IF\\s+NOT\\s+EXISTS\\s+.*|(?i)CREATE\\s+VIEW\\s+IF\\s+NOT\\s+EXISTS\\s+.*"))
      .map(line => line.split('.')(1)
        .replace("(","")
        .replaceAll("(?i)\\s+AS", "")
        .trim.toLowerCase)
  }
}

package com.optum.oadw.utils

import com.optum.oadw.constants.II
import com.optum.oap.utils.FileUtils.ensureNonTrailingCharacter

case class OADWSchemaInput(
  clientId: String,
  environment: String,
  instance: String,
  streamId: String,
  cdrCycle: String,
  cdrLevel: String,
  dryRun: Boolean = false,
  updateCurrent: Boolean = false,
  iiDateStamp: String = II.DEFAULT_DATESTAMP,
  iiProcessId: String = II.DEFAULT_PROCESSID,
  oadwRefVersion: String,
  protocol: String,
  refBucket: String = null,
  bucket: String) {

  private val getBaseDbName: String = s"${clientId.toLowerCase}_${environment.toLowerCase}"

  val streamSuffix: String = if (streamId == "default") "" else "_" + streamId

  val getOadwDbName: String = {
    if (!updateCurrent)
      s"${getBaseDbName}_oadw_${cdrCycle}_$instance$streamSuffix"
    else
      s"${getBaseDbName}_oadw"
  }

  private val getBasePath: String = {
    ensureNonTrailingCharacter(
      if (protocol.toLowerCase == "s3") s"s3://$bucket"
      else s"/optum/data_factory/$clientId",
      '/')
  }

  private val getBasePathRef: String = {
    ensureNonTrailingCharacter(
      if (protocol.toLowerCase == "s3") s"s3://$refBucket"
      else s"/optum/data_factory/default",
      '/')
  }

  val replacementMap: Map[String, String] =
    Map(
      "db_name"          -> getOadwDbName,
      "basePath"         -> getBasePath,
      "basePathRef"      -> getBasePathRef,
      "env"              -> environment,
      "client"           -> clientId.toUpperCase,
      "process_id"       -> iiProcessId,
      "dateStamp"        -> iiDateStamp,
      "instance"         -> instance,
      "stream_id"        -> streamId,
      "cdr_cycle"        -> cdrCycle,
      "cdr_level"        -> cdrLevel,
      "oadw_ref_version" -> oadwRefVersion
    )

  def replace(input: String, useLowerCase: Boolean = false): String =
    if (!useLowerCase) {
      ConfigFuncs.replaceTokens(input, replacementMap)
    } else {
      val lowerCaseReplacementMap = replacementMap.map { case (key, value) => key.toLowerCase -> value }
      ConfigFuncs.replaceTokens(input, lowerCaseReplacementMap)
    }
}

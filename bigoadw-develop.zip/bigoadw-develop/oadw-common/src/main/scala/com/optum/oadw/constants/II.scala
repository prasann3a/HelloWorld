package com.optum.oadw.constants

object II {
  val DEFAULT_DATESTAMP = "nodate"
  val DEFAULT_PROCESSID = "0"
  val VERSION = "8.1"
  val CONFIG_FILE = "IIExternalDataTypeMap-8-1.txt"
}
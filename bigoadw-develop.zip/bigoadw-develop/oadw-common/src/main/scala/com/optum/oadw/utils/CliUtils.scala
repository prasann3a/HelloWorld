package com.optum.oadw.utils

import org.rogach.scallop.ScallopOption

object CliUtils {

  def getOptionalString(opt: ScallopOption[String]): Option[String] = {
    if(opt.isSupplied) {
      Some(opt())
    } else {
      None
    }
  }

  def getOptionalSeq(opt: ScallopOption[String]): Option[Seq[String]] = {
    if(opt.isSupplied) {
      val inputArr = opt().split(",").filter(!_.isEmpty)
      Some(inputArr.map(s => s.trim).toSeq)
    } else {
      None
    }
  }

  def getOptionalSeqFromString(input: String): Option[Seq[String]] = {
    if( (input != null && ! input.trim.isEmpty)) {
      val inputArr = input.split(",").filter(!_.isEmpty)
      Some(inputArr.map(s => s.trim).toSeq)
    } else {
      None
    }
  }

  def getOptionalDouble(opt: ScallopOption[Double]): Option[Double] = {
    if(opt.isSupplied) {
      Some(opt())
    } else {
      None
    }
  }

  def getOptionalInt(opt: ScallopOption[Int]): Option[Int] = {
    if(opt.isSupplied) {
      Some(opt())
    } else {
      None
    }
  }
}

case class ExitCode(code: Int)

object ExitCode {
  val SUCCESS = ExitCode(0)
  val FAILURE = ExitCode(1)
}
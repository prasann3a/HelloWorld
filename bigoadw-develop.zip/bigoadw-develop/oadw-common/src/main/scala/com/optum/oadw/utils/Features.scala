package com.optum.oadw.utils

/**
  * List of available features toggles
  */
object Features extends Enumeration{
  type Feature = Value

  val DynamicPartition = Value("dynamicPartition")
  val SDOH = Value("sdoh")
  val MSDRG = Value("msdrg")
  val EtlFilters = Value("etlFilters")
}
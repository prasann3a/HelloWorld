package com.optum.oadw.utils

import java.sql.Timestamp

import com.optum.oadw.common.models.OADWRuntimeVariables
import com.optum.oadw.utils.PartitionManager._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.slf4j.LoggerFactory

import scala.reflect.runtime.universe._

case class partition_data(oadwschema: String = null, groupid: String = null, instance: String = null, environment: String = null, is_delta: Boolean = false, table_name: String = null, table_size: Long = 0L, partitions: BigInt = 1, creation_dtm: Timestamp = new java.sql.Timestamp((new java.util.Date).getTime), is_dynamic_partition_enabled: Boolean = false, dynamic_partition_size: Long = 0L)

class PartitionManager(runtimeVariables: OADWRuntimeVariables, partitionDetailLocation: String, partitionSize: Long){
  val (groupId,env,delta,release,instanceId,streamId,oadwDb) = (runtimeVariables.clientId,runtimeVariables.environment,(runtimeVariables.cdrLevel == "ecdr"),runtimeVariables.cdrRelease,runtimeVariables.instance,runtimeVariables.streamId,runtimeVariables.oadwDb)

  def getPartitions(sparkSession: SparkSession): Unit = {
    if (dynamicPartitionFeatureEnabled && partitionSize > 0) {
      logger.warn(s"getting the partition details, Partitionsize: $partitionSize, partitionBuildsPath: $partitionDetailLocation, oadwDbName: $oadwDb")

      //    read the json
      import sparkSession.implicits._
      val df = readPartitionDetailsJson(s"$partitionDetailLocation/*.json", sparkSession, groupId)

      tablePartitionsMap ++= df.where($"groupid" === groupId and $"environment" === env and $"is_delta" === delta).groupBy($"table_name").agg(greatest(lit(2),ceil(avg("table_size")/(partitionSize)))).collect().map(row => row.getString(0) -> row.getLong(1).toInt).toMap
    }
  }

  def setPartitions(tblPartitionMap: Map[String,Long], sparkSession: SparkSession) = {
    //place to persist the map in a db
    logger.warn(s"setting the partition details")

    import sparkSession.implicits._


    val existingDf = readPartitionDetailsJson(s"$partitionDetailLocation/$oadwDb.json", sparkSession, groupId).where(!$"table_name".isin(tablePartitionsMap.keySet.toList:_*))

    logger.warn(s"number of records in the existing dataframe: ${existingDf.cache().count()}")

    tblPartitionMap.map{case(tblName,size) => partition_data(oadwschema = oadwDb.toLowerCase,table_name = tblName,table_size = size,environment = env,groupid = groupId,instance = instanceId, is_delta = delta,partitions = getPartition(tblName),is_dynamic_partition_enabled = dynamicPartitionFeatureEnabled, dynamic_partition_size = partitionSize)}.toSeq.toDF.select(columnsLst:_*).union(existingDf.select(columnsLst:_*)).coalesce(1).write.mode(SaveMode.Overwrite).format("json").save(s"$partitionDetailLocation/$oadwDb.json")
  }

}

object PartitionManager {

  private val logger = LoggerFactory.getLogger(this.getClass)
  val tablePartitionsMap = scala.collection.mutable.Map.empty[String, Int]
  val dynamicPartitionFeatureEnabled = FeatureManager.Instance.isEnable(Features.DynamicPartition)
  val columnsLst = classAccessors[partition_data].map(trmname => col(trmname.name.toString))

  def apply(runtimeVariables: OADWRuntimeVariables, partitionDetailLocation: String, partitionSize: Long) = new PartitionManager(runtimeVariables, partitionDetailLocation, partitionSize)

  private def readPartitionDetailsJson(partitionBuildsPath: String, sparkSession: SparkSession, groupId: String) = {
    import sparkSession.implicits._
      try {
        sparkSession.read.format("json").load(s"$partitionBuildsPath").where($"groupid" === groupId).select(columnsLst:_*).as[partition_data]
      } catch {
        case e: Exception => {
          logger.warn(s"$partitionBuildsPath not found")
          logger.warn(e.getMessage)
          sparkSession.emptyDataset[partition_data]
        }
      }
  }

  def classAccessors[T: TypeTag]: List[MethodSymbol] = typeOf[T].members.collect {
    case m: MethodSymbol if m.isCaseAccessor => m
  }.toList

  def getPartition(tableName: String) = tablePartitionsMap.get(tableName).getOrElse(0)
}

package com.optum.oadw.datatools.ii.iiUtils

import com.optum.oap.sparklib.HDFSUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.io.IOUtils
import org.apache.hadoop.io.compress.{CompressionCodec, CompressionCodecFactory, CompressionOutputStream}
import org.slf4j.LoggerFactory

import java.io.{InputStream, OutputStream}
import java.net.URI

object BzipUtils {

  private val log = LoggerFactory.getLogger(this.getClass)

  def deCompressBz2(uri: String): Unit = {

    val conf: Configuration = new Configuration()
    val fs: FileSystem = FileSystem.get(URI.create(uri), conf)
    val inputPath: Path = new Path(uri)
    val factory: CompressionCodecFactory = new CompressionCodecFactory(conf)
    val codec: CompressionCodec = factory.getCodec(inputPath)
    if (codec == null) {
      log.error("No codec found for " + uri)
      throw BzipUtilsException("No codec found for " + uri)
    }
    log.warn("Starting decompress for " + uri)
    val outputUri: String = CompressionCodecFactory.removeSuffix(uri, codec.getDefaultExtension())
    var in: InputStream = null
    var out: OutputStream = null
    try {
      in = codec.createInputStream(fs.open(inputPath))
      out = fs.create(new Path(outputUri))
      IOUtils.copyBytes(in, out, conf)
    } catch {
      case e: Exception =>
        IOUtils.closeStream(in)
        IOUtils.closeStream(out)
        log.error("Compress of bz2 file failed")
        e.printStackTrace()
        throw BzipUtilsException("Compress of bz2 file failed " + uri)
    }
    IOUtils.closeStream(in)
    IOUtils.closeStream(out)
    log.warn("Completed decompress for " + uri)

  }

  def deleteFile(uri: String): Unit ={

    val conf: Configuration = new Configuration()
    val fs: FileSystem = FileSystem.get(URI.create(uri), conf)
      try {
        HDFSUtils.deleteFrom(uri, isRecursive = false, fs)
      } catch {
        case e: Exception =>
          log.error("Deletion of " + uri + " failed")
          e.printStackTrace()
          throw BzipUtilsException("Deletion of " + uri + " failed")
      }
    log.warn("Deletion of " + uri + " Completed")
  }

  def compressToBz2(uri: String): Unit = {

    val inFilePath = uri
    val outFilePath = uri + ".bz2"
    val conf:Configuration = new Configuration()
    var in:InputStream = null
    var out:OutputStream = null
    log.warn("Compression for " + uri + " started")
    try {
      val fs:FileSystem = FileSystem.get(URI.create(inFilePath), conf)
      val inputPath:Path = new Path(inFilePath)
      in = fs.open(inputPath)
      val outFile:Path = new Path(outFilePath)
      if (fs.exists(outFile)) {
        log.error("Output file already exists")
        throw BzipUtilsException("Output file already exists")
      }
      out = fs.create(outFile)

      // bzip2 compression
      val factory:CompressionCodecFactory = new CompressionCodecFactory(conf)
      val codec:CompressionCodec = factory.getCodecByClassName("org.apache.hadoop.io.compress.BZip2Codec")
      val compressionOutputStream:CompressionOutputStream = codec.createOutputStream(out)

      try {
        IOUtils.copyBytes(in, compressionOutputStream, conf)
        compressionOutputStream.finish()
      }catch {
        case e: Exception =>
          IOUtils.closeStream(in)
          IOUtils.closeStream(compressionOutputStream)
          log.error("Compress of bz2 file failed")
          e.printStackTrace()
          throw BzipUtilsException("Compress of bz2 file failed " + uri)
      }

      IOUtils.closeStream(in)
      IOUtils.closeStream(compressionOutputStream)
    } catch {
      case e: Exception =>
        log.error("Compress of bz2 file failed")
        e.printStackTrace()
        throw BzipUtilsException("Compress of bz2 file failed " + uri)
    }
    log.warn("Compression for " + uri + " completed")
  }

}


final case class BzipUtilsException(private val message: String = "") extends Exception(message)
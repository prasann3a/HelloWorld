package com.optum.oadw.utils

import com.optum.oadw.constants.OADWSchema
import org.apache.spark.sql.{AnalysisException, SparkSession}
import com.optum.oap.sparklib.HDFSUtils
import org.slf4j.LoggerFactory

import scala.collection.mutable.{ArrayBuffer, ListBuffer}

case class HiveColumnDefinition(columns: Array[String], parquetLocation: String, isDistinct: Boolean = false, statement: String = "", whereExpression: String = "", groupByCols: Array[String] = null, selectQuery: String = "")
case class HiveViewDefinition(columns: Array[String], tableName: String, isDistinct: Boolean = false, statment: String = "", whereExpression: String = "", groupByCols: Array[String] = null)
case class ColumnDef(columnName: String, selectExpression: String, emptyColumnExpression: String)

object HiveParquetMapper {
  private val log =  LoggerFactory.getLogger(this.getClass)

  private def getCastType(columnName: String, columnDef: String): String ={
    val lowerColumnDef = columnDef.toLowerCase()
    if (lowerColumnDef.contains("boolean")){
      s"cast(null as boolean) $columnName"
    } else if(lowerColumnDef.contains("varchar") || lowerColumnDef.contains("string")){
      s"cast(null as string) $columnName"
    } else if(lowerColumnDef.contains("decimal") || lowerColumnDef.contains("double")) {
      s"cast(null as decimal) $columnName"
    } else if(lowerColumnDef.contains("int")){
      s"cast(null as int) $columnName"
    } else if(lowerColumnDef.contains("time")){
      s"cast(null as timestamp) $columnName"
    }
    else columnName
  }

  private object RegexMap {
    val groupBy = "(?i)\\s+group\\s+by\\s+"
    val createExternalTable = "(?i)create\\s+external\\s+table"
    val storedAsParquet = "(?i)stored\\s+as\\s+parquet"
  }

  def getTNameToParquetLoc(filename: String, schemaInput: OADWSchemaInput, session: SparkSession = null): Map[String, HiveColumnDefinition] = {
    val fileSchema = ResourceHelper.readLinesFromStream(filename)
    val allContent = fileSchema.mkString("\n")

    allContent
      .toLowerCase
      .split(RegexMap.createExternalTable)
      .filter(_.contains("stored as parquet"))
      .par
      .map(definition => {
        val tableDef        = definition.split(";")(0).trim
        val tableDefLines   = tableDef.lines.toList
        val tableName       = tableDefLines.head.split('.')(1).stripSuffix("(").trim.toUpperCase
        val parquetLocationLower = schemaInput.replace(tableDefLines.last.stripPrefix("location '").stripSuffix("'").trim, true)
        val parquetLocationToken = parquetLocationLower.splitAt(parquetLocationLower.lastIndexOf('/'))
        val parquetLocation = parquetLocationToken._1 + parquetLocationToken._2.toUpperCase()

        val columnString = tableDef.split("\\(", 2)(1).split(RegexMap.storedAsParquet)(0).trim.stripSuffix(")")
        val columns = columnString
          .split(",\\s*\n")
          .map(col => {
            val trimmedCol = col.trim
            val hiveColumnName = trimmedCol.split("\\s+")(0).trim
            val columnName = hiveColumnName.replaceAll("`", "")
            val emptyColumnExpr = getCastType(columnName, trimmedCol)
            if (trimmedCol.contains("boolean")) {
              ColumnDef(columnName, s"cast($hiveColumnName as boolean) $columnName", emptyColumnExpr)
            } else if (hiveColumnName.contains("`")) {
              ColumnDef(columnName, s"$hiveColumnName $columnName", emptyColumnExpr)
            }
            else {
              ColumnDef(columnName, columnName, emptyColumnExpr)
            }
          })
        // if sparkSession is passed, check the column list from the parquet.
        // Since there are cases where there are extra columns in hive, this will only select columns which are available
        // log.warn(s"Reading parquet from location $parquetLocation")
        // don't need to read schema for oadw tables, as parquet and hive always matches in these case
        val parquetColumns: Array[String] = if (session != null && !parquetLocation.contains("/oadw/")) {
          try{
            val pSchema = session.read.parquet(parquetLocation).schema
            pSchema.fieldNames.map(f => f.toLowerCase)
          } catch {
            case e: AnalysisException => {
              log.warn(s"Error: ${e.getMessage()} while reading parquet $parquetLocation")
              columns.map(_.emptyColumnExpression)
            }
          }
        } else {
          columns.map(_.columnName)
        }
        val matchingColumns = columns.filter(col => parquetColumns.contains(col.columnName)).map(_.selectExpression)
        val nonExistingColumns = columns.filter(col => !parquetColumns.contains(col.columnName)).map(_.emptyColumnExpression)

        val finalColumns = matchingColumns ++ nonExistingColumns
        tableName.toUpperCase -> HiveColumnDefinition(columns = finalColumns, parquetLocation = parquetLocation, statement = definition)
      })
      .toList
      .toMap[String, HiveColumnDefinition]
  }

  def checkIfPathExistsInHdfs(filePath: String): Boolean = {
    val fs          = HDFSUtils.getHDFSFileSystem(filePath)
    HDFSUtils.ifPathExists(fs, filePath)
  }

  def readColumns(columnStr: String): Array[String] = {
    var tokens = new ArrayBuffer[String]
    var current = new StringBuilder("")
    var parenthesesCount = 0
    columnStr.foreach(char => {
      if (char == ',' && parenthesesCount == 0){
        tokens += current.toString()
        current = new StringBuilder("")
      } else {
        if (char == '(') { parenthesesCount = parenthesesCount + 1 }
        if (char == ')') { parenthesesCount = parenthesesCount - 1 }
        current.append(char)
      }
    })
    if (current.nonEmpty){
      tokens.append(current.toString())
    }
    tokens.map(_.trim).toArray
  }

  def checkContainsUsingRegex(input: String, regex: String): Boolean ={
    if (input.split(regex).length == 1) {
      false
    } else {
      true
    }
  }

  private def getVNameToParquetLoc(filename: String, schemaInput: OADWSchemaInput, session: SparkSession = null): Map[String, HiveViewDefinition] = {
    val fileSchema = ResourceHelper.readLinesFromStream(filename)
    val allContent = fileSchema.mkString("\n")

    allContent
      .split(";")
      // This will only work with simple views with direct select from one table, as there will be single parquet
      // to select from. If there are joins, those should be converted to the actual table
      .filter(defs => defs.toLowerCase.contains("create view"))
      .map(vwCode => {
        //val vwCode = vwCodeActual.toLowerCase
        val viewName = vwCode.split("(?i)create\\s+view\\s+if\\s+not\\s+exists\\s+\\{\\{db_name\\}\\}.")(1).split("(?i)\\s+as\\s+")(0).trim
        val viewColumns = vwCode.split("(?i)as\\s+select")(1).split("(?i)\\s+from\\s+")(0).trim
        val columns = readColumns(viewColumns).map(colSel => colSel.replace("distinct", "").trim)

        val tableName = vwCode.split("(?i)\\s+from\\s+\\{\\{db_name\\}\\}.")(1).split("\\s+")(0)
        val whereCond = if (vwCode.toLowerCase.contains("where")) {
          vwCode.split("(?i)\\s+where\\s+")(1).trim
        } else {
          ""
        }
        val groupBy = if (checkContainsUsingRegex(vwCode, RegexMap.groupBy)) {
          readColumns(vwCode.split(RegexMap.groupBy)(1))
        } else {
          null
        }
        val hasDistinct = vwCode.contains("distinct")
        viewName.toUpperCase -> HiveViewDefinition(columns, tableName.toUpperCase, hasDistinct, statment = vwCode, whereExpression=whereCond, groupByCols = groupBy)
      }).toMap[String, HiveViewDefinition]
  }



  def getViewNameToParquet(schemaInput: OADWSchemaInput, session: SparkSession): Map[String, HiveViewDefinition] = {

    getVNameToParquetLoc(OADWSchema.OADW_COMBINED_SCHEMA, schemaInput, session)

  }

  def getViewParquet(schemaInput: OADWSchemaInput, sparkSession: SparkSession, tableDefs: Map[String, HiveColumnDefinition]): Map[String, HiveColumnDefinition] = {
    val viewDefs = getViewNameToParquet(schemaInput, sparkSession)
    // convert all the viewDefs to tableDefs, which have the exact parquet location
    viewDefs.map(vw => {
      val viewVal = vw._2
      val dependentTable = viewVal.tableName
      if (tableDefs.contains(dependentTable)) {
        val parquetLoc = tableDefs(dependentTable).parquetLocation
        val finalCols = viewVal.columns.map(vCol=>{
          val lowerVCol = vCol.toLowerCase.trim
          if (lowerVCol == "modified_date"){
            "cast(null as timestamp) modified_date"
          } else if(lowerVCol == "row_source") {
            "cast(null as string) row_source"
          } else {
            vCol
          }
        })
        vw._1 -> HiveColumnDefinition(columns = finalCols, parquetLocation = parquetLoc, isDistinct = viewVal.isDistinct, statement = viewVal.statment, whereExpression = viewVal.whereExpression, groupByCols = viewVal.groupByCols)
      }
      else {
        log.warn(s"Dependent table $dependentTable not found for view ${vw._1}.")
        "" -> HiveColumnDefinition(null, "")
      }
    })
  }

  def getTableNameToParquet(
    schemaInput: OADWSchemaInput,
    session: SparkSession): Map[String, HiveColumnDefinition] = {
    getTNameToParquetLoc(OADWSchema.OADW_COMBINED_SCHEMA, schemaInput, session) ++ getTNameToParquetLoc(OADWSchema.CDR_CLASS_SCHEMA, schemaInput, session)
  }

  def getTableAndViewParquetMap(schemaInput: OADWSchemaInput, sparkSession: SparkSession): Map[String, HiveColumnDefinition] = {
    val tableParquetMap = getTableNameToParquet(schemaInput, sparkSession)
    val viewMap = getViewParquet(schemaInput, sparkSession, tableParquetMap)
    tableParquetMap ++ viewMap
  }
}

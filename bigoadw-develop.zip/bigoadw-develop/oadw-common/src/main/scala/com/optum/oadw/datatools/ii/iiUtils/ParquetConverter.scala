package com.optum.oadw.datatools.ii.iiUtils

import com.optum.oadw.constants.II
import com.optum.oap.sparklib.{HDFSUtils, SparkUtils}
import com.optum.oap.utils.ExitCode
import com.optum.oap.utils.Resource._
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.SaveMode
import org.slf4j.LoggerFactory

import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

case class ParquetConverter(input: ToParquetInput) {

  import ConverterUtils._
  import HDFSUtils._
  import ParquetConverter._

  def convert: ExitCode = {
    import scala.concurrent.ExecutionContext.Implicits.global

    val fs = HDFSUtils.getHDFSFileSystem(input.basePath)

    val saveMode = SaveMode.Overwrite

    val mapIIFilesConfig = getConfigMap(input.configFile, input.models, input.excludeModels)
    val configFileModel = mapIIFilesConfig.keys.head
    val dropTokenCount = if (configFileModel.startsWith("t_")) 3 else 2
    val reverseIISynonymMap: Map[String, String] = ConverterUtils.getReverseSynonymMap(input.configFile)

    using(SparkUtils.createSparkSession(SparkUtils.getAppName(s"ii-parquet-converter"), false, true))(session => {

      // Hardcoding to HDFS protocol until this system is rigged to support s3 for ii ingestion
      EmptyParquetUtils(input.clientId, input.env, input.createEmptyParquet, input.basePath, II.VERSION, mapIIFilesConfig, "hdfs", session).handleEmptyParquet

      if (!input.emptyParquetOnly) {
        val pathForBZ2Files = getPathForFiles(input.basePath, input.clientId, input.dateStamp, input.env, input.processId, fs)

        if (pathForBZ2Files.isDefined) {
          Validation.pathValidation(pathForBZ2Files.get, input.clientId, input.env)

          val allBZ2Files = getBz2Files(getAllFiles(fs, pathForBZ2Files.get).filter(x => x._1.toLowerCase.contains(".txt.bz2")), input.models, input.excludeModels, dropTokenCount)

          if (input.models.isEmpty && input.excludeModels.isEmpty) {
            clearTargetDir(pathForBZ2Files.get, fs)
          }

          Validation.fileLevelValidation(session, allBZ2Files.keySet, mapIIFilesConfig.keySet, pathForBZ2Files.get, input.controlsTotal, input.configFile)

          val result = Future.traverse(allBZ2Files) {
            kv =>
              Future {
                val fileNameUpper = kv._1.toUpperCase
                val fileNameUpperNoExt = stripFileExtension(fileNameUpper)
                val bz2FilePath = kv._2
                val normalizedBZ2FileName = getBZ2FileNameNormalized(kv._1.toLowerCase)
                val synonymMapmodel = if(reverseIISynonymMap.contains(normalizedBZ2FileName)) reverseIISynonymMap(normalizedBZ2FileName) else normalizedBZ2FileName
                log.warn(s"Processing file $fileNameUpper with location $bz2FilePath")
                val iiModelName = if(mapIIFilesConfig.contains("l1_ii_" + synonymMapmodel)) "l1_ii_" + synonymMapmodel else "l2_ii_" + synonymMapmodel
                val schema = getModelSchema(mapIIFilesConfig(iiModelName))
                val dfOpt = getDataFrameForDoublePipeBz2(bz2FilePath, session, schema)

                if (dfOpt.isDefined) {
                  try {
                    val destLocation = getDestinationDirForModelFromBz2Location(bz2FilePath, getBZ2FileNameNormalized(fileNameUpperNoExt))
                    Validation.pathValidation(destLocation, input.clientId, input.env)
                    session.sparkContext.setJobDescription(s"Processing $fileNameUpperNoExt")
                    dfOpt.get.coalesce(input.partitionsCount).write.mode(saveMode).format("parquet").save(destLocation)
                    log.warn("Running count validation between parquet and bz2 ")
                    Validation.validateParquetRowsCountToBZ2(bz2FilePath, destLocation, session)
                  } catch {
                    case e: Exception =>
                      throw IIParquetConversionException(s"Error while processing $fileNameUpperNoExt: ${e.getMessage}")
                  }
                } else {
                  log.warn(s"Schema issues while processing $fileNameUpperNoExt. All errors till now are: ${Validation.schemaValidationErrors.mkString("\n")}")
                }
              }
          }
          Await.result(result, Duration.Inf)

          logAnySchemaIssues
        }
      }
    })
    ExitCode.SUCCESS
  }

  /**
    * Strategy to fetch II External files for client - (should be simpler once queue listener is in place and correct arguments are expected at all times) -
    * There are basic validations to see if ii data is available for client or not or whether empty ii data is required (processId zero) - In such we give None as bz2 files path indicating that empty parquet files should be used
    * 1. Validate if client directory is present and process id is not zero. If either condition fails then None (hint for empty parquet files).
    * 2. If process id is defined and is not non-zero, but dateStamp is not defined - fetch all dateStamp directories under process id directory and fetch the latest one. If unable to find one, error out.
    * 3. If process id is not defined but dateStamp is - fetch all directories for the given dateStamp, sort by latest modifiedDate and fetch the latest. If unable to find one, error out.
    * 4. If both process id and date stamp are provided - fetch the correct directory. If unable to find one, error out.
    * 5. If both process id and date stamp are not defined - fetch all process id directories and get the latest directory by sorting with dateStamp and modificationDate. If unable to find one, give None(hint for empty parquet files).
    * Conventions -
    * Bz2 files location - basePath/{{clientId}}/{{env}}/external/ii/{{processId}}/{{dateStamp}}/landed
    * Parquet files location - basePath/{{clientId}}/{{env}}/external/ii/{{processId}}/{{dateStamp}}/data
    * Hive schema deployment can be much simplified if we persist to basePath/{{clientId}}/{{env}}/external/ii/data [something to consider]
    */
  private def getPathForFiles(basePath: String, clientId: String, dateStamp: Option[String], env: String, processId: Option[String], fs: FileSystem): Option[String] = {

    if (Validation.validateRequirements(processId, clientId, basePath, env, fs)) {
      val regexPathAllPIDs = getBasePathClient(basePath, clientId, env).concat(s"/*")

      val finalPath = if (processId.isDefined && !processId.get.equalsIgnoreCase("0") && dateStamp.isEmpty) {
        getFilePathForProcessIdOnly(basePath, clientId, env, processId.get, fs)

      } else if (processId.isEmpty && dateStamp.isDefined) {
        getFilePathForInstanceOnly(dateStamp.get, regexPathAllPIDs, fs)

      } else if (processId.isDefined && dateStamp.isDefined) {
        getBz2HDFSPathForProcessIdAndInstance(basePath, clientId, env, processId.get, dateStamp.get)

      } else {
        getBz2HDFSPathNoArgs(regexPathAllPIDs, fs)
      }

      if (finalPath.isDefined && HDFSUtils.ifPathExists(fs, finalPath.get)) {
        log.warn(s"Final resolved path to look for bz2 files: $finalPath")
        finalPath
      } else {
        throw IIParquetConversionException(s"Resolved path $finalPath does not exists")
      }
    } else {
      None
    }
  }

  private def logAnySchemaIssues: Unit = {
    if (Validation.schemaValidationErrors.nonEmpty && Validation.schemaValidationErrors.lengthCompare(0) != 0) {
      throw IIValidationException(s"${Validation.schemaValidationErrors.mkString("---* Schema Errors *---", "\n", "---**---")}")
    }
  }
}

object ParquetConverter {
  private val log = LoggerFactory.getLogger(this.getClass)
}

case class ToParquetInput(excludeModels: Option[Seq[String]], models: Option[Seq[String]], basePath: String, env: String, clientId: String, dateStamp: Option[String], processId: Option[String], configFile: String,
                          controlsTotal: Option[String] = None, createEmptyParquet: Boolean = false, emptyParquetOnly: Boolean = false, partitionsCount: Int)

final case class IIParquetConversionException(private val message: String = "") extends Exception(message)
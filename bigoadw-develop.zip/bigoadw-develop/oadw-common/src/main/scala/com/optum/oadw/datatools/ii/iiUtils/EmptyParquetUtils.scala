package com.optum.oadw.datatools.ii.iiUtils

import com.amazonaws.services.s3.AmazonS3ClientBuilder
import com.amazonaws.services.s3.model.ObjectMetadata
import com.optum.oap.constants.II
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.slf4j.LoggerFactory

import java.io.{ByteArrayInputStream, InputStream, PrintWriter}
import java.nio.charset.StandardCharsets
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

case class EmptyParquetUtils(clientIdOrBucket: String, env: String, isCreateEmptyParquet: Boolean, baseDestPath: String, iiDBVersion: String, mapIIFilesConfig: Map[String, Seq[ColumnDataTypeMapping]], protocol: String, sparkSession: SparkSession) {

  import ConverterUtils._
  import EmptyParquetUtils._

  def handleEmptyParquet: Unit = {
    if (isCreateEmptyParquet) {
      import scala.concurrent.ExecutionContext.Implicits.global

      val metaDataFileName = "ii_dbversion.txt"
      val iiDBVersionFileLocation = getEmptyParquetFilesPath(baseDestPath, clientIdOrBucket, env)

      if (protocol.toLowerCase == "s3") {
        val s3Client = AmazonS3ClientBuilder.standard.withRegion("us-east-1").build
        val stream: InputStream = new ByteArrayInputStream(iiDBVersion.getBytes(StandardCharsets.UTF_8.name))
        val key: String = iiDBVersionFileLocation.replace("s3://" + clientIdOrBucket+"/", "") + "/" + metaDataFileName
        logger.warn(s"S3 METADATA WRITE: Writing ${iiDBVersion} to Bucket: ${clientIdOrBucket} - S3 Key: ${key}")
        s3Client.putObject(clientIdOrBucket, key, stream, new ObjectMetadata())
      } else if (protocol.toLowerCase == "hdfs") {
        val conf = new Configuration()
        val fs = FileSystem.get(conf)
        val output = fs.create(new Path(iiDBVersionFileLocation + "/" + metaDataFileName), true)
        val writer = new PrintWriter(output)
        writer.write(iiDBVersion)
        writer.close()
      } else throw new IllegalArgumentException("invalid protocol. Must be s3 or hdfs")

      val futureWriteList = mapIIFilesConfig.map(modelConfig =>
        Future {
          val modelSchema = getModelSchema(modelConfig._2)

          val nullRow = getSingleNullRow(modelConfig._2.length)
          val nullRdd = sparkSession.sparkContext.parallelize(Seq(nullRow))
          val df = sparkSession.createDataFrame(nullRdd, modelSchema).limit(0)
          val modelName = getIIFileNameNormalized(modelConfig._1)
          val location = s"${getEmptyParquetFilesPath(baseDestPath, clientIdOrBucket, env)}/data/${modelName.toUpperCase}"

          Validation.iiDestinationValidation(location, clientIdOrBucket, env, processId = II.DEFAULT_PROCESSID, dateStamp = II.DEFAULT_DATESTAMP, protocol)

          logger.warn(s"Writing empty df for model $modelName at $location")
          df.coalesce(1).write.mode(SaveMode.Overwrite).parquet(location)
        })

      Await.result(Future.sequence(futureWriteList), Duration.Inf)

    }
  }

  private def getSingleNullRow(colCount: Int): Row = {
    val nullSeq = (1 to colCount).map(i => null)
    Row.fromSeq(nullSeq)
  }
}

object EmptyParquetUtils {
  private val logger = LoggerFactory.getLogger(this.getClass)
}
package com.optum.oadw.utils

import scala.collection.immutable
import scala.util.matching.Regex

object ConfigFuncs {

  /**
    * Find {{patterns}} and replace with token values from one or more maps.
    * @param template pattern to be processed.
    * @param replacementValues map of token to replacement strings.
    * @return
    */
  def replaceTokens(template: String, replacementValues: immutable.Map[String, String]*): String = {
    require(template != null)

    val combinedReplacementValues =
      replacementValues
        .foldRight(immutable.Map.empty[String, String])((m, accum) => accum ++ m)

    val pattern = """\{\{(.+?)\}\}""".r

    def replacer(m: Regex.Match): String = {
      val key = m.group(1)
      combinedReplacementValues.get(key) match {
        case Some(str) =>
          Regex.quoteReplacement(replace(str))
        case None => throw new IllegalArgumentException(
          s"Replacement value '$key' in template '$template' was not found. " +
            s"Valid keys are: ${combinedReplacementValues.keys.mkString(", ")}")
      }
    }

    def replace(t: String): String = {
      pattern.replaceAllIn(t, replacer _)
    }

    replace(template)
  }
}
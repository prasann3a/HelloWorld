package com.optum.oadw.constants

object OADWSchema {
  val II_EXTERNAL_FILE = "ii_external_schema.hql"
  val OADW_SCHEMA = "oadw_schema.hql"
  val CDR_SCHEMA = "cdr_schema.hql"
  val CDR_CLASS_SCHEMA = "cdr_class_schema.hql"
  val OADW_DATA_TYPE_MAP = "oadw_data_type_map.txt"
  val CDR_OADW_MAPPING_FILE = "cdr_synonym.json"
  val CDR_BE_OVERRIDES_FILE = "cdr_be_overrides.hql"
  val REF_SCHEMA = "oadw_reference_schema.hql"
  val EPSILON_OADW_SCHEMA = "epsilon_oadw_schema.hql"
  val EPSILON_OADW_TABLE_LIST = "epsilon_oadw_table_list.txt"
  val OADW_COMBINED_SCHEMA = "oadw_combined_schema.hql"
  val OADW_DATA_VERIFICATION_NULL_PK_CONFIG_FILE = "oadw_data_verification_null_pk_config_file.txt"
  val OADW_DATA_VERIFICATION_UNIQUENESS_CONFIG_FILE = "oadw_data_verification_uniqueness_config_file.txt"
}
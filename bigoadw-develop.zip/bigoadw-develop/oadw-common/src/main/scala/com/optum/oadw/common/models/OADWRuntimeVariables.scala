package com.optum.oadw.common.models

import com.optum.oadw.utils.OADWSchemaInput
import com.optum.oap.sparkdataloader.{EmptyRuntimeVariables, RuntimeVariables}
import org.apache.spark.sql.{DataFrame, SparkSession}
import scala.reflect.runtime.universe.TypeTag

case class OADWRuntimeVariables(clientId: String = "",
                                parmOcuMonths: Int = 0,
                                environment: String = "",
                                instance: String = "",
                                streamId: String = "",
                                oadwDb: String = "",
                                partitionMultipler: Int = 0,
                                iiProcessId: String = "",
                                iiDateStamp: String = "",
                                cdrCycle: String = "",
                                cdrRelease: String = "",
                                cdrLevel: String = "",
                                oadwRefVersion: String = "",
                                protocol: String = "hdfs",
                                bucket: Option[String] = None,
                                refBucket: Option[String] = None,
                                extras: Map[String, String] = Map.empty,
                                setupDtm: java.time.LocalDateTime = null,
                                oadwAutoBcLimit: Long = 0L,
                                runDataVerification: Boolean = false) extends RuntimeVariables

case class BasePaths(baseRefPath: String = "", baseOadwPath: String = "", baseCdrPath: String = "", baseIIPath: String = "")

object OADWRuntimeVariables {
  def apply(runtimeVariables: RuntimeVariables): OADWRuntimeVariables = runtimeVariables.asInstanceOf[OADWRuntimeVariables]
  def apply(runtimeVariables: EmptyRuntimeVariables): OADWRuntimeVariables = new OADWRuntimeVariables()
  def getOadwSchemaInput(runtimeVariables: OADWRuntimeVariables): OADWSchemaInput = {
    OADWSchemaInput(
      clientId = runtimeVariables.clientId,
      environment = runtimeVariables.environment,
      instance = runtimeVariables.instance,
      streamId = runtimeVariables.streamId,
      cdrCycle = runtimeVariables.cdrCycle,
      cdrLevel = runtimeVariables.cdrLevel,
      iiDateStamp = runtimeVariables.iiDateStamp, // has default value of "nodate"
      iiProcessId = runtimeVariables.iiProcessId, // has default value of "0"
      oadwRefVersion = runtimeVariables.oadwRefVersion,
      protocol = runtimeVariables.protocol,
      bucket = runtimeVariables.bucket.getOrElse(""),
      refBucket = runtimeVariables.refBucket.getOrElse("")
    )
  }
  def getBasePath(runtimeVariables: OADWRuntimeVariables): BasePaths =
    runtimeVariables.protocol.toLowerCase match {
      case "s3"            => BasePaths(
        baseOadwPath = s"s3://${runtimeVariables.bucket.get}/${runtimeVariables.environment}/oadw/${runtimeVariables.cdrCycle}/${runtimeVariables.instance}/${runtimeVariables.streamId}",
        baseRefPath = s"s3://${runtimeVariables.refBucket.get}/${runtimeVariables.environment}/oadw_ref/${runtimeVariables.oadwRefVersion}",
        baseCdrPath =  s"s3://${runtimeVariables.bucket.get}/${runtimeVariables.environment}/${runtimeVariables.cdrLevel}/${runtimeVariables.cdrCycle}/${runtimeVariables.instance}/default",
        baseIIPath = s"s3://${runtimeVariables.bucket.get}/${runtimeVariables.environment}/external/ii/${runtimeVariables.iiProcessId}/${runtimeVariables.iiDateStamp}/data")
      case "hdfs"          => BasePaths(
        baseOadwPath =  s"/optum/data_factory/${runtimeVariables.clientId}/${runtimeVariables.environment}/oadw/${runtimeVariables.cdrCycle}/${runtimeVariables.instance}/${runtimeVariables.streamId}",
        baseRefPath =  s"/optum/data_factory/default/${runtimeVariables.environment}/oadw_ref/${runtimeVariables.oadwRefVersion}",
        baseCdrPath = s"/optum/data_factory/${runtimeVariables.clientId}/${runtimeVariables.environment}/${runtimeVariables.cdrLevel}/${runtimeVariables.cdrCycle}/${runtimeVariables.instance}/default/",
        baseIIPath = s"/optum/data_factory/${runtimeVariables.clientId}/${runtimeVariables.environment}/external/ii/${runtimeVariables.iiProcessId}/${runtimeVariables.iiDateStamp}/data"
      )
      case invalidProtocol => throw new IllegalArgumentException(s"Invalid protocol $invalidProtocol")
    }

  def getCdrDataFrame[T <: Product with Serializable: TypeTag](sparkSession: SparkSession, runtimeVariables: RuntimeVariables, parquetName: String): DataFrame = {
    import sparkSession.implicits._

    val oadwRuntimeVariables = OADWRuntimeVariables(runtimeVariables)
    if(!oadwRuntimeVariables.protocol.isEmpty){
      sparkSession.read.parquet(s"${getBasePath(oadwRuntimeVariables).baseCdrPath}/$parquetName")
    } else {
      Seq.empty[T].toDF
    }
  }

  def getIIDataFrame[T <: Product with Serializable: TypeTag](sparkSession: SparkSession, runtimeVariables: RuntimeVariables, parquetName: String): DataFrame = {
    import sparkSession.implicits._

    val oadwRuntimeVariables = OADWRuntimeVariables(runtimeVariables)
    if(!oadwRuntimeVariables.protocol.isEmpty) {
      sparkSession.read.parquet(s"${getBasePath(oadwRuntimeVariables).baseIIPath}/$parquetName")
    } else {
      Seq.empty[T].toDF
    }
  }

  def getRefDataFrame[T <: Product with Serializable: TypeTag](sparkSession: SparkSession, runtimeVariables: RuntimeVariables, parquetName: String): DataFrame = {
    import sparkSession.implicits._

    val oadwRuntimeVariables = OADWRuntimeVariables(runtimeVariables)
    if(!oadwRuntimeVariables.protocol.isEmpty) {
      sparkSession.read.parquet(s"${getBasePath(oadwRuntimeVariables).baseRefPath}/$parquetName")
    } else {
      Seq.empty[T].toDF
    }
  }
}
package com.optum.oadw.datatools.ii.iiUtils

import com.optum.oap.sparklib.HDFSUtils
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.StructType
import org.slf4j.LoggerFactory

import java.io.{BufferedReader, InputStreamReader}
import scala.collection.mutable
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

object Validation {

  val schemaValidationErrors = mutable.ArrayBuffer[String]()
  val hiveBZ2Mismatch = new mutable.ArrayBuffer[String]
  private val log = LoggerFactory.getLogger(this.getClass)

  def fileLevelValidation(spark: SparkSession, allBZ2Files: Set[String], mapIIFilesConfig: Set[String], basePathBz2: String, controlsTotal: Option[String] = None, configFile: String): Unit = {

    val allBZ2FilesNameNormalized = allBZ2Files.map(f => ConverterUtils.getBZ2FileNameNormalized(f).toLowerCase).toSeq.sorted
    val iiSynonymMap: Map[String, String] = ConverterUtils.getSynonymMap(configFile)
    val mapIIFilesConfigNameNormalized = mapIIFilesConfig.map(f => {
      if (iiSynonymMap.contains(ConverterUtils.getIIFileNameNormalized(f).toLowerCase))
        iiSynonymMap(ConverterUtils.getIIFileNameNormalized(f).toLowerCase)
      else
      ConverterUtils.getIIFileNameNormalized(f).toLowerCase
    }).toSeq.sorted

    val missingFilesDiff = mapIIFilesConfigNameNormalized.diff(allBZ2FilesNameNormalized)
    val extraFilesDiff = allBZ2FilesNameNormalized.diff(mapIIFilesConfigNameNormalized)

    if (missingFilesDiff.nonEmpty) {
      throw IIValidationException(s"Missing files: ${missingFilesDiff.mkString(", ")}")
    }

    if (extraFilesDiff.nonEmpty) {
      throw IIValidationException(s"Extra files: ${extraFilesDiff.mkString(", ")}")
    }

    val zippedFileNames = allBZ2FilesNameNormalized.zip(mapIIFilesConfigNameNormalized)
    val mismatchedNames = zippedFileNames.map(files => {
      if (!files._1.equalsIgnoreCase(files._2)) s"File name ${files._1} does not match expected name ${files._2}" else ""
    }).mkString("\n").trim()

    val controlsValidationMsg = validateControlsFile(controlsTotal, basePathBz2, spark, mapIIFilesConfig.size)

    if (mismatchedNames.nonEmpty || controlsValidationMsg.nonEmpty) {
      throw IIValidationException(s"$mismatchedNames\n\n$controlsValidationMsg")
    }
  }

  /**
    * If processId is 0 or client directory does not exist then give empty files path - no II files present for this client
    * If environment directory does not exist then error out - client directory is present but environment missing, maybe someone should look for ii files
    **/
  def validateRequirements(processId: Option[String], clientId: String, baseSourcePath: String, env: String, fs: FileSystem): Boolean = {
    val clientDirPath = ConverterUtils.getClientDirPath(baseSourcePath, clientId)
    if ((processId.isDefined && processId.get.equalsIgnoreCase("0")) || !HDFSUtils.ifPathExists(fs, clientDirPath)) {
      false
    }

    val envDirPath = s"${ConverterUtils.getClientDirPath(baseSourcePath, clientId)}$env"
    if (!HDFSUtils.ifPathExists(fs, clientDirPath)) {
      throw IIValidationException(s"Environment directory $envDirPath missing for client")
    }

    true
  }

  def validateSchema(actualSchema: StructType, expectedSchema: StructType, filePath: String): Boolean = {
    val expectedFields = expectedSchema.fieldNames.map(f => f.toLowerCase)
    val actualFields = actualSchema.fieldNames.map(f => f.toLowerCase)

    val missingFields = expectedFields.diff(actualFields)
    val extraFields = actualFields.diff(expectedFields)

    if (missingFields.nonEmpty) {
      schemaValidationErrors.append(s"Missing fields: ${missingFields.mkString(", ")} for file $filePath")
    }

    if (extraFields.nonEmpty) {
      schemaValidationErrors.append(s"Extra fields: ${extraFields.mkString(", ")} for file $filePath")
    }

    if (extraFields.nonEmpty || missingFields.nonEmpty) {
      false
    } else true
  }

  def iiDestinationValidation(path: String, clientId: String, env: String, processId: String, dateStamp: String, storageProtocol: String): Unit = {
    val expectedInPath = if (storageProtocol.equalsIgnoreCase("hdfs")) s"/optum/data_factory/${clientId.toUpperCase}/${env.toLowerCase}/external/ii/$processId/$dateStamp/data/"
    else s"/${env.toLowerCase}/external/ii/$processId/$dateStamp/data"

    /** If path does not match then fail immediately */
    if (!path.contains(expectedInPath)) {
      throw IIValidationException(s"Path for file(s) '$path' is wrong for given environment '$env', client '$clientId', processId '$processId' or dateStamp '$dateStamp'")
    }
  }

  def pathValidation(path: String, clientId: String, env: String): Unit = {
    if (!path.toLowerCase.contains(clientId.toLowerCase) || !path.toLowerCase.contains(env.toLowerCase)) {
      throw IIValidationException(s"Path for file(s) '$path' is wrong for given environment '$env' or client '$clientId'")
    }
  }

  def validateParquetRowsCountToBZ2(BZ2Path: String, parquetPath: String, session: SparkSession)= {
    val BZ2RowsCount = session.sparkContext.textFile(BZ2Path, 1).count()
    val parquetCount = session.read.parquet(parquetPath).count()
    /** parquet count will not contain header as a row*/
    if (BZ2RowsCount - 1 != parquetCount)
      throw IIValidationException(s"Rows count is not matching between parquet file $parquetPath and bz2 file $BZ2Path")
  }

  private def validateControlsFile(controlsTotalFileName: Option[String], basePath: String, session: SparkSession, expectedCount: Int): String = {
    val errors = mutable.ArrayBuffer[String]()
    import scala.concurrent.ExecutionContext.Implicits.global

    if (controlsTotalFileName.isDefined) {
      val seqFileTotals = loadControlTotalsFile(controlsTotalFileName.get, basePath)

      if (seqFileTotals.size != expectedCount) {
        errors.append(s"Count of records in controls file (${seqFileTotals.size}) does not match expected count of $expectedCount")
      } else {
        val result = Future.traverse(seqFileTotals) {
          f =>
            Future {

              try {
                val filePath = s"$basePath/${f.fileName}"

                val BZ2Rowscount = session.sparkContext.textFile(filePath, 1).count()

                if (BZ2Rowscount != f.count) {
                  log.warn("Count in controls file for "+ filePath + " does not match, trying to re-compress the file")
                  //decompress the file
                  BzipUtils.deCompressBz2(filePath)
                  //delete the existing bzip file
                  BzipUtils.deleteFile(filePath)
                  //compress the file again
                  BzipUtils.compressToBz2(filePath.replace(".bz2",""))
                  //delete the de-compressed file
                  BzipUtils.deleteFile(filePath.replace(".bz2",""))

                  val changedCount = session.sparkContext.textFile(filePath, 1).count()
                  if (changedCount != f.count) {
                    errors.append(s"Count for file $filePath did not match. Bz2 file count: $changedCount | Controls file count: ${f.count - 1}")
                  }
                }
              } catch {
                case e: Exception =>
                  errors.append(s"Error while counting records for file ${f.fileName}. Check if the path exists.")
              }
            }
        }
        Await.result(result, Duration.Inf)
      }
      if (errors.nonEmpty && errors.lengthCompare(0) != 0) {
        s"${errors.mkString("---* Count mismatch errors *---", "\n", "---**---")}"
      } else ""
    } else ""
  }

  private def loadControlTotalsFile(controlsTotalFileName: String, basePath: String): Seq[FileCount] = {
    val filePath = s"$basePath/$controlsTotalFileName"
    val optStream = getInputStreamForFile(filePath)

    if (optStream.isEmpty) {
      throw IIValidationException(s"Input stream not available for controls file path $filePath")
    }

    getAllFileCountsFromControl(optStream.get)
  }

  private def getInputStreamForFile(filePath: String): Option[BufferedReader] = {
    val path = new Path(filePath)
    val fs = HDFSUtils.getHDFSFileSystem(filePath)
    if (fs.exists(path)) {
      Some(new BufferedReader(new InputStreamReader(fs.open(path))))
    } else None
  }

  def getAllFileCountsFromControl(iStream: BufferedReader): Seq[FileCount] = {
    Stream.continually(iStream.readLine()).takeWhile(_ != null).filter(_.contains('|')).map(x => {
      val split = x.split("\\|")
      FileCount(split(0), split(1).toLong)
    })
  }
}

final case class IIValidationException(private val message: String = "") extends Exception(message)

case class FileCount(fileName: String, count: Long)
package com.optum.oadw.utils

import java.text.{ParsePosition, SimpleDateFormat}

object SystemUtils {
  def isCorrectDateFormat(dateStr: String, format: String): Boolean = {
    val sdf = new SimpleDateFormat(format)
    sdf.setLenient(false)
    sdf.parse(dateStr, new ParsePosition(0)) != null
  }
}
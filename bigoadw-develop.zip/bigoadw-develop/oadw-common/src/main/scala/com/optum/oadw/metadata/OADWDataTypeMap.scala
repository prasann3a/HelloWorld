package com.optum.oadw.metadata

import better.files.Resource
import com.optum.oadw.utils.Resource._

import scala.collection.mutable
import scala.io.Source

object OADWDataTypeMap {

  private val dataTypeMap = "OADWDataTypeMap.txt"

  lazy val tableColumnMapping: Seq[TableColumnMapping] = prepareTableColumnMap

  private def prepareTableColumnMap: Seq[TableColumnMapping] = {
    val records = mutable.ArrayBuffer[TableColumnMapping]()

    using(Resource.getAsStream(dataTypeMap))(inputStream => {
      Source.fromInputStream(inputStream).getLines().foreach(line => {
        val data = line.split("\\|")
        val tableName = data(0)
        val columnName = data(1)
        val dataType = data(2)
        records.append(TableColumnMapping(tableName, columnName, dataType))
      })
    })
    records.toSeq
  }

  def getColumnMapping(tableName: String): Map[String, String] = {
    tableColumnMapping.filter(_.tableName.equalsIgnoreCase(tableName)).map(x => x.columnName.toLowerCase -> x.dataType).toMap
  }
}

case class TableColumnMapping(tableName: String, columnName: String, dataType: String) {
  override def toString: String = s"""TableColumnMapping("$tableName", "$columnName", "$dataType")"""
}

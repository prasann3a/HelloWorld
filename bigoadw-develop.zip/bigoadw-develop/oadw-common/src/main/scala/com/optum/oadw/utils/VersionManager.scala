package com.optum.oadw.utils

import scala.io.Source

object VersionManager {

  private val properties = {

    val fileStream = getClass.getResourceAsStream("/version.properties")
    val lines = Source.fromInputStream(fileStream).getLines.toList
    Source.fromInputStream(fileStream).close

    lines
      .map(_.split("=")).map(a=>a(0)->a(1))
      .toMap
  }

  val RefVersion : String = properties("OADW_REF_VERSION").split("-")(0).replace(".","_")

  val OADWVersion : String = properties("OADW_VERSION")

  val CDRContractVersion : String = properties("CDR_CONTRACT")
}

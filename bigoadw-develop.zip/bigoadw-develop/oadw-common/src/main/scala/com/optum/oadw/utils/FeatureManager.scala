package com.optum.oadw.utils

import org.slf4j.LoggerFactory
import scala.collection.mutable

/**
  * Feature Manager Class is used to manage the enable/disable the features it is provided with,
  * For ex: we can disable trim_var_feature using the feature manager
  * The features are enabled by default
  */
class FeatureManager(featureSet : Enumeration) {

  private val logger = LoggerFactory.getLogger(this.getClass)
  private val featureMap: mutable.Map[Enumeration#Value, Boolean] = mutable.Map[Enumeration#Value,Boolean]()


  def EnabledFeatures: mutable.Map[Enumeration#Value, Boolean] = featureMap.filter(_._2)

  def DisabledFeatures: mutable.Map[Enumeration#Value, Boolean] = featureMap.filter(!_._2)
  def AllFeatures: mutable.Map[Enumeration#Value, Boolean] = featureMap

  featureSet.values.foreach(enable)

  def enable(features: String): Unit ={
      features
        .split(",")
        .map(featureSet.withName)
        .foreach(enable)
  }

  def disable(features: String): Unit ={
      features
        .split(",")
        .map(featureSet.withName)
        .foreach(disable)
  }

  def isEnable(feature: Enumeration#Value): Boolean = {
    featureMap(feature)
  }

  def enable(feature: Enumeration#Value): Unit ={
    featureMap(feature) = true
    logger.warn(s"Enable feature : $feature")
  }

  def disable(feature: Enumeration#Value): Unit ={
    featureMap(feature) = false
    logger.warn(s"Disable feature : $feature")
  }

}

/**
  * Default FeatureManager Instance
  * If we want to disable a feature, we need to pass it through command line argument
  */
object FeatureManager{
  val Instance = new FeatureManager(Features)
}
package com.optum.oadw.utils

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor

trait PasswordAccessor {
  protected val passwordKey: String

  protected def decryptPassword(encrypted: String): String = {
    val encryptor = new StandardPBEStringEncryptor()
    encryptor.setPassword(passwordKey)
    encryptor.decrypt(encrypted)
  }

  protected def encryptPassword(raw: String): String = {
    val encryptor = new StandardPBEStringEncryptor()
    encryptor.setPassword(passwordKey)
    encryptor.encrypt(raw)
  }
}

class MakePassword extends PasswordAccessor {
  protected val passwordKey = "qQmMWhWmCsfwK4yy"

  def run(args: Array[String]): Unit = {
    for (n <- args.indices) {
      val encrypted = encryptPassword(args(n))
      println(s"$n ${args(n)}=$encrypted")
    }
  }

  @deprecated("Replace encrypt usage with a secure alternative.")
  def encrypt(raw: String): String = encryptPassword(raw)

  @deprecated("Replace decrypt usage with a secure alternative.")
  def decrypt(password: String): String = decryptPassword(password)
}

object MakePassword {

  @deprecated("Replace encrypt usage with a secure alternative.")
  def encrypt(raw: String): String = (new MakePassword).encrypt(raw)

  @deprecated("Replace decrypt usage with a secure alternative.")
  def decrypt(password: String): String = (new MakePassword).decrypt(password)

  def main(args: Array[String]): Unit = {
    val app = new MakePassword
    app.run(args)
  }
}

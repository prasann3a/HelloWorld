-- This script adds list partitions to tables
-- This script needs to be executed after loading the oadw_reference tables listed in oadw_prereq_export_tables.txt and before the actual OADW export process starts.
call add_list_partitions(p_table => 'L2_PAT_PROC',p_part_src_tbl => 'L2_DICT_PROC',p_part_name_col => q'[code_type]',p_part_prefix => 'P_');
call add_list_partitions(p_table => 'L2_PAT_CLINICAL_EVENT',p_part_src_tbl => 'L4_MAP_EVENT_TYPE',p_part_name_col => 'EVENT_TYPE_CUI',p_part_prefix => 'P_');
call add_list_partitions(p_table => 'L2_PAT_DIAG',p_part_src_tbl => 'L2_DICT_DIAG',p_part_name_col => q'[substr(code_type,1,20) || '_' || substr(diag_cd,1,1)]',p_part_prefix => 'P_');
call add_list_partitions(p_table => 'L2_PAT_ASSESS_NUM',p_part_src_tbl => 'L1_MAP_OBSTYPE',p_part_name_col => 'OBSTYPE_CUI',p_part_prefix => 'P_');
call add_list_partitions(p_table => 'L2_PAT_ASSESS_NUM',p_part_src_tbl => 'L1_MAP_LAB',p_part_name_col => 'CUI',p_part_prefix => 'P_');
call add_list_partitions(p_table => 'L2_PAT_ASSESS_NUM',p_part_src_tbl => 'MD_DOMAIN_CONCEPT', p_part_name_col => 'CONCEPT_CUI',p_part_prefix => 'P_',p_filter => 'domain_cui = ''CH003715''');
call add_list_partitions(p_table => 'L2_PAT_ASSESS_QUAL',p_part_src_tbl => 'L1_MAP_OBSTYPE',p_part_name_col => 'OBSTYPE_CUI',p_part_prefix => 'P_');
call add_list_partitions(p_table => 'L2_PAT_ASSESS_QUAL',p_part_src_tbl => 'L1_MAP_LAB',p_part_name_col => 'CUI',p_part_prefix => 'P_');

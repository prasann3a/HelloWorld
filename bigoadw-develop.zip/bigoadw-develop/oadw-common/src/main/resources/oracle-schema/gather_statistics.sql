--https://docs.oracle.com/cd/B19306_01/appdev.102/b14258/d_stats.htm#i1055451

call dbms_stats.GATHER_SCHEMA_STATS(ownname => NULL, options => 'GATHER AUTO');

-- create oracle_stats table with null and non null columns

CREATE TABLE oracle_stats (
	TABLE_NAME VARCHAR2(255),
	COLUMN_NAME VARCHAR2(255),
	NULL_COUNT NUMERIC(19, 0),
	NON_NULL_COUNT NUMERIC(19, 0),
	TOTAL_COUNT NUMERIC(19, 0)
	)
	PCTFREE 0 NOLOGGING COMPRESS;

INSERT INTO oracle_stats
	(TABLE_NAME,COLUMN_NAME,NULL_COUNT,NON_NULL_COUNT,TOTAL_COUNT)
	SELECT
	    cs.TABLE_NAME,
        cs.COLUMN_NAME,
        cs.NUM_NULLS as NULL_COUNT,
        (ut.NUM_ROWS - cs.NUM_NULLS) as NON_NULL_COUNT,
        ut.NUM_ROWS as TOTAL_COUNT
    FROM USER_TAB_col_statistics cs, USER_TABLES ut
    where cs.TABLE_NAME = ut.TABLE_NAME;
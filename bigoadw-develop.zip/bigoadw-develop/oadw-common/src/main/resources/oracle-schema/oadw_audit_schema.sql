-- Static table in static OADW_AUDIT schema present in rac03, opa_prod and rac_multi
-- Any changes to this schema file (i.e., OADW_AUDIT schema) has to be deployed manually with the help of ADO team in all oracle servers

CREATE TABLE OADW_AUDIT.CLIENT_AUDIT
(
      CLIENT_ID VARCHAR2(20 CHAR)
    , ENVIRONMENT VARCHAR2(10 CHAR)
    , ORACLE_SCHEMA VARCHAR2(35 CHAR)
    , LAST_UPDATE_DTM TIMESTAMP(6)
    , IS_MONTHLY NUMBER(1, 0)
    , IS_LATEST NUMBER(1, 0)
    , SOURCE_HIVE_SCHEMA VARCHAR2(50 BYTE)
    , REF_SCHEMA VARCHAR2(100 BYTE)
    , CDR_VERSION VARCHAR2(100 BYTE)
    , CDR_SCHEMA VARCHAR2(100 BYTE)
    , CDR_INSTANCE VARCHAR2(100 BYTE)
    , OADW_VERSION VARCHAR2(100 BYTE)
    , II_DATE_STAMP VARCHAR2(100 BYTE)
    , II_PROCESS_ID VARCHAR2(100 BYTE)
    , SETUP_DTM VARCHAR2(100 BYTE)
    , DATA_THRU VARCHAR2(100 BYTE)
    , ORCL_DATA_SIZE_GB VARCHAR2(100 BYTE)
    , ETL_START_DTM VARCHAR2(100 BYTE)
    , ETL_END_DTM VARCHAR2(100 BYTE)
    , ORCL_EXPORT_START_DTM VARCHAR2(100 BYTE)
    , ORCL_EXPORT_END_DTM VARCHAR2(100 BYTE)
    , CLEANUP_FLG VARCHAR2(8 CHAR) DEFAULT 'KEEP'
    , CLEANUP_REQUESTOR VARCHAR2(50 CHAR) DEFAULT USER
    , CLEANUP_REQUEST_DTM TIMESTAMP(6) DEFAULT LOCALTIMESTAMP
    , BUILD_ENVIRONMENT VARCHAR2 (32 CHAR)
     CONSTRAINT client_audit_pk PRIMARY KEY (CLIENT_ID, ENVIRONMENT,ORACLE_SCHEMA)
);


-- Valid values of CLEANUP_FLG column:
-- KEEP : Status to retain till threshold of 90 or 120 days
-- DELETE : Status to delete in next cleanup cycle
-- DELETED: Status to confirm cleanup is complete for that row
-- IGNORE: Status to manually override for avoiding cleanup. Should be used for few scenarios or those databases where you want them little longer
CREATE OR REPLACE PROCEDURE update_schema_cleanup_status(
    p_client_id IN VARCHAR2(20)
    , p_env IN VARCHAR2(10)
    , p_schema_name IN VARCHAR2(35)
    , p_cleanup_flg IN VARCHAR2(8)
)
BEGIN
    UPDATE OADW_AUDIT.CLIENT_AUDIT
        SET CLEANUP_FLG = p_cleanup_flg,
        CLEANUP_REQUESTOR = USER,
        CLEANUP_REQUEST_DTM = LOCALTIMESTAMP
    WHERE CLIENT_ID = p_client_id
        AND ENVIRONMENT = p_env
        AND ORACLE_SCHEMA = p_schema_name;

    COMMIT;
END update_schema_cleanup_status;


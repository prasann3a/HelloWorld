BEGIN
  set_user_columns_nullable();
END;

CREATE OR REPLACE FUNCTION safe_to_number (p_txt IN VARCHAR2
                                          ,p_format IN VARCHAR2 := NULL)
  RETURN NUMBER
  DETERMINISTIC
IS
  v_number  number;
BEGIN
  IF p_format IS NOT NULL THEN
    v_number := to_number(p_txt, p_format);
  ELSE
    v_number := to_number(p_txt);
    if to_char(v_number)='~' then
      v_number := NULL;
    END IF;
  END IF;
  RETURN v_number;
EXCEPTION WHEN value_error THEN
  RETURN NULL;
END safe_to_number;
/


CREATE OR REPLACE PROCEDURE add_list_partition(p_table IN VARCHAR2,p_part_name IN VARCHAR2,p_values IN VARCHAR2)
AS
  part_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(part_exists, -14013);
  value_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(value_exists, -14312);
  v_values VARCHAR2(60) := p_values;
BEGIN
  if (safe_to_number(p_values) is null) then
    v_values := '''' || p_values || '''';
  end if;
  EXECUTE IMMEDIATE 'ALTER TABLE ' || p_table || ' ADD PARTITION ' || p_part_name || ' VALUES(' || v_values || ')';
  --TODO: Decide how we want to handle errors.  We should verify that if the partition exists, it has the same values.
  EXCEPTION
  WHEN part_exists THEN
       --Check that the value is
       null;
  WHEN value_exists THEN
       null;
END add_list_partition;
/

CREATE OR REPLACE PROCEDURE add_list_partitions(p_table IN VARCHAR2,p_part_src_tbl IN VARCHAR2, p_part_name_col IN VARCHAR2, p_part_val_col IN VARCHAR2 DEFAULT NULL
                                                ,p_part_prefix IN VARCHAR2 default 'P_'
                                                ,p_filter IN VARCHAR2 default '1=1')
AS
  v_sql VARCHAR2(400);
  v_part VARCHAR2(32);
  v_val VARCHAR2(32); --probably needs to be large for when we support multiple values.
  TYPE result_cur IS REF CURSOR;
  v_cursor result_cur;
  v_part_val_col VARCHAR2(100) := NVL(p_part_val_col,p_part_name_col);
BEGIN
  v_sql := 'SELECT DISTINCT ' || p_part_name_col || ' AS part_nm, ' || v_part_val_col || ' AS part_val FROM ' || p_part_src_tbl || ' t ' || ' WHERE ' || p_filter || ' GROUP BY ' || p_part_name_col;
  OPEN v_cursor FOR v_sql;
  LOOP
    FETCH v_cursor INTO v_part,v_val;
    EXIT WHEN v_cursor%NOTFOUND;
    add_list_partition(p_table => p_table,p_part_name => p_part_prefix || v_part,p_values => v_val);
  END LOOP;
END add_list_partitions;
/

CREATE OR REPLACE FUNCTION is_bitvalue(p_val IN NUMBER) RETURN NUMBER
DETERMINISTIC
AS
BEGIN
  IF (p_val <= 0) THEN
     RETURN 0;
  ELSE
     RETURN CASE WHEN BITAND(p_val,p_val-1) = 0 THEN 1 ELSE 0 END;
  END IF;
END;
/


-- The below functions were added for OADW-1749
CREATE OR REPLACE FUNCTION add_yr_month(p_yr_month IN NUMBER,p_increment IN NUMBER) RETURN NUMBER
DETERMINISTIC
IS
  v_return NUMBER;
  v_year NUMBER := TO_NUMBER(SUBSTR(p_yr_month,1,4));
  v_month NUMBER := TO_NUMBER(SUBSTR(p_yr_month,-2));
BEGIN
  v_month := v_month + p_increment;
  IF (v_month = 0) THEN
    v_year := v_year - 1;
    v_month := 12;
  ELSIF (v_month < 1) THEN
    v_year := v_year + FLOOR(v_month / 12);
    v_month := 12 + MOD(v_month,12);
  ELSIF (v_month > 12) THEN
        v_year := v_year + FLOOR(v_month / 12);
        v_month := MOD(v_month , 12);
  END IF;
  v_return := (v_year * 100) + v_month;
  RETURN(v_return);
END add_yr_month;
/
CREATE OR REPLACE FUNCTION age_as_of (birth_date in date, as_of_date in date := sysdate, unit in VARCHAR2 := 'YEAR')
--Return an age based on the birthdate and as_of_date supplied
--Age will be returned as a whole number
--If birthdate is null return null
--valid units include: YEAR or MONTH
    RETURN NUMBER
    DETERMINISTIC
IS
    PRAGMA UDF;
    age  INTEGER;
BEGIN
    IF birth_date IS NULL THEN
        RETURN NULL;
    END IF;

    -- Calculate the age in months
    age := FLOOR (MONTHS_BETWEEN (TRUNC (as_of_date), TRUNC (birth_date)));

    -- Calculate age in MONTHs or YEARs
    CASE UPPER (unit)
    WHEN 'MONTH' THEN
        NULL;
    WHEN 'YEAR' THEN
        age := FLOOR (age / 12);
    ELSE
        RETURN NULL;
    END CASE;

    -- Return age
    RETURN age;

EXCEPTION
WHEN VALUE_ERROR THEN
    RETURN NULL;
END age_as_of;
/

CREATE OR REPLACE TYPE bitand_impl AS OBJECT
(
  agg_bitand INTEGER,

  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitand_impl) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitand_impl,
                                       val  IN INTEGER) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitand_impl,
                                     ctx2 IN bitand_impl) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitand_impl,
                                         returnval OUT INTEGER,
                                         flags     IN NUMBER) RETURN NUMBER
)
/

CREATE OR REPLACE TYPE BODY bitand_impl IS
  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitand_impl) RETURN NUMBER IS
  BEGIN
    ctx := bitand_impl(NULL);
    RETURN ODCIConst.Success;
  END ODCIAggregateInitialize;

  MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitand_impl,
                                       val  IN INTEGER) RETURN NUMBER IS
  BEGIN
    SELF.agg_bitand :=  bitand(NVL(SELF.agg_bitand,val), val);
    RETURN ODCIConst.Success;
  END ODCIAggregateIterate;

  MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitand_impl,
                                     ctx2 IN bitand_impl) RETURN NUMBER IS
  BEGIN
    SELF.agg_bitand := bitand(NVL(SELF.agg_bitand,ctx2.agg_bitand), ctx2.agg_bitand);
    RETURN ODCIConst.Success;
  END ODCIAggregateMerge;

  MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitand_impl,
                                         returnval OUT INTEGER,
                                         flags     IN NUMBER) RETURN NUMBER IS
  BEGIN
    returnval := SELF.agg_bitand;
    RETURN ODCIConst.Success;
  END ODCIAggregateTerminate;
END;
/

CREATE OR REPLACE FUNCTION bitandagg(x IN INTEGER) RETURN INTEGER
PARALLEL_ENABLE
AGGREGATE USING bitand_impl;
/

CREATE OR REPLACE FUNCTION bitor(p_bitfield1 IN NUMBER,p_bitfield2 IN NUMBER,p_bitfield3 IN NUMBER DEFAULT 0) RETURN NUMBER
DETERMINISTIC
AS
       v_f1 NUMBER := NVL(p_bitfield1,0);
       v_f2 NUMBER := NVL(p_bitfield2,0);
       v_f3 NUMBER := NVL(p_bitfield3,0);
       v_tmp NUMBER;
BEGIN
  IF (least(v_f1,v_f2,v_f3) < 0) THEN
     RETURN 0;
  ELSE
     v_tmp := v_f1 + v_f2 - bitand(v_f1,v_f2);
     v_tmp := v_tmp + v_f3 - bitand(v_tmp,v_f3);
     RETURN v_tmp;
  END IF;
END;
/

CREATE OR REPLACE TYPE bitor_impl AS OBJECT
(
  agg_bitor INTEGER,

  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitor_impl) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitor_impl,
                                       val  IN INTEGER) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitor_impl,
                                     ctx2 IN bitor_impl) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitor_impl,
                                         returnval OUT INTEGER,
                                         flags     IN NUMBER) RETURN NUMBER
)
/

CREATE OR REPLACE TYPE BODY bitor_impl IS
  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitor_impl) RETURN NUMBER IS
  BEGIN
    ctx := bitor_impl(0);
    RETURN ODCIConst.Success;
  END ODCIAggregateInitialize;

  MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitor_impl,
                                       val  IN INTEGER) RETURN NUMBER IS
  BEGIN
    SELF.agg_bitor := SELF.agg_bitor + val - bitand(SELF.agg_bitor, val);
    RETURN ODCIConst.Success;
  END ODCIAggregateIterate;

  MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitor_impl,
                                     ctx2 IN bitor_impl) RETURN NUMBER IS
  BEGIN
    SELF.agg_bitor := SELF.agg_bitor + ctx2.agg_bitor - bitand(SELF.agg_bitor, ctx2.agg_bitor);
    RETURN ODCIConst.Success;
  END ODCIAggregateMerge;

  MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitor_impl,
                                         returnval OUT INTEGER,
                                         flags     IN NUMBER) RETURN NUMBER IS
  BEGIN
    returnval := SELF.agg_bitor;
    RETURN ODCIConst.Success;
  END ODCIAggregateTerminate;
END;
/

CREATE OR REPLACE FUNCTION bitoragg(x IN INTEGER) RETURN INTEGER
PARALLEL_ENABLE
AGGREGATE USING bitor_impl;
/

CREATE OR REPLACE FUNCTION generate_date_subpartitions(p_years IN NUMBER DEFAULT 5
                                                       ,p_sub_part_ind IN NUMBER DEFAULT 1
                                                      ,p_years_future IN NUMBER DEFAULT 0
                                                      ,p_value_type IN VARCHAR2 DEFAULT 'DATE') RETURN VARCHAR2
IS
  v_result VARCHAR2(4000);
  v_min_yr NUMBER;
  v_max_yr NUMBER;
  v_part_prefix VARCHAR2(3) := CASE WHEN p_sub_part_ind = 1 THEN 'SUB' ELSE NULL END;
  v_value_expr VARCHAR2(100);
BEGIN
  -- start creating following new year sub-partitions 1 month ahead. eg: create 2018 sub-partitions starting 01-dec-2017
  SELECT TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')) - p_years INTO v_min_yr FROM DUAL;
  SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE,1),'YYYY')) + p_years_future INTO v_max_yr FROM DUAL;

  IF (p_value_type = 'NUMBER') THEN
     v_value_expr := q'[YEARVAL01]';
  ELSIF (p_value_type = 'DATE') THEN
     v_value_expr := q'[TO_DATE('YEARVAL0101','YYYYMMDD')]';
  ELSE
     raise_application_error(-20001, 'Invalid p_value_type argument to generate_date_subpartitions');
  END IF;

  v_result := replace(v_part_prefix || 'PARTITION P_pre' || v_min_yr || q'[ VALUES LESS THAN (]' || v_value_expr || ')','YEARVAL',v_min_yr);
  for yr in v_min_yr..v_max_yr
  loop
    v_result := v_result || chr(10) || replace(',' || v_part_prefix || 'PARTITION P_' || yr || q'[ VALUES LESS THAN (]' || v_value_expr || ')','YEARVAL',yr + 1);
  end loop;

  return(v_result);
end generate_date_subpartitions;
/

CREATE OR REPLACE FUNCTION generate_hash_partitions(p_cnt IN NUMBER DEFAULT 4,p_sub_part_ind IN NUMBER DEFAULT 0) RETURN VARCHAR2
IS
  v_result VARCHAR2(4000);
  v_part_nm VARCHAR2(8);
  v_part_prefix VARCHAR2(3) := CASE WHEN p_sub_part_ind = 1 THEN 'SUB' ELSE NULL END;
BEGIN
  -- create hash partitions

  v_result := v_part_prefix || 'PARTITION P_01';
  for pidx in 2..p_cnt
  loop
    v_result := v_result || chr(10) || ',' || v_part_prefix || 'PARTITION P_' || lpad(pidx,2,'0');
  end loop;

  return(v_result);
end generate_hash_partitions;
/

create or replace function get_ii_filename (p_client_id in varchar2,p_process_id in number ,p_script_name in varchar2 ) return varchar2
is
  l_filename varchar2(100);
begin
  if p_process_id = 0 then
    -- no valid process_id exists, set to default values
    -- these will point to an empty file so a select against the external table will succeed but return zero rows
    l_filename    := 'DO_NOT_REMOVE';  -- DO_NOT_REMOVE.txt
  else
    -- a valid process_id exists, set to group-specific values.
    l_filename    := p_process_id||'_'||p_client_id||'_'||p_script_name;  -- eg 34048_H704847_ADM_COSTS_ADMLEVEL
  end if;
  return(l_filename);
end ;
/

create or replace function get_ii_group_directory (p_client_id in varchar2,p_process_id in number) return varchar2
is
  l_group_dir varchar2(30);
begin
  if p_process_id = 0 then
    -- no valid process_id exists, set to default values
    -- these will point to an empty file so a select against the external table will succeed but return zero rows
    l_group_dir := 'II_EXTERNAL_COMMON';  -- /misc/phiops/archive/in_ii
  else
    -- a valid process_id exists, set to group-specific values.
    l_group_dir := p_client_id||'_LOAD_DIR_PROD';   -- eg H704847_LOAD_DIR_PROD
  end if;
  return(l_group_dir);
end ;
/

create or replace function get_ii_process_id (p_client_id in varchar2
                                             ,p_process_id in varchar2 := '0'
                                             ,p_cdr_schema in varchar2
                                             ,p_cdr_view in varchar2 := null
                                              )
return number
is
  c_proc_name varchar2(30) := $$PLSQL_UNIT;
  l_process_id number(10) :=0;
  l_cdr_view varchar2(30) := 'v_bpo_ext_table_process_id';
  l_cnt pls_integer;
  l_sql varchar2(1000);
  p_process_num number(10);
  v_where_clause varchar2(100) := '';

begin
  l_cdr_view := nvl(p_cdr_view, l_cdr_view);
  -- confirm view exists
  select count(*)
  into   l_cnt
  from all_views where owner = upper(p_cdr_schema) and view_name = upper(l_cdr_view);
  if l_cnt = 0 then
    raise_application_error (-20000, c_proc_name||': Specified view does not exist '''||p_cdr_schema||'.'||l_cdr_view||'''');
    l_process_id := 0;
  end if;

  -- if process_id is specified from command line, validate and use that
  if p_process_id not in ('0','*') then
    -- validate from view, raise error if not found
    -- check if the process id is actually a valid number. if it is then return it else - exception ....
    if safe_to_number(p_process_id) is null then
      raise_application_error (-20009, c_proc_name||': Specified process_id '||p_process_id||' is invalid');
      l_process_id := 0;
    end if;
    p_process_num := p_process_id;
    l_sql := 'select process_id
              from   '||p_cdr_schema||'.'||l_cdr_view||'
              where  client_id = :clientid
              and    process_id = :pid ';
    begin
      execute immediate l_sql into l_process_id using p_client_id, p_process_num;
    exception
      when no_data_found then
        raise_application_error (-20001, c_proc_name||': Specified process_id '||p_process_id||' does not exist in '||p_cdr_schema||'.'||l_cdr_view||' for '||p_client_id);
    end;
  else
    if p_process_id = '0' then
        v_where_clause := ' and out_schema_name = ''' || upper(p_cdr_schema) || '''';
     else
       v_where_clause := '';
    end if;
    -- look up from view:
    --   Get the most recent sendout per schema for this client_id
    --   From these, select the latest send out for this source schema.  If no successful process for this schema, select the latest process_id
    l_sql := 'select process_id
              from   (select *
                      from   (select v.*
                                    ,row_number() over (partition by out_schema_name order by out_transfer_timestamp desc) as latest_procid_per_schema
                              from  '||p_cdr_schema||'.'||l_cdr_view||' v
                              where  client_id = :clientid added_where_clause
                              )
                      where latest_procid_per_schema = 1
                      order by decode(out_schema_name, :cdr_schm, 1, 0) desc, out_transfer_timestamp desc
                      )
              where rownum = 1';
    begin
      l_sql := replace( l_sql, 'added_where_clause', v_where_clause);
      execute immediate l_sql into l_process_id using p_client_id, upper(p_cdr_schema) ;
    exception
      when no_data_found then
        l_process_id := 0;
    end;
  end if;
  return l_process_id;
end ;
/

CREATE OR REPLACE FUNCTION is_bitvalue(p_val IN NUMBER) RETURN NUMBER
DETERMINISTIC
AS
BEGIN
  IF (p_val <= 0) THEN
     RETURN 0;
  ELSE
     RETURN CASE WHEN BITAND(p_val,p_val-1) = 0 THEN 1 ELSE 0 END;
  END IF;
END;
/
CREATE OR REPLACE FUNCTION safe_to_number (p_txt IN VARCHAR2
                                          ,p_format IN VARCHAR2 := NULL)
  RETURN NUMBER
  DETERMINISTIC
IS
  v_number  number;
BEGIN
  IF p_format IS NOT NULL THEN
    v_number := to_number(p_txt, p_format);
  ELSE
    v_number := to_number(p_txt);
    if to_char(v_number)='~' then
      v_number := NULL;
    END IF;
  END IF;
  RETURN v_number;
EXCEPTION WHEN value_error THEN
  RETURN NULL;
END safe_to_number;
/
CREATE OR REPLACE PROCEDURE update_current_schema (p_dest_schema IN varchar2)
AUTHID CURRENT_USER
IS
  l_cnt1               number;
  l_cnt2               number;
  l_referenced_owner   varchar2(30);
  l_sql                varchar2(2000);
  cursor c0 is select object_name from user_objects where object_type in ('VIEW');
  cursor c1 (dest_schema  varchar2) is select object_type, object_name from all_objects where owner = UPPER(dest_schema)
    and object_type in ('TABLE','VIEW') order by object_type, object_name;
  cursor c2 (dest_schema  varchar2) is select object_name from user_objects where object_type in ('SYNONYM')
    minus
    select object_name from all_objects where owner = UPPER(dest_schema) and object_type in ('TABLE','VIEW');
  cursor c3 (dest_schema  varchar2) is select object_name from user_objects where object_type in ('VIEW')
    minus
    select object_name from all_objects where owner = UPPER(dest_schema) and object_type in ('TABLE','VIEW');
BEGIN
  FOR X in c0 LOOP
    l_sql :=  'DROP VIEW ' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  FOR X in c1 (p_dest_schema) LOOP
    l_sql :=  'CREATE OR REPLACE SYNONYM ' || X.object_name || ' FOR ' || upper(p_dest_schema) || '.' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  FOR X in c2 (p_dest_schema) LOOP
    l_sql :=  'DROP SYNONYM ' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  FOR X in c3 (p_dest_schema) LOOP
    l_sql :=  'DROP VIEW ' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  select count(*)
  into l_cnt1
  from USER_DEPENDENCIES
  where REFERENCED_OWNER not in ('PUBLIC','SYS')
  and REFERENCED_OWNER not in (select user from dual)
  and type ='SYNONYM';

  select referenced_owner, count(*)
  into l_referenced_owner, l_cnt1
  from USER_DEPENDENCIES
  where REFERENCED_OWNER not in ('PUBLIC','SYS')
  and REFERENCED_OWNER not in (select user from dual)
  and type ='SYNONYM'
  group by referenced_owner;

  IF l_referenced_owner != upper(p_dest_schema) THEN
   RAISE_APPLICATION_ERROR(-20000, 'Validation Error: referenced_owner ' || l_referenced_owner || ' and dest schema ' || upper(p_dest_schema) || ' mismatch!');
  END IF;

  select count(*)
  into l_cnt2
  from ALL_OBJECTS
  where owner = UPPER(p_dest_schema)
  and object_type in ('TABLE','VIEW');

  IF l_cnt1 != l_cnt2 THEN
    RAISE_APPLICATION_ERROR(-20001, 'Validation Error: CURRENT schema synonym count ' || to_char(l_cnt1) || ' and dest schema ' || upper(p_dest_schema) || ' table/view count ' || to_char(l_cnt2) || ' mismatch!');
  END IF;
END;
/
CREATE OR REPLACE PROCEDURE grant_synonyms_select (p_link_schema IN varchar2)
IS
  l_cnt1          number;
  l_sql           varchar2(2000);
  l_schema_upper  varchar2(30);
BEGIN
  l_schema_upper := UPPER(p_link_schema);

  SELECT count(username)
  INTO l_cnt1
  FROM all_users
  WHERE UPPER(username) = l_schema_upper;

  IF l_cnt1 = 1 THEN
    FOR x IN (SELECT SYNONYM_NAME FROM user_synonyms ORDER BY SYNONYM_NAME) LOOP
       l_sql :=  'GRANT SELECT ON ' || x.SYNONYM_NAME || ' TO ' || l_schema_upper ;
       EXECUTE IMMEDIATE l_sql ;
    END LOOP;
  END IF;
END;
/
create or replace PROCEDURE grant_synonyms_to_opa_rep (client_id IN varchar2, env in varchar2)
IS
  rep_schema_pattern varchar2(30);
BEGIN
  rep_schema_pattern := UPPER('REP_%'||client_id||'%'||env||'%');
  FOR x IN (select USERNAME from all_users where username like rep_schema_pattern) LOOP
    grant_synonyms_select(x.USERNAME);
  END LOOP;
END;
/
CREATE OR REPLACE PROCEDURE set_user_columns_nullable
IS
  l_sql           varchar2(2000);
BEGIN
  FOR x IN (SELECT table_name, column_name FROM user_tab_columns where NULLABLE = 'N'
                   and table_name in (select object_name from user_objects where object_type='TABLE')
           )
  LOOP
    l_sql :=  'ALTER TABLE ' || user || '.' || x.table_name || ' MODIFY ' || x.column_name || ' NULL';
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;
END;
/
-- Auto-generated content from ii_external_schema.hql
DECLARE
    PROCEDURE DROP_IF_EXISTS (objectName IN VARCHAR2, objectType IN VARCHAR2 )
    IS
    v_counter number:=0;
    BEGIN

        IF (objectType = 'TABLE') THEN
        select count(*) into v_counter from user_tables where table_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName || ' CASCADE CONSTRAINTS PURGE';
        end if;
        END IF;

        IF (objectType = 'VIEW') THEN
        select count(*) into v_counter from user_views where view_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName;
        end if;
        END IF;

        commit;

    END;
BEGIN
  NULL;
END;
/

-- Auto-generated content from cdr_schema.hql
DECLARE
    PROCEDURE DROP_IF_EXISTS (objectName IN VARCHAR2, objectType IN VARCHAR2 )
    IS
    v_counter number:=0;
    BEGIN

        IF (objectType = 'TABLE') THEN
        select count(*) into v_counter from user_tables where table_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName || ' CASCADE CONSTRAINTS PURGE';
        end if;
        END IF;

        IF (objectType = 'VIEW') THEN
        select count(*) into v_counter from user_views where view_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName;
        end if;
        END IF;

        commit;

    END;
BEGIN

-- This table is sourced from CDR
DROP_IF_EXISTS('l1_map_lab', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_lab (
	cui VARCHAR2(20 CHAR) NOT  NULL,
	dts_version NUMBER  NOT NULL,
	local_name VARCHAR2(150 CHAR) NULL,
	modified_date TIMESTAMP,
	notes VARCHAR2(4000 CHAR) NULL,
	ref_range_max VARCHAR2(150 CHAR) NULL,
	ref_range_min VARCHAR2(150 CHAR) NULL,
	result_type VARCHAR2(2000 CHAR) NULL,
	row_source VARCHAR2 (10 CHAR),
	semantic_val_max VARCHAR2(150 CHAR) NULL,
	semantic_val_min VARCHAR2(150 CHAR) NULL,
	sensitive_ind NUMBER (1) NULL,
	unit VARCHAR2(200 CHAR) NULL,
	usage VARCHAR2(150 CHAR) NULL,
	validated_ind NUMBER (1) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    END;
/

-- Auto-generated content from oadw_schema.hql
DECLARE
    PROCEDURE DROP_IF_EXISTS (objectName IN VARCHAR2, objectType IN VARCHAR2 )
    IS
    v_counter number:=0;
    BEGIN

        IF (objectType = 'TABLE') THEN
        select count(*) into v_counter from user_tables where table_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName || ' CASCADE CONSTRAINTS PURGE';
        end if;
        END IF;

        IF (objectType = 'VIEW') THEN
        select count(*) into v_counter from user_views where view_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName;
        end if;
        END IF;

        commit;

    END;
BEGIN

-- This table is sourced from OADW
DROP_IF_EXISTS('l2_map_amb_site', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_amb_site (
	amb_site_cd VARCHAR2 (400 CHAR) NOT NULL,
	amb_site_desc VARCHAR2 (400 CHAR),
	amb_site_id NUMBER NOT NULL,
	amb_site_zip VARCHAR2 (20 CHAR),
	client_id VARCHAR2 (16 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_map_hosp_site', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_hosp_site (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	hosp_site_cd VARCHAR2 (400 CHAR) NOT NULL,
	hosp_site_desc VARCHAR2 (400 CHAR),
	hosp_site_id NUMBER NOT NULL,
	hosp_site_zip VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_pat_appointment', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_appointment (
	appointment_dtm DATE NOT NULL,
	appointment_location VARCHAR2 (100 CHAR),
	appointment_reason VARCHAR2 (249 CHAR),
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	location_key VARCHAR2 (100 CHAR),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	prov_id VARCHAR2 (20 CHAR),
	prov_id_key VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_pat_assess_num', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_assess_num (
	assessment_cui VARCHAR2 (8 CHAR) NOT NULL,
	assessment_dtm DATE NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	clinical_evt_key NUMBER (19, 0),
	hosp_ind NUMBER (1) DEFAULT 0 NOT NULL,
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	nlp_ind NUMBER (1),
	numeric_value NUMBER NOT NULL,
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL
	) PARTITION BY LIST (assessment_cui) (PARTITION P_CH999999 values(''CH999999''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_pat_assess_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_assess_qual (
	assessment_cui VARCHAR2 (8 CHAR) NOT NULL,
	assessment_dtm DATE NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	clinical_evt_key NUMBER (19, 0),
	hosp_ind NUMBER (1) DEFAULT 0 NOT NULL,
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	nlp_ind NUMBER (1),
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL,
	value_cui VARCHAR2 (8 CHAR) NOT NULL
	) PARTITION BY LIST (ASSESSMENT_CUI) (PARTITION P_CH999999 values(''CH999999''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_pat_clinical_event', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_clinical_event (
	admit_prov_id VARCHAR2 (20 CHAR),
	admitsource_cui VARCHAR2 (8 CHAR),
	admitted_er_ind NUMBER (1) NOT NULL,
	amb_site_id NUMBER,
	apr_drg_id NUMBER (6),
	apr_drg_sensitive_ind NUMBER (1) NOT NULL,
	base_include_ind NUMBER (1) NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER NOT NULL,
	cms_include_ind NUMBER (1) NOT NULL,
	cms_planned_ind NUMBER (1) NOT NULL,
	convert_ip_ind NUMBER (1) NOT NULL,
	disch_prov_id VARCHAR2 (20 CHAR),
	disch_team_prov_id VARCHAR2 (20 CHAR),
	display_ds_id NUMBER NOT NULL,
	display_encounterid VARCHAR2 (255 CHAR) NOT NULL,
	disposition_cui VARCHAR2 (8 CHAR),
	drg_id NUMBER (6),
	drg_id_calc NUMBER (10, 0),
	drg_sensitive_ind NUMBER (1) NOT NULL,
	etg_qual_evt_ind NUMBER (1) NOT NULL,
	event_type_cui VARCHAR2 (8 CHAR) NOT NULL,
	evt_admit_dtm DATE,
	evt_end_dtm DATE,
	evt_start_dtm DATE NOT NULL,
	hosp_service_cui VARCHAR2 (8 CHAR),
	hosp_site_id NUMBER,
	los NUMBER (10, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	pat_zip VARCHAR2 (10 CHAR),
	prindx VARCHAR2 (10 CHAR),
	prindx_codetype VARCHAR2 (16 CHAR),
	prindx_sensitive_ind NUMBER (1) NOT NULL,
	prinpx VARCHAR2 (10 CHAR),
	prinpx_codetype VARCHAR2 (16 CHAR),
	prinpx_sensitive_ind NUMBER (1) NOT NULL,
	prov_id VARCHAR2 (20 CHAR),
	same_day_stay NUMBER (10, 0),
	sensitive_ind NUMBER (1) NOT NULL
	) PARTITION BY LIST(EVENT_TYPE_CUI) (PARTITION P_CH000000 values (''CH000000''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_pat_diag', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_diag (
	admit_ind NUMBER (1) NOT NULL,
	bill_claim_ind NUMBER (1) NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	clinical_evt_key NUMBER,
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	diag_cd VARCHAR2 (20 CHAR) NOT NULL,
	diag_dt DATE NOT NULL,
	discharge_ind NUMBER (1) NOT NULL,
	hosp_dx_ind NUMBER (1) NOT NULL,
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	poa_cui VARCHAR2 (8 CHAR) NOT NULL,
	primary_hosp_dx_ind NUMBER (1) NOT NULL,
	primary_ind NUMBER (1) NOT NULL,
	problemlist_ind NUMBER (1) NOT NULL,
	resolution_dt DATE,
	sensitive_ind NUMBER (1) NOT NULL,
	status_cui VARCHAR2 (8 CHAR) NOT NULL,
	parititon_key VARCHAR2(100 CHAR) GENERATED ALWAYS AS (substr(code_type,1,20) || ''_'' ||  substr(diag_cd,1,1)) VIRTUAL
	) PARTITION BY LIST(parititon_key) (PARTITION P_ICD10_U VALUES (''ICD10_U''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_pat_id', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_id (
	client_ds_id NUMBER NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	id_subtype VARCHAR2 (50 CHAR),
	id_subtype_ind NUMBER (1),
	id_type VARCHAR2 (20 CHAR) NOT NULL,
	id_value VARCHAR2 (50 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL
	) PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_pat_proc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_proc (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	hosp_px_ind NUMBER (1),
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	modifier_1 VARCHAR2 (2 CHAR),
	modifier_1_excld NUMBER (1) NOT NULL,
	modifier_2 VARCHAR2 (2 CHAR),
	modifier_2_excld NUMBER (1) NOT NULL,
	modifier_3 VARCHAR2 (2 CHAR),
	modifier_3_excld NUMBER (1) NOT NULL,
	modifier_4 VARCHAR2 (2 CHAR),
	modifier_4_excld NUMBER (1) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	place_of_svc VARCHAR2 (10 CHAR) NOT NULL,
	place_of_svc_sensitive_ind NUMBER NOT NULL,
	principal_ind NUMBER (1),
	proc_cd VARCHAR2 (20 CHAR) NOT NULL,
	proc_dtm DATE NOT NULL,
	prov_id VARCHAR2 (20 CHAR) DEFAULT ''0'' NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL,
	tos_i_5 NUMBER (12)
	) PARTITION BY LIST(code_type) (PARTITION P_NULL VALUES (NULL))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_patient_info', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_patient_info (
	addr_line_1 VARCHAR2 (100 CHAR),
	addr_line_2 VARCHAR2 (100 CHAR),
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	city VARCHAR2 (50 CHAR),
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	death_ind_cui VARCHAR2 (8 CHAR),
	dob DATE,
	dod DATE,
	email VARCHAR2 (100 CHAR),
	ethnicity_cui VARCHAR2 (8 CHAR),
	first_name VARCHAR2 (30 CHAR),
	gender_cui VARCHAR2 (8 CHAR),
	home_phone VARCHAR2 (30 CHAR),
	language_cui VARCHAR2 (8 CHAR),
	last_name VARCHAR2 (50 CHAR),
	marital_status_cui VARCHAR2 (8 CHAR),
	middle_name VARCHAR2 (30 CHAR),
	mobile_phone VARCHAR2 (30 CHAR),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	mrace_infer_ind NUMBER (10, 0),
	mrn VARCHAR2 (20 CHAR),
	postal_cd VARCHAR2 (5 CHAR),
	race_cui VARCHAR2 (8 CHAR),
	religion VARCHAR2 (100 CHAR),
	ssn VARCHAR2 (9 CHAR),
	state VARCHAR2 (2 CHAR),
	work_phone VARCHAR2 (30 CHAR)
	) PARTITION BY RANGE(dob) (PARTITION P_pre1940 VALUES LESS THAN (to_date(''19400101'',''YYYYMMDD'')) ,PARTITION P_1940s VALUES LESS THAN (to_date(''19500101'',''YYYYMMDD'')) ,PARTITION P_1950s VALUES LESS THAN (to_date(''19600101'',''YYYYMMDD'')) ,PARTITION P_1960s VALUES LESS THAN (to_date(''19700101'',''YYYYMMDD'')) ,PARTITION P_1970s VALUES LESS THAN (to_date(''19800101'',''YYYYMMDD'')) ,PARTITION P_1980s VALUES LESS THAN (to_date(''19900101'',''YYYYMMDD'')) ,PARTITION P_1990s VALUES LESS THAN (to_date(''20000101'',''YYYYMMDD'')) ,PARTITION P_pre2020 VALUES LESS THAN (to_date(''20200101'',''YYYYMMDD'')) ,PARTITION P_MAX VALUES LESS THAN (MAXVALUE) )
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_provider_info', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_provider_info (
	address VARCHAR2 (100 CHAR),
	amb_site_id NUMBER DEFAULT 0 NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	city VARCHAR2 (100 CHAR),
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	cust_prv_1 VARCHAR2 (255 CHAR),
	cust_prv_10 VARCHAR2 (255 CHAR),
	cust_prv_11 VARCHAR2 (255 CHAR),
	cust_prv_12 VARCHAR2 (255 CHAR),
	cust_prv_13 VARCHAR2 (255 CHAR),
	cust_prv_14 VARCHAR2 (255 CHAR),
	cust_prv_15 VARCHAR2 (255 CHAR),
	cust_prv_16 NUMBER (38, 10),
	cust_prv_17 NUMBER (38, 10),
	cust_prv_18 NUMBER (38, 10),
	cust_prv_19 NUMBER (38, 10),
	cust_prv_2 VARCHAR2 (255 CHAR),
	cust_prv_20 NUMBER (38, 10),
	cust_prv_3 VARCHAR2 (255 CHAR),
	cust_prv_4 VARCHAR2 (255 CHAR),
	cust_prv_5 VARCHAR2 (255 CHAR),
	cust_prv_6 VARCHAR2 (255 CHAR),
	cust_prv_7 VARCHAR2 (255 CHAR),
	cust_prv_8 VARCHAR2 (255 CHAR),
	cust_prv_9 VARCHAR2 (255 CHAR),
	facility_ind NUMBER (1) DEFAULT 0 NOT NULL,
	npi VARCHAR2 (10 CHAR),
	pcp_ind NUMBER (1) DEFAULT 0 NOT NULL,
	prov_affil_id VARCHAR2 (40 CHAR),
	prov_id VARCHAR2 (20 CHAR) NOT NULL,
	prov_userdef_1 VARCHAR2 (100 CHAR),
	prov_userdef_2_id VARCHAR2 (40 CHAR),
	provider_name VARCHAR2 (255 CHAR),
	sec_provider_id VARCHAR2 (20 CHAR),
	sec_provider_id_2 VARCHAR2 (20 CHAR),
	specialty_id NUMBER (12),
	state VARCHAR2 (2 CHAR),
	zipcode VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('md_oadw_instance', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE md_oadw_instance (
	attribute_name VARCHAR2 (20 CHAR) NOT NULL,
	attribute_value VARCHAR2 (100 CHAR) NOT NULL,
	last_update_dtm DATE DEFAULT SYSDATE
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l4_pat_org_hier', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_org_hier (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	most_recent_ind NUMBER (1, 0) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	org_cd VARCHAR2 (150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l1_allergy', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_allergy (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dcc VARCHAR2(16 CHAR) NULL,
	encounterid VARCHAR2(249 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hts_generic VARCHAR2(100 CHAR) NULL,
	hts_generic_ext VARCHAR2(100 CHAR) NULL,
	hum_gen_med_key VARCHAR2(80 CHAR) NULL,
	hum_med_key VARCHAR2(16 CHAR) NULL,
	localallergencd VARCHAR2(249 CHAR) NULL,
	localallergendesc VARCHAR2(249 CHAR) NULL,
	localallergentype VARCHAR2(249 CHAR) NULL,
	localgpi VARCHAR2(249 CHAR) NULL,
	localndc VARCHAR2(249 CHAR) NULL,
	localstatus VARCHAR2(249 CHAR) NULL,
	map_used VARCHAR2(16 CHAR) NULL,
	mappedgpi VARCHAR2(249 CHAR) NULL,
	mappedndc VARCHAR2(249 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	ndc11 VARCHAR2(11 CHAR) NULL,
	onset_dt DATE  NOT NULL,
	patientid VARCHAR2(249 CHAR) NOT NULL,
	rxnorm_code VARCHAR2(25 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l1_rxorder', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_rxorder (
	active_med_flag VARCHAR2(1 CHAR) NULL,
	allowedamount NUMBER  NULL,
	altmedcode VARCHAR2(255 CHAR) NULL,
	charge NUMBER  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	coinsurance_amt NUMBER  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	copay_amt NUMBER  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dcc VARCHAR2(16 CHAR) NULL,
	deductable_amt NUMBER  NULL,
	denied_flag VARCHAR2(249 CHAR) NULL,
	discontinue_dt TIMESTAMP(3)  NULL,
	discontinuereason VARCHAR2(250 CHAR) NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	expire_dt TIMESTAMP(3)  NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	fillnum NUMBER (4) NULL,
	formulary_indicator VARCHAR2(249 CHAR) NULL,
	generic_status VARCHAR2(249 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hts_generic VARCHAR2(100 CHAR) NULL,
	hts_generic_ext VARCHAR2(100 CHAR) NULL,
	hum_gen_med_key VARCHAR2(80 CHAR) NULL,
	hum_med_key VARCHAR2(16 CHAR) NULL,
	issue_dtm TIMESTAMP(3)  NULL,
	localdaw VARCHAR2(225 CHAR) NULL,
	localdaysupplied NUMBER  NULL,
	localdescription VARCHAR2(1000 CHAR) NULL,
	localdescription_phi VARCHAR2(1000 CHAR) NULL,
	localdischargemedflg VARCHAR2(255 CHAR) NULL,
	localdosefreq VARCHAR2(255 CHAR) NULL,
	localdoseunit VARCHAR2(255 CHAR) NULL,
	localduration VARCHAR2(255 CHAR) NULL,
	localform VARCHAR2(255 CHAR) NULL,
	localgenericdesc VARCHAR2(255 CHAR) NULL,
	localgpi VARCHAR2(255 CHAR) NULL,
	localinfusionduration VARCHAR2(255 CHAR) NULL,
	localinfusionrate VARCHAR2(255 CHAR) NULL,
	localinfusionvolume VARCHAR2(255 CHAR) NULL,
	localmedcode VARCHAR2(100 CHAR) NULL,
	localndc VARCHAR2(255 CHAR) NULL,
	localproviderid VARCHAR2(255 CHAR) NULL,
	localqtyofdoseunit VARCHAR2(255 CHAR) NULL,
	localroute VARCHAR2(255 CHAR) NULL,
	localstrengthperdoseunit VARCHAR2(255 CHAR) NULL,
	localstrengthunit VARCHAR2(255 CHAR) NULL,
	localtotaldose VARCHAR2(255 CHAR) NULL,
	map_used VARCHAR2(16 CHAR) NULL,
	mappedgpi VARCHAR2(14 CHAR) NULL,
	mappedgpi_conf NUMBER (1) NULL,
	mappedndc VARCHAR2(11 CHAR) NULL,
	mappedndc_conf NUMBER (1) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	ndc11 VARCHAR2(11 CHAR) NULL,
	network_paid_status VARCHAR2(30 CHAR) NULL,
	orderstatus VARCHAR2(255 CHAR) NULL,
	ordertype VARCHAR2(255 CHAR) NULL,
	ordervsprescription VARCHAR2(1 CHAR) NULL,
	paidamount NUMBER  NULL,
	pat_liability_amt NUMBER  NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	pseudo_flag VARCHAR2(249 CHAR) NULL,
	quantityperfill VARCHAR2(200 CHAR) NULL,
	rxid VARCHAR2(100 CHAR) NOT NULL,
	rxnorm_code VARCHAR2(25 CHAR) NULL,
	signature VARCHAR2(4000 CHAR) NULL,
	venue VARCHAR2(8 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l1_rx_patient_reported', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_rx_patient_reported (
	action_dt TIMESTAMP(3)  NULL,
	active_med_flag VARCHAR2(1 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dcc VARCHAR2(16 CHAR) NULL,
	discontinue_dt TIMESTAMP(3)  NULL,
	discontinuereason VARCHAR2(250 CHAR) NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hts_generic VARCHAR2(100 CHAR) NULL,
	hts_generic_ext VARCHAR2(100 CHAR) NULL,
	hum_gen_med_key VARCHAR2(80 CHAR) NULL,
	hum_med_key VARCHAR2(16 CHAR) NULL,
	localactioncode VARCHAR2(255 CHAR) NULL,
	localcategorycode VARCHAR2(255 CHAR) NULL,
	localdoseunit VARCHAR2(255 CHAR) NULL,
	localdrugdescription VARCHAR2(1000 CHAR) NULL,
	localform VARCHAR2(255 CHAR) NULL,
	localgpi VARCHAR2(255 CHAR) NULL,
	localmedcode VARCHAR2(100 CHAR) NULL,
	localndc VARCHAR2(255 CHAR) NULL,
	localproviderid VARCHAR2(255 CHAR) NULL,
	localqtyofdoseunit VARCHAR2(255 CHAR) NULL,
	localroute VARCHAR2(255 CHAR) NULL,
	localstrengthperdoseunit VARCHAR2(255 CHAR) NULL,
	localstrengthunit VARCHAR2(255 CHAR) NULL,
	localtotaldose VARCHAR2(255 CHAR) NULL,
	map_used VARCHAR2(16 CHAR) NULL,
	mappedgpi VARCHAR2(14 CHAR) NULL,
	mappedndc VARCHAR2(11 CHAR) NULL,
	medreported_dt TIMESTAMP(3)  NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	ndc11 VARCHAR2(11 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	reportedmedid VARCHAR2(100 CHAR) NULL,
	rxnorm_code VARCHAR2(25 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l3_pat_proc_group', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_proc_group (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER (19, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	principal_ind NUMBER NOT NULL,
	proc_dtm TIMESTAMP(3) NOT NULL,
	proc_group_id NUMBER NOT NULL,
	prov_id VARCHAR2(20 CHAR) NOT NULL,
	sensitive_cat_id NUMBER NOT NULL,
	sensitive_ind NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_pat_immunization', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_immunization (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	code_type VARCHAR(8 CHAR) NOT NULL,
	imm_cd VARCHAR(255 CHAR) NOT NULL,
	imm_dt DATE NOT NULL,
	immunization_ind NUMBER (1) NOT NULL,
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	pat_reported_ind NUMBER (1) NOT NULL,
	procedure_ind NUMBER (1) NOT NULL,
	rxadmin_ind NUMBER (1) NOT NULL,
	rxorder_ind NUMBER (1) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l3_pat_immunization', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_immunization (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	code_type VARCHAR(8 CHAR) NOT NULL,
	imm_cd VARCHAR(20 CHAR) NOT NULL,
	imm_dt DATE NOT NULL,
	immunization_id NUMBER NOT NULL,
	immunization_ind NUMBER (1) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	pat_reported_ind NUMBER (1) NOT NULL,
	procedure_ind NUMBER (1) NOT NULL,
	rxadmin_ind NUMBER (1) NOT NULL,
	rxorder_ind NUMBER (1) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_dict_diag', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_diag (
	code_desc VARCHAR2 (500 CHAR),
	code_name VARCHAR2 (100 CHAR) NOT NULL,
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	diag_cd VARCHAR2 (20 CHAR) NOT NULL,
	icd_version NUMBER (10, 0),
	icddx VARCHAR2 (20 CHAR),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l2_dict_proc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_proc (
	code_desc VARCHAR2 (500 CHAR),
	code_name VARCHAR2 (100 CHAR) NOT NULL,
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	proc_cd VARCHAR2 (20 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (1) NOT NULL,
	specialty_med_ind NUMBER (1) DEFAULT 0 NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l4_pat_clinical_event_cond', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_clinical_event_cond (
	bill_claim_ind NUMBER (10, 0),
	client_id VARCHAR2 (16 CHAR),
	clinical_event_id NUMBER (19, 0),
	condition_id NUMBER (10, 0),
	em_ind NUMBER (10, 0),
	em_narrow_ind NUMBER (10, 0),
	em_wide_ind NUMBER (10, 0),
	etg_qual_evt_ind NUMBER (10, 0),
	hosp_dx_ind NUMBER (10, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	principal_dx_ind NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('md_domain_concept', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE md_domain_concept (
	concept_cui VARCHAR2 (50 CHAR),
	concept_name VARCHAR2 (100 CHAR),
	domain_cui VARCHAR2 (50 CHAR),
	domain_name VARCHAR2 (100 CHAR),
	first_valid_dt DATE  NULL,
	is_other VARCHAR2 (255 CHAR),
	last_valid_dt DATE  NULL,
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l1_map_obstype', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_obstype (
	begin_range NUMBER  NULL,
	datatype VARCHAR2(255 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	end_range NUMBER  NULL,
	foam_restriction VARCHAR2(255 CHAR) NULL,
	obstype VARCHAR2(255 CHAR) NOT  NULL,
	obstype_cui VARCHAR2(50 CHAR) NOT NULL,
	obstype_std_units VARCHAR2(50 CHAR) NULL,
	round_prec NUMBER  NULL,
	sensitive_ind NUMBER (1) NULL,
	validated_ind NUMBER (1) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l4_map_event_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_event_type (
	event_type_cui VARCHAR2 (50 CHAR) NOT NULL,
	event_type_description VARCHAR2 (100 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from OADW
DROP_IF_EXISTS('l4_dict_org_hier', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_org_hier (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	org_cd VARCHAR2 (150 CHAR) NOT NULL,
	org_desc VARCHAR2 (150 CHAR),
	org_lv1_cd VARCHAR2 (150 CHAR),
	org_lv1_desc VARCHAR2 (150 CHAR),
	org_lv2_cd VARCHAR2 (150 CHAR),
	org_lv2_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    END;
/


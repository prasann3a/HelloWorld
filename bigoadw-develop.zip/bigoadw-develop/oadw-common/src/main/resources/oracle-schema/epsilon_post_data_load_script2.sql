--This file contains all the ALTER INDEX statements that set them to NOPARALLEL
--The indexes are created in epsilon_post_data_load_script.sql file. That file should be run before this one
--Need to ensure that each ALTER INDEX statement spans exactly one line.
ALTER INDEX L2_patient_info_IDX01 NOPARALLEL;
ALTER INDEX L2_pat_assess_num_mpi_idx NOPARALLEL;
ALTER INDEX L2_pat_diag_mpi_idx NOPARALLEL;
ALTER INDEX L2_pat_id_cdi_it_iv_idx NOPARALLEL;
ALTER INDEX L2_pat_id_mpi_idx NOPARALLEL;
ALTER INDEX l2_pat_proc_mpi_idx NOPARALLEL;
ALTER INDEX L2_patient_info_idx NOPARALLEL;
ALTER INDEX L2_provider_info_prov_id_idx NOPARALLEL;
ALTER INDEX l2_pat_info_fname_idx NOPARALLEL;
ALTER INDEX l2_pat_info_lname_idx NOPARALLEL;
ALTER INDEX l2_pat_info_dob_idx NOPARALLEL;
ALTER INDEX l2_pat_id_idx NOPARALLEL;
ALTER INDEX IDX_L1RX_MPI NOPARALLEL;
ALTER INDEX IDX_L1RX_PAT_REPORTED_MPI NOPARALLEL;
ALTER INDEX IDX_L2_PAT_APPT NOPARALLEL;
ALTER INDEX L2_PAT_CLINICAL_EVENT_IDX01 NOPARALLEL;

CREATE OR REPLACE FUNCTION safe_to_number (p_txt IN VARCHAR2
                                          ,p_format IN VARCHAR2 := NULL)
  RETURN NUMBER
  DETERMINISTIC
IS
  v_number  number;
BEGIN
  IF p_format IS NOT NULL THEN
    v_number := to_number(p_txt, p_format);
  ELSE
    v_number := to_number(p_txt);
    if to_char(v_number)='~' then
      v_number := NULL;
    END IF;
  END IF;
  RETURN v_number;
EXCEPTION WHEN value_error THEN
  RETURN NULL;
END safe_to_number;
/


CREATE OR REPLACE PROCEDURE add_list_partition(p_table IN VARCHAR2,p_part_name IN VARCHAR2,p_values IN VARCHAR2)
AS
  part_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(part_exists, -14013);
  value_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(value_exists, -14312);
  v_values VARCHAR2(60) := p_values;
BEGIN
  if (safe_to_number(p_values) is null) then
    v_values := '''' || p_values || '''';
  end if;
  EXECUTE IMMEDIATE 'ALTER TABLE ' || p_table || ' ADD PARTITION ' || p_part_name || ' VALUES(' || v_values || ')';
  --TODO: Decide how we want to handle errors.  We should verify that if the partition exists, it has the same values.
  EXCEPTION
  WHEN part_exists THEN
       --Check that the value is
       null;
  WHEN value_exists THEN
       null;
END add_list_partition;
/

CREATE OR REPLACE PROCEDURE add_list_partitions(p_table IN VARCHAR2,p_part_src_tbl IN VARCHAR2, p_part_name_col IN VARCHAR2, p_part_val_col IN VARCHAR2 DEFAULT NULL
                                                ,p_part_prefix IN VARCHAR2 default 'P_'
                                                ,p_filter IN VARCHAR2 default '1=1')
AS
  v_sql VARCHAR2(400);
  v_part VARCHAR2(32);
  v_val VARCHAR2(32); --probably needs to be large for when we support multiple values.
  TYPE result_cur IS REF CURSOR;
  v_cursor result_cur;
  v_part_val_col VARCHAR2(100) := NVL(p_part_val_col,p_part_name_col);
BEGIN
  v_sql := 'SELECT DISTINCT ' || p_part_name_col || ' AS part_nm, ' || v_part_val_col || ' AS part_val FROM ' || p_part_src_tbl || ' t ' || ' WHERE ' || p_filter || ' GROUP BY ' || p_part_name_col;
  OPEN v_cursor FOR v_sql;
  LOOP
    FETCH v_cursor INTO v_part,v_val;
    EXIT WHEN v_cursor%NOTFOUND;
    add_list_partition(p_table => p_table,p_part_name => p_part_prefix || v_part,p_values => v_val);
  END LOOP;
END add_list_partitions;
/

CREATE OR REPLACE FUNCTION is_bitvalue(p_val IN NUMBER) RETURN NUMBER
DETERMINISTIC
AS
BEGIN
  IF (p_val <= 0) THEN
     RETURN 0;
  ELSE
     RETURN CASE WHEN BITAND(p_val,p_val-1) = 0 THEN 1 ELSE 0 END;
  END IF;
END;
/


-- The below functions were added for OADW-1749
CREATE OR REPLACE FUNCTION add_yr_month(p_yr_month IN NUMBER,p_increment IN NUMBER) RETURN NUMBER
DETERMINISTIC
IS
  v_return NUMBER;
  v_year NUMBER := TO_NUMBER(SUBSTR(p_yr_month,1,4));
  v_month NUMBER := TO_NUMBER(SUBSTR(p_yr_month,-2));
BEGIN
  v_month := v_month + p_increment;
  IF (v_month = 0) THEN
    v_year := v_year - 1;
    v_month := 12;
  ELSIF (v_month < 1) THEN
    v_year := v_year + FLOOR(v_month / 12);
    v_month := 12 + MOD(v_month,12);
  ELSIF (v_month > 12) THEN
        v_year := v_year + FLOOR(v_month / 12);
        v_month := MOD(v_month , 12);
  END IF;
  v_return := (v_year * 100) + v_month;
  RETURN(v_return);
END add_yr_month;
/
CREATE OR REPLACE FUNCTION age_as_of (birth_date in date, as_of_date in date := sysdate, unit in VARCHAR2 := 'YEAR')
--Return an age based on the birthdate and as_of_date supplied
--Age will be returned as a whole number
--If birthdate is null return null
--valid units include: YEAR or MONTH
    RETURN NUMBER
    DETERMINISTIC
IS
    PRAGMA UDF;
    age  INTEGER;
BEGIN
    IF birth_date IS NULL THEN
        RETURN NULL;
    END IF;

    -- Calculate the age in months
    age := FLOOR (MONTHS_BETWEEN (TRUNC (as_of_date), TRUNC (birth_date)));

    -- Calculate age in MONTHs or YEARs
    CASE UPPER (unit)
    WHEN 'MONTH' THEN
        NULL;
    WHEN 'YEAR' THEN
        age := FLOOR (age / 12);
    ELSE
        RETURN NULL;
    END CASE;

    -- Return age
    RETURN age;

EXCEPTION
WHEN VALUE_ERROR THEN
    RETURN NULL;
END age_as_of;
/

CREATE OR REPLACE TYPE bitand_impl AS OBJECT
(
  agg_bitand INTEGER,

  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitand_impl) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitand_impl,
                                       val  IN INTEGER) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitand_impl,
                                     ctx2 IN bitand_impl) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitand_impl,
                                         returnval OUT INTEGER,
                                         flags     IN NUMBER) RETURN NUMBER
)
/

CREATE OR REPLACE TYPE BODY bitand_impl IS
  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitand_impl) RETURN NUMBER IS
  BEGIN
    ctx := bitand_impl(NULL);
    RETURN ODCIConst.Success;
  END ODCIAggregateInitialize;

  MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitand_impl,
                                       val  IN INTEGER) RETURN NUMBER IS
  BEGIN
    SELF.agg_bitand :=  bitand(NVL(SELF.agg_bitand,val), val);
    RETURN ODCIConst.Success;
  END ODCIAggregateIterate;

  MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitand_impl,
                                     ctx2 IN bitand_impl) RETURN NUMBER IS
  BEGIN
    SELF.agg_bitand := bitand(NVL(SELF.agg_bitand,ctx2.agg_bitand), ctx2.agg_bitand);
    RETURN ODCIConst.Success;
  END ODCIAggregateMerge;

  MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitand_impl,
                                         returnval OUT INTEGER,
                                         flags     IN NUMBER) RETURN NUMBER IS
  BEGIN
    returnval := SELF.agg_bitand;
    RETURN ODCIConst.Success;
  END ODCIAggregateTerminate;
END;
/

CREATE OR REPLACE FUNCTION bitandagg(x IN INTEGER) RETURN INTEGER
PARALLEL_ENABLE
AGGREGATE USING bitand_impl;
/

CREATE OR REPLACE FUNCTION bitor(p_bitfield1 IN NUMBER,p_bitfield2 IN NUMBER,p_bitfield3 IN NUMBER DEFAULT 0) RETURN NUMBER
DETERMINISTIC
AS
       v_f1 NUMBER := NVL(p_bitfield1,0);
       v_f2 NUMBER := NVL(p_bitfield2,0);
       v_f3 NUMBER := NVL(p_bitfield3,0);
       v_tmp NUMBER;
BEGIN
  IF (least(v_f1,v_f2,v_f3) < 0) THEN
     RETURN 0;
  ELSE
     v_tmp := v_f1 + v_f2 - bitand(v_f1,v_f2);
     v_tmp := v_tmp + v_f3 - bitand(v_tmp,v_f3);
     RETURN v_tmp;
  END IF;
END;
/

CREATE OR REPLACE TYPE bitor_impl AS OBJECT
(
  agg_bitor INTEGER,

  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitor_impl) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitor_impl,
                                       val  IN INTEGER) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitor_impl,
                                     ctx2 IN bitor_impl) RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitor_impl,
                                         returnval OUT INTEGER,
                                         flags     IN NUMBER) RETURN NUMBER
)
/

CREATE OR REPLACE TYPE BODY bitor_impl IS
  STATIC FUNCTION ODCIAggregateInitialize(ctx IN OUT NOCOPY bitor_impl) RETURN NUMBER IS
  BEGIN
    ctx := bitor_impl(0);
    RETURN ODCIConst.Success;
  END ODCIAggregateInitialize;

  MEMBER FUNCTION ODCIAggregateIterate(SELF IN OUT NOCOPY bitor_impl,
                                       val  IN INTEGER) RETURN NUMBER IS
  BEGIN
    SELF.agg_bitor := SELF.agg_bitor + val - bitand(SELF.agg_bitor, val);
    RETURN ODCIConst.Success;
  END ODCIAggregateIterate;

  MEMBER FUNCTION ODCIAggregateMerge(SELF IN OUT NOCOPY bitor_impl,
                                     ctx2 IN bitor_impl) RETURN NUMBER IS
  BEGIN
    SELF.agg_bitor := SELF.agg_bitor + ctx2.agg_bitor - bitand(SELF.agg_bitor, ctx2.agg_bitor);
    RETURN ODCIConst.Success;
  END ODCIAggregateMerge;

  MEMBER FUNCTION ODCIAggregateTerminate(SELF      IN OUT NOCOPY bitor_impl,
                                         returnval OUT INTEGER,
                                         flags     IN NUMBER) RETURN NUMBER IS
  BEGIN
    returnval := SELF.agg_bitor;
    RETURN ODCIConst.Success;
  END ODCIAggregateTerminate;
END;
/

CREATE OR REPLACE FUNCTION bitoragg(x IN INTEGER) RETURN INTEGER
PARALLEL_ENABLE
AGGREGATE USING bitor_impl;
/

CREATE OR REPLACE FUNCTION generate_date_subpartitions(p_years IN NUMBER DEFAULT 5
                                                       ,p_sub_part_ind IN NUMBER DEFAULT 1
                                                      ,p_years_future IN NUMBER DEFAULT 0
                                                      ,p_value_type IN VARCHAR2 DEFAULT 'DATE') RETURN VARCHAR2
IS
  v_result VARCHAR2(4000);
  v_min_yr NUMBER;
  v_max_yr NUMBER;
  v_part_prefix VARCHAR2(3) := CASE WHEN p_sub_part_ind = 1 THEN 'SUB' ELSE NULL END;
  v_value_expr VARCHAR2(100);
BEGIN
  -- start creating following new year sub-partitions 1 month ahead. eg: create 2018 sub-partitions starting 01-dec-2017
  SELECT TO_NUMBER(TO_CHAR(SYSDATE,'YYYY')) - p_years INTO v_min_yr FROM DUAL;
  SELECT TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE,1),'YYYY')) + p_years_future INTO v_max_yr FROM DUAL;

  IF (p_value_type = 'NUMBER') THEN
     v_value_expr := q'[YEARVAL01]';
  ELSIF (p_value_type = 'DATE') THEN
     v_value_expr := q'[TO_DATE('YEARVAL0101','YYYYMMDD')]';
  ELSE
     raise_application_error(-20001, 'Invalid p_value_type argument to generate_date_subpartitions');
  END IF;

  v_result := replace(v_part_prefix || 'PARTITION P_pre' || v_min_yr || q'[ VALUES LESS THAN (]' || v_value_expr || ')','YEARVAL',v_min_yr);
  for yr in v_min_yr..v_max_yr
  loop
    v_result := v_result || chr(10) || replace(',' || v_part_prefix || 'PARTITION P_' || yr || q'[ VALUES LESS THAN (]' || v_value_expr || ')','YEARVAL',yr + 1);
  end loop;

  return(v_result);
end generate_date_subpartitions;
/

CREATE OR REPLACE FUNCTION generate_hash_partitions(p_cnt IN NUMBER DEFAULT 4,p_sub_part_ind IN NUMBER DEFAULT 0) RETURN VARCHAR2
IS
  v_result VARCHAR2(4000);
  v_part_nm VARCHAR2(8);
  v_part_prefix VARCHAR2(3) := CASE WHEN p_sub_part_ind = 1 THEN 'SUB' ELSE NULL END;
BEGIN
  -- create hash partitions

  v_result := v_part_prefix || 'PARTITION P_01';
  for pidx in 2..p_cnt
  loop
    v_result := v_result || chr(10) || ',' || v_part_prefix || 'PARTITION P_' || lpad(pidx,2,'0');
  end loop;

  return(v_result);
end generate_hash_partitions;
/

create or replace function get_ii_filename (p_client_id in varchar2,p_process_id in number ,p_script_name in varchar2 ) return varchar2
is
  l_filename varchar2(100);
begin
  if p_process_id = 0 then
    -- no valid process_id exists, set to default values
    -- these will point to an empty file so a select against the external table will succeed but return zero rows
    l_filename    := 'DO_NOT_REMOVE';  -- DO_NOT_REMOVE.txt
  else
    -- a valid process_id exists, set to group-specific values.
    l_filename    := p_process_id||'_'||p_client_id||'_'||p_script_name;  -- eg 34048_H704847_ADM_COSTS_ADMLEVEL
  end if;
  return(l_filename);
end ;
/

create or replace function get_ii_group_directory (p_client_id in varchar2,p_process_id in number) return varchar2
is
  l_group_dir varchar2(30);
begin
  if p_process_id = 0 then
    -- no valid process_id exists, set to default values
    -- these will point to an empty file so a select against the external table will succeed but return zero rows
    l_group_dir := 'II_EXTERNAL_COMMON';  -- /misc/phiops/archive/in_ii
  else
    -- a valid process_id exists, set to group-specific values.
    l_group_dir := p_client_id||'_LOAD_DIR_PROD';   -- eg H704847_LOAD_DIR_PROD
  end if;
  return(l_group_dir);
end ;
/

create or replace function get_ii_process_id (p_client_id in varchar2
                                             ,p_process_id in varchar2 := '0'
                                             ,p_cdr_schema in varchar2
                                             ,p_cdr_view in varchar2 := null
                                              )
return number
is
  c_proc_name varchar2(30) := $$PLSQL_UNIT;
  l_process_id number(10) :=0;
  l_cdr_view varchar2(30) := 'v_bpo_ext_table_process_id';
  l_cnt pls_integer;
  l_sql varchar2(1000);
  p_process_num number(10);
  v_where_clause varchar2(100) := '';

begin
  l_cdr_view := nvl(p_cdr_view, l_cdr_view);
  -- confirm view exists
  select count(*)
  into   l_cnt
  from all_views where owner = upper(p_cdr_schema) and view_name = upper(l_cdr_view);
  if l_cnt = 0 then
    raise_application_error (-20000, c_proc_name||': Specified view does not exist '''||p_cdr_schema||'.'||l_cdr_view||'''');
    l_process_id := 0;
  end if;

  -- if process_id is specified from command line, validate and use that
  if p_process_id not in ('0','*') then
    -- validate from view, raise error if not found
    -- check if the process id is actually a valid number. if it is then return it else - exception ....
    if safe_to_number(p_process_id) is null then
      raise_application_error (-20009, c_proc_name||': Specified process_id '||p_process_id||' is invalid');
      l_process_id := 0;
    end if;
    p_process_num := p_process_id;
    l_sql := 'select process_id
              from   '||p_cdr_schema||'.'||l_cdr_view||'
              where  client_id = :clientid
              and    process_id = :pid ';
    begin
      execute immediate l_sql into l_process_id using p_client_id, p_process_num;
    exception
      when no_data_found then
        raise_application_error (-20001, c_proc_name||': Specified process_id '||p_process_id||' does not exist in '||p_cdr_schema||'.'||l_cdr_view||' for '||p_client_id);
    end;
  else
    if p_process_id = '0' then
        v_where_clause := ' and out_schema_name = ''' || upper(p_cdr_schema) || '''';
     else
       v_where_clause := '';
    end if;
    -- look up from view:
    --   Get the most recent sendout per schema for this client_id
    --   From these, select the latest send out for this source schema.  If no successful process for this schema, select the latest process_id
    l_sql := 'select process_id
              from   (select *
                      from   (select v.*
                                    ,row_number() over (partition by out_schema_name order by out_transfer_timestamp desc) as latest_procid_per_schema
                              from  '||p_cdr_schema||'.'||l_cdr_view||' v
                              where  client_id = :clientid added_where_clause
                              )
                      where latest_procid_per_schema = 1
                      order by decode(out_schema_name, :cdr_schm, 1, 0) desc, out_transfer_timestamp desc
                      )
              where rownum = 1';
    begin
      l_sql := replace( l_sql, 'added_where_clause', v_where_clause);
      execute immediate l_sql into l_process_id using p_client_id, upper(p_cdr_schema) ;
    exception
      when no_data_found then
        l_process_id := 0;
    end;
  end if;
  return l_process_id;
end ;
/

CREATE OR REPLACE FUNCTION is_bitvalue(p_val IN NUMBER) RETURN NUMBER
DETERMINISTIC
AS
BEGIN
  IF (p_val <= 0) THEN
     RETURN 0;
  ELSE
     RETURN CASE WHEN BITAND(p_val,p_val-1) = 0 THEN 1 ELSE 0 END;
  END IF;
END;
/
CREATE OR REPLACE FUNCTION safe_to_number (p_txt IN VARCHAR2
                                          ,p_format IN VARCHAR2 := NULL)
  RETURN NUMBER
  DETERMINISTIC
IS
  v_number  number;
BEGIN
  IF p_format IS NOT NULL THEN
    v_number := to_number(p_txt, p_format);
  ELSE
    v_number := to_number(p_txt);
    if to_char(v_number)='~' then
      v_number := NULL;
    END IF;
  END IF;
  RETURN v_number;
EXCEPTION WHEN value_error THEN
  RETURN NULL;
END safe_to_number;
/
CREATE OR REPLACE PROCEDURE update_current_schema (p_dest_schema IN varchar2)
AUTHID CURRENT_USER
IS
  l_cnt1               number;
  l_cnt2               number;
  l_referenced_owner   varchar2(30);
  l_sql                varchar2(2000);
  cursor c0 is select object_name from user_objects where object_type in ('VIEW');
  cursor c1 (dest_schema  varchar2) is select object_type, object_name from all_objects where owner = UPPER(dest_schema)
    and object_type in ('TABLE','VIEW') order by object_type, object_name;
  cursor c2 (dest_schema  varchar2) is select object_name from user_objects where object_type in ('SYNONYM')
    minus
    select object_name from all_objects where owner = UPPER(dest_schema) and object_type in ('TABLE','VIEW');
  cursor c3 (dest_schema  varchar2) is select object_name from user_objects where object_type in ('VIEW')
    minus
    select object_name from all_objects where owner = UPPER(dest_schema) and object_type in ('TABLE','VIEW');
BEGIN
  FOR X in c0 LOOP
    l_sql :=  'DROP VIEW ' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  FOR X in c1 (p_dest_schema) LOOP
    l_sql :=  'CREATE OR REPLACE SYNONYM ' || X.object_name || ' FOR ' || upper(p_dest_schema) || '.' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  FOR X in c2 (p_dest_schema) LOOP
    l_sql :=  'DROP SYNONYM ' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  FOR X in c3 (p_dest_schema) LOOP
    l_sql :=  'DROP VIEW ' || X.object_name ;
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;

  select count(*)
  into l_cnt1
  from USER_DEPENDENCIES
  where REFERENCED_OWNER not in ('PUBLIC','SYS')
  and REFERENCED_OWNER not in (select user from dual)
  and type ='SYNONYM';

  select referenced_owner, count(*)
  into l_referenced_owner, l_cnt1
  from USER_DEPENDENCIES
  where REFERENCED_OWNER not in ('PUBLIC','SYS')
  and REFERENCED_OWNER not in (select user from dual)
  and type ='SYNONYM'
  group by referenced_owner;

  IF l_referenced_owner != upper(p_dest_schema) THEN
   RAISE_APPLICATION_ERROR(-20000, 'Validation Error: referenced_owner ' || l_referenced_owner || ' and dest schema ' || upper(p_dest_schema) || ' mismatch!');
  END IF;

  select count(*)
  into l_cnt2
  from ALL_OBJECTS
  where owner = UPPER(p_dest_schema)
  and object_type in ('TABLE','VIEW');

  IF l_cnt1 != l_cnt2 THEN
    RAISE_APPLICATION_ERROR(-20001, 'Validation Error: CURRENT schema synonym count ' || to_char(l_cnt1) || ' and dest schema ' || upper(p_dest_schema) || ' table/view count ' || to_char(l_cnt2) || ' mismatch!');
  END IF;
END;
/
CREATE OR REPLACE PROCEDURE grant_synonyms_select (p_link_schema IN varchar2)
IS
  l_cnt1          number;
  l_sql           varchar2(2000);
  l_schema_upper  varchar2(30);
BEGIN
  l_schema_upper := UPPER(p_link_schema);

  SELECT count(username)
  INTO l_cnt1
  FROM all_users
  WHERE UPPER(username) = l_schema_upper;

  IF l_cnt1 = 1 THEN
    FOR x IN (SELECT SYNONYM_NAME FROM user_synonyms ORDER BY SYNONYM_NAME) LOOP
       l_sql :=  'GRANT SELECT ON ' || x.SYNONYM_NAME || ' TO ' || l_schema_upper ;
       EXECUTE IMMEDIATE l_sql ;
    END LOOP;
  END IF;
END;
/
create or replace PROCEDURE grant_synonyms_to_opa_rep (client_id IN varchar2, env in varchar2)
IS
  rep_schema_pattern varchar2(30);
BEGIN
  rep_schema_pattern := UPPER('REP_%'||client_id||'%'||env||'%');
  FOR x IN (select USERNAME from all_users where username like rep_schema_pattern) LOOP
    grant_synonyms_select(x.USERNAME);
  END LOOP;
END;
/
CREATE OR REPLACE PROCEDURE set_user_columns_nullable
IS
  l_sql           varchar2(2000);
BEGIN
  FOR x IN (SELECT table_name, column_name FROM user_tab_columns where NULLABLE = 'N'
                   and table_name in (select object_name from user_objects where object_type='TABLE')
           )
  LOOP
    l_sql :=  'ALTER TABLE ' || user || '.' || x.table_name || ' MODIFY ' || x.column_name || ' NULL';
    EXECUTE IMMEDIATE l_sql ;
  END LOOP;
END;
/
-- Auto-generated content from oadw_combined_schema.hql
DECLARE
    PROCEDURE DROP_IF_EXISTS (objectName IN VARCHAR2, objectType IN VARCHAR2 )
    IS
    v_counter number:=0;
    BEGIN

        IF (objectType = 'TABLE') THEN
        select count(*) into v_counter from user_tables where table_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName || ' CASCADE CONSTRAINTS PURGE';
        end if;
        END IF;

        IF (objectType = 'VIEW') THEN
        select count(*) into v_counter from user_views where view_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName;
        end if;
        END IF;

        commit;

    END;
BEGIN

-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_confinements', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_confinements (
	"CLUSTER" NUMBER (10, 0),
	"EXCLUDE" NUMBER (1),
	acw_srv NUMBER (10, 0),
	admit NUMBER (1),
	admit_source VARCHAR2 (1 CHAR),
	amt_admin_fee NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_cf NUMBER (19, 4),
	amt_liab NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_cf NUMBER (19, 4),
	amt_req NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	avoidable_admit_flag NUMBER (10, 0),
	beg_dt TIMESTAMP,
	bill_drg_id VARCHAR2 (12 CHAR),
	bill_provider_id VARCHAR2 (20 CHAR),
	clm_type VARCHAR2 (1 CHAR),
	clus_prv VARCHAR2 (20 CHAR),
	conf_num NUMBER (19, 0),
	contract_id VARCHAR2 (40 CHAR),
	covid_flag NUMBER (1),
	cust_med_1 VARCHAR2 (255 CHAR),
	cust_med_10 VARCHAR2 (255 CHAR),
	cust_med_11 VARCHAR2 (255 CHAR),
	cust_med_12 VARCHAR2 (255 CHAR),
	cust_med_13 VARCHAR2 (255 CHAR),
	cust_med_14 VARCHAR2 (255 CHAR),
	cust_med_15 VARCHAR2 (255 CHAR),
	cust_med_16 NUMBER (38, 10),
	cust_med_17 NUMBER (38, 10),
	cust_med_18 NUMBER (38, 10),
	cust_med_19 NUMBER (38, 10),
	cust_med_2 VARCHAR2 (255 CHAR),
	cust_med_20 NUMBER (38, 10),
	cust_med_3 VARCHAR2 (255 CHAR),
	cust_med_4 VARCHAR2 (255 CHAR),
	cust_med_5 VARCHAR2 (255 CHAR),
	cust_med_6 VARCHAR2 (255 CHAR),
	cust_med_7 VARCHAR2 (255 CHAR),
	cust_med_8 VARCHAR2 (255 CHAR),
	cust_med_9 VARCHAR2 (255 CHAR),
	cust_med_pk_id VARCHAR2 (32 CHAR),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag11 VARCHAR2 (8 CHAR),
	diag12 VARCHAR2 (8 CHAR),
	diag13 VARCHAR2 (8 CHAR),
	diag14 VARCHAR2 (8 CHAR),
	diag15 VARCHAR2 (8 CHAR),
	diag16 VARCHAR2 (8 CHAR),
	diag17 VARCHAR2 (8 CHAR),
	diag18 VARCHAR2 (8 CHAR),
	diag19 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag20 VARCHAR2 (8 CHAR),
	diag21 VARCHAR2 (8 CHAR),
	diag22 VARCHAR2 (8 CHAR),
	diag23 VARCHAR2 (8 CHAR),
	diag24 VARCHAR2 (8 CHAR),
	diag25 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	disrel NUMBER (10, 0),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	drg_outlier NUMBER (10, 0),
	encounter NUMBER (19, 2),
	end_dt TIMESTAMP,
	episode_id NUMBER (19, 0),
	er_conf NUMBER (1),
	etg VARCHAR2 (9 CHAR),
	etg_id NUMBER (10, 0),
	etg_sub_id VARCHAR2 (7 CHAR),
	ia_time NUMBER (10, 0),
	icd_version NUMBER (10, 0),
	icustay NUMBER (10, 0),
	icusurg NUMBER (10, 0),
	inp_admit_type VARCHAR2 (2 CHAR),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc11 VARCHAR2 (7 CHAR),
	iproc12 VARCHAR2 (7 CHAR),
	iproc13 VARCHAR2 (7 CHAR),
	iproc14 VARCHAR2 (7 CHAR),
	iproc15 VARCHAR2 (7 CHAR),
	iproc16 VARCHAR2 (7 CHAR),
	iproc17 VARCHAR2 (7 CHAR),
	iproc18 VARCHAR2 (7 CHAR),
	iproc19 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc20 VARCHAR2 (7 CHAR),
	iproc21 VARCHAR2 (7 CHAR),
	iproc22 VARCHAR2 (7 CHAR),
	iproc23 VARCHAR2 (7 CHAR),
	iproc24 VARCHAR2 (7 CHAR),
	iproc25 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	lag_days NUMBER (10, 0),
	lag_ind NUMBER (1),
	los NUMBER (10, 0),
	matern NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	msurg NUMBER (10, 0),
	network_paid_status_id VARCHAR2 (40 CHAR),
	newborn NUMBER (10, 0),
	noenr_dos NUMBER (1),
	pac_rsnf_index NUMBER (1),
	pac_rsnf_postconf NUMBER (19, 0),
	pac_rsnf_preconf NUMBER (19, 0),
	pac_rsnf_readm_days NUMBER (10, 0),
	pac_rsnf_readmit NUMBER (1),
	pay_dt TIMESTAMP,
	pay_dt_beg TIMESTAMP,
	pdi NUMBER (10, 0),
	peg_episode_id NUMBER (19, 0),
	planned_adm NUMBER (1),
	poa1 VARCHAR2 (1 CHAR),
	pos_i NUMBER (10, 0),
	pqi NUMBER (10, 0),
	prfl_clm NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_beg VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	psc_cat1_id NUMBER (10, 0),
	psc_cat2_id NUMBER (10, 0),
	readmit_07 NUMBER (1),
	readmit_30 NUMBER (1),
	readmit_60 NUMBER (1),
	readmit_90 NUMBER (1),
	readmit_conf_07 NUMBER (19, 0),
	readmit_conf_30 NUMBER (19, 0),
	readmit_conf_60 NUMBER (19, 0),
	readmit_conf_90 NUMBER (19, 0),
	readmit_index_07 NUMBER (1),
	readmit_index_30 NUMBER (1),
	readmit_index_60 NUMBER (1),
	readmit_index_90 NUMBER (1),
	rec_type VARCHAR2 (1 CHAR),
	rehab NUMBER (10, 0),
	rsnf NUMBER (10, 0),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	snf NUMBER (10, 0),
	sub_episode_num NUMBER (10, 0),
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_contract', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_contract (
	contract VARCHAR2 (30 CHAR),
	contract_desc VARCHAR2 (150 CHAR),
	contract_hier NUMBER (10, 0),
	contract_id VARCHAR2 (40 CHAR),
	contract_lv1 VARCHAR2 (30 CHAR),
	contract_lv1_desc VARCHAR2 (150 CHAR),
	contract_lv1_id VARCHAR2 (100 CHAR),
	contract_lv2 VARCHAR2 (30 CHAR),
	contract_lv2_desc VARCHAR2 (150 CHAR),
	contract_lv2_id VARCHAR2 (100 CHAR),
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_dcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_dcc (
	chronic NUMBER (1),
	dcc VARCHAR2 (5 CHAR),
	gen_name VARCHAR2 (255 CHAR),
	pcc VARCHAR2 (3 CHAR),
	tos_i_5 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_disease', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_disease (
	disease_desc VARCHAR2 (60 CHAR),
	disease_desc_mask VARCHAR2 (60 CHAR),
	disease_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_drg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_drg (
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_code VARCHAR2 (4 CHAR),
	drg_desc VARCHAR2 (200 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	drg_level VARCHAR2 (2 CHAR),
	drg_version VARCHAR2 (3 CHAR),
	drg_wgt NUMBER (10, 4),
	mdc NUMBER (10, 0),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_ebm_rules', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_ebm_rules (
	author VARCHAR2 (25 CHAR),
	enabled NUMBER (1),
	ext_flag NUMBER (10, 0),
	labdata_req NUMBER (1),
	labresults_req NUMBER (1),
	nqf_endorsed NUMBER (1),
	nqf_similar NUMBER (1),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0),
	rule_desc VARCHAR2 (212 CHAR),
	rule_type_id NUMBER (10, 0),
	rx_req NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_etg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_etg (
	chronic NUMBER (10, 0),
	etg_id NUMBER (10, 0),
	etg_impact VARCHAR2 (8 CHAR),
	etg_impact_desc VARCHAR2 (150 CHAR),
	family NUMBER (10, 0),
	mpc NUMBER (10, 0),
	tx_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_etg_base', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_etg_base (
	base VARCHAR2 (6 CHAR),
	base_desc VARCHAR2 (50 CHAR),
	base_desc_long VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_etg_comorb', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_etg_comorb (
	comorb_code NUMBER (10, 0),
	comorb_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_etg_cond', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_etg_cond (
	cond_desc VARCHAR2 (150 CHAR),
	cond_status NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_etg_family', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_etg_family (
	family NUMBER (10, 0),
	family_desc VARCHAR2 (80 CHAR),
	family_desc_mask VARCHAR2 (80 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_etg_impact', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_etg_impact (
	base VARCHAR2 (6 CHAR),
	etg VARCHAR2 (9 CHAR),
	etg_desc VARCHAR2 (150 CHAR),
	etg_impact VARCHAR2 (8 CHAR),
	etg_short VARCHAR2 (60 CHAR),
	prim_cond_code NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_etg_sev', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_etg_sev (
	etg_id NUMBER (10, 0),
	etg_sev_desc VARCHAR2 (150 CHAR),
	etg_sev_id NUMBER (10, 0),
	sev_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_etg_tx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_etg_tx (
	tx_code NUMBER (10, 0),
	tx_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_etg_unit', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_etg_unit (
	etg_unit VARCHAR2 (9 CHAR),
	etg_unit_desc VARCHAR2 (75 CHAR),
	etg_unit_id NUMBER (10, 0),
	family NUMBER (10, 0),
	mpc NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_icddx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_icddx (
	ccs_dx_cat VARCHAR2 (4 CHAR),
	ccsr_dx_cat VARCHAR2 (6 CHAR),
	icd_version NUMBER (10, 0),
	icddx VARCHAR2 (7 CHAR),
	icddx_desc VARCHAR2 (150 CHAR),
	planned_dx_flag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_icdproc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_icdproc (
	ccs_proc_cat VARCHAR2 (4 CHAR),
	ccsr_proc_cat VARCHAR2 (6 CHAR),
	icd_version NUMBER (10, 0),
	icdproc VARCHAR2 (7 CHAR),
	icdproc_desc VARCHAR2 (150 CHAR),
	planned_proc_flag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_mdc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_mdc (
	mdc NUMBER (10, 0),
	mdc_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_ndc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_ndc (
	brand_name VARCHAR2 (50 CHAR),
	brand_name_mask VARCHAR2 (50 CHAR),
	dcc VARCHAR2 (5 CHAR),
	ndc VARCHAR2 (11 CHAR),
	ndc_desc VARCHAR2 (50 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_pcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_pcc (
	pcc VARCHAR2 (3 CHAR),
	pcc_desc VARCHAR2 (120 CHAR),
	tcc VARCHAR2 (2 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_peg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_peg (
	peg_cat_desc VARCHAR2 (150 CHAR),
	peg_cat_id NUMBER (10, 0),
	peg_ppc NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_peg_target', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_peg_target (
	peg_target NUMBER (10, 0),
	peg_target_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_pop_morb_cat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_pop_morb_cat (
	"INTERVAL" NUMBER (19, 2),
	distrib_label VARCHAR2 (12 CHAR),
	high NUMBER (19, 2),
	low NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_pos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_pos (
	pos_desc VARCHAR2 (150 CHAR),
	pos_i NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_proccode', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_proccode (
	proccode VARCHAR2 (15 CHAR),
	proccode_desc VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_revenue', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_revenue (
	revenue VARCHAR2 (15 CHAR),
	revenue_desc VARCHAR2 (190 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_service_code', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_service_code (
	code_desc VARCHAR2 (255 CHAR),
	code_type NUMBER (10, 0),
	serv_code VARCHAR2 (15 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_tos (
	tos1 VARCHAR2 (100 CHAR),
	tos1_id NUMBER (10, 0),
	tos2 VARCHAR2 (100 CHAR),
	tos2_id NUMBER (10, 0),
	tos3 VARCHAR2 (120 CHAR),
	tos3_id NUMBER (10, 0),
	tos4 VARCHAR2 (255 CHAR),
	tos5 VARCHAR2 (255 CHAR),
	tos_i VARCHAR2 (255 CHAR),
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tos_i_short VARCHAR2 (255 CHAR),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_util_spec_cat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_util_spec_cat (
	def_util_spec_cat NUMBER (10, 0),
	util_spec1 VARCHAR2 (90 CHAR),
	util_spec2 VARCHAR2 (90 CHAR),
	util_spec_cat_cd NUMBER (10, 0),
	util_spec_cat_desc VARCHAR2 (90 CHAR),
	util_spec_id1 NUMBER (10, 0),
	util_spec_id2 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_map_utl_spc_cat_cpaoly', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_map_utl_spc_cat_cpaoly (
	def_util_spec_cat NUMBER (10, 0),
	util_spec0 VARCHAR2 (90 CHAR),
	util_spec1 VARCHAR2 (90 CHAR),
	util_spec2 VARCHAR2 (90 CHAR),
	util_spec_cat_cd NUMBER (10, 0),
	util_spec_cat_desc VARCHAR2 (90 CHAR),
	util_spec_id0 NUMBER (10, 0),
	util_spec_id1 NUMBER (10, 0),
	util_spec_id2 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_ql_claims', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_ql_claims (
	account_id VARCHAR2 (40 CHAR),
	age NUMBER (10, 0),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	claim_id VARCHAR2 (30 CHAR),
	clm_exclude NUMBER (10, 0),
	clm_id_n VARCHAR2 (30 CHAR),
	clm_type VARCHAR2 (1 CHAR),
	conf_num NUMBER (19, 0),
	contract_id VARCHAR2 (40 CHAR),
	cost1 NUMBER (19, 2),
	cost1_k NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost2_k NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_k NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost4_k NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost5_k NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	cost6_k NUMBER (19, 2),
	days_sup NUMBER (10, 0),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	enc_k NUMBER (19, 2),
	encounter NUMBER (19, 2),
	episode_id NUMBER (19, 0),
	etg_id NUMBER (10, 0),
	from_dt TIMESTAMP,
	ia_time NUMBER (10, 0),
	icd_version NUMBER (10, 0),
	line_nat VARCHAR2 (10 CHAR),
	map_srce_n VARCHAR2 (6 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1),
	pay_dt TIMESTAMP,
	poa1 VARCHAR2 (1 CHAR),
	pos_i NUMBER (10, 0),
	proc_srv VARCHAR2 (15 CHAR),
	proc_srv_desc VARCHAR2 (200 CHAR),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	qlc_id NUMBER (19, 0),
	sev_level NUMBER (10, 0),
	sex NUMBER (1),
	svc_grp VARCHAR2 (30 CHAR),
	svc_qty NUMBER (19, 2),
	svc_qty_k NUMBER (19, 2),
	to_dt TIMESTAMP,
	tos_i_5 NUMBER (10, 0),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_services_inp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_services_inp (
	"EXCLUDE" NUMBER (1),
	admit_source VARCHAR2 (1 CHAR),
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cap_pay_k NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_cob_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_ded_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth1_k NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth2_k NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth3_k NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_oth4_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	amt_wth_k NUMBER (19, 2),
	bill_drg_id VARCHAR2 (12 CHAR),
	bill_drg_outlier NUMBER (10, 0),
	bill_provider_id VARCHAR2 (20 CHAR),
	bill_type VARCHAR2 (4 CHAR),
	cap_flag NUMBER (1),
	claim_id VARCHAR2 (30 CHAR),
	clm_id_n VARCHAR2 (30 CHAR),
	clm_type VARCHAR2 (1 CHAR),
	conf_num NUMBER (19, 0),
	contract_id VARCHAR2 (40 CHAR),
	cust_med_1 VARCHAR2 (255 CHAR),
	cust_med_10 VARCHAR2 (255 CHAR),
	cust_med_11 VARCHAR2 (255 CHAR),
	cust_med_12 VARCHAR2 (255 CHAR),
	cust_med_13 VARCHAR2 (255 CHAR),
	cust_med_14 VARCHAR2 (255 CHAR),
	cust_med_15 VARCHAR2 (255 CHAR),
	cust_med_16 NUMBER (38, 10),
	cust_med_17 NUMBER (38, 10),
	cust_med_18 NUMBER (38, 10),
	cust_med_19 NUMBER (38, 10),
	cust_med_2 VARCHAR2 (255 CHAR),
	cust_med_20 NUMBER (38, 10),
	cust_med_3 VARCHAR2 (255 CHAR),
	cust_med_4 VARCHAR2 (255 CHAR),
	cust_med_5 VARCHAR2 (255 CHAR),
	cust_med_6 VARCHAR2 (255 CHAR),
	cust_med_7 VARCHAR2 (255 CHAR),
	cust_med_8 VARCHAR2 (255 CHAR),
	cust_med_9 VARCHAR2 (255 CHAR),
	cust_med_pk_id VARCHAR2 (32 CHAR),
	cvx_code VARCHAR2 (3 CHAR),
	denied_ind_id VARCHAR2 (40 CHAR),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag11 VARCHAR2 (8 CHAR),
	diag12 VARCHAR2 (8 CHAR),
	diag13 VARCHAR2 (8 CHAR),
	diag14 VARCHAR2 (8 CHAR),
	diag15 VARCHAR2 (8 CHAR),
	diag16 VARCHAR2 (8 CHAR),
	diag17 VARCHAR2 (8 CHAR),
	diag18 VARCHAR2 (8 CHAR),
	diag19 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag20 VARCHAR2 (8 CHAR),
	diag21 VARCHAR2 (8 CHAR),
	diag22 VARCHAR2 (8 CHAR),
	diag23 VARCHAR2 (8 CHAR),
	diag24 VARCHAR2 (8 CHAR),
	diag25 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	dos TIMESTAMP,
	drg_id VARCHAR2 (12 CHAR),
	drg_outlier NUMBER (10, 0),
	er_conf NUMBER (1),
	er_flag NUMBER (1),
	from_dt TIMESTAMP,
	ia_time NUMBER (10, 0),
	icd_version NUMBER (10, 0),
	inp_admit_type VARCHAR2 (2 CHAR),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc11 VARCHAR2 (7 CHAR),
	iproc12 VARCHAR2 (7 CHAR),
	iproc13 VARCHAR2 (7 CHAR),
	iproc14 VARCHAR2 (7 CHAR),
	iproc15 VARCHAR2 (7 CHAR),
	iproc16 VARCHAR2 (7 CHAR),
	iproc17 VARCHAR2 (7 CHAR),
	iproc18 VARCHAR2 (7 CHAR),
	iproc19 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc20 VARCHAR2 (7 CHAR),
	iproc21 VARCHAR2 (7 CHAR),
	iproc22 VARCHAR2 (7 CHAR),
	iproc23 VARCHAR2 (7 CHAR),
	iproc24 VARCHAR2 (7 CHAR),
	iproc25 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	line_nat VARCHAR2 (10 CHAR),
	local_flag NUMBER (10, 0),
	map_srce_e VARCHAR2 (6 CHAR),
	map_srce_n VARCHAR2 (6 CHAR),
	map_srce_p VARCHAR2 (6 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	mod_n_2 VARCHAR2 (4 CHAR),
	mod_n_3 VARCHAR2 (4 CHAR),
	mod_n_4 VARCHAR2 (4 CHAR),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	noenr_dos NUMBER (1),
	obs_flag NUMBER (1),
	order_prov VARCHAR2 (20 CHAR),
	pay_dt TIMESTAMP,
	poa1 VARCHAR2 (1 CHAR),
	poa10 VARCHAR2 (1 CHAR),
	poa2 VARCHAR2 (1 CHAR),
	poa3 VARCHAR2 (1 CHAR),
	poa4 VARCHAR2 (1 CHAR),
	poa5 VARCHAR2 (1 CHAR),
	poa6 VARCHAR2 (1 CHAR),
	poa7 VARCHAR2 (1 CHAR),
	poa8 VARCHAR2 (1 CHAR),
	poa9 VARCHAR2 (1 CHAR),
	pos_i NUMBER (10, 0),
	pos_n VARCHAR2 (3 CHAR),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	prv_sp_n VARCHAR2 (30 CHAR),
	qty NUMBER (10, 0),
	qty_k NUMBER (10, 0),
	refer_prov VARCHAR2 (20 CHAR),
	revenue VARCHAR2 (15 CHAR),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	svc_grp VARCHAR2 (30 CHAR),
	to_dt TIMESTAMP,
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tos_n VARCHAR2 (30 CHAR),
	uniq_rec_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_services_med', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_services_med (
	"CLUSTER" NUMBER (10, 0),
	"EXCLUDE" NUMBER (1),
	acw_srv NUMBER (10, 0),
	admit_source VARCHAR2 (1 CHAR),
	amb_sens NUMBER (10, 0),
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cap_pay_k NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_cob_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_ded_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_cf NUMBER (19, 4),
	amt_eqv_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth1_k NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth2_k NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth3_k NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_oth4_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_cf NUMBER (19, 4),
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	amt_wth_k NUMBER (19, 2),
	bill_drg_id VARCHAR2 (12 CHAR),
	bill_drg_outlier NUMBER (10, 0),
	bill_provider_id VARCHAR2 (20 CHAR),
	bill_type VARCHAR2 (4 CHAR),
	cap_flag NUMBER (1),
	claim_id VARCHAR2 (30 CHAR),
	clm_id_n VARCHAR2 (30 CHAR),
	clm_type VARCHAR2 (1 CHAR),
	clus_prv VARCHAR2 (20 CHAR),
	conf_num NUMBER (19, 0),
	contract_id VARCHAR2 (40 CHAR),
	cov_order NUMBER (1),
	covid_flag NUMBER (1),
	cust_med_1 VARCHAR2 (255 CHAR),
	cust_med_10 VARCHAR2 (255 CHAR),
	cust_med_11 VARCHAR2 (255 CHAR),
	cust_med_12 VARCHAR2 (255 CHAR),
	cust_med_13 VARCHAR2 (255 CHAR),
	cust_med_14 VARCHAR2 (255 CHAR),
	cust_med_15 VARCHAR2 (255 CHAR),
	cust_med_16 NUMBER (38, 10),
	cust_med_17 NUMBER (38, 10),
	cust_med_18 NUMBER (38, 10),
	cust_med_19 NUMBER (38, 10),
	cust_med_2 VARCHAR2 (255 CHAR),
	cust_med_20 NUMBER (38, 10),
	cust_med_3 VARCHAR2 (255 CHAR),
	cust_med_4 VARCHAR2 (255 CHAR),
	cust_med_5 VARCHAR2 (255 CHAR),
	cust_med_6 VARCHAR2 (255 CHAR),
	cust_med_7 VARCHAR2 (255 CHAR),
	cust_med_8 VARCHAR2 (255 CHAR),
	cust_med_9 VARCHAR2 (255 CHAR),
	cust_med_pk_id VARCHAR2 (32 CHAR),
	cvx_code VARCHAR2 (3 CHAR),
	dcc VARCHAR2 (5 CHAR),
	denied_ind_id VARCHAR2 (40 CHAR),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag11 VARCHAR2 (8 CHAR),
	diag12 VARCHAR2 (8 CHAR),
	diag13 VARCHAR2 (8 CHAR),
	diag14 VARCHAR2 (8 CHAR),
	diag15 VARCHAR2 (8 CHAR),
	diag16 VARCHAR2 (8 CHAR),
	diag17 VARCHAR2 (8 CHAR),
	diag18 VARCHAR2 (8 CHAR),
	diag19 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag20 VARCHAR2 (8 CHAR),
	diag21 VARCHAR2 (8 CHAR),
	diag22 VARCHAR2 (8 CHAR),
	diag23 VARCHAR2 (8 CHAR),
	diag24 VARCHAR2 (8 CHAR),
	diag25 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	disrel NUMBER (10, 0),
	dos TIMESTAMP,
	drg_id VARCHAR2 (12 CHAR),
	drg_outlier NUMBER (10, 0),
	ed_enc_id NUMBER (10, 0),
	em_svc_flag NUMBER (1),
	enc_k NUMBER (19, 2),
	encounter NUMBER (19, 2),
	episode_id NUMBER (19, 0),
	er_conf NUMBER (1),
	er_flag NUMBER (1),
	er_util NUMBER (19, 2),
	er_util_k NUMBER (19, 2),
	etg VARCHAR2 (9 CHAR),
	etg_id NUMBER (10, 0),
	etg_sub_id VARCHAR2 (7 CHAR),
	from_dt TIMESTAMP,
	ia_time NUMBER (10, 0),
	icd_version NUMBER (10, 0),
	inp_admit_type VARCHAR2 (2 CHAR),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc11 VARCHAR2 (7 CHAR),
	iproc12 VARCHAR2 (7 CHAR),
	iproc13 VARCHAR2 (7 CHAR),
	iproc14 VARCHAR2 (7 CHAR),
	iproc15 VARCHAR2 (7 CHAR),
	iproc16 VARCHAR2 (7 CHAR),
	iproc17 VARCHAR2 (7 CHAR),
	iproc18 VARCHAR2 (7 CHAR),
	iproc19 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc20 VARCHAR2 (7 CHAR),
	iproc21 VARCHAR2 (7 CHAR),
	iproc22 VARCHAR2 (7 CHAR),
	iproc23 VARCHAR2 (7 CHAR),
	iproc24 VARCHAR2 (7 CHAR),
	iproc25 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	lab_flag NUMBER (1),
	lab_util NUMBER (19, 2),
	lab_util_k NUMBER (19, 2),
	lag_days NUMBER (10, 0),
	lag_ind NUMBER (1),
	line_nat VARCHAR2 (10 CHAR),
	local_flag NUMBER (10, 0),
	map_srce_e VARCHAR2 (6 CHAR),
	map_srce_n VARCHAR2 (6 CHAR),
	map_srce_p VARCHAR2 (6 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	mod_n_2 VARCHAR2 (4 CHAR),
	mod_n_3 VARCHAR2 (4 CHAR),
	mod_n_4 VARCHAR2 (4 CHAR),
	mri_util NUMBER (19, 2),
	mri_util_k NUMBER (19, 2),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	noenr_dos NUMBER (1),
	np_op_visit_id NUMBER (19, 0),
	obs_flag NUMBER (1),
	op_visit_id NUMBER (10, 0),
	order_prov VARCHAR2 (20 CHAR),
	order_prv_i VARCHAR2 (20 CHAR),
	pay_dt TIMESTAMP,
	pcp_vis_flag NUMBER (1),
	pcp_vis_flag_k NUMBER (1),
	peg_episode_id NUMBER (19, 0),
	poa1 VARCHAR2 (1 CHAR),
	poa10 VARCHAR2 (1 CHAR),
	poa2 VARCHAR2 (1 CHAR),
	poa3 VARCHAR2 (1 CHAR),
	poa4 VARCHAR2 (1 CHAR),
	poa5 VARCHAR2 (1 CHAR),
	poa6 VARCHAR2 (1 CHAR),
	poa7 VARCHAR2 (1 CHAR),
	poa8 VARCHAR2 (1 CHAR),
	poa9 VARCHAR2 (1 CHAR),
	pos_i NUMBER (10, 0),
	pos_n VARCHAR2 (3 CHAR),
	prfl_clm NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	prv_sp_n VARCHAR2 (30 CHAR),
	psc_cat1_id NUMBER (10, 0),
	psc_cat2_id NUMBER (10, 0),
	pseudo NUMBER (1),
	qty NUMBER (10, 0),
	qty_k NUMBER (10, 0),
	rad_flag NUMBER (1),
	rad_util NUMBER (19, 2),
	rad_util_k NUMBER (19, 2),
	rec_type VARCHAR2 (1 CHAR),
	ref_flag NUMBER (1),
	ref_flag_k NUMBER (1),
	ref_vis_flag NUMBER (1),
	ref_vis_flag_k NUMBER (1),
	refer_prov VARCHAR2 (20 CHAR),
	revenue VARCHAR2 (15 CHAR),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	spec_drug NUMBER (10, 0),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	sub_episode_num NUMBER (10, 0),
	svc_grp VARCHAR2 (30 CHAR),
	th_flag NUMBER (1),
	to_dt TIMESTAMP,
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tos_n VARCHAR2 (30 CHAR),
	unavoid_ed NUMBER (10, 0),
	uniq_rec_id NUMBER (19, 0),
	user_spec_drug NUMBER (10, 0),
	util_spec_cat_cd NUMBER (10, 0),
	util_spec_enc NUMBER (10, 0),
	util_spec_enc_k NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ii_services_rx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ii_services_rx (
	"CLUSTER" NUMBER (10, 0),
	"EXCLUDE" NUMBER (1),
	acw_srv NUMBER (10, 0),
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cap_pay_k NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_cob_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_ded_k NUMBER (19, 2),
	amt_disp NUMBER (19, 2),
	amt_disp_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_cf NUMBER (19, 4),
	amt_eqv_k NUMBER (19, 2),
	amt_ingr NUMBER (19, 2),
	amt_ingr_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth1_k NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth2_k NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth3_k NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_oth4_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_cf NUMBER (19, 4),
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	amt_sales_tax NUMBER (19, 2),
	amt_sales_tax_k NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	amt_wth_k NUMBER (19, 2),
	cap_flag NUMBER (1),
	channel NUMBER (10, 0),
	claim_id VARCHAR2 (30 CHAR),
	clm_id_n VARCHAR2 (30 CHAR),
	clm_type VARCHAR2 (1 CHAR),
	clus_prv VARCHAR2 (20 CHAR),
	contract_id VARCHAR2 (40 CHAR),
	covid_flag NUMBER (1),
	cust_rx_1 VARCHAR2 (255 CHAR),
	cust_rx_10 VARCHAR2 (255 CHAR),
	cust_rx_11 VARCHAR2 (255 CHAR),
	cust_rx_12 VARCHAR2 (255 CHAR),
	cust_rx_13 VARCHAR2 (255 CHAR),
	cust_rx_14 VARCHAR2 (255 CHAR),
	cust_rx_15 VARCHAR2 (255 CHAR),
	cust_rx_16 NUMBER (38, 10),
	cust_rx_17 NUMBER (38, 10),
	cust_rx_18 NUMBER (38, 10),
	cust_rx_19 NUMBER (38, 10),
	cust_rx_2 VARCHAR2 (255 CHAR),
	cust_rx_20 NUMBER (38, 10),
	cust_rx_3 VARCHAR2 (255 CHAR),
	cust_rx_4 VARCHAR2 (255 CHAR),
	cust_rx_5 VARCHAR2 (255 CHAR),
	cust_rx_6 VARCHAR2 (255 CHAR),
	cust_rx_7 VARCHAR2 (255 CHAR),
	cust_rx_8 VARCHAR2 (255 CHAR),
	cust_rx_9 VARCHAR2 (255 CHAR),
	cust_rx_pk_id VARCHAR2 (32 CHAR),
	daw NUMBER (10, 0),
	days_sup NUMBER (10, 0),
	days_sup_k NUMBER (10, 0),
	dcc VARCHAR2 (5 CHAR),
	dea VARCHAR2 (15 CHAR),
	denied_ind_id VARCHAR2 (40 CHAR),
	disrel NUMBER (10, 0),
	dos TIMESTAMP,
	enc_k NUMBER (19, 2),
	encounter NUMBER (19, 2),
	episode_id NUMBER (19, 0),
	etg VARCHAR2 (9 CHAR),
	etg_id NUMBER (10, 0),
	etg_sub_id VARCHAR2 (7 CHAR),
	formulary NUMBER (10, 0),
	gbo NUMBER (10, 0),
	generic NUMBER (1),
	generic_k NUMBER (1),
	ia_time NUMBER (10, 0),
	lag_days NUMBER (10, 0),
	lag_ind NUMBER (1),
	map_srce_e VARCHAR2 (6 CHAR),
	map_srce_n VARCHAR2 (6 CHAR),
	map_srce_p VARCHAR2 (6 CHAR),
	member VARCHAR2 (32 CHAR),
	met_qty NUMBER (19, 2),
	met_qty_k NUMBER (19, 2),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	noenr_dos NUMBER (1),
	pay_dt TIMESTAMP,
	peg_episode_id NUMBER (19, 0),
	pres_prov_affil_id VARCHAR2 (40 CHAR),
	pres_provider_id VARCHAR2 (20 CHAR),
	pres_prv_i VARCHAR2 (20 CHAR),
	prfl_clm NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	psc_cat1_id NUMBER (10, 0),
	psc_cat2_id NUMBER (10, 0),
	pseudo NUMBER (1),
	rec_type VARCHAR2 (1 CHAR),
	refill_num NUMBER (10, 0),
	rx_count_n NUMBER (4, 2),
	rx_count_n_k NUMBER (4, 2),
	script NUMBER (19, 2),
	script_adj NUMBER (19, 2),
	script_adj_k NUMBER (19, 2),
	script_gen NUMBER (1),
	script_gen_k NUMBER (1),
	script_k NUMBER (19, 2),
	sev_level NUMBER (10, 0),
	spec_drug NUMBER (10, 0),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	sub_episode_num NUMBER (10, 0),
	svc_grp VARCHAR2 (30 CHAR),
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	uniq_rec_id NUMBER (19, 0),
	user_spec_drug NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_adm_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_adm_costs (
	account_id VARCHAR2 (40 CHAR),
	admit_act_tot NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	cat_member NUMBER (10, 0),
	cost2_act_tot NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	county_m NUMBER (10, 0),
	days_act_tot NUMBER (28, 6),
	days_peer_tot NUMBER (28, 6),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	drg_unit_id VARCHAR2 (12 CHAR),
	ia_time NUMBER (10, 0),
	ia_time_adj NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	peer_def_id NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	readmit_07_act_tot NUMBER (10, 0),
	readmit_07_peer_tot NUMBER (28, 6),
	readmit_30_act_tot NUMBER (10, 0),
	readmit_30_peer_tot NUMBER (28, 6),
	readmit_60_act_tot NUMBER (10, 0),
	readmit_60_peer_tot NUMBER (28, 6),
	readmit_90_act_tot NUMBER (10, 0),
	readmit_90_peer_tot NUMBER (28, 6),
	readmit_index_07_act_tot NUMBER (10, 0),
	readmit_index_30_act_tot NUMBER (10, 0),
	readmit_index_60_act_tot NUMBER (10, 0),
	readmit_index_90_act_tot NUMBER (10, 0),
	rrisk_adm_act_tot NUMBER (28, 6),
	rrisk_adm_peer_tot NUMBER (28, 6),
	sex NUMBER (1),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_adm_costs_admlevel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_adm_costs_admlevel (
	admit_act_tot NUMBER (10, 0),
	conf_num NUMBER (19, 0),
	cost2_act_tot NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	days_act_tot NUMBER (28, 6),
	days_peer_tot NUMBER (28, 6),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	drg_unit_id VARCHAR2 (12 CHAR),
	fac_qty_elig_peer NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	readmit_07_act_tot NUMBER (10, 0),
	readmit_07_peer_tot NUMBER (28, 6),
	readmit_30_act_tot NUMBER (10, 0),
	readmit_30_peer_tot NUMBER (28, 6),
	readmit_60_act_tot NUMBER (10, 0),
	readmit_60_peer_tot NUMBER (28, 6),
	readmit_90_act_tot NUMBER (10, 0),
	readmit_90_peer_tot NUMBER (28, 6),
	readmit_index_07_act_tot NUMBER (10, 0),
	readmit_index_30_act_tot NUMBER (10, 0),
	readmit_index_60_act_tot NUMBER (10, 0),
	readmit_index_90_act_tot NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_adm_det_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_adm_det_costs (
	account_id VARCHAR2 (40 CHAR),
	admit_act_tot NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	cat_member NUMBER (10, 0),
	cost2_act_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	county_m NUMBER (10, 0),
	days_act_tot NUMBER (28, 6),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	drg_outlier_cost NUMBER (10, 0),
	drg_outlier_los NUMBER (10, 0),
	drg_unit_id VARCHAR2 (12 CHAR),
	fac_qty_elig_peer NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	readmit_07_act_tot NUMBER (10, 0),
	readmit_30_act_tot NUMBER (10, 0),
	readmit_60_act_tot NUMBER (10, 0),
	readmit_90_act_tot NUMBER (10, 0),
	rrisk_adm_act_tot NUMBER (28, 6),
	sex NUMBER (1),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_clinmark', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_clinmark (
	ia_time NUMBER (10, 0),
	max_dt TIMESTAMP,
	member VARCHAR2 (32 CHAR),
	min_dt TIMESTAMP,
	occurrences NUMBER (10, 0),
	rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_cm_disprev_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_cm_disprev_costs (
	act_last NUMBER (1),
	acw_id NUMBER (10, 0),
	admit NUMBER (10, 0),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	dis_0001 NUMBER (10, 0),
	dis_0002 NUMBER (10, 0),
	dis_0003 NUMBER (10, 0),
	dis_0004 NUMBER (10, 0),
	dis_0005 NUMBER (10, 0),
	dis_0006 NUMBER (10, 0),
	dis_0007 NUMBER (10, 0),
	dis_0008 NUMBER (10, 0),
	dis_0009 NUMBER (10, 0),
	dis_0010 NUMBER (10, 0),
	dis_0011 NUMBER (10, 0),
	dis_0012 NUMBER (10, 0),
	dis_0013 NUMBER (10, 0),
	dis_0014 NUMBER (10, 0),
	dis_0015 NUMBER (10, 0),
	dis_0016 NUMBER (10, 0),
	dis_0017 NUMBER (10, 0),
	dis_0018 NUMBER (10, 0),
	dis_0020 NUMBER (10, 0),
	dis_0022 NUMBER (10, 0),
	dis_0023 NUMBER (10, 0),
	dis_0026 NUMBER (10, 0),
	dis_0029 NUMBER (10, 0),
	dis_0030 NUMBER (10, 0),
	dis_0031 NUMBER (10, 0),
	dis_0032 NUMBER (10, 0),
	dis_0033 NUMBER (10, 0),
	dis_0034 NUMBER (10, 0),
	dis_0035 NUMBER (10, 0),
	dis_0036 NUMBER (10, 0),
	dis_0037 NUMBER (10, 0),
	dis_0038 NUMBER (10, 0),
	dis_0040 NUMBER (10, 0),
	dis_0041 NUMBER (10, 0),
	dis_0042 NUMBER (10, 0),
	dis_0043 NUMBER (10, 0),
	dis_0047 NUMBER (10, 0),
	dis_0048 NUMBER (10, 0),
	dis_0050 NUMBER (10, 0),
	dis_0051 NUMBER (10, 0),
	dis_0052 NUMBER (10, 0),
	dis_0053 NUMBER (10, 0),
	dis_0054 NUMBER (10, 0),
	dis_0055 NUMBER (10, 0),
	dis_0056 NUMBER (10, 0),
	dis_0057 NUMBER (10, 0),
	dis_0058 NUMBER (10, 0),
	dis_0059 NUMBER (10, 0),
	dis_0060 NUMBER (10, 0),
	dis_0061 NUMBER (10, 0),
	dis_0065 NUMBER (10, 0),
	dis_0066 NUMBER (10, 0),
	dis_0067 NUMBER (10, 0),
	dis_0068 NUMBER (10, 0),
	dis_0069 NUMBER (10, 0),
	dis_0070 NUMBER (10, 0),
	dis_0071 NUMBER (10, 0),
	dis_0072 NUMBER (10, 0),
	dis_0073 NUMBER (10, 0),
	dis_0074 NUMBER (10, 0),
	dis_0075 NUMBER (10, 0),
	dis_0200 NUMBER (10, 0),
	dis_0201 NUMBER (10, 0),
	dis_0202 NUMBER (10, 0),
	dis_0203 NUMBER (10, 0),
	disease VARCHAR2 (250 CHAR),
	disrel NUMBER (10, 0),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	los NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	network_status NUMBER (1),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	prisk_cat NUMBER (10, 0),
	ptl_yr_enr NUMBER (1),
	rrisk_cat NUMBER (10, 0),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_cm_disprev_mem', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_cm_disprev_mem (
	act_last NUMBER (1),
	arisk NUMBER (10, 4),
	dis_0001 NUMBER (10, 0),
	dis_0002 NUMBER (10, 0),
	dis_0003 NUMBER (10, 0),
	dis_0004 NUMBER (10, 0),
	dis_0005 NUMBER (10, 0),
	dis_0006 NUMBER (10, 0),
	dis_0007 NUMBER (10, 0),
	dis_0008 NUMBER (10, 0),
	dis_0009 NUMBER (10, 0),
	dis_0010 NUMBER (10, 0),
	dis_0011 NUMBER (10, 0),
	dis_0012 NUMBER (10, 0),
	dis_0013 NUMBER (10, 0),
	dis_0014 NUMBER (10, 0),
	dis_0015 NUMBER (10, 0),
	dis_0016 NUMBER (10, 0),
	dis_0017 NUMBER (10, 0),
	dis_0018 NUMBER (10, 0),
	dis_0020 NUMBER (10, 0),
	dis_0022 NUMBER (10, 0),
	dis_0023 NUMBER (10, 0),
	dis_0026 NUMBER (10, 0),
	dis_0029 NUMBER (10, 0),
	dis_0030 NUMBER (10, 0),
	dis_0031 NUMBER (10, 0),
	dis_0032 NUMBER (10, 0),
	dis_0033 NUMBER (10, 0),
	dis_0034 NUMBER (10, 0),
	dis_0035 NUMBER (10, 0),
	dis_0036 NUMBER (10, 0),
	dis_0037 NUMBER (10, 0),
	dis_0038 NUMBER (10, 0),
	dis_0040 NUMBER (10, 0),
	dis_0041 NUMBER (10, 0),
	dis_0042 NUMBER (10, 0),
	dis_0043 NUMBER (10, 0),
	dis_0047 NUMBER (10, 0),
	dis_0048 NUMBER (10, 0),
	dis_0050 NUMBER (10, 0),
	dis_0051 NUMBER (10, 0),
	dis_0052 NUMBER (10, 0),
	dis_0053 NUMBER (10, 0),
	dis_0054 NUMBER (10, 0),
	dis_0055 NUMBER (10, 0),
	dis_0056 NUMBER (10, 0),
	dis_0057 NUMBER (10, 0),
	dis_0058 NUMBER (10, 0),
	dis_0059 NUMBER (10, 0),
	dis_0060 NUMBER (10, 0),
	dis_0061 NUMBER (10, 0),
	dis_0065 NUMBER (10, 0),
	dis_0066 NUMBER (10, 0),
	dis_0067 NUMBER (10, 0),
	dis_0068 NUMBER (10, 0),
	dis_0069 NUMBER (10, 0),
	dis_0070 NUMBER (10, 0),
	dis_0071 NUMBER (10, 0),
	dis_0072 NUMBER (10, 0),
	dis_0073 NUMBER (10, 0),
	dis_0074 NUMBER (10, 0),
	dis_0075 NUMBER (10, 0),
	dis_0200 NUMBER (10, 0),
	dis_0201 NUMBER (10, 0),
	dis_0202 NUMBER (10, 0),
	dis_0203 NUMBER (10, 0),
	disease VARCHAR2 (250 CHAR),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mems NUMBER (10, 0),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	prisk NUMBER (10, 4),
	prisk_cat NUMBER (10, 0),
	ptl_yr_enr NUMBER (1),
	rrisk_cat NUMBER (10, 0),
	tot_mm NUMBER (19, 2),
	wrrisk NUMBER (10, 4)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_conf_avoidable', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_conf_avoidable (
	account_id VARCHAR2 (40 CHAR),
	account_lv1_id VARCHAR2 (100 CHAR),
	account_lv2_id VARCHAR2 (100 CHAR),
	admit NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	avoidable_admit_flag NUMBER (10, 0),
	conf_num NUMBER (19, 0),
	contract_id VARCHAR2 (40 CHAR),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	county_id NUMBER (10, 0),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	fac_affil_id VARCHAR2 (40 CHAR),
	fac_name VARCHAR2 (50 CHAR),
	ia_time NUMBER (10, 0),
	los NUMBER (10, 0),
	mdc NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_assign_name VARCHAR2 (50 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pcp_imp_affil_id VARCHAR2 (40 CHAR),
	pcp_imp_name VARCHAR2 (50 CHAR),
	pdi NUMBER (10, 0),
	pqi NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR),
	product_lv1_id VARCHAR2 (100 CHAR),
	product_lv2_id VARCHAR2 (100 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	readmit_07 NUMBER (10, 0),
	readmit_30 NUMBER (10, 0),
	readmit_60 NUMBER (10, 0),
	readmit_90 NUMBER (10, 0),
	readmit_index_07 NUMBER (10, 0),
	readmit_index_30 NUMBER (10, 0),
	readmit_index_60 NUMBER (10, 0),
	readmit_index_90 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_confinements_pdi', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_confinements_pdi (
	conf_num NUMBER (19, 0),
	pdi NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_confinements_pqi', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_confinements_pqi (
	conf_num NUMBER (19, 0),
	pqi NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_contract_erg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_contract_erg (
	act_prisk NUMBER (10, 4),
	act_prisk_cat NUMBER (10, 0),
	arisk NUMBER (10, 4),
	contract_id VARCHAR2 (40 CHAR),
	erg_age NUMBER (10, 0),
	erg_end_date TIMESTAMP,
	erg_error_stat NUMBER (10, 0),
	erg_exp_thresh NUMBER (10, 0),
	erg_gender VARCHAR2 (1 CHAR),
	erg_inp_data NUMBER (10, 0),
	erg_partial_enr NUMBER (10, 0),
	erg_risk_out NUMBER (10, 0),
	erg_run_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	lob NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	prisk NUMBER (10, 4),
	prisk_cat NUMBER (10, 0),
	ptl_yr_enr NUMBER (10, 0),
	rrisk NUMBER (10, 4),
	rrisk_cat NUMBER (10, 0),
	tot_mm NUMBER (19, 2),
	tot_phm_mm NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_custom_labels', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_custom_labels (
	column_name VARCHAR2 (255 CHAR),
	custom_label VARCHAR2 (100 CHAR),
	label_default VARCHAR2 (50 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_custom_map_cases', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_custom_map_cases (
	cust_case_desc VARCHAR2 (45 CHAR),
	cust_case_id NUMBER (10, 0),
	cust_cond_1 VARCHAR2 (45 CHAR),
	cust_cond_1_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_custom_map_info', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_custom_map_info (
	cust_map_info_id NUMBER (10, 0),
	level1_desc VARCHAR2 (50 CHAR),
	level2_desc VARCHAR2 (50 CHAR),
	level3_desc VARCHAR2 (50 CHAR),
	map_friendly_name VARCHAR2 (100 CHAR),
	map_name VARCHAR2 (50 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_custom_map_rules', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_custom_map_rules (
	cust_case_id NUMBER (10, 0),
	cust_rule_desc VARCHAR2 (212 CHAR),
	cust_rule_id NUMBER (10, 0),
	rule_type_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_custom_rule_results', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_custom_rule_results (
	attribution_rule NUMBER (10, 0),
	cust_rule_id NUMBER (10, 0),
	event_id NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	neg_flag NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	result_flag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_dis_reg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_dis_reg (
	member VARCHAR2 (32 CHAR),
	rpt_case_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ebm_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ebm_count (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	pcp_imp_flag NUMBER (1),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	peer_ebm_num NUMBER (28, 6),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ebm_event_physician', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ebm_event_physician (
	charge_amount NUMBER (19, 2),
	event_id NUMBER (10, 0),
	first_visit_date TIMESTAMP,
	initial_status VARCHAR2 (1 CHAR),
	last_visit_date TIMESTAMP,
	member VARCHAR2 (32 CHAR),
	num_visits NUMBER (10, 0),
	paid_amount NUMBER (19, 2),
	prov_key VARCHAR2 (20 CHAR),
	prov_spec VARCHAR2 (2 CHAR),
	rpt_case_id NUMBER (10, 0),
	support_flag VARCHAR2 (1 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ebm_physician_visits', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ebm_physician_visits (
	charge_amount NUMBER (19, 2),
	event_id NUMBER (10, 0),
	first_visit_date TIMESTAMP,
	imp_phy_flag VARCHAR2 (1 CHAR),
	last_visit_date TIMESTAMP,
	member VARCHAR2 (32 CHAR),
	num_visits NUMBER (10, 0),
	paid_amount NUMBER (19, 2),
	prov_key VARCHAR2 (20 CHAR),
	prov_spec VARCHAR2 (2 CHAR),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0),
	rule_end_dt TIMESTAMP,
	rule_start_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ebm_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ebm_prov (
	attr_reason_id NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	pcp_imp_flag NUMBER (1),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	rpt_case_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ebm_results', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ebm_results (
	ebm_noncompliance_flag NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	event_id NUMBER (10, 0),
	ext_flag NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	result_flag NUMBER (10, 0),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ebm_summary_results', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ebm_summary_results (
	ebm_compliance_flag NUMBER (1),
	ebm_noncompliance_flag NUMBER (1),
	event_id NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	result_flag VARCHAR2 (3 CHAR),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0),
	unused_1 NUMBER (10, 0),
	unused_2 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ed_avoidable', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ed_avoidable (
	account_id VARCHAR2 (40 CHAR),
	account_lv1_id VARCHAR2 (100 CHAR),
	account_lv2_id VARCHAR2 (100 CHAR),
	age_cat2 NUMBER (10, 0),
	amb_sens NUMBER (10, 0),
	conf_num NUMBER (19, 0),
	contract_id VARCHAR2 (40 CHAR),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	county_id NUMBER (10, 0),
	dos TIMESTAMP,
	ed_enc_id NUMBER (10, 0),
	er_conf NUMBER (1),
	er_util NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	member_name VARCHAR2 (100 CHAR),
	mpc_dx NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_assign_name VARCHAR2 (50 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pcp_imp_affil_id VARCHAR2 (40 CHAR),
	pcp_imp_name VARCHAR2 (50 CHAR),
	product_id VARCHAR2 (40 CHAR),
	product_lv1_id VARCHAR2 (100 CHAR),
	product_lv2_id VARCHAR2 (100 CHAR),
	unavoid_ed NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ed_avoidable_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ed_avoidable_detail (
	amb_sens NUMBER (10, 0),
	claim_id VARCHAR2 (30 CHAR),
	cost1 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	diag1 VARCHAR2 (8 CHAR),
	dos TIMESTAMP,
	ed_enc_id NUMBER (10, 0),
	er_util NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	ia_time_code VARCHAR2 (15 CHAR),
	member VARCHAR2 (32 CHAR),
	member_attr_id NUMBER (10, 0),
	mpc_dx NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR),
	tos1_id NUMBER (10, 0),
	unavoid_ed NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_emp_product', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_emp_product (
	account_id VARCHAR2 (40 CHAR),
	account_num_id NUMBER (10, 0),
	benefit_plan_id VARCHAR2 (40 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR),
	product_num_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_emp_product_info', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_emp_product_info (
	account_desc VARCHAR2 (150 CHAR),
	account_id VARCHAR2 (40 CHAR),
	account_lv1_desc VARCHAR2 (150 CHAR),
	account_lv1_id VARCHAR2 (100 CHAR),
	account_lv2_desc VARCHAR2 (150 CHAR),
	account_lv2_id VARCHAR2 (100 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR),
	benefit_plan_lv1_id VARCHAR2 (100 CHAR),
	benefit_plan_lv2_id VARCHAR2 (100 CHAR),
	biz_segment_desc VARCHAR2 (150 CHAR),
	biz_segment_id VARCHAR2 (40 CHAR),
	biz_segment_lv1_desc VARCHAR2 (150 CHAR),
	biz_segment_lv1_id VARCHAR2 (100 CHAR),
	biz_segment_lv2_desc VARCHAR2 (150 CHAR),
	biz_segment_lv2_id VARCHAR2 (100 CHAR),
	industry NUMBER (10, 0),
	mem_userdef_1_desc VARCHAR2 (150 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_desc VARCHAR2 (150 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_desc VARCHAR2 (150 CHAR),
	product_id VARCHAR2 (40 CHAR),
	product_lv1_desc VARCHAR2 (150 CHAR),
	product_lv1_id VARCHAR2 (100 CHAR),
	product_lv2_desc VARCHAR2 (150 CHAR),
	product_lv2_id VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_epi_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_epi_costs (
	admit_act_tot NUMBER (10, 0),
	admit_peer_tot NUMBER (28, 6),
	cat_member NUMBER (10, 0),
	cost2_act_tot NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	days_act_tot NUMBER (28, 6),
	days_peer_tot NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	enc_peer_tot NUMBER (28, 6),
	er_act_tot NUMBER (28, 6),
	er_peer_tot NUMBER (28, 6),
	etg_id NUMBER (10, 0),
	etg_unit_id NUMBER (10, 0),
	gen_act_tot NUMBER (28, 6),
	gen_peer_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	ia_time_adj NUMBER (10, 0),
	lab_act_tot NUMBER (28, 6),
	lab_peer_tot NUMBER (28, 6),
	mri_act_tot NUMBER (28, 6),
	mri_peer_tot NUMBER (28, 6),
	ospvis_act_tot NUMBER (28, 6),
	ospvis_peer_tot NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	psc_cat1_id NUMBER (10, 0),
	rad_act_tot NUMBER (28, 6),
	rad_peer_tot NUMBER (28, 6),
	script_act_tot NUMBER (28, 6),
	script_gen_act_tot NUMBER (28, 6),
	script_peer_tot NUMBER (28, 6),
	sev_level NUMBER (10, 0),
	specprv NUMBER (1),
	spvis_act_tot NUMBER (28, 6),
	spvis_peer_tot NUMBER (28, 6),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_epi_costs_cpt_riskadj', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_epi_costs_cpt_riskadj (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	cat_member NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	code_type NUMBER (10, 0),
	cost2_act_tot NUMBER (28, 6),
	cost2_act_tot_adj NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_act_tot_adj NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_act_tot_adj NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	enc_act_tot_adj NUMBER (28, 6),
	episode_id NUMBER (19, 0),
	etg_id NUMBER (10, 0),
	etg_unit_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	peer_def_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	psc_cat1_id NUMBER (10, 0),
	serv_code VARCHAR2 (15 CHAR),
	sev_level NUMBER (10, 0),
	sex NUMBER (1),
	specprv NUMBER (1),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_epi_costs_epilevel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_epi_costs_epilevel (
	admit_act_tot NUMBER (10, 0),
	admit_peer_tot NUMBER (28, 6),
	cost2_act_tot NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	days_act_tot NUMBER (28, 6),
	days_peer_tot NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	enc_peer_tot NUMBER (28, 6),
	epi_er_pct NUMBER (7, 4),
	epi_er_pct_adj NUMBER (7, 4),
	epi_hosp_pct NUMBER (7, 4),
	epi_hosp_pct_adj NUMBER (7, 4),
	epi_lab_pct NUMBER (7, 4),
	epi_lab_pct_adj NUMBER (7, 4),
	epi_pcc_pct NUMBER (7, 4),
	epi_pcc_pct_adj NUMBER (7, 4),
	epi_phm_pct NUMBER (7, 4),
	epi_phm_pct_adj NUMBER (7, 4),
	epi_qty NUMBER (28, 6),
	epi_rad_pct NUMBER (7, 4),
	epi_rad_pct_adj NUMBER (7, 4),
	epi_spec_pct NUMBER (7, 4),
	epi_spec_pct_adj NUMBER (7, 4),
	episode_id NUMBER (19, 0),
	er_act_tot NUMBER (28, 6),
	er_cost2_act_tot NUMBER (28, 6),
	er_cost2_peer_tot NUMBER (28, 6),
	er_cost3_act_tot NUMBER (28, 6),
	er_cost3_peer_tot NUMBER (28, 6),
	er_cost_act_tot NUMBER (28, 6),
	er_cost_peer_tot NUMBER (28, 6),
	er_enc_act_tot NUMBER (28, 6),
	er_enc_peer_tot NUMBER (28, 6),
	er_peer_tot NUMBER (28, 6),
	etg_unit_id NUMBER (10, 0),
	gen_act_tot NUMBER (28, 6),
	gen_peer_tot NUMBER (28, 6),
	hosp_cost2_act_tot NUMBER (28, 6),
	hosp_cost2_peer_tot NUMBER (28, 6),
	hosp_cost3_act_tot NUMBER (28, 6),
	hosp_cost3_peer_tot NUMBER (28, 6),
	hosp_cost_act_tot NUMBER (28, 6),
	hosp_cost_peer_tot NUMBER (28, 6),
	hosp_enc_act_tot NUMBER (28, 6),
	hosp_enc_peer_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	lab_act_tot NUMBER (28, 6),
	lab_cost2_act_tot NUMBER (28, 6),
	lab_cost2_peer_tot NUMBER (28, 6),
	lab_cost3_act_tot NUMBER (28, 6),
	lab_cost3_peer_tot NUMBER (28, 6),
	lab_cost_act_tot NUMBER (28, 6),
	lab_cost_peer_tot NUMBER (28, 6),
	lab_enc_act_tot NUMBER (28, 6),
	lab_enc_peer_tot NUMBER (28, 6),
	lab_peer_tot NUMBER (28, 6),
	mri_act_tot NUMBER (28, 6),
	mri_peer_tot NUMBER (28, 6),
	ospvis_act_tot NUMBER (28, 6),
	ospvis_peer_tot NUMBER (28, 6),
	pcc_cost2_act_tot NUMBER (28, 6),
	pcc_cost2_peer_tot NUMBER (28, 6),
	pcc_cost3_act_tot NUMBER (28, 6),
	pcc_cost3_peer_tot NUMBER (28, 6),
	pcc_cost_act_tot NUMBER (28, 6),
	pcc_cost_peer_tot NUMBER (28, 6),
	pcc_enc_act_tot NUMBER (28, 6),
	pcc_enc_peer_tot NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rad_act_tot NUMBER (28, 6),
	rad_cost2_act_tot NUMBER (28, 6),
	rad_cost2_peer_tot NUMBER (28, 6),
	rad_cost3_act_tot NUMBER (28, 6),
	rad_cost3_peer_tot NUMBER (28, 6),
	rad_cost_act_tot NUMBER (28, 6),
	rad_cost_peer_tot NUMBER (28, 6),
	rad_enc_act_tot NUMBER (28, 6),
	rad_enc_peer_tot NUMBER (28, 6),
	rad_peer_tot NUMBER (28, 6),
	rx_cost2_act_tot NUMBER (28, 6),
	rx_cost2_peer_tot NUMBER (28, 6),
	rx_cost3_act_tot NUMBER (28, 6),
	rx_cost3_peer_tot NUMBER (28, 6),
	rx_cost_act_tot NUMBER (28, 6),
	rx_cost_peer_tot NUMBER (28, 6),
	rx_enc_act_tot NUMBER (28, 6),
	rx_enc_peer_tot NUMBER (28, 6),
	script_act_tot NUMBER (28, 6),
	script_gen_act_tot NUMBER (28, 6),
	script_peer_tot NUMBER (28, 6),
	spec_cost2_act_tot NUMBER (28, 6),
	spec_cost2_peer_tot NUMBER (28, 6),
	spec_cost3_act_tot NUMBER (28, 6),
	spec_cost3_peer_tot NUMBER (28, 6),
	spec_cost_act_tot NUMBER (28, 6),
	spec_cost_peer_tot NUMBER (28, 6),
	spec_enc_act_tot NUMBER (28, 6),
	spec_enc_peer_tot NUMBER (28, 6),
	spvis_act_tot NUMBER (28, 6),
	spvis_peer_tot NUMBER (28, 6)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_epi_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_epi_count (
	cat_member NUMBER (10, 0),
	epi_qty NUMBER (28, 6),
	etg_id NUMBER (10, 0),
	etg_unit_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	ia_time_adj NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rrisk_epi_w NUMBER (28, 6),
	sev_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_epi_det_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_epi_det_costs (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	cat_member NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	code_type NUMBER (10, 0),
	complete NUMBER (1),
	cost2_act_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_e_act_tot NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	epi_qty_elig_peer NUMBER (1),
	etg_id NUMBER (10, 0),
	etg_unit_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	outlier NUMBER (10, 0),
	outlier_clinical NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	psc_cat1_id NUMBER (10, 0),
	serv_code VARCHAR2 (15 CHAR),
	sev_level NUMBER (10, 0),
	sex NUMBER (1),
	specprv NUMBER (1),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_epi_det_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_epi_det_count (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	cat_member NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	complete NUMBER (1),
	epi_qty NUMBER (28, 6),
	epi_qty_elig_peer NUMBER (1),
	etg_id NUMBER (10, 0),
	etg_unit_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	outlier NUMBER (10, 0),
	outlier_clinical NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rrisk_epi_w NUMBER (28, 6),
	sev_level NUMBER (10, 0),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_epi_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_epi_prov (
	attr_reason_id NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_episodes', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_episodes (
	chronic NUMBER (10, 0),
	elig_days NUMBER (10, 0),
	epi_cost_ratio_hi NUMBER (14, 6),
	epi_cost_ratio_lo NUMBER (14, 6),
	epi_from TIMESTAMP,
	epi_qty NUMBER (19, 2),
	epi_to TIMESTAMP,
	epi_type NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	etg VARCHAR2 (9 CHAR),
	etg_id NUMBER (10, 0),
	etg_resp_prov VARCHAR2 (20 CHAR),
	ia_time NUMBER (10, 0),
	lob NUMBER (10, 0),
	med_qual NUMBER (1),
	med_quest_ind NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	outlier NUMBER (10, 0),
	outlier_o NUMBER (10, 0),
	phm_qual NUMBER (1),
	sev_level NUMBER (10, 0),
	sev_score NUMBER (19, 4),
	sub_epi_count NUMBER (10, 0),
	tot_allow NUMBER (19, 2),
	tx_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_episodes_comorb', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_episodes_comorb (
	comorb_code NUMBER (10, 0),
	episode_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_episodes_cond', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_episodes_cond (
	cond_status NUMBER (10, 0),
	episode_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_episodes_sub', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_episodes_sub (
	episode_id NUMBER (19, 0),
	etg_base_tx VARCHAR2 (7 CHAR),
	etg_sub_id VARCHAR2 (7 CHAR),
	etg_sub_resp_prov VARCHAR2 (20 CHAR),
	ia_time NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	sub_epi_from TIMESTAMP,
	sub_epi_to TIMESTAMP,
	sub_epi_type NUMBER (10, 0),
	sub_episode_cat_id VARCHAR2 (1 CHAR),
	sub_episode_id VARCHAR2 (15 CHAR),
	sub_episode_num NUMBER (10, 0),
	tot_allow NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_episodes_sub_tx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_episodes_sub_tx (
	episode_id NUMBER (19, 0),
	sub_episode_num NUMBER (10, 0),
	tx_code NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_episodes_tx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_episodes_tx (
	episode_id NUMBER (19, 0),
	tx_code NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_erg_array', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_erg_array (
	erg_risk_marker VARCHAR2 (11 CHAR),
	ia_time NUMBER (10, 0),
	member VARCHAR2 (32 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_erg_risk', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_erg_risk (
	act_prisk NUMBER (10, 4),
	act_prisk_array VARCHAR2 (40 CHAR),
	act_prisk_cat NUMBER (10, 0),
	act_prisk_cat_array VARCHAR2 (8 CHAR),
	arisk NUMBER (10, 4),
	arisk_array VARCHAR2 (40 CHAR),
	erg_age NUMBER (10, 0),
	erg_end_date TIMESTAMP,
	erg_error_stat NUMBER (10, 0),
	erg_exp_thresh NUMBER (10, 0),
	erg_gender VARCHAR2 (1 CHAR),
	erg_inp_data NUMBER (10, 0),
	erg_partial_enr NUMBER (10, 0),
	erg_risk_out NUMBER (10, 0),
	lob NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	prisk NUMBER (10, 4),
	prisk_array VARCHAR2 (40 CHAR),
	prisk_cat NUMBER (10, 0),
	prisk_cat_array VARCHAR2 (8 CHAR),
	ptl_yr_enr NUMBER (10, 0),
	rrisk NUMBER (10, 4),
	rrisk_array VARCHAR2 (40 CHAR),
	rrisk_cat NUMBER (10, 0),
	rrisk_cat_array VARCHAR2 (8 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_annual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_annual (
	anc_inp_allow NUMBER (19, 2),
	anc_inp_paid NUMBER (19, 2),
	anc_out_allow NUMBER (19, 2),
	anc_out_paid NUMBER (19, 2),
	epi_type NUMBER (10, 0),
	etg_base_class VARCHAR2 (6 CHAR),
	fac_allow NUMBER (19, 2),
	fac_paid NUMBER (19, 2),
	member VARCHAR2 (32 CHAR),
	mgmt_allow NUMBER (19, 2),
	mgmt_paid NUMBER (19, 2),
	rx_allow NUMBER (19, 2),
	rx_paid NUMBER (19, 2),
	start_dt TIMESTAMP,
	surg_allow NUMBER (19, 2),
	surg_paid NUMBER (19, 2),
	tot_allow NUMBER (19, 2),
	tot_paid NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_claims', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_claims (
	"CLUSTER" NUMBER (10, 0),
	amt_eqv NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	anc_type VARCHAR2 (1 CHAR),
	bed_type VARCHAR2 (2 CHAR),
	bill_type_ind VARCHAR2 (1 CHAR),
	claim_id VARCHAR2 (30 CHAR),
	clus_prv VARCHAR2 (20 CHAR),
	days_sup NUMBER (10, 0),
	dcc VARCHAR2 (5 CHAR),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	epi_type NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	etg VARCHAR2 (9 CHAR),
	etg_conf_num NUMBER (19, 0),
	etg_from_dt TIMESTAMP,
	etg_to_dt TIMESTAMP,
	etg_top NUMBER (10, 0),
	etg_tos NUMBER (10, 0),
	etg_version VARCHAR2 (1 CHAR),
	icd_version NUMBER (10, 0),
	int_etg_top NUMBER (10, 0),
	int_etg_tos NUMBER (10, 0),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	med_clm_type NUMBER (1),
	member VARCHAR2 (32 CHAR),
	met_qty NUMBER (19, 2),
	mod_n VARCHAR2 (4 CHAR),
	mod_n_2 VARCHAR2 (4 CHAR),
	mod_n_3 VARCHAR2 (4 CHAR),
	mod_n_4 VARCHAR2 (4 CHAR),
	ndc VARCHAR2 (11 CHAR),
	order_prov VARCHAR2 (20 CHAR),
	outlier NUMBER (10, 0),
	pay_dt TIMESTAMP,
	phantom NUMBER (10, 0),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider VARCHAR2 (20 CHAR),
	prv_key VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	rec_type VARCHAR2 (1 CHAR),
	revenue VARCHAR2 (15 CHAR),
	sev_level NUMBER (10, 0),
	spec_drug NUMBER (10, 0),
	sub_episode_cat_id VARCHAR2 (1 CHAR),
	sub_episode_num NUMBER (10, 0),
	unq_svc NUMBER (19, 0),
	user_epi_type NUMBER (10, 0),
	user_outlier NUMBER (10, 0),
	user_spec_drug NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_comorb', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_comorb (
	comorb_code NUMBER (10, 0),
	episode_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_condstat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_condstat (
	cond_stat NUMBER (10, 0),
	episode_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_confinement', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_confinement (
	admit_age NUMBER (10, 0),
	admit_dt TIMESTAMP,
	anc_inp_allow NUMBER (19, 2),
	anc_inp_paid NUMBER (19, 2),
	bed_type VARCHAR2 (1 CHAR),
	clin_allow NUMBER (19, 2),
	clin_paid NUMBER (19, 2),
	conf_type NUMBER (10, 0),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag10_icd_version NUMBER (10, 0),
	diag11 VARCHAR2 (8 CHAR),
	diag11_icd_version NUMBER (10, 0),
	diag12 VARCHAR2 (8 CHAR),
	diag12_icd_version NUMBER (10, 0),
	diag13 VARCHAR2 (8 CHAR),
	diag13_icd_version NUMBER (10, 0),
	diag14 VARCHAR2 (8 CHAR),
	diag14_icd_version NUMBER (10, 0),
	diag15 VARCHAR2 (8 CHAR),
	diag15_icd_version NUMBER (10, 0),
	diag1_icd_version NUMBER (10, 0),
	diag2 VARCHAR2 (8 CHAR),
	diag2_icd_version NUMBER (10, 0),
	diag3 VARCHAR2 (8 CHAR),
	diag3_icd_version NUMBER (10, 0),
	diag4 VARCHAR2 (8 CHAR),
	diag4_icd_version NUMBER (10, 0),
	diag5 VARCHAR2 (8 CHAR),
	diag5_icd_version NUMBER (10, 0),
	diag6 VARCHAR2 (8 CHAR),
	diag6_icd_version NUMBER (10, 0),
	diag7 VARCHAR2 (8 CHAR),
	diag7_icd_version NUMBER (10, 0),
	diag8 VARCHAR2 (8 CHAR),
	diag8_icd_version NUMBER (10, 0),
	diag9 VARCHAR2 (8 CHAR),
	diag9_icd_version NUMBER (10, 0),
	diag_array VARCHAR2 (105 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	dischg_age NUMBER (10, 0),
	dischg_dt TIMESTAMP,
	epi_allow NUMBER (19, 2),
	epi_paid NUMBER (19, 2),
	epi_type NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	etg VARCHAR2 (9 CHAR),
	etg_conf_num NUMBER (19, 0),
	etg_gender VARCHAR2 (1 CHAR),
	fac_allow NUMBER (19, 2),
	fac_paid NUMBER (19, 2),
	fac_type VARCHAR2 (2 CHAR),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc10_icd_version NUMBER (10, 0),
	iproc11 VARCHAR2 (7 CHAR),
	iproc11_icd_version NUMBER (10, 0),
	iproc12 VARCHAR2 (7 CHAR),
	iproc12_icd_version NUMBER (10, 0),
	iproc13 VARCHAR2 (7 CHAR),
	iproc13_icd_version NUMBER (10, 0),
	iproc14 VARCHAR2 (7 CHAR),
	iproc14_icd_version NUMBER (10, 0),
	iproc15 VARCHAR2 (7 CHAR),
	iproc15_icd_version NUMBER (10, 0),
	iproc1_icd_version NUMBER (10, 0),
	iproc2 VARCHAR2 (7 CHAR),
	iproc2_icd_version NUMBER (10, 0),
	iproc3 VARCHAR2 (7 CHAR),
	iproc3_icd_version NUMBER (10, 0),
	iproc4 VARCHAR2 (7 CHAR),
	iproc4_icd_version NUMBER (10, 0),
	iproc5 VARCHAR2 (7 CHAR),
	iproc5_icd_version NUMBER (10, 0),
	iproc6 VARCHAR2 (7 CHAR),
	iproc6_icd_version NUMBER (10, 0),
	iproc7 VARCHAR2 (7 CHAR),
	iproc7_icd_version NUMBER (10, 0),
	iproc8 VARCHAR2 (7 CHAR),
	iproc8_icd_version NUMBER (10, 0),
	iproc9 VARCHAR2 (7 CHAR),
	iproc9_icd_version NUMBER (10, 0),
	iproc_array VARCHAR2 (105 CHAR),
	los NUMBER (10, 0),
	non_epi_allow NUMBER (19, 2),
	non_epi_paid NUMBER (19, 2),
	oth_allow NUMBER (19, 2),
	oth_paid NUMBER (19, 2),
	proc1 VARCHAR2 (5 CHAR),
	proc10 VARCHAR2 (5 CHAR),
	proc11 VARCHAR2 (5 CHAR),
	proc12 VARCHAR2 (5 CHAR),
	proc13 VARCHAR2 (5 CHAR),
	proc14 VARCHAR2 (5 CHAR),
	proc15 VARCHAR2 (5 CHAR),
	proc2 VARCHAR2 (5 CHAR),
	proc3 VARCHAR2 (5 CHAR),
	proc4 VARCHAR2 (5 CHAR),
	proc5 VARCHAR2 (5 CHAR),
	proc6 VARCHAR2 (5 CHAR),
	proc7 VARCHAR2 (5 CHAR),
	proc8 VARCHAR2 (5 CHAR),
	proc9 VARCHAR2 (5 CHAR),
	proc_array VARCHAR2 (75 CHAR),
	provider VARCHAR2 (20 CHAR),
	resp_provider VARCHAR2 (20 CHAR),
	room_board_allow NUMBER (19, 2),
	room_board_paid NUMBER (19, 2),
	tot_allow NUMBER (19, 2),
	tot_paid NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_episode', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_episode (
	episode_id NUMBER (19, 0),
	etg_base_class VARCHAR2 (6 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_episode_attrib', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_episode_attrib (
	clinician_flag NUMBER (10, 0),
	cluster_from_dt TIMESTAMP,
	cluster_to_dt TIMESTAMP,
	em_visits NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	facility_flag NUMBER (10, 0),
	first_provider NUMBER (10, 0),
	last_provider NUMBER (10, 0),
	non_acute_em_visits NUMBER (10, 0),
	pct_tot_amt_allow NUMBER (19, 2),
	pms_claim_allow NUMBER (19, 2),
	pms_claim_count NUMBER (10, 0),
	pmsrb_claim_allow NUMBER (19, 2),
	provider VARCHAR2 (20 CHAR),
	tot_allow NUMBER (19, 2),
	tot_cluster NUMBER (10, 0),
	tot_cluster_phantom NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_opp_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_opp_prov (
	base_etg VARCHAR2 (6 CHAR),
	cost_act_tot NUMBER (28, 6),
	cost_field VARCHAR2 (10 CHAR),
	cost_peer_tot NUMBER (28, 6),
	cost_var_tot NUMBER (28, 6),
	epi_qty NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	oe NUMBER (28, 6),
	oe_range NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_name VARCHAR2 (50 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_opp_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_opp_summary (
	base_etg VARCHAR2 (6 CHAR),
	cost_act_tot NUMBER (28, 6),
	cost_field VARCHAR2 (10 CHAR),
	cost_peer_tot NUMBER (28, 6),
	cost_var_tot NUMBER (28, 6),
	epi_qty NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	oe_range NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR),
	prov_count NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_patient_comorb', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_patient_comorb (
	comorb_code NUMBER (10, 0),
	comorb_id NUMBER (10, 0),
	end_dt TIMESTAMP,
	member VARCHAR2 (32 CHAR),
	start_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_phantom', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_phantom (
	"CLUSTER" NUMBER (10, 0),
	amt_eqv NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	anc_type VARCHAR2 (1 CHAR),
	bed_type VARCHAR2 (2 CHAR),
	bill_type_ind VARCHAR2 (1 CHAR),
	claim_id VARCHAR2 (30 CHAR),
	clus_prv VARCHAR2 (20 CHAR),
	days_sup NUMBER (10, 0),
	dcc VARCHAR2 (5 CHAR),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	epi_type NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	etg VARCHAR2 (9 CHAR),
	etg_conf_num NUMBER (19, 0),
	etg_from_dt TIMESTAMP,
	etg_to_dt TIMESTAMP,
	etg_top NUMBER (10, 0),
	etg_tos NUMBER (10, 0),
	etg_version VARCHAR2 (1 CHAR),
	icd_version NUMBER (10, 0),
	int_etg_top NUMBER (10, 0),
	int_etg_tos NUMBER (10, 0),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	med_clm_type NUMBER (1),
	member VARCHAR2 (32 CHAR),
	met_qty NUMBER (19, 2),
	mod_n VARCHAR2 (4 CHAR),
	mod_n_2 VARCHAR2 (4 CHAR),
	mod_n_3 VARCHAR2 (4 CHAR),
	mod_n_4 VARCHAR2 (4 CHAR),
	ndc VARCHAR2 (11 CHAR),
	order_prov VARCHAR2 (20 CHAR),
	outlier NUMBER (10, 0),
	pay_dt TIMESTAMP,
	phantom NUMBER (10, 0),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider VARCHAR2 (20 CHAR),
	prv_key VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	rec_type VARCHAR2 (1 CHAR),
	revenue VARCHAR2 (15 CHAR),
	sev_level NUMBER (10, 0),
	spec_drug NUMBER (10, 0),
	sub_episode_cat_id VARCHAR2 (1 CHAR),
	sub_episode_num NUMBER (10, 0),
	unq_svc NUMBER (19, 0),
	user_epi_type NUMBER (10, 0),
	user_outlier NUMBER (10, 0),
	user_spec_drug NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_sub_episode_attrib', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_sub_episode_attrib (
	clinician_flag NUMBER (10, 0),
	cluster_from_dt TIMESTAMP,
	cluster_to_dt TIMESTAMP,
	em_visits NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	facility_flag NUMBER (10, 0),
	first_provider NUMBER (10, 0),
	last_provider NUMBER (10, 0),
	non_acute_em_visits NUMBER (10, 0),
	pct_tot_amt_allow NUMBER (19, 2),
	pms_claim_allow NUMBER (19, 2),
	pms_claim_count NUMBER (10, 0),
	pmsrb_claim_allow NUMBER (19, 2),
	provider VARCHAR2 (20 CHAR),
	sub_episode_num NUMBER (10, 0),
	tot_allow NUMBER (19, 2),
	tot_cluster NUMBER (10, 0),
	tot_cluster_phantom NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_sub_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_sub_summary (
	anc_inp_allow NUMBER (19, 2),
	anc_inp_paid NUMBER (19, 2),
	anc_out_allow NUMBER (19, 2),
	anc_out_paid NUMBER (19, 2),
	conf_overlap NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	etg_base_tx VARCHAR2 (7 CHAR),
	etg_chronic_id NUMBER (10, 0),
	etg_sub_resp_prov VARCHAR2 (20 CHAR),
	fac_allow NUMBER (19, 2),
	fac_paid NUMBER (19, 2),
	first_anchor_date TIMESTAMP,
	inc_reason NUMBER (10, 0),
	last_anchor_date TIMESTAMP,
	member VARCHAR2 (32 CHAR),
	mgmt_allow NUMBER (19, 2),
	mgmt_paid NUMBER (19, 2),
	rx_allow NUMBER (19, 2),
	rx_paid NUMBER (19, 2),
	spec_drug_count NUMBER (10, 0),
	sub_epi_from TIMESTAMP,
	sub_epi_to TIMESTAMP,
	sub_epi_type NUMBER (10, 0),
	sub_episode_cat_id VARCHAR2 (1 CHAR),
	sub_episode_num NUMBER (10, 0),
	surg_allow NUMBER (19, 2),
	surg_paid NUMBER (19, 2),
	tot_allow NUMBER (19, 2),
	tot_clus NUMBER (10, 0),
	tot_paid NUMBER (19, 2),
	tot_phantom NUMBER (10, 0),
	truncation NUMBER (10, 0),
	user_spec_drug_count NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_sub_tx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_sub_tx (
	episode_id NUMBER (19, 0),
	sub_episode_num NUMBER (10, 0),
	tx_code NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_summary (
	anc_inp_allow NUMBER (19, 2),
	anc_inp_paid NUMBER (19, 2),
	anc_out_allow NUMBER (19, 2),
	anc_out_paid NUMBER (19, 2),
	elig_days NUMBER (10, 0),
	epi_from TIMESTAMP,
	epi_to TIMESTAMP,
	epi_type NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	etg VARCHAR2 (9 CHAR),
	etg_age NUMBER (10, 0),
	etg_chronic_id NUMBER (10, 0),
	etg_gender VARCHAR2 (1 CHAR),
	etg_resp_prov VARCHAR2 (20 CHAR),
	fac_allow NUMBER (19, 2),
	fac_paid NUMBER (19, 2),
	first_anchor_date TIMESTAMP,
	inc_reason NUMBER (10, 0),
	last_anchor_date TIMESTAMP,
	lob NUMBER (10, 0),
	med_quest_ind NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	mgmt_allow NUMBER (19, 2),
	mgmt_paid NUMBER (19, 2),
	outlier NUMBER (10, 0),
	rx_allow NUMBER (19, 2),
	rx_paid NUMBER (19, 2),
	sev_error_stat NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	sev_score NUMBER (10, 4),
	shift_dx VARCHAR2 (8 CHAR),
	shift_dx_icd_version NUMBER (10, 0),
	shift_proc VARCHAR2 (5 CHAR),
	spec_drug_count NUMBER (10, 0),
	start_dx VARCHAR2 (8 CHAR),
	start_dx_icd_version NUMBER (10, 0),
	surg_allow NUMBER (19, 2),
	surg_paid NUMBER (19, 2),
	tot_allow NUMBER (19, 2),
	tot_clus NUMBER (10, 0),
	tot_paid NUMBER (19, 2),
	tot_phantom NUMBER (10, 0),
	user_epi_type NUMBER (10, 0),
	user_inc_reason NUMBER (10, 0),
	user_outlier NUMBER (10, 0),
	user_spec_drug_count NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_etg_tx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_etg_tx (
	episode_id NUMBER (19, 0),
	tx_code NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_fac_attr_base_etg_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_fac_attr_base_etg_tos (
	actual_cost NUMBER (19, 2),
	base_etg VARCHAR2 (6 CHAR),
	base_etg_desc VARCHAR2 (150 CHAR),
	episode_count NUMBER (10, 0),
	expected_cost NUMBER (19, 2),
	low_outliers_included NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	tos_i_5 NUMBER (10, 0),
	zero_dollars_included NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_fact_pop_cost_util', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_fact_pop_cost_util (
	account_id VARCHAR2 (40 CHAR),
	account_lv1_id VARCHAR2 (100 CHAR),
	account_lv2_id VARCHAR2 (100 CHAR),
	admit_cp NUMBER (19, 2),
	admit_pp NUMBER (19, 2),
	affil_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	cost1_cp NUMBER (19, 2),
	cost1_pp NUMBER (19, 2),
	cost3_cp NUMBER (19, 2),
	cost3_pp NUMBER (19, 2),
	county_id NUMBER (10, 0),
	encounter_cp NUMBER (19, 2),
	encounter_pp NUMBER (19, 2),
	er_util_cp NUMBER (19, 2),
	er_util_pp NUMBER (19, 2),
	family NUMBER (10, 0),
	lab_util_cp NUMBER (19, 2),
	lab_util_pp NUMBER (19, 2),
	mpc NUMBER (10, 0),
	mri_util_cp NUMBER (19, 2),
	mri_util_pp NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	product_lv1_id VARCHAR2 (100 CHAR),
	product_lv2_id VARCHAR2 (100 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rad_util_cp NUMBER (19, 2),
	rad_util_pp NUMBER (19, 2),
	riskcat_lv2 NUMBER (10, 0),
	sex NUMBER (1),
	tos_i_5 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_fact_pop_mem', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_fact_pop_mem (
	account_id VARCHAR2 (40 CHAR),
	account_lv1_id VARCHAR2 (100 CHAR),
	account_lv2_id VARCHAR2 (100 CHAR),
	age_cat2 NUMBER (10, 0),
	county_id NUMBER (10, 0),
	mm_cp NUMBER (19, 2),
	mm_pp NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	product_lv1_id VARCHAR2 (100 CHAR),
	product_lv2_id VARCHAR2 (100 CHAR),
	riskcat_lv2 NUMBER (10, 0),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_fact_prov_quality', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_fact_prov_quality (
	all_ebm_num NUMBER (28, 6),
	case_rule_id NUMBER (10, 0),
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	event_id NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	pcp_imp_flag NUMBER (1),
	peer_def_id NUMBER (10, 0),
	peer_ebm_num NUMBER (28, 6),
	provider_id VARCHAR2 (20 CHAR),
	result_flag NUMBER (10, 0),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ia_times', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ia_times (
	act_last NUMBER (1),
	age NUMBER (10, 0),
	arisk NUMBER (10, 4),
	cat_member NUMBER (1),
	cat_ratio NUMBER (19, 6),
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	cust_mem_1 VARCHAR2 (255 CHAR),
	cust_mem_10 VARCHAR2 (255 CHAR),
	cust_mem_11 VARCHAR2 (255 CHAR),
	cust_mem_12 VARCHAR2 (255 CHAR),
	cust_mem_13 VARCHAR2 (255 CHAR),
	cust_mem_14 VARCHAR2 (255 CHAR),
	cust_mem_15 VARCHAR2 (255 CHAR),
	cust_mem_16 NUMBER (38, 10),
	cust_mem_17 NUMBER (38, 10),
	cust_mem_18 NUMBER (38, 10),
	cust_mem_19 NUMBER (38, 10),
	cust_mem_2 VARCHAR2 (255 CHAR),
	cust_mem_20 NUMBER (38, 10),
	cust_mem_3 VARCHAR2 (255 CHAR),
	cust_mem_4 VARCHAR2 (255 CHAR),
	cust_mem_5 VARCHAR2 (255 CHAR),
	cust_mem_6 VARCHAR2 (255 CHAR),
	cust_mem_7 VARCHAR2 (255 CHAR),
	cust_mem_8 VARCHAR2 (255 CHAR),
	cust_mem_9 VARCHAR2 (255 CHAR),
	cust_mem_pk_id VARCHAR2 (32 CHAR),
	cust_sub_1 VARCHAR2 (255 CHAR),
	cust_sub_10 VARCHAR2 (255 CHAR),
	cust_sub_11 VARCHAR2 (255 CHAR),
	cust_sub_12 VARCHAR2 (255 CHAR),
	cust_sub_13 VARCHAR2 (255 CHAR),
	cust_sub_14 VARCHAR2 (255 CHAR),
	cust_sub_15 VARCHAR2 (255 CHAR),
	cust_sub_16 NUMBER (38, 10),
	cust_sub_17 NUMBER (38, 10),
	cust_sub_18 NUMBER (38, 10),
	cust_sub_19 NUMBER (38, 10),
	cust_sub_2 VARCHAR2 (255 CHAR),
	cust_sub_20 NUMBER (38, 10),
	cust_sub_3 VARCHAR2 (255 CHAR),
	cust_sub_4 VARCHAR2 (255 CHAR),
	cust_sub_5 VARCHAR2 (255 CHAR),
	cust_sub_6 VARCHAR2 (255 CHAR),
	cust_sub_7 VARCHAR2 (255 CHAR),
	cust_sub_8 VARCHAR2 (255 CHAR),
	cust_sub_9 VARCHAR2 (255 CHAR),
	cust_sub_pk_id VARCHAR2 (32 CHAR),
	ia_time NUMBER (10, 0),
	med_qual NUMBER (1),
	member VARCHAR2 (32 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	phm_qual NUMBER (1),
	prfl_mem NUMBER (10, 0),
	prisk NUMBER (10, 4),
	prisk_cat NUMBER (10, 0),
	ptl_yr_enr NUMBER (1),
	rrisk NUMBER (10, 4),
	rrisk_cat NUMBER (10, 0),
	tot_den_mm NUMBER (19, 2),
	tot_mm NUMBER (19, 2),
	tot_phm_mm NUMBER (19, 2),
	wrrisk NUMBER (10, 4)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ii_db_version', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ii_db_version (
	build NUMBER (10, 0),
	code_upd_applied TIMESTAMP,
	code_upd_version TIMESTAMP,
	major NUMBER (10, 0),
	minor NUMBER (10, 0),
	module VARCHAR2 (10 CHAR),
	paid_through_date TIMESTAMP,
	report_begin_date TIMESTAMP,
	report_end_date TIMESTAMP,
	revision NUMBER (10, 0),
	setid VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_imap_fop_ratio_sspp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_imap_fop_ratio_sspp (
	fop_ratio NUMBER (19, 2),
	tos_r VARCHAR2 (20 CHAR),
	tos_r_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_imap_options_sspp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_imap_options_sspp (
	amt_day_outlier_threshold NUMBER (19, 2),
	anc_outlier_factor_hi NUMBER (10, 5),
	anc_outlier_factor_lo NUMBER (10, 2),
	append_amt_other VARCHAR2 (50 CHAR),
	append_amt_std VARCHAR2 (1 CHAR),
	cf_var1 VARCHAR2 (100 CHAR),
	cf_var2 VARCHAR2 (100 CHAR),
	cfvar_sql VARCHAR2 (4000 CHAR),
	custom_fop_ratio VARCHAR2 (1 CHAR),
	facop_req_fix VARCHAR2 (1 CHAR),
	gen_med_pmpm VARCHAR2 (1 CHAR),
	gen_rx_pmpm VARCHAR2 (1 CHAR),
	include_er VARCHAR2 (1 CHAR),
	inp_outlier_hi NUMBER (10, 2),
	inp_outlier_lo NUMBER (10, 5),
	ip_price_method NUMBER (10, 0),
	j_code_qty_adj VARCHAR2 (1 CHAR),
	keep_work VARCHAR2 (1 CHAR),
	los_outlier_threshold NUMBER (10, 0),
	med_cust_dnp_ind VARCHAR2 (50 CHAR),
	med_where_clause VARCHAR2 (4000 CHAR),
	op_outlier_hi NUMBER (10, 2),
	op_outlier_lo NUMBER (10, 5),
	op_price_method NUMBER (10, 0),
	op_prorate NUMBER (10, 0),
	parm_confine_icd_version NUMBER (10, 0),
	parm_obs_stay VARCHAR2 (1 CHAR),
	pricing_var VARCHAR2 (10 CHAR),
	prof_anesth_outlier_factor_hi NUMBER (10, 5),
	prof_anesth_outlier_factor_lo NUMBER (10, 2),
	prof_lab_outlier_factor_hi NUMBER (10, 5),
	prof_lab_outlier_factor_lo NUMBER (10, 2),
	prof_mh_outlier_factor_hi NUMBER (10, 5),
	prof_mh_outlier_factor_lo NUMBER (10, 2),
	prof_other_outlier_factor_hi NUMBER (10, 5),
	prof_other_outlier_factor_lo NUMBER (10, 2),
	prof_rad_outlier_factor_hi NUMBER (10, 5),
	prof_rad_outlier_factor_lo NUMBER (10, 2),
	prof_rad_outlier_hi NUMBER (10, 2),
	prof_rad_outlier_lo NUMBER (10, 5),
	prof_surg_outlier_factor_hi NUMBER (10, 5),
	prof_surg_outlier_factor_lo NUMBER (10, 2),
	qty_adj VARCHAR2 (1 CHAR),
	rad_mod_inp VARCHAR2 (1 CHAR),
	reset_0 VARCHAR2 (1 CHAR),
	rx_amt_std_loc VARCHAR2 (8 CHAR),
	rx_cust_dnp_ind VARCHAR2 (50 CHAR),
	rx_outlier_hi NUMBER (10, 2),
	rx_outlier_lo NUMBER (10, 5),
	rx_where_clause VARCHAR2 (4000 CHAR),
	surg_mod VARCHAR2 (1 CHAR),
	tos_r_outlier_hi NUMBER (10, 2),
	tos_r_outlier_lo NUMBER (10, 5),
	use_cust_pli VARCHAR2 (1 CHAR),
	use_fac_type_ind VARCHAR2 (1 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_imap_param_list_sspp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_imap_param_list_sspp (
	active_flag VARCHAR2 (1 CHAR),
	default_val VARCHAR2 (30 CHAR),
	param VARCHAR2 (50 CHAR),
	param_desc VARCHAR2 (500 CHAR),
	param_name VARCHAR2 (100 CHAR),
	param_short VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_lab', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_lab (
	claim_id VARCHAR2 (30 CHAR),
	clm_type VARCHAR2 (1 CHAR),
	dos TIMESTAMP,
	loinc VARCHAR2 (7 CHAR),
	member VARCHAR2 (32 CHAR),
	num_val NUMBER (19, 2),
	str_val VARCHAR2 (25 CHAR),
	uniq_rec_id NUMBER (19, 0),
	units VARCHAR2 (25 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_account', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_account (
	account VARCHAR2 (30 CHAR),
	account_desc VARCHAR2 (150 CHAR),
	account_id VARCHAR2 (40 CHAR),
	account_lv1 VARCHAR2 (30 CHAR),
	account_lv1_desc VARCHAR2 (150 CHAR),
	account_lv1_id VARCHAR2 (100 CHAR),
	account_lv2 VARCHAR2 (30 CHAR),
	account_lv2_desc VARCHAR2 (150 CHAR),
	account_lv2_id VARCHAR2 (100 CHAR),
	account_num_id NUMBER (10, 0),
	biz_segment_id VARCHAR2 (40 CHAR),
	industry NUMBER (10, 0),
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_acw', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_acw (
	acw_desc VARCHAR2 (10 CHAR),
	acw_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_admit_source', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_admit_source (
	admit_source VARCHAR2 (1 CHAR),
	admit_source_desc VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_age', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_age (
	age NUMBER (10, 0),
	age_cat1 NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	age_lab1 VARCHAR2 (5 CHAR),
	age_lab2 VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_at_risk_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_at_risk_status (
	at_risk_status VARCHAR2 (30 CHAR),
	at_risk_status_desc VARCHAR2 (150 CHAR),
	at_risk_status_id VARCHAR2 (40 CHAR),
	at_risk_status_lv1 VARCHAR2 (30 CHAR),
	at_risk_status_lv1_desc VARCHAR2 (150 CHAR),
	at_risk_status_lv1_id VARCHAR2 (100 CHAR),
	at_risk_status_lv2 VARCHAR2 (30 CHAR),
	at_risk_status_lv2_desc VARCHAR2 (150 CHAR),
	at_risk_status_lv2_id VARCHAR2 (100 CHAR),
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0),
	risk_status NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_attr_reason', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_attr_reason (
	attr_reason_desc VARCHAR2 (120 CHAR),
	attr_reason_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_attrib_lvl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_attrib_lvl (
	attrib_lvl_code VARCHAR2 (5 CHAR),
	attrib_lvl_desc VARCHAR2 (20 CHAR),
	attrib_lvl_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_benefit_plan', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_benefit_plan (
	benefit_plan VARCHAR2 (30 CHAR),
	benefit_plan_desc VARCHAR2 (150 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR),
	benefit_plan_lv1 VARCHAR2 (30 CHAR),
	benefit_plan_lv1_desc VARCHAR2 (150 CHAR),
	benefit_plan_lv1_id VARCHAR2 (100 CHAR),
	benefit_plan_lv2 VARCHAR2 (30 CHAR),
	benefit_plan_lv2_desc VARCHAR2 (150 CHAR),
	benefit_plan_lv2_id VARCHAR2 (100 CHAR),
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_bill_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_bill_type (
	bill_type VARCHAR2 (4 CHAR),
	bill_type_desc VARCHAR2 (255 CHAR),
	pos_i NUMBER (10, 0),
	prv_sp_4 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_biz_segment', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_biz_segment (
	biz_segment VARCHAR2 (30 CHAR),
	biz_segment_desc VARCHAR2 (150 CHAR),
	biz_segment_id VARCHAR2 (40 CHAR),
	biz_segment_lv1 VARCHAR2 (30 CHAR),
	biz_segment_lv1_desc VARCHAR2 (150 CHAR),
	biz_segment_lv1_id VARCHAR2 (100 CHAR),
	biz_segment_lv2 VARCHAR2 (30 CHAR),
	biz_segment_lv2_desc VARCHAR2 (150 CHAR),
	biz_segment_lv2_id VARCHAR2 (100 CHAR),
	biz_segment_num_id NUMBER (10, 0),
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_case_rule', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_case_rule (
	case_rule_id NUMBER (10, 0),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_catstatus', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_catstatus (
	cat100k NUMBER (1),
	cat200k NUMBER (1),
	cat25k NUMBER (1),
	cat50k NUMBER (1),
	cat_status NUMBER (10, 0),
	cat_status_desc VARCHAR2 (22 CHAR),
	cat_status_lv2 NUMBER (10, 0),
	cat_status_lv2_desc VARCHAR2 (22 CHAR),
	threshold NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_channel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_channel (
	channel NUMBER (10, 0),
	channel_desc VARCHAR2 (25 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_clm_exclude', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_clm_exclude (
	clm_exclude NUMBER (10, 0),
	clm_exclude_desc VARCHAR2 (40 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_clm_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_clm_type (
	clm_type VARCHAR2 (1 CHAR),
	clm_type_desc VARCHAR2 (12 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_contract_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_contract_type (
	contract_type VARCHAR2 (30 CHAR),
	contract_type_desc VARCHAR2 (150 CHAR),
	contract_type_id VARCHAR2 (40 CHAR),
	contract_type_lv1 VARCHAR2 (30 CHAR),
	contract_type_lv1_desc VARCHAR2 (150 CHAR),
	contract_type_lv1_id VARCHAR2 (100 CHAR),
	contract_type_lv2 VARCHAR2 (30 CHAR),
	contract_type_lv2_desc VARCHAR2 (150 CHAR),
	contract_type_lv2_id VARCHAR2 (100 CHAR),
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_county', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_county (
	cens_division NUMBER (10, 0),
	cens_division_desc VARCHAR2 (30 CHAR),
	cens_reg NUMBER (10, 0),
	cens_reg_desc VARCHAR2 (30 CHAR),
	county_desc VARCHAR2 (40 CHAR),
	county_id NUMBER (10, 0),
	state NUMBER (10, 0),
	state_desc VARCHAR2 (2 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_coverage_class', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_coverage_class (
	coverage_class NUMBER (10, 0),
	coverage_class_desc VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_coverage_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_coverage_status (
	coverage_class NUMBER (10, 0),
	coverage_status VARCHAR2 (30 CHAR),
	coverage_status_desc VARCHAR2 (150 CHAR),
	coverage_status_id VARCHAR2 (40 CHAR),
	coverage_status_lv1 VARCHAR2 (30 CHAR),
	coverage_status_lv1_desc VARCHAR2 (150 CHAR),
	coverage_status_lv1_id VARCHAR2 (100 CHAR),
	coverage_status_lv2 VARCHAR2 (30 CHAR),
	coverage_status_lv2_desc VARCHAR2 (150 CHAR),
	coverage_status_lv2_id VARCHAR2 (100 CHAR),
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_date_range', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_date_range (
	ia_time NUMBER (10, 0),
	ia_time_code VARCHAR2 (15 CHAR),
	ia_time_date_desc VARCHAR2 (25 CHAR),
	ia_time_desc VARCHAR2 (25 CHAR),
	ia_time_end_date TIMESTAMP,
	ia_time_full_desc VARCHAR2 (55 CHAR),
	ia_time_start_date TIMESTAMP,
	month_code VARCHAR2 (10 CHAR),
	month_date TIMESTAMP,
	month_end_date TIMESTAMP,
	month_full_desc VARCHAR2 (50 CHAR),
	month_label1 VARCHAR2 (10 CHAR),
	month_label2 VARCHAR2 (3 CHAR),
	month_label3 VARCHAR2 (10 CHAR),
	month_val NUMBER (10, 0),
	qtr_code VARCHAR2 (10 CHAR),
	qtr_date_desc VARCHAR2 (50 CHAR),
	qtr_full_desc VARCHAR2 (50 CHAR),
	qtr_id NUMBER (10, 0),
	qtr_label1 VARCHAR2 (3 CHAR),
	qtr_label2 VARCHAR2 (12 CHAR),
	qtr_val NUMBER (10, 0),
	year_label VARCHAR2 (4 CHAR),
	year_mth_id NUMBER (10, 0),
	year_val NUMBER (10, 0),
	yr_month NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_daw', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_daw (
	daw NUMBER (10, 0),
	daw_desc VARCHAR2 (75 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_denied_ind', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_denied_ind (
	denied_ind VARCHAR2 (30 CHAR),
	denied_ind_desc VARCHAR2 (150 CHAR),
	denied_ind_id VARCHAR2 (40 CHAR),
	denied_ind_lv1 VARCHAR2 (30 CHAR),
	denied_ind_lv1_desc VARCHAR2 (150 CHAR),
	denied_ind_lv1_id VARCHAR2 (100 CHAR),
	denied_ind_lv2 VARCHAR2 (30 CHAR),
	denied_ind_lv2_desc VARCHAR2 (150 CHAR),
	denied_ind_lv2_id VARCHAR2 (100 CHAR),
	denied_status NUMBER (1),
	map_srce_n VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_dis_stat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_dis_stat (
	dis_stat VARCHAR2 (3 CHAR),
	dis_stat_desc VARCHAR2 (200 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_drg_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_drg_type (
	drg_admit_lv1 VARCHAR2 (9 CHAR),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_type_desc VARCHAR2 (79 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_dx_fmt', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_dx_fmt (
	fmt VARCHAR2 (10 CHAR),
	icd_version NUMBER (10, 0),
	icddx VARCHAR2 (7 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ebm_attr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ebm_attr (
	ebm_attr_desc VARCHAR2 (50 CHAR),
	ebm_attr_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ebm_cases', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ebm_cases (
	ebm_cond_1 VARCHAR2 (50 CHAR),
	ebm_cond_1_id NUMBER (10, 0),
	ebm_cond_2 VARCHAR2 (50 CHAR),
	ebm_cond_2_mask VARCHAR2 (50 CHAR),
	enabled NUMBER (1),
	ext_flag NUMBER (10, 0),
	rpt_case_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ebm_dls', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ebm_dls (
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0),
	svc_case_id NUMBER (10, 0),
	svc_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ebm_rule_types', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ebm_rule_types (
	ebm_ruletyp_1 VARCHAR2 (35 CHAR),
	ebm_ruletyp_2 VARCHAR2 (55 CHAR),
	rule_type VARCHAR2 (6 CHAR),
	rule_type_1_id NUMBER (10, 0),
	rule_type_id NUMBER (10, 0),
	typical NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ebm_svc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ebm_svc (
	svc_case_id NUMBER (10, 0),
	svc_desc VARCHAR2 (212 CHAR),
	svc_id VARCHAR2 (25 CHAR),
	svc_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ed_amb_sens', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ed_amb_sens (
	"PRIORITY" NUMBER (10, 0),
	amb_sens NUMBER (10, 0),
	amb_sens_desc VARCHAR2 (30 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ed_unavoid_ed', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ed_unavoid_ed (
	"PRIORITY" NUMBER (10, 0),
	unavoid_ed NUMBER (10, 0),
	unavoid_ed_desc VARCHAR2 (30 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_employee_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_employee_type (
	employee_status NUMBER (1),
	employee_type VARCHAR2 (30 CHAR),
	employee_type_desc VARCHAR2 (150 CHAR),
	employee_type_id VARCHAR2 (40 CHAR),
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_epi_attr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_epi_attr (
	epi_attr_desc VARCHAR2 (50 CHAR),
	epi_attr_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_epi_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_epi_type (
	complete NUMBER (1),
	epi_type NUMBER (10, 0),
	epi_type_desc VARCHAR2 (40 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_opp_oe_range', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_opp_oe_range (
	hi_range NUMBER (4, 2),
	lo_range NUMBER (4, 2),
	oe_range NUMBER (10, 0),
	oe_range_desc VARCHAR2 (50 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_prim_cond', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_prim_cond (
	prim_cond_code NUMBER (10, 0),
	prim_cond_desc VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_sub_cat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_sub_cat (
	base VARCHAR2 (6 CHAR),
	etg_sub_id VARCHAR2 (7 CHAR),
	sub_episode_cat_desc VARCHAR2 (255 CHAR),
	sub_episode_cat_id VARCHAR2 (1 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_fac_attr_etg_base', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_fac_attr_etg_base (
	base_etg VARCHAR2 (6 CHAR),
	etg_id NUMBER (10, 0),
	etg_impact VARCHAR2 (8 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_fac_risk_adj', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_fac_risk_adj (
	fac_risk_adj_desc VARCHAR2 (50 CHAR),
	fac_risk_adj_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_formulary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_formulary (
	formulary NUMBER (10, 0),
	formulary_desc VARCHAR2 (25 CHAR),
	formulary_ind NUMBER (1),
	tier_order NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_gbo', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_gbo (
	gbo NUMBER (10, 0),
	gbo_desc VARCHAR2 (50 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_industry', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_industry (
	industry NUMBER (10, 0),
	industry_desc VARCHAR2 (50 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_inp_admit_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_inp_admit_type (
	inp_admit_type VARCHAR2 (2 CHAR),
	inp_admit_type_desc VARCHAR2 (255 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_lob', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_lob (
	lob VARCHAR2 (3 CHAR),
	lob_desc VARCHAR2 (15 CHAR),
	lob_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_mem_userdef_1', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_mem_userdef_1 (
	map_srce_e VARCHAR2 (6 CHAR),
	mem_userdef_1 VARCHAR2 (30 CHAR),
	mem_userdef_1_desc VARCHAR2 (150 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_1_lv1 VARCHAR2 (30 CHAR),
	mem_userdef_1_lv1_desc VARCHAR2 (150 CHAR),
	mem_userdef_1_lv1_id VARCHAR2 (100 CHAR),
	mem_userdef_1_lv2 VARCHAR2 (30 CHAR),
	mem_userdef_1_lv2_desc VARCHAR2 (150 CHAR),
	mem_userdef_1_lv2_id VARCHAR2 (100 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_mem_userdef_2', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_mem_userdef_2 (
	map_srce_e VARCHAR2 (6 CHAR),
	mem_userdef_2 VARCHAR2 (30 CHAR),
	mem_userdef_2_desc VARCHAR2 (150 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_mem_userdef_3', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_mem_userdef_3 (
	map_srce_e VARCHAR2 (6 CHAR),
	mem_userdef_3 VARCHAR2 (30 CHAR),
	mem_userdef_3_desc VARCHAR2 (150 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_mem_userdef_4', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_mem_userdef_4 (
	map_srce_e VARCHAR2 (6 CHAR),
	mem_userdef_4 VARCHAR2 (30 CHAR),
	mem_userdef_4_desc VARCHAR2 (150 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	mem_userdef_4_lv1 VARCHAR2 (30 CHAR),
	mem_userdef_4_lv1_desc VARCHAR2 (150 CHAR),
	mem_userdef_4_lv1_id VARCHAR2 (100 CHAR),
	mem_userdef_4_lv2 VARCHAR2 (30 CHAR),
	mem_userdef_4_lv2_desc VARCHAR2 (150 CHAR),
	mem_userdef_4_lv2_id VARCHAR2 (100 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_mpc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_mpc (
	mpc NUMBER (10, 0),
	mpc_desc VARCHAR2 (50 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_mpg_code', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_mpg_code (
	mpg_code NUMBER (10, 0),
	mpg_code_str VARCHAR2 (100 CHAR),
	mpg_codetype_id NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_mpg_codetype', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_mpg_codetype (
	mpg_codetype VARCHAR2 (50 CHAR),
	mpg_codetype_desc VARCHAR2 (50 CHAR),
	mpg_codetype_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_mpg_def', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_mpg_def (
	mpg_def_desc VARCHAR2 (60 CHAR),
	mpg_def_id NUMBER (10, 0),
	mpg_other_flag NUMBER (10, 0),
	mpg_seg_lvl NUMBER (10, 0),
	parent_mpg_def_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ntwrk_paid_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ntwrk_paid_status (
	map_srce_p VARCHAR2 (6 CHAR),
	network_paid_status VARCHAR2 (30 CHAR),
	network_paid_status_desc VARCHAR2 (150 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_paid_status_lv1 VARCHAR2 (30 CHAR),
	network_paid_status_lv1_desc VARCHAR2 (150 CHAR),
	network_paid_status_lv1_id VARCHAR2 (100 CHAR),
	network_paid_status_lv2 VARCHAR2 (30 CHAR),
	network_paid_status_lv2_desc VARCHAR2 (150 CHAR),
	network_paid_status_lv2_id VARCHAR2 (100 CHAR),
	network_status NUMBER (1),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_pcp_attr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_pcp_attr (
	pcp_attr_desc VARCHAR2 (50 CHAR),
	pcp_attr_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_pdi', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_pdi (
	avoidable NUMBER (10, 0),
	pdi NUMBER (10, 0),
	pdi_desc VARCHAR2 (100 CHAR),
	pdi_hier NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peer', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peer (
	active NUMBER (10, 0),
	attrib_lvl_id NUMBER (10, 0),
	ci_epi NUMBER (6, 3),
	ci_epi_peg NUMBER (6, 3),
	ci_pop NUMBER (6, 3),
	ci_qual NUMBER (6, 3),
	cust_peer_mem NUMBER (10, 0),
	cust_peer_prov NUMBER (10, 0),
	ebm_attr_id NUMBER (10, 0),
	ebm_attr_prev_id NUMBER (10, 0),
	elig_admits NUMBER (10, 0),
	elig_dens NUMBER (10, 0),
	elig_epi_qty NUMBER (10, 0),
	elig_epi_qty_peg NUMBER (10, 0),
	elig_mems NUMBER (10, 0),
	elig_mmos NUMBER (10, 0),
	epi_attr_id NUMBER (10, 0),
	epi_clin_out NUMBER (10, 0),
	epi_clust_min_thresh NUMBER (10, 0),
	epi_cov_max_thresh NUMBER (6, 3),
	epi_cov_min_thresh NUMBER (6, 3),
	epi_elig_peer NUMBER (10, 0),
	epi_er_pct NUMBER (6, 3),
	epi_hosp_pct NUMBER (6, 3),
	epi_lab_pct NUMBER (6, 3),
	epi_max_etg NUMBER (10, 0),
	epi_max_peg NUMBER (10, 0),
	epi_median_cost_max_thresh NUMBER (19, 2),
	epi_median_cost_min_thresh NUMBER (19, 2),
	epi_min_epi_pct_thresh NUMBER (6, 3),
	epi_min_epi_thresh NUMBER (10, 0),
	epi_min_pct_tot_cost NUMBER (6, 3),
	epi_pcc_pct NUMBER (6, 3),
	epi_peer_def_var_latest NUMBER (1),
	epi_peer_def_var_type NUMBER (10, 0),
	epi_phm_pct NUMBER (6, 3),
	epi_rad_pct NUMBER (6, 3),
	epi_spec_pct NUMBER (6, 3),
	fac_elig_peer NUMBER (10, 0),
	fac_risk_adj_id NUMBER (10, 0),
	mem_exc_ind NUMBER (10, 0),
	num_years_epi NUMBER (10, 0),
	num_years_epi_peg NUMBER (10, 0),
	num_years_fac NUMBER (10, 0),
	num_years_pop NUMBER (10, 0),
	pat_sat NUMBER (10, 0),
	pcp_attr_id NUMBER (10, 0),
	pcp_elig_peer NUMBER (10, 0),
	peer_cat1_id NUMBER (10, 0),
	peer_cat2_id NUMBER (10, 0),
	peer_def_desc VARCHAR2 (50 CHAR),
	peer_def_id NUMBER (10, 0),
	peer_epi_out_hi NUMBER (10, 0),
	peer_epi_out_hi_peg NUMBER (10, 0),
	peer_epi_out_lo NUMBER (10, 0),
	peer_epi_out_lo_peg NUMBER (10, 0),
	peg_epi_clin_out NUMBER (10, 0),
	peg_epi_cov_max_thresh NUMBER (6, 3),
	peg_epi_cov_min_thresh NUMBER (6, 3),
	peg_epi_elig_peer NUMBER (10, 0),
	peg_epi_er_pct NUMBER (6, 3),
	peg_epi_hosp_inp_pct NUMBER (6, 3),
	peg_epi_hosp_op_othr_pct NUMBER (6, 3),
	peg_epi_hosp_op_surg_pct NUMBER (6, 3),
	peg_epi_lab_pct NUMBER (6, 3),
	peg_epi_median_cost_max_thresh NUMBER (19, 2),
	peg_epi_median_cost_min_thresh NUMBER (19, 2),
	peg_epi_min_epi_pct_thresh NUMBER (6, 3),
	peg_epi_min_epi_thresh NUMBER (10, 0),
	peg_epi_min_pct_tot_cost NUMBER (6, 3),
	peg_epi_pcc_pct NUMBER (6, 3),
	peg_epi_phm_pct NUMBER (6, 3),
	peg_epi_prod_lv NUMBER (1),
	peg_epi_rad_pct NUMBER (6, 3),
	peg_epi_spec_pct NUMBER (6, 3),
	peg_risk_adj_id NUMBER (10, 0),
	pop_cat_mem NUMBER (10, 0),
	pop_er_pct NUMBER (6, 3),
	pop_hosp_pct NUMBER (6, 3),
	pop_lab_pct NUMBER (6, 3),
	pop_pcc_pct NUMBER (6, 3),
	pop_peer_def_var_type NUMBER (10, 0),
	pop_phm_pct NUMBER (6, 3),
	pop_rad_pct NUMBER (6, 3),
	pop_spec_pct NUMBER (6, 3),
	qual_elig_peer NUMBER (10, 0),
	resp_ebm_all_pct NUMBER (6, 3),
	resp_ebm_spec_pct NUMBER (6, 3),
	resp_pct NUMBER (6, 3),
	resp_spec_pct NUMBER (6, 3),
	risk_adj_epi_ia_time NUMBER (1),
	risk_adj_fac_ia_time NUMBER (1),
	risk_adj_id NUMBER (10, 0),
	risk_adj_peg_epi_ia_time NUMBER (1),
	risk_adj_pop_ia_time NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peer_cat1', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peer_cat1 (
	peer_cat1_desc VARCHAR2 (50 CHAR),
	peer_cat1_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peer_cat2', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peer_cat2 (
	peer_cat2_desc VARCHAR2 (50 CHAR),
	peer_cat2_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peer_code', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peer_code (
	code NUMBER (10, 0),
	code_str VARCHAR2 (100 CHAR),
	codetype_id NUMBER (10, 0),
	peer_def_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peer_codetype', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peer_codetype (
	codetype VARCHAR2 (50 CHAR),
	codetype_desc VARCHAR2 (50 CHAR),
	codetype_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peer_def_var_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peer_def_var_type (
	map_column_name VARCHAR2 (60 CHAR),
	map_join_column VARCHAR2 (60 CHAR),
	map_table_name VARCHAR2 (60 CHAR),
	peer_def_var_column VARCHAR2 (60 CHAR),
	peer_def_var_join_column VARCHAR2 (60 CHAR),
	peer_def_var_type NUMBER (10, 0),
	peer_def_var_type_desc VARCHAR2 (100 CHAR),
	peer_def_var_usage NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_comp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_comp (
	comp_code VARCHAR2 (5 CHAR),
	comp_desc VARCHAR2 (255 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_laterality', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_laterality (
	laterality VARCHAR2 (1 CHAR),
	laterality_desc VARCHAR2 (100 CHAR),
	peg_unit_laterality VARCHAR2 (1 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_pos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_pos (
	peg_pos NUMBER (10, 0),
	peg_pos_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_pos_expected', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_pos_expected (
	peg_pos_expected NUMBER (10, 0),
	peg_pos_expected_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_pos_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_pos_status (
	peg_pos_status VARCHAR2 (2 CHAR),
	peg_pos_status_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_ppc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_ppc (
	peg_ppc NUMBER (10, 0),
	peg_ppc_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_psc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_psc (
	peg_psc_cat1 VARCHAR2 (100 CHAR),
	peg_psc_cat1_id NUMBER (10, 0),
	peg_psc_cat2 VARCHAR2 (100 CHAR),
	peg_psc_cat2_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_sub_anchor', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_sub_anchor (
	peg_cat_id NUMBER (10, 0),
	sub_anchor_desc VARCHAR2 (150 CHAR),
	sub_anchor_id VARCHAR2 (1 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_unit', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_unit (
	peg_ppc NUMBER (10, 0),
	peg_unit VARCHAR2 (8 CHAR),
	peg_unit_desc VARCHAR2 (100 CHAR),
	peg_unit_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_poa', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_poa (
	poa VARCHAR2 (1 CHAR),
	poa_desc VARCHAR2 (25 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_pop_cat_mem', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_pop_cat_mem (
	pop_cat_mem NUMBER (10, 0),
	pop_cat_mem_desc VARCHAR2 (75 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_pqi', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_pqi (
	avoidable NUMBER (10, 0),
	pqi NUMBER (10, 0),
	pqi_desc VARCHAR2 (100 CHAR),
	pqi_hier NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_proc_fmt', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_proc_fmt (
	fmt VARCHAR2 (10 CHAR),
	icd_version NUMBER (10, 0),
	icdproc VARCHAR2 (7 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_product', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_product (
	lob_id NUMBER (10, 0),
	map_srce_e VARCHAR2 (6 CHAR),
	product VARCHAR2 (30 CHAR),
	product_desc VARCHAR2 (150 CHAR),
	product_id VARCHAR2 (40 CHAR),
	product_lv1 VARCHAR2 (30 CHAR),
	product_lv1_desc VARCHAR2 (150 CHAR),
	product_lv1_id VARCHAR2 (100 CHAR),
	product_lv2 VARCHAR2 (30 CHAR),
	product_lv2_desc VARCHAR2 (150 CHAR),
	product_lv2_id VARCHAR2 (100 CHAR),
	product_num_id NUMBER (10, 0),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_prov_affil', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_prov_affil (
	affil_id VARCHAR2 (40 CHAR),
	map_srce_p VARCHAR2 (6 CHAR),
	prov_affil VARCHAR2 (30 CHAR),
	prov_affil_desc VARCHAR2 (150 CHAR),
	prov_affil_lv1 VARCHAR2 (30 CHAR),
	prov_affil_lv1_desc VARCHAR2 (150 CHAR),
	prov_affil_lv1_id VARCHAR2 (100 CHAR),
	prov_affil_lv2 VARCHAR2 (30 CHAR),
	prov_affil_lv2_desc VARCHAR2 (150 CHAR),
	prov_affil_lv2_id VARCHAR2 (100 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_prov_userdef_2', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_prov_userdef_2 (
	map_srce_p VARCHAR2 (6 CHAR),
	prov_userdef_2 VARCHAR2 (30 CHAR),
	prov_userdef_2_desc VARCHAR2 (150 CHAR),
	prov_userdef_2_id VARCHAR2 (40 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_provider_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_provider_status (
	map_srce_p VARCHAR2 (6 CHAR),
	par_status NUMBER (1),
	provider_status VARCHAR2 (30 CHAR),
	provider_status_desc VARCHAR2 (150 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	provider_status_lv1 VARCHAR2 (30 CHAR),
	provider_status_lv1_desc VARCHAR2 (150 CHAR),
	provider_status_lv1_id VARCHAR2 (100 CHAR),
	provider_status_lv2 VARCHAR2 (30 CHAR),
	provider_status_lv2_desc VARCHAR2 (150 CHAR),
	provider_status_lv2_id VARCHAR2 (100 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ps_quest_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ps_quest_type (
	quest_type NUMBER (10, 0),
	quest_type_desc VARCHAR2 (30 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ps_question', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ps_question (
	quest_desc VARCHAR2 (1000 CHAR),
	quest_id VARCHAR2 (5 CHAR),
	quest_max NUMBER (38, 10),
	quest_type NUMBER (10, 0),
	survey_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ps_survey', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ps_survey (
	survey_desc VARCHAR2 (120 CHAR),
	survey_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_psc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_psc (
	peg_psc_cat1_id NUMBER (10, 0),
	peg_psc_cat2_id NUMBER (10, 0),
	psc_cat NUMBER (10, 0),
	psc_cat1 VARCHAR2 (100 CHAR),
	psc_cat1_id NUMBER (10, 0),
	psc_cat2 VARCHAR2 (100 CHAR),
	psc_cat2_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ql_prov_rate_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ql_prov_rate_type (
	rate_type_desc VARCHAR2 (30 CHAR),
	rate_type_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_rank_dec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_rank_dec (
	dec_desc VARCHAR2 (20 CHAR),
	quint_desc VARCHAR2 (25 CHAR),
	rank_dec NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_region', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_region (
	cens_division NUMBER (10, 0),
	cens_division_desc VARCHAR2 (30 CHAR),
	cens_reg NUMBER (10, 0),
	cens_reg_desc VARCHAR2 (30 CHAR),
	city VARCHAR2 (35 CHAR),
	county_desc VARCHAR2 (40 CHAR),
	county_id NUMBER (10, 0),
	msa VARCHAR2 (35 CHAR),
	state NUMBER (10, 0),
	state_desc VARCHAR2 (2 CHAR),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_risk_adj', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_risk_adj (
	risk_adj_desc VARCHAR2 (50 CHAR),
	risk_adj_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_risk_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_risk_type (
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0),
	risk_type VARCHAR2 (30 CHAR),
	risk_type_desc VARCHAR2 (150 CHAR),
	risk_type_id VARCHAR2 (40 CHAR),
	risk_type_lv1 VARCHAR2 (30 CHAR),
	risk_type_lv1_desc VARCHAR2 (150 CHAR),
	risk_type_lv1_id VARCHAR2 (100 CHAR),
	risk_type_lv2 VARCHAR2 (30 CHAR),
	risk_type_lv2_desc VARCHAR2 (150 CHAR),
	risk_type_lv2_id VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_riskcat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_riskcat (
	erg_risk_cat NUMBER (10, 0),
	lob_id NUMBER (10, 0),
	risk_cat NUMBER (10, 0),
	risk_cat_desc VARCHAR2 (20 CHAR),
	riskcat_lv2 NUMBER (10, 0),
	riskcat_lv2_desc VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_sex', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_sex (
	sex NUMBER (1),
	sex_desc VARCHAR2 (1 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_spec (
	prv_sp_4 NUMBER (10, 0),
	prv_sp_i VARCHAR2 (11 CHAR),
	sp1 VARCHAR2 (12 CHAR),
	sp1_id NUMBER (10, 0),
	sp2 VARCHAR2 (30 CHAR),
	sp2_id NUMBER (10, 0),
	sp3 VARCHAR2 (40 CHAR),
	sp3_id NUMBER (10, 0),
	sp4 VARCHAR2 (40 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_spec_rx_n', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_spec_rx_n (
	map_srce_n VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0),
	spec_rx_n VARCHAR2 (30 CHAR),
	spec_rx_n_desc VARCHAR2 (150 CHAR),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	spec_rx_n_lv1 VARCHAR2 (20 CHAR),
	spec_rx_n_lv1_desc VARCHAR2 (150 CHAR),
	spec_rx_n_lv1_id VARCHAR2 (100 CHAR),
	spec_rx_n_lv2 VARCHAR2 (20 CHAR),
	spec_rx_n_lv2_desc VARCHAR2 (150 CHAR),
	spec_rx_n_lv2_id VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_specialty_hcpcs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_specialty_hcpcs (
	hcpcs VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_specialty_ndc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_specialty_ndc (
	ndc VARCHAR2 (11 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_tcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_tcc (
	tcc VARCHAR2 (2 CHAR),
	tcc_desc VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_tos_cat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_tos_cat (
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	tos_cat_desc VARCHAR2 (100 CHAR),
	tos_cat_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_tx_ind', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_tx_ind (
	tx_ind NUMBER (10, 0),
	tx_ind_desc VARCHAR2 (20 CHAR),
	tx_ind_flag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_attr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_attr (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	at_risk_status_id VARCHAR2 (40 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR),
	biz_segment_id VARCHAR2 (40 CHAR),
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	contract_id VARCHAR2 (40 CHAR),
	contract_type_id VARCHAR2 (40 CHAR),
	county_id NUMBER (10, 0),
	coverage_status_id VARCHAR2 (40 CHAR),
	den NUMBER (1),
	employee_type_id VARCHAR2 (40 CHAR),
	industry NUMBER (10, 0),
	med NUMBER (1),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	member_attr_id NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR),
	risk_type_id VARCHAR2 (40 CHAR),
	rx NUMBER (1),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_attr_member', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_attr_member (
	account_id VARCHAR2 (40 CHAR),
	age NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	arisk NUMBER (10, 4),
	at_risk_status_id VARCHAR2 (40 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR),
	biz_segment_id VARCHAR2 (40 CHAR),
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	contract_id VARCHAR2 (40 CHAR),
	contract_type_id VARCHAR2 (40 CHAR),
	county_id NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	coverage_status_id VARCHAR2 (40 CHAR),
	den NUMBER (1),
	employee_type_id VARCHAR2 (40 CHAR),
	hra_ind NUMBER (1),
	hsa_ind NUMBER (1),
	ia_time NUMBER (10, 0),
	iatime_lag NUMBER (1),
	industry NUMBER (10, 0),
	last_enroll NUMBER (1),
	med NUMBER (1),
	med_qual NUMBER (1),
	mem_eff_dt TIMESTAMP,
	mem_end_dt TIMESTAMP,
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	member_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	mm_den NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	mpg_def_id NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	phm_qual NUMBER (1),
	premium_tot NUMBER (19, 2),
	prisk NUMBER (10, 4),
	product_id VARCHAR2 (40 CHAR),
	risk_type_id VARCHAR2 (40 CHAR),
	rrisk NUMBER (10, 4),
	rx NUMBER (1),
	sex NUMBER (1),
	sub_eff_dt TIMESTAMP,
	sub_end_dt TIMESTAMP,
	subscr_months NUMBER (19, 2),
	subscriber_id VARCHAR2 (32 CHAR),
	year_mth_id NUMBER (10, 0),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_attr_membr_contr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_attr_membr_contr (
	account_id VARCHAR2 (40 CHAR),
	age NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	at_risk_status_id VARCHAR2 (40 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR),
	biz_segment_id VARCHAR2 (40 CHAR),
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	contract_arisk NUMBER (10, 4),
	contract_id VARCHAR2 (40 CHAR),
	contract_prisk NUMBER (10, 4),
	contract_rrisk NUMBER (10, 4),
	contract_type_id VARCHAR2 (40 CHAR),
	county_id NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	coverage_status_id VARCHAR2 (40 CHAR),
	den NUMBER (1),
	employee_type_id VARCHAR2 (40 CHAR),
	hra_ind NUMBER (1),
	hsa_ind NUMBER (1),
	ia_time NUMBER (10, 0),
	iatime_lag NUMBER (1),
	industry NUMBER (10, 0),
	last_enroll NUMBER (1),
	med NUMBER (1),
	med_qual NUMBER (1),
	mem_eff_dt TIMESTAMP,
	mem_end_dt TIMESTAMP,
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	member_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	mm_den NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	mpg_def_id NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	phm_qual NUMBER (1),
	premium_tot NUMBER (19, 2),
	primary_payer_ind NUMBER (1),
	prisk NUMBER (10, 4),
	product_id VARCHAR2 (40 CHAR),
	risk_type_id VARCHAR2 (40 CHAR),
	rrisk NUMBER (10, 4),
	rx NUMBER (1),
	sex NUMBER (1),
	sub_eff_dt TIMESTAMP,
	sub_end_dt TIMESTAMP,
	subscr_months NUMBER (19, 2),
	subscriber_id VARCHAR2 (32 CHAR),
	year_mth_id NUMBER (10, 0),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_attr_mem_cst_egr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_attr_mem_cst_egr (
	cat_status_cost3 NUMBER (10, 0),
	cost3 NUMBER (19, 2),
	cost3_anc NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	enc NUMBER (19, 2),
	enc_anc NUMBER (19, 2),
	enc_ifac NUMBER (19, 2),
	enc_ofac NUMBER (19, 2),
	enc_phm NUMBER (19, 2),
	enc_prof NUMBER (19, 2),
	member VARCHAR2 (32 CHAR),
	member_attr_id NUMBER (10, 0),
	rrisk_cat NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_avoidable', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_avoidable (
	account_id VARCHAR2 (40 CHAR),
	account_lv1_id VARCHAR2 (100 CHAR),
	account_lv2_id VARCHAR2 (100 CHAR),
	age_cat2 NUMBER (10, 0),
	contract_id VARCHAR2 (40 CHAR),
	county_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mm NUMBER (19, 2),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pcp_imp_affil_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR),
	product_lv1_id VARCHAR2 (100 CHAR),
	product_lv2_id VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_disprev', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_disprev (
	disease_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	member VARCHAR2 (32 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_enroll', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_enroll (
	address VARCHAR2 (100 CHAR),
	at_risk_status_id VARCHAR2 (40 CHAR),
	city VARCHAR2 (50 CHAR),
	coverage_status_id VARCHAR2 (40 CHAR),
	cust_mem_1 VARCHAR2 (255 CHAR),
	cust_mem_10 VARCHAR2 (255 CHAR),
	cust_mem_11 VARCHAR2 (255 CHAR),
	cust_mem_12 VARCHAR2 (255 CHAR),
	cust_mem_13 VARCHAR2 (255 CHAR),
	cust_mem_14 VARCHAR2 (255 CHAR),
	cust_mem_15 VARCHAR2 (255 CHAR),
	cust_mem_16 NUMBER (38, 10),
	cust_mem_17 NUMBER (38, 10),
	cust_mem_18 NUMBER (38, 10),
	cust_mem_19 NUMBER (38, 10),
	cust_mem_2 VARCHAR2 (255 CHAR),
	cust_mem_20 NUMBER (38, 10),
	cust_mem_3 VARCHAR2 (255 CHAR),
	cust_mem_4 VARCHAR2 (255 CHAR),
	cust_mem_5 VARCHAR2 (255 CHAR),
	cust_mem_6 VARCHAR2 (255 CHAR),
	cust_mem_7 VARCHAR2 (255 CHAR),
	cust_mem_8 VARCHAR2 (255 CHAR),
	cust_mem_9 VARCHAR2 (255 CHAR),
	cust_mem_pk_id VARCHAR2 (32 CHAR),
	den NUMBER (1),
	dual_elig NUMBER (1),
	eff_dt TIMESTAMP,
	email VARCHAR2 (50 CHAR),
	employee_type_id VARCHAR2 (40 CHAR),
	end_dt TIMESTAMP,
	geo_lat NUMBER (9, 6),
	geo_lon NUMBER (9, 6),
	hra_ind NUMBER (1),
	hsa_ind NUMBER (1),
	map_srce_e VARCHAR2 (6 CHAR),
	med NUMBER (1),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	mh NUMBER (1),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_id VARCHAR2 (20 CHAR),
	phone VARCHAR2 (15 CHAR),
	prim_payer_id VARCHAR2 (40 CHAR),
	rx NUMBER (1),
	sec_member_id_1 VARCHAR2 (32 CHAR),
	sec_member_id_2 VARCHAR2 (32 CHAR),
	sec_payer_id VARCHAR2 (40 CHAR),
	state_n VARCHAR2 (2 CHAR),
	subscriber_id VARCHAR2 (32 CHAR),
	zip VARCHAR2 (5 CHAR),
	zip_n VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_enroll_contract', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_enroll_contract (
	address VARCHAR2 (100 CHAR),
	at_risk_status_id VARCHAR2 (40 CHAR),
	city VARCHAR2 (50 CHAR),
	contract_id VARCHAR2 (40 CHAR),
	coverage_status_id VARCHAR2 (40 CHAR),
	cust_mem_1 VARCHAR2 (255 CHAR),
	cust_mem_10 VARCHAR2 (255 CHAR),
	cust_mem_11 VARCHAR2 (255 CHAR),
	cust_mem_12 VARCHAR2 (255 CHAR),
	cust_mem_13 VARCHAR2 (255 CHAR),
	cust_mem_14 VARCHAR2 (255 CHAR),
	cust_mem_15 VARCHAR2 (255 CHAR),
	cust_mem_16 NUMBER (38, 10),
	cust_mem_17 NUMBER (38, 10),
	cust_mem_18 NUMBER (38, 10),
	cust_mem_19 NUMBER (38, 10),
	cust_mem_2 VARCHAR2 (255 CHAR),
	cust_mem_20 NUMBER (38, 10),
	cust_mem_3 VARCHAR2 (255 CHAR),
	cust_mem_4 VARCHAR2 (255 CHAR),
	cust_mem_5 VARCHAR2 (255 CHAR),
	cust_mem_6 VARCHAR2 (255 CHAR),
	cust_mem_7 VARCHAR2 (255 CHAR),
	cust_mem_8 VARCHAR2 (255 CHAR),
	cust_mem_9 VARCHAR2 (255 CHAR),
	cust_mem_pk_id VARCHAR2 (32 CHAR),
	den NUMBER (1),
	eff_dt TIMESTAMP,
	email VARCHAR2 (50 CHAR),
	employee_type_id VARCHAR2 (40 CHAR),
	end_dt TIMESTAMP,
	geo_lat NUMBER (9, 6),
	geo_lon NUMBER (9, 6),
	hra_ind NUMBER (1),
	hsa_ind NUMBER (1),
	map_srce_e VARCHAR2 (6 CHAR),
	med NUMBER (1),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	mh NUMBER (1),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_id VARCHAR2 (20 CHAR),
	phone VARCHAR2 (15 CHAR),
	rx NUMBER (1),
	sec_member_id_1 VARCHAR2 (32 CHAR),
	sec_member_id_2 VARCHAR2 (32 CHAR),
	state_n VARCHAR2 (2 CHAR),
	subscriber_id VARCHAR2 (32 CHAR),
	zip VARCHAR2 (5 CHAR),
	zip_n VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_member_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_member_status (
	error_msg VARCHAR2 (4000 CHAR),
	member VARCHAR2 (32 CHAR),
	member_id NUMBER (19, 0),
	paf_status NUMBER (10, 0),
	status NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_meminfo', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_meminfo (
	date_of_death TIMESTAMP,
	dob TIMESTAMP,
	first_name VARCHAR2 (50 CHAR),
	full_name VARCHAR2 (100 CHAR),
	last_name VARCHAR2 (50 CHAR),
	member VARCHAR2 (32 CHAR),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_module_date_range', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_module_date_range (
	module_id NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_epi', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_epi (
	epi_qty NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	sev_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_epi_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_epi_tos (
	cost3 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	peer_cost3 NUMBER (19, 2),
	peer_encounter NUMBER (19, 2),
	sev_level NUMBER (10, 0),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_mem_attr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_mem_attr (
	account_id VARCHAR2 (40 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR),
	biz_segment_id VARCHAR2 (40 CHAR),
	county_id NUMBER (10, 0),
	industry NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	mpg_def_id NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_pop', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_pop (
	admit NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	amt_req NUMBER (28, 6),
	cost1 NUMBER (28, 6),
	cost1_rx NUMBER (28, 6),
	cost2 NUMBER (28, 6),
	cost3 NUMBER (28, 6),
	cost4 NUMBER (28, 6),
	days_sup NUMBER (10, 0),
	encounter NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	mm NUMBER (28, 6),
	mm_rx NUMBER (28, 6),
	mpg_def_id NUMBER (10, 0),
	peer_admit_pmpm NUMBER (28, 6),
	peer_amt_req_med_pmpm NUMBER (28, 6),
	peer_amt_req_rx_pmpm NUMBER (28, 6),
	peer_cost1_med_pmpm NUMBER (28, 6),
	peer_cost1_rx_pmpm NUMBER (28, 6),
	peer_cost2_med_pmpm NUMBER (28, 6),
	peer_cost2_rx_pmpm NUMBER (28, 6),
	peer_cost3_med_pmpm NUMBER (28, 6),
	peer_cost3_rx_pmpm NUMBER (28, 6),
	peer_cost4_med_pmpm NUMBER (28, 6),
	peer_cost4_rx_pmpm NUMBER (28, 6),
	peer_days_sup_pmpm NUMBER (28, 6),
	peer_encounter_med_pmpm NUMBER (28, 6),
	peer_encounter_rx_pmpm NUMBER (28, 6),
	peer_rrisk_pmpm NUMBER (28, 6),
	rrisk NUMBER (28, 6),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_pop_channel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_pop_channel (
	age_cat2 NUMBER (10, 0),
	channel NUMBER (10, 0),
	cost3 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_encounter_pmpm NUMBER (28, 6),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_pop_drug', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_pop_drug (
	age_cat2 NUMBER (10, 0),
	brand_name VARCHAR2 (50 CHAR),
	cost3 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_encounter_pmpm NUMBER (28, 6),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_pop_formulary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_pop_formulary (
	age_cat2 NUMBER (10, 0),
	cost3 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	formulary NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_encounter_pmpm NUMBER (28, 6),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_pop_generic', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_pop_generic (
	age_cat2 NUMBER (10, 0),
	cost3 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	generic NUMBER (1),
	ia_time NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_encounter_pmpm NUMBER (28, 6),
	peer_script_gen_pmpm NUMBER (28, 6),
	script_gen NUMBER (19, 2),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_pop_source', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_pop_source (
	age_cat2 NUMBER (10, 0),
	cost3 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	gbo NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_encounter_pmpm NUMBER (28, 6),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_pop_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_pop_tos (
	admit NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_net_in NUMBER (19, 2),
	cost3_net_out NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	los NUMBER (19, 2),
	mpg_def_id NUMBER (10, 0),
	peer_admit_pmpm NUMBER (28, 6),
	peer_amt_coin_pmpm NUMBER (28, 6),
	peer_amt_cop_pmpm NUMBER (28, 6),
	peer_amt_ded_pmpm NUMBER (28, 6),
	peer_amt_eqv_pmpm NUMBER (28, 6),
	peer_amt_liab_pmpm NUMBER (28, 6),
	peer_amt_pay_pmpm NUMBER (28, 6),
	peer_amt_req_pmpm NUMBER (28, 6),
	peer_cost1_pmpm NUMBER (28, 6),
	peer_cost2_pmpm NUMBER (28, 6),
	peer_cost3_net_in_pmpm NUMBER (28, 6),
	peer_cost3_net_out_pmpm NUMBER (28, 6),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_cost4_pmpm NUMBER (28, 6),
	peer_encounter_pmpm NUMBER (28, 6),
	peer_los_pmpm NUMBER (28, 6),
	sex NUMBER (1),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mpg_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mpg_qual (
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	peer_comp_rate NUMBER (19, 2),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_conf_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_conf_costs (
	admit_source VARCHAR2 (1 CHAR),
	amt_admin_fee NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	avoidable_admit_flag NUMBER (10, 0),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	covid_flag NUMBER (1),
	dis_stat VARCHAR2 (3 CHAR),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	encounter NUMBER (19, 2),
	er_conf NUMBER (1),
	etg_id NUMBER (10, 0),
	facip_flag NUMBER (10, 0),
	inp_admit_type VARCHAR2 (2 CHAR),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	network_status NUMBER (1),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pdi NUMBER (10, 0),
	planned_adm NUMBER (1),
	poa1 VARCHAR2 (1 CHAR),
	pqi NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_conf_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_conf_count (
	admit NUMBER (10, 0),
	admit_source VARCHAR2 (1 CHAR),
	avoidable_admit_flag NUMBER (10, 0),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	drg_wgt NUMBER (10, 4),
	etg_id NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	los NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	pac_rsnf_index NUMBER (10, 0),
	pac_rsnf_readm_days NUMBER (10, 0),
	pac_rsnf_readmit NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pdi NUMBER (10, 0),
	planned_adm NUMBER (1),
	poa1 VARCHAR2 (1 CHAR),
	pqi NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	readmit_07 NUMBER (10, 0),
	readmit_30 NUMBER (10, 0),
	readmit_60 NUMBER (10, 0),
	readmit_90 NUMBER (10, 0),
	readmit_index_07 NUMBER (10, 0),
	readmit_index_30 NUMBER (10, 0),
	readmit_index_60 NUMBER (10, 0),
	readmit_index_90 NUMBER (10, 0),
	rrisk NUMBER (10, 4),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_costs (
	admit NUMBER (10, 0),
	amt_admin_fee NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	complete NUMBER (1),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	covid_flag NUMBER (1),
	drg_id VARCHAR2 (12 CHAR),
	em_svc_flag NUMBER (10, 0),
	encounter NUMBER (19, 2),
	er_util NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	etg_resp_prov VARCHAR2 (20 CHAR),
	lab_util NUMBER (19, 2),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	los NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mri_util NUMBER (19, 2),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1),
	outlier NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	rad_util NUMBER (19, 2),
	script NUMBER (10, 0),
	script_adj NUMBER (19, 2),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	th_flag NUMBER (1),
	tos_i_5 NUMBER (10, 0),
	tx_ind NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_costs_egr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_costs_egr (
	cost3 NUMBER (38, 2),
	etg_id NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	tos1_id NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_count (
	complete NUMBER (1),
	epi_qty NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	outlier NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	rrisk NUMBER (10, 4),
	sev_level NUMBER (10, 0),
	tx_ind NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_count_egr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_count_egr (
	epi_qty NUMBER (38, 2),
	etg_id NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_phm_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_phm_costs (
	amt_admin_fee NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_disp NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_ingr NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_sales_tax NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	channel NUMBER (10, 0),
	complete NUMBER (1),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	covid_flag NUMBER (1),
	days_sup NUMBER (10, 0),
	etg_id NUMBER (10, 0),
	formulary NUMBER (10, 0),
	gbo NUMBER (10, 0),
	generic NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	outlier NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pres_prov_affil_id VARCHAR2 (40 CHAR),
	pres_prv_i VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	script NUMBER (10, 0),
	script_adj NUMBER (19, 2),
	script_gen NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tx_ind NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_rad_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_rad_costs (
	amt_admin_fee NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	complete NUMBER (1),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	outlier NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	revenue VARCHAR2 (15 CHAR),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tx_ind NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_spec_phm_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_spec_phm_costs (
	amt_admin_fee NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_disp NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_ingr NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_sales_tax NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	complete NUMBER (1),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	daw NUMBER (10, 0),
	encounter NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	outlier NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pos_i NUMBER (10, 0),
	pres_prv_i VARCHAR2 (20 CHAR),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	script NUMBER (19, 2),
	script_adj NUMBER (19, 2),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	spec_drug NUMBER (10, 0),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	tos_i_5 NUMBER (10, 0),
	tx_ind NUMBER (10, 0),
	user_spec_drug NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_member', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_member (
	age_tot NUMBER (10, 0),
	arisk NUMBER (10, 4),
	iatime_lag NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	mm_den NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	premium_tot NUMBER (19, 2),
	prisk NUMBER (10, 4),
	rrisk NUMBER (10, 4),
	subscr_months NUMBER (19, 2),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_member_contract', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_member_contract (
	age_tot NUMBER (10, 0),
	contract_id VARCHAR2 (40 CHAR),
	contract_prisk NUMBER (10, 4),
	contract_rrisk NUMBER (10, 4),
	iatime_lag NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	mm_den NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	premium_tot NUMBER (19, 2),
	primary_payer_ind NUMBER (1),
	prisk NUMBER (10, 4),
	rrisk NUMBER (10, 4),
	subscr_months NUMBER (19, 2),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_member_egr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_member_egr (
	age_cat2 NUMBER (10, 0),
	cat25k NUMBER (1),
	mm NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	mpg_def_id NUMBER (10, 0),
	rrisk NUMBER (12, 4),
	sex NUMBER (1),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_peg_epi_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_peg_epi_costs (
	admit NUMBER (10, 0),
	amt_admin_fee NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	complete NUMBER (10, 0),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	disqualified_flag NUMBER (1),
	drg_id VARCHAR2 (12 CHAR),
	em_svc_flag NUMBER (10, 0),
	encounter NUMBER (19, 2),
	er_util NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	etg_sev_level NUMBER (10, 0),
	lab_util NUMBER (19, 2),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	laterality VARCHAR2 (1 CHAR),
	los NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mri_util NUMBER (19, 2),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1),
	outlier NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	peg_cat_id NUMBER (10, 0),
	peg_sev_level NUMBER (10, 0),
	peg_target NUMBER (10, 0),
	peg_window NUMBER (10, 0),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	rad_util NUMBER (19, 2),
	resp_prov VARCHAR2 (20 CHAR),
	script NUMBER (19, 2),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_peg_epi_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_peg_epi_count (
	complete NUMBER (10, 0),
	disqualified_flag NUMBER (1),
	laterality VARCHAR2 (1 CHAR),
	mem_attr_id NUMBER (10, 0),
	outlier NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	peg_cat_id NUMBER (10, 0),
	peg_epi_qty NUMBER (28, 6),
	peg_score NUMBER (10, 4),
	peg_sev_level NUMBER (10, 0),
	rrisk NUMBER (10, 4),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_peg_epi_phm_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_peg_epi_phm_costs (
	amt_admin_fee NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_disp NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_ingr NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_sales_tax NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	channel NUMBER (10, 0),
	complete NUMBER (10, 0),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	days_sup NUMBER (10, 0),
	disqualified_flag NUMBER (1),
	etg_id NUMBER (10, 0),
	etg_sev_level NUMBER (10, 0),
	formulary NUMBER (10, 0),
	gbo NUMBER (10, 0),
	generic NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	laterality VARCHAR2 (1 CHAR),
	mem_attr_id NUMBER (10, 0),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	outlier NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	peg_cat_id NUMBER (10, 0),
	peg_sev_level NUMBER (10, 0),
	peg_target NUMBER (10, 0),
	peg_window NUMBER (10, 0),
	pres_prov_affil_id VARCHAR2 (40 CHAR),
	pres_prv_i VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	script NUMBER (10, 0),
	script_gen NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_peg_epi_rad_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_peg_epi_rad_costs (
	amt_admin_fee NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	complete NUMBER (10, 0),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	disqualified_flag NUMBER (1),
	encounter NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	etg_sev_level NUMBER (10, 0),
	laterality VARCHAR2 (1 CHAR),
	mem_attr_id NUMBER (10, 0),
	outlier NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	peg_cat_id NUMBER (10, 0),
	peg_sev_level NUMBER (10, 0),
	peg_target NUMBER (10, 0),
	peg_window NUMBER (10, 0),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	revenue VARCHAR2 (15 CHAR),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_costs (
	admit NUMBER (10, 0),
	amt_admin_fee NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	covid_flag NUMBER (1),
	drg_id VARCHAR2 (12 CHAR),
	drg_wgt NUMBER (10, 4),
	em_svc_flag NUMBER (10, 0),
	encounter NUMBER (19, 2),
	er_util NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	iatime_lag NUMBER (10, 0),
	lab_util NUMBER (19, 2),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	los NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mri_util NUMBER (19, 2),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	rad_util NUMBER (19, 2),
	script NUMBER (10, 0),
	script_adj NUMBER (19, 2),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	th_flag NUMBER (1),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_costs_contract', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_costs_contract (
	admit NUMBER (10, 0),
	admit_source VARCHAR2 (1 CHAR),
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cap_pay_k NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_cob_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_ded_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth1_k NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth2_k NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth3_k NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_oth4_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	amt_wth_k NUMBER (19, 2),
	covid_flag NUMBER (1),
	disrel NUMBER (10, 0),
	drg_id VARCHAR2 (12 CHAR),
	drg_wgt NUMBER (10, 4),
	em_svc_flag NUMBER (10, 0),
	em_svc_flag_k NUMBER (10, 0),
	encounter NUMBER (19, 2),
	encounter_k NUMBER (19, 2),
	er_conf NUMBER (1),
	er_util NUMBER (19, 2),
	er_util_k NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	generic NUMBER (10, 0),
	generic_k NUMBER (10, 0),
	iatime_lag NUMBER (10, 0),
	lab_util NUMBER (19, 2),
	lab_util_k NUMBER (19, 2),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	los NUMBER (19, 2),
	mem_attr_id NUMBER (10, 0),
	mri_util NUMBER (19, 2),
	mri_util_k NUMBER (19, 2),
	network_paid_status_id VARCHAR2 (40 CHAR),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	rad_util NUMBER (19, 2),
	rad_util_k NUMBER (19, 2),
	revenue VARCHAR2 (15 CHAR),
	script NUMBER (10, 0),
	script_adj NUMBER (19, 2),
	script_adj_k NUMBER (19, 2),
	script_gen NUMBER (10, 0),
	script_gen_k NUMBER (10, 0),
	script_k NUMBER (10, 0),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	th_flag NUMBER (1),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_costs_egr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_costs_egr (
	admit NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	amt_coin NUMBER (38, 2),
	amt_cop NUMBER (38, 2),
	amt_ded NUMBER (38, 2),
	amt_eqv NUMBER (38, 2),
	amt_liab NUMBER (38, 2),
	amt_req NUMBER (38, 2),
	cat25k NUMBER (1),
	cost3 NUMBER (38, 2),
	encounter NUMBER (38, 2),
	los NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	network_status NUMBER (1),
	script NUMBER (10, 0),
	sex NUMBER (1),
	tos1 VARCHAR2 (100 CHAR),
	tos1_id NUMBER (10, 0),
	tos_cat_id NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_costs_egr_tos5', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_costs_egr_tos5 (
	age_cat2 NUMBER (10, 0),
	cost3 NUMBER (38, 2),
	encounter NUMBER (38, 2),
	mpg_def_id NUMBER (10, 0),
	sex NUMBER (1),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_phm_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_phm_costs (
	amt_admin_fee NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_disp NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_ingr NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_sales_tax NUMBER (19, 2),
	brand_name VARCHAR2 (50 CHAR),
	channel NUMBER (10, 0),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	covid_flag NUMBER (1),
	daw NUMBER (10, 0),
	days_sup NUMBER (10, 0),
	encounter NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	formulary NUMBER (10, 0),
	gbo NUMBER (10, 0),
	generic NUMBER (10, 0),
	iatime_lag NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	ndc VARCHAR2 (11 CHAR),
	network_status NUMBER (1),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pres_prov_affil_id VARCHAR2 (40 CHAR),
	pres_prv_i VARCHAR2 (20 CHAR),
	script NUMBER (10, 0),
	script_adj NUMBER (19, 2),
	script_gen NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_phm_cst_contr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_phm_cst_contr (
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cap_pay_k NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_cob_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_ded_k NUMBER (19, 2),
	amt_disp NUMBER (19, 2),
	amt_disp_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_k NUMBER (19, 2),
	amt_ingr NUMBER (19, 2),
	amt_ingr_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth1_k NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth2_k NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth3_k NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_oth4_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	amt_sales_tax NUMBER (19, 2),
	amt_sales_tax_k NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	amt_wth_k NUMBER (19, 2),
	brand_name VARCHAR2 (50 CHAR),
	channel NUMBER (10, 0),
	covid_flag NUMBER (1),
	daw NUMBER (10, 0),
	days_sup NUMBER (10, 0),
	days_sup_k NUMBER (10, 0),
	encounter NUMBER (19, 2),
	encounter_k NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	formulary NUMBER (10, 0),
	gbo NUMBER (10, 0),
	generic NUMBER (10, 0),
	generic_k NUMBER (10, 0),
	iatime_lag NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pres_prov_affil_id VARCHAR2 (40 CHAR),
	pres_prv_i VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	rx_count_n NUMBER (10, 2),
	rx_count_n_k NUMBER (10, 2),
	script NUMBER (10, 0),
	script_adj NUMBER (19, 2),
	script_adj_k NUMBER (19, 2),
	script_gen NUMBER (10, 0),
	script_gen_k NUMBER (10, 0),
	script_k NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_phm_costs_egr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_phm_costs_egr (
	age_cat2 NUMBER (10, 0),
	amt_liab NUMBER (38, 2),
	amt_req NUMBER (38, 2),
	cat25k NUMBER (1),
	channel NUMBER (10, 0),
	cost3 NUMBER (38, 2),
	days_sup NUMBER (10, 0),
	encounter NUMBER (38, 2),
	formulary NUMBER (10, 0),
	gbo NUMBER (10, 0),
	generic NUMBER (10, 0),
	mpg_def_id NUMBER (10, 0),
	script NUMBER (10, 0),
	script_gen NUMBER (10, 0),
	sex NUMBER (1),
	tos2_id NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_rad_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_rad_costs (
	amt_admin_fee NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	iatime_lag NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	revenue VARCHAR2 (15 CHAR),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_rad_cst_contr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_rad_cst_contr (
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cap_pay_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_ded_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	encounter NUMBER (19, 2),
	encounter_k NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	iatime_lag NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pos_i NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	revenue VARCHAR2 (15 CHAR),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_spec_phm_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_spec_phm_costs (
	amt_admin_fee NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_disp NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_ingr NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_sales_tax NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	daw NUMBER (10, 0),
	encounter NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	iatime_lag NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pos_i NUMBER (10, 0),
	pres_prv_i VARCHAR2 (20 CHAR),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	script NUMBER (19, 2),
	script_adj NUMBER (19, 2),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	spec_drug NUMBER (10, 0),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	tos_i_5 NUMBER (10, 0),
	user_spec_drug NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pp_spc_pm_cst_ctrt', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pp_spc_pm_cst_ctrt (
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cap_pay_k NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_cob_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_ded_k NUMBER (19, 2),
	amt_disp NUMBER (19, 2),
	amt_disp_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_k NUMBER (19, 2),
	amt_ingr NUMBER (19, 2),
	amt_ingr_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth1_k NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth2_k NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth3_k NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_oth4_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	amt_sales_tax NUMBER (19, 2),
	amt_sales_tax_k NUMBER (19, 2),
	daw NUMBER (10, 0),
	encounter NUMBER (19, 2),
	encounter_k NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	iatime_lag NUMBER (10, 0),
	lag_ind NUMBER (1),
	lag_months NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	pcp_affil_id VARCHAR2 (40 CHAR),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	pos_i NUMBER (10, 0),
	pres_prv_i VARCHAR2 (20 CHAR),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	rx_count_n NUMBER (10, 2),
	rx_count_n_k NUMBER (10, 2),
	script NUMBER (19, 2),
	script_adj NUMBER (19, 2),
	script_adj_k NUMBER (19, 2),
	script_k NUMBER (19, 2),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (10, 0),
	spec_drug NUMBER (10, 0),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	tos_i_5 NUMBER (10, 0),
	user_spec_drug NUMBER (10, 0),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_paf_completion_member', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_paf_completion_member (
	id NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	member_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_adm_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_adm_costs (
	cost2_adm_peer NUMBER (28, 6),
	cost3_adm_peer NUMBER (28, 6),
	cost_adm_peer NUMBER (28, 6),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_unit_id VARCHAR2 (12 CHAR),
	fac_qty_elig_peer NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	los_adm_peer NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	readmit_07_peer NUMBER (28, 6),
	readmit_30_peer NUMBER (28, 6),
	readmit_60_peer NUMBER (28, 6),
	readmit_90_peer NUMBER (28, 6),
	rrisk_adm_peer NUMBER (28, 6)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_def_var', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_def_var (
	account_lv1_id VARCHAR2 (100 CHAR),
	account_lv2_id VARCHAR2 (100 CHAR),
	at_risk_status_lv1_id VARCHAR2 (100 CHAR),
	at_risk_status_lv2_id VARCHAR2 (100 CHAR),
	contract_lv1_id VARCHAR2 (100 CHAR),
	contract_lv2_id VARCHAR2 (100 CHAR),
	lob_id NUMBER (10, 0),
	network_paid_status_lv1_id VARCHAR2 (100 CHAR),
	network_paid_status_lv2_id VARCHAR2 (100 CHAR),
	network_status NUMBER (1),
	par_status NUMBER (1),
	pcp_prov_affil_lv1_id VARCHAR2 (100 CHAR),
	pcp_prov_affil_lv2_id VARCHAR2 (100 CHAR),
	peer_def_var_desc VARCHAR2 (150 CHAR),
	peer_def_var_id NUMBER (10, 0),
	peer_def_var_type NUMBER (10, 0),
	product_lv1_id VARCHAR2 (100 CHAR),
	product_lv2_id VARCHAR2 (100 CHAR),
	provider_status_lv1_id VARCHAR2 (100 CHAR),
	provider_status_lv2_id VARCHAR2 (100 CHAR),
	risk_status NUMBER (1),
	serv_prov_affil_lv1_id VARCHAR2 (100 CHAR),
	serv_prov_affil_lv2_id VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_ebm_rates', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_ebm_rates (
	pcp_imp_flag NUMBER (1),
	peer_def_id NUMBER (10, 0),
	peer_rate NUMBER (28, 6),
	qual_opp_elig_peer NUMBER (1),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_epi_analytic', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_epi_analytic (
	admit NUMBER (10, 0),
	attr_reason_id NUMBER (10, 0),
	code_type NUMBER (10, 0),
	complete NUMBER (1),
	cost1 NUMBER (28, 6),
	cost2 NUMBER (28, 6),
	cost3 NUMBER (28, 6),
	cost_e NUMBER (28, 6),
	encounter NUMBER (28, 6),
	epi_qty NUMBER (28, 6),
	episode_id NUMBER (19, 0),
	er_util NUMBER (28, 6),
	etg_id NUMBER (10, 0),
	etg_unit VARCHAR2 (9 CHAR),
	etg_unit_id NUMBER (10, 0),
	generic NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	lab_util NUMBER (28, 6),
	los NUMBER (28, 6),
	member VARCHAR2 (32 CHAR),
	mri_util NUMBER (28, 6),
	ospvis NUMBER (28, 6),
	outlier NUMBER (10, 0),
	outlier_clinical NUMBER (10, 0),
	outlier_e NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	psc_cat1_id NUMBER (10, 0),
	rad_util NUMBER (28, 6),
	script NUMBER (28, 6),
	script_gen NUMBER (28, 6),
	serv_code VARCHAR2 (15 CHAR),
	sev_level NUMBER (10, 0),
	specprv NUMBER (1),
	spvis NUMBER (28, 6),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_epi_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_epi_costs (
	admit_peer NUMBER (28, 6),
	cost2_peer NUMBER (28, 6),
	cost3_peer NUMBER (28, 6),
	cost_peer NUMBER (28, 6),
	days_peer NUMBER (28, 6),
	enc_peer NUMBER (28, 6),
	er_peer NUMBER (28, 6),
	etg_unit_id NUMBER (10, 0),
	gen_peer NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	lab_peer NUMBER (28, 6),
	mri_peer NUMBER (28, 6),
	ospvis_peer NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	psc_cat1_id NUMBER (10, 0),
	rad_peer NUMBER (28, 6),
	script_peer NUMBER (28, 6),
	specprv NUMBER (1),
	spvis_peer NUMBER (28, 6),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_epi_costs_peg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_epi_costs_peg (
	admit_peer NUMBER (28, 6),
	cost2_peer NUMBER (28, 6),
	cost3_peer NUMBER (28, 6),
	cost_peer NUMBER (28, 6),
	days_peer NUMBER (28, 6),
	enc_peer NUMBER (28, 6),
	er_peer NUMBER (28, 6),
	gen_peer NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	lab_peer NUMBER (28, 6),
	mri_peer NUMBER (28, 6),
	ospvis_peer NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	peg_psc_cat1_id NUMBER (10, 0),
	peg_unit_id NUMBER (10, 0),
	peg_window NUMBER (10, 0),
	phm_qual NUMBER (1),
	rad_peer NUMBER (28, 6),
	script_peer NUMBER (28, 6),
	spvis_peer NUMBER (28, 6),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_epi_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_epi_count (
	epi_qty_elig_peer NUMBER (1),
	epi_qty_peer NUMBER (28, 6),
	epi_qty_rx_peer NUMBER (28, 6),
	etg_unit_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_epi_count_peg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_epi_count_peg (
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peg_epi_qty_elig_peer NUMBER (1),
	peg_epi_qty_peer NUMBER (28, 6),
	peg_epi_qty_rx_peer NUMBER (28, 6),
	peg_unit_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_epi_etg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_epi_etg (
	etg_id NUMBER (10, 0),
	peer_def_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_mem_exc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_mem_exc (
	ia_time NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	peer_def_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_pop_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_pop_costs (
	admit_peer NUMBER (28, 6),
	cost2_peer NUMBER (28, 6),
	cost3_peer NUMBER (28, 6),
	cost_peer NUMBER (28, 6),
	days_peer NUMBER (28, 6),
	enc_peer NUMBER (28, 6),
	er_peer NUMBER (28, 6),
	gen_peer NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	lab_peer NUMBER (28, 6),
	mri_peer NUMBER (28, 6),
	pcp_imp_flag NUMBER (10, 0),
	pcpvis_peer NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	pop_qty_elig_peer NUMBER (1),
	psc_cat1_id NUMBER (10, 0),
	rad_peer NUMBER (28, 6),
	ref_peer NUMBER (28, 6),
	refvis_peer NUMBER (28, 6),
	rrisk_cat NUMBER (10, 0),
	script_peer NUMBER (28, 6),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_pop_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_pop_count (
	ia_time NUMBER (10, 0),
	pcp_imp_flag NUMBER (10, 0),
	pcp_mmos_peer NUMBER (28, 6),
	pcp_mmos_rx_peer NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	pop_qty_elig_peer NUMBER (10, 0),
	rrisk_cat NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peer_ps_results', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peer_ps_results (
	peer_def_id NUMBER (10, 0),
	quest_id VARCHAR2 (5 CHAR),
	quest_resp_peer NUMBER (10, 0),
	quest_result_peer NUMBER (19, 2),
	survey_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_claims_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_claims_detail (
	amt_eqv NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	claim_id VARCHAR2 (30 CHAR),
	etg VARCHAR2 (9 CHAR),
	etg_anc_type VARCHAR2 (1 CHAR),
	etg_clus_prv VARCHAR2 (20 CHAR),
	etg_cluster NUMBER (10, 0),
	etg_epi_type NUMBER (10, 0),
	etg_episode_id NUMBER (19, 0),
	etg_rec_type VARCHAR2 (1 CHAR),
	etg_top NUMBER (10, 0),
	etg_tos NUMBER (10, 0),
	from_dt TIMESTAMP,
	icd_version NUMBER (10, 0),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	mod_n_2 VARCHAR2 (4 CHAR),
	mod_n_3 VARCHAR2 (4 CHAR),
	mod_n_4 VARCHAR2 (4 CHAR),
	order_prov VARCHAR2 (20 CHAR),
	outlier NUMBER (10, 0),
	pay_dt TIMESTAMP,
	peg_anchor_proc_flag NUMBER (10, 0),
	peg_cat_id NUMBER (10, 0),
	peg_epi_cost_ratio_hi NUMBER (19, 2),
	peg_epi_cost_ratio_lo NUMBER (19, 2),
	peg_episode_id NUMBER (19, 0),
	peg_target NUMBER (10, 0),
	peg_unrelated_etg NUMBER (10, 0),
	peg_window NUMBER (10, 0),
	phantom_claim NUMBER (1),
	proccode VARCHAR2 (15 CHAR),
	provider VARCHAR2 (20 CHAR),
	revenue VARCHAR2 (15 CHAR),
	to_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_complications', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_complications (
	comp_code VARCHAR2 (5 CHAR),
	diag1 VARCHAR2 (8 CHAR),
	diag1_icd_version NUMBER (10, 0),
	diag2 VARCHAR2 (8 CHAR),
	diag2_icd_version NUMBER (10, 0),
	diag3 VARCHAR2 (8 CHAR),
	diag3_icd_version NUMBER (10, 0),
	diag4 VARCHAR2 (8 CHAR),
	diag4_icd_version NUMBER (10, 0),
	diag5 VARCHAR2 (8 CHAR),
	diag5_icd_version NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	peg_episode_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_detail (
	amt_eqv NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	claim_id VARCHAR2 (30 CHAR),
	etg VARCHAR2 (9 CHAR),
	etg_anc_type VARCHAR2 (1 CHAR),
	etg_clus_prv VARCHAR2 (20 CHAR),
	etg_cluster NUMBER (10, 0),
	etg_epi_type NUMBER (10, 0),
	etg_episode_id NUMBER (19, 0),
	etg_rec_type VARCHAR2 (1 CHAR),
	etg_top NUMBER (10, 0),
	etg_tos NUMBER (10, 0),
	from_dt TIMESTAMP,
	icd_version NUMBER (10, 0),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_array VARCHAR2 (10 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	mod_n_2 VARCHAR2 (4 CHAR),
	mod_n_3 VARCHAR2 (4 CHAR),
	mod_n_4 VARCHAR2 (4 CHAR),
	order_prov VARCHAR2 (20 CHAR),
	pay_dt TIMESTAMP,
	peg_anchor_proc_flag NUMBER (10, 0),
	peg_cat_id NUMBER (10, 0),
	peg_episode_id NUMBER (19, 0),
	peg_target NUMBER (10, 0),
	peg_unrelated_etg NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider VARCHAR2 (20 CHAR),
	revenue VARCHAR2 (15 CHAR),
	to_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_epi_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_epi_costs (
	admit_act_tot NUMBER (10, 0),
	admit_peer_tot NUMBER (28, 6),
	cat_member NUMBER (10, 0),
	cost2_act_tot NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	days_act_tot NUMBER (28, 6),
	days_peer_tot NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	enc_peer_tot NUMBER (28, 6),
	er_act_tot NUMBER (28, 6),
	er_peer_tot NUMBER (28, 6),
	gen_act_tot NUMBER (28, 6),
	gen_peer_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	ia_time_adj NUMBER (10, 0),
	lab_act_tot NUMBER (28, 6),
	lab_peer_tot NUMBER (28, 6),
	laterality VARCHAR2 (1 CHAR),
	mri_act_tot NUMBER (28, 6),
	mri_peer_tot NUMBER (28, 6),
	ospvis_act_tot NUMBER (28, 6),
	ospvis_peer_tot NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	peg_cat_id NUMBER (10, 0),
	peg_psc_cat1_id NUMBER (10, 0),
	peg_sev_level NUMBER (10, 0),
	peg_unit_id NUMBER (10, 0),
	peg_window NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rad_act_tot NUMBER (28, 6),
	rad_peer_tot NUMBER (28, 6),
	script_act_tot NUMBER (28, 6),
	script_gen_act_tot NUMBER (28, 6),
	script_peer_tot NUMBER (28, 6),
	spvis_act_tot NUMBER (28, 6),
	spvis_peer_tot NUMBER (28, 6),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_epi_cst_epilevel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_epi_cst_epilevel (
	admit_act_tot NUMBER (10, 0),
	admit_act_tot_post NUMBER (10, 0),
	admit_act_tot_pre NUMBER (10, 0),
	admit_peer_tot NUMBER (28, 6),
	admit_peer_tot_post NUMBER (28, 6),
	admit_peer_tot_pre NUMBER (28, 6),
	cost2_act_tot NUMBER (28, 6),
	cost2_act_tot_post NUMBER (28, 6),
	cost2_act_tot_pre NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost2_peer_tot_post NUMBER (28, 6),
	cost2_peer_tot_pre NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_act_tot_post NUMBER (28, 6),
	cost3_act_tot_pre NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost3_peer_tot_post NUMBER (28, 6),
	cost3_peer_tot_pre NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_act_tot_post NUMBER (28, 6),
	cost_act_tot_pre NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	cost_peer_tot_post NUMBER (28, 6),
	cost_peer_tot_pre NUMBER (28, 6),
	days_act_tot NUMBER (28, 6),
	days_act_tot_post NUMBER (28, 6),
	days_act_tot_pre NUMBER (28, 6),
	days_peer_tot NUMBER (28, 6),
	days_peer_tot_post NUMBER (28, 6),
	days_peer_tot_pre NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	enc_act_tot_post NUMBER (28, 6),
	enc_act_tot_pre NUMBER (28, 6),
	enc_peer_tot NUMBER (28, 6),
	enc_peer_tot_post NUMBER (28, 6),
	enc_peer_tot_pre NUMBER (28, 6),
	er_act_tot NUMBER (28, 6),
	er_act_tot_post NUMBER (28, 6),
	er_act_tot_pre NUMBER (28, 6),
	er_cost2_act_tot NUMBER (28, 6),
	er_cost2_act_tot_post NUMBER (28, 6),
	er_cost2_act_tot_pre NUMBER (28, 6),
	er_cost2_peer_tot NUMBER (28, 6),
	er_cost2_peer_tot_post NUMBER (28, 6),
	er_cost2_peer_tot_pre NUMBER (28, 6),
	er_cost3_act_tot NUMBER (28, 6),
	er_cost3_act_tot_post NUMBER (28, 6),
	er_cost3_act_tot_pre NUMBER (28, 6),
	er_cost3_peer_tot NUMBER (28, 6),
	er_cost3_peer_tot_post NUMBER (28, 6),
	er_cost3_peer_tot_pre NUMBER (28, 6),
	er_cost_act_tot NUMBER (28, 6),
	er_cost_act_tot_post NUMBER (28, 6),
	er_cost_act_tot_pre NUMBER (28, 6),
	er_cost_peer_tot NUMBER (28, 6),
	er_cost_peer_tot_post NUMBER (28, 6),
	er_cost_peer_tot_pre NUMBER (28, 6),
	er_enc_act_tot NUMBER (28, 6),
	er_enc_act_tot_post NUMBER (28, 6),
	er_enc_act_tot_pre NUMBER (28, 6),
	er_enc_peer_tot NUMBER (28, 6),
	er_enc_peer_tot_post NUMBER (28, 6),
	er_enc_peer_tot_pre NUMBER (28, 6),
	er_peer_tot NUMBER (28, 6),
	er_peer_tot_post NUMBER (28, 6),
	er_peer_tot_pre NUMBER (28, 6),
	gen_act_tot NUMBER (28, 6),
	gen_act_tot_post NUMBER (28, 6),
	gen_act_tot_pre NUMBER (28, 6),
	gen_peer_tot NUMBER (28, 6),
	gen_peer_tot_post NUMBER (28, 6),
	gen_peer_tot_pre NUMBER (28, 6),
	hosp_inp_cost2_act_tot NUMBER (28, 6),
	hosp_inp_cost2_act_tot_post NUMBER (28, 6),
	hosp_inp_cost2_act_tot_pre NUMBER (28, 6),
	hosp_inp_cost2_peer_tot NUMBER (28, 6),
	hosp_inp_cost2_peer_tot_post NUMBER (28, 6),
	hosp_inp_cost2_peer_tot_pre NUMBER (28, 6),
	hosp_inp_cost3_act_tot NUMBER (28, 6),
	hosp_inp_cost3_act_tot_post NUMBER (28, 6),
	hosp_inp_cost3_act_tot_pre NUMBER (28, 6),
	hosp_inp_cost3_peer_tot NUMBER (28, 6),
	hosp_inp_cost3_peer_tot_post NUMBER (28, 6),
	hosp_inp_cost3_peer_tot_pre NUMBER (28, 6),
	hosp_inp_cost_act_tot NUMBER (28, 6),
	hosp_inp_cost_act_tot_post NUMBER (28, 6),
	hosp_inp_cost_act_tot_pre NUMBER (28, 6),
	hosp_inp_cost_peer_tot NUMBER (28, 6),
	hosp_inp_cost_peer_tot_post NUMBER (28, 6),
	hosp_inp_cost_peer_tot_pre NUMBER (28, 6),
	hosp_inp_enc_act_tot NUMBER (28, 6),
	hosp_inp_enc_act_tot_post NUMBER (28, 6),
	hosp_inp_enc_act_tot_pre NUMBER (28, 6),
	hosp_inp_enc_peer_tot NUMBER (28, 6),
	hosp_inp_enc_peer_tot_post NUMBER (28, 6),
	hosp_inp_enc_peer_tot_pre NUMBER (28, 6),
	hosp_op_othr_cost2_act_tot NUMBER (28, 6),
	HOSP_OP_OTHR_CST2_ACT_TOT_PST NUMBER (28, 6),
	hosp_op_othr_cost2_act_tot_pre NUMBER (28, 6),
	hosp_op_othr_cost2_peer_tot NUMBER (28, 6),
	HOSP_OP_OTHR_CST2_PEER_TOT_PST NUMBER (28, 6),
	HOSP_OP_OTHR_CST2_PEER_TOT_PRE NUMBER (28, 6),
	hosp_op_othr_cost3_act_tot NUMBER (28, 6),
	HOSP_OP_OTHR_CST3_ACT_TOT_PST NUMBER (28, 6),
	hosp_op_othr_cost3_act_tot_pre NUMBER (28, 6),
	hosp_op_othr_cost3_peer_tot NUMBER (28, 6),
	HOSP_OP_OTHR_CST3_PEER_TOT_PST NUMBER (28, 6),
	HOSP_OP_OTHR_CST3_PEER_TOT_PRE NUMBER (28, 6),
	hosp_op_othr_cost_act_tot NUMBER (28, 6),
	hosp_op_othr_cost_act_tot_post NUMBER (28, 6),
	hosp_op_othr_cost_act_tot_pre NUMBER (28, 6),
	hosp_op_othr_cost_peer_tot NUMBER (28, 6),
	HOSP_OP_OTHR_CST_PEER_TOT_PST NUMBER (28, 6),
	hosp_op_othr_cost_peer_tot_pre NUMBER (28, 6),
	hosp_op_othr_enc_act_tot NUMBER (28, 6),
	hosp_op_othr_enc_act_tot_post NUMBER (28, 6),
	hosp_op_othr_enc_act_tot_pre NUMBER (28, 6),
	hosp_op_othr_enc_peer_tot NUMBER (28, 6),
	hosp_op_othr_enc_peer_tot_post NUMBER (28, 6),
	hosp_op_othr_enc_peer_tot_pre NUMBER (28, 6),
	hosp_op_surg_cost2_act_tot NUMBER (28, 6),
	HOSP_OP_SURG_CST2_ACT_TOT_PST NUMBER (28, 6),
	hosp_op_surg_cost2_act_tot_pre NUMBER (28, 6),
	hosp_op_surg_cost2_peer_tot NUMBER (28, 6),
	HOSP_OP_SURG_CST2_PEER_TOT_PST NUMBER (28, 6),
	HOSP_OP_SURG_CST2_PEER_TOT_PRE NUMBER (28, 6),
	hosp_op_surg_cost3_act_tot NUMBER (28, 6),
	HOSP_OP_SURG_CST3_ACT_TOT_PST NUMBER (28, 6),
	hosp_op_surg_cost3_act_tot_pre NUMBER (28, 6),
	hosp_op_surg_cost3_peer_tot NUMBER (28, 6),
	HOSP_OP_SURG_CST3_PEER_TOT_PST NUMBER (28, 6),
	HOSP_OP_SURG_CST3_PEER_TOT_PRE NUMBER (28, 6),
	hosp_op_surg_cost_act_tot NUMBER (28, 6),
	hosp_op_surg_cost_act_tot_post NUMBER (28, 6),
	hosp_op_surg_cost_act_tot_pre NUMBER (28, 6),
	hosp_op_surg_cost_peer_tot NUMBER (28, 6),
	HOSP_OP_SURG_CST_PEER_TOT_PST NUMBER (28, 6),
	hosp_op_surg_cost_peer_tot_pre NUMBER (28, 6),
	hosp_op_surg_enc_act_tot NUMBER (28, 6),
	hosp_op_surg_enc_act_tot_post NUMBER (28, 6),
	hosp_op_surg_enc_act_tot_pre NUMBER (28, 6),
	hosp_op_surg_enc_peer_tot NUMBER (28, 6),
	hosp_op_surg_enc_peer_tot_post NUMBER (28, 6),
	hosp_op_surg_enc_peer_tot_pre NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	lab_act_tot NUMBER (28, 6),
	lab_act_tot_post NUMBER (28, 6),
	lab_act_tot_pre NUMBER (28, 6),
	lab_cost2_act_tot NUMBER (28, 6),
	lab_cost2_act_tot_post NUMBER (28, 6),
	lab_cost2_act_tot_pre NUMBER (28, 6),
	lab_cost2_peer_tot NUMBER (28, 6),
	lab_cost2_peer_tot_post NUMBER (28, 6),
	lab_cost2_peer_tot_pre NUMBER (28, 6),
	lab_cost3_act_tot NUMBER (28, 6),
	lab_cost3_act_tot_post NUMBER (28, 6),
	lab_cost3_act_tot_pre NUMBER (28, 6),
	lab_cost3_peer_tot NUMBER (28, 6),
	lab_cost3_peer_tot_post NUMBER (28, 6),
	lab_cost3_peer_tot_pre NUMBER (28, 6),
	lab_cost_act_tot NUMBER (28, 6),
	lab_cost_act_tot_post NUMBER (28, 6),
	lab_cost_act_tot_pre NUMBER (28, 6),
	lab_cost_peer_tot NUMBER (28, 6),
	lab_cost_peer_tot_post NUMBER (28, 6),
	lab_cost_peer_tot_pre NUMBER (28, 6),
	lab_enc_act_tot NUMBER (28, 6),
	lab_enc_act_tot_post NUMBER (28, 6),
	lab_enc_act_tot_pre NUMBER (28, 6),
	lab_enc_peer_tot NUMBER (28, 6),
	lab_enc_peer_tot_post NUMBER (28, 6),
	lab_enc_peer_tot_pre NUMBER (28, 6),
	lab_peer_tot NUMBER (28, 6),
	lab_peer_tot_post NUMBER (28, 6),
	lab_peer_tot_pre NUMBER (28, 6),
	mri_act_tot NUMBER (28, 6),
	mri_act_tot_post NUMBER (28, 6),
	mri_act_tot_pre NUMBER (28, 6),
	mri_peer_tot NUMBER (28, 6),
	mri_peer_tot_post NUMBER (28, 6),
	mri_peer_tot_pre NUMBER (28, 6),
	ospvis_act_tot NUMBER (28, 6),
	ospvis_act_tot_post NUMBER (28, 6),
	ospvis_act_tot_pre NUMBER (28, 6),
	ospvis_peer_tot NUMBER (28, 6),
	ospvis_peer_tot_post NUMBER (28, 6),
	ospvis_peer_tot_pre NUMBER (28, 6),
	pcc_cost2_act_tot NUMBER (28, 6),
	pcc_cost2_act_tot_post NUMBER (28, 6),
	pcc_cost2_act_tot_pre NUMBER (28, 6),
	pcc_cost2_peer_tot NUMBER (28, 6),
	pcc_cost2_peer_tot_post NUMBER (28, 6),
	pcc_cost2_peer_tot_pre NUMBER (28, 6),
	pcc_cost3_act_tot NUMBER (28, 6),
	pcc_cost3_act_tot_post NUMBER (28, 6),
	pcc_cost3_act_tot_pre NUMBER (28, 6),
	pcc_cost3_peer_tot NUMBER (28, 6),
	pcc_cost3_peer_tot_post NUMBER (28, 6),
	pcc_cost3_peer_tot_pre NUMBER (28, 6),
	pcc_cost_act_tot NUMBER (28, 6),
	pcc_cost_act_tot_post NUMBER (28, 6),
	pcc_cost_act_tot_pre NUMBER (28, 6),
	pcc_cost_peer_tot NUMBER (28, 6),
	pcc_cost_peer_tot_post NUMBER (28, 6),
	pcc_cost_peer_tot_pre NUMBER (28, 6),
	pcc_enc_act_tot NUMBER (28, 6),
	pcc_enc_act_tot_post NUMBER (28, 6),
	pcc_enc_act_tot_pre NUMBER (28, 6),
	pcc_enc_peer_tot NUMBER (28, 6),
	pcc_enc_peer_tot_post NUMBER (28, 6),
	pcc_enc_peer_tot_pre NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	peg_epi_er_pct NUMBER (7, 4),
	peg_epi_er_pct_adj NUMBER (7, 4),
	peg_epi_hosp_inp_pct NUMBER (7, 4),
	peg_epi_hosp_inp_pct_adj NUMBER (7, 4),
	peg_epi_hosp_op_othr_pct NUMBER (7, 4),
	peg_epi_hosp_op_othr_pct_adj NUMBER (7, 4),
	peg_epi_hosp_op_surg_pct NUMBER (7, 4),
	peg_epi_hosp_op_surg_pct_adj NUMBER (7, 4),
	peg_epi_lab_pct NUMBER (7, 4),
	peg_epi_lab_pct_adj NUMBER (7, 4),
	peg_epi_pcc_pct NUMBER (7, 4),
	peg_epi_pcc_pct_adj NUMBER (7, 4),
	peg_epi_phm_pct NUMBER (7, 4),
	peg_epi_phm_pct_adj NUMBER (7, 4),
	peg_epi_qty NUMBER (28, 6),
	peg_epi_rad_pct NUMBER (7, 4),
	peg_epi_rad_pct_adj NUMBER (7, 4),
	peg_epi_spec_pct NUMBER (7, 4),
	peg_epi_spec_pct_adj NUMBER (7, 4),
	peg_episode_id NUMBER (19, 0),
	peg_unit_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rad_act_tot NUMBER (28, 6),
	rad_act_tot_post NUMBER (28, 6),
	rad_act_tot_pre NUMBER (28, 6),
	rad_cost2_act_tot NUMBER (28, 6),
	rad_cost2_act_tot_post NUMBER (28, 6),
	rad_cost2_act_tot_pre NUMBER (28, 6),
	rad_cost2_peer_tot NUMBER (28, 6),
	rad_cost2_peer_tot_post NUMBER (28, 6),
	rad_cost2_peer_tot_pre NUMBER (28, 6),
	rad_cost3_act_tot NUMBER (28, 6),
	rad_cost3_act_tot_post NUMBER (28, 6),
	rad_cost3_act_tot_pre NUMBER (28, 6),
	rad_cost3_peer_tot NUMBER (28, 6),
	rad_cost3_peer_tot_post NUMBER (28, 6),
	rad_cost3_peer_tot_pre NUMBER (28, 6),
	rad_cost_act_tot NUMBER (28, 6),
	rad_cost_act_tot_post NUMBER (28, 6),
	rad_cost_act_tot_pre NUMBER (28, 6),
	rad_cost_peer_tot NUMBER (28, 6),
	rad_cost_peer_tot_post NUMBER (28, 6),
	rad_cost_peer_tot_pre NUMBER (28, 6),
	rad_enc_act_tot NUMBER (28, 6),
	rad_enc_act_tot_post NUMBER (28, 6),
	rad_enc_act_tot_pre NUMBER (28, 6),
	rad_enc_peer_tot NUMBER (28, 6),
	rad_enc_peer_tot_post NUMBER (28, 6),
	rad_enc_peer_tot_pre NUMBER (28, 6),
	rad_peer_tot NUMBER (28, 6),
	rad_peer_tot_post NUMBER (28, 6),
	rad_peer_tot_pre NUMBER (28, 6),
	rx_cost2_act_tot NUMBER (28, 6),
	rx_cost2_act_tot_post NUMBER (28, 6),
	rx_cost2_act_tot_pre NUMBER (28, 6),
	rx_cost2_peer_tot NUMBER (28, 6),
	rx_cost2_peer_tot_post NUMBER (28, 6),
	rx_cost2_peer_tot_pre NUMBER (28, 6),
	rx_cost3_act_tot NUMBER (28, 6),
	rx_cost3_act_tot_post NUMBER (28, 6),
	rx_cost3_act_tot_pre NUMBER (28, 6),
	rx_cost3_peer_tot NUMBER (28, 6),
	rx_cost3_peer_tot_post NUMBER (28, 6),
	rx_cost3_peer_tot_pre NUMBER (28, 6),
	rx_cost_act_tot NUMBER (28, 6),
	rx_cost_act_tot_post NUMBER (28, 6),
	rx_cost_act_tot_pre NUMBER (28, 6),
	rx_cost_peer_tot NUMBER (28, 6),
	rx_cost_peer_tot_post NUMBER (28, 6),
	rx_cost_peer_tot_pre NUMBER (28, 6),
	rx_enc_act_tot NUMBER (28, 6),
	rx_enc_act_tot_post NUMBER (28, 6),
	rx_enc_act_tot_pre NUMBER (28, 6),
	rx_enc_peer_tot NUMBER (28, 6),
	rx_enc_peer_tot_post NUMBER (28, 6),
	rx_enc_peer_tot_pre NUMBER (28, 6),
	script_act_tot NUMBER (28, 6),
	script_act_tot_post NUMBER (28, 6),
	script_act_tot_pre NUMBER (28, 6),
	script_gen_act_tot NUMBER (28, 6),
	script_gen_act_tot_post NUMBER (28, 6),
	script_gen_act_tot_pre NUMBER (28, 6),
	script_peer_tot NUMBER (28, 6),
	script_peer_tot_post NUMBER (28, 6),
	script_peer_tot_pre NUMBER (28, 6),
	spec_cost2_act_tot NUMBER (28, 6),
	spec_cost2_act_tot_post NUMBER (28, 6),
	spec_cost2_act_tot_pre NUMBER (28, 6),
	spec_cost2_peer_tot NUMBER (28, 6),
	spec_cost2_peer_tot_post NUMBER (28, 6),
	spec_cost2_peer_tot_pre NUMBER (28, 6),
	spec_cost3_act_tot NUMBER (28, 6),
	spec_cost3_act_tot_post NUMBER (28, 6),
	spec_cost3_act_tot_pre NUMBER (28, 6),
	spec_cost3_peer_tot NUMBER (28, 6),
	spec_cost3_peer_tot_post NUMBER (28, 6),
	spec_cost3_peer_tot_pre NUMBER (28, 6),
	spec_cost_act_tot NUMBER (28, 6),
	spec_cost_act_tot_post NUMBER (28, 6),
	spec_cost_act_tot_pre NUMBER (28, 6),
	spec_cost_peer_tot NUMBER (28, 6),
	spec_cost_peer_tot_post NUMBER (28, 6),
	spec_cost_peer_tot_pre NUMBER (28, 6),
	spec_enc_act_tot NUMBER (28, 6),
	spec_enc_act_tot_post NUMBER (28, 6),
	spec_enc_act_tot_pre NUMBER (28, 6),
	spec_enc_peer_tot NUMBER (28, 6),
	spec_enc_peer_tot_post NUMBER (28, 6),
	spec_enc_peer_tot_pre NUMBER (28, 6),
	spvis_act_tot NUMBER (28, 6),
	spvis_act_tot_post NUMBER (28, 6),
	spvis_act_tot_pre NUMBER (28, 6),
	spvis_peer_tot NUMBER (28, 6),
	spvis_peer_tot_post NUMBER (28, 6),
	spvis_peer_tot_pre NUMBER (28, 6)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_epi_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_epi_count (
	cat_member NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	ia_time_adj NUMBER (10, 0),
	laterality VARCHAR2 (1 CHAR),
	peer_def_id NUMBER (10, 0),
	peg_cat_id NUMBER (10, 0),
	peg_epi_qty NUMBER (28, 6),
	peg_sev_level NUMBER (10, 0),
	peg_unit_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rrisk_epi_w NUMBER (28, 6)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_epi_det_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_epi_det_costs (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	cat_member NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	code_type NUMBER (10, 0),
	complete NUMBER (1),
	cost2_act_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_e_act_tot NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	laterality VARCHAR2 (1 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	outlier NUMBER (10, 0),
	outlier_clinical NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peg_cat_id NUMBER (10, 0),
	peg_epi_qty_elig_peer NUMBER (1),
	peg_psc_cat1_id NUMBER (10, 0),
	peg_sev_level NUMBER (10, 0),
	peg_unit_id NUMBER (10, 0),
	peg_window NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	serv_code VARCHAR2 (15 CHAR),
	sex NUMBER (1),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_epi_det_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_epi_det_count (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	cat_member NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	complete NUMBER (1),
	ia_time NUMBER (10, 0),
	laterality VARCHAR2 (1 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	outlier NUMBER (10, 0),
	outlier_clinical NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peg_cat_id NUMBER (10, 0),
	peg_epi_qty NUMBER (28, 6),
	peg_epi_qty_elig_peer NUMBER (1),
	peg_sev_level NUMBER (10, 0),
	peg_unit_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rrisk_epi_w NUMBER (28, 6),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_epi_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_epi_prov (
	attr_reason_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peg_episode_id NUMBER (19, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_episodes', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_episodes (
	age NUMBER (10, 0),
	anchor_proc_dt TIMESTAMP,
	begin_clean NUMBER (10, 0),
	combined NUMBER (10, 0),
	disqualified_flag NUMBER (1),
	drg_id VARCHAR2 (30 CHAR),
	end_clean NUMBER (10, 0),
	fac_allow NUMBER (19, 2),
	fac_paid NUMBER (19, 2),
	gender VARCHAR2 (1 CHAR),
	ia_time NUMBER (10, 0),
	inp_allow NUMBER (19, 2),
	inp_paid NUMBER (19, 2),
	laterality VARCHAR2 (1 CHAR),
	lob NUMBER (10, 0),
	med_qual NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	mgmt_allow NUMBER (19, 2),
	mgmt_paid NUMBER (19, 2),
	other_allow NUMBER (19, 2),
	other_paid NUMBER (19, 2),
	out_allow NUMBER (19, 2),
	out_paid NUMBER (19, 2),
	outlier NUMBER (10, 0),
	peg_cat_id NUMBER (10, 0),
	peg_comp_ind NUMBER (10, 0),
	peg_epi_complete NUMBER (10, 0),
	peg_epi_cost_ratio_hi NUMBER (19, 2),
	peg_epi_cost_ratio_lo NUMBER (19, 2),
	peg_epi_from TIMESTAMP,
	peg_epi_to TIMESTAMP,
	peg_episode_id NUMBER (19, 0),
	peg_pos NUMBER (10, 0),
	peg_pos_expected NUMBER (10, 0),
	peg_pos_status VARCHAR2 (2 CHAR),
	peg_ppc NUMBER (10, 0),
	peg_sev_error_stat NUMBER (10, 0),
	peg_sev_level NUMBER (10, 0),
	peg_sev_score NUMBER (10, 4),
	phm_qual NUMBER (10, 0),
	resp_prov VARCHAR2 (20 CHAR),
	resp_prov_type VARCHAR2 (10 CHAR),
	rx_allow NUMBER (19, 2),
	rx_paid NUMBER (19, 2),
	sub_anchor_id VARCHAR2 (1 CHAR),
	surg_allow NUMBER (19, 2),
	surg_paid NUMBER (19, 2),
	tot_allow NUMBER (19, 2),
	tot_paid NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_phantom', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_phantom (
	amt_eqv NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	claim_id VARCHAR2 (30 CHAR),
	etg VARCHAR2 (9 CHAR),
	etg_anc_type VARCHAR2 (1 CHAR),
	etg_clus_prv VARCHAR2 (20 CHAR),
	etg_cluster NUMBER (10, 0),
	etg_epi_type NUMBER (10, 0),
	etg_episode_id NUMBER (19, 0),
	etg_rec_type VARCHAR2 (1 CHAR),
	etg_top NUMBER (10, 0),
	etg_tos NUMBER (10, 0),
	from_dt TIMESTAMP,
	icd_version NUMBER (10, 0),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_array VARCHAR2 (10 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	mod_n_2 VARCHAR2 (4 CHAR),
	mod_n_3 VARCHAR2 (4 CHAR),
	mod_n_4 VARCHAR2 (4 CHAR),
	order_prov VARCHAR2 (20 CHAR),
	pay_dt TIMESTAMP,
	peg_cat_id NUMBER (10, 0),
	peg_episode_id NUMBER (19, 0),
	peg_target NUMBER (10, 0),
	peg_unrelated_etg NUMBER (10, 0),
	proccode VARCHAR2 (15 CHAR),
	provider VARCHAR2 (20 CHAR),
	revenue VARCHAR2 (15 CHAR),
	to_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_peg_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_peg_summary (
	age NUMBER (10, 0),
	anchor_proc_dt TIMESTAMP,
	begin_clean NUMBER (10, 0),
	combined NUMBER (10, 0),
	end_clean NUMBER (10, 0),
	fac_allow NUMBER (19, 2),
	fac_paid NUMBER (19, 2),
	gender VARCHAR2 (1 CHAR),
	inp_allow NUMBER (19, 2),
	inp_paid NUMBER (19, 2),
	laterality VARCHAR2 (1 CHAR),
	lob NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	mgmt_allow NUMBER (19, 2),
	mgmt_paid NUMBER (19, 2),
	other_allow NUMBER (19, 2),
	other_paid NUMBER (19, 2),
	out_allow NUMBER (19, 2),
	out_paid NUMBER (19, 2),
	outlier NUMBER (10, 0),
	peg_cat_id NUMBER (10, 0),
	peg_comp_ind NUMBER (10, 0),
	peg_epi_complete NUMBER (10, 0),
	peg_epi_from TIMESTAMP,
	peg_epi_to TIMESTAMP,
	peg_episode_id NUMBER (19, 0),
	peg_pos NUMBER (10, 0),
	peg_pos_expected NUMBER (10, 0),
	peg_pos_status VARCHAR2 (2 CHAR),
	peg_ppc NUMBER (10, 0),
	peg_sev_error_stat NUMBER (10, 0),
	peg_sev_level NUMBER (10, 0),
	peg_sev_score NUMBER (10, 4),
	resp_prov VARCHAR2 (20 CHAR),
	resp_prov_type VARCHAR2 (10 CHAR),
	rx_allow NUMBER (19, 2),
	rx_paid NUMBER (19, 2),
	sub_anchor_id VARCHAR2 (1 CHAR),
	surg_allow NUMBER (19, 2),
	surg_paid NUMBER (19, 2),
	tot_allow NUMBER (19, 2),
	tot_paid NUMBER (19, 2),
	user_outlier NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pop_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pop_costs (
	admit_act_tot NUMBER (10, 0),
	admit_peer_tot NUMBER (28, 6),
	age_cat2 NUMBER (10, 0),
	cost2_act_tot NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	days_act_tot NUMBER (28, 6),
	days_peer_tot NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	enc_peer_tot NUMBER (28, 6),
	er_act_tot NUMBER (28, 6),
	er_peer_tot NUMBER (28, 6),
	gen_act_tot NUMBER (28, 6),
	gen_peer_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	ia_time_adj NUMBER (10, 0),
	lab_act_tot NUMBER (28, 6),
	lab_peer_tot NUMBER (28, 6),
	mri_act_tot NUMBER (28, 6),
	mri_peer_tot NUMBER (28, 6),
	pcp_imp_flag NUMBER (10, 0),
	pcpvis_act_tot NUMBER (28, 6),
	pcpvis_peer_tot NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	psc_cat1_id NUMBER (10, 0),
	rad_act_tot NUMBER (28, 6),
	rad_peer_tot NUMBER (28, 6),
	ref_act_tot NUMBER (28, 6),
	ref_peer_tot NUMBER (28, 6),
	refvis_act_tot NUMBER (28, 6),
	refvis_peer_tot NUMBER (28, 6),
	rrisk_cat NUMBER (10, 0),
	script_act_tot NUMBER (28, 6),
	script_gen_act_tot NUMBER (28, 6),
	script_peer_tot NUMBER (28, 6),
	sex NUMBER (1),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pop_costs_poplevel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pop_costs_poplevel (
	admit_act_tot NUMBER (10, 0),
	admit_peer_tot NUMBER (28, 6),
	age_cat2 NUMBER (10, 0),
	cost2_act_tot NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	days_act_tot NUMBER (28, 6),
	days_peer_tot NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	enc_peer_tot NUMBER (28, 6),
	er_act_tot NUMBER (28, 6),
	er_cost2_act_tot NUMBER (28, 6),
	er_cost2_peer_tot NUMBER (28, 6),
	er_cost3_act_tot NUMBER (28, 6),
	er_cost3_peer_tot NUMBER (28, 6),
	er_cost_act_tot NUMBER (28, 6),
	er_cost_peer_tot NUMBER (28, 6),
	er_enc_act_tot NUMBER (28, 6),
	er_enc_peer_tot NUMBER (28, 6),
	er_peer_tot NUMBER (28, 6),
	gen_act_tot NUMBER (28, 6),
	gen_peer_tot NUMBER (28, 6),
	hosp_cost2_act_tot NUMBER (28, 6),
	hosp_cost2_peer_tot NUMBER (28, 6),
	hosp_cost3_act_tot NUMBER (28, 6),
	hosp_cost3_peer_tot NUMBER (28, 6),
	hosp_cost_act_tot NUMBER (28, 6),
	hosp_cost_peer_tot NUMBER (28, 6),
	hosp_enc_act_tot NUMBER (28, 6),
	hosp_enc_peer_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	lab_act_tot NUMBER (28, 6),
	lab_cost2_act_tot NUMBER (28, 6),
	lab_cost2_peer_tot NUMBER (28, 6),
	lab_cost3_act_tot NUMBER (28, 6),
	lab_cost3_peer_tot NUMBER (28, 6),
	lab_cost_act_tot NUMBER (28, 6),
	lab_cost_peer_tot NUMBER (28, 6),
	lab_enc_act_tot NUMBER (28, 6),
	lab_enc_peer_tot NUMBER (28, 6),
	lab_peer_tot NUMBER (28, 6),
	member VARCHAR2 (32 CHAR),
	mri_act_tot NUMBER (28, 6),
	mri_peer_tot NUMBER (28, 6),
	pcc_cost2_act_tot NUMBER (28, 6),
	pcc_cost2_peer_tot NUMBER (28, 6),
	pcc_cost3_act_tot NUMBER (28, 6),
	pcc_cost3_peer_tot NUMBER (28, 6),
	pcc_cost_act_tot NUMBER (28, 6),
	pcc_cost_peer_tot NUMBER (28, 6),
	pcc_enc_act_tot NUMBER (28, 6),
	pcc_enc_peer_tot NUMBER (28, 6),
	pcp_imp_flag NUMBER (10, 0),
	pcp_mmos NUMBER (28, 6),
	pcpvis_act_tot NUMBER (28, 6),
	pcpvis_peer_tot NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	pop_er_pct NUMBER (7, 4),
	pop_er_pct_adj NUMBER (7, 4),
	pop_hosp_pct NUMBER (7, 4),
	pop_hosp_pct_adj NUMBER (7, 4),
	pop_lab_pct NUMBER (7, 4),
	pop_lab_pct_adj NUMBER (7, 4),
	pop_pcc_pct NUMBER (7, 4),
	pop_pcc_pct_adj NUMBER (7, 4),
	pop_phm_pct NUMBER (7, 4),
	pop_phm_pct_adj NUMBER (7, 4),
	pop_rad_pct NUMBER (7, 4),
	pop_rad_pct_adj NUMBER (7, 4),
	pop_spec_pct NUMBER (7, 4),
	pop_spec_pct_adj NUMBER (7, 4),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rad_act_tot NUMBER (28, 6),
	rad_cost2_act_tot NUMBER (28, 6),
	rad_cost2_peer_tot NUMBER (28, 6),
	rad_cost3_act_tot NUMBER (28, 6),
	rad_cost3_peer_tot NUMBER (28, 6),
	rad_cost_act_tot NUMBER (28, 6),
	rad_cost_peer_tot NUMBER (28, 6),
	rad_enc_act_tot NUMBER (28, 6),
	rad_enc_peer_tot NUMBER (28, 6),
	rad_peer_tot NUMBER (28, 6),
	ref_act_tot NUMBER (28, 6),
	ref_peer_tot NUMBER (28, 6),
	refvis_act_tot NUMBER (28, 6),
	refvis_peer_tot NUMBER (28, 6),
	rrisk_cat NUMBER (10, 0),
	rx_cost2_act_tot NUMBER (28, 6),
	rx_cost2_peer_tot NUMBER (28, 6),
	rx_cost3_act_tot NUMBER (28, 6),
	rx_cost3_peer_tot NUMBER (28, 6),
	rx_cost_act_tot NUMBER (28, 6),
	rx_cost_peer_tot NUMBER (28, 6),
	rx_enc_act_tot NUMBER (28, 6),
	rx_enc_peer_tot NUMBER (28, 6),
	script_act_tot NUMBER (28, 6),
	script_gen_act_tot NUMBER (28, 6),
	script_peer_tot NUMBER (28, 6),
	sex NUMBER (1),
	spec_cost2_act_tot NUMBER (28, 6),
	spec_cost2_peer_tot NUMBER (28, 6),
	spec_cost3_act_tot NUMBER (28, 6),
	spec_cost3_peer_tot NUMBER (28, 6),
	spec_cost_act_tot NUMBER (28, 6),
	spec_cost_peer_tot NUMBER (28, 6),
	spec_enc_act_tot NUMBER (28, 6),
	spec_enc_peer_tot NUMBER (28, 6)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pop_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pop_count (
	age_cat2 NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	ia_time_adj NUMBER (10, 0),
	pcp_imp_flag NUMBER (10, 0),
	pcp_mmos NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rrisk_cat NUMBER (10, 0),
	rrisk_w NUMBER (28, 6),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pop_det_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pop_det_costs (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	cat_member NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	code_type NUMBER (10, 0),
	cost2_act_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_o_act_tot NUMBER (28, 6),
	enc_act_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	pcp_imp_flag NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	psc_cat1_id NUMBER (10, 0),
	rrisk_cat NUMBER (10, 0),
	serv_code VARCHAR2 (20 CHAR),
	sex NUMBER (1),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pop_det_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pop_det_count (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	cat_member NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	pcp_imp_flag NUMBER (10, 0),
	pcp_mmos NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	peer_def_var_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	rrisk_cat NUMBER (10, 0),
	rrisk_w NUMBER (28, 6),
	sex NUMBER (1)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pop_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pop_prov (
	ia_time NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	pcp_imp_flag NUMBER (10, 0),
	pcp_mmos NUMBER (28, 6),
	pcp_mmos_rx NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_claims_age_pd', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_claims_age_pd (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	cost3 NUMBER (19, 2),
	coverage_class NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR),
	sex NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_claims_dist', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_claims_dist (
	account_id VARCHAR2 (40 CHAR),
	cat_status_cost3 NUMBER (10, 0),
	cost3 NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_claims_hc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_claims_hc (
	account_id VARCHAR2 (40 CHAR),
	admit NUMBER (10, 0),
	cost3_anc NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	cost3_tot NUMBER (19, 2),
	coverage_status_desc VARCHAR2 (150 CHAR),
	encounter_ofac NUMBER (19, 2),
	encounter_prof NUMBER (19, 2),
	high_cost_flag NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_status VARCHAR2 (6 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	product_id VARCHAR2 (40 CHAR),
	script NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_claims_lag', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_claims_lag (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_contract_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_contract_type (
	account_id VARCHAR2 (40 CHAR),
	contract_type_id VARCHAR2 (40 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	qtr_id NUMBER (10, 0),
	subscr_months NUMBER (19, 2),
	subscr_related_mm NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_dem', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_dem (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	female_mm NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	male_mm NUMBER (19, 2),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_disprev', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_disprev (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	cost3_anc NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	disease_id NUMBER (10, 0),
	disease_related_flag NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	wrrisk NUMBER (19, 4)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_epi_family', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_epi_family (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	cost3_anc NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	epi_qty NUMBER (19, 2),
	family NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	peer_cost3 NUMBER (19, 2),
	peer_cost3_anc NUMBER (19, 2),
	peer_cost3_ifac NUMBER (19, 2),
	peer_cost3_ofac NUMBER (19, 2),
	peer_cost3_phm NUMBER (19, 2),
	peer_cost3_prof NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_exec_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_exec_summary (
	account_id VARCHAR2 (40 CHAR),
	age_y1 NUMBER (10, 0),
	age_y2 NUMBER (10, 0),
	amt_coin_y1 NUMBER (38, 2),
	amt_coin_y2 NUMBER (38, 2),
	amt_cop_y1 NUMBER (38, 2),
	amt_cop_y2 NUMBER (38, 2),
	amt_ded_y1 NUMBER (38, 2),
	amt_ded_y2 NUMBER (38, 2),
	amt_liab_y1 NUMBER (38, 2),
	amt_liab_y2 NUMBER (38, 2),
	cost3_hc_y1 NUMBER (38, 2),
	cost3_hc_y2 NUMBER (38, 2),
	cost3_in_net_y1 NUMBER (38, 2),
	cost3_in_net_y2 NUMBER (38, 2),
	cost3_y1 NUMBER (38, 2),
	cost3_y2 NUMBER (38, 2),
	generic_y1 NUMBER (10, 0),
	generic_y2 NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm_hc_y1 NUMBER (38, 2),
	mm_hc_y2 NUMBER (38, 2),
	mm_y1 NUMBER (38, 2),
	mm_y2 NUMBER (38, 2),
	peer_amt_coin_pmpm_y1 NUMBER (38, 2),
	peer_amt_coin_pmpm_y2 NUMBER (38, 2),
	peer_amt_cop_pmpm_y1 NUMBER (38, 2),
	peer_amt_cop_pmpm_y2 NUMBER (38, 2),
	peer_amt_ded_pmpm_y1 NUMBER (38, 2),
	peer_amt_ded_pmpm_y2 NUMBER (38, 2),
	peer_amt_liab_pmpm_y1 NUMBER (38, 2),
	peer_amt_liab_pmpm_y2 NUMBER (38, 2),
	peer_cost3_in_net_pmpm_y1 NUMBER (38, 2),
	peer_cost3_in_net_pmpm_y2 NUMBER (38, 2),
	peer_cost3_pmpm_y1 NUMBER (38, 2),
	peer_cost3_pmpm_y2 NUMBER (38, 2),
	peer_generic_pmpm_y1 NUMBER (38, 2),
	peer_generic_pmpm_y2 NUMBER (38, 2),
	peer_rrisk_pmpm_y1 NUMBER (38, 4),
	peer_rrisk_pmpm_y2 NUMBER (38, 4),
	peer_script_form_pmpm_y1 NUMBER (38, 2),
	peer_script_form_pmpm_y2 NUMBER (38, 2),
	peer_script_gen_pmpm_y1 NUMBER (38, 2),
	peer_script_gen_pmpm_y2 NUMBER (38, 2),
	peer_script_mail_pmpm_y1 NUMBER (38, 2),
	peer_script_mail_pmpm_y2 NUMBER (38, 2),
	peer_script_pmpm_y1 NUMBER (38, 2),
	peer_script_pmpm_y2 NUMBER (38, 2),
	product_id VARCHAR2 (40 CHAR),
	rrisk_y1 NUMBER (38, 4),
	rrisk_y2 NUMBER (38, 4),
	script_form_y1 NUMBER (10, 0),
	script_form_y2 NUMBER (10, 0),
	script_gen_y1 NUMBER (10, 0),
	script_gen_y2 NUMBER (10, 0),
	script_mail_y1 NUMBER (10, 0),
	script_mail_y2 NUMBER (10, 0),
	script_y1 NUMBER (10, 0),
	script_y2 NUMBER (10, 0),
	subscr_months_y1 NUMBER (38, 2),
	subscr_months_y2 NUMBER (38, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_network', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_network (
	account_id VARCHAR2 (40 CHAR),
	cost3_in NUMBER (19, 2),
	cost3_out NUMBER (19, 2),
	encounter_in NUMBER (19, 2),
	encounter_out NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	peer_cost3_in_pmpm NUMBER (28, 6),
	peer_cost3_out_pmpm NUMBER (28, 6),
	product_id VARCHAR2 (40 CHAR),
	tos1_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_network_pd', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_network_pd (
	account_id VARCHAR2 (40 CHAR),
	cost3_in NUMBER (19, 2),
	cost3_out NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR),
	tos1_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_phm', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_phm (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	days_sup NUMBER (10, 0),
	generic NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_script_pmpm NUMBER (28, 6),
	product_id VARCHAR2 (40 CHAR),
	script NUMBER (19, 2),
	script_form NUMBER (19, 2),
	script_gen NUMBER (19, 2),
	tos2_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_phm_form', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_phm_form (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	formulary NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_script_pmpm NUMBER (28, 6),
	product_id VARCHAR2 (40 CHAR),
	script NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_phm_script', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_phm_script (
	account_id VARCHAR2 (40 CHAR),
	amt_liab NUMBER (19, 2),
	brand_name VARCHAR2 (50 CHAR),
	cost3 NUMBER (19, 2),
	days_sup NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR),
	script NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_phm_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_phm_summary (
	account_id VARCHAR2 (40 CHAR),
	amt_liab NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_brand NUMBER (19, 2),
	cost3_form NUMBER (19, 2),
	cost3_gen NUMBER (19, 2),
	cost3_mail NUMBER (19, 2),
	cost3_non_form NUMBER (19, 2),
	cost3_retail NUMBER (19, 2),
	days_sup NUMBER (10, 0),
	generic NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm NUMBER (19, 2),
	peer_amt_liab_pmpm NUMBER (28, 6),
	peer_amt_req_pmpm NUMBER (28, 6),
	peer_cost3_brand_pmpm NUMBER (28, 6),
	peer_cost3_form_pmpm NUMBER (28, 6),
	peer_cost3_gen_pmpm NUMBER (28, 6),
	peer_cost3_mail_pmpm NUMBER (28, 6),
	peer_cost3_non_form_pmpm NUMBER (28, 6),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_cost3_retail_pmpm NUMBER (28, 6),
	peer_days_sup_pmpm NUMBER (28, 6),
	peer_generic_pmpm NUMBER (28, 6),
	peer_script_brand_pmpm NUMBER (28, 6),
	peer_script_form_pmpm NUMBER (28, 6),
	peer_script_gen_pmpm NUMBER (28, 6),
	peer_script_mail_pmpm NUMBER (28, 6),
	peer_script_non_form_pmpm NUMBER (28, 6),
	peer_script_pmpm NUMBER (28, 6),
	peer_script_retail_pmpm NUMBER (28, 6),
	product_id VARCHAR2 (40 CHAR),
	script NUMBER (10, 0),
	script_brand NUMBER (10, 0),
	script_form NUMBER (10, 0),
	script_gen NUMBER (10, 0),
	script_mail NUMBER (10, 0),
	script_non_form NUMBER (10, 0),
	script_retail NUMBER (10, 0),
	subscr_months NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_premium_pd', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_premium_pd (
	account_id VARCHAR2 (40 CHAR),
	amt_cap_pay NUMBER (19, 2),
	cost3_med NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm NUMBER (19, 2),
	premium_tot NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	subscr_months NUMBER (19, 2),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_prov (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	los NUMBER (19, 2),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	tos1_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_qual (
	account_id VARCHAR2 (40 CHAR),
	all_ebm_num NUMBER (28, 6),
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	peer_comp_rate NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	rpt_case_id NUMBER (10, 0),
	rule_type_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_risk', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_risk (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	riskcat_lv2 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_spec (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR),
	sp3_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_tos_trend', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_tos_trend (
	account_id VARCHAR2 (40 CHAR),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	los NUMBER (19, 2),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	peer_amt_coin_pmpm NUMBER (28, 6),
	peer_amt_cop_pmpm NUMBER (28, 6),
	peer_amt_ded_pmpm NUMBER (28, 6),
	peer_amt_eqv_pmpm NUMBER (28, 6),
	peer_amt_liab_pmpm NUMBER (28, 6),
	peer_amt_req_pmpm NUMBER (28, 6),
	peer_cost1_pmpm NUMBER (28, 6),
	peer_cost2_pmpm NUMBER (28, 6),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_cost4_pmpm NUMBER (28, 6),
	peer_encounter_pmpm NUMBER (28, 6),
	peer_los_pmpm NUMBER (28, 6),
	product_id VARCHAR2 (40 CHAR),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_tos_trend_qtr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_tos_trend_qtr (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	product_id VARCHAR2 (40 CHAR),
	qtr_id NUMBER (10, 0),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_trend', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_trend (
	account_id VARCHAR2 (40 CHAR),
	age NUMBER (10, 0),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_in_net NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	female_mems NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	male_mems NUMBER (19, 2),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	peer_cost1_pmpm NUMBER (28, 6),
	peer_cost2_pmpm NUMBER (28, 6),
	peer_cost3_in_net_pmpm NUMBER (28, 6),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_cost4_pmpm NUMBER (28, 6),
	peer_rrisk_pmpm NUMBER (28, 6),
	premium_tot NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	rrisk NUMBER (19, 4),
	subscr_months NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_trend_pd', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_trend_pd (
	account_id VARCHAR2 (40 CHAR),
	ia_time NUMBER (10, 0),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm NUMBER (19, 2),
	premium_tot NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	subscr_months NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_pr_emp_trend_qtr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_pr_emp_trend_qtr (
	account_id VARCHAR2 (40 CHAR),
	cost3_in_net NUMBER (19, 2),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mm NUMBER (19, 2),
	product_id VARCHAR2 (40 CHAR),
	qtr_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_premium', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_premium (
	billed_mth NUMBER (10, 0),
	billed_yr NUMBER (10, 0),
	premium_tot NUMBER (19, 2),
	subscriber_id VARCHAR2 (32 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_adm_det_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_adm_det_count (
	adm_100 NUMBER (10, 0),
	adm_200 NUMBER (10, 0),
	adm_300 NUMBER (10, 0),
	adm_400 NUMBER (10, 0),
	admit_act_tot NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_eff_adm', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_eff_adm (
	adm_100 NUMBER (10, 0),
	adm_200 NUMBER (10, 0),
	adm_300 NUMBER (10, 0),
	adm_400 NUMBER (10, 0),
	adm_case_mix NUMBER (28, 6),
	adm_case_mix2 NUMBER (28, 6),
	adm_case_mix3 NUMBER (28, 6),
	admit_act_tot NUMBER (10, 0),
	admit_elig NUMBER (10, 0),
	cost2_act_tot NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	days_act_tot NUMBER (28, 6),
	days_peer_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	rank_dec_adm NUMBER (10, 0),
	rank_dec_adm2 NUMBER (10, 0),
	rank_dec_adm3 NUMBER (10, 0),
	readmit_07_act_tot NUMBER (10, 0),
	readmit_07_peer_tot NUMBER (28, 6),
	readmit_30_act_tot NUMBER (10, 0),
	readmit_30_peer_tot NUMBER (28, 6),
	readmit_60_act_tot NUMBER (10, 0),
	readmit_60_peer_tot NUMBER (28, 6),
	readmit_90_act_tot NUMBER (10, 0),
	readmit_90_peer_tot NUMBER (28, 6),
	rrisk_adm_act_tot NUMBER (28, 6),
	rrisk_adm_peer_tot NUMBER (28, 6)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_eff_epi', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_eff_epi (
	epi_40 NUMBER (1),
	epi_50 NUMBER (1),
	epi_60 NUMBER (1),
	epi_70 NUMBER (1),
	epi_case_mix NUMBER (28, 6),
	epi_case_mix2 NUMBER (28, 6),
	epi_case_mix3 NUMBER (28, 6),
	epi_cost2_act_tot NUMBER (28, 6),
	epi_cost2_ovr_ind NUMBER (28, 6),
	epi_cost2_peer_tot NUMBER (28, 6),
	epi_cost3_act_tot NUMBER (28, 6),
	epi_cost3_ovr_ind NUMBER (28, 6),
	epi_cost3_peer_tot NUMBER (28, 6),
	epi_cost_act_tot NUMBER (28, 6),
	epi_cost_ovr_ind NUMBER (28, 6),
	epi_cost_peer_tot NUMBER (28, 6),
	epi_elig NUMBER (1),
	epi_enc_act_tot NUMBER (28, 6),
	epi_enc_ovr_ind NUMBER (28, 6),
	epi_enc_peer_tot NUMBER (28, 6),
	epi_qty NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	rank_dec_epi NUMBER (10, 0),
	rank_dec_epi2 NUMBER (10, 0),
	rank_dec_epi3 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_eff_epi_peg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_eff_epi_peg (
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peg_elig NUMBER (1),
	peg_epi_case_mix NUMBER (28, 6),
	peg_epi_case_mix2 NUMBER (28, 6),
	peg_epi_case_mix3 NUMBER (28, 6),
	peg_epi_cost2_act_tot NUMBER (28, 6),
	peg_epi_cost2_ovr_ind NUMBER (28, 6),
	peg_epi_cost2_peer_tot NUMBER (28, 6),
	peg_epi_cost3_act_tot NUMBER (28, 6),
	peg_epi_cost3_ovr_ind NUMBER (28, 6),
	peg_epi_cost3_peer_tot NUMBER (28, 6),
	peg_epi_cost_act_tot NUMBER (28, 6),
	peg_epi_cost_ovr_ind NUMBER (28, 6),
	peg_epi_cost_peer_tot NUMBER (28, 6),
	peg_epi_enc_act_tot NUMBER (28, 6),
	peg_epi_enc_ovr_ind NUMBER (28, 6),
	peg_epi_enc_peer_tot NUMBER (28, 6),
	peg_epi_qty NUMBER (28, 6),
	provider_id VARCHAR2 (20 CHAR),
	rank_dec_epi2_peg NUMBER (10, 0),
	rank_dec_epi3_peg NUMBER (10, 0),
	rank_dec_epi_peg NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_eff_pop', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_eff_pop (
	ia_time NUMBER (10, 0),
	pcp_elig NUMBER (10, 0),
	pcp_members NUMBER (10, 0),
	pcp_mmos NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	pop_200 NUMBER (10, 0),
	pop_300 NUMBER (10, 0),
	pop_400 NUMBER (10, 0),
	pop_500 NUMBER (10, 0),
	pop_cost2_act_tot NUMBER (28, 6),
	pop_cost2_ovr_ind NUMBER (28, 6),
	pop_cost2_peer_tot NUMBER (28, 6),
	pop_cost3_act_tot NUMBER (28, 6),
	pop_cost3_ovr_ind NUMBER (28, 6),
	pop_cost3_peer_tot NUMBER (28, 6),
	pop_cost_act_tot NUMBER (28, 6),
	pop_cost_ovr_ind NUMBER (28, 6),
	pop_cost_peer_tot NUMBER (28, 6),
	pop_enc_act_tot NUMBER (28, 6),
	pop_enc_ovr_ind NUMBER (28, 6),
	pop_enc_peer_tot NUMBER (28, 6),
	pop_morb NUMBER (28, 6),
	pop_morb2 NUMBER (28, 6),
	pop_morb3 NUMBER (28, 6),
	provider_id VARCHAR2 (20 CHAR),
	rank_dec_pop NUMBER (10, 0),
	rank_dec_pop2 NUMBER (10, 0),
	rank_dec_pop3 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_epi_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_epi_count (
	epi_fam_10 NUMBER (1),
	epi_fam_20 NUMBER (1),
	epi_fam_30 NUMBER (1),
	epi_fam_40 NUMBER (1),
	epi_qty NUMBER (28, 6),
	family NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_epi_count_peg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_epi_count_peg (
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peg_epi_qty NUMBER (28, 6),
	peg_ppc NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_epi_det_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_epi_det_count (
	epi_fam_10 NUMBER (1),
	epi_fam_20 NUMBER (1),
	epi_fam_30 NUMBER (1),
	epi_fam_40 NUMBER (1),
	epi_qty NUMBER (28, 6),
	family NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_epi_det_count_peg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_epi_det_count_peg (
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peg_epi_qty NUMBER (28, 6),
	peg_ppc NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_peer_def', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_peer_def (
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_pop_det_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_pop_det_count (
	ia_time NUMBER (10, 0),
	pcp_members NUMBER (10, 0),
	pcp_mmos NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	pop_200 NUMBER (10, 0),
	pop_300 NUMBER (10, 0),
	pop_400 NUMBER (10, 0),
	pop_500 NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_qual_ebm', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_qual_ebm (
	ebm_100 NUMBER (1),
	ebm_200 NUMBER (1),
	ebm_300 NUMBER (1),
	ebm_400 NUMBER (1),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	qual_ebm_den NUMBER (10, 0),
	qual_ebm_num NUMBER (10, 0),
	qual_elig NUMBER (1),
	qual_ovr_ind NUMBER (28, 6),
	qual_peer_ebm_num NUMBER (28, 6),
	rank_dec_qual NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_prov_qual_rule', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_prov_qual_rule (
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	event_id NUMBER (10, 0),
	mem_case_rule VARCHAR2 (100 CHAR),
	member VARCHAR2 (32 CHAR),
	pcp_imp_flag NUMBER (1),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	result_flag NUMBER (10, 0),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_provider_multi_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_provider_multi_spec (
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_provider_status_span', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_provider_status_span (
	map_srce_p VARCHAR2 (6 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	status_begin TIMESTAMP,
	status_end TIMESTAMP,
	update_date TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_provinfo', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_provinfo (
	address VARCHAR2 (100 CHAR),
	affil_id VARCHAR2 (40 CHAR),
	cust_prv_1 VARCHAR2 (255 CHAR),
	cust_prv_10 VARCHAR2 (255 CHAR),
	cust_prv_11 VARCHAR2 (255 CHAR),
	cust_prv_12 VARCHAR2 (255 CHAR),
	cust_prv_13 VARCHAR2 (255 CHAR),
	cust_prv_14 VARCHAR2 (255 CHAR),
	cust_prv_15 VARCHAR2 (255 CHAR),
	cust_prv_16 NUMBER (38, 10),
	cust_prv_17 NUMBER (38, 10),
	cust_prv_18 NUMBER (38, 10),
	cust_prv_19 NUMBER (38, 10),
	cust_prv_2 VARCHAR2 (255 CHAR),
	cust_prv_20 NUMBER (38, 10),
	cust_prv_3 VARCHAR2 (255 CHAR),
	cust_prv_4 VARCHAR2 (255 CHAR),
	cust_prv_5 VARCHAR2 (255 CHAR),
	cust_prv_6 VARCHAR2 (255 CHAR),
	cust_prv_7 VARCHAR2 (255 CHAR),
	cust_prv_8 VARCHAR2 (255 CHAR),
	cust_prv_9 VARCHAR2 (255 CHAR),
	map_srce_p VARCHAR2 (6 CHAR),
	pcp_indicator NUMBER (1),
	prov_city VARCHAR2 (50 CHAR),
	prov_email VARCHAR2 (50 CHAR),
	prov_first_name VARCHAR2 (50 CHAR),
	prov_geo_lat NUMBER (9, 6),
	prov_geo_lon NUMBER (9, 6),
	prov_last_name VARCHAR2 (50 CHAR),
	prov_phone VARCHAR2 (15 CHAR),
	prov_userdef_1 VARCHAR2 (100 CHAR),
	prov_userdef_2_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_name VARCHAR2 (50 CHAR),
	prv_sp_4 NUMBER (10, 0),
	prv_sp_n VARCHAR2 (30 CHAR),
	sec_provider_id VARCHAR2 (20 CHAR),
	sec_provider_id_2 VARCHAR2 (20 CHAR),
	state_n VARCHAR2 (2 CHAR),
	zip VARCHAR2 (5 CHAR),
	zip_n VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ps_patsat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ps_patsat (
	provider_id VARCHAR2 (20 CHAR),
	quest_id VARCHAR2 (5 CHAR),
	quest_resp NUMBER (10, 0),
	quest_result NUMBER (19, 2),
	survey_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ps_results', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ps_results (
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	quest_id VARCHAR2 (5 CHAR),
	quest_resp NUMBER (10, 0),
	quest_resp_peer NUMBER (10, 0),
	quest_result NUMBER (19, 2),
	quest_result_peer NUMBER (19, 2),
	survey_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_cm_disprev', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_cm_disprev (
	act_last NUMBER (1),
	admit_ifac NUMBER (10, 0),
	admit_ifac_disr NUMBER (10, 0),
	arisk NUMBER (19, 4),
	cost1 NUMBER (19, 2),
	cost1_acute NUMBER (19, 2),
	cost1_anc NUMBER (19, 2),
	cost1_chronic NUMBER (19, 2),
	cost1_ifac NUMBER (19, 2),
	cost1_ofac NUMBER (19, 2),
	cost1_phm NUMBER (19, 2),
	cost1_prof NUMBER (19, 2),
	cost1_well NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost2_acute NUMBER (19, 2),
	cost2_anc NUMBER (19, 2),
	cost2_chronic NUMBER (19, 2),
	cost2_ifac NUMBER (19, 2),
	cost2_ofac NUMBER (19, 2),
	cost2_phm NUMBER (19, 2),
	cost2_prof NUMBER (19, 2),
	cost2_well NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_acute NUMBER (19, 2),
	cost3_anc NUMBER (19, 2),
	cost3_anc_disr NUMBER (19, 2),
	cost3_chronic NUMBER (19, 2),
	cost3_disr NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_ifac_disr NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_ofac_disr NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	cost3_phm_disr NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	cost3_prof_disr NUMBER (19, 2),
	cost3_well NUMBER (19, 2),
	disease_id NUMBER (10, 0),
	encounter NUMBER (19, 2),
	encounter_acute NUMBER (19, 2),
	encounter_anc NUMBER (19, 2),
	encounter_chronic NUMBER (19, 2),
	encounter_ifac NUMBER (19, 2),
	encounter_ofac NUMBER (19, 2),
	encounter_phm NUMBER (19, 2),
	encounter_prof NUMBER (19, 2),
	encounter_well NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	los_ifac NUMBER (10, 0),
	los_ifac_disr NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mems NUMBER (10, 0),
	mm NUMBER (19, 2),
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	prisk NUMBER (19, 4),
	prisk_cat NUMBER (10, 0),
	ptl_yr_enr NUMBER (1),
	rrisk_cat NUMBER (10, 0),
	wrrisk NUMBER (19, 4)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_conf', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_conf (
	account_id VARCHAR2 (40 CHAR),
	admit_source VARCHAR2 (1 CHAR),
	age NUMBER (10, 0),
	amt_req NUMBER (19, 2),
	avoidable_admit_flag NUMBER (10, 0),
	beg_dt TIMESTAMP,
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	clm_exclude NUMBER (10, 0),
	conf_num NUMBER (19, 0),
	contract_id VARCHAR2 (40 CHAR),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	disrel NUMBER (10, 0),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_desc VARCHAR2 (200 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	end_dt TIMESTAMP,
	episode_id NUMBER (19, 0),
	er_conf NUMBER (1),
	etg_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	icd_version NUMBER (10, 0),
	iproc1 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	los NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1),
	pac_rsnf_index NUMBER (1),
	pac_rsnf_postconf NUMBER (19, 0),
	pac_rsnf_preconf NUMBER (19, 0),
	pac_rsnf_readm_days NUMBER (10, 0),
	pac_rsnf_readmit NUMBER (1),
	pay_dt TIMESTAMP,
	pdi NUMBER (10, 0),
	planned_adm NUMBER (1),
	poa1 VARCHAR2 (1 CHAR),
	pos_i NUMBER (10, 0),
	pqi NUMBER (10, 0),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	readmit_07 NUMBER (1),
	readmit_30 NUMBER (1),
	readmit_60 NUMBER (1),
	readmit_90 NUMBER (1),
	readmit_conf_07 NUMBER (19, 0),
	readmit_conf_30 NUMBER (19, 0),
	readmit_conf_60 NUMBER (19, 0),
	readmit_conf_90 NUMBER (19, 0),
	readmit_index_07 NUMBER (1),
	readmit_index_30 NUMBER (1),
	readmit_index_60 NUMBER (1),
	readmit_index_90 NUMBER (1),
	sev_level NUMBER (10, 0),
	sex NUMBER (1),
	tos_i_5 NUMBER (10, 0),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_claims_dist', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_claims_dist (
	cost3_anc NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_medtot NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_epi_family', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_epi_family (
	cost1 NUMBER (19, 2),
	cost1_anc NUMBER (19, 2),
	cost1_ifac NUMBER (19, 2),
	cost1_ofac NUMBER (19, 2),
	cost1_phm NUMBER (19, 2),
	cost1_prof NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost2_anc NUMBER (19, 2),
	cost2_ifac NUMBER (19, 2),
	cost2_ofac NUMBER (19, 2),
	cost2_phm NUMBER (19, 2),
	cost2_prof NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_anc NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	epi_qty NUMBER (19, 2),
	family NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_fac', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_fac (
	cost3 NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	los NUMBER (19, 2),
	mem_attr_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	tos1_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_phm', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_phm (
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	brand_name VARCHAR2 (50 CHAR),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_form NUMBER (19, 2),
	cost3_gen NUMBER (19, 2),
	cost3_mail NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	days_sup NUMBER (10, 0),
	encounter NUMBER (19, 2),
	generic NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	rrisk NUMBER (19, 4),
	script NUMBER (10, 0),
	script_form NUMBER (10, 0),
	script_gen NUMBER (10, 0),
	script_mail NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	tos3_id NUMBER (10, 0),
	tos4_id NUMBER (10, 0),
	tos5_id NUMBER (10, 0),
	tos_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_phm_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_phm_summary (
	amt_liab NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_form NUMBER (19, 2),
	cost3_gen NUMBER (19, 2),
	cost3_mail NUMBER (19, 2),
	encounter NUMBER (19, 2),
	encounter_form NUMBER (19, 2),
	encounter_gen NUMBER (19, 2),
	encounter_mail NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	peer_amt_liab_pmpm NUMBER (28, 6),
	peer_amt_req_pmpm NUMBER (28, 6),
	peer_cost3_form_pmpm NUMBER (28, 6),
	peer_cost3_gen_pmpm NUMBER (28, 6),
	peer_cost3_mail_pmpm NUMBER (28, 6),
	peer_cost3_pmpm NUMBER (28, 6),
	peer_encounter_form_pmpm NUMBER (28, 6),
	peer_encounter_gen_pmpm NUMBER (28, 6),
	peer_encounter_mail_pmpm NUMBER (28, 6),
	peer_encounter_pmpm NUMBER (28, 6)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_prov (
	cost3 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_qual (
	all_ebm_num NUMBER (28, 6),
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	ebm_numx NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_risk', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_risk (
	cost3 NUMBER (19, 2),
	cost3_anc NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	rrisk_cat NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_spec (
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	rrisk NUMBER (19, 4),
	sp1_id NUMBER (10, 0),
	sp2_id NUMBER (10, 0),
	sp3_id NUMBER (10, 0),
	sp4_id NUMBER (10, 0),
	spec_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_tos (
	age_tot NUMBER (10, 0),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_medtot NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	encounter_ifac NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	los_ifac NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	network_status NUMBER (1),
	premium_tot NUMBER (19, 2),
	rrisk NUMBER (19, 4),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	tos3_id NUMBER (10, 0),
	tos_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_emp_trend', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_emp_trend (
	amt_eqv_adj_q1 NUMBER (19, 2),
	amt_eqv_adj_q2 NUMBER (19, 2),
	amt_eqv_adj_q3 NUMBER (19, 2),
	amt_eqv_adj_q4 NUMBER (19, 2),
	amt_eqv_adj_q5 NUMBER (19, 2),
	amt_eqv_adj_q6 NUMBER (19, 2),
	amt_eqv_adj_q7 NUMBER (19, 2),
	amt_eqv_adj_q8 NUMBER (19, 2),
	amt_eqv_adj_t NUMBER (19, 2),
	amt_eqv_adj_y1 NUMBER (19, 2),
	amt_eqv_adj_y2 NUMBER (19, 2),
	amt_pay_adj_q1 NUMBER (19, 2),
	amt_pay_adj_q2 NUMBER (19, 2),
	amt_pay_adj_q3 NUMBER (19, 2),
	amt_pay_adj_q4 NUMBER (19, 2),
	amt_pay_adj_q5 NUMBER (19, 2),
	amt_pay_adj_q6 NUMBER (19, 2),
	amt_pay_adj_q7 NUMBER (19, 2),
	amt_pay_adj_q8 NUMBER (19, 2),
	amt_pay_adj_t NUMBER (19, 2),
	amt_pay_adj_y1 NUMBER (19, 2),
	amt_pay_adj_y2 NUMBER (19, 2),
	cost1_q1 NUMBER (19, 2),
	cost1_q2 NUMBER (19, 2),
	cost1_q3 NUMBER (19, 2),
	cost1_q4 NUMBER (19, 2),
	cost1_q5 NUMBER (19, 2),
	cost1_q6 NUMBER (19, 2),
	cost1_q7 NUMBER (19, 2),
	cost1_q8 NUMBER (19, 2),
	cost1_t NUMBER (19, 2),
	cost1_y1 NUMBER (19, 2),
	cost1_y2 NUMBER (19, 2),
	cost2_q1 NUMBER (19, 2),
	cost2_q2 NUMBER (19, 2),
	cost2_q3 NUMBER (19, 2),
	cost2_q4 NUMBER (19, 2),
	cost2_q5 NUMBER (19, 2),
	cost2_q6 NUMBER (19, 2),
	cost2_q7 NUMBER (19, 2),
	cost2_q8 NUMBER (19, 2),
	cost2_t NUMBER (19, 2),
	cost2_y1 NUMBER (19, 2),
	cost2_y2 NUMBER (19, 2),
	cost3_q1 NUMBER (19, 2),
	cost3_q2 NUMBER (19, 2),
	cost3_q3 NUMBER (19, 2),
	cost3_q4 NUMBER (19, 2),
	cost3_q5 NUMBER (19, 2),
	cost3_q6 NUMBER (19, 2),
	cost3_q7 NUMBER (19, 2),
	cost3_q8 NUMBER (19, 2),
	cost3_t NUMBER (19, 2),
	cost3_y1 NUMBER (19, 2),
	cost3_y2 NUMBER (19, 2),
	cost4_q1 NUMBER (19, 2),
	cost4_q2 NUMBER (19, 2),
	cost4_q3 NUMBER (19, 2),
	cost4_q4 NUMBER (19, 2),
	cost4_q5 NUMBER (19, 2),
	cost4_q6 NUMBER (19, 2),
	cost4_q7 NUMBER (19, 2),
	cost4_q8 NUMBER (19, 2),
	cost4_t NUMBER (19, 2),
	cost4_y1 NUMBER (19, 2),
	cost4_y2 NUMBER (19, 2),
	cost5_q1 NUMBER (19, 2),
	cost5_q2 NUMBER (19, 2),
	cost5_q3 NUMBER (19, 2),
	cost5_q4 NUMBER (19, 2),
	cost5_q5 NUMBER (19, 2),
	cost5_q6 NUMBER (19, 2),
	cost5_q7 NUMBER (19, 2),
	cost5_q8 NUMBER (19, 2),
	cost5_t NUMBER (19, 2),
	cost5_y1 NUMBER (19, 2),
	cost5_y2 NUMBER (19, 2),
	cost6_q1 NUMBER (19, 2),
	cost6_q2 NUMBER (19, 2),
	cost6_q3 NUMBER (19, 2),
	cost6_q4 NUMBER (19, 2),
	cost6_q5 NUMBER (19, 2),
	cost6_q6 NUMBER (19, 2),
	cost6_q7 NUMBER (19, 2),
	cost6_q8 NUMBER (19, 2),
	cost6_t NUMBER (19, 2),
	cost6_y1 NUMBER (19, 2),
	cost6_y2 NUMBER (19, 2),
	encounter_q1 NUMBER (19, 2),
	encounter_q2 NUMBER (19, 2),
	encounter_q3 NUMBER (19, 2),
	encounter_q4 NUMBER (19, 2),
	encounter_q5 NUMBER (19, 2),
	encounter_q6 NUMBER (19, 2),
	encounter_q7 NUMBER (19, 2),
	encounter_q8 NUMBER (19, 2),
	encounter_t NUMBER (19, 2),
	encounter_y1 NUMBER (19, 2),
	encounter_y2 NUMBER (19, 2),
	mem_attr_id NUMBER (10, 0),
	mm_q1 NUMBER (19, 2),
	mm_q2 NUMBER (19, 2),
	mm_q3 NUMBER (19, 2),
	mm_q4 NUMBER (19, 2),
	mm_q5 NUMBER (19, 2),
	mm_q6 NUMBER (19, 2),
	mm_q7 NUMBER (19, 2),
	mm_q8 NUMBER (19, 2),
	mm_t NUMBER (19, 2),
	mm_y1 NUMBER (19, 2),
	mm_y2 NUMBER (19, 2),
	rrisk_q1 NUMBER (19, 4),
	rrisk_q2 NUMBER (19, 4),
	rrisk_q3 NUMBER (19, 4),
	rrisk_q4 NUMBER (19, 4),
	rrisk_q5 NUMBER (19, 4),
	rrisk_q6 NUMBER (19, 4),
	rrisk_q7 NUMBER (19, 4),
	rrisk_q8 NUMBER (19, 4),
	rrisk_t NUMBER (19, 4),
	rrisk_y1 NUMBER (19, 4),
	rrisk_y2 NUMBER (19, 4),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	tos3_id NUMBER (10, 0),
	tos_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_episodes', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_episodes (
	account_id VARCHAR2 (40 CHAR),
	age NUMBER (10, 0),
	at_risk_status_id VARCHAR2 (40 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR),
	biz_segment_id VARCHAR2 (40 CHAR),
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	contract_id VARCHAR2 (40 CHAR),
	contract_type_id VARCHAR2 (40 CHAR),
	cost1_anc NUMBER (19, 2),
	cost1_ifac NUMBER (19, 2),
	cost1_medtot NUMBER (19, 2),
	cost1_ofac NUMBER (19, 2),
	cost1_phm NUMBER (19, 2),
	cost1_prof NUMBER (19, 2),
	cost1_tot NUMBER (19, 2),
	cost2_tot NUMBER (19, 2),
	cost3_tot NUMBER (19, 2),
	coverage_status_id VARCHAR2 (40 CHAR),
	epi_duration NUMBER (19, 2),
	epi_from TIMESTAMP,
	epi_qty NUMBER (19, 2),
	epi_to TIMESTAMP,
	epi_type NUMBER (10, 0),
	episode_id NUMBER (19, 0),
	etg_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	industry NUMBER (10, 0),
	los NUMBER (10, 0),
	med_qual NUMBER (1),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	mpg_def_id NUMBER (10, 0),
	outlier NUMBER (10, 0),
	pcp_id VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	rrisk NUMBER (10, 4),
	sev_level NUMBER (10, 0),
	sex NUMBER (1),
	tx_ind NUMBER (10, 0),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_members', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_members (
	account_id VARCHAR2 (40 CHAR),
	admit NUMBER (10, 0),
	at_risk_status_id VARCHAR2 (40 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR),
	biz_segment_id VARCHAR2 (40 CHAR),
	comp_case_rule VARCHAR2 (4000 CHAR),
	contract_id VARCHAR2 (40 CHAR),
	contract_type_id VARCHAR2 (40 CHAR),
	cost1_anc NUMBER (19, 2),
	cost1_ifac NUMBER (19, 2),
	cost1_medtot NUMBER (19, 2),
	cost1_ofac NUMBER (19, 2),
	cost1_phm NUMBER (19, 2),
	cost1_prof NUMBER (19, 2),
	cost1_tot NUMBER (19, 2),
	cost2_anc NUMBER (19, 2),
	cost2_ifac NUMBER (19, 2),
	cost2_medtot NUMBER (19, 2),
	cost2_ofac NUMBER (19, 2),
	cost2_phm NUMBER (19, 2),
	cost2_prof NUMBER (19, 2),
	cost2_tot NUMBER (19, 2),
	cost3_anc NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_medtot NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	cost3_tot NUMBER (19, 2),
	cost4_anc NUMBER (19, 2),
	cost4_ifac NUMBER (19, 2),
	cost4_medtot NUMBER (19, 2),
	cost4_ofac NUMBER (19, 2),
	cost4_phm NUMBER (19, 2),
	cost4_prof NUMBER (19, 2),
	cost4_tot NUMBER (19, 2),
	cost5_anc NUMBER (19, 2),
	cost5_ifac NUMBER (19, 2),
	cost5_medtot NUMBER (19, 2),
	cost5_ofac NUMBER (19, 2),
	cost5_phm NUMBER (19, 2),
	cost5_prof NUMBER (19, 2),
	cost5_tot NUMBER (19, 2),
	cost6_anc NUMBER (19, 2),
	cost6_ifac NUMBER (19, 2),
	cost6_medtot NUMBER (19, 2),
	cost6_ofac NUMBER (19, 2),
	cost6_phm NUMBER (19, 2),
	cost6_prof NUMBER (19, 2),
	cost6_tot NUMBER (19, 2),
	coverage_status_id VARCHAR2 (40 CHAR),
	ebm_den_tot NUMBER (10, 0),
	ebm_num_tot NUMBER (10, 0),
	ebm_rate_tot NUMBER (19, 2),
	em_svc_flag NUMBER (10, 0),
	encounter_anc NUMBER (19, 2),
	encounter_ofac NUMBER (19, 2),
	encounter_prof NUMBER (19, 2),
	encounter_tot NUMBER (19, 2),
	er_util NUMBER (19, 2),
	first_name VARCHAR2 (50 CHAR),
	full_name VARCHAR2 (100 CHAR),
	ia_time NUMBER (10, 0),
	industry NUMBER (10, 0),
	lab_util NUMBER (19, 2),
	last_active_dt TIMESTAMP,
	last_name VARCHAR2 (50 CHAR),
	los NUMBER (10, 0),
	mem_ia_time_code VARCHAR2 (50 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	mpg_def_id NUMBER (10, 0),
	mri_util NUMBER (19, 2),
	ncomp_case_rule VARCHAR2 (4000 CHAR),
	num_claims NUMBER (10, 0),
	num_episodes NUMBER (10, 0),
	pcp_id VARCHAR2 (20 CHAR),
	product_id VARCHAR2 (40 CHAR),
	rad_util NUMBER (19, 2),
	script NUMBER (10, 0),
	sex NUMBER (1),
	subscriber_id VARCHAR2 (32 CHAR),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_adm_fac', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_adm_fac (
	adm_year_mth_id NUMBER (10, 0),
	admit NUMBER (10, 0),
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	etg_id NUMBER (10, 0),
	los NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	qoaf_id NUMBER (19, 0),
	readmit_07 NUMBER (10, 0),
	readmit_30 NUMBER (10, 0),
	readmit_60 NUMBER (10, 0),
	readmit_90 NUMBER (10, 0),
	readmit_index_07 NUMBER (10, 0),
	readmit_index_30 NUMBER (10, 0),
	readmit_index_60 NUMBER (10, 0),
	readmit_index_90 NUMBER (10, 0),
	rrisk NUMBER (12, 4),
	sev_level NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_epi_agg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_epi_agg (
	admit NUMBER (10, 0),
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	complete NUMBER (1),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	em_svc_flag NUMBER (10, 0),
	encounter NUMBER (19, 2),
	epi_qty NUMBER (19, 2),
	er_util NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	lab_util NUMBER (19, 2),
	los NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mri_util NUMBER (19, 2),
	outlier NUMBER (10, 0),
	qoea_id NUMBER (19, 0),
	rad_util NUMBER (19, 2),
	rrisk NUMBER (12, 4),
	script NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_epi_phm', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_epi_phm (
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	complete NUMBER (1),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	days_sup NUMBER (10, 0),
	epi_qty NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	generic NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	outlier NUMBER (10, 0),
	rrisk NUMBER (12, 4),
	script NUMBER (10, 0),
	script_gen NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	tos3_id NUMBER (10, 0),
	tos4_id NUMBER (10, 0),
	tos5_id NUMBER (10, 0),
	tos_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_epi_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_epi_spec (
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	complete NUMBER (1),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	epi_qty NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	outlier NUMBER (10, 0),
	rrisk NUMBER (12, 4),
	sev_level NUMBER (10, 0),
	sp1_id NUMBER (10, 0),
	sp2_id NUMBER (10, 0),
	sp3_id NUMBER (10, 0),
	sp4_id NUMBER (10, 0),
	spec_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_epi_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_epi_tos (
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	complete NUMBER (1),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	epi_qty NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	outlier NUMBER (10, 0),
	rrisk NUMBER (12, 4),
	sev_level NUMBER (10, 0),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	tos3_id NUMBER (10, 0),
	tos_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_pop_agg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_pop_agg (
	admit NUMBER (10, 0),
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	em_svc_flag NUMBER (10, 0),
	encounter NUMBER (19, 2),
	er_util NUMBER (19, 2),
	lab_util NUMBER (19, 2),
	los NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	mri_util NUMBER (19, 2),
	qopa_id NUMBER (19, 0),
	rad_util NUMBER (19, 2),
	rrisk NUMBER (12, 4),
	script NUMBER (10, 0),
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_pop_phm', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_pop_phm (
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	brand_name VARCHAR2 (50 CHAR),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_form NUMBER (19, 2),
	cost3_gen NUMBER (19, 2),
	cost3_mail NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	days_sup NUMBER (10, 0),
	encounter NUMBER (19, 2),
	generic NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	rrisk NUMBER (12, 4),
	script NUMBER (10, 0),
	script_form NUMBER (10, 0),
	script_gen NUMBER (10, 0),
	script_mail NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	tos3_id NUMBER (10, 0),
	tos4_id NUMBER (10, 0),
	tos5_id NUMBER (10, 0),
	tos_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_pop_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_pop_spec (
	amt_eqv_adj NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	rrisk NUMBER (12, 4),
	sp1_id NUMBER (10, 0),
	sp2_id NUMBER (10, 0),
	sp3_id NUMBER (10, 0),
	sp4_id NUMBER (10, 0),
	spec_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_pop_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_pop_tos (
	age_tot NUMBER (10, 0),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_eqv_adj NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_pay_adj NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	cost1 NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_medtot NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	encounter NUMBER (19, 2),
	encounter_ifac NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	los_ifac NUMBER (10, 0),
	mem_attr_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	network_status NUMBER (1),
	premium_tot NUMBER (19, 2),
	rrisk NUMBER (12, 4),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	tos3_id NUMBER (10, 0),
	tos_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_ocu_trend', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_ocu_trend (
	amt_eqv_adj_q1 NUMBER (19, 2),
	amt_eqv_adj_q2 NUMBER (19, 2),
	amt_eqv_adj_q3 NUMBER (19, 2),
	amt_eqv_adj_q4 NUMBER (19, 2),
	amt_eqv_adj_q5 NUMBER (19, 2),
	amt_eqv_adj_q6 NUMBER (19, 2),
	amt_eqv_adj_q7 NUMBER (19, 2),
	amt_eqv_adj_q8 NUMBER (19, 2),
	amt_eqv_adj_t NUMBER (19, 2),
	amt_eqv_adj_y1 NUMBER (19, 2),
	amt_eqv_adj_y2 NUMBER (19, 2),
	amt_pay_adj_q1 NUMBER (19, 2),
	amt_pay_adj_q2 NUMBER (19, 2),
	amt_pay_adj_q3 NUMBER (19, 2),
	amt_pay_adj_q4 NUMBER (19, 2),
	amt_pay_adj_q5 NUMBER (19, 2),
	amt_pay_adj_q6 NUMBER (19, 2),
	amt_pay_adj_q7 NUMBER (19, 2),
	amt_pay_adj_q8 NUMBER (19, 2),
	amt_pay_adj_t NUMBER (19, 2),
	amt_pay_adj_y1 NUMBER (19, 2),
	amt_pay_adj_y2 NUMBER (19, 2),
	cost1_q1 NUMBER (19, 2),
	cost1_q2 NUMBER (19, 2),
	cost1_q3 NUMBER (19, 2),
	cost1_q4 NUMBER (19, 2),
	cost1_q5 NUMBER (19, 2),
	cost1_q6 NUMBER (19, 2),
	cost1_q7 NUMBER (19, 2),
	cost1_q8 NUMBER (19, 2),
	cost1_t NUMBER (19, 2),
	cost1_y1 NUMBER (19, 2),
	cost1_y2 NUMBER (19, 2),
	cost2_q1 NUMBER (19, 2),
	cost2_q2 NUMBER (19, 2),
	cost2_q3 NUMBER (19, 2),
	cost2_q4 NUMBER (19, 2),
	cost2_q5 NUMBER (19, 2),
	cost2_q6 NUMBER (19, 2),
	cost2_q7 NUMBER (19, 2),
	cost2_q8 NUMBER (19, 2),
	cost2_t NUMBER (19, 2),
	cost2_y1 NUMBER (19, 2),
	cost2_y2 NUMBER (19, 2),
	cost3_q1 NUMBER (19, 2),
	cost3_q2 NUMBER (19, 2),
	cost3_q3 NUMBER (19, 2),
	cost3_q4 NUMBER (19, 2),
	cost3_q5 NUMBER (19, 2),
	cost3_q6 NUMBER (19, 2),
	cost3_q7 NUMBER (19, 2),
	cost3_q8 NUMBER (19, 2),
	cost3_t NUMBER (19, 2),
	cost3_y1 NUMBER (19, 2),
	cost3_y2 NUMBER (19, 2),
	cost4_q1 NUMBER (19, 2),
	cost4_q2 NUMBER (19, 2),
	cost4_q3 NUMBER (19, 2),
	cost4_q4 NUMBER (19, 2),
	cost4_q5 NUMBER (19, 2),
	cost4_q6 NUMBER (19, 2),
	cost4_q7 NUMBER (19, 2),
	cost4_q8 NUMBER (19, 2),
	cost4_t NUMBER (19, 2),
	cost4_y1 NUMBER (19, 2),
	cost4_y2 NUMBER (19, 2),
	cost5_q1 NUMBER (19, 2),
	cost5_q2 NUMBER (19, 2),
	cost5_q3 NUMBER (19, 2),
	cost5_q4 NUMBER (19, 2),
	cost5_q5 NUMBER (19, 2),
	cost5_q6 NUMBER (19, 2),
	cost5_q7 NUMBER (19, 2),
	cost5_q8 NUMBER (19, 2),
	cost5_t NUMBER (19, 2),
	cost5_y1 NUMBER (19, 2),
	cost5_y2 NUMBER (19, 2),
	cost6_q1 NUMBER (19, 2),
	cost6_q2 NUMBER (19, 2),
	cost6_q3 NUMBER (19, 2),
	cost6_q4 NUMBER (19, 2),
	cost6_q5 NUMBER (19, 2),
	cost6_q6 NUMBER (19, 2),
	cost6_q7 NUMBER (19, 2),
	cost6_q8 NUMBER (19, 2),
	cost6_t NUMBER (19, 2),
	cost6_y1 NUMBER (19, 2),
	cost6_y2 NUMBER (19, 2),
	encounter_q1 NUMBER (19, 2),
	encounter_q2 NUMBER (19, 2),
	encounter_q3 NUMBER (19, 2),
	encounter_q4 NUMBER (19, 2),
	encounter_q5 NUMBER (19, 2),
	encounter_q6 NUMBER (19, 2),
	encounter_q7 NUMBER (19, 2),
	encounter_q8 NUMBER (19, 2),
	encounter_t NUMBER (19, 2),
	encounter_y1 NUMBER (19, 2),
	encounter_y2 NUMBER (19, 2),
	mem_attr_id NUMBER (10, 0),
	mm_q1 NUMBER (19, 2),
	mm_q2 NUMBER (19, 2),
	mm_q3 NUMBER (19, 2),
	mm_q4 NUMBER (19, 2),
	mm_q5 NUMBER (19, 2),
	mm_q6 NUMBER (19, 2),
	mm_q7 NUMBER (19, 2),
	mm_q8 NUMBER (19, 2),
	mm_t NUMBER (19, 2),
	mm_y1 NUMBER (19, 2),
	mm_y2 NUMBER (19, 2),
	rrisk_q1 NUMBER (19, 4),
	rrisk_q2 NUMBER (19, 4),
	rrisk_q3 NUMBER (19, 4),
	rrisk_q4 NUMBER (19, 4),
	rrisk_q5 NUMBER (19, 4),
	rrisk_q6 NUMBER (19, 4),
	rrisk_q7 NUMBER (19, 4),
	rrisk_q8 NUMBER (19, 4),
	rrisk_t NUMBER (19, 4),
	rrisk_y1 NUMBER (19, 4),
	rrisk_y2 NUMBER (19, 4),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	tos3_id NUMBER (10, 0),
	tos_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov (
	affil_id VARCHAR2 (40 CHAR),
	cens_division NUMBER (10, 0),
	cens_division_desc VARCHAR2 (30 CHAR),
	cens_reg NUMBER (10, 0),
	cens_reg_desc VARCHAR2 (30 CHAR),
	ci_ebm_den NUMBER (28, 6),
	ci_ebm_num NUMBER (28, 6),
	ci_epi_val NUMBER (4, 3),
	ci_peer_ebm_num NUMBER (28, 6),
	ci_pop_val NUMBER (4, 3),
	ci_qual_sum_odd NUMBER (28, 6),
	ci_qual_val NUMBER (4, 3),
	ci_qual_wgt_var_odd NUMBER (28, 6),
	county_desc VARCHAR2 (40 CHAR),
	county_id NUMBER (10, 0),
	epi_case_mix NUMBER (19, 2),
	epi_cost2_act_tot NUMBER (19, 2),
	epi_cost2_ind NUMBER (19, 2),
	epi_cost2_ovr_ind NUMBER (19, 2),
	epi_cost2_peer_tot NUMBER (19, 2),
	epi_cost3_act_tot NUMBER (19, 2),
	epi_cost3_ind NUMBER (19, 2),
	epi_cost3_ovr_ind NUMBER (19, 2),
	epi_cost3_peer_tot NUMBER (19, 2),
	epi_cost_act_tot NUMBER (19, 2),
	epi_cost_ind NUMBER (19, 2),
	epi_cost_ovr_ind NUMBER (19, 2),
	epi_cost_peer_tot NUMBER (19, 2),
	epi_elig NUMBER (10, 0),
	epi_enc_act_tot NUMBER (19, 2),
	epi_enc_ind NUMBER (19, 2),
	epi_enc_ovr_ind NUMBER (19, 2),
	epi_enc_peer_tot NUMBER (19, 2),
	epi_er_cost2_act_tot_0 NUMBER (28, 6),
	epi_er_cost2_act_tot_1 NUMBER (28, 6),
	epi_er_cost2_act_tot_var NUMBER (28, 6),
	epi_er_cost2_peer_tot_0 NUMBER (28, 6),
	epi_er_cost2_peer_tot_1 NUMBER (28, 6),
	epi_er_cost3_act_tot_0 NUMBER (28, 6),
	epi_er_cost3_act_tot_1 NUMBER (28, 6),
	epi_er_cost3_act_tot_var NUMBER (28, 6),
	epi_er_cost3_peer_tot_0 NUMBER (28, 6),
	epi_er_cost3_peer_tot_1 NUMBER (28, 6),
	epi_er_cost_act_tot_0 NUMBER (28, 6),
	epi_er_cost_act_tot_1 NUMBER (28, 6),
	epi_er_cost_act_tot_var NUMBER (28, 6),
	epi_er_cost_peer_tot_0 NUMBER (28, 6),
	epi_er_cost_peer_tot_1 NUMBER (28, 6),
	epi_er_enc_act_tot_0 NUMBER (28, 6),
	epi_er_enc_act_tot_1 NUMBER (28, 6),
	epi_er_enc_peer_tot_0 NUMBER (28, 6),
	epi_er_enc_peer_tot_1 NUMBER (28, 6),
	epi_er_pct_0 NUMBER (7, 4),
	epi_er_pct_1 NUMBER (7, 4),
	epi_hosp_cost2_act_tot_0 NUMBER (28, 6),
	epi_hosp_cost2_act_tot_1 NUMBER (28, 6),
	epi_hosp_cost2_act_tot_var NUMBER (28, 6),
	epi_hosp_cost2_peer_tot_0 NUMBER (28, 6),
	epi_hosp_cost2_peer_tot_1 NUMBER (28, 6),
	epi_hosp_cost3_act_tot_0 NUMBER (28, 6),
	epi_hosp_cost3_act_tot_1 NUMBER (28, 6),
	epi_hosp_cost3_act_tot_var NUMBER (28, 6),
	epi_hosp_cost3_peer_tot_0 NUMBER (28, 6),
	epi_hosp_cost3_peer_tot_1 NUMBER (28, 6),
	epi_hosp_cost_act_tot_0 NUMBER (28, 6),
	epi_hosp_cost_act_tot_1 NUMBER (28, 6),
	epi_hosp_cost_act_tot_var NUMBER (28, 6),
	epi_hosp_cost_peer_tot_0 NUMBER (28, 6),
	epi_hosp_cost_peer_tot_1 NUMBER (28, 6),
	epi_hosp_enc_act_tot_0 NUMBER (28, 6),
	epi_hosp_enc_act_tot_1 NUMBER (28, 6),
	epi_hosp_enc_peer_tot_0 NUMBER (28, 6),
	epi_hosp_enc_peer_tot_1 NUMBER (28, 6),
	epi_hosp_pct_0 NUMBER (7, 4),
	epi_hosp_pct_1 NUMBER (7, 4),
	epi_lab_cost2_act_tot_0 NUMBER (28, 6),
	epi_lab_cost2_act_tot_1 NUMBER (28, 6),
	epi_lab_cost2_act_tot_var NUMBER (28, 6),
	epi_lab_cost2_peer_tot_0 NUMBER (28, 6),
	epi_lab_cost2_peer_tot_1 NUMBER (28, 6),
	epi_lab_cost3_act_tot_0 NUMBER (28, 6),
	epi_lab_cost3_act_tot_1 NUMBER (28, 6),
	epi_lab_cost3_act_tot_var NUMBER (28, 6),
	epi_lab_cost3_peer_tot_0 NUMBER (28, 6),
	epi_lab_cost3_peer_tot_1 NUMBER (28, 6),
	epi_lab_cost_act_tot_0 NUMBER (28, 6),
	epi_lab_cost_act_tot_1 NUMBER (28, 6),
	epi_lab_cost_act_tot_var NUMBER (28, 6),
	epi_lab_cost_peer_tot_0 NUMBER (28, 6),
	epi_lab_cost_peer_tot_1 NUMBER (28, 6),
	epi_lab_enc_act_tot_0 NUMBER (28, 6),
	epi_lab_enc_act_tot_1 NUMBER (28, 6),
	epi_lab_enc_peer_tot_0 NUMBER (28, 6),
	epi_lab_enc_peer_tot_1 NUMBER (28, 6),
	epi_lab_pct_0 NUMBER (7, 4),
	epi_lab_pct_1 NUMBER (7, 4),
	epi_pcc_cost2_act_tot_0 NUMBER (28, 6),
	epi_pcc_cost2_act_tot_1 NUMBER (28, 6),
	epi_pcc_cost2_act_tot_var NUMBER (28, 6),
	epi_pcc_cost2_peer_tot_0 NUMBER (28, 6),
	epi_pcc_cost2_peer_tot_1 NUMBER (28, 6),
	epi_pcc_cost3_act_tot_0 NUMBER (28, 6),
	epi_pcc_cost3_act_tot_1 NUMBER (28, 6),
	epi_pcc_cost3_act_tot_var NUMBER (28, 6),
	epi_pcc_cost3_peer_tot_0 NUMBER (28, 6),
	epi_pcc_cost3_peer_tot_1 NUMBER (28, 6),
	epi_pcc_cost_act_tot_0 NUMBER (28, 6),
	epi_pcc_cost_act_tot_1 NUMBER (28, 6),
	epi_pcc_cost_act_tot_var NUMBER (28, 6),
	epi_pcc_cost_peer_tot_0 NUMBER (28, 6),
	epi_pcc_cost_peer_tot_1 NUMBER (28, 6),
	epi_pcc_enc_act_tot_0 NUMBER (28, 6),
	epi_pcc_enc_act_tot_1 NUMBER (28, 6),
	epi_pcc_enc_peer_tot_0 NUMBER (28, 6),
	epi_pcc_enc_peer_tot_1 NUMBER (28, 6),
	epi_pcc_pct_0 NUMBER (7, 4),
	epi_pcc_pct_1 NUMBER (7, 4),
	epi_peer_qty NUMBER (19, 2),
	epi_phm_pct_0 NUMBER (7, 4),
	epi_phm_pct_1 NUMBER (7, 4),
	epi_phm_qual_1 NUMBER (10, 0),
	epi_qty NUMBER (19, 2),
	epi_qty_0 NUMBER (28, 2),
	epi_qty_1 NUMBER (28, 2),
	epi_rad_cost2_act_tot_0 NUMBER (28, 6),
	epi_rad_cost2_act_tot_1 NUMBER (28, 6),
	epi_rad_cost2_act_tot_var NUMBER (28, 6),
	epi_rad_cost2_peer_tot_0 NUMBER (28, 6),
	epi_rad_cost2_peer_tot_1 NUMBER (28, 6),
	epi_rad_cost3_act_tot_0 NUMBER (28, 6),
	epi_rad_cost3_act_tot_1 NUMBER (28, 6),
	epi_rad_cost3_act_tot_var NUMBER (28, 6),
	epi_rad_cost3_peer_tot_0 NUMBER (28, 6),
	epi_rad_cost3_peer_tot_1 NUMBER (28, 6),
	epi_rad_cost_act_tot_0 NUMBER (28, 6),
	epi_rad_cost_act_tot_1 NUMBER (28, 6),
	epi_rad_cost_act_tot_var NUMBER (28, 6),
	epi_rad_cost_peer_tot_0 NUMBER (28, 6),
	epi_rad_cost_peer_tot_1 NUMBER (28, 6),
	epi_rad_enc_act_tot_0 NUMBER (28, 6),
	epi_rad_enc_act_tot_1 NUMBER (28, 6),
	epi_rad_enc_peer_tot_0 NUMBER (28, 6),
	epi_rad_enc_peer_tot_1 NUMBER (28, 6),
	epi_rad_pct_0 NUMBER (7, 4),
	epi_rad_pct_1 NUMBER (7, 4),
	epi_rx_cost2_act_tot_0 NUMBER (28, 6),
	epi_rx_cost2_act_tot_1 NUMBER (28, 6),
	epi_rx_cost2_act_tot_var NUMBER (28, 6),
	epi_rx_cost2_peer_tot_0 NUMBER (28, 6),
	epi_rx_cost2_peer_tot_1 NUMBER (28, 6),
	epi_rx_cost3_act_tot_0 NUMBER (28, 6),
	epi_rx_cost3_act_tot_1 NUMBER (28, 6),
	epi_rx_cost3_act_tot_var NUMBER (28, 6),
	epi_rx_cost3_peer_tot_0 NUMBER (28, 6),
	epi_rx_cost3_peer_tot_1 NUMBER (28, 6),
	epi_rx_cost_act_tot_0 NUMBER (28, 6),
	epi_rx_cost_act_tot_1 NUMBER (28, 6),
	epi_rx_cost_act_tot_var NUMBER (28, 6),
	epi_rx_cost_peer_tot_0 NUMBER (28, 6),
	epi_rx_cost_peer_tot_1 NUMBER (28, 6),
	epi_rx_enc_act_tot_0 NUMBER (28, 6),
	epi_rx_enc_act_tot_1 NUMBER (28, 6),
	epi_rx_enc_peer_tot_0 NUMBER (28, 6),
	epi_rx_enc_peer_tot_1 NUMBER (28, 6),
	epi_spec_cost2_act_tot_0 NUMBER (28, 6),
	epi_spec_cost2_act_tot_1 NUMBER (28, 6),
	epi_spec_cost2_act_tot_var NUMBER (28, 6),
	epi_spec_cost2_peer_tot_0 NUMBER (28, 6),
	epi_spec_cost2_peer_tot_1 NUMBER (28, 6),
	epi_spec_cost3_act_tot_0 NUMBER (28, 6),
	epi_spec_cost3_act_tot_1 NUMBER (28, 6),
	epi_spec_cost3_act_tot_var NUMBER (28, 6),
	epi_spec_cost3_peer_tot_0 NUMBER (28, 6),
	epi_spec_cost3_peer_tot_1 NUMBER (28, 6),
	epi_spec_cost_act_tot_0 NUMBER (28, 6),
	epi_spec_cost_act_tot_1 NUMBER (28, 6),
	epi_spec_cost_act_tot_var NUMBER (28, 6),
	epi_spec_cost_peer_tot_0 NUMBER (28, 6),
	epi_spec_cost_peer_tot_1 NUMBER (28, 6),
	epi_spec_enc_act_tot_0 NUMBER (28, 6),
	epi_spec_enc_act_tot_1 NUMBER (28, 6),
	epi_spec_enc_peer_tot_0 NUMBER (28, 6),
	epi_spec_enc_peer_tot_1 NUMBER (28, 6),
	epi_spec_pct_0 NUMBER (7, 4),
	epi_spec_pct_1 NUMBER (7, 4),
	ia_time NUMBER (10, 0),
	ia_time_code VARCHAR2 (15 CHAR),
	ia_time_date_desc VARCHAR2 (25 CHAR),
	ia_time_desc VARCHAR2 (25 CHAR),
	ia_time_end_date TIMESTAMP,
	ia_time_full_desc VARCHAR2 (55 CHAR),
	ia_time_start_date TIMESTAMP,
	pcp_elig NUMBER (10, 0),
	pcp_members NUMBER (19, 2),
	pcp_mmos NUMBER (19, 2),
	pcp_mmos_0 NUMBER (28, 6),
	pcp_mmos_1 NUMBER (28, 6),
	pcp_peer_mmos NUMBER (19, 2),
	pd_epi_cost2_peer_tot NUMBER (38, 2),
	pd_epi_cost3_peer_tot NUMBER (38, 2),
	pd_epi_cost_peer_tot NUMBER (38, 2),
	pd_pop_cost2_peer_tot NUMBER (38, 2),
	pd_pop_cost3_peer_tot NUMBER (38, 2),
	pd_pop_cost_peer_tot NUMBER (38, 2),
	peer_cat1_id NUMBER (10, 0),
	peer_cat2_desc VARCHAR2 (50 CHAR),
	peer_cat2_id NUMBER (10, 0),
	peer_def_desc VARCHAR2 (50 CHAR),
	peer_def_id NUMBER (10, 0),
	pop_cost2_act_tot NUMBER (19, 2),
	pop_cost2_ind NUMBER (19, 2),
	pop_cost2_ovr_ind NUMBER (19, 2),
	pop_cost2_peer_tot NUMBER (19, 2),
	pop_cost3_act_tot NUMBER (19, 2),
	pop_cost3_ind NUMBER (19, 2),
	pop_cost3_ovr_ind NUMBER (19, 2),
	pop_cost3_peer_tot NUMBER (19, 2),
	pop_cost_act_tot NUMBER (19, 2),
	pop_cost_ind NUMBER (19, 2),
	pop_cost_ovr_ind NUMBER (19, 2),
	pop_cost_peer_tot NUMBER (19, 2),
	pop_enc_act_tot NUMBER (19, 2),
	pop_enc_ind NUMBER (19, 2),
	pop_enc_ovr_ind NUMBER (19, 2),
	pop_enc_peer_tot NUMBER (19, 2),
	pop_er_cost2_act_tot_0 NUMBER (28, 6),
	pop_er_cost2_act_tot_1 NUMBER (28, 6),
	pop_er_cost2_act_tot_var NUMBER (28, 6),
	pop_er_cost2_peer_tot_0 NUMBER (28, 6),
	pop_er_cost2_peer_tot_1 NUMBER (28, 6),
	pop_er_cost3_act_tot_0 NUMBER (28, 6),
	pop_er_cost3_act_tot_1 NUMBER (28, 6),
	pop_er_cost3_act_tot_var NUMBER (28, 6),
	pop_er_cost3_peer_tot_0 NUMBER (28, 6),
	pop_er_cost3_peer_tot_1 NUMBER (28, 6),
	pop_er_cost_act_tot_0 NUMBER (28, 6),
	pop_er_cost_act_tot_1 NUMBER (28, 6),
	pop_er_cost_act_tot_var NUMBER (28, 6),
	pop_er_cost_peer_tot_0 NUMBER (28, 6),
	pop_er_cost_peer_tot_1 NUMBER (28, 6),
	pop_er_enc_act_tot_0 NUMBER (28, 6),
	pop_er_enc_act_tot_1 NUMBER (28, 6),
	pop_er_enc_peer_tot_0 NUMBER (28, 6),
	pop_er_enc_peer_tot_1 NUMBER (28, 6),
	pop_er_pct_0 NUMBER (7, 4),
	pop_er_pct_1 NUMBER (7, 4),
	pop_hosp_cost2_act_tot_0 NUMBER (28, 6),
	pop_hosp_cost2_act_tot_1 NUMBER (28, 6),
	pop_hosp_cost2_act_tot_var NUMBER (28, 6),
	pop_hosp_cost2_peer_tot_0 NUMBER (28, 6),
	pop_hosp_cost2_peer_tot_1 NUMBER (28, 6),
	pop_hosp_cost3_act_tot_0 NUMBER (28, 6),
	pop_hosp_cost3_act_tot_1 NUMBER (28, 6),
	pop_hosp_cost3_act_tot_var NUMBER (28, 6),
	pop_hosp_cost3_peer_tot_0 NUMBER (28, 6),
	pop_hosp_cost3_peer_tot_1 NUMBER (28, 6),
	pop_hosp_cost_act_tot_0 NUMBER (28, 6),
	pop_hosp_cost_act_tot_1 NUMBER (28, 6),
	pop_hosp_cost_act_tot_var NUMBER (28, 6),
	pop_hosp_cost_peer_tot_0 NUMBER (28, 6),
	pop_hosp_cost_peer_tot_1 NUMBER (28, 6),
	pop_hosp_enc_act_tot_0 NUMBER (28, 6),
	pop_hosp_enc_act_tot_1 NUMBER (28, 6),
	pop_hosp_enc_peer_tot_0 NUMBER (28, 6),
	pop_hosp_enc_peer_tot_1 NUMBER (28, 6),
	pop_hosp_pct_0 NUMBER (7, 4),
	pop_hosp_pct_1 NUMBER (7, 4),
	pop_lab_cost2_act_tot_0 NUMBER (28, 6),
	pop_lab_cost2_act_tot_1 NUMBER (28, 6),
	pop_lab_cost2_act_tot_var NUMBER (28, 6),
	pop_lab_cost2_peer_tot_0 NUMBER (28, 6),
	pop_lab_cost2_peer_tot_1 NUMBER (28, 6),
	pop_lab_cost3_act_tot_0 NUMBER (28, 6),
	pop_lab_cost3_act_tot_1 NUMBER (28, 6),
	pop_lab_cost3_act_tot_var NUMBER (28, 6),
	pop_lab_cost3_peer_tot_0 NUMBER (28, 6),
	pop_lab_cost3_peer_tot_1 NUMBER (28, 6),
	pop_lab_cost_act_tot_0 NUMBER (28, 6),
	pop_lab_cost_act_tot_1 NUMBER (28, 6),
	pop_lab_cost_act_tot_var NUMBER (28, 6),
	pop_lab_cost_peer_tot_0 NUMBER (28, 6),
	pop_lab_cost_peer_tot_1 NUMBER (28, 6),
	pop_lab_enc_act_tot_0 NUMBER (28, 6),
	pop_lab_enc_act_tot_1 NUMBER (28, 6),
	pop_lab_enc_peer_tot_0 NUMBER (28, 6),
	pop_lab_enc_peer_tot_1 NUMBER (28, 6),
	pop_lab_pct_0 NUMBER (7, 4),
	pop_lab_pct_1 NUMBER (7, 4),
	pop_morb NUMBER (19, 2),
	pop_morb2 NUMBER (19, 2),
	pop_morb3 NUMBER (19, 2),
	pop_pcc_cost2_act_tot_0 NUMBER (28, 6),
	pop_pcc_cost2_act_tot_1 NUMBER (28, 6),
	pop_pcc_cost2_act_tot_var NUMBER (28, 6),
	pop_pcc_cost2_peer_tot_0 NUMBER (28, 6),
	pop_pcc_cost2_peer_tot_1 NUMBER (28, 6),
	pop_pcc_cost3_act_tot_0 NUMBER (28, 6),
	pop_pcc_cost3_act_tot_1 NUMBER (28, 6),
	pop_pcc_cost3_act_tot_var NUMBER (28, 6),
	pop_pcc_cost3_peer_tot_0 NUMBER (28, 6),
	pop_pcc_cost3_peer_tot_1 NUMBER (28, 6),
	pop_pcc_cost_act_tot_0 NUMBER (28, 6),
	pop_pcc_cost_act_tot_1 NUMBER (28, 6),
	pop_pcc_cost_act_tot_var NUMBER (28, 6),
	pop_pcc_cost_peer_tot_0 NUMBER (28, 6),
	pop_pcc_cost_peer_tot_1 NUMBER (28, 6),
	pop_pcc_enc_act_tot_0 NUMBER (28, 6),
	pop_pcc_enc_act_tot_1 NUMBER (28, 6),
	pop_pcc_enc_peer_tot_0 NUMBER (28, 6),
	pop_pcc_enc_peer_tot_1 NUMBER (28, 6),
	pop_pcc_pct_0 NUMBER (7, 4),
	pop_pcc_pct_1 NUMBER (7, 4),
	pop_phm_pct_0 NUMBER (7, 4),
	pop_phm_pct_1 NUMBER (7, 4),
	pop_phm_qual_1 NUMBER (10, 0),
	pop_rad_cost2_act_tot_0 NUMBER (28, 6),
	pop_rad_cost2_act_tot_1 NUMBER (28, 6),
	pop_rad_cost2_act_tot_var NUMBER (28, 6),
	pop_rad_cost2_peer_tot_0 NUMBER (28, 6),
	pop_rad_cost2_peer_tot_1 NUMBER (28, 6),
	pop_rad_cost3_act_tot_0 NUMBER (28, 6),
	pop_rad_cost3_act_tot_1 NUMBER (28, 6),
	pop_rad_cost3_act_tot_var NUMBER (28, 6),
	pop_rad_cost3_peer_tot_0 NUMBER (28, 6),
	pop_rad_cost3_peer_tot_1 NUMBER (28, 6),
	pop_rad_cost_act_tot_0 NUMBER (28, 6),
	pop_rad_cost_act_tot_1 NUMBER (28, 6),
	pop_rad_cost_act_tot_var NUMBER (28, 6),
	pop_rad_cost_peer_tot_0 NUMBER (28, 6),
	pop_rad_cost_peer_tot_1 NUMBER (28, 6),
	pop_rad_enc_act_tot_0 NUMBER (28, 6),
	pop_rad_enc_act_tot_1 NUMBER (28, 6),
	pop_rad_enc_peer_tot_0 NUMBER (28, 6),
	pop_rad_enc_peer_tot_1 NUMBER (28, 6),
	pop_rad_pct_0 NUMBER (7, 4),
	pop_rad_pct_1 NUMBER (7, 4),
	pop_rx_cost2_act_tot_0 NUMBER (28, 6),
	pop_rx_cost2_act_tot_1 NUMBER (28, 6),
	pop_rx_cost2_act_tot_var NUMBER (28, 6),
	pop_rx_cost2_peer_tot_0 NUMBER (28, 6),
	pop_rx_cost2_peer_tot_1 NUMBER (28, 6),
	pop_rx_cost3_act_tot_0 NUMBER (28, 6),
	pop_rx_cost3_act_tot_1 NUMBER (28, 6),
	pop_rx_cost3_act_tot_var NUMBER (28, 6),
	pop_rx_cost3_peer_tot_0 NUMBER (28, 6),
	pop_rx_cost3_peer_tot_1 NUMBER (28, 6),
	pop_rx_cost_act_tot_0 NUMBER (28, 6),
	pop_rx_cost_act_tot_1 NUMBER (28, 6),
	pop_rx_cost_act_tot_var NUMBER (28, 6),
	pop_rx_cost_peer_tot_0 NUMBER (28, 6),
	pop_rx_cost_peer_tot_1 NUMBER (28, 6),
	pop_rx_enc_act_tot_0 NUMBER (28, 6),
	pop_rx_enc_act_tot_1 NUMBER (28, 6),
	pop_rx_enc_peer_tot_0 NUMBER (28, 6),
	pop_rx_enc_peer_tot_1 NUMBER (28, 6),
	pop_spec_cost2_act_tot_0 NUMBER (28, 6),
	pop_spec_cost2_act_tot_1 NUMBER (28, 6),
	pop_spec_cost2_act_tot_var NUMBER (28, 6),
	pop_spec_cost2_peer_tot_0 NUMBER (28, 6),
	pop_spec_cost2_peer_tot_1 NUMBER (28, 6),
	pop_spec_cost3_act_tot_0 NUMBER (28, 6),
	pop_spec_cost3_act_tot_1 NUMBER (28, 6),
	pop_spec_cost3_act_tot_var NUMBER (28, 6),
	pop_spec_cost3_peer_tot_0 NUMBER (28, 6),
	pop_spec_cost3_peer_tot_1 NUMBER (28, 6),
	pop_spec_cost_act_tot_0 NUMBER (28, 6),
	pop_spec_cost_act_tot_1 NUMBER (28, 6),
	pop_spec_cost_act_tot_var NUMBER (28, 6),
	pop_spec_cost_peer_tot_0 NUMBER (28, 6),
	pop_spec_cost_peer_tot_1 NUMBER (28, 6),
	pop_spec_enc_act_tot_0 NUMBER (28, 6),
	pop_spec_enc_act_tot_1 NUMBER (28, 6),
	pop_spec_enc_peer_tot_0 NUMBER (28, 6),
	pop_spec_enc_peer_tot_1 NUMBER (28, 6),
	pop_spec_pct_0 NUMBER (7, 4),
	pop_spec_pct_1 NUMBER (7, 4),
	prov_affil VARCHAR2 (30 CHAR),
	prov_affil_desc VARCHAR2 (150 CHAR),
	prov_affil_lv1 VARCHAR2 (30 CHAR),
	prov_affil_lv1_desc VARCHAR2 (150 CHAR),
	prov_affil_lv1_id VARCHAR2 (100 CHAR),
	prov_affil_lv2 VARCHAR2 (30 CHAR),
	prov_affil_lv2_desc VARCHAR2 (150 CHAR),
	prov_affil_lv2_id VARCHAR2 (100 CHAR),
	prov_userdef_1 VARCHAR2 (100 CHAR),
	prov_userdef_2_desc VARCHAR2 (150 CHAR),
	prov_userdef_2_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_name VARCHAR2 (50 CHAR),
	prv_sp_4 NUMBER (10, 0),
	qual_ebm_den NUMBER (10, 0),
	qual_ebm_num NUMBER (10, 0),
	qual_elig NUMBER (10, 0),
	qual_ovr_ind NUMBER (28, 6),
	qual_peer_ebm_num NUMBER (28, 6),
	qual_rate NUMBER (19, 2),
	rank_dec_epi NUMBER (10, 0),
	rank_dec_epi2 NUMBER (10, 0),
	rank_dec_epi3 NUMBER (10, 0),
	rank_dec_pop NUMBER (10, 0),
	rank_dec_pop2 NUMBER (10, 0),
	rank_dec_pop3 NUMBER (10, 0),
	rank_dec_qual NUMBER (10, 0),
	sec_provider_id VARCHAR2 (20 CHAR),
	sp2_id NUMBER (10, 0),
	sp3_id NUMBER (10, 0),
	sp4 VARCHAR2 (40 CHAR),
	state NUMBER (10, 0),
	state_desc VARCHAR2 (2 CHAR),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_ci_epi', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_ci_epi (
	cost2_act_tot NUMBER (28, 6),
	cost2_act_tot_var NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_act_tot_var NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_act_tot_var NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	epi_pct NUMBER (7, 4),
	epi_qty NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	provider_id VARCHAR2 (20 CHAR),
	psc_cat1_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_ci_epi_unw', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_ci_epi_unw (
	cost2_act_tot NUMBER (28, 6),
	cost2_act_tot_var NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_act_tot_var NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_act_tot_var NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	epi_qty NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_ci_pop', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_ci_pop (
	cost2_act_tot NUMBER (28, 6),
	cost2_act_tot_var NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_act_tot_var NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_act_tot_var NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	pcp_mmos NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	phm_qual NUMBER (1),
	pop_pct NUMBER (7, 4),
	provider_id VARCHAR2 (20 CHAR),
	psc_cat1_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_ci_pop_unw', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_ci_pop_unw (
	cost2_act_tot NUMBER (28, 6),
	cost2_act_tot_var NUMBER (28, 6),
	cost2_peer_tot NUMBER (28, 6),
	cost3_act_tot NUMBER (28, 6),
	cost3_act_tot_var NUMBER (28, 6),
	cost3_peer_tot NUMBER (28, 6),
	cost_act_tot NUMBER (28, 6),
	cost_act_tot_var NUMBER (28, 6),
	cost_peer_tot NUMBER (28, 6),
	ia_time NUMBER (10, 0),
	pcp_mmos NUMBER (28, 6),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_ci_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_ci_qual (
	ci_hi_qual NUMBER (7, 2),
	ci_lo_qual NUMBER (7, 2),
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_ebm_num NUMBER (28, 6),
	provider_id VARCHAR2 (20 CHAR),
	signif_qual VARCHAR2 (2 CHAR),
	sum_odd NUMBER (28, 6),
	var_odd NUMBER (28, 6),
	wgt_var_odd NUMBER (28, 6)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_dem', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_dem (
	age_cat2 NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_female_pct NUMBER (19, 2),
	peer_female_qty NUMBER (19, 2),
	peer_male_pct NUMBER (19, 2),
	peer_male_qty NUMBER (19, 2),
	prov_female_pct NUMBER (19, 2),
	prov_female_qty NUMBER (19, 2),
	prov_male_pct NUMBER (19, 2),
	prov_male_qty NUMBER (19, 2),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_dem_pdv', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_dem_pdv (
	age_cat2 NUMBER (10, 0),
	ia_time NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_def_var_desc VARCHAR2 (150 CHAR),
	peer_def_var_id NUMBER (10, 0),
	peer_female_pct NUMBER (19, 2),
	peer_female_qty NUMBER (19, 2),
	peer_male_pct NUMBER (19, 2),
	peer_male_qty NUMBER (19, 2),
	prov_pdv_female_pct NUMBER (19, 2),
	prov_pdv_female_qty NUMBER (19, 2),
	prov_pdv_male_pct NUMBER (19, 2),
	prov_pdv_male_qty NUMBER (19, 2),
	provider_id VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_epi_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_epi_costs (
	admit_act_tot NUMBER (10, 0),
	admit_peer_tot NUMBER (19, 2),
	cost2_act_tot NUMBER (19, 2),
	cost2_ind NUMBER (19, 2),
	cost2_peer_tot NUMBER (19, 2),
	cost3_act_tot NUMBER (19, 2),
	cost3_ind NUMBER (19, 2),
	cost3_peer_tot NUMBER (19, 2),
	cost_act_tot NUMBER (19, 2),
	cost_ind NUMBER (19, 2),
	cost_peer_tot NUMBER (19, 2),
	days_act_tot NUMBER (19, 2),
	days_peer_tot NUMBER (19, 2),
	enc_act_tot NUMBER (19, 2),
	enc_ind NUMBER (19, 2),
	enc_peer_tot NUMBER (19, 2),
	epi_qty NUMBER (19, 2),
	er_act_tot NUMBER (19, 2),
	er_cost2_act_tot NUMBER (19, 2),
	er_cost2_ind NUMBER (19, 2),
	er_cost2_peer_tot NUMBER (19, 2),
	er_cost3_act_tot NUMBER (19, 2),
	er_cost3_ind NUMBER (19, 2),
	er_cost3_peer_tot NUMBER (19, 2),
	er_cost_act_tot NUMBER (19, 2),
	er_cost_ind NUMBER (19, 2),
	er_cost_peer_tot NUMBER (19, 2),
	er_enc_act_tot NUMBER (19, 2),
	er_enc_ind NUMBER (19, 2),
	er_enc_peer_tot NUMBER (19, 2),
	er_peer_tot NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	family NUMBER (10, 0),
	gen_act_tot NUMBER (19, 2),
	gen_peer_tot NUMBER (19, 2),
	hosp_cost2_act_tot NUMBER (19, 2),
	hosp_cost2_ind NUMBER (19, 2),
	hosp_cost2_peer_tot NUMBER (19, 2),
	hosp_cost3_act_tot NUMBER (19, 2),
	hosp_cost3_ind NUMBER (19, 2),
	hosp_cost3_peer_tot NUMBER (19, 2),
	hosp_cost_act_tot NUMBER (19, 2),
	hosp_cost_ind NUMBER (19, 2),
	hosp_cost_peer_tot NUMBER (19, 2),
	hosp_enc_act_tot NUMBER (19, 2),
	hosp_enc_ind NUMBER (19, 2),
	hosp_enc_peer_tot NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	lab_act_tot NUMBER (19, 2),
	lab_cost2_act_tot NUMBER (19, 2),
	lab_cost2_ind NUMBER (19, 2),
	lab_cost2_peer_tot NUMBER (19, 2),
	lab_cost3_act_tot NUMBER (19, 2),
	lab_cost3_ind NUMBER (19, 2),
	lab_cost3_peer_tot NUMBER (19, 2),
	lab_cost_act_tot NUMBER (19, 2),
	lab_cost_ind NUMBER (19, 2),
	lab_cost_peer_tot NUMBER (19, 2),
	lab_enc_act_tot NUMBER (19, 2),
	lab_enc_ind NUMBER (19, 2),
	lab_enc_peer_tot NUMBER (19, 2),
	lab_peer_tot NUMBER (19, 2),
	mpc NUMBER (10, 0),
	mri_act_tot NUMBER (19, 2),
	mri_peer_tot NUMBER (19, 2),
	ospvis_act_tot NUMBER (19, 2),
	ospvis_peer_tot NUMBER (19, 2),
	pcc_cost2_act_tot NUMBER (19, 2),
	pcc_cost2_ind NUMBER (19, 2),
	pcc_cost2_peer_tot NUMBER (19, 2),
	pcc_cost3_act_tot NUMBER (19, 2),
	pcc_cost3_ind NUMBER (19, 2),
	pcc_cost3_peer_tot NUMBER (19, 2),
	pcc_cost_act_tot NUMBER (19, 2),
	pcc_cost_ind NUMBER (19, 2),
	pcc_cost_peer_tot NUMBER (19, 2),
	pcc_enc_act_tot NUMBER (19, 2),
	pcc_enc_ind NUMBER (19, 2),
	pcc_enc_peer_tot NUMBER (19, 2),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	rad_act_tot NUMBER (19, 2),
	rad_cost2_act_tot NUMBER (19, 2),
	rad_cost2_ind NUMBER (19, 2),
	rad_cost2_peer_tot NUMBER (19, 2),
	rad_cost3_act_tot NUMBER (19, 2),
	rad_cost3_ind NUMBER (19, 2),
	rad_cost3_peer_tot NUMBER (19, 2),
	rad_cost_act_tot NUMBER (19, 2),
	rad_cost_ind NUMBER (19, 2),
	rad_cost_peer_tot NUMBER (19, 2),
	rad_enc_act_tot NUMBER (19, 2),
	rad_enc_ind NUMBER (19, 2),
	rad_enc_peer_tot NUMBER (19, 2),
	rad_peer_tot NUMBER (19, 2),
	rx_cost2_act_tot NUMBER (19, 2),
	rx_cost2_ind NUMBER (19, 2),
	rx_cost2_peer_tot NUMBER (19, 2),
	rx_cost3_act_tot NUMBER (19, 2),
	rx_cost3_ind NUMBER (19, 2),
	rx_cost3_peer_tot NUMBER (19, 2),
	rx_cost_act_tot NUMBER (19, 2),
	rx_cost_ind NUMBER (19, 2),
	rx_cost_peer_tot NUMBER (19, 2),
	rx_enc_act_tot NUMBER (19, 2),
	rx_enc_ind NUMBER (19, 2),
	rx_enc_peer_tot NUMBER (19, 2),
	script_act_tot NUMBER (19, 2),
	script_gen_act_tot NUMBER (19, 2),
	script_peer_tot NUMBER (19, 2),
	sev_level NUMBER (10, 0),
	spec_cost2_act_tot NUMBER (19, 2),
	spec_cost2_ind NUMBER (19, 2),
	spec_cost2_peer_tot NUMBER (19, 2),
	spec_cost3_act_tot NUMBER (19, 2),
	spec_cost3_ind NUMBER (19, 2),
	spec_cost3_peer_tot NUMBER (19, 2),
	spec_cost_act_tot NUMBER (19, 2),
	spec_cost_ind NUMBER (19, 2),
	spec_cost_peer_tot NUMBER (19, 2),
	spec_enc_act_tot NUMBER (19, 2),
	spec_enc_ind NUMBER (19, 2),
	spec_enc_peer_tot NUMBER (19, 2),
	spvis_act_tot NUMBER (19, 2),
	spvis_peer_tot NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_epi_costs_pdv', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_epi_costs_pdv (
	admit_act_tot NUMBER (10, 0),
	admit_peer_tot NUMBER (19, 2),
	cost2_act_tot NUMBER (19, 2),
	cost2_ind NUMBER (19, 2),
	cost2_peer_tot NUMBER (19, 2),
	cost3_act_tot NUMBER (19, 2),
	cost3_ind NUMBER (19, 2),
	cost3_peer_tot NUMBER (19, 2),
	cost_act_tot NUMBER (19, 2),
	cost_ind NUMBER (19, 2),
	cost_peer_tot NUMBER (19, 2),
	days_act_tot NUMBER (19, 2),
	days_peer_tot NUMBER (19, 2),
	enc_act_tot NUMBER (19, 2),
	enc_ind NUMBER (19, 2),
	enc_peer_tot NUMBER (19, 2),
	epi_qty NUMBER (19, 2),
	er_act_tot NUMBER (19, 2),
	er_cost2_act_tot NUMBER (19, 2),
	er_cost2_ind NUMBER (19, 2),
	er_cost2_peer_tot NUMBER (19, 2),
	er_cost3_act_tot NUMBER (19, 2),
	er_cost3_ind NUMBER (19, 2),
	er_cost3_peer_tot NUMBER (19, 2),
	er_cost_act_tot NUMBER (19, 2),
	er_cost_ind NUMBER (19, 2),
	er_cost_peer_tot NUMBER (19, 2),
	er_enc_act_tot NUMBER (19, 2),
	er_enc_ind NUMBER (19, 2),
	er_enc_peer_tot NUMBER (19, 2),
	er_peer_tot NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	family NUMBER (10, 0),
	gen_act_tot NUMBER (19, 2),
	gen_peer_tot NUMBER (19, 2),
	hosp_cost2_act_tot NUMBER (19, 2),
	hosp_cost2_ind NUMBER (19, 2),
	hosp_cost2_peer_tot NUMBER (19, 2),
	hosp_cost3_act_tot NUMBER (19, 2),
	hosp_cost3_ind NUMBER (19, 2),
	hosp_cost3_peer_tot NUMBER (19, 2),
	hosp_cost_act_tot NUMBER (19, 2),
	hosp_cost_ind NUMBER (19, 2),
	hosp_cost_peer_tot NUMBER (19, 2),
	hosp_enc_act_tot NUMBER (19, 2),
	hosp_enc_ind NUMBER (19, 2),
	hosp_enc_peer_tot NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	lab_act_tot NUMBER (19, 2),
	lab_cost2_act_tot NUMBER (19, 2),
	lab_cost2_ind NUMBER (19, 2),
	lab_cost2_peer_tot NUMBER (19, 2),
	lab_cost3_act_tot NUMBER (19, 2),
	lab_cost3_ind NUMBER (19, 2),
	lab_cost3_peer_tot NUMBER (19, 2),
	lab_cost_act_tot NUMBER (19, 2),
	lab_cost_ind NUMBER (19, 2),
	lab_cost_peer_tot NUMBER (19, 2),
	lab_enc_act_tot NUMBER (19, 2),
	lab_enc_ind NUMBER (19, 2),
	lab_enc_peer_tot NUMBER (19, 2),
	lab_peer_tot NUMBER (19, 2),
	mpc NUMBER (10, 0),
	mri_act_tot NUMBER (19, 2),
	mri_peer_tot NUMBER (19, 2),
	ospvis_act_tot NUMBER (19, 2),
	ospvis_peer_tot NUMBER (19, 2),
	pcc_cost2_act_tot NUMBER (19, 2),
	pcc_cost2_ind NUMBER (19, 2),
	pcc_cost2_peer_tot NUMBER (19, 2),
	pcc_cost3_act_tot NUMBER (19, 2),
	pcc_cost3_ind NUMBER (19, 2),
	pcc_cost3_peer_tot NUMBER (19, 2),
	pcc_cost_act_tot NUMBER (19, 2),
	pcc_cost_ind NUMBER (19, 2),
	pcc_cost_peer_tot NUMBER (19, 2),
	pcc_enc_act_tot NUMBER (19, 2),
	pcc_enc_ind NUMBER (19, 2),
	pcc_enc_peer_tot NUMBER (19, 2),
	peer_def_id NUMBER (10, 0),
	peer_def_var_desc VARCHAR2 (150 CHAR),
	peer_def_var_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	rad_act_tot NUMBER (19, 2),
	rad_cost2_act_tot NUMBER (19, 2),
	rad_cost2_ind NUMBER (19, 2),
	rad_cost2_peer_tot NUMBER (19, 2),
	rad_cost3_act_tot NUMBER (19, 2),
	rad_cost3_ind NUMBER (19, 2),
	rad_cost3_peer_tot NUMBER (19, 2),
	rad_cost_act_tot NUMBER (19, 2),
	rad_cost_ind NUMBER (19, 2),
	rad_cost_peer_tot NUMBER (19, 2),
	rad_enc_act_tot NUMBER (19, 2),
	rad_enc_ind NUMBER (19, 2),
	rad_enc_peer_tot NUMBER (19, 2),
	rad_peer_tot NUMBER (19, 2),
	rx_cost2_act_tot NUMBER (19, 2),
	rx_cost2_ind NUMBER (19, 2),
	rx_cost2_peer_tot NUMBER (19, 2),
	rx_cost3_act_tot NUMBER (19, 2),
	rx_cost3_ind NUMBER (19, 2),
	rx_cost3_peer_tot NUMBER (19, 2),
	rx_cost_act_tot NUMBER (19, 2),
	rx_cost_ind NUMBER (19, 2),
	rx_cost_peer_tot NUMBER (19, 2),
	rx_enc_act_tot NUMBER (19, 2),
	rx_enc_ind NUMBER (19, 2),
	rx_enc_peer_tot NUMBER (19, 2),
	script_act_tot NUMBER (19, 2),
	script_gen_act_tot NUMBER (19, 2),
	script_peer_tot NUMBER (19, 2),
	sev_level NUMBER (10, 0),
	spec_cost2_act_tot NUMBER (19, 2),
	spec_cost2_ind NUMBER (19, 2),
	spec_cost2_peer_tot NUMBER (19, 2),
	spec_cost3_act_tot NUMBER (19, 2),
	spec_cost3_ind NUMBER (19, 2),
	spec_cost3_peer_tot NUMBER (19, 2),
	spec_cost_act_tot NUMBER (19, 2),
	spec_cost_ind NUMBER (19, 2),
	spec_cost_peer_tot NUMBER (19, 2),
	spec_enc_act_tot NUMBER (19, 2),
	spec_enc_ind NUMBER (19, 2),
	spec_enc_peer_tot NUMBER (19, 2),
	spvis_act_tot NUMBER (19, 2),
	spvis_peer_tot NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_epi_pop', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_epi_pop (
	ci_hi_epi NUMBER (7, 2),
	ci_hi_epi2 NUMBER (7, 2),
	ci_hi_epi2_unwtd NUMBER (7, 2),
	ci_hi_epi3 NUMBER (7, 2),
	ci_hi_epi3_unwtd NUMBER (7, 2),
	ci_hi_epi_unwtd NUMBER (7, 2),
	ci_hi_pop NUMBER (7, 2),
	ci_hi_pop2 NUMBER (7, 2),
	ci_hi_pop2_unwtd NUMBER (7, 2),
	ci_hi_pop3 NUMBER (7, 2),
	ci_hi_pop3_unwtd NUMBER (7, 2),
	ci_hi_pop_unwtd NUMBER (7, 2),
	ci_lo_epi NUMBER (7, 2),
	ci_lo_epi2 NUMBER (7, 2),
	ci_lo_epi2_unwtd NUMBER (7, 2),
	ci_lo_epi3 NUMBER (7, 2),
	ci_lo_epi3_unwtd NUMBER (7, 2),
	ci_lo_epi_unwtd NUMBER (7, 2),
	ci_lo_pop NUMBER (7, 2),
	ci_lo_pop2 NUMBER (7, 2),
	ci_lo_pop2_unwtd NUMBER (7, 2),
	ci_lo_pop3 NUMBER (7, 2),
	ci_lo_pop3_unwtd NUMBER (7, 2),
	ci_lo_pop_unwtd NUMBER (7, 2),
	epi_case_mix NUMBER (19, 2),
	epi_case_mix2 NUMBER (19, 2),
	epi_case_mix3 NUMBER (19, 2),
	epi_cost2_act_tot NUMBER (19, 2),
	epi_cost2_ind NUMBER (19, 2),
	epi_cost2_ovr_ind NUMBER (19, 2),
	epi_cost2_peer_tot NUMBER (19, 2),
	epi_cost3_act_tot NUMBER (19, 2),
	epi_cost3_ind NUMBER (19, 2),
	epi_cost3_ovr_ind NUMBER (19, 2),
	epi_cost3_peer_tot NUMBER (19, 2),
	epi_cost_act_tot NUMBER (19, 2),
	epi_cost_ind NUMBER (19, 2),
	epi_cost_ovr_ind NUMBER (19, 2),
	epi_cost_peer_tot NUMBER (19, 2),
	epi_elig NUMBER (10, 0),
	epi_enc_act_tot NUMBER (19, 2),
	epi_enc_ind NUMBER (19, 2),
	epi_enc_ovr_ind NUMBER (19, 2),
	epi_enc_peer_tot NUMBER (19, 2),
	epi_peer_qty NUMBER (19, 2),
	epi_qty NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	pcp_elig NUMBER (10, 0),
	pcp_members NUMBER (19, 2),
	pcp_mmos NUMBER (19, 2),
	pcp_peer_mmos NUMBER (19, 2),
	peer_def_id NUMBER (10, 0),
	pop_cost2_act_tot NUMBER (19, 2),
	pop_cost2_ind NUMBER (19, 2),
	pop_cost2_ovr_ind NUMBER (19, 2),
	pop_cost2_peer_tot NUMBER (19, 2),
	pop_cost3_act_tot NUMBER (19, 2),
	pop_cost3_ind NUMBER (19, 2),
	pop_cost3_ovr_ind NUMBER (19, 2),
	pop_cost3_peer_tot NUMBER (19, 2),
	pop_cost_act_tot NUMBER (19, 2),
	pop_cost_ind NUMBER (19, 2),
	pop_cost_ovr_ind NUMBER (19, 2),
	pop_cost_peer_tot NUMBER (19, 2),
	pop_enc_act_tot NUMBER (19, 2),
	pop_enc_ind NUMBER (19, 2),
	pop_enc_ovr_ind NUMBER (19, 2),
	pop_enc_peer_tot NUMBER (19, 2),
	pop_morb NUMBER (19, 2),
	pop_morb2 NUMBER (19, 2),
	pop_morb3 NUMBER (19, 2),
	provider_id VARCHAR2 (20 CHAR),
	rank_dec_epi NUMBER (10, 0),
	rank_dec_epi2 NUMBER (10, 0),
	rank_dec_epi3 NUMBER (10, 0),
	rank_dec_pop NUMBER (10, 0),
	rank_dec_pop2 NUMBER (10, 0),
	rank_dec_pop3 NUMBER (10, 0),
	signif_epi VARCHAR2 (2 CHAR),
	signif_epi2 VARCHAR2 (2 CHAR),
	signif_epi2_unwtd VARCHAR2 (2 CHAR),
	signif_epi3 VARCHAR2 (2 CHAR),
	signif_epi3_unwtd VARCHAR2 (2 CHAR),
	signif_epi_unwtd VARCHAR2 (2 CHAR),
	signif_pop VARCHAR2 (2 CHAR),
	signif_pop2 VARCHAR2 (2 CHAR),
	signif_pop2_unwtd VARCHAR2 (2 CHAR),
	signif_pop3 VARCHAR2 (2 CHAR),
	signif_pop3_unwtd VARCHAR2 (2 CHAR),
	signif_pop_unwtd VARCHAR2 (2 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_fac', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_fac (
	adm_case_mix NUMBER (19, 2),
	adm_case_mix2 NUMBER (19, 2),
	adm_case_mix3 NUMBER (19, 2),
	admit_act_tot NUMBER (10, 0),
	admit_elig NUMBER (10, 0),
	cost2_act_tot NUMBER (19, 2),
	cost2_adm_act NUMBER (19, 2),
	cost2_adm_ind NUMBER (19, 2),
	cost2_adm_peer NUMBER (19, 2),
	cost2_day_act NUMBER (19, 2),
	cost2_day_ind NUMBER (19, 2),
	cost2_day_peer NUMBER (19, 2),
	cost2_peer_tot NUMBER (19, 2),
	cost3_act_tot NUMBER (19, 2),
	cost3_adm_act NUMBER (19, 2),
	cost3_adm_ind NUMBER (19, 2),
	cost3_adm_peer NUMBER (19, 2),
	cost3_day_act NUMBER (19, 2),
	cost3_day_ind NUMBER (19, 2),
	cost3_day_peer NUMBER (19, 2),
	cost3_peer_tot NUMBER (19, 2),
	cost_act_tot NUMBER (19, 2),
	cost_adm_act NUMBER (19, 2),
	cost_adm_ind NUMBER (19, 2),
	cost_adm_peer NUMBER (19, 2),
	cost_day_act NUMBER (19, 2),
	cost_day_ind NUMBER (19, 2),
	cost_day_peer NUMBER (19, 2),
	cost_peer_tot NUMBER (19, 2),
	days_act_tot NUMBER (19, 2),
	days_peer_tot NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	los_adm_act NUMBER (19, 2),
	los_adm_ind NUMBER (19, 2),
	los_adm_peer NUMBER (19, 2),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	rank_dec_adm NUMBER (10, 0),
	rank_dec_adm2 NUMBER (10, 0),
	rank_dec_adm3 NUMBER (10, 0),
	readmit_07_act NUMBER (19, 2),
	readmit_07_act_tot NUMBER (10, 0),
	readmit_07_ind NUMBER (19, 2),
	readmit_07_peer NUMBER (19, 2),
	readmit_07_peer_tot NUMBER (19, 2),
	readmit_30_act NUMBER (19, 2),
	readmit_30_act_tot NUMBER (10, 0),
	readmit_30_ind NUMBER (19, 2),
	readmit_30_peer NUMBER (19, 2),
	readmit_30_peer_tot NUMBER (19, 2),
	readmit_60_act NUMBER (19, 2),
	readmit_60_act_tot NUMBER (10, 0),
	readmit_60_ind NUMBER (19, 2),
	readmit_60_peer NUMBER (19, 2),
	readmit_60_peer_tot NUMBER (19, 2),
	readmit_90_act NUMBER (19, 2),
	readmit_90_act_tot NUMBER (10, 0),
	readmit_90_ind NUMBER (19, 2),
	readmit_90_peer NUMBER (19, 2),
	readmit_90_peer_tot NUMBER (19, 2),
	readmit_index_07_act_tot NUMBER (10, 0),
	readmit_index_30_act_tot NUMBER (10, 0),
	readmit_index_60_act_tot NUMBER (10, 0),
	readmit_index_90_act_tot NUMBER (10, 0),
	rrisk_adm_act NUMBER (19, 2),
	rrisk_adm_act_tot NUMBER (19, 2),
	rrisk_adm_peer NUMBER (19, 2),
	rrisk_adm_peer_tot NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_fac_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_fac_costs (
	admit_act_tot NUMBER (10, 0),
	cost2_act_tot NUMBER (19, 2),
	cost2_adm_act NUMBER (19, 2),
	cost2_adm_ind NUMBER (19, 2),
	cost2_day_act NUMBER (19, 2),
	cost2_day_ind NUMBER (19, 2),
	cost2_peer_tot NUMBER (19, 2),
	cost3_act_tot NUMBER (19, 2),
	cost3_adm_act NUMBER (19, 2),
	cost3_adm_ind NUMBER (19, 2),
	cost3_day_act NUMBER (19, 2),
	cost3_day_ind NUMBER (19, 2),
	cost3_peer_tot NUMBER (19, 2),
	cost_act_tot NUMBER (19, 2),
	cost_adm_act NUMBER (19, 2),
	cost_adm_ind NUMBER (19, 2),
	cost_day_act NUMBER (19, 2),
	cost_day_ind NUMBER (19, 2),
	cost_peer_tot NUMBER (19, 2),
	days_act_tot NUMBER (19, 2),
	days_peer_tot NUMBER (19, 2),
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_unit_id VARCHAR2 (12 CHAR),
	ia_time NUMBER (10, 0),
	los_adm_act NUMBER (19, 2),
	los_adm_ind NUMBER (19, 2),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	readmit_07_act NUMBER (19, 2),
	readmit_07_act_tot NUMBER (10, 0),
	readmit_07_ind NUMBER (19, 2),
	readmit_07_peer_tot NUMBER (19, 2),
	readmit_30_act NUMBER (19, 2),
	readmit_30_act_tot NUMBER (10, 0),
	readmit_30_ind NUMBER (19, 2),
	readmit_30_peer_tot NUMBER (19, 2),
	readmit_60_act NUMBER (19, 2),
	readmit_60_act_tot NUMBER (10, 0),
	readmit_60_ind NUMBER (19, 2),
	readmit_60_peer_tot NUMBER (19, 2),
	readmit_90_act NUMBER (19, 2),
	readmit_90_act_tot NUMBER (10, 0),
	readmit_90_ind NUMBER (19, 2),
	readmit_90_peer_tot NUMBER (19, 2),
	readmit_index_07_act_tot NUMBER (10, 0),
	readmit_index_30_act_tot NUMBER (10, 0),
	readmit_index_60_act_tot NUMBER (10, 0),
	readmit_index_90_act_tot NUMBER (10, 0),
	rrisk_adm_act NUMBER (19, 2),
	rrisk_adm_act_tot NUMBER (19, 2),
	rrisk_adm_peer NUMBER (19, 2),
	rrisk_adm_peer_tot NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_pop_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_pop_costs (
	admit_act_tot NUMBER (10, 0),
	admit_peer_tot NUMBER (19, 2),
	cost2_act_pmpm NUMBER (19, 2),
	cost2_act_tot NUMBER (19, 2),
	cost2_ind NUMBER (19, 2),
	cost2_peer_pmpm NUMBER (19, 2),
	cost2_peer_tot NUMBER (19, 2),
	cost3_act_pmpm NUMBER (19, 2),
	cost3_act_tot NUMBER (19, 2),
	cost3_ind NUMBER (19, 2),
	cost3_peer_pmpm NUMBER (19, 2),
	cost3_peer_tot NUMBER (19, 2),
	cost_act_pmpm NUMBER (19, 2),
	cost_act_tot NUMBER (19, 2),
	cost_ind NUMBER (19, 2),
	cost_peer_pmpm NUMBER (19, 2),
	cost_peer_tot NUMBER (19, 2),
	days_act_tot NUMBER (19, 2),
	days_peer_tot NUMBER (19, 2),
	enc_act_1k NUMBER (19, 2),
	enc_act_tot NUMBER (19, 2),
	enc_ind NUMBER (19, 2),
	enc_peer_1k NUMBER (19, 2),
	enc_peer_tot NUMBER (19, 2),
	er_act_tot NUMBER (19, 2),
	er_peer_tot NUMBER (19, 2),
	gen_act_tot NUMBER (19, 2),
	gen_peer_tot NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	lab_act_tot NUMBER (19, 2),
	lab_peer_tot NUMBER (19, 2),
	mri_act_tot NUMBER (19, 2),
	mri_peer_tot NUMBER (19, 2),
	pcp_mmos NUMBER (19, 2),
	pcpvis_act_tot NUMBER (19, 2),
	pcpvis_peer_tot NUMBER (19, 2),
	peer_def_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	psc_cat1_id NUMBER (10, 0),
	rad_act_tot NUMBER (19, 2),
	rad_peer_tot NUMBER (19, 2),
	ref_act_tot NUMBER (19, 2),
	ref_peer_tot NUMBER (19, 2),
	refvis_act_tot NUMBER (19, 2),
	refvis_peer_tot NUMBER (19, 2),
	script_act_tot NUMBER (19, 2),
	script_gen_act_tot NUMBER (19, 2),
	script_peer_tot NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_pop_costs_pdv', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_pop_costs_pdv (
	admit_act_tot NUMBER (10, 0),
	admit_peer_tot NUMBER (19, 2),
	cost2_act_pmpm NUMBER (19, 2),
	cost2_act_tot NUMBER (19, 2),
	cost2_ind NUMBER (19, 2),
	cost2_peer_pmpm NUMBER (19, 2),
	cost2_peer_tot NUMBER (19, 2),
	cost3_act_pmpm NUMBER (19, 2),
	cost3_act_tot NUMBER (19, 2),
	cost3_ind NUMBER (19, 2),
	cost3_peer_pmpm NUMBER (19, 2),
	cost3_peer_tot NUMBER (19, 2),
	cost_act_pmpm NUMBER (19, 2),
	cost_act_tot NUMBER (19, 2),
	cost_ind NUMBER (19, 2),
	cost_peer_pmpm NUMBER (19, 2),
	cost_peer_tot NUMBER (19, 2),
	days_act_tot NUMBER (19, 2),
	days_peer_tot NUMBER (19, 2),
	enc_act_1k NUMBER (19, 2),
	enc_act_tot NUMBER (19, 2),
	enc_ind NUMBER (19, 2),
	enc_peer_1k NUMBER (19, 2),
	enc_peer_tot NUMBER (19, 2),
	er_act_tot NUMBER (19, 2),
	er_peer_tot NUMBER (19, 2),
	gen_act_tot NUMBER (19, 2),
	gen_peer_tot NUMBER (19, 2),
	ia_time NUMBER (10, 0),
	lab_act_tot NUMBER (19, 2),
	lab_peer_tot NUMBER (19, 2),
	mri_act_tot NUMBER (19, 2),
	mri_peer_tot NUMBER (19, 2),
	pcp_mmos NUMBER (19, 2),
	pcpvis_act_tot NUMBER (19, 2),
	pcpvis_peer_tot NUMBER (19, 2),
	peer_def_id NUMBER (10, 0),
	peer_def_var_desc VARCHAR2 (150 CHAR),
	peer_def_var_id NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	psc_cat1_id NUMBER (10, 0),
	rad_act_tot NUMBER (19, 2),
	rad_peer_tot NUMBER (19, 2),
	ref_act_tot NUMBER (19, 2),
	ref_peer_tot NUMBER (19, 2),
	refvis_act_tot NUMBER (19, 2),
	refvis_peer_tot NUMBER (19, 2),
	script_act_tot NUMBER (19, 2),
	script_gen_act_tot NUMBER (19, 2),
	script_peer_tot NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_qual (
	all_ebm_num NUMBER (28, 6),
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	ebm_numx NUMBER (10, 0),
	num_members NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_ebm_num NUMBER (28, 6),
	provider_id VARCHAR2 (20 CHAR),
	qual_all_rate NUMBER (19, 2),
	qual_elig NUMBER (10, 0),
	qual_ovr_ind NUMBER (28, 6),
	qual_peer_rate NUMBER (19, 2),
	qual_rate NUMBER (19, 2),
	rank_dec_qual NUMBER (10, 0),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_prov_qual_pop_pdv', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_prov_qual_pop_pdv (
	all_ebm_num NUMBER (28, 6),
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	ebm_numx NUMBER (10, 0),
	peer_def_id NUMBER (10, 0),
	peer_def_var_desc VARCHAR2 (150 CHAR),
	peer_def_var_id NUMBER (10, 0),
	peer_ebm_num NUMBER (28, 6),
	provider_id VARCHAR2 (20 CHAR),
	qual_all_rate NUMBER (19, 2),
	qual_ovr_ind NUMBER (28, 6),
	qual_peer_rate NUMBER (19, 2),
	qual_rate NUMBER (19, 2),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_quality', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_quality (
	account_id VARCHAR2 (40 CHAR),
	age NUMBER (10, 0),
	all_ebm_num NUMBER (28, 6),
	at_risk_status_id VARCHAR2 (40 CHAR),
	biz_segment_id VARCHAR2 (40 CHAR),
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	contract_id VARCHAR2 (40 CHAR),
	contract_type_id VARCHAR2 (40 CHAR),
	coverage_status_id VARCHAR2 (40 CHAR),
	ebm_den NUMBER (10, 0),
	ebm_num NUMBER (10, 0),
	event_id NUMBER (10, 0),
	med_qual NUMBER (1),
	mem_case_rule VARCHAR2 (100 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	pcp_id VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	phm_qual NUMBER (1),
	product_id VARCHAR2 (40 CHAR),
	result_flag NUMBER (10, 0),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0),
	rrisk NUMBER (10, 4),
	sex NUMBER (1),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_rp_agr_claims_hc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_rp_agr_claims_hc (
	account_id VARCHAR2 (40 CHAR),
	cost3 NUMBER (19, 2),
	cost3_anc NUMBER (19, 2),
	cost3_ifac NUMBER (19, 2),
	cost3_ofac NUMBER (19, 2),
	cost3_phm NUMBER (19, 2),
	cost3_prof NUMBER (19, 2),
	coverage_status_desc VARCHAR2 (150 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	product_id VARCHAR2 (40 CHAR),
	year_mth_id NUMBER (10, 0),
	year_mth_pd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_rp_opp_dash', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_rp_opp_dash (
	affil_lvl NUMBER (10, 0),
	epi_qty NUMBER (19, 2),
	ia_time_end TIMESTAMP,
	ia_time_start TIMESTAMP,
	pcp_attr_id NUMBER (10, 0),
	peer_def_desc VARCHAR2 (50 CHAR),
	peer_def_id NUMBER (10, 0),
	prov_affil_desc VARCHAR2 (150 CHAR),
	prov_affil_id VARCHAR2 (100 CHAR),
	q_qual_ovr_ind NUMBER (28, 6),
	qual_opp NUMBER (19, 2),
	w_cost1 NUMBER (19, 2),
	w_cost2 NUMBER (19, 2),
	w_cost3 NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_rs_rowcount', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_rs_rowcount (
	view_name VARCHAR2 (50 CHAR),
	view_rowcount NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_confinement_clms', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_confinement_clms (
	"EXCLUDE" NUMBER (1),
	amt_cob NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_std NUMBER (19, 2),
	bill_type VARCHAR2 (4 CHAR),
	cf_var1 VARCHAR2 (30 CHAR),
	cf_var2 VARCHAR2 (30 CHAR),
	clm_id_n VARCHAR2 (30 CHAR),
	conf_num NUMBER (19, 0),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	dnp_ind NUMBER (10, 0),
	dos TIMESTAMP,
	drg_level VARCHAR2 (2 CHAR),
	drg_n VARCHAR2 (4 CHAR),
	drg_outlier NUMBER (10, 0),
	drg_version VARCHAR2 (3 CHAR),
	er_conf NUMBER (1),
	er_flag NUMBER (1),
	fac_level NUMBER (10, 0),
	from_dt TIMESTAMP,
	icd_version NUMBER (10, 0),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	local_flag NUMBER (10, 0),
	map_srce_n VARCHAR2 (6 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	mod_n2 NUMBER (10, 0),
	mod_n3 NUMBER (10, 0),
	mod_n4 NUMBER (10, 0),
	mod_n5 NUMBER (10, 0),
	network_status NUMBER (1),
	noenr_dos NUMBER (1),
	obs_flag NUMBER (1),
	order_prov VARCHAR2 (20 CHAR),
	pay_dt TIMESTAMP,
	poa1 VARCHAR2 (1 CHAR),
	poa10 NUMBER (10, 0),
	poa2 NUMBER (10, 0),
	poa3 NUMBER (10, 0),
	poa4 NUMBER (10, 0),
	poa5 NUMBER (10, 0),
	poa6 NUMBER (10, 0),
	poa7 NUMBER (10, 0),
	poa8 NUMBER (10, 0),
	poa9 NUMBER (10, 0),
	pos_i NUMBER (10, 0),
	pos_n VARCHAR2 (3 CHAR),
	pricing_var NUMBER (19, 2),
	proccode VARCHAR2 (15 CHAR),
	provider VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	prv_sp_n VARCHAR2 (30 CHAR),
	qty NUMBER (10, 0),
	revenue VARCHAR2 (15 CHAR),
	rnb_claim NUMBER (10, 0),
	std_zero VARCHAR2 (1 CHAR),
	to_dt TIMESTAMP,
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tos_n VARCHAR2 (30 CHAR),
	tos_r_id NUMBER (10, 0),
	uniq_rec_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_confinement_final', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_confinement_final (
	amt_cob NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_day NUMBER (25, 8),
	amt_ded NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_std NUMBER (19, 2),
	beg_dt TIMESTAMP,
	cf_var1 VARCHAR2 (30 CHAR),
	cf_var2 VARCHAR2 (30 CHAR),
	conf_num NUMBER (19, 0),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	drg_int NUMBER (10, 0),
	drg_level VARCHAR2 (2 CHAR),
	drg_n VARCHAR2 (4 CHAR),
	drg_outlier NUMBER (10, 0),
	drg_version VARCHAR2 (3 CHAR),
	end_dt TIMESTAMP,
	icd_version NUMBER (10, 0),
	icustay NUMBER (10, 0),
	icusurg NUMBER (10, 0),
	iprice_cat VARCHAR2 (30 CHAR),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	los NUMBER (10, 0),
	losgrp VARCHAR2 (7 CHAR),
	matern NUMBER (10, 0),
	member VARCHAR2 (32 CHAR),
	method VARCHAR2 (1 CHAR),
	msurg NUMBER (10, 0),
	network_status NUMBER (1),
	newborn NUMBER (10, 0),
	outlier_cost VARCHAR2 (1 CHAR),
	outlier_los VARCHAR2 (1 CHAR),
	pay_dt TIMESTAMP,
	pay_dt_beg TIMESTAMP,
	poa1 VARCHAR2 (1 CHAR),
	poa10 NUMBER (10, 0),
	poa2 NUMBER (10, 0),
	poa3 NUMBER (10, 0),
	poa4 NUMBER (10, 0),
	poa5 NUMBER (10, 0),
	poa6 NUMBER (10, 0),
	poa7 NUMBER (10, 0),
	poa8 NUMBER (10, 0),
	poa9 NUMBER (10, 0),
	pos_i NUMBER (10, 0),
	pricing_var NUMBER (19, 2),
	provider VARCHAR2 (20 CHAR),
	prv_beg VARCHAR2 (20 CHAR),
	prv_sp_4 NUMBER (10, 0),
	reset_0 VARCHAR2 (1 CHAR),
	rsnf NUMBER (10, 0),
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tos_r_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_date_range', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_date_range (
	month_date TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_fop_ratio', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_fop_ratio (
	fop_ratio NUMBER (19, 4),
	grouper VARCHAR2 (7 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_member_span', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_member_span (
	cf_var1 VARCHAR2 (30 CHAR),
	cf_var2 VARCHAR2 (30 CHAR),
	eff_dt TIMESTAMP,
	end_dt TIMESTAMP,
	member VARCHAR2 (32 CHAR),
	subscriber_id VARCHAR2 (32 CHAR),
	uniq_rec_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_outpatient_final', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_outpatient_final (
	amt_eqv NUMBER (19, 4),
	amt_oth1 NUMBER (19, 4),
	amt_oth2 NUMBER (19, 4),
	amt_oth3 NUMBER (19, 4),
	amt_oth4 NUMBER (19, 4),
	amt_pay NUMBER (19, 4),
	amt_req NUMBER (19, 4),
	amt_std NUMBER (38, 6),
	cf_var1 VARCHAR2 (30 CHAR),
	cf_var2 VARCHAR2 (30 CHAR),
	dos TIMESTAMP,
	dos_year NUMBER (10, 0),
	fac_op_visit_id NUMBER (19, 0),
	j_code_qty_adj VARCHAR2 (1 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_i VARCHAR2 (4 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	op_adj NUMBER (18, 4),
	op_adj_reason VARCHAR2 (100 CHAR),
	op_apc VARCHAR2 (50 CHAR),
	op_indicator VARCHAR2 (50 CHAR),
	op_mult_reduction VARCHAR2 (50 CHAR),
	op_packaged_final_ind NUMBER (10, 0),
	op_packaged_instruct VARCHAR2 (50 CHAR),
	op_packaged_reset NUMBER (10, 0),
	op_payment_method VARCHAR2 (50 CHAR),
	op_payment_method_notes VARCHAR2 (150 CHAR),
	op_payment_method_notes_desc VARCHAR2 (500 CHAR),
	op_proccode_key VARCHAR2 (50 CHAR),
	op_rvu_final NUMBER (18, 4),
	op_rvu_final_src VARCHAR2 (130 CHAR),
	op_rvu_orig NUMBER (18, 4),
	op_type VARCHAR2 (50 CHAR),
	outlier VARCHAR2 (50 CHAR),
	outlier_type VARCHAR2 (50 CHAR),
	pos_i NUMBER (10, 0),
	price_index NUMBER (18, 4),
	pricing_var NUMBER (19, 4),
	proccode VARCHAR2 (15 CHAR),
	proccode_key VARCHAR2 (23 CHAR),
	proccode_xwalk_from_revenue VARCHAR2 (100 CHAR),
	proctype VARCHAR2 (3 CHAR),
	proration_var NUMBER (38, 6),
	provider VARCHAR2 (20 CHAR),
	qty NUMBER (38, 10),
	qty_adj VARCHAR2 (1 CHAR),
	quant VARCHAR2 (2 CHAR),
	revenue VARCHAR2 (15 CHAR),
	std_zero VARCHAR2 (1 CHAR),
	tos_i_5 NUMBER (10, 0),
	tos_r_id NUMBER (10, 0),
	tot_visit_prorate_rvu NUMBER (38, 10),
	tot_visit_proration_var NUMBER (38, 6),
	uniq_rec_id NUMBER (19, 0),
	use_flag VARCHAR2 (1 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_preprocess_final', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_preprocess_final (
	cf_var1 VARCHAR2 (30 CHAR),
	cf_var2 VARCHAR2 (30 CHAR),
	cust_dnp_ind VARCHAR2 (20 CHAR),
	dos TIMESTAMP,
	local_flag NUMBER (10, 0),
	map_srce_n VARCHAR2 (6 CHAR),
	member VARCHAR2 (32 CHAR),
	pos_i NUMBER (10, 0),
	pricing_var NUMBER (19, 2),
	proccode VARCHAR2 (15 CHAR),
	prv_sp_4 NUMBER (10, 0),
	pseudo NUMBER (1),
	revenue VARCHAR2 (15 CHAR),
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tos_n VARCHAR2 (30 CHAR),
	tos_r_id NUMBER (10, 0),
	uniq_rec_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_preproc_final_excld', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_preproc_final_excld (
	cf_var1 VARCHAR2 (30 CHAR),
	cf_var2 VARCHAR2 (30 CHAR),
	cust_dnp_ind VARCHAR2 (20 CHAR),
	dos TIMESTAMP,
	local_flag NUMBER (10, 0),
	map_srce_n VARCHAR2 (6 CHAR),
	member VARCHAR2 (32 CHAR),
	pos_i NUMBER (10, 0),
	pricing_var NUMBER (19, 2),
	proccode VARCHAR2 (15 CHAR),
	prv_sp_4 NUMBER (10, 0),
	pseudo NUMBER (1),
	revenue VARCHAR2 (15 CHAR),
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tos_n VARCHAR2 (30 CHAR),
	tos_r_id NUMBER (10, 0),
	uniq_rec_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_prof_anc_final', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_prof_anc_final (
	adj NUMBER (20, 2),
	amt_eqv NUMBER (19, 4),
	amt_pay NUMBER (19, 4),
	amt_req NUMBER (19, 4),
	amt_std NUMBER (19, 2),
	m_look NUMBER (19, 2),
	method VARCHAR2 (1 CHAR),
	mod_i VARCHAR2 (15 CHAR),
	price_index NUMBER (19, 2),
	pricing_var NUMBER (19, 4),
	proccode VARCHAR2 (15 CHAR),
	proccode_key VARCHAR2 (21 CHAR),
	qty_i NUMBER (38, 10),
	quant VARCHAR2 (2 CHAR),
	revenue VARCHAR2 (15 CHAR),
	rvus NUMBER (19, 2),
	set_mod VARCHAR2 (1 CHAR),
	std_zero VARCHAR2 (1 CHAR),
	tos_i_5 NUMBER (10, 0),
	tos_level_rvu VARCHAR2 (1 CHAR),
	tos_r_id NUMBER (10, 0),
	uniq_rec_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_rx_final', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_rx_final (
	amt_eqv NUMBER (19, 4),
	amt_oth1 NUMBER (19, 4),
	amt_oth2 NUMBER (19, 4),
	amt_oth3 NUMBER (19, 4),
	amt_oth4 NUMBER (19, 4),
	amt_pay NUMBER (19, 4),
	amt_req NUMBER (19, 4),
	amt_std NUMBER (19, 2),
	cf_var1 VARCHAR2 (30 CHAR),
	cf_var2 VARCHAR2 (30 CHAR),
	day_cost NUMBER (19, 2),
	day_sup NUMBER (10, 0),
	dos TIMESTAMP,
	eoynpt NUMBER (38, 10),
	eoynpt_adj NUMBER (38, 10),
	gbo_look VARCHAR2 (1 CHAR),
	gbo_sspp VARCHAR2 (1 CHAR),
	member VARCHAR2 (32 CHAR),
	met_qty NUMBER (19, 2),
	method VARCHAR2 (1 CHAR),
	ndc VARCHAR2 (11 CHAR),
	new_met_qty NUMBER (19, 2),
	price_type VARCHAR2 (3 CHAR),
	pricing_var NUMBER (19, 4),
	rx_cf_dp NUMBER (19, 2),
	rx_cf_swp NUMBER (19, 2),
	rx_cf_wac NUMBER (19, 2),
	std_zero VARCHAR2 (1 CHAR),
	stdprice NUMBER (12, 5),
	tos_1 VARCHAR2 (13 CHAR),
	tos_2 VARCHAR2 (20 CHAR),
	tos_i VARCHAR2 (27 CHAR),
	uniq_rec_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_summary_all', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_summary_all (
	allowed NUMBER (38, 10),
	amt_outlier NUMBER (10, 0),
	los_outlier NUMBER (10, 0),
	negative_metqty NUMBER (10, 0),
	negative_orig NUMBER (10, 0),
	negative_orig_flag VARCHAR2 (1 CHAR),
	negative_requested NUMBER (10, 0),
	normalized NUMBER (38, 2),
	original NUMBER (38, 10),
	outliers NUMBER (10, 0),
	paid NUMBER (38, 10),
	place_of_service VARCHAR2 (150 CHAR),
	priced_flag VARCHAR2 (3 CHAR),
	pricing_method VARCHAR2 (150 CHAR),
	product VARCHAR2 (150 CHAR),
	record_type VARCHAR2 (37 CHAR),
	records NUMBER (10, 0),
	requested NUMBER (38, 10),
	service_category VARCHAR2 (100 CHAR),
	set_mod_used NUMBER (10, 0),
	specialty_level1 VARCHAR2 (12 CHAR),
	specialty_level2 VARCHAR2 (30 CHAR),
	specialty_level3 VARCHAR2 (40 CHAR),
	specialty_level4 VARCHAR2 (40 CHAR),
	type_of_service VARCHAR2 (255 CHAR),
	year NUMBER (10, 0),
	zero_metqty NUMBER (10, 0),
	zero_orig NUMBER (10, 0),
	zero_orig_flag VARCHAR2 (1 CHAR),
	zero_requtested NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_summary_conf', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_summary_conf (
	allowed NUMBER (38, 2),
	amt_cob NUMBER (38, 2),
	amt_coinsurance NUMBER (38, 2),
	amt_copay NUMBER (38, 2),
	amt_deduct NUMBER (38, 2),
	confinements NUMBER (10, 0),
	normalized NUMBER (38, 2),
	original NUMBER (38, 2),
	paid NUMBER (38, 2),
	product VARCHAR2 (150 CHAR),
	product_lv3 VARCHAR2 (150 CHAR),
	requested NUMBER (38, 2),
	service_category VARCHAR2 (100 CHAR),
	type_of_service VARCHAR2 (255 CHAR),
	year NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_summary_ptiles', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_summary_ptiles (
	avg_normalized_amt NUMBER (38, 10),
	avg_original_amt NUMBER (38, 10),
	modifier VARCHAR2 (15 CHAR),
	orig_tot NUMBER (38, 10),
	p10th NUMBER (38, 10),
	p25th NUMBER (38, 10),
	p50th NUMBER (38, 10),
	p75th NUMBER (38, 10),
	p90th NUMBER (38, 10),
	pct_outlier NUMBER (38, 10),
	pct_zero NUMBER (38, 10),
	proc_code VARCHAR2 (15 CHAR),
	procedure_desc VARCHAR2 (100 CHAR),
	product VARCHAR2 (150 CHAR),
	ratio NUMBER (38, 10),
	records NUMBER (10, 0),
	year VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_summary_tos_pmpm', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_summary_tos_pmpm (
	allowed NUMBER (38, 10),
	allowed_pmpm NUMBER (38, 10),
	member_months NUMBER (10, 0),
	normalized NUMBER (38, 2),
	normalized_pmpm NUMBER (38, 6),
	original NUMBER (38, 10),
	original_pmpm NUMBER (38, 10),
	paid NUMBER (38, 10),
	paid_pmpm NUMBER (38, 10),
	product VARCHAR2 (150 CHAR),
	requested NUMBER (38, 10),
	requested_pmpm NUMBER (38, 10),
	service_category VARCHAR2 (100 CHAR),
	type_of_service VARCHAR2 (255 CHAR),
	year VARCHAR2 (9 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_sspp_uniq_member', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_sspp_uniq_member (
	max_eff_dt TIMESTAMP,
	member VARCHAR2 (32 CHAR),
	nbr NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_subscriber', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_subscriber (
	account_id VARCHAR2 (40 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR),
	contract_id VARCHAR2 (40 CHAR),
	contract_type_id VARCHAR2 (40 CHAR),
	cust_sub_1 VARCHAR2 (255 CHAR),
	cust_sub_10 VARCHAR2 (255 CHAR),
	cust_sub_11 VARCHAR2 (255 CHAR),
	cust_sub_12 VARCHAR2 (255 CHAR),
	cust_sub_13 VARCHAR2 (255 CHAR),
	cust_sub_14 VARCHAR2 (255 CHAR),
	cust_sub_15 VARCHAR2 (255 CHAR),
	cust_sub_16 NUMBER (38, 10),
	cust_sub_17 NUMBER (38, 10),
	cust_sub_18 NUMBER (38, 10),
	cust_sub_19 NUMBER (38, 10),
	cust_sub_2 VARCHAR2 (255 CHAR),
	cust_sub_20 NUMBER (38, 10),
	cust_sub_3 VARCHAR2 (255 CHAR),
	cust_sub_4 VARCHAR2 (255 CHAR),
	cust_sub_5 VARCHAR2 (255 CHAR),
	cust_sub_6 VARCHAR2 (255 CHAR),
	cust_sub_7 VARCHAR2 (255 CHAR),
	cust_sub_8 VARCHAR2 (255 CHAR),
	cust_sub_9 VARCHAR2 (255 CHAR),
	cust_sub_pk_id VARCHAR2 (32 CHAR),
	eff_dt TIMESTAMP,
	end_dt TIMESTAMP,
	map_srce_e VARCHAR2 (6 CHAR),
	product_id VARCHAR2 (40 CHAR),
	risk_type_id VARCHAR2 (40 CHAR),
	subscriber_id VARCHAR2 (32 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('md_client', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE md_client (
	census_region VARCHAR2 (255 CHAR),
	client_id VARCHAR2 (16 CHAR),
	displayid VARCHAR2 (255 CHAR),
	external_id VARCHAR2 (255 CHAR),
	group_type VARCHAR2 (20 CHAR),
	has_cc VARCHAR2 (3 CHAR),
	has_pae VARCHAR2 (3 CHAR),
	has_pe VARCHAR2 (255 CHAR),
	has_reg VARCHAR2 (3 CHAR),
	is_retired VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_int_claim_labresult', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_int_claim_labresult (
	abnormal_flag VARCHAR2(249 CHAR) NULL,
	claim_header_id VARCHAR2(249 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	collection_date DATE  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(249 CHAR) NULL,
	fasting_status VARCHAR2(249 CHAR) NULL,
	groupid VARCHAR2(16 CHAR) NOT  NULL,
	labresult_id VARCHAR2(249 CHAR) NULL,
	loinc_code VARCHAR2(25 CHAR) NULL,
	loinc_name VARCHAR2(249 CHAR) NULL,
	member_dob DATE  NULL,
	member_eff_date DATE  NULL,
	member_end_date DATE  NULL,
	member_fname VARCHAR2(249 CHAR) NULL,
	member_gender_code VARCHAR2(10 CHAR) NULL,
	member_id VARCHAR2(249 CHAR) NULL,
	member_lname VARCHAR2(249 CHAR) NULL,
	member_mname VARCHAR2(249 CHAR) NULL,
	member_name VARCHAR2(249 CHAR) NULL,
	member_ssn NUMBER  NULL,
	modified_date TIMESTAMP,
	order_date DATE  NULL,
	ordering_prov_fname VARCHAR2(249 CHAR) NULL,
	ordering_prov_id VARCHAR2(249 CHAR) NULL,
	ordering_prov_lname VARCHAR2(249 CHAR) NULL,
	ordering_prov_mi VARCHAR2(249 CHAR) NULL,
	ordering_prov_name VARCHAR2(249 CHAR) NULL,
	ordering_prov_npi VARCHAR2(249 CHAR) NULL,
	ordering_prov_spclty_cd VARCHAR2(249 CHAR) NULL,
	ordering_prov_spclty_desc VARCHAR2(249 CHAR) NULL,
	pcp_end_date DATE  NULL,
	pcp_fname VARCHAR2(249 CHAR) NULL,
	pcp_id VARCHAR2(249 CHAR) NULL,
	pcp_lname VARCHAR2(249 CHAR) NULL,
	pcp_mi VARCHAR2(249 CHAR) NULL,
	pcp_name VARCHAR2(249 CHAR) NULL,
	pcp_npi VARCHAR2(249 CHAR) NULL,
	pcp_spclty_cd VARCHAR2(249 CHAR) NULL,
	pcp_spclty_desc VARCHAR2(249 CHAR) NULL,
	pcp_start_date DATE  NULL,
	reference_range VARCHAR2(249 CHAR) NULL,
	result_code VARCHAR2(249 CHAR) NULL,
	result_date DATE  NULL,
	result_name VARCHAR2(249 CHAR) NULL,
	row_source VARCHAR2 (10 CHAR),
	source_code VARCHAR2(249 CHAR) NULL,
	specimen_source VARCHAR2(249 CHAR) NULL,
	test_order_code VARCHAR2(249 CHAR) NULL,
	test_order_name VARCHAR2(249 CHAR) NULL,
	test_result_number NUMBER  NULL,
	test_result_text VARCHAR2(249 CHAR) NULL,
	test_result_units VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_int_claim_medical', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_int_claim_medical (
	adj_pre_flg_1 VARCHAR2(1 CHAR) NULL,
	adj_pre_flg_2 VARCHAR2(1 CHAR) NULL,
	adj_pre_flg_3 VARCHAR2(1 CHAR) NULL,
	admin_fee_amt NUMBER (38, 10),
	admit_date DATE  NULL,
	admit_prov_fname VARCHAR2(249 CHAR) NULL,
	admit_prov_id VARCHAR2(249 CHAR) NULL,
	admit_prov_lname VARCHAR2(249 CHAR) NULL,
	admit_prov_mi VARCHAR2(249 CHAR) NULL,
	admit_prov_name VARCHAR2(249 CHAR) NULL,
	admit_prov_npi VARCHAR2(249 CHAR) NULL,
	admit_prov_spclty_cd VARCHAR2(249 CHAR) NULL,
	admit_prov_spclty_desc VARCHAR2(249 CHAR) NULL,
	admit_source_code VARCHAR2(249 CHAR) NULL,
	admit_type_code VARCHAR2(249 CHAR) NULL,
	allowed_amt NUMBER  NULL,
	attnd_prov_fname VARCHAR2(249 CHAR) NULL,
	attnd_prov_id VARCHAR2(249 CHAR) NULL,
	attnd_prov_lname VARCHAR2(249 CHAR) NULL,
	attnd_prov_mi VARCHAR2(249 CHAR) NULL,
	attnd_prov_name VARCHAR2(249 CHAR) NULL,
	attnd_prov_npi VARCHAR2(249 CHAR) NULL,
	attnd_prov_spclty_cd VARCHAR2(249 CHAR) NULL,
	attnd_prov_spclty_desc VARCHAR2(249 CHAR) NULL,
	billing_prov_fname VARCHAR2(249 CHAR) NULL,
	billing_prov_id VARCHAR2(249 CHAR) NULL,
	billing_prov_lname VARCHAR2(249 CHAR) NULL,
	billing_prov_mi VARCHAR2(249 CHAR) NULL,
	billing_prov_name VARCHAR2(249 CHAR) NULL,
	billing_prov_npi VARCHAR2(249 CHAR) NULL,
	billing_prov_spclty_cd VARCHAR2(249 CHAR) NULL,
	billing_prov_spclty_desc VARCHAR2(249 CHAR) NULL,
	capitated_service_flag VARCHAR2(249 CHAR) NULL,
	capitation_amt NUMBER  NULL,
	claim_adj_type VARCHAR2(1 CHAR) NULL,
	claim_header_id VARCHAR2(249 CHAR) NULL,
	claim_line_id VARCHAR2(249 CHAR) NULL,
	claim_type VARCHAR2(249 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	coinsurance_amt NUMBER  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	coord_benifits_amt NUMBER  NULL,
	copay_amt NUMBER  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	deductable_amt NUMBER  NULL,
	denied_flag VARCHAR2(249 CHAR) NULL,
	denied_reason VARCHAR2(249 CHAR) NULL,
	diag_rel_grp_code VARCHAR2(249 CHAR) NULL,
	diag_rel_grp_grouper VARCHAR2(249 CHAR) NULL,
	diag_rel_grp_outlier VARCHAR2(249 CHAR) NULL,
	diag_rel_grp_rom VARCHAR2(10 CHAR) NULL,
	diag_rel_grp_severity VARCHAR2(249 CHAR) NULL,
	discharge_date DATE  NULL,
	discharge_status_code VARCHAR2(249 CHAR) NULL,
	ein VARCHAR2(249 CHAR) NULL,
	encounterid VARCHAR2(249 CHAR) NULL,
	facility_code VARCHAR2(249 CHAR) NULL,
	facility_name VARCHAR2(249 CHAR) NULL,
	fee_for_service_amt NUMBER  NULL,
	financial_class VARCHAR2(249 CHAR) NULL,
	groupid VARCHAR2(16 CHAR) NOT  NULL,
	icd_diag_cd1 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd10 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd10_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd10_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd10_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd11 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd11_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd11_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd11_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd12 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd12_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd12_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd12_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd13 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd13_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd13_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd13_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd14 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd14_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd14_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd14_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd15 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd15_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd15_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd15_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd16 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd16_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd16_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd16_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd17 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd17_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd17_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd17_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd18 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd18_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd18_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd18_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd19 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd19_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd19_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd19_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd1_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd1_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd1_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd2 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd20 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd20_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd20_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd20_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd21 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd21_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd21_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd21_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd22 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd22_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd22_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd22_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd23 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd23_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd23_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd23_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd2_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd2_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd2_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd3 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd3_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd3_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd3_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd4 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd4_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd4_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd4_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd5 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd5_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd5_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd5_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd6 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd6_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd6_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd6_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd7 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd7_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd7_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd7_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd8 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd8_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd8_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd8_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd9 VARCHAR2(249 CHAR) NULL,
	icd_diag_cd9_adm_diag_flag VARCHAR2(249 CHAR) NULL,
	icd_diag_cd9_poa_indicator VARCHAR2(249 CHAR) NULL,
	icd_diag_cd9_type VARCHAR2(249 CHAR) NULL,
	icd_diag_cd_24 VARCHAR2 (249 CHAR),
	icd_diag_cd_24_type VARCHAR2 (249 CHAR),
	icd_diag_cd_25 VARCHAR2 (249 CHAR),
	icd_diag_cd_25_type VARCHAR2 (249 CHAR),
	icd_diag_cd_type_24_poa_ind VARCHAR2 (249 CHAR),
	icd_diag_cd_type_25_poa_ind VARCHAR2 (249 CHAR),
	icd_proc_cd_1 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_10 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_10_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_11 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_11_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_12 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_12_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_13 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_13_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_14 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_14_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_15 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_15_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_16 VARCHAR2 (249 CHAR),
	icd_proc_cd_16_type VARCHAR2 (249 CHAR),
	icd_proc_cd_17 VARCHAR2 (249 CHAR),
	icd_proc_cd_17_type VARCHAR2 (249 CHAR),
	icd_proc_cd_18 VARCHAR2 (249 CHAR),
	icd_proc_cd_18_type VARCHAR2 (249 CHAR),
	icd_proc_cd_19 VARCHAR2 (249 CHAR),
	icd_proc_cd_19_type VARCHAR2 (249 CHAR),
	icd_proc_cd_1_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_2 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_20 VARCHAR2 (249 CHAR),
	icd_proc_cd_20_type VARCHAR2 (249 CHAR),
	icd_proc_cd_21 VARCHAR2 (249 CHAR),
	icd_proc_cd_21_type VARCHAR2 (249 CHAR),
	icd_proc_cd_22 VARCHAR2 (249 CHAR),
	icd_proc_cd_22_type VARCHAR2 (249 CHAR),
	icd_proc_cd_23 VARCHAR2 (249 CHAR),
	icd_proc_cd_23_type VARCHAR2 (249 CHAR),
	icd_proc_cd_24 VARCHAR2 (249 CHAR),
	icd_proc_cd_24_type VARCHAR2 (249 CHAR),
	icd_proc_cd_25 VARCHAR2 (249 CHAR),
	icd_proc_cd_25_type VARCHAR2 (249 CHAR),
	icd_proc_cd_2_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_3 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_3_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_4 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_4_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_5 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_5_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_6 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_6_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_7 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_7_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_8 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_8_type VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_9 VARCHAR2(249 CHAR) NULL,
	icd_proc_cd_9_type VARCHAR2(249 CHAR) NULL,
	ii_cust_attr_1 VARCHAR2 (255 CHAR),
	ii_cust_attr_10 VARCHAR2 (255 CHAR),
	ii_cust_attr_11 VARCHAR2 (255 CHAR),
	ii_cust_attr_12 VARCHAR2 (255 CHAR),
	ii_cust_attr_13 VARCHAR2 (255 CHAR),
	ii_cust_attr_14 VARCHAR2 (255 CHAR),
	ii_cust_attr_15 VARCHAR2 (255 CHAR),
	ii_cust_attr_16 NUMBER (38, 10),
	ii_cust_attr_17 NUMBER (38, 10),
	ii_cust_attr_18 NUMBER (38, 10),
	ii_cust_attr_19 NUMBER (38, 10),
	ii_cust_attr_2 VARCHAR2 (255 CHAR),
	ii_cust_attr_20 NUMBER (38, 10),
	ii_cust_attr_3 VARCHAR2 (255 CHAR),
	ii_cust_attr_4 VARCHAR2 (255 CHAR),
	ii_cust_attr_5 VARCHAR2 (255 CHAR),
	ii_cust_attr_6 VARCHAR2 (255 CHAR),
	ii_cust_attr_7 VARCHAR2 (255 CHAR),
	ii_cust_attr_8 VARCHAR2 (255 CHAR),
	ii_cust_attr_9 VARCHAR2 (255 CHAR),
	medical_benefit_flag VARCHAR2(20 CHAR) NULL,
	member_dob DATE  NULL,
	member_eff_date DATE  NULL,
	member_end_date DATE  NULL,
	member_fname VARCHAR2(249 CHAR) NULL,
	member_gender_code VARCHAR2(10 CHAR) NULL,
	member_id VARCHAR2(249 CHAR) NULL,
	member_lname VARCHAR2(249 CHAR) NULL,
	member_mname VARCHAR2(249 CHAR) NULL,
	member_name VARCHAR2(249 CHAR) NULL,
	member_ssn NUMBER  NULL,
	modified_date TIMESTAMP,
	network_paid_status VARCHAR2(30 CHAR) NULL,
	network_status_flag VARCHAR2(249 CHAR) NULL,
	not_covered_amt NUMBER (38, 10),
	ordering_prov_id VARCHAR2(249 CHAR) NULL,
	other_1_amt NUMBER (38, 10),
	other_2_amt NUMBER (38, 10),
	other_3_amt NUMBER (38, 10),
	other_4_amt NUMBER (38, 10),
	other_carrier_pay_amt NUMBER (38, 10),
	par_flag VARCHAR2(1 CHAR) NULL,
	pat_liability_amt NUMBER  NULL,
	pay_process_date DATE  NULL,
	payer_code VARCHAR2(249 CHAR) NULL,
	payer_name VARCHAR2(249 CHAR) NULL,
	payment_amt NUMBER  NULL,
	pcp_end_date DATE  NULL,
	pcp_fname VARCHAR2(249 CHAR) NULL,
	pcp_id VARCHAR2(249 CHAR) NULL,
	pcp_lname VARCHAR2(249 CHAR) NULL,
	pcp_mi VARCHAR2(249 CHAR) NULL,
	pcp_name VARCHAR2(249 CHAR) NULL,
	pcp_npi VARCHAR2(249 CHAR) NULL,
	pcp_spclty_cd VARCHAR2(249 CHAR) NULL,
	pcp_spclty_desc VARCHAR2(249 CHAR) NULL,
	pcp_start_date DATE  NULL,
	pharmacy_benefit_flag VARCHAR2(20 CHAR) NULL,
	place_of_service VARCHAR2(249 CHAR) NULL,
	plan_code VARCHAR2(249 CHAR) NULL,
	plan_name VARCHAR2(249 CHAR) NULL,
	policy_nbr VARCHAR2(249 CHAR) NULL,
	principle_proc_cd VARCHAR2(249 CHAR) NULL,
	principle_proc_icd_type VARCHAR2(249 CHAR) NULL,
	proc_cd_modifier_1 VARCHAR2(249 CHAR) NULL,
	proc_cd_modifier_2 VARCHAR2(249 CHAR) NULL,
	proc_cd_modifier_3 VARCHAR2(249 CHAR) NULL,
	proc_code VARCHAR2(249 CHAR) NULL,
	product_code VARCHAR2(249 CHAR) NULL,
	product_name VARCHAR2(249 CHAR) NULL,
	pseudo_flag VARCHAR2(249 CHAR) NULL,
	quantity_of_service VARCHAR2(249 CHAR) NULL,
	referring_prov_id VARCHAR2(249 CHAR) NULL,
	requested_amt NUMBER  NULL,
	revenue_code VARCHAR2(249 CHAR) NULL,
	row_source VARCHAR2 (10 CHAR),
	serv_prov_affil_id VARCHAR2 (30 CHAR),
	serv_prov_status_id VARCHAR2 (30 CHAR),
	service_date DATE  NULL,
	service_from_date DATE  NULL,
	service_to_date DATE  NULL,
	servicing_prov_fname VARCHAR2(249 CHAR) NULL,
	servicing_prov_id VARCHAR2(249 CHAR) NULL,
	servicing_prov_lname VARCHAR2(249 CHAR) NULL,
	servicing_prov_mi VARCHAR2(249 CHAR) NULL,
	servicing_prov_name VARCHAR2(249 CHAR) NULL,
	servicing_prov_npi VARCHAR2(249 CHAR) NULL,
	servicing_prov_spclty_cd VARCHAR2(249 CHAR) NULL,
	servicing_prov_spclty_desc VARCHAR2(249 CHAR) NULL,
	source_code VARCHAR2(249 CHAR) NULL,
	submitted_date DATE  NULL,
	type_of_bill_code VARCHAR2(249 CHAR) NULL,
	type_of_service VARCHAR2(249 CHAR) NULL,
	withhold_amt NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_int_claim_member', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_int_claim_member (
	alternate_member_id VARCHAR2(249 CHAR) NULL,
	alternate_member_id_2 VARCHAR2 (249 CHAR),
	benefit_plan_code VARCHAR2(249 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	contract_type_code VARCHAR2(249 CHAR) NULL,
	coverage_class_code VARCHAR2(249 CHAR) NULL,
	coverage_status_code VARCHAR2(249 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dental_benefit_ind NUMBER (10, 0),
	eligibile_member_month VARCHAR2(249 CHAR) NULL,
	emp_acct_id VARCHAR2(249 CHAR) NULL,
	employee_type VARCHAR2 (30 CHAR),
	financial_class VARCHAR2(249 CHAR) NULL,
	groupid VARCHAR2(16 CHAR) NOT  NULL,
	hicn VARCHAR2(249 CHAR) NULL,
	hra_ind NUMBER (10, 0),
	hsa_ind NUMBER (10, 0),
	ii_cust_attr_1 VARCHAR2 (255 CHAR),
	ii_cust_attr_10 VARCHAR2 (255 CHAR),
	ii_cust_attr_11 VARCHAR2 (255 CHAR),
	ii_cust_attr_12 VARCHAR2 (255 CHAR),
	ii_cust_attr_13 VARCHAR2 (255 CHAR),
	ii_cust_attr_14 VARCHAR2 (255 CHAR),
	ii_cust_attr_15 VARCHAR2 (255 CHAR),
	ii_cust_attr_16 NUMBER (38, 10),
	ii_cust_attr_17 NUMBER (38, 10),
	ii_cust_attr_18 NUMBER (38, 10),
	ii_cust_attr_19 NUMBER (38, 10),
	ii_cust_attr_2 VARCHAR2 (255 CHAR),
	ii_cust_attr_20 NUMBER (38, 10),
	ii_cust_attr_3 VARCHAR2 (255 CHAR),
	ii_cust_attr_4 VARCHAR2 (255 CHAR),
	ii_cust_attr_5 VARCHAR2 (255 CHAR),
	ii_cust_attr_6 VARCHAR2 (255 CHAR),
	ii_cust_attr_7 VARCHAR2 (255 CHAR),
	ii_cust_attr_8 VARCHAR2 (255 CHAR),
	ii_cust_attr_9 VARCHAR2 (255 CHAR),
	ii_mem_userdef_1 VARCHAR2 (30 CHAR),
	ii_mem_userdef_2 VARCHAR2 (30 CHAR),
	ii_mem_userdef_3 VARCHAR2 (30 CHAR),
	ii_mem_userdef_4 VARCHAR2 (30 CHAR),
	medical_benefit_flag VARCHAR2(249 CHAR) NULL,
	member_addr_1 VARCHAR2(249 CHAR) NULL,
	member_addr_2 VARCHAR2(249 CHAR) NULL,
	member_addr_lat NUMBER (9, 6),
	member_city VARCHAR2(249 CHAR) NULL,
	member_death_ind VARCHAR2(20 CHAR) NULL,
	member_dob DATE  NULL,
	member_dod DATE  NULL,
	member_eff_date DATE  NULL,
	member_email VARCHAR2(249 CHAR) NULL,
	member_end_date DATE  NULL,
	member_ethnicity VARCHAR2(249 CHAR) NULL,
	member_fname VARCHAR2(249 CHAR) NULL,
	member_gender_code VARCHAR2(10 CHAR) NULL,
	member_id VARCHAR2(249 CHAR) NULL,
	member_language VARCHAR2(249 CHAR) NULL,
	member_lname VARCHAR2(249 CHAR) NULL,
	member_marital_status VARCHAR2(249 CHAR) NULL,
	member_mname VARCHAR2(249 CHAR) NULL,
	member_name VARCHAR2(249 CHAR) NULL,
	member_nationality VARCHAR2(249 CHAR) NULL,
	member_phone VARCHAR2(30 CHAR) NULL,
	member_race VARCHAR2(249 CHAR) NULL,
	member_ssn VARCHAR2(30 CHAR) NULL,
	member_state_code VARCHAR2(20 CHAR) NULL,
	member_zip_code VARCHAR2(20 CHAR) NULL,
	mh_benefit_ind NUMBER (10, 0),
	modified_date TIMESTAMP,
	payer_code VARCHAR2(249 CHAR) NULL,
	payer_name VARCHAR2(249 CHAR) NULL,
	pcp_end_date DATE  NULL,
	pcp_fname VARCHAR2(249 CHAR) NULL,
	pcp_id VARCHAR2(249 CHAR) NULL,
	pcp_lname VARCHAR2(249 CHAR) NULL,
	pcp_mi VARCHAR2(249 CHAR) NULL,
	pcp_name VARCHAR2(249 CHAR) NULL,
	pcp_npi VARCHAR2(249 CHAR) NULL,
	pcp_prov_affil_id VARCHAR2 (30 CHAR),
	pcp_spclty_cd VARCHAR2(249 CHAR) NULL,
	pcp_spclty_desc VARCHAR2(249 CHAR) NULL,
	pcp_start_date DATE  NULL,
	pharmacy_benefit_flag VARCHAR2(249 CHAR) NULL,
	plan_code VARCHAR2(249 CHAR) NULL,
	plan_name VARCHAR2(249 CHAR) NULL,
	product_code VARCHAR2(249 CHAR) NULL,
	product_name VARCHAR2(249 CHAR) NULL,
	row_source VARCHAR2 (10 CHAR),
	source_code VARCHAR2(249 CHAR) NULL,
	subscriber_flag VARCHAR2(249 CHAR) NULL,
	subscriber_id VARCHAR2(249 CHAR) NULL,
	subscriber_ssn VARCHAR2 (30 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_int_claim_pharm', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_int_claim_pharm (
	adj_pre_flg_1 VARCHAR2(1 CHAR) NULL,
	adj_pre_flg_2 VARCHAR2(1 CHAR) NULL,
	adj_pre_flg_3 VARCHAR2(1 CHAR) NULL,
	adjusted_rx_cnt NUMBER (10, 0),
	admin_fee_amt NUMBER (38, 10),
	allowed_amount NUMBER  NULL,
	capitated_service_ind NUMBER (10, 0),
	claim_adj_type VARCHAR2(1 CHAR) NULL,
	claim_id VARCHAR2(249 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	coinsurance_amount NUMBER  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	coord_benefits_amt NUMBER (38, 10),
	copay_amount NUMBER  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	days_supply NUMBER  NULL,
	deductible_amount NUMBER  NULL,
	denied_flag VARCHAR2(249 CHAR) NULL,
	denied_reason VARCHAR2(249 CHAR) NULL,
	dispensing_fee NUMBER  NULL,
	encounterid VARCHAR2(249 CHAR) NULL,
	formulary_indicator VARCHAR2(249 CHAR) NULL,
	fulfillment_type_cd VARCHAR2 (249 CHAR),
	generic_status VARCHAR2(249 CHAR) NULL,
	groupid VARCHAR2(16 CHAR) NOT  NULL,
	ii_cust_attr_1 VARCHAR2 (255 CHAR),
	ii_cust_attr_10 VARCHAR2 (255 CHAR),
	ii_cust_attr_11 VARCHAR2 (255 CHAR),
	ii_cust_attr_12 VARCHAR2 (255 CHAR),
	ii_cust_attr_13 VARCHAR2 (255 CHAR),
	ii_cust_attr_14 VARCHAR2 (255 CHAR),
	ii_cust_attr_15 VARCHAR2 (255 CHAR),
	ii_cust_attr_16 NUMBER (38, 10),
	ii_cust_attr_17 NUMBER (38, 10),
	ii_cust_attr_18 NUMBER (38, 10),
	ii_cust_attr_19 NUMBER (38, 10),
	ii_cust_attr_2 VARCHAR2 (255 CHAR),
	ii_cust_attr_20 NUMBER (38, 10),
	ii_cust_attr_3 VARCHAR2 (255 CHAR),
	ii_cust_attr_4 VARCHAR2 (255 CHAR),
	ii_cust_attr_5 VARCHAR2 (255 CHAR),
	ii_cust_attr_6 VARCHAR2 (255 CHAR),
	ii_cust_attr_7 VARCHAR2 (255 CHAR),
	ii_cust_attr_8 VARCHAR2 (255 CHAR),
	ii_cust_attr_9 VARCHAR2 (255 CHAR),
	ingredient_cost_paid NUMBER  NULL,
	localdaw VARCHAR2 (255 CHAR),
	member_dob DATE  NULL,
	member_eff_date DATE  NULL,
	member_end_date DATE  NULL,
	member_fname VARCHAR2(249 CHAR) NULL,
	member_gender_code VARCHAR2(10 CHAR) NULL,
	member_id VARCHAR2(249 CHAR) NULL,
	member_lname VARCHAR2(249 CHAR) NULL,
	member_mname VARCHAR2(249 CHAR) NULL,
	member_name VARCHAR2(249 CHAR) NULL,
	member_ssn NUMBER  NULL,
	metric_quantity NUMBER  NULL,
	modified_date TIMESTAMP,
	ndc VARCHAR2(249 CHAR) NULL,
	ndc_name VARCHAR2(249 CHAR) NULL,
	network_paid_status VARCHAR2(30 CHAR) NULL,
	network_status_flag VARCHAR2(249 CHAR) NULL,
	not_covered_amt NUMBER (38, 10),
	other_1_amt NUMBER (38, 10),
	other_2_amt NUMBER (38, 10),
	other_3_amt NUMBER (38, 10),
	other_4_amt NUMBER (38, 10),
	other_carrier_pay_amt NUMBER (38, 10),
	patient_liability_amount NUMBER  NULL,
	pay_process_date DATE  NULL,
	payment_amount NUMBER  NULL,
	pcp_end_date DATE  NULL,
	pcp_fname VARCHAR2(249 CHAR) NULL,
	pcp_id VARCHAR2(249 CHAR) NULL,
	pcp_lname VARCHAR2(249 CHAR) NULL,
	pcp_mi VARCHAR2(249 CHAR) NULL,
	pcp_name VARCHAR2(249 CHAR) NULL,
	pcp_npi VARCHAR2(249 CHAR) NULL,
	pcp_spclty_cd VARCHAR2(249 CHAR) NULL,
	pcp_spclty_desc VARCHAR2(249 CHAR) NULL,
	pcp_start_date DATE  NULL,
	pharmacy_id VARCHAR2(249 CHAR) NULL,
	pharmacy_name VARCHAR2(249 CHAR) NULL,
	pharmacy_type_code VARCHAR2(249 CHAR) NULL,
	presc_prov_affil_id VARCHAR2 (30 CHAR),
	presc_prov_fname VARCHAR2(249 CHAR) NULL,
	presc_prov_id VARCHAR2(249 CHAR) NULL,
	presc_prov_lname VARCHAR2(249 CHAR) NULL,
	presc_prov_mi VARCHAR2(249 CHAR) NULL,
	presc_prov_name VARCHAR2(249 CHAR) NULL,
	presc_prov_npi VARCHAR2(249 CHAR) NULL,
	presc_prov_spclty_cd VARCHAR2(249 CHAR) NULL,
	presc_prov_spclty_desc VARCHAR2(249 CHAR) NULL,
	presc_prov_status_id VARCHAR2 (30 CHAR),
	pseudo_flag VARCHAR2(249 CHAR) NULL,
	quantity_per_fill NUMBER  NULL,
	refill_num NUMBER (10, 0),
	requested_amount NUMBER  NULL,
	row_source VARCHAR2 (10 CHAR),
	rx_id VARCHAR2(249 CHAR) NULL,
	sales_tax_amt NUMBER (38, 10),
	service_date DATE  NULL,
	source_code VARCHAR2(249 CHAR) NULL,
	spec_rx_ind VARCHAR2 (30 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_int_claim_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_int_claim_prov (
	client_ds_id NUMBER  NOT NULL,
	cust_attr_1 VARCHAR2(255 CHAR) NULL,
	cust_attr_10 VARCHAR2(255 CHAR) NULL,
	cust_attr_11 VARCHAR2(255 CHAR) NULL,
	cust_attr_12 VARCHAR2(255 CHAR) NULL,
	cust_attr_13 VARCHAR2(255 CHAR) NULL,
	cust_attr_14 VARCHAR2(255 CHAR) NULL,
	cust_attr_15 VARCHAR2(255 CHAR) NULL,
	cust_attr_16 NUMBER  NULL,
	cust_attr_17 NUMBER  NULL,
	cust_attr_18 NUMBER  NULL,
	cust_attr_19 NUMBER  NULL,
	cust_attr_2 VARCHAR2(255 CHAR) NULL,
	cust_attr_20 NUMBER  NULL,
	cust_attr_3 VARCHAR2(255 CHAR) NULL,
	cust_attr_4 VARCHAR2(255 CHAR) NULL,
	cust_attr_5 VARCHAR2(255 CHAR) NULL,
	cust_attr_6 VARCHAR2(255 CHAR) NULL,
	cust_attr_7 VARCHAR2(255 CHAR) NULL,
	cust_attr_8 VARCHAR2(255 CHAR) NULL,
	cust_attr_9 VARCHAR2(255 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dea_number VARCHAR2(249 CHAR) NULL,
	eff_date DATE  NULL,
	end_date DATE  NULL,
	groupid VARCHAR2(16 CHAR) NOT  NULL,
	ii_prov_userdef_1 VARCHAR2 (30 CHAR),
	ii_prov_userdef_2 VARCHAR2 (30 CHAR),
	master_id VARCHAR2 (20 CHAR),
	modified_date TIMESTAMP,
	pcp_flag VARCHAR2(10 CHAR) NULL,
	primary_span VARCHAR2 (1 CHAR),
	prov_addr_1 VARCHAR2(249 CHAR) NULL,
	prov_addr_2 VARCHAR2(249 CHAR) NULL,
	prov_addr_lat NUMBER (38, 10),
	prov_addr_lon NUMBER (38, 10),
	prov_affil_id VARCHAR2(30 CHAR) NULL,
	prov_city VARCHAR2(249 CHAR) NULL,
	prov_credentials VARCHAR2(249 CHAR) NULL,
	prov_email VARCHAR2(249 CHAR) NULL,
	prov_fname VARCHAR2(249 CHAR) NULL,
	prov_id VARCHAR2(249 CHAR) NULL,
	prov_lname VARCHAR2(249 CHAR) NULL,
	prov_mi VARCHAR2(249 CHAR) NULL,
	prov_name VARCHAR2(249 CHAR) NULL,
	prov_npi VARCHAR2(249 CHAR) NULL,
	prov_phone VARCHAR2(30 CHAR) NULL,
	prov_sec_spclty_cd VARCHAR2(249 CHAR) NULL,
	prov_spclty_cd VARCHAR2(249 CHAR) NULL,
	prov_state_code VARCHAR2(20 CHAR) NULL,
	prov_status_id VARCHAR2(30 CHAR) NULL,
	prov_type_code VARCHAR2(249 CHAR) NULL,
	prov_zip_code VARCHAR2(20 CHAR) NULL,
	provider_region VARCHAR2(249 CHAR) NULL,
	row_source VARCHAR2 (10 CHAR),
	source_code VARCHAR2(249 CHAR) NULL,
	update_dt DATE  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_diagnosis', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_diagnosis (
	codetype VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	is_ambulatory NUMBER (1) NULL,
	mappedcode VARCHAR2(50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_hts_dcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_hts_dcc (
	dcc VARCHAR2(249 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	hts_cui VARCHAR2(8 CHAR) NOT  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_hts_term', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_hts_term (
	dts_version NUMBER  NULL,
	hts_cui VARCHAR2(249 CHAR)  NULL,
	preferred VARCHAR2(249 CHAR) NULL,
	term_code VARCHAR2(249 CHAR) NULL,
	terminology_cui VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_procedure', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_procedure (
	codetype VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	is_ambulatory NUMBER (1) NULL,
	mappedcode VARCHAR2(50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_provider_taxonomy', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_provider_taxonomy (
	dts_version NUMBER  NULL,
	ii_code VARCHAR2(249 CHAR) NULL,
	specialty_cui VARCHAR2(8 CHAR) NOT NULL,
	taxonomy_code VARCHAR2(10 CHAR) NOT  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_qual_text_result', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_qual_text_result (
	dts_version NUMBER  NOT NULL,
	lab_code VARCHAR2(255 CHAR)  NULL,
	qual_result_code VARCHAR2(255 CHAR) NULL,
	txt_pattern VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_lab', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_lab (
	cui VARCHAR2(20 CHAR) NOT  NULL,
	dts_version NUMBER  NOT NULL,
	local_name VARCHAR2(150 CHAR) NULL,
	modified_date TIMESTAMP,
	notes VARCHAR2(4000 CHAR) NULL,
	ref_range_max VARCHAR2(150 CHAR) NULL,
	ref_range_min VARCHAR2(150 CHAR) NULL,
	result_type VARCHAR2(2000 CHAR) NULL,
	row_source VARCHAR2 (10 CHAR),
	semantic_val_max VARCHAR2(150 CHAR) NULL,
	semantic_val_min VARCHAR2(150 CHAR) NULL,
	sensitive_ind NUMBER (1) NULL,
	unit VARCHAR2(200 CHAR) NULL,
	usage VARCHAR2(150 CHAR) NULL,
	validated_ind NUMBER (1) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('md_med_schedule', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE md_med_schedule (
	cui VARCHAR2 (50 CHAR),
	dts_version NUMBER (10, 0),
	frequency NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_mv_client_data_src', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_mv_client_data_src (
	"PRIORITY" NUMBER (10, 0),
	abbreviation VARCHAR2(10 CHAR) NULL,
	alias_of_id NUMBER  NULL,
	client_data_src_id NUMBER (10) NOT  NULL,
	client_data_src_name VARCHAR2(255 CHAR) NOT NULL,
	client_id VARCHAR2(16 CHAR) NULL,
	data_src_id NUMBER (10) NULL,
	data_src_name VARCHAR2(255 CHAR) NULL,
	db_schema VARCHAR2(32 CHAR) NULL,
	dcdr_exclude CHAR(1) NULL,
	display_name VARCHAR2(255 CHAR) NULL,
	external_ds_id VARCHAR2(255 CHAR) NULL,
	final_release VARCHAR2(8 CHAR) NULL,
	included_data_types NUMBER  NULL,
	included_domains NUMBER  NULL,
	initial_release VARCHAR2(8 CHAR) NULL,
	is_shared CHAR(1) NULL,
	modified_date TIMESTAMP,
	row_source VARCHAR2 (10 CHAR),
	status_cd VARCHAR2(3 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('md_client_data_src', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE md_client_data_src (
	"PRIORITY" NUMBER (10, 0),
	abbreviation VARCHAR2 (10 CHAR),
	alias_of_id NUMBER (10, 0),
	client_data_src_id NUMBER (10, 0),
	client_data_src_name VARCHAR2 (255 CHAR),
	client_id VARCHAR2 (16 CHAR),
	data_src_id NUMBER (10, 0),
	data_src_name VARCHAR2 (255 CHAR),
	db_schema VARCHAR2 (32 CHAR),
	dcdr_exclude VARCHAR2 (1 CHAR),
	display_name VARCHAR2 (255 CHAR),
	external_ds_id VARCHAR2 (255 CHAR),
	final_release VARCHAR2 (8 CHAR),
	included_data_types NUMBER (10, 0),
	included_domains NUMBER (10, 0),
	initial_release VARCHAR2 (8 CHAR),
	is_shared VARCHAR2 (1 CHAR),
	status_cd VARCHAR2 (3 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_mv_hts_domain_concept', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_mv_hts_domain_concept (
	concept_cui VARCHAR2(50 CHAR)  NULL,
	concept_name VARCHAR2(100 CHAR) NULL,
	domain_cui VARCHAR2(50 CHAR) NULL,
	domain_name VARCHAR2(100 CHAR) NULL,
	first_valid_dt DATE  NULL,
	is_other VARCHAR2(255 CHAR) NULL,
	is_valid CHAR(1) NULL,
	last_valid_dt DATE  NULL,
	modified_date TIMESTAMP,
	row_source VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_org_rollup', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_org_rollup (
	client_ds_id NUMBER (10, 0),
	groupid VARCHAR2 (16 CHAR),
	modified_date TIMESTAMP,
	org_cd VARCHAR2 (150 CHAR),
	org_desc VARCHAR2 (150 CHAR),
	org_lv1_cd VARCHAR2 (150 CHAR),
	org_lv1_desc VARCHAR2 (150 CHAR),
	org_lv2_cd VARCHAR2 (150 CHAR),
	org_lv2_desc VARCHAR2 (150 CHAR),
	row_source VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patientdetailtype', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patientdetailtype (
	detailtypedesc VARCHAR2(100 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	patientdetailtype VARCHAR2(32 CHAR) NOT  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_provider_role_rank', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_provider_role_rank (
	dts_version NUMBER  NOT NULL,
	provider_role_cui VARCHAR2(8 CHAR) NOT  NULL,
	rank VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_acs_5yr_b15002', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_acs_5yr_b15002 (
	fileid NUMBER   NULL,
	geo_display_label VARCHAR2(249 CHAR) NULL,
	geo_id VARCHAR2(249 CHAR) NULL,
	geo_id2 VARCHAR2(249 CHAR) NULL,
	hd01_vd01 VARCHAR2(249 CHAR) NULL,
	hd01_vd02 VARCHAR2(249 CHAR) NULL,
	hd01_vd03 VARCHAR2(249 CHAR) NULL,
	hd01_vd04 VARCHAR2(249 CHAR) NULL,
	hd01_vd05 VARCHAR2(249 CHAR) NULL,
	hd01_vd06 VARCHAR2(249 CHAR) NULL,
	hd01_vd07 VARCHAR2(249 CHAR) NULL,
	hd01_vd08 VARCHAR2(249 CHAR) NULL,
	hd01_vd09 VARCHAR2(249 CHAR) NULL,
	hd01_vd10 VARCHAR2(249 CHAR) NULL,
	hd01_vd11 VARCHAR2(249 CHAR) NULL,
	hd01_vd12 VARCHAR2(249 CHAR) NULL,
	hd01_vd13 VARCHAR2(249 CHAR) NULL,
	hd01_vd14 VARCHAR2(249 CHAR) NULL,
	hd01_vd15 VARCHAR2(249 CHAR) NULL,
	hd01_vd16 VARCHAR2(249 CHAR) NULL,
	hd01_vd17 VARCHAR2(249 CHAR) NULL,
	hd01_vd18 VARCHAR2(249 CHAR) NULL,
	hd01_vd19 VARCHAR2(249 CHAR) NULL,
	hd01_vd20 VARCHAR2(249 CHAR) NULL,
	hd01_vd21 VARCHAR2(249 CHAR) NULL,
	hd01_vd22 VARCHAR2(249 CHAR) NULL,
	hd01_vd23 VARCHAR2(249 CHAR) NULL,
	hd01_vd24 VARCHAR2(249 CHAR) NULL,
	hd01_vd25 VARCHAR2(249 CHAR) NULL,
	hd01_vd26 VARCHAR2(249 CHAR) NULL,
	hd01_vd27 VARCHAR2(249 CHAR) NULL,
	hd01_vd28 VARCHAR2(249 CHAR) NULL,
	hd01_vd29 VARCHAR2(249 CHAR) NULL,
	hd01_vd30 VARCHAR2(249 CHAR) NULL,
	hd01_vd31 VARCHAR2(249 CHAR) NULL,
	hd01_vd32 VARCHAR2(249 CHAR) NULL,
	hd01_vd33 VARCHAR2(249 CHAR) NULL,
	hd01_vd34 VARCHAR2(249 CHAR) NULL,
	hd01_vd35 VARCHAR2(249 CHAR) NULL,
	hd02_vd01 VARCHAR2(249 CHAR) NULL,
	hd02_vd02 VARCHAR2(249 CHAR) NULL,
	hd02_vd03 VARCHAR2(249 CHAR) NULL,
	hd02_vd04 VARCHAR2(249 CHAR) NULL,
	hd02_vd05 VARCHAR2(249 CHAR) NULL,
	hd02_vd06 VARCHAR2(249 CHAR) NULL,
	hd02_vd07 VARCHAR2(249 CHAR) NULL,
	hd02_vd08 VARCHAR2(249 CHAR) NULL,
	hd02_vd09 VARCHAR2(249 CHAR) NULL,
	hd02_vd10 VARCHAR2(249 CHAR) NULL,
	hd02_vd11 VARCHAR2(249 CHAR) NULL,
	hd02_vd12 VARCHAR2(249 CHAR) NULL,
	hd02_vd13 VARCHAR2(249 CHAR) NULL,
	hd02_vd14 VARCHAR2(249 CHAR) NULL,
	hd02_vd15 VARCHAR2(249 CHAR) NULL,
	hd02_vd16 VARCHAR2(249 CHAR) NULL,
	hd02_vd17 VARCHAR2(249 CHAR) NULL,
	hd02_vd18 VARCHAR2(249 CHAR) NULL,
	hd02_vd19 VARCHAR2(249 CHAR) NULL,
	hd02_vd20 VARCHAR2(249 CHAR) NULL,
	hd02_vd21 VARCHAR2(249 CHAR) NULL,
	hd02_vd22 VARCHAR2(249 CHAR) NULL,
	hd02_vd23 VARCHAR2(249 CHAR) NULL,
	hd02_vd24 VARCHAR2(249 CHAR) NULL,
	hd02_vd25 VARCHAR2(249 CHAR) NULL,
	hd02_vd26 VARCHAR2(249 CHAR) NULL,
	hd02_vd27 VARCHAR2(249 CHAR) NULL,
	hd02_vd28 VARCHAR2(249 CHAR) NULL,
	hd02_vd29 VARCHAR2(249 CHAR) NULL,
	hd02_vd30 VARCHAR2(249 CHAR) NULL,
	hd02_vd31 VARCHAR2(249 CHAR) NULL,
	hd02_vd32 VARCHAR2(249 CHAR) NULL,
	hd02_vd33 VARCHAR2(249 CHAR) NULL,
	hd02_vd34 VARCHAR2(249 CHAR) NULL,
	hd02_vd35 VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_acs_5yr_c17002', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_acs_5yr_c17002 (
	fileid NUMBER   NULL,
	geo_display_label VARCHAR2(249 CHAR) NULL,
	geo_id VARCHAR2(249 CHAR) NULL,
	geo_id2 VARCHAR2(249 CHAR) NULL,
	hd01_vd01 VARCHAR2(249 CHAR) NULL,
	hd01_vd02 VARCHAR2(249 CHAR) NULL,
	hd01_vd03 VARCHAR2(249 CHAR) NULL,
	hd01_vd04 VARCHAR2(249 CHAR) NULL,
	hd01_vd05 VARCHAR2(249 CHAR) NULL,
	hd01_vd06 VARCHAR2(249 CHAR) NULL,
	hd01_vd07 VARCHAR2(249 CHAR) NULL,
	hd01_vd08 VARCHAR2(249 CHAR) NULL,
	hd02_vd01 VARCHAR2(249 CHAR) NULL,
	hd02_vd02 VARCHAR2(249 CHAR) NULL,
	hd02_vd03 VARCHAR2(249 CHAR) NULL,
	hd02_vd04 VARCHAR2(249 CHAR) NULL,
	hd02_vd05 VARCHAR2(249 CHAR) NULL,
	hd02_vd06 VARCHAR2(249 CHAR) NULL,
	hd02_vd07 VARCHAR2(249 CHAR) NULL,
	hd02_vd08 VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_acs_5yr_dp03', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_acs_5yr_dp03 (
	fileid NUMBER   NULL,
	geo_display_label VARCHAR2(249 CHAR) NULL,
	geo_id VARCHAR2(249 CHAR) NULL,
	geo_id2 VARCHAR2(249 CHAR) NULL,
	hc01_vc03 VARCHAR2(249 CHAR) NULL,
	hc01_vc04 VARCHAR2(249 CHAR) NULL,
	hc01_vc05 VARCHAR2(249 CHAR) NULL,
	hc01_vc06 VARCHAR2(249 CHAR) NULL,
	hc01_vc07 VARCHAR2(249 CHAR) NULL,
	hc01_vc08 VARCHAR2(249 CHAR) NULL,
	hc01_vc09 VARCHAR2(249 CHAR) NULL,
	hc01_vc100 VARCHAR2(249 CHAR) NULL,
	hc01_vc101 VARCHAR2(249 CHAR) NULL,
	hc01_vc103 VARCHAR2(249 CHAR) NULL,
	hc01_vc104 VARCHAR2(249 CHAR) NULL,
	hc01_vc105 VARCHAR2(249 CHAR) NULL,
	hc01_vc106 VARCHAR2(249 CHAR) NULL,
	hc01_vc107 VARCHAR2(249 CHAR) NULL,
	hc01_vc108 VARCHAR2(249 CHAR) NULL,
	hc01_vc109 VARCHAR2(249 CHAR) NULL,
	hc01_vc11 VARCHAR2(249 CHAR) NULL,
	hc01_vc110 VARCHAR2(249 CHAR) NULL,
	hc01_vc111 VARCHAR2(249 CHAR) NULL,
	hc01_vc112 VARCHAR2(249 CHAR) NULL,
	hc01_vc113 VARCHAR2(249 CHAR) NULL,
	hc01_vc114 VARCHAR2(249 CHAR) NULL,
	hc01_vc115 VARCHAR2(249 CHAR) NULL,
	hc01_vc118 VARCHAR2(249 CHAR) NULL,
	hc01_vc12 VARCHAR2(249 CHAR) NULL,
	hc01_vc120 VARCHAR2(249 CHAR) NULL,
	hc01_vc121 VARCHAR2(249 CHAR) NULL,
	hc01_vc122 VARCHAR2(249 CHAR) NULL,
	hc01_vc124 VARCHAR2(249 CHAR) NULL,
	hc01_vc125 VARCHAR2(249 CHAR) NULL,
	hc01_vc126 VARCHAR2(249 CHAR) NULL,
	hc01_vc130 VARCHAR2(249 CHAR) NULL,
	hc01_vc131 VARCHAR2(249 CHAR) NULL,
	hc01_vc132 VARCHAR2(249 CHAR) NULL,
	hc01_vc133 VARCHAR2(249 CHAR) NULL,
	hc01_vc134 VARCHAR2(249 CHAR) NULL,
	hc01_vc137 VARCHAR2(249 CHAR) NULL,
	hc01_vc138 VARCHAR2(249 CHAR) NULL,
	hc01_vc14 VARCHAR2(249 CHAR) NULL,
	hc01_vc141 VARCHAR2(249 CHAR) NULL,
	hc01_vc142 VARCHAR2(249 CHAR) NULL,
	hc01_vc143 VARCHAR2(249 CHAR) NULL,
	hc01_vc144 VARCHAR2(249 CHAR) NULL,
	hc01_vc145 VARCHAR2(249 CHAR) NULL,
	hc01_vc146 VARCHAR2(249 CHAR) NULL,
	hc01_vc147 VARCHAR2(249 CHAR) NULL,
	hc01_vc148 VARCHAR2(249 CHAR) NULL,
	hc01_vc149 VARCHAR2(249 CHAR) NULL,
	hc01_vc15 VARCHAR2(249 CHAR) NULL,
	hc01_vc150 VARCHAR2(249 CHAR) NULL,
	hc01_vc151 VARCHAR2(249 CHAR) NULL,
	hc01_vc152 VARCHAR2(249 CHAR) NULL,
	hc01_vc153 VARCHAR2(249 CHAR) NULL,
	hc01_vc154 VARCHAR2(249 CHAR) NULL,
	hc01_vc155 VARCHAR2(249 CHAR) NULL,
	hc01_vc156 VARCHAR2(249 CHAR) NULL,
	hc01_vc157 VARCHAR2(249 CHAR) NULL,
	hc01_vc16 VARCHAR2(249 CHAR) NULL,
	hc01_vc161 VARCHAR2(249 CHAR) NULL,
	hc01_vc162 VARCHAR2(249 CHAR) NULL,
	hc01_vc163 VARCHAR2(249 CHAR) NULL,
	hc01_vc164 VARCHAR2(249 CHAR) NULL,
	hc01_vc165 VARCHAR2(249 CHAR) NULL,
	hc01_vc166 VARCHAR2(4000 CHAR) NULL,
	hc01_vc167 VARCHAR2(249 CHAR) NULL,
	hc01_vc168 VARCHAR2(249 CHAR) NULL,
	hc01_vc169 VARCHAR2(4000 CHAR) NULL,
	hc01_vc17 VARCHAR2(249 CHAR) NULL,
	hc01_vc171 VARCHAR2(249 CHAR) NULL,
	hc01_vc172 VARCHAR2(249 CHAR) NULL,
	hc01_vc173 VARCHAR2(249 CHAR) NULL,
	hc01_vc174 VARCHAR2(249 CHAR) NULL,
	hc01_vc175 VARCHAR2(249 CHAR) NULL,
	hc01_vc176 VARCHAR2(249 CHAR) NULL,
	hc01_vc177 VARCHAR2(249 CHAR) NULL,
	hc01_vc178 VARCHAR2(249 CHAR) NULL,
	hc01_vc179 VARCHAR2(249 CHAR) NULL,
	hc01_vc180 VARCHAR2(249 CHAR) NULL,
	hc01_vc19 VARCHAR2(249 CHAR) NULL,
	hc01_vc20 VARCHAR2(249 CHAR) NULL,
	hc01_vc22 VARCHAR2(249 CHAR) NULL,
	hc01_vc23 VARCHAR2(249 CHAR) NULL,
	hc01_vc27 VARCHAR2(249 CHAR) NULL,
	hc01_vc28 VARCHAR2(249 CHAR) NULL,
	hc01_vc29 VARCHAR2(249 CHAR) NULL,
	hc01_vc30 VARCHAR2(249 CHAR) NULL,
	hc01_vc31 VARCHAR2(249 CHAR) NULL,
	hc01_vc32 VARCHAR2(249 CHAR) NULL,
	hc01_vc33 VARCHAR2(249 CHAR) NULL,
	hc01_vc36 VARCHAR2(249 CHAR) NULL,
	hc01_vc40 VARCHAR2(249 CHAR) NULL,
	hc01_vc41 VARCHAR2(249 CHAR) NULL,
	hc01_vc42 VARCHAR2(249 CHAR) NULL,
	hc01_vc43 VARCHAR2(249 CHAR) NULL,
	hc01_vc44 VARCHAR2(249 CHAR) NULL,
	hc01_vc45 VARCHAR2(249 CHAR) NULL,
	hc01_vc49 VARCHAR2(249 CHAR) NULL,
	hc01_vc50 VARCHAR2(249 CHAR) NULL,
	hc01_vc51 VARCHAR2(249 CHAR) NULL,
	hc01_vc52 VARCHAR2(249 CHAR) NULL,
	hc01_vc53 VARCHAR2(249 CHAR) NULL,
	hc01_vc54 VARCHAR2(249 CHAR) NULL,
	hc01_vc55 VARCHAR2(249 CHAR) NULL,
	hc01_vc56 VARCHAR2(249 CHAR) NULL,
	hc01_vc57 VARCHAR2(249 CHAR) NULL,
	hc01_vc58 VARCHAR2(249 CHAR) NULL,
	hc01_vc59 VARCHAR2(249 CHAR) NULL,
	hc01_vc60 VARCHAR2(249 CHAR) NULL,
	hc01_vc61 VARCHAR2(249 CHAR) NULL,
	hc01_vc62 VARCHAR2(249 CHAR) NULL,
	hc01_vc66 VARCHAR2(249 CHAR) NULL,
	hc01_vc67 VARCHAR2(249 CHAR) NULL,
	hc01_vc68 VARCHAR2(249 CHAR) NULL,
	hc01_vc69 VARCHAR2(249 CHAR) NULL,
	hc01_vc70 VARCHAR2(249 CHAR) NULL,
	hc01_vc74 VARCHAR2(249 CHAR) NULL,
	hc01_vc75 VARCHAR2(249 CHAR) NULL,
	hc01_vc76 VARCHAR2(249 CHAR) NULL,
	hc01_vc77 VARCHAR2(249 CHAR) NULL,
	hc01_vc78 VARCHAR2(249 CHAR) NULL,
	hc01_vc79 VARCHAR2(249 CHAR) NULL,
	hc01_vc80 VARCHAR2(249 CHAR) NULL,
	hc01_vc81 VARCHAR2(249 CHAR) NULL,
	hc01_vc82 VARCHAR2(249 CHAR) NULL,
	hc01_vc83 VARCHAR2(249 CHAR) NULL,
	hc01_vc84 VARCHAR2(249 CHAR) NULL,
	hc01_vc85 VARCHAR2(249 CHAR) NULL,
	hc01_vc86 VARCHAR2(249 CHAR) NULL,
	hc01_vc89 VARCHAR2(249 CHAR) NULL,
	hc01_vc90 VARCHAR2(249 CHAR) NULL,
	hc01_vc91 VARCHAR2(249 CHAR) NULL,
	hc01_vc92 VARCHAR2(249 CHAR) NULL,
	hc01_vc93 VARCHAR2(249 CHAR) NULL,
	hc01_vc94 VARCHAR2(249 CHAR) NULL,
	hc01_vc97 VARCHAR2(249 CHAR) NULL,
	hc01_vc98 VARCHAR2(249 CHAR) NULL,
	hc01_vc99 VARCHAR2(249 CHAR) NULL,
	hc02_vc03 VARCHAR2(249 CHAR) NULL,
	hc02_vc04 VARCHAR2(249 CHAR) NULL,
	hc02_vc05 VARCHAR2(249 CHAR) NULL,
	hc02_vc06 VARCHAR2(249 CHAR) NULL,
	hc02_vc07 VARCHAR2(249 CHAR) NULL,
	hc02_vc08 VARCHAR2(249 CHAR) NULL,
	hc02_vc09 VARCHAR2(249 CHAR) NULL,
	hc02_vc100 VARCHAR2(249 CHAR) NULL,
	hc02_vc101 VARCHAR2(249 CHAR) NULL,
	hc02_vc103 VARCHAR2(249 CHAR) NULL,
	hc02_vc104 VARCHAR2(249 CHAR) NULL,
	hc02_vc105 VARCHAR2(249 CHAR) NULL,
	hc02_vc106 VARCHAR2(249 CHAR) NULL,
	hc02_vc107 VARCHAR2(249 CHAR) NULL,
	hc02_vc108 VARCHAR2(249 CHAR) NULL,
	hc02_vc109 VARCHAR2(249 CHAR) NULL,
	hc02_vc11 VARCHAR2(249 CHAR) NULL,
	hc02_vc110 VARCHAR2(249 CHAR) NULL,
	hc02_vc111 VARCHAR2(249 CHAR) NULL,
	hc02_vc112 VARCHAR2(249 CHAR) NULL,
	hc02_vc113 VARCHAR2(249 CHAR) NULL,
	hc02_vc114 VARCHAR2(249 CHAR) NULL,
	hc02_vc115 VARCHAR2(249 CHAR) NULL,
	hc02_vc118 VARCHAR2(249 CHAR) NULL,
	hc02_vc12 VARCHAR2(249 CHAR) NULL,
	hc02_vc120 VARCHAR2(249 CHAR) NULL,
	hc02_vc121 VARCHAR2(249 CHAR) NULL,
	hc02_vc122 VARCHAR2(249 CHAR) NULL,
	hc02_vc124 VARCHAR2(249 CHAR) NULL,
	hc02_vc125 VARCHAR2(249 CHAR) NULL,
	hc02_vc126 VARCHAR2(249 CHAR) NULL,
	hc02_vc130 VARCHAR2(249 CHAR) NULL,
	hc02_vc131 VARCHAR2(249 CHAR) NULL,
	hc02_vc132 VARCHAR2(249 CHAR) NULL,
	hc02_vc133 VARCHAR2(249 CHAR) NULL,
	hc02_vc134 VARCHAR2(249 CHAR) NULL,
	hc02_vc137 VARCHAR2(249 CHAR) NULL,
	hc02_vc138 VARCHAR2(249 CHAR) NULL,
	hc02_vc14 VARCHAR2(249 CHAR) NULL,
	hc02_vc141 VARCHAR2(249 CHAR) NULL,
	hc02_vc142 VARCHAR2(249 CHAR) NULL,
	hc02_vc143 VARCHAR2(249 CHAR) NULL,
	hc02_vc144 VARCHAR2(249 CHAR) NULL,
	hc02_vc145 VARCHAR2(249 CHAR) NULL,
	hc02_vc146 VARCHAR2(249 CHAR) NULL,
	hc02_vc147 VARCHAR2(249 CHAR) NULL,
	hc02_vc148 VARCHAR2(249 CHAR) NULL,
	hc02_vc149 VARCHAR2(249 CHAR) NULL,
	hc02_vc15 VARCHAR2(249 CHAR) NULL,
	hc02_vc150 VARCHAR2(249 CHAR) NULL,
	hc02_vc151 VARCHAR2(249 CHAR) NULL,
	hc02_vc152 VARCHAR2(249 CHAR) NULL,
	hc02_vc153 VARCHAR2(249 CHAR) NULL,
	hc02_vc154 VARCHAR2(249 CHAR) NULL,
	hc02_vc155 VARCHAR2(249 CHAR) NULL,
	hc02_vc156 VARCHAR2(249 CHAR) NULL,
	hc02_vc157 VARCHAR2(249 CHAR) NULL,
	hc02_vc16 VARCHAR2(249 CHAR) NULL,
	hc02_vc161 VARCHAR2(249 CHAR) NULL,
	hc02_vc162 VARCHAR2(249 CHAR) NULL,
	hc02_vc163 VARCHAR2(249 CHAR) NULL,
	hc02_vc164 VARCHAR2(249 CHAR) NULL,
	hc02_vc165 VARCHAR2(249 CHAR) NULL,
	hc02_vc166 VARCHAR2(4000 CHAR) NULL,
	hc02_vc167 VARCHAR2(249 CHAR) NULL,
	hc02_vc168 VARCHAR2(249 CHAR) NULL,
	hc02_vc169 VARCHAR2(4000 CHAR) NULL,
	hc02_vc17 VARCHAR2(249 CHAR) NULL,
	hc02_vc171 VARCHAR2(249 CHAR) NULL,
	hc02_vc172 VARCHAR2(249 CHAR) NULL,
	hc02_vc173 VARCHAR2(249 CHAR) NULL,
	hc02_vc174 VARCHAR2(249 CHAR) NULL,
	hc02_vc175 VARCHAR2(249 CHAR) NULL,
	hc02_vc176 VARCHAR2(249 CHAR) NULL,
	hc02_vc177 VARCHAR2(249 CHAR) NULL,
	hc02_vc178 VARCHAR2(249 CHAR) NULL,
	hc02_vc179 VARCHAR2(249 CHAR) NULL,
	hc02_vc180 VARCHAR2(249 CHAR) NULL,
	hc02_vc19 VARCHAR2(249 CHAR) NULL,
	hc02_vc20 VARCHAR2(249 CHAR) NULL,
	hc02_vc22 VARCHAR2(249 CHAR) NULL,
	hc02_vc23 VARCHAR2(249 CHAR) NULL,
	hc02_vc27 VARCHAR2(249 CHAR) NULL,
	hc02_vc28 VARCHAR2(249 CHAR) NULL,
	hc02_vc29 VARCHAR2(249 CHAR) NULL,
	hc02_vc30 VARCHAR2(249 CHAR) NULL,
	hc02_vc31 VARCHAR2(249 CHAR) NULL,
	hc02_vc32 VARCHAR2(249 CHAR) NULL,
	hc02_vc33 VARCHAR2(249 CHAR) NULL,
	hc02_vc36 VARCHAR2(249 CHAR) NULL,
	hc02_vc40 VARCHAR2(249 CHAR) NULL,
	hc02_vc41 VARCHAR2(249 CHAR) NULL,
	hc02_vc42 VARCHAR2(249 CHAR) NULL,
	hc02_vc43 VARCHAR2(249 CHAR) NULL,
	hc02_vc44 VARCHAR2(249 CHAR) NULL,
	hc02_vc45 VARCHAR2(249 CHAR) NULL,
	hc02_vc49 VARCHAR2(249 CHAR) NULL,
	hc02_vc50 VARCHAR2(249 CHAR) NULL,
	hc02_vc51 VARCHAR2(249 CHAR) NULL,
	hc02_vc52 VARCHAR2(249 CHAR) NULL,
	hc02_vc53 VARCHAR2(249 CHAR) NULL,
	hc02_vc54 VARCHAR2(249 CHAR) NULL,
	hc02_vc55 VARCHAR2(249 CHAR) NULL,
	hc02_vc56 VARCHAR2(249 CHAR) NULL,
	hc02_vc57 VARCHAR2(249 CHAR) NULL,
	hc02_vc58 VARCHAR2(249 CHAR) NULL,
	hc02_vc59 VARCHAR2(249 CHAR) NULL,
	hc02_vc60 VARCHAR2(249 CHAR) NULL,
	hc02_vc61 VARCHAR2(249 CHAR) NULL,
	hc02_vc62 VARCHAR2(249 CHAR) NULL,
	hc02_vc66 VARCHAR2(249 CHAR) NULL,
	hc02_vc67 VARCHAR2(249 CHAR) NULL,
	hc02_vc68 VARCHAR2(249 CHAR) NULL,
	hc02_vc69 VARCHAR2(249 CHAR) NULL,
	hc02_vc70 VARCHAR2(249 CHAR) NULL,
	hc02_vc74 VARCHAR2(249 CHAR) NULL,
	hc02_vc75 VARCHAR2(249 CHAR) NULL,
	hc02_vc76 VARCHAR2(249 CHAR) NULL,
	hc02_vc77 VARCHAR2(249 CHAR) NULL,
	hc02_vc78 VARCHAR2(249 CHAR) NULL,
	hc02_vc79 VARCHAR2(249 CHAR) NULL,
	hc02_vc80 VARCHAR2(249 CHAR) NULL,
	hc02_vc81 VARCHAR2(249 CHAR) NULL,
	hc02_vc82 VARCHAR2(249 CHAR) NULL,
	hc02_vc83 VARCHAR2(249 CHAR) NULL,
	hc02_vc84 VARCHAR2(249 CHAR) NULL,
	hc02_vc85 VARCHAR2(249 CHAR) NULL,
	hc02_vc86 VARCHAR2(249 CHAR) NULL,
	hc02_vc89 VARCHAR2(249 CHAR) NULL,
	hc02_vc90 VARCHAR2(249 CHAR) NULL,
	hc02_vc91 VARCHAR2(249 CHAR) NULL,
	hc02_vc92 VARCHAR2(249 CHAR) NULL,
	hc02_vc93 VARCHAR2(249 CHAR) NULL,
	hc02_vc94 VARCHAR2(249 CHAR) NULL,
	hc02_vc97 VARCHAR2(249 CHAR) NULL,
	hc02_vc98 VARCHAR2(249 CHAR) NULL,
	hc02_vc99 VARCHAR2(249 CHAR) NULL,
	hc03_vc03 VARCHAR2(249 CHAR) NULL,
	hc03_vc04 VARCHAR2(249 CHAR) NULL,
	hc03_vc05 VARCHAR2(249 CHAR) NULL,
	hc03_vc06 VARCHAR2(249 CHAR) NULL,
	hc03_vc07 VARCHAR2(249 CHAR) NULL,
	hc03_vc08 VARCHAR2(249 CHAR) NULL,
	hc03_vc09 VARCHAR2(249 CHAR) NULL,
	hc03_vc100 VARCHAR2(249 CHAR) NULL,
	hc03_vc101 VARCHAR2(249 CHAR) NULL,
	hc03_vc103 VARCHAR2(249 CHAR) NULL,
	hc03_vc104 VARCHAR2(249 CHAR) NULL,
	hc03_vc105 VARCHAR2(249 CHAR) NULL,
	hc03_vc106 VARCHAR2(249 CHAR) NULL,
	hc03_vc107 VARCHAR2(249 CHAR) NULL,
	hc03_vc108 VARCHAR2(249 CHAR) NULL,
	hc03_vc109 VARCHAR2(249 CHAR) NULL,
	hc03_vc11 VARCHAR2(249 CHAR) NULL,
	hc03_vc110 VARCHAR2(249 CHAR) NULL,
	hc03_vc111 VARCHAR2(249 CHAR) NULL,
	hc03_vc112 VARCHAR2(249 CHAR) NULL,
	hc03_vc113 VARCHAR2(249 CHAR) NULL,
	hc03_vc114 VARCHAR2(249 CHAR) NULL,
	hc03_vc115 VARCHAR2(249 CHAR) NULL,
	hc03_vc118 VARCHAR2(249 CHAR) NULL,
	hc03_vc12 VARCHAR2(249 CHAR) NULL,
	hc03_vc120 VARCHAR2(249 CHAR) NULL,
	hc03_vc121 VARCHAR2(249 CHAR) NULL,
	hc03_vc122 VARCHAR2(249 CHAR) NULL,
	hc03_vc124 VARCHAR2(249 CHAR) NULL,
	hc03_vc125 VARCHAR2(249 CHAR) NULL,
	hc03_vc126 VARCHAR2(249 CHAR) NULL,
	hc03_vc130 VARCHAR2(249 CHAR) NULL,
	hc03_vc131 VARCHAR2(249 CHAR) NULL,
	hc03_vc132 VARCHAR2(249 CHAR) NULL,
	hc03_vc133 VARCHAR2(249 CHAR) NULL,
	hc03_vc134 VARCHAR2(249 CHAR) NULL,
	hc03_vc137 VARCHAR2(249 CHAR) NULL,
	hc03_vc138 VARCHAR2(249 CHAR) NULL,
	hc03_vc14 VARCHAR2(249 CHAR) NULL,
	hc03_vc141 VARCHAR2(249 CHAR) NULL,
	hc03_vc142 VARCHAR2(249 CHAR) NULL,
	hc03_vc143 VARCHAR2(249 CHAR) NULL,
	hc03_vc144 VARCHAR2(249 CHAR) NULL,
	hc03_vc145 VARCHAR2(249 CHAR) NULL,
	hc03_vc146 VARCHAR2(249 CHAR) NULL,
	hc03_vc147 VARCHAR2(249 CHAR) NULL,
	hc03_vc148 VARCHAR2(249 CHAR) NULL,
	hc03_vc149 VARCHAR2(249 CHAR) NULL,
	hc03_vc15 VARCHAR2(249 CHAR) NULL,
	hc03_vc150 VARCHAR2(249 CHAR) NULL,
	hc03_vc151 VARCHAR2(249 CHAR) NULL,
	hc03_vc152 VARCHAR2(249 CHAR) NULL,
	hc03_vc153 VARCHAR2(249 CHAR) NULL,
	hc03_vc154 VARCHAR2(249 CHAR) NULL,
	hc03_vc155 VARCHAR2(249 CHAR) NULL,
	hc03_vc156 VARCHAR2(249 CHAR) NULL,
	hc03_vc157 VARCHAR2(249 CHAR) NULL,
	hc03_vc16 VARCHAR2(249 CHAR) NULL,
	hc03_vc161 VARCHAR2(249 CHAR) NULL,
	hc03_vc162 VARCHAR2(249 CHAR) NULL,
	hc03_vc163 VARCHAR2(249 CHAR) NULL,
	hc03_vc164 VARCHAR2(249 CHAR) NULL,
	hc03_vc165 VARCHAR2(249 CHAR) NULL,
	hc03_vc166 VARCHAR2(4000 CHAR) NULL,
	hc03_vc167 VARCHAR2(249 CHAR) NULL,
	hc03_vc168 VARCHAR2(249 CHAR) NULL,
	hc03_vc169 VARCHAR2(4000 CHAR) NULL,
	hc03_vc17 VARCHAR2(249 CHAR) NULL,
	hc03_vc171 VARCHAR2(249 CHAR) NULL,
	hc03_vc172 VARCHAR2(249 CHAR) NULL,
	hc03_vc173 VARCHAR2(249 CHAR) NULL,
	hc03_vc174 VARCHAR2(249 CHAR) NULL,
	hc03_vc175 VARCHAR2(249 CHAR) NULL,
	hc03_vc176 VARCHAR2(249 CHAR) NULL,
	hc03_vc177 VARCHAR2(249 CHAR) NULL,
	hc03_vc178 VARCHAR2(249 CHAR) NULL,
	hc03_vc179 VARCHAR2(249 CHAR) NULL,
	hc03_vc180 VARCHAR2(249 CHAR) NULL,
	hc03_vc19 VARCHAR2(249 CHAR) NULL,
	hc03_vc20 VARCHAR2(249 CHAR) NULL,
	hc03_vc22 VARCHAR2(249 CHAR) NULL,
	hc03_vc23 VARCHAR2(249 CHAR) NULL,
	hc03_vc27 VARCHAR2(249 CHAR) NULL,
	hc03_vc28 VARCHAR2(249 CHAR) NULL,
	hc03_vc29 VARCHAR2(249 CHAR) NULL,
	hc03_vc30 VARCHAR2(249 CHAR) NULL,
	hc03_vc31 VARCHAR2(249 CHAR) NULL,
	hc03_vc32 VARCHAR2(249 CHAR) NULL,
	hc03_vc33 VARCHAR2(249 CHAR) NULL,
	hc03_vc36 VARCHAR2(249 CHAR) NULL,
	hc03_vc40 VARCHAR2(249 CHAR) NULL,
	hc03_vc41 VARCHAR2(249 CHAR) NULL,
	hc03_vc42 VARCHAR2(249 CHAR) NULL,
	hc03_vc43 VARCHAR2(249 CHAR) NULL,
	hc03_vc44 VARCHAR2(249 CHAR) NULL,
	hc03_vc45 VARCHAR2(249 CHAR) NULL,
	hc03_vc49 VARCHAR2(249 CHAR) NULL,
	hc03_vc50 VARCHAR2(249 CHAR) NULL,
	hc03_vc51 VARCHAR2(249 CHAR) NULL,
	hc03_vc52 VARCHAR2(249 CHAR) NULL,
	hc03_vc53 VARCHAR2(249 CHAR) NULL,
	hc03_vc54 VARCHAR2(249 CHAR) NULL,
	hc03_vc55 VARCHAR2(249 CHAR) NULL,
	hc03_vc56 VARCHAR2(249 CHAR) NULL,
	hc03_vc57 VARCHAR2(249 CHAR) NULL,
	hc03_vc58 VARCHAR2(249 CHAR) NULL,
	hc03_vc59 VARCHAR2(249 CHAR) NULL,
	hc03_vc60 VARCHAR2(249 CHAR) NULL,
	hc03_vc61 VARCHAR2(249 CHAR) NULL,
	hc03_vc62 VARCHAR2(249 CHAR) NULL,
	hc03_vc66 VARCHAR2(249 CHAR) NULL,
	hc03_vc67 VARCHAR2(249 CHAR) NULL,
	hc03_vc68 VARCHAR2(249 CHAR) NULL,
	hc03_vc69 VARCHAR2(249 CHAR) NULL,
	hc03_vc70 VARCHAR2(249 CHAR) NULL,
	hc03_vc74 VARCHAR2(249 CHAR) NULL,
	hc03_vc75 VARCHAR2(249 CHAR) NULL,
	hc03_vc76 VARCHAR2(249 CHAR) NULL,
	hc03_vc77 VARCHAR2(249 CHAR) NULL,
	hc03_vc78 VARCHAR2(249 CHAR) NULL,
	hc03_vc79 VARCHAR2(249 CHAR) NULL,
	hc03_vc80 VARCHAR2(249 CHAR) NULL,
	hc03_vc81 VARCHAR2(249 CHAR) NULL,
	hc03_vc82 VARCHAR2(249 CHAR) NULL,
	hc03_vc83 VARCHAR2(249 CHAR) NULL,
	hc03_vc84 VARCHAR2(249 CHAR) NULL,
	hc03_vc85 VARCHAR2(249 CHAR) NULL,
	hc03_vc86 VARCHAR2(249 CHAR) NULL,
	hc03_vc89 VARCHAR2(249 CHAR) NULL,
	hc03_vc90 VARCHAR2(249 CHAR) NULL,
	hc03_vc91 VARCHAR2(249 CHAR) NULL,
	hc03_vc92 VARCHAR2(249 CHAR) NULL,
	hc03_vc93 VARCHAR2(249 CHAR) NULL,
	hc03_vc94 VARCHAR2(249 CHAR) NULL,
	hc03_vc97 VARCHAR2(249 CHAR) NULL,
	hc03_vc98 VARCHAR2(249 CHAR) NULL,
	hc03_vc99 VARCHAR2(249 CHAR) NULL,
	hc04_vc03 VARCHAR2(249 CHAR) NULL,
	hc04_vc04 VARCHAR2(249 CHAR) NULL,
	hc04_vc05 VARCHAR2(249 CHAR) NULL,
	hc04_vc06 VARCHAR2(249 CHAR) NULL,
	hc04_vc07 VARCHAR2(249 CHAR) NULL,
	hc04_vc08 VARCHAR2(249 CHAR) NULL,
	hc04_vc09 VARCHAR2(249 CHAR) NULL,
	hc04_vc100 VARCHAR2(249 CHAR) NULL,
	hc04_vc101 VARCHAR2(249 CHAR) NULL,
	hc04_vc103 VARCHAR2(249 CHAR) NULL,
	hc04_vc104 VARCHAR2(249 CHAR) NULL,
	hc04_vc105 VARCHAR2(249 CHAR) NULL,
	hc04_vc106 VARCHAR2(249 CHAR) NULL,
	hc04_vc107 VARCHAR2(249 CHAR) NULL,
	hc04_vc108 VARCHAR2(249 CHAR) NULL,
	hc04_vc109 VARCHAR2(249 CHAR) NULL,
	hc04_vc11 VARCHAR2(249 CHAR) NULL,
	hc04_vc110 VARCHAR2(249 CHAR) NULL,
	hc04_vc111 VARCHAR2(249 CHAR) NULL,
	hc04_vc112 VARCHAR2(249 CHAR) NULL,
	hc04_vc113 VARCHAR2(249 CHAR) NULL,
	hc04_vc114 VARCHAR2(249 CHAR) NULL,
	hc04_vc115 VARCHAR2(249 CHAR) NULL,
	hc04_vc118 VARCHAR2(249 CHAR) NULL,
	hc04_vc12 VARCHAR2(249 CHAR) NULL,
	hc04_vc120 VARCHAR2(249 CHAR) NULL,
	hc04_vc121 VARCHAR2(249 CHAR) NULL,
	hc04_vc122 VARCHAR2(249 CHAR) NULL,
	hc04_vc124 VARCHAR2(249 CHAR) NULL,
	hc04_vc125 VARCHAR2(249 CHAR) NULL,
	hc04_vc126 VARCHAR2(249 CHAR) NULL,
	hc04_vc130 VARCHAR2(249 CHAR) NULL,
	hc04_vc131 VARCHAR2(249 CHAR) NULL,
	hc04_vc132 VARCHAR2(249 CHAR) NULL,
	hc04_vc133 VARCHAR2(249 CHAR) NULL,
	hc04_vc134 VARCHAR2(249 CHAR) NULL,
	hc04_vc137 VARCHAR2(249 CHAR) NULL,
	hc04_vc138 VARCHAR2(249 CHAR) NULL,
	hc04_vc14 VARCHAR2(249 CHAR) NULL,
	hc04_vc141 VARCHAR2(249 CHAR) NULL,
	hc04_vc142 VARCHAR2(249 CHAR) NULL,
	hc04_vc143 VARCHAR2(249 CHAR) NULL,
	hc04_vc144 VARCHAR2(249 CHAR) NULL,
	hc04_vc145 VARCHAR2(249 CHAR) NULL,
	hc04_vc146 VARCHAR2(249 CHAR) NULL,
	hc04_vc147 VARCHAR2(249 CHAR) NULL,
	hc04_vc148 VARCHAR2(249 CHAR) NULL,
	hc04_vc149 VARCHAR2(249 CHAR) NULL,
	hc04_vc15 VARCHAR2(249 CHAR) NULL,
	hc04_vc150 VARCHAR2(249 CHAR) NULL,
	hc04_vc151 VARCHAR2(249 CHAR) NULL,
	hc04_vc152 VARCHAR2(249 CHAR) NULL,
	hc04_vc153 VARCHAR2(249 CHAR) NULL,
	hc04_vc154 VARCHAR2(249 CHAR) NULL,
	hc04_vc155 VARCHAR2(249 CHAR) NULL,
	hc04_vc156 VARCHAR2(249 CHAR) NULL,
	hc04_vc157 VARCHAR2(249 CHAR) NULL,
	hc04_vc16 VARCHAR2(249 CHAR) NULL,
	hc04_vc161 VARCHAR2(249 CHAR) NULL,
	hc04_vc162 VARCHAR2(249 CHAR) NULL,
	hc04_vc163 VARCHAR2(4000 CHAR) NULL,
	hc04_vc164 VARCHAR2(249 CHAR) NULL,
	hc04_vc165 VARCHAR2(249 CHAR) NULL,
	hc04_vc166 VARCHAR2(4000 CHAR) NULL,
	hc04_vc167 VARCHAR2(249 CHAR) NULL,
	hc04_vc168 VARCHAR2(249 CHAR) NULL,
	hc04_vc169 VARCHAR2(4000 CHAR) NULL,
	hc04_vc17 VARCHAR2(249 CHAR) NULL,
	hc04_vc171 VARCHAR2(249 CHAR) NULL,
	hc04_vc172 VARCHAR2(249 CHAR) NULL,
	hc04_vc173 VARCHAR2(249 CHAR) NULL,
	hc04_vc174 VARCHAR2(4000 CHAR) NULL,
	hc04_vc175 VARCHAR2(4000 CHAR) NULL,
	hc04_vc176 VARCHAR2(249 CHAR) NULL,
	hc04_vc177 VARCHAR2(249 CHAR) NULL,
	hc04_vc178 VARCHAR2(249 CHAR) NULL,
	hc04_vc179 VARCHAR2(249 CHAR) NULL,
	hc04_vc180 VARCHAR2(249 CHAR) NULL,
	hc04_vc19 VARCHAR2(249 CHAR) NULL,
	hc04_vc20 VARCHAR2(249 CHAR) NULL,
	hc04_vc22 VARCHAR2(249 CHAR) NULL,
	hc04_vc23 VARCHAR2(249 CHAR) NULL,
	hc04_vc27 VARCHAR2(249 CHAR) NULL,
	hc04_vc28 VARCHAR2(249 CHAR) NULL,
	hc04_vc29 VARCHAR2(249 CHAR) NULL,
	hc04_vc30 VARCHAR2(249 CHAR) NULL,
	hc04_vc31 VARCHAR2(249 CHAR) NULL,
	hc04_vc32 VARCHAR2(249 CHAR) NULL,
	hc04_vc33 VARCHAR2(249 CHAR) NULL,
	hc04_vc36 VARCHAR2(249 CHAR) NULL,
	hc04_vc40 VARCHAR2(249 CHAR) NULL,
	hc04_vc41 VARCHAR2(249 CHAR) NULL,
	hc04_vc42 VARCHAR2(249 CHAR) NULL,
	hc04_vc43 VARCHAR2(249 CHAR) NULL,
	hc04_vc44 VARCHAR2(249 CHAR) NULL,
	hc04_vc45 VARCHAR2(249 CHAR) NULL,
	hc04_vc49 VARCHAR2(249 CHAR) NULL,
	hc04_vc50 VARCHAR2(249 CHAR) NULL,
	hc04_vc51 VARCHAR2(249 CHAR) NULL,
	hc04_vc52 VARCHAR2(249 CHAR) NULL,
	hc04_vc53 VARCHAR2(249 CHAR) NULL,
	hc04_vc54 VARCHAR2(249 CHAR) NULL,
	hc04_vc55 VARCHAR2(249 CHAR) NULL,
	hc04_vc56 VARCHAR2(249 CHAR) NULL,
	hc04_vc57 VARCHAR2(249 CHAR) NULL,
	hc04_vc58 VARCHAR2(249 CHAR) NULL,
	hc04_vc59 VARCHAR2(249 CHAR) NULL,
	hc04_vc60 VARCHAR2(249 CHAR) NULL,
	hc04_vc61 VARCHAR2(249 CHAR) NULL,
	hc04_vc62 VARCHAR2(249 CHAR) NULL,
	hc04_vc66 VARCHAR2(249 CHAR) NULL,
	hc04_vc67 VARCHAR2(249 CHAR) NULL,
	hc04_vc68 VARCHAR2(249 CHAR) NULL,
	hc04_vc69 VARCHAR2(249 CHAR) NULL,
	hc04_vc70 VARCHAR2(249 CHAR) NULL,
	hc04_vc74 VARCHAR2(249 CHAR) NULL,
	hc04_vc75 VARCHAR2(249 CHAR) NULL,
	hc04_vc76 VARCHAR2(249 CHAR) NULL,
	hc04_vc77 VARCHAR2(249 CHAR) NULL,
	hc04_vc78 VARCHAR2(249 CHAR) NULL,
	hc04_vc79 VARCHAR2(249 CHAR) NULL,
	hc04_vc80 VARCHAR2(249 CHAR) NULL,
	hc04_vc81 VARCHAR2(249 CHAR) NULL,
	hc04_vc82 VARCHAR2(249 CHAR) NULL,
	hc04_vc83 VARCHAR2(249 CHAR) NULL,
	hc04_vc84 VARCHAR2(249 CHAR) NULL,
	hc04_vc85 VARCHAR2(249 CHAR) NULL,
	hc04_vc86 VARCHAR2(249 CHAR) NULL,
	hc04_vc89 VARCHAR2(249 CHAR) NULL,
	hc04_vc90 VARCHAR2(249 CHAR) NULL,
	hc04_vc91 VARCHAR2(249 CHAR) NULL,
	hc04_vc92 VARCHAR2(249 CHAR) NULL,
	hc04_vc93 VARCHAR2(249 CHAR) NULL,
	hc04_vc94 VARCHAR2(249 CHAR) NULL,
	hc04_vc97 VARCHAR2(249 CHAR) NULL,
	hc04_vc98 VARCHAR2(249 CHAR) NULL,
	hc04_vc99 VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_apr_drg_3m', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_apr_drg_3m (
	all_rom_counts VARCHAR2(249 CHAR) NULL,
	apr_drg VARCHAR2(249 CHAR)  NULL,
	average_charge_trimmed VARCHAR2(249 CHAR) NULL,
	average_charge_untrimmed VARCHAR2(249 CHAR) NULL,
	avg_arithmetic_los_trimmed VARCHAR2(249 CHAR) NULL,
	avg_arithmetic_los_untrimmed VARCHAR2(249 CHAR) NULL,
	avg_geometric_los_trimmed VARCHAR2(249 CHAR) NULL,
	avg_geometric_los_untrimmed VARCHAR2(249 CHAR) NULL,
	charge_stand_dev_trimmed VARCHAR2(249 CHAR) NULL,
	charge_stand_dev_untrimmed VARCHAR2(249 CHAR) NULL,
	counts_all VARCHAR2(249 CHAR) NULL,
	counts_inlier VARCHAR2(249 CHAR) NULL,
	drg_description VARCHAR2(249 CHAR) NULL,
	los_stand_dev_trimmed VARCHAR2(249 CHAR) NULL,
	los_stand_dev_untrimmed VARCHAR2(249 CHAR) NULL,
	mdc VARCHAR2(249 CHAR) NULL,
	mdc_description VARCHAR2(249 CHAR) NULL,
	rom_died_counts VARCHAR2(249 CHAR) NULL,
	rom_mortality_rate VARCHAR2(249 CHAR) NULL,
	soi_subclass VARCHAR2(249 CHAR) NULL,
	trim_high VARCHAR2(249 CHAR) NULL,
	trim_low VARCHAR2(249 CHAR) NULL,
	v31_weights VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_billtype_pos_xref', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_billtype_pos_xref (
	bill_clsfctn_cd VARCHAR2(249 CHAR) NULL,
	bill_clsfctn_desc VARCHAR2(249 CHAR) NULL,
	bill_type VARCHAR2(249 CHAR)  NULL,
	bpo_spec VARCHAR2(249 CHAR) NULL,
	bpo_spec_name VARCHAR2(249 CHAR) NULL,
	fac_type_cd VARCHAR2(249 CHAR) NULL,
	fac_type_desc VARCHAR2(249 CHAR) NULL,
	imputed_pos VARCHAR2(249 CHAR) NULL,
	specialty VARCHAR2(249 CHAR) NULL,
	specialty_classification VARCHAR2(249 CHAR) NULL,
	specialty_specialization VARCHAR2(249 CHAR) NULL,
	specialty_type VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_ccs_multi_dx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_ccs_multi_dx (
	ccs_lvl_1 VARCHAR2(5 CHAR) NULL,
	ccs_lvl_1_label VARCHAR2(100 CHAR) NULL,
	ccs_lvl_2 VARCHAR2(10 CHAR) NULL,
	ccs_lvl_2_label VARCHAR2(100 CHAR) NULL,
	ccs_lvl_3 VARCHAR2(10 CHAR) NULL,
	ccs_lvl_3_label VARCHAR2(100 CHAR) NULL,
	ccs_lvl_4 VARCHAR2(100 CHAR) NULL,
	ccs_lvl_4_label VARCHAR2(100 CHAR) NULL,
	hum_year VARCHAR2(10 CHAR)  NULL,
	icd_cm_code VARCHAR2(10 CHAR) NULL,
	icd_version VARCHAR2(10 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_cen_educ_25yr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_cen_educ_25yr (
	all_10gr NUMBER  NULL,
	all_11gr NUMBER  NULL,
	all_12gr_nodiploma NUMBER  NULL,
	all_5gr_6gr NUMBER  NULL,
	all_7gr_8gr NUMBER  NULL,
	all_9gr NUMBER  NULL,
	all_assoc_deg NUMBER  NULL,
	all_bach_deg NUMBER  NULL,
	all_coll_gte_1yr_no_deg NUMBER  NULL,
	all_coll_lt_1yr NUMBER  NULL,
	all_doct_deg NUMBER  NULL,
	all_hs_grad_incl_equiv NUMBER  NULL,
	all_mast_deg NUMBER  NULL,
	all_no_school NUMBER  NULL,
	all_nur_4gr NUMBER  NULL,
	all_prof_deg NUMBER  NULL,
	female NUMBER  NULL,
	female_10gr NUMBER  NULL,
	female_11gr NUMBER  NULL,
	female_12gr_nodiploma NUMBER  NULL,
	female_5gr_6gr NUMBER  NULL,
	female_7gr_8gr NUMBER  NULL,
	female_9gr NUMBER  NULL,
	female_assoc_deg NUMBER  NULL,
	female_bach_deg NUMBER  NULL,
	female_coll_gte_1yr_no_deg NUMBER  NULL,
	female_coll_lt_1yr NUMBER  NULL,
	female_doct_deg NUMBER  NULL,
	female_hs_grad_incl_equiv NUMBER  NULL,
	female_mast_deg NUMBER  NULL,
	female_no_school NUMBER  NULL,
	female_nur_4gr NUMBER  NULL,
	female_prof_deg NUMBER  NULL,
	geo_id VARCHAR2(20 CHAR)  NULL,
	geo_id2 VARCHAR2(5 CHAR) NULL,
	geo_sum_level VARCHAR2(3 CHAR) NULL,
	geography VARCHAR2(36 CHAR) NULL,
	male NUMBER  NULL,
	male_10gr NUMBER  NULL,
	male_11gr NUMBER  NULL,
	male_12gr_nodiploma NUMBER  NULL,
	male_5gr_6gr NUMBER  NULL,
	male_7gr_8gr NUMBER  NULL,
	male_9gr NUMBER  NULL,
	male_assoc_deg NUMBER  NULL,
	male_bach_deg NUMBER  NULL,
	male_coll_gte_1yr_no_deg NUMBER  NULL,
	male_coll_lt_1yr NUMBER  NULL,
	male_doct_deg NUMBER  NULL,
	male_hs_grad_incl_equiv NUMBER  NULL,
	male_mast_deg NUMBER  NULL,
	male_no_school NUMBER  NULL,
	male_nur_4gr NUMBER  NULL,
	male_prof_deg NUMBER  NULL,
	total NUMBER  NULL,
	total2 NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_cen_median_hh_inc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_cen_median_hh_inc (
	geo_id VARCHAR2(20 CHAR)  NULL,
	geo_id2 VARCHAR2(5 CHAR) NULL,
	geo_sum_level VARCHAR2(3 CHAR) NULL,
	geography VARCHAR2(36 CHAR) NULL,
	median_hh_inc NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_cen_per_capita_inc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_cen_per_capita_inc (
	geo_id VARCHAR2(20 CHAR)  NULL,
	geo_id2 VARCHAR2(5 CHAR) NULL,
	geo_sum_level VARCHAR2(3 CHAR) NULL,
	geography VARCHAR2(36 CHAR) NULL,
	per_capita_inc NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_cen_inc_pov_ratio', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_cen_inc_pov_ratio (
	geo_id VARCHAR2(20 CHAR)  NULL,
	geo_id2 VARCHAR2(5 CHAR) NULL,
	geo_sum_level VARCHAR2(3 CHAR) NULL,
	geography VARCHAR2(36 CHAR) NULL,
	ratio_100pct_to_124pct NUMBER  NULL,
	ratio_125pct_to_149pct NUMBER  NULL,
	ratio_150pct_to_184pct NUMBER  NULL,
	ratio_185pct_to_199pct NUMBER  NULL,
	ratio_200pct_and_over NUMBER  NULL,
	ratio_50pct_to_99pct NUMBER  NULL,
	ratio_under_50pct NUMBER  NULL,
	total NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_commercial_zipcodes', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_commercial_zipcodes (
	areacode VARCHAR2(16 CHAR) NULL,
	cityname VARCHAR2(64 CHAR) NULL,
	citytype VARCHAR2(1 CHAR) NULL,
	countyfips VARCHAR2(5 CHAR) NULL,
	countyname VARCHAR2(64 CHAR) NULL,
	dst VARCHAR2(1 CHAR) NULL,
	latitude NUMBER  NULL,
	longitude NUMBER  NULL,
	msacode VARCHAR2(4 CHAR) NULL,
	stateabbr VARCHAR2(2 CHAR) NULL,
	statefips VARCHAR2(2 CHAR) NULL,
	statename VARCHAR2(64 CHAR) NULL,
	timezone VARCHAR2(16 CHAR) NULL,
	utc NUMBER  NULL,
	zipcode VARCHAR2(5 CHAR)  NULL,
	ziptype VARCHAR2(1 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_cpt4', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_cpt4 (
	long_description VARCHAR2(4000 CHAR) NULL,
	modifier VARCHAR2(249 CHAR) NULL,
	procedure_code VARCHAR2(249 CHAR)  NULL,
	short_description VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_cust_proc_mapped_val', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_cust_proc_mapped_val (
	description VARCHAR2(249 CHAR) NULL,
	mappedvalue VARCHAR2(249 CHAR)  NULL,
	sensitive_ind NUMBER (1) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_dcc_ndc_raw', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_dcc_ndc_raw (
	dcc VARCHAR2(249 CHAR)  NULL,
	drugformcode VARCHAR2(249 CHAR) NULL,
	gcdf VARCHAR2(249 CHAR) NULL,
	gcdf_desc VARCHAR2(249 CHAR) NULL,
	gcdf_desc_short VARCHAR2(249 CHAR) NULL,
	gcn_seqno VARCHAR2(249 CHAR) NULL,
	gcn_seqno_num VARCHAR2(249 CHAR) NULL,
	gcrt VARCHAR2(249 CHAR) NULL,
	gcrt_desc VARCHAR2(249 CHAR) NULL,
	gnn60 VARCHAR2(249 CHAR) NULL,
	ln VARCHAR2(249 CHAR) NULL,
	ndc VARCHAR2(249 CHAR) NULL,
	obsoletedate VARCHAR2(249 CHAR) NULL,
	productsid VARCHAR2(249 CHAR) NULL,
	str VARCHAR2(249 CHAR) NULL,
	str60 VARCHAR2(249 CHAR) NULL,
	strnum NUMBER  NULL,
	strun50 VARCHAR2(249 CHAR) NULL,
	volnum NUMBER  NULL,
	volun50 VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_ebm_reference', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_ebm_reference (
	adherence_rule_id NUMBER  NULL,
	ama_pcpi VARCHAR2(20 CHAR) NULL,
	cms VARCHAR2(20 CHAR) NULL,
	endorsed_by_nqf VARCHAR2(20 CHAR) NULL,
	lab_data VARCHAR2(20 CHAR) NULL,
	lab_results VARCHAR2(20 CHAR) NULL,
	ncqa_hedis VARCHAR2(20 CHAR) NULL,
	pharmacy_data VARCHAR2(20 CHAR) NULL,
	pqa VARCHAR2(20 CHAR) NULL,
	prospective VARCHAR2(20 CHAR) NULL,
	report_case_id NUMBER   NULL,
	report_case_long_description VARCHAR2(1038 CHAR) NULL,
	report_case_short_description VARCHAR2(524 CHAR) NULL,
	report_rule_context VARCHAR2(1024 CHAR) NULL,
	report_rule_description VARCHAR2(1024 CHAR) NULL,
	report_rule_id NUMBER  NULL,
	rule_type VARCHAR2(20 CHAR) NULL,
	rule_type_description VARCHAR2(1024 CHAR) NULL,
	rule_type_num NUMBER  NULL,
	similar_to_nqf VARCHAR2(20 CHAR) NULL,
	task_number NUMBER  NULL,
	task_number_description VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_hcpcs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_hcpcs (
	long_description VARCHAR2(4000 CHAR) NULL,
	procedure_code VARCHAR2(249 CHAR)  NULL,
	short_description VARCHAR2(500 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_hedis_reference', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_hedis_reference (
	measure_id VARCHAR2(20 CHAR) NOT NULL,
	measure_id_description VARCHAR2(255 CHAR) NOT NULL,
	measure_name VARCHAR2(20 CHAR) NOT  NULL,
	measure_name_description VARCHAR2(255 CHAR) NOT NULL,
	stratification_description VARCHAR2(255 CHAR) NULL,
	stratification_id VARCHAR2(20 CHAR) NULL,
	versions VARCHAR2(20 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_hts_dcc_current', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_hts_dcc_current (
	cdr_dcc_rxcnt NUMBER  NULL,
	cdr_top_ndc_rxcnt NUMBER  NULL,
	dcc VARCHAR2(249 CHAR)  NULL,
	dccdateadded DATE  NULL,
	genericname VARCHAR2(249 CHAR) NULL,
	harmful_geriatric_med VARCHAR2(256 CHAR) NULL,
	hts_generic VARCHAR2(256 CHAR) NULL,
	hts_generic_ext VARCHAR2(256 CHAR) NULL,
	hum_gen_med_key VARCHAR2(64 CHAR) NULL,
	hum_med_key VARCHAR2(44 CHAR) NULL,
	is_sensitive VARCHAR2(256 CHAR) NULL,
	is_vaccine VARCHAR2(256 CHAR) NULL,
	isspecialtydrug VARCHAR2(1 CHAR) NULL,
	max_ndc VARCHAR2(11 CHAR) NULL,
	min_ndc VARCHAR2(11 CHAR) NULL,
	ndc_sme VARCHAR2(256 CHAR) NULL,
	num_9dig_ndcs NUMBER  NULL,
	num_ndcs NUMBER  NULL,
	offmarket VARCHAR2(5 CHAR) NULL,
	offmarketdate DATE  NULL,
	offmarketnote VARCHAR2(249 CHAR) NULL,
	pcc VARCHAR2(249 CHAR) NULL,
	pcc_label VARCHAR2(249 CHAR) NULL,
	preferred_route_cui VARCHAR2(256 CHAR) NULL,
	rxa_dcc_rxcnt NUMBER  NULL,
	rxa_max_ndc VARCHAR2(11 CHAR) NULL,
	rxa_min_ndc VARCHAR2(11 CHAR) NULL,
	rxa_num_9dig_ndcs NUMBER  NULL,
	rxa_num_ndcs NUMBER  NULL,
	rxa_top_ndc VARCHAR2(11 CHAR) NULL,
	rxa_top_ndc_rxcnt NUMBER  NULL,
	rxo_dcc_rxcnt NUMBER  NULL,
	rxo_max_ndc VARCHAR2(11 CHAR) NULL,
	rxo_min_ndc VARCHAR2(11 CHAR) NULL,
	rxo_num_9dig_ndcs NUMBER  NULL,
	rxo_num_ndcs NUMBER  NULL,
	rxo_top_ndc VARCHAR2(11 CHAR) NULL,
	rxo_top_ndc_rxcnt NUMBER  NULL,
	tcc VARCHAR2(249 CHAR) NULL,
	tcc_label VARCHAR2(249 CHAR) NULL,
	top_ndc VARCHAR2(256 CHAR) NULL,
	top_ndc_src VARCHAR2(11 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_hts_ndc_current', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_hts_ndc_current (
	cdr_ndc_rxcnt NUMBER  NULL,
	dcc VARCHAR2(249 CHAR) NULL,
	deleted_yn CHAR(1) NULL,
	formcode VARCHAR2(29 CHAR) NULL,
	gbo_desc VARCHAR2(30 CHAR) NULL,
	gbo_ind VARCHAR2(249 CHAR) NULL,
	gcdf_desc_short VARCHAR2(249 CHAR) NULL,
	gcn_seqno VARCHAR2(249 CHAR) NULL,
	gcrt_desc VARCHAR2(249 CHAR) NULL,
	genericname VARCHAR2(249 CHAR) NULL,
	gnn60 VARCHAR2(249 CHAR) NULL,
	hts_generic VARCHAR2(256 CHAR) NULL,
	hts_generic_ext VARCHAR2(256 CHAR) NULL,
	hum_gen_med_key VARCHAR2(64 CHAR) NULL,
	hum_med_key VARCHAR2(44 CHAR) NULL,
	ln VARCHAR2(249 CHAR) NULL,
	ndc VARCHAR2(249 CHAR)  NULL,
	obsolete_flag NUMBER  NULL,
	obsoletedate VARCHAR2(249 CHAR) NULL,
	otc VARCHAR2(249 CHAR) NULL,
	pcc VARCHAR2(249 CHAR) NULL,
	pcc_label VARCHAR2(249 CHAR) NULL,
	rxa_cdr_ndc_rxcnt NUMBER  NULL,
	rxa_volrank NUMBER  NULL,
	rxo_cdr_ndc_rxcnt NUMBER  NULL,
	rxo_volrank NUMBER  NULL,
	str60 VARCHAR2(249 CHAR) NULL,
	strnum NUMBER (18, 4) NULL,
	tcc VARCHAR2(249 CHAR) NULL,
	tcc_label VARCHAR2(249 CHAR) NULL,
	volnum NUMBER (18, 4) NULL,
	volrank NUMBER  NULL,
	volrank_src VARCHAR2(11 CHAR) NULL,
	volun50 VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_hum_amb_rx_gen_cd', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_hum_amb_rx_gen_cd (
	comment0 CHAR(1) NULL,
	hts_generic VARCHAR2(256 CHAR) NULL,
	hts_generic_ext VARCHAR2(256 CHAR) NULL,
	hum_amb_grp_code VARCHAR2(20 CHAR) NULL,
	hum_amb_rx_class VARCHAR2(256 CHAR) NULL,
	hum_amb_rx_class_code VARCHAR2(32 CHAR) NULL,
	hum_amb_rx_generic_code VARCHAR2(64 CHAR) NULL,
	hum_amb_rx_grp VARCHAR2(256 CHAR) NULL,
	hum_amb_rx_subclass VARCHAR2(256 CHAR) NULL,
	hum_amb_rx_subclass_code VARCHAR2(44 CHAR) NULL,
	hum_gen_med_key VARCHAR2(64 CHAR)  NULL,
	hum_med_key VARCHAR2(44 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_icd0_dx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_icd0_dx (
	diagnosis_code VARCHAR2(249 CHAR)  NULL,
	long_description VARCHAR2(4000 CHAR) NULL,
	short_description VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_icd0_px', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_icd0_px (
	long_description VARCHAR2(4000 CHAR) NULL,
	procedure_code VARCHAR2(249 CHAR)  NULL,
	short_description VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_icd9_dx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_icd9_dx (
	diagnosis_code VARCHAR2(249 CHAR)  NULL,
	long_description VARCHAR2(4000 CHAR) NULL,
	short_description VARCHAR2(500 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_icd9_px', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_icd9_px (
	long_description VARCHAR2(4000 CHAR) NULL,
	procedure_code VARCHAR2(249 CHAR)  NULL,
	short_description VARCHAR2(500 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_disease', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_disease (
	disease_desc VARCHAR2 (1024 CHAR),
	disease_id NUMBER (10, 0),
	fileid NUMBER (10, 0),
	ii_version VARCHAR2 (249 CHAR),
	sensitive_cat VARCHAR2 (249 CHAR),
	sensitive_ind NUMBER (10, 0),
	update_version VARCHAR2 (249 CHAR),
	update_version_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_em_proc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_em_proc (
	fileid NUMBER (10, 0),
	ii_version VARCHAR2 (249 CHAR),
	modified_date TIMESTAMP,
	proccode VARCHAR2 (249 CHAR),
	row_source VARCHAR2 (10 CHAR),
	update_version VARCHAR2 (249 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_etg_comorb', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_etg_comorb (
	comorb_code VARCHAR2(249 CHAR)  NULL,
	comorb_desc VARCHAR2(249 CHAR) NULL,
	fileid NUMBER (10, 0),
	ii_version VARCHAR2 (249 CHAR),
	sensitive_cat VARCHAR2 (249 CHAR),
	sensitive_ind NUMBER (10, 0),
	update_version VARCHAR2 (249 CHAR),
	update_version_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_etg_cond', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_etg_cond (
	cond_desc VARCHAR2(249 CHAR) NULL,
	cond_status VARCHAR2(249 CHAR)  NULL,
	fileid NUMBER (10, 0),
	ii_version VARCHAR2 (249 CHAR),
	sensitive_cat VARCHAR2 (249 CHAR),
	sensitive_ind NUMBER (10, 0),
	update_version VARCHAR2 (249 CHAR),
	update_version_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_etg_tx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_etg_tx (
	fileid NUMBER   NULL,
	ii_version VARCHAR2(249 CHAR) NULL,
	sensitive_cat VARCHAR2(249 CHAR) NULL,
	sensitive_ind VARCHAR2(249 CHAR) NULL,
	tx_code VARCHAR2(249 CHAR) NULL,
	tx_desc VARCHAR2(249 CHAR) NULL,
	update_version VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_pcpserv_cat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_pcpserv_cat (
	cms_pccem NUMBER  NULL,
	fileid NUMBER   NULL,
	pcc NUMBER  NULL,
	pccem NUMBER  NULL,
	proccode VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_peg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_peg (
	fileid NUMBER   NULL,
	ii_version VARCHAR2(249 CHAR) NULL,
	peg_cat_desc VARCHAR2(249 CHAR) NULL,
	peg_cat_id VARCHAR2(249 CHAR) NULL,
	sensitive_cat VARCHAR2(249 CHAR) NULL,
	sensitive_ind VARCHAR2(249 CHAR) NULL,
	update_version VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_peg_target', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_peg_target (
	fileid NUMBER (10, 0),
	ii_version VARCHAR2 (249 CHAR),
	peg_target NUMBER (10, 0),
	peg_target_desc VARCHAR2 (249 CHAR),
	sensitive_cat VARCHAR2 (249 CHAR),
	sensitive_ind NUMBER (10, 0),
	update_version VARCHAR2 (249 CHAR),
	update_version_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_pos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_pos (
	pos_desc VARCHAR2(249 CHAR) NULL,
	pos_i VARCHAR2(249 CHAR)  NULL,
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_region', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_region (
	cens_reg NUMBER (3) NOT NULL,
	cens_reg_desc VARCHAR2(30 CHAR) NOT NULL,
	county_desc VARCHAR2(40 CHAR) NOT NULL,
	county_id NUMBER (12) NOT NULL,
	fileid NUMBER   NULL,
	state NUMBER (3) NOT NULL,
	state_desc CHAR(2) NOT NULL,
	zip CHAR(5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_spec (
	etg_top VARCHAR2(249 CHAR) NULL,
	prv_sp_4 VARCHAR2(249 CHAR)  NULL,
	prv_sp_i VARCHAR2(249 CHAR) NULL,
	sp1 VARCHAR2(249 CHAR) NULL,
	sp1_id VARCHAR2(249 CHAR) NULL,
	sp2 VARCHAR2(249 CHAR) NULL,
	sp2_id VARCHAR2(249 CHAR) NULL,
	sp3 VARCHAR2(249 CHAR) NULL,
	sp3_id VARCHAR2(249 CHAR) NULL,
	sp4 VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_tos_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_tos_type (
	fac_type VARCHAR2(249 CHAR) NULL,
	modified_date TIMESTAMP,
	pos_i VARCHAR2(249 CHAR) NULL,
	prv_sp_4 VARCHAR2(249 CHAR)  NULL,
	row_source VARCHAR2 (10 CHAR),
	tos_map_type VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_util_spec_cat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_util_spec_cat (
	def_util_spec_cat VARCHAR2(249 CHAR) NULL,
	sensitive_ind NUMBER (10, 0),
	util_spec1 VARCHAR2(249 CHAR) NULL,
	util_spec2 VARCHAR2(249 CHAR) NULL,
	util_spec_cat_cd VARCHAR2(249 CHAR)  NULL,
	util_spec_cat_desc VARCHAR2(249 CHAR) NULL,
	util_spec_id1 VARCHAR2(249 CHAR) NULL,
	util_spec_id2 VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_map_ccs_icdx_dx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_map_ccs_icdx_dx (
	ccs_category VARCHAR2(40 CHAR) NULL,
	ccs_category_desc VARCHAR2(249 CHAR) NULL,
	hum_year VARCHAR2(249 CHAR)  NULL,
	icd_cm_code VARCHAR2(249 CHAR) NULL,
	icd_cm_code_desc VARCHAR2(249 CHAR) NULL,
	icd_version VARCHAR2(249 CHAR) NULL,
	optional_ccs_category VARCHAR2(40 CHAR) NULL,
	optional_ccs_category_desc VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_map_ccs_icdx_px', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_map_ccs_icdx_px (
	ccs_category VARCHAR2(40 CHAR) NULL,
	ccs_category_desc VARCHAR2(249 CHAR) NULL,
	hum_year VARCHAR2(249 CHAR)  NULL,
	icd_cm_code VARCHAR2(249 CHAR) NULL,
	icd_cm_code_desc VARCHAR2(249 CHAR) NULL,
	icd_version VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_mdc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_mdc (
	mdc_code VARCHAR2(2 CHAR)  NULL,
	mdc_desc VARCHAR2(255 CHAR) NULL,
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_aprdrg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_aprdrg (
	aprdrg CHAR(3)  NULL,
	aprdrg_desc VARCHAR2(63 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_cpt', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_cpt (
	cpt_code VARCHAR2(10 CHAR) NOT NULL,
	modified_date TIMESTAMP,
	restricted_cat VARCHAR2(255 CHAR) NOT NULL,
	row_source VARCHAR2 (10 CHAR),
	short_desc VARCHAR2(255 CHAR) NOT NULL,
	version_year NUMBER  NOT  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_drg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_drg (
	drg VARCHAR2(4 CHAR) NULL,
	drg_description VARCHAR2(100 CHAR) NULL,
	drg_type_cui CHAR(8)  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_ebm', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_ebm (
	ebm_measure_desc VARCHAR2 (1600 CHAR),
	fileid NUMBER (10, 0),
	ii_version VARCHAR2 (249 CHAR),
	modified_date TIMESTAMP,
	row_source VARCHAR2 (10 CHAR),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0),
	sensitive_cat VARCHAR2 (249 CHAR),
	sensitive_ind NUMBER (10, 0),
	update_version VARCHAR2 (249 CHAR),
	update_version_dt TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_etg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_etg (
	etg_id NUMBER (6)  NULL,
	etg_impact VARCHAR2(8 CHAR) NULL,
	etg_impact_desc VARCHAR2(150 CHAR) NULL,
	family NUMBER (6) NULL,
	mpc NUMBER (6) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_hcpcs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_hcpcs (
	code VARCHAR2(10 CHAR) NOT NULL,
	coverage_instr_ref VARCHAR2(255 CHAR) NULL,
	modified_date TIMESTAMP,
	restricted_cat VARCHAR2(255 CHAR) NOT NULL,
	row_source VARCHAR2 (10 CHAR),
	short_description VARCHAR2(255 CHAR) NOT NULL,
	year NUMBER  NOT  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_icd0_dx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_icd0_dx (
	diag_code VARCHAR2(249 CHAR)  NULL,
	long_desc VARCHAR2(249 CHAR) NULL,
	modified_date TIMESTAMP,
	row_source VARCHAR2 (10 CHAR),
	short_desc VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_icd0_px', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_icd0_px (
	long_desc VARCHAR2(249 CHAR) NULL,
	modified_date TIMESTAMP,
	proc_code VARCHAR2(249 CHAR)  NULL,
	row_source VARCHAR2 (10 CHAR),
	short_desc VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_icd9_dx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_icd9_dx (
	humedica_desc VARCHAR2(249 CHAR) NULL,
	icd9_code VARCHAR2(249 CHAR)  NULL,
	modified_date TIMESTAMP,
	new_desc VARCHAR2(249 CHAR) NULL,
	row_source VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_icd9_px', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_icd9_px (
	full_desc VARCHAR2(249 CHAR) NULL,
	modified_date TIMESTAMP,
	proc_code VARCHAR2(249 CHAR)  NULL,
	row_source VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_revenue', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_revenue (
	description VARCHAR2(249 CHAR) NULL,
	rev_code VARCHAR2(249 CHAR)  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_tos (
	tos1 VARCHAR2(100 CHAR) NULL,
	tos2 VARCHAR2(100 CHAR) NULL,
	tos3 VARCHAR2(120 CHAR) NULL,
	tos4 VARCHAR2(255 CHAR) NULL,
	tos5 VARCHAR2(255 CHAR) NULL,
	tos_i_5 NUMBER (9)  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_snomed_icd10', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_snomed_icd10 (
	icd10_code VARCHAR2(249 CHAR) NULL,
	icd10_name VARCHAR2(4000 CHAR) NULL,
	snomed_id VARCHAR2(249 CHAR)  NULL,
	snomed_name VARCHAR2(4000 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_snomed_icd9', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_snomed_icd9 (
	icd9cm_code VARCHAR2(249 CHAR) NULL,
	icd9cm_name VARCHAR2(4000 CHAR) NULL,
	snomed_id VARCHAR2(249 CHAR)  NULL,
	snomed_name VARCHAR2(4000 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sre_marker_types', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sre_marker_types (
	marker_type VARCHAR2(10 CHAR) NOT  NULL,
	marker_type_desc VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sre_markers', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sre_markers (
	marker_id VARCHAR2(11 CHAR) NOT  NULL,
	marker_longdesc VARCHAR2(255 CHAR) NOT NULL,
	marker_shortdesc VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_term_dict_loinc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_term_dict_loinc (
	askatorderentry VARCHAR2(249 CHAR) NULL,
	associatedobservations VARCHAR2(249 CHAR) NULL,
	cdisc_common_tests VARCHAR2(249 CHAR) NULL,
	"CLASS" VARCHAR2(249 CHAR) NULL,
	classtype VARCHAR2(249 CHAR) NULL,
	common_order_rank VARCHAR2(249 CHAR) NULL,
	common_si_test_rank VARCHAR2(249 CHAR) NULL,
	common_test_rank VARCHAR2(249 CHAR) NULL,
	component VARCHAR2(249 CHAR) NULL,
	consumer_name VARCHAR2(249 CHAR) NULL,
	example_units VARCHAR2(249 CHAR) NULL,
	loinc_num VARCHAR2(249 CHAR) NULL,
	long_common_name VARCHAR2(4000 CHAR) NULL,
	method_typ VARCHAR2(249 CHAR) NULL,
	order_obs VARCHAR2(249 CHAR) NULL,
	paneltype VARCHAR2(249 CHAR) NULL,
	property VARCHAR2(249 CHAR) NULL,
	release_date VARCHAR2(249 CHAR) NULL,
	scale_typ VARCHAR2(249 CHAR) NULL,
	shortname VARCHAR2(249 CHAR) NULL,
	status VARCHAR2(249 CHAR) NULL,
	status_reason VARCHAR2(249 CHAR) NULL,
	status_text VARCHAR2(4000 CHAR) NULL,
	submitted_units VARCHAR2(249 CHAR) NULL,
	system VARCHAR2(249 CHAR) NULL,
	time_aspct VARCHAR2(249 CHAR) NULL,
	unitsandrange VARCHAR2(4000 CHAR) NULL,
	unitsrequired VARCHAR2(249 CHAR) NULL,
	version VARCHAR2(249 CHAR)  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_vw_ref_drg_reference', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_vw_ref_drg_reference (
	alos NUMBER  NULL,
	drg VARCHAR2(4 CHAR) NULL,
	drg_category VARCHAR2(10 CHAR) NULL,
	drg_description VARCHAR2(249 CHAR) NULL,
	drg_type_cui CHAR(8) NULL,
	final_rule_post_acute_drg VARCHAR2(10 CHAR) NULL,
	final_rule_special_pay_drg VARCHAR2(10 CHAR) NULL,
	gelos NUMBER  NULL,
	mdc VARCHAR2(10 CHAR) NULL,
	weight NUMBER  NULL,
	year VARCHAR2(4 CHAR)  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('md_inst_info', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE md_inst_info (
	attribute VARCHAR2(30 CHAR) NOT  NULL,
	description VARCHAR2(255 CHAR) NULL,
	modified_date TIMESTAMP,
	row_source VARCHAR2 (10 CHAR),
	value VARCHAR2(100 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_treatment_type_base', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_treatment_type_base (
	begin_range NUMBER  NULL,
	data_type VARCHAR2(10 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	end_range NUMBER  NULL,
	round_prec NUMBER  NULL,
	treatment_type_cui VARCHAR2(50 CHAR) NOT  NULL,
	treatment_type_std_units VARCHAR2(50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_venue', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_venue (
	venue VARCHAR2(8 CHAR)  NULL,
	venue_desc VARCHAR2(100 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_place_of_service', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_place_of_service (
	dts_version NUMBER  NOT NULL,
	hts_cui VARCHAR2(255 CHAR) NOT  NULL,
	ii_code VARCHAR2(255 CHAR) NULL,
	ii_name VARCHAR2(255 CHAR) NULL,
	pe_cc_code VARCHAR2(255 CHAR) NULL,
	pe_cc_name VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_cui_ii_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_cui_ii_spec (
	cc_code VARCHAR2(255 CHAR) NULL,
	cc_name VARCHAR2(255 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	hts_cui VARCHAR2(255 CHAR) NOT  NULL,
	ii_code VARCHAR2(255 CHAR) NULL,
	ii_name VARCHAR2(255 CHAR) NULL,
	pe_cc_code VARCHAR2(255 CHAR) NULL,
	pe_cc_name VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_age_buckets', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_age_buckets (
	age_cat2 NUMBER (10, 0),
	age_lab2 VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_pop_morb_cat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_pop_morb_cat (
	distrib_label VARCHAR2 (12 CHAR),
	high NUMBER (19, 2),
	low NUMBER (19, 2),
	pop_morb_intrvl NUMBER (19, 2)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_clinical_event_encounter', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_clinical_event_encounter (
	client_ds_id NUMBER (10, 0),
	client_id VARCHAR2 (16 CHAR),
	encounter_grp_num NUMBER (19, 0),
	encounterid VARCHAR2 (255 CHAR),
	encounteridtype_cui VARCHAR2 (8 CHAR),
	mpi VARCHAR2 (32 CHAR),
	patienttype_cui VARCHAR2 (8 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_diagnosis_cui', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_diagnosis_cui (
	codetype VARCHAR2 (16 CHAR),
	cui VARCHAR2 (16 CHAR),
	mappedcode VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_procedure_cui', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_procedure_cui (
	codetype VARCHAR2 (16 CHAR),
	cui VARCHAR2 (16 CHAR),
	mappedcode VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_diag', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_diag (
	code_type VARCHAR2 (10 CHAR),
	diag_cd VARCHAR2 (20 CHAR),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_sensitive_proc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_sensitive_proc (
	code_type VARCHAR2(10 CHAR) NOT NULL,
	proc_cd VARCHAR2(20 CHAR) NOT NULL,
	sensitive_ind NUMBER(1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_clinical_event_id', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_clinical_event_id (
	client_ds_id NUMBER NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id VARCHAR2 (20 CHAR) NOT NULL,
	id_type VARCHAR2 (20 CHAR) NOT NULL,
	id_value VARCHAR2 (50 CHAR) NOT NULL
	) PARTITION BY HASH(clinical_event_id) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_assess_qual_value', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_assess_qual_value (
	assessment_cui VARCHAR2 (8 CHAR) NOT NULL,
	value_cui VARCHAR2 (8 CHAR) NOT NULL,
	value_name VARCHAR2 (150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_assessment', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_assessment (
	assessment_cui VARCHAR2 (8 CHAR) NOT NULL,
	assessment_name VARCHAR2 (150 CHAR) NOT NULL,
	assessment_units VARCHAR2 (50 CHAR),
	lab_ind NUMBER (1) NOT NULL,
	qualitative_ind NUMBER (1) DEFAULT 0 NOT NULL,
	quantitative_ind NUMBER (1) DEFAULT 0 NOT NULL,
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_ndc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_ndc (
	dcc VARCHAR2 (5 CHAR),
	deleted_ind NUMBER (1),
	doseform_desc VARCHAR2 (120 CHAR),
	gbo NUMBER (3),
	gbo_desc VARCHAR2 (120 CHAR),
	generic_name VARCHAR2 (120 CHAR),
	label_name VARCHAR2 (120 CHAR),
	ndc VARCHAR2 (11 CHAR),
	obsolete_dt DATE,
	obsolete_ind NUMBER (1),
	otc_ind NUMBER (1),
	pcc VARCHAR2 (3 CHAR),
	pcc_desc VARCHAR2 (120 CHAR),
	route_desc VARCHAR2 (120 CHAR),
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL,
	strength VARCHAR2 (120 CHAR),
	strength_nbr NUMBER (18, 4),
	strength_unit VARCHAR2 (120 CHAR),
	tcc VARCHAR2 (2 CHAR),
	tcc_desc VARCHAR2 (120 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_confinements', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_confinements (
	"CLUSTER" NUMBER (10, 0),
	"EXCLUDE" NUMBER (1),
	acw_srv NUMBER (9) NULL,
	admit NUMBER (1) NULL,
	admit_source VARCHAR2 (1 CHAR),
	amt_admin_fee NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2) NULL,
	amt_cob NUMBER (19, 2) NULL,
	amt_coin NUMBER (19, 2) NULL,
	amt_cop NUMBER (19, 2) NULL,
	amt_ded NUMBER (19, 2) NULL,
	amt_eqv NUMBER (19, 2) NULL,
	amt_eqv_cf NUMBER (19, 2) NULL,
	amt_liab NUMBER (19, 2) NULL,
	amt_not_covered NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2) NULL,
	amt_oth2 NUMBER (19, 2) NULL,
	amt_oth3 NUMBER (19, 2) NULL,
	amt_oth4 NUMBER (19, 2) NULL,
	amt_other_carrier_pay NUMBER (19, 2),
	amt_pay NUMBER (19, 2) NULL,
	amt_pay_cf NUMBER (19, 2) NULL,
	amt_req NUMBER (19, 2) NULL,
	amt_wth NUMBER (19, 2) NULL,
	avoidable_admit_flag NUMBER (10, 0),
	beg_dt DATE  NULL,
	bill_drg_id VARCHAR2 (12 CHAR),
	bill_provider_id VARCHAR2 (20 CHAR),
	clm_type CHAR(1) NULL,
	clus_prv VARCHAR2(20 CHAR) NULL,
	conf_num NUMBER (10) NULL,
	contract_id VARCHAR2 (40 CHAR),
	covid_flag NUMBER (1),
	cust_med_1 VARCHAR2 (255 CHAR),
	cust_med_10 VARCHAR2 (255 CHAR),
	cust_med_11 VARCHAR2 (255 CHAR),
	cust_med_12 VARCHAR2 (255 CHAR),
	cust_med_13 VARCHAR2 (255 CHAR),
	cust_med_14 VARCHAR2 (255 CHAR),
	cust_med_15 VARCHAR2 (255 CHAR),
	cust_med_16 NUMBER (38, 10),
	cust_med_17 NUMBER (38, 10),
	cust_med_18 NUMBER (38, 10),
	cust_med_19 NUMBER (38, 10),
	cust_med_2 VARCHAR2 (255 CHAR),
	cust_med_20 NUMBER (38, 10),
	cust_med_3 VARCHAR2 (255 CHAR),
	cust_med_4 VARCHAR2 (255 CHAR),
	cust_med_5 VARCHAR2 (255 CHAR),
	cust_med_6 VARCHAR2 (255 CHAR),
	cust_med_7 VARCHAR2 (255 CHAR),
	cust_med_8 VARCHAR2 (255 CHAR),
	cust_med_9 VARCHAR2 (255 CHAR),
	cust_med_pk_id VARCHAR2 (32 CHAR),
	diag1 VARCHAR2(8 CHAR) NULL,
	diag10 VARCHAR2(8 CHAR) NULL,
	diag11 VARCHAR2 (8 CHAR),
	diag12 VARCHAR2 (8 CHAR),
	diag13 VARCHAR2 (8 CHAR),
	diag14 VARCHAR2 (8 CHAR),
	diag15 VARCHAR2 (8 CHAR),
	diag16 VARCHAR2 (8 CHAR),
	diag17 VARCHAR2 (8 CHAR),
	diag18 VARCHAR2 (8 CHAR),
	diag19 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2(8 CHAR) NULL,
	diag20 VARCHAR2 (8 CHAR),
	diag21 VARCHAR2 (8 CHAR),
	diag22 VARCHAR2 (8 CHAR),
	diag23 VARCHAR2 (8 CHAR),
	diag24 VARCHAR2 (8 CHAR),
	diag25 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2(8 CHAR) NULL,
	diag4 VARCHAR2(8 CHAR) NULL,
	diag5 VARCHAR2(8 CHAR) NULL,
	diag6 VARCHAR2(8 CHAR) NULL,
	diag7 VARCHAR2(8 CHAR) NULL,
	diag8 VARCHAR2(8 CHAR) NULL,
	diag9 VARCHAR2(8 CHAR) NULL,
	dis_stat VARCHAR2(3 CHAR) NULL,
	disrel NUMBER (9) NULL,
	drg_admittyp VARCHAR2(3 CHAR) NULL,
	drg_id VARCHAR2(12 CHAR) NULL,
	drg_outlier NUMBER (9) NULL,
	encounter NUMBER (19, 2) NULL,
	end_dt DATE  NULL,
	episode_id NUMBER (19, 0),
	er_conf NUMBER (1),
	etg VARCHAR2(9 CHAR) NULL,
	etg_id NUMBER (9) NULL,
	etg_sub_id VARCHAR2 (7 CHAR),
	ia_time NUMBER (6) NULL,
	icd_version NUMBER (3) NULL,
	icustay NUMBER (9) NULL,
	icusurg NUMBER (9) NULL,
	inp_admit_type VARCHAR2 (2 CHAR),
	iproc1 VARCHAR2(7 CHAR) NULL,
	iproc10 VARCHAR2 (7 CHAR),
	iproc11 VARCHAR2 (7 CHAR),
	iproc12 VARCHAR2 (7 CHAR),
	iproc13 VARCHAR2 (7 CHAR),
	iproc14 VARCHAR2 (7 CHAR),
	iproc15 VARCHAR2 (7 CHAR),
	iproc16 VARCHAR2 (7 CHAR),
	iproc17 VARCHAR2 (7 CHAR),
	iproc18 VARCHAR2 (7 CHAR),
	iproc19 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2(7 CHAR) NULL,
	iproc20 VARCHAR2 (7 CHAR),
	iproc21 VARCHAR2 (7 CHAR),
	iproc22 VARCHAR2 (7 CHAR),
	iproc23 VARCHAR2 (7 CHAR),
	iproc24 VARCHAR2 (7 CHAR),
	iproc25 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2(7 CHAR) NULL,
	iproc4 VARCHAR2(7 CHAR) NULL,
	iproc5 VARCHAR2(7 CHAR) NULL,
	iproc6 VARCHAR2(7 CHAR) NULL,
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	lag_days NUMBER (9) NULL,
	lag_ind NUMBER (1) NULL,
	los NUMBER (19, 2) NULL,
	matern NUMBER (9) NULL,
	member VARCHAR2(32 CHAR) NULL,
	msurg NUMBER (9) NULL,
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (9) NULL,
	newborn NUMBER (9) NULL,
	noenr_dos NUMBER (1) NULL,
	pac_rsnf_index NUMBER (1),
	pac_rsnf_postconf NUMBER (19, 0),
	pac_rsnf_preconf NUMBER (19, 0),
	pac_rsnf_readm_days NUMBER (10, 0),
	pac_rsnf_readmit NUMBER (1),
	pay_dt DATE  NULL,
	pay_dt_beg DATE  NULL,
	pdi NUMBER (10, 0),
	peg_episode_id NUMBER (19, 0),
	planned_adm NUMBER (1),
	poa CHAR(1) NULL,
	pos_i NUMBER (9) NULL,
	pqi NUMBER (10, 0),
	prfl_clm NUMBER (9) NULL,
	provider_id VARCHAR2(20 CHAR) NULL,
	provider_status_id VARCHAR2 (40 CHAR),
	prv_beg VARCHAR2(20 CHAR) NULL,
	prv_sp_4 NUMBER (9) NULL,
	psc_cat1_id NUMBER (9) NULL,
	psc_cat2_id NUMBER (9) NULL,
	readmit_07 NUMBER (1) NULL,
	readmit_30 NUMBER (1) NULL,
	readmit_60 NUMBER (1) NULL,
	readmit_90 NUMBER (1) NULL,
	readmit_conf_07 NUMBER (10) NULL,
	readmit_conf_30 NUMBER (10) NULL,
	readmit_conf_60 NUMBER (10) NULL,
	readmit_conf_90 NUMBER (10) NULL,
	readmit_index_07 NUMBER (1) NULL,
	readmit_index_30 NUMBER (1) NULL,
	readmit_index_60 NUMBER (1) NULL,
	readmit_index_90 NUMBER (1) NULL,
	rec_type CHAR(1) NULL,
	rehab NUMBER (10, 0),
	rsnf NUMBER (9) NULL,
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (9) NULL,
	snf NUMBER (10, 0),
	sub_episode_num NUMBER (10, 0),
	tos_i_4 NUMBER (9) NULL,
	tos_i_5 NUMBER (9) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_services_rx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_services_rx (
	"CLUSTER" NUMBER (10, 0),
	"EXCLUDE" NUMBER (1),
	acw_srv NUMBER (10, 0),
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cap_pay_k NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_cob_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_ded_k NUMBER (19, 2),
	amt_disp NUMBER (19, 2),
	amt_disp_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_cf NUMBER (19, 4),
	amt_eqv_k NUMBER (19, 2),
	amt_ingr NUMBER (19, 2),
	amt_ingr_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth1_k NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth2_k NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth3_k NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_oth4_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_cf NUMBER (19, 4),
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	amt_sales_tax NUMBER (19, 2),
	amt_sales_tax_k NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	amt_wth_k NUMBER (19, 2),
	cap_flag NUMBER (1),
	channel NUMBER (10, 0),
	claim_id VARCHAR2 (30 CHAR),
	clm_id_n VARCHAR2 (30 CHAR),
	clm_type VARCHAR2 (1 CHAR),
	clus_prv VARCHAR2 (20 CHAR),
	contract_id VARCHAR2 (40 CHAR),
	covid_flag NUMBER (1),
	cust_rx_1 VARCHAR2 (255 CHAR),
	cust_rx_10 VARCHAR2 (255 CHAR),
	cust_rx_11 VARCHAR2 (255 CHAR),
	cust_rx_12 VARCHAR2 (255 CHAR),
	cust_rx_13 VARCHAR2 (255 CHAR),
	cust_rx_14 VARCHAR2 (255 CHAR),
	cust_rx_15 VARCHAR2 (255 CHAR),
	cust_rx_16 NUMBER (38, 10),
	cust_rx_17 NUMBER (38, 10),
	cust_rx_18 NUMBER (38, 10),
	cust_rx_19 NUMBER (38, 10),
	cust_rx_2 VARCHAR2 (255 CHAR),
	cust_rx_20 NUMBER (38, 10),
	cust_rx_3 VARCHAR2 (255 CHAR),
	cust_rx_4 VARCHAR2 (255 CHAR),
	cust_rx_5 VARCHAR2 (255 CHAR),
	cust_rx_6 VARCHAR2 (255 CHAR),
	cust_rx_7 VARCHAR2 (255 CHAR),
	cust_rx_8 VARCHAR2 (255 CHAR),
	cust_rx_9 VARCHAR2 (255 CHAR),
	cust_rx_pk_id VARCHAR2 (32 CHAR),
	daw NUMBER (10, 0),
	days_sup NUMBER (10, 0),
	days_sup_k NUMBER (10, 0),
	dcc VARCHAR2 (5 CHAR),
	dea VARCHAR2 (15 CHAR),
	denied_ind_id VARCHAR2 (40 CHAR),
	disrel NUMBER (10, 0),
	dos TIMESTAMP,
	enc_k NUMBER (19, 2),
	encounter NUMBER (19, 2),
	episode_id NUMBER (19, 0),
	etg VARCHAR2 (9 CHAR),
	etg_id NUMBER (10, 0),
	etg_sub_id VARCHAR2 (7 CHAR),
	formulary NUMBER (10, 0),
	gbo NUMBER (10, 0),
	generic NUMBER (1),
	generic_k NUMBER (1),
	ia_time NUMBER (10, 0),
	lag_days NUMBER (10, 0),
	lag_ind NUMBER (1),
	map_srce_e VARCHAR2 (6 CHAR),
	map_srce_n VARCHAR2 (6 CHAR),
	map_srce_p VARCHAR2 (6 CHAR),
	member VARCHAR2 (32 CHAR),
	met_qty NUMBER (19, 2),
	met_qty_k NUMBER (19, 2),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1),
	noenr_dos NUMBER (1),
	pay_dt TIMESTAMP,
	peg_episode_id NUMBER (19, 0),
	pres_prov_affil_id VARCHAR2 (40 CHAR),
	pres_provider_id VARCHAR2 (20 CHAR),
	pres_prv_i VARCHAR2 (20 CHAR),
	prfl_clm NUMBER (10, 0),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	psc_cat1_id NUMBER (10, 0),
	psc_cat2_id NUMBER (10, 0),
	pseudo NUMBER (1),
	rec_type VARCHAR2 (1 CHAR),
	refill_num NUMBER (10, 0),
	rx_count_n NUMBER (4, 2),
	rx_count_n_k NUMBER (4, 2),
	script NUMBER (19, 2),
	script_adj NUMBER (19, 2),
	script_adj_k NUMBER (19, 2),
	script_gen NUMBER (1),
	script_gen_k NUMBER (1),
	script_k NUMBER (19, 2),
	sev_level NUMBER (10, 0),
	spec_drug NUMBER (10, 0),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	sub_episode_num NUMBER (10, 0),
	svc_grp VARCHAR2 (30 CHAR),
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	uniq_rec_id NUMBER (19, 0),
	user_spec_drug NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_services_inp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_services_inp (
	"EXCLUDE" NUMBER (1),
	admit_source VARCHAR2 (1 CHAR),
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2),
	amt_cap_pay_k NUMBER (19, 2),
	amt_cob NUMBER (19, 2),
	amt_cob_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2),
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2),
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2),
	amt_ded_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2),
	amt_eqv_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2),
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2),
	amt_oth1_k NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2),
	amt_oth2_k NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2),
	amt_oth3_k NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2),
	amt_oth4_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2),
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	amt_wth NUMBER (19, 2),
	amt_wth_k NUMBER (19, 2),
	bill_drg_id VARCHAR2 (12 CHAR),
	bill_drg_outlier NUMBER (10, 0),
	bill_provider_id VARCHAR2 (20 CHAR),
	bill_type VARCHAR2 (4 CHAR),
	cap_flag NUMBER (1),
	claim_id VARCHAR2 (30 CHAR),
	clm_id_n VARCHAR2 (30 CHAR),
	clm_type VARCHAR2 (1 CHAR),
	conf_num NUMBER (19, 0),
	contract_id VARCHAR2 (40 CHAR),
	cust_med_1 VARCHAR2 (255 CHAR),
	cust_med_10 VARCHAR2 (255 CHAR),
	cust_med_11 VARCHAR2 (255 CHAR),
	cust_med_12 VARCHAR2 (255 CHAR),
	cust_med_13 VARCHAR2 (255 CHAR),
	cust_med_14 VARCHAR2 (255 CHAR),
	cust_med_15 VARCHAR2 (255 CHAR),
	cust_med_16 NUMBER (38, 10),
	cust_med_17 NUMBER (38, 10),
	cust_med_18 NUMBER (38, 10),
	cust_med_19 NUMBER (38, 10),
	cust_med_2 VARCHAR2 (255 CHAR),
	cust_med_20 NUMBER (38, 10),
	cust_med_3 VARCHAR2 (255 CHAR),
	cust_med_4 VARCHAR2 (255 CHAR),
	cust_med_5 VARCHAR2 (255 CHAR),
	cust_med_6 VARCHAR2 (255 CHAR),
	cust_med_7 VARCHAR2 (255 CHAR),
	cust_med_8 VARCHAR2 (255 CHAR),
	cust_med_9 VARCHAR2 (255 CHAR),
	cust_med_pk_id VARCHAR2 (32 CHAR),
	cvx_code VARCHAR2 (3 CHAR),
	denied_ind_id VARCHAR2 (40 CHAR),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag11 VARCHAR2 (8 CHAR),
	diag12 VARCHAR2 (8 CHAR),
	diag13 VARCHAR2 (8 CHAR),
	diag14 VARCHAR2 (8 CHAR),
	diag15 VARCHAR2 (8 CHAR),
	diag16 VARCHAR2 (8 CHAR),
	diag17 VARCHAR2 (8 CHAR),
	diag18 VARCHAR2 (8 CHAR),
	diag19 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag20 VARCHAR2 (8 CHAR),
	diag21 VARCHAR2 (8 CHAR),
	diag22 VARCHAR2 (8 CHAR),
	diag23 VARCHAR2 (8 CHAR),
	diag24 VARCHAR2 (8 CHAR),
	diag25 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	dis_stat VARCHAR2 (3 CHAR),
	dos TIMESTAMP,
	drg_id VARCHAR2 (12 CHAR),
	drg_outlier NUMBER (10, 0),
	er_conf NUMBER (1),
	er_flag NUMBER (1),
	from_dt TIMESTAMP,
	ia_time NUMBER (10, 0),
	icd_version NUMBER (10, 0),
	inp_admit_type VARCHAR2 (2 CHAR),
	iproc1 VARCHAR2 (7 CHAR),
	iproc10 VARCHAR2 (7 CHAR),
	iproc11 VARCHAR2 (7 CHAR),
	iproc12 VARCHAR2 (7 CHAR),
	iproc13 VARCHAR2 (7 CHAR),
	iproc14 VARCHAR2 (7 CHAR),
	iproc15 VARCHAR2 (7 CHAR),
	iproc16 VARCHAR2 (7 CHAR),
	iproc17 VARCHAR2 (7 CHAR),
	iproc18 VARCHAR2 (7 CHAR),
	iproc19 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2 (7 CHAR),
	iproc20 VARCHAR2 (7 CHAR),
	iproc21 VARCHAR2 (7 CHAR),
	iproc22 VARCHAR2 (7 CHAR),
	iproc23 VARCHAR2 (7 CHAR),
	iproc24 VARCHAR2 (7 CHAR),
	iproc25 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2 (7 CHAR),
	iproc4 VARCHAR2 (7 CHAR),
	iproc5 VARCHAR2 (7 CHAR),
	iproc6 VARCHAR2 (7 CHAR),
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	line_nat VARCHAR2 (10 CHAR),
	local_flag NUMBER (10, 0),
	map_srce_e VARCHAR2 (6 CHAR),
	map_srce_n VARCHAR2 (6 CHAR),
	map_srce_p VARCHAR2 (6 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	mod_n_2 VARCHAR2 (4 CHAR),
	mod_n_3 VARCHAR2 (4 CHAR),
	mod_n_4 VARCHAR2 (4 CHAR),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1),
	noenr_dos NUMBER (1),
	obs_flag NUMBER (1),
	order_prov VARCHAR2 (20 CHAR),
	pay_dt TIMESTAMP,
	poa VARCHAR2 (1 CHAR),
	poa10 VARCHAR2 (1 CHAR),
	poa2 VARCHAR2 (1 CHAR),
	poa3 VARCHAR2 (1 CHAR),
	poa4 VARCHAR2 (1 CHAR),
	poa5 VARCHAR2 (1 CHAR),
	poa6 VARCHAR2 (1 CHAR),
	poa7 VARCHAR2 (1 CHAR),
	poa8 VARCHAR2 (1 CHAR),
	poa9 VARCHAR2 (1 CHAR),
	pos_i NUMBER (10, 0),
	pos_n VARCHAR2 (3 CHAR),
	proccode VARCHAR2 (15 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	prv_sp_n VARCHAR2 (30 CHAR),
	qty NUMBER (10, 0),
	qty_k NUMBER (10, 0),
	refer_prov VARCHAR2 (20 CHAR),
	revenue VARCHAR2 (15 CHAR),
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	svc_grp VARCHAR2 (30 CHAR),
	to_dt TIMESTAMP,
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tos_n VARCHAR2 (30 CHAR),
	uniq_rec_id NUMBER (19, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_services_med', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_services_med (
	"CLUSTER" NUMBER (10, 0),
	"EXCLUDE" NUMBER (1),
	acw_srv NUMBER (3) NULL,
	admit_source VARCHAR2 (1 CHAR),
	amb_sens NUMBER (10, 0),
	amt_admin_fee NUMBER (19, 2),
	amt_admin_fee_k NUMBER (19, 2),
	amt_cap_pay NUMBER (19, 2) NULL,
	amt_cap_pay_k NUMBER (19, 2),
	amt_cob NUMBER (19, 2) NULL,
	amt_cob_k NUMBER (19, 2),
	amt_coin NUMBER (19, 2) NULL,
	amt_coin_k NUMBER (19, 2),
	amt_cop NUMBER (19, 2) NULL,
	amt_cop_k NUMBER (19, 2),
	amt_ded NUMBER (19, 2) NULL,
	amt_ded_k NUMBER (19, 2),
	amt_eqv NUMBER (19, 2) NULL,
	amt_eqv_cf NUMBER (19, 2) NULL,
	amt_eqv_k NUMBER (19, 2),
	amt_liab NUMBER (19, 2) NULL,
	amt_liab_k NUMBER (19, 2),
	amt_not_covered NUMBER (19, 2),
	amt_not_covered_k NUMBER (19, 2),
	amt_np NUMBER (19, 2),
	amt_np_k NUMBER (19, 2),
	amt_oth1 NUMBER (19, 2) NULL,
	amt_oth1_k NUMBER (19, 2),
	amt_oth2 NUMBER (19, 2) NULL,
	amt_oth2_k NUMBER (19, 2),
	amt_oth3 NUMBER (19, 2) NULL,
	amt_oth3_k NUMBER (19, 2),
	amt_oth4 NUMBER (19, 2) NULL,
	amt_oth4_k NUMBER (19, 2),
	amt_other_carrier_pay NUMBER (19, 2),
	amt_other_carrier_pay_k NUMBER (19, 2),
	amt_pay NUMBER (19, 2) NULL,
	amt_pay_cf NUMBER (19, 2) NULL,
	amt_pay_k NUMBER (19, 2),
	amt_req NUMBER (19, 2) NULL,
	amt_req_k NUMBER (19, 2),
	amt_wth NUMBER (19, 2) NULL,
	amt_wth_k NUMBER (19, 2),
	bill_drg_id VARCHAR2 (12 CHAR),
	bill_drg_outlier NUMBER (10, 0),
	bill_provider_id VARCHAR2 (20 CHAR),
	bill_type VARCHAR2 (4 CHAR),
	cap_flag NUMBER (1),
	claim_id VARCHAR2(30 CHAR) NULL,
	clm_id_n VARCHAR2(30 CHAR) NULL,
	clm_type CHAR(1) NULL,
	clus_prv VARCHAR2(20 CHAR) NULL,
	conf_num NUMBER (9) NULL,
	contract_id VARCHAR2 (40 CHAR),
	cov_order NUMBER (3) NULL,
	covid_flag NUMBER (1),
	cust_med_1 VARCHAR2 (255 CHAR),
	cust_med_10 VARCHAR2 (255 CHAR),
	cust_med_11 VARCHAR2 (255 CHAR),
	cust_med_12 VARCHAR2 (255 CHAR),
	cust_med_13 VARCHAR2 (255 CHAR),
	cust_med_14 VARCHAR2 (255 CHAR),
	cust_med_15 VARCHAR2 (255 CHAR),
	cust_med_16 NUMBER (38, 10),
	cust_med_17 NUMBER (38, 10),
	cust_med_18 NUMBER (38, 10),
	cust_med_19 NUMBER (38, 10),
	cust_med_2 VARCHAR2 (255 CHAR),
	cust_med_20 NUMBER (38, 10),
	cust_med_3 VARCHAR2 (255 CHAR),
	cust_med_4 VARCHAR2 (255 CHAR),
	cust_med_5 VARCHAR2 (255 CHAR),
	cust_med_6 VARCHAR2 (255 CHAR),
	cust_med_7 VARCHAR2 (255 CHAR),
	cust_med_8 VARCHAR2 (255 CHAR),
	cust_med_9 VARCHAR2 (255 CHAR),
	cust_med_pk_id VARCHAR2 (32 CHAR),
	cvx_code VARCHAR2 (3 CHAR),
	dcc CHAR(5) NULL,
	denied_ind_id VARCHAR2 (40 CHAR),
	diag1 VARCHAR2(8 CHAR) NULL,
	diag10 VARCHAR2(8 CHAR) NULL,
	diag11 VARCHAR2 (8 CHAR),
	diag12 VARCHAR2 (8 CHAR),
	diag13 VARCHAR2 (8 CHAR),
	diag14 VARCHAR2 (8 CHAR),
	diag15 VARCHAR2 (8 CHAR),
	diag16 VARCHAR2 (8 CHAR),
	diag17 VARCHAR2 (8 CHAR),
	diag18 VARCHAR2 (8 CHAR),
	diag19 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2(8 CHAR) NULL,
	diag20 VARCHAR2 (8 CHAR),
	diag21 VARCHAR2 (8 CHAR),
	diag22 VARCHAR2 (8 CHAR),
	diag23 VARCHAR2 (8 CHAR),
	diag24 VARCHAR2 (8 CHAR),
	diag25 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2(8 CHAR) NULL,
	diag4 VARCHAR2(8 CHAR) NULL,
	diag5 VARCHAR2(8 CHAR) NULL,
	diag6 VARCHAR2(8 CHAR) NULL,
	diag7 VARCHAR2(8 CHAR) NULL,
	diag8 VARCHAR2(8 CHAR) NULL,
	diag9 VARCHAR2(8 CHAR) NULL,
	dis_stat VARCHAR2(3 CHAR) NULL,
	disrel NUMBER (9) NULL,
	dos DATE  NULL,
	drg_id VARCHAR2(12 CHAR) NULL,
	drg_outlier NUMBER (3) NULL,
	ed_enc_id NUMBER (10, 0),
	em_svc_flag NUMBER (1) NULL,
	enc_k NUMBER (19, 2),
	encounter NUMBER (19, 2) NULL,
	episode_id NUMBER (19, 0),
	er_conf NUMBER (1) NULL,
	er_flag NUMBER (1) NULL,
	er_util NUMBER (19, 2) NULL,
	er_util_k NUMBER (19, 2),
	etg VARCHAR2(9 CHAR) NULL,
	etg_id NUMBER (9) NULL,
	etg_sub_id VARCHAR2 (7 CHAR),
	from_dt DATE  NULL,
	ia_time NUMBER (30) NULL,
	icd_version NUMBER (3) NULL,
	inp_admit_type VARCHAR2 (2 CHAR),
	iproc1 VARCHAR2(7 CHAR) NULL,
	iproc10 VARCHAR2 (7 CHAR),
	iproc11 VARCHAR2 (7 CHAR),
	iproc12 VARCHAR2 (7 CHAR),
	iproc13 VARCHAR2 (7 CHAR),
	iproc14 VARCHAR2 (7 CHAR),
	iproc15 VARCHAR2 (7 CHAR),
	iproc16 VARCHAR2 (7 CHAR),
	iproc17 VARCHAR2 (7 CHAR),
	iproc18 VARCHAR2 (7 CHAR),
	iproc19 VARCHAR2 (7 CHAR),
	iproc2 VARCHAR2(7 CHAR) NULL,
	iproc20 VARCHAR2 (7 CHAR),
	iproc21 VARCHAR2 (7 CHAR),
	iproc22 VARCHAR2 (7 CHAR),
	iproc23 VARCHAR2 (7 CHAR),
	iproc24 VARCHAR2 (7 CHAR),
	iproc25 VARCHAR2 (7 CHAR),
	iproc3 VARCHAR2(7 CHAR) NULL,
	iproc4 VARCHAR2(7 CHAR) NULL,
	iproc5 VARCHAR2(7 CHAR) NULL,
	iproc6 VARCHAR2(7 CHAR) NULL,
	iproc7 VARCHAR2 (7 CHAR),
	iproc8 VARCHAR2 (7 CHAR),
	iproc9 VARCHAR2 (7 CHAR),
	lab_flag NUMBER (1) NULL,
	lab_util NUMBER (19, 2) NULL,
	lab_util_k NUMBER (19, 2),
	lag_days NUMBER (9) NULL,
	lag_ind NUMBER (1) NULL,
	line_nat VARCHAR2(10 CHAR) NULL,
	local_flag NUMBER (3) NULL,
	map_srce_e VARCHAR2 (6 CHAR),
	map_srce_n VARCHAR2(6 CHAR) NULL,
	map_srce_p VARCHAR2 (6 CHAR),
	member VARCHAR2(32 CHAR) NULL,
	mod_n VARCHAR2(4 CHAR) NULL,
	mod_n_2 VARCHAR2 (4 CHAR),
	mod_n_3 VARCHAR2 (4 CHAR),
	mod_n_4 VARCHAR2 (4 CHAR),
	mri_util NUMBER (19, 2) NULL,
	mri_util_k NUMBER (19, 2),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1) NULL,
	noenr_dos NUMBER (1) NULL,
	np_op_visit_id NUMBER (19, 0),
	obs_flag NUMBER (1),
	op_visit_id NUMBER (10, 0),
	order_prov VARCHAR2(20 CHAR) NULL,
	order_prv_i VARCHAR2(20 CHAR) NULL,
	pay_dt DATE  NULL,
	pcp_vis_flag NUMBER (1) NULL,
	pcp_vis_flag_k NUMBER (1),
	peg_episode_id NUMBER (19, 0),
	poa CHAR(1) NULL,
	poa10 VARCHAR2 (1 CHAR),
	poa2 VARCHAR2 (1 CHAR),
	poa3 VARCHAR2 (1 CHAR),
	poa4 VARCHAR2 (1 CHAR),
	poa5 VARCHAR2 (1 CHAR),
	poa6 VARCHAR2 (1 CHAR),
	poa7 VARCHAR2 (1 CHAR),
	poa8 VARCHAR2 (1 CHAR),
	poa9 VARCHAR2 (1 CHAR),
	pos_i NUMBER (3) NULL,
	pos_n VARCHAR2(3 CHAR) NULL,
	prfl_clm NUMBER (3) NULL,
	proccode VARCHAR2(15 CHAR) NULL,
	provider_id VARCHAR2(20 CHAR) NULL,
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (9) NULL,
	prv_sp_n VARCHAR2(30 CHAR) NULL,
	psc_cat1_id NUMBER (9) NULL,
	psc_cat2_id NUMBER (9) NULL,
	pseudo NUMBER (1) NULL,
	qty NUMBER (9) NULL,
	qty_k NUMBER (10, 0),
	rad_flag NUMBER (1) NULL,
	rad_util NUMBER (19, 2) NULL,
	rad_util_k NUMBER (19, 2),
	rec_type CHAR(1) NULL,
	ref_flag NUMBER (1) NULL,
	ref_flag_k NUMBER (1),
	ref_vis_flag NUMBER (1) NULL,
	ref_vis_flag_k NUMBER (1),
	refer_prov VARCHAR2 (20 CHAR),
	revenue VARCHAR2(15 CHAR) NULL,
	serv_prov_affil_id VARCHAR2 (40 CHAR),
	sev_level NUMBER (3) NULL,
	spec_drug NUMBER (10, 0),
	spec_rx_n_id VARCHAR2 (40 CHAR),
	sub_episode_num NUMBER (10, 0),
	svc_grp VARCHAR2 (30 CHAR),
	th_flag NUMBER (1),
	to_dt DATE  NULL,
	tos_i_4 NUMBER (9) NULL,
	tos_i_5 NUMBER (9) NULL,
	tos_n VARCHAR2(30 CHAR) NULL,
	unavoid_ed NUMBER (10, 0),
	uniq_rec_id NUMBER (9) NULL,
	user_spec_drug NUMBER (10, 0),
	util_spec_cat_cd NUMBER (9) NULL,
	util_spec_enc NUMBER (3) NULL,
	util_spec_enc_k NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_costs_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_costs_ext (
	admit NUMBER,
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	complete NUMBER,
	em_svc_flag NUMBER,
	encounter NUMBER,
	er_util NUMBER,
	etg_id NUMBER (12),
	etg_resp_prov VARCHAR2 (20 CHAR),
	ia_time NUMBER (3) NOT NULL,
	lab_util NUMBER,
	los NUMBER,
	mri_util NUMBER,
	network_paid_status_id VARCHAR2 (40 CHAR),
	new_mem_attr_id NUMBER NOT NULL,
	outlier NUMBER (3) NOT NULL,
	pos_i NUMBER (3) NOT NULL,
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (12) NOT NULL,
	rad_util NUMBER,
	script NUMBER,
	sev_level NUMBER (3),
	tos_i_5 NUMBER (12) NOT NULL,
	tx_ind NUMBER (3) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_count_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_count_ext (
	complete NUMBER,
	epi_qty NUMBER,
	etg_id NUMBER (12) NOT NULL,
	new_mem_attr_id NUMBER NOT NULL,
	outlier NUMBER (3) NOT NULL,
	sev_level NUMBER (3),
	tx_ind NUMBER (3) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_epi_phm_costs_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_epi_phm_costs_ext (
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	amt_req NUMBER,
	channel NUMBER (12),
	complete NUMBER,
	days_sup NUMBER,
	etg_id NUMBER (12),
	formulary NUMBER (3),
	gbo NUMBER (3) NOT NULL,
	generic NUMBER,
	ia_time NUMBER (3) NOT NULL,
	network_paid_status_id VARCHAR2 (40 CHAR),
	new_mem_attr_id NUMBER NOT NULL,
	outlier NUMBER (3) NOT NULL,
	provider_status_id VARCHAR2 (40 CHAR),
	script_gen NUMBER,
	scripts NUMBER,
	sev_level NUMBER (3),
	tos_i_5 NUMBER (12),
	tx_ind NUMBER (3) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_costs_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_costs_ext (
	admit NUMBER (12) NOT NULL,
	admit_source NUMBER (1) NOT NULL,
	amt_cap_pay NUMBER (19, 2) NOT NULL,
	amt_coin NUMBER (19, 2) NOT NULL,
	amt_cop NUMBER (19, 2) NOT NULL,
	amt_ded NUMBER (19, 2) NOT NULL,
	amt_eqv NUMBER (19, 2) NOT NULL,
	amt_liab NUMBER (19, 2) NOT NULL,
	amt_np NUMBER (19, 2) NOT NULL,
	amt_pay NUMBER (19, 2) NOT NULL,
	amt_req NUMBER (19, 2) NOT NULL,
	disrel NUMBER (12),
	drg_id VARCHAR2 (12 CHAR) NOT NULL,
	em_svc_flag NUMBER (12) NOT NULL,
	encounter NUMBER (19, 2) NOT NULL,
	er_util NUMBER (19, 2) NOT NULL,
	etg_id NUMBER (12) NULL,
	lab_util NUMBER (19, 2) NOT NULL,
	los NUMBER (12) NOT NULL,
	mri_util NUMBER (19, 2) NOT NULL,
	network_paid_status_id VARCHAR2 (40 CHAR) NOT NULL,
	new_mem_attr_id NUMBER (12) NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR) NULL,
	pcp_imp VARCHAR2 (20 CHAR) NULL,
	pos_i NUMBER (3) NULL,
	provider_id VARCHAR2 (20 CHAR) NULL,
	provider_status_id VARCHAR2 (40 CHAR) NOT NULL,
	prv_sp_4 NUMBER (12) NOT NULL,
	rad_util NUMBER (19, 2) NOT NULL,
	script NUMBER (12) NOT NULL,
	sev_level NUMBER (3) NULL,
	tos_i_5 NUMBER (12) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL,
	year_mth_pd NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_pop_phm_costs_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_pop_phm_costs_ext (
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	amt_req NUMBER,
	channel NUMBER (12),
	days_sup NUMBER,
	formulary NUMBER (3),
	gbo NUMBER (3) NOT NULL,
	generic NUMBER,
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	new_mem_attr_id NUMBER NOT NULL,
	pres_prv_i VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	script NUMBER,
	script_gen NUMBER,
	tos_i_5 NUMBER (12),
	year_mth_id NUMBER (3) NOT NULL,
	year_mth_pd NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_amb_site', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_amb_site (
	amb_site_cd VARCHAR2 (400 CHAR) NOT NULL,
	amb_site_desc VARCHAR2 (400 CHAR),
	amb_site_id NUMBER NOT NULL,
	amb_site_zip VARCHAR2 (20 CHAR),
	client_id VARCHAR2 (16 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_apr_drg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_apr_drg (
	apr_drg_cd VARCHAR2 (4 CHAR) NOT NULL,
	apr_drg_description VARCHAR2 (249 CHAR) NOT NULL,
	apr_drg_id NUMBER (6) NOT NULL,
	apr_drg_risk NUMBER (1) NOT NULL,
	apr_drg_sev NUMBER (1) NOT NULL,
	sensitive_cat_id NUMBER NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_cds_flg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_cds_flg (
	client_ds_id NUMBER NOT NULL,
	client_ds_name VARCHAR2 (100 CHAR),
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	data_grp_flg NUMBER NOT NULL,
	data_grp_name VARCHAR2 (200 CHAR) NOT NULL,
	source_type_flg NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_drg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_drg (
	drg_alos NUMBER NOT NULL,
	drg_cd VARCHAR2 (4 CHAR) NOT NULL,
	drg_description VARCHAR2 (249 CHAR) NOT NULL,
	drg_gelos NUMBER NOT NULL,
	drg_id NUMBER (6) NOT NULL,
	drg_type_cui VARCHAR2 (8 CHAR) NOT NULL,
	drg_weight NUMBER NOT NULL,
	sensitive_cat_id NUMBER NULL,
	sensitive_ind NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_clinical_event_enc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_clinical_event_enc (
	client_ds_id NUMBER (10, 0),
	client_id VARCHAR2 (16 CHAR),
	clinical_event_id NUMBER (19, 0),
	encounterid VARCHAR2 (255 CHAR),
	id_type VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_hosp_site', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_hosp_site (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	hosp_site_cd VARCHAR2 (400 CHAR) NOT NULL,
	hosp_site_desc VARCHAR2 (400 CHAR),
	hosp_site_id NUMBER NOT NULL,
	hosp_site_zip VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_upload_rules', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_upload_rules (
	client_ds_id NUMBER NOT NULL,
	client_id VARCHAR2 (20 CHAR) NOT NULL,
	datasource VARCHAR2 (255 CHAR),
	ds_display_name VARCHAR2 (255 CHAR),
	dts_version NUMBER,
	id_sub_type VARCHAR2 (255 CHAR),
	id_type VARCHAR2 (255 CHAR),
	is_default_datasource NUMBER (1),
	regex VARCHAR2 (255 CHAR),
	rule_type VARCHAR2 (255 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_activity_month', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_activity_month (
	activity_count NUMBER (4) NOT NULL,
	activity_type_cd VARCHAR2 (8 CHAR) NOT NULL,
	activity_yr_month NUMBER (6) NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL
	) PARTITION BY LIST(activity_type_cd) (PARTITION P_EVENT VALUES(''EVENT''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_activity_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_activity_summary (
	all_act_type_flg NUMBER NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	class_1_ind NUMBER (1) NOT NULL,
	class_2_ind NUMBER (1) NOT NULL,
	class_3_ind NUMBER (1) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL
	) PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_appointment', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_appointment (
	appointment_dtm DATE NOT NULL,
	appointment_location VARCHAR2 (100 CHAR),
	appointment_reason VARCHAR2 (249 CHAR),
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	location_key VARCHAR2 (100 CHAR),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	prov_id VARCHAR2 (20 CHAR),
	prov_id_key VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_assess_num', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_assess_num (
	assessment_cui VARCHAR2 (8 CHAR) NOT NULL,
	assessment_dtm DATE NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	clinical_evt_key NUMBER (19, 0),
	hosp_ind NUMBER (1) DEFAULT 0 NOT NULL,
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	nlp_ind NUMBER (1),
	numeric_value NUMBER NOT NULL,
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL
	) PARTITION BY LIST (assessment_cui) (PARTITION P_CH999999 values(''CH999999''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_assess_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_assess_qual (
	assessment_cui VARCHAR2 (8 CHAR) NOT NULL,
	assessment_dtm DATE NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	clinical_evt_key NUMBER (19, 0),
	hosp_ind NUMBER (1) DEFAULT 0 NOT NULL,
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	nlp_ind NUMBER (1),
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL,
	value_cui VARCHAR2 (8 CHAR) NOT NULL
	) PARTITION BY LIST (ASSESSMENT_CUI) (PARTITION P_CH999999 values(''CH999999''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_clinical_event', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_clinical_event (
	admit_prov_id VARCHAR2 (20 CHAR),
	admitsource_cui VARCHAR2 (8 CHAR),
	admitted_er_ind NUMBER (1) NOT NULL,
	amb_site_id NUMBER,
	apr_drg_id NUMBER (6),
	apr_drg_sensitive_ind NUMBER (1) NOT NULL,
	base_include_ind NUMBER (1) NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER NOT NULL,
	cms_include_ind NUMBER (1) NOT NULL,
	cms_planned_ind NUMBER (1) NOT NULL,
	convert_ip_ind NUMBER (1) NOT NULL,
	disch_prov_id VARCHAR2 (20 CHAR),
	disch_team_prov_id VARCHAR2 (20 CHAR),
	display_ds_id NUMBER NOT NULL,
	display_encounterid VARCHAR2 (255 CHAR) NOT NULL,
	disposition_cui VARCHAR2 (8 CHAR),
	drg_id NUMBER (6),
	drg_id_calc NUMBER (10, 0),
	drg_sensitive_ind NUMBER (1) NOT NULL,
	etg_qual_evt_ind NUMBER (1) NOT NULL,
	event_type_cui VARCHAR2 (8 CHAR) NOT NULL,
	evt_admit_dtm DATE,
	evt_end_dtm DATE,
	evt_start_dtm DATE NOT NULL,
	hosp_service_cui VARCHAR2 (8 CHAR),
	hosp_site_id NUMBER,
	los NUMBER (10, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	pat_zip VARCHAR2 (10 CHAR),
	prindx VARCHAR2 (10 CHAR),
	prindx_codetype VARCHAR2 (16 CHAR),
	prindx_sensitive_ind NUMBER (1) NOT NULL,
	prinpx VARCHAR2 (10 CHAR),
	prinpx_codetype VARCHAR2 (16 CHAR),
	prinpx_sensitive_ind NUMBER (1) NOT NULL,
	prov_id VARCHAR2 (20 CHAR),
	same_day_stay NUMBER (10, 0),
	sensitive_ind NUMBER (1) NOT NULL
	) PARTITION BY LIST(EVENT_TYPE_CUI) (PARTITION P_CH000000 values (''CH000000''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_clinical_event_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_clinical_event_prov (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER NOT NULL,
	prov_id VARCHAR2 (20 CHAR) NOT NULL,
	prov_role_cui VARCHAR2 (8 CHAR) NOT NULL,
	prov_role_dtm DATE NOT NULL
	) PARTITION BY LIST (prov_role_cui) (PARTITION p_CH999999 VALUES (''CH999999''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_diag', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_diag (
	admit_ind NUMBER (1) NOT NULL,
	bill_claim_ind NUMBER (1) NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	clinical_evt_key NUMBER,
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	diag_cd VARCHAR2 (20 CHAR) NOT NULL,
	diag_dt DATE NOT NULL,
	discharge_ind NUMBER (1) NOT NULL,
	hosp_dx_ind NUMBER (1) NOT NULL,
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	poa_cui VARCHAR2 (8 CHAR) NOT NULL,
	primary_hosp_dx_ind NUMBER (1) NOT NULL,
	primary_ind NUMBER (1) NOT NULL,
	problemlist_ind NUMBER (1) NOT NULL,
	resolution_dt DATE,
	sensitive_ind NUMBER (1) NOT NULL,
	status_cui VARCHAR2 (8 CHAR) NOT NULL,
	parititon_key VARCHAR2(100 CHAR) GENERATED ALWAYS AS (substr(code_type,1,20) || ''_'' ||  substr(diag_cd,1,1)) VIRTUAL
	) PARTITION BY LIST(parititon_key) (PARTITION P_ICD10_U VALUES (''ICD10_U''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_hm_deferred', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_hm_deferred (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	dcc VARCHAR2 (5 CHAR),
	defer_rsn_cui VARCHAR2 (8 CHAR),
	deferral_dtm DATE NOT NULL,
	hm_deferred_key VARCHAR2 (21 CHAR),
	hm_type_cui VARCHAR2 (8 CHAR),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL
	) PARTITION BY HASH (mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_id', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_id (
	client_ds_id NUMBER NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	id_subtype VARCHAR2 (50 CHAR),
	id_subtype_ind NUMBER (1),
	id_type VARCHAR2 (20 CHAR) NOT NULL,
	id_value VARCHAR2 (50 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL
	) PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_insurance', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_insurance (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	insurance_order NUMBER (1) DEFAULT 0 NOT NULL,
	last_ind NUMBER (1) NOT NULL,
	lob_cui VARCHAR2 (8 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	no_enc_ind NUMBER (1) NOT NULL,
	payer_cui VARCHAR2 (8 CHAR) NOT NULL,
	plancode VARCHAR2 (255 CHAR),
	planname VARCHAR2 (255 CHAR),
	primary_ind NUMBER (1),
	yr_month NUMBER (6) NOT NULL
	) PARTITION BY LIST (primary_ind) (PARTITION P_PRIMARY_0 VALUES (0) ,PARTITION P_PRIMARY_1 VALUES (1))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_med', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_med (
	active_ind NUMBER (1),
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	dcc VARCHAR2 (5 CHAR) NOT NULL,
	fill_ind NUMBER (1) DEFAULT 0 NOT NULL,
	gbo_id NUMBER (1),
	hosp_ind NUMBER (1) DEFAULT 0 NOT NULL,
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	ndc VARCHAR2 (11 CHAR) NOT NULL,
	pat_reported_ind NUMBER (1),
	prov_id VARCHAR2 (20 CHAR),
	route_cui VARCHAR2 (8 CHAR) NOT NULL,
	rx_dtm DATE NOT NULL,
	rxadmin_ind NUMBER (1),
	rxorder_ind NUMBER (1),
	sensitive_ind NUMBER (1) NOT NULL,
	tos_i_5 NUMBER (12),
	partition_key VARCHAR2(1 CHAR) GENERATED ALWAYS AS (SUBSTRB(dcc,1,1)) VIRTUAL
	) PARTITION BY LIST (partition_key) (PARTITION p_dcc_0 values (''0'') ,PARTITION p_dcc_1 values (''1'') ,PARTITION p_dcc_2 values (''2'') ,PARTITION p_dcc_3 values (''3'') ,PARTITION p_dcc_4 values (''4'') ,PARTITION p_dcc_5 values (''5'') ,PARTITION p_dcc_6 values (''6'') ,PARTITION p_dcc_7 values (''7'') ,PARTITION p_dcc_8 values (''8'') ,PARTITION p_dcc_9 values (''9''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_microbio', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_microbio (
	antibiotic_loinc VARCHAR2 (50 CHAR),
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	clinical_evt_key NUMBER,
	culture_growth_cui VARCHAR2 (8 CHAR),
	culture_unit_cui VARCHAR2 (8 CHAR),
	culture_value_cui VARCHAR2 (8 CHAR),
	has_dt NUMBER (1),
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	order_dtm DATE,
	org_exclude_cui VARCHAR2 (8 CHAR),
	organism_cui VARCHAR2 (8 CHAR),
	result_dtm DATE,
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL,
	sensitivity_cui VARCHAR2 (8 CHAR),
	specimen_source_cui VARCHAR2 (8 CHAR)
	) PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_mrace_infer', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_mrace_infer (
	cds_grp VARCHAR2 (4000 CHAR),
	client_id VARCHAR2 (16 CHAR),
	mapped_race VARCHAR2 (16 CHAR),
	mpi VARCHAR2 (32 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_proc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_proc (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	hosp_px_ind NUMBER (1),
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	modifier_1 VARCHAR2 (2 CHAR),
	modifier_1_excld NUMBER (1) NOT NULL,
	modifier_2 VARCHAR2 (2 CHAR),
	modifier_2_excld NUMBER (1) NOT NULL,
	modifier_3 VARCHAR2 (2 CHAR),
	modifier_3_excld NUMBER (1) NOT NULL,
	modifier_4 VARCHAR2 (2 CHAR),
	modifier_4_excld NUMBER (1) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	place_of_svc VARCHAR2 (10 CHAR) NOT NULL,
	place_of_svc_sensitive_ind NUMBER NOT NULL,
	principal_ind NUMBER (1),
	proc_cd VARCHAR2 (20 CHAR) NOT NULL,
	proc_dtm DATE NOT NULL,
	prov_id VARCHAR2 (20 CHAR) DEFAULT ''0'' NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL,
	tos_i_5 NUMBER (12)
	) PARTITION BY LIST(code_type) (PARTITION P_NULL VALUES (NULL))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_patient_attr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_patient_attr (
	attr_cui VARCHAR2 (8 CHAR) NOT NULL,
	attr_end_dt DATE,
	attr_start_dt DATE,
	attr_value VARCHAR2 (255 CHAR) NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	last_ind NUMBER NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_patient_info', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_patient_info (
	addr_line_1 VARCHAR2 (100 CHAR),
	addr_line_2 VARCHAR2 (100 CHAR),
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	city VARCHAR2 (50 CHAR),
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	death_ind_cui VARCHAR2 (8 CHAR),
	dob DATE,
	dod DATE,
	email VARCHAR2 (100 CHAR),
	ethnicity_cui VARCHAR2 (8 CHAR),
	first_name VARCHAR2 (30 CHAR),
	gender_cui VARCHAR2 (8 CHAR),
	home_phone VARCHAR2 (30 CHAR),
	language_cui VARCHAR2 (8 CHAR),
	last_name VARCHAR2 (50 CHAR),
	marital_status_cui VARCHAR2 (8 CHAR),
	middle_name VARCHAR2 (30 CHAR),
	mobile_phone VARCHAR2 (30 CHAR),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	mrace_infer_ind NUMBER (10, 0),
	mrn VARCHAR2 (20 CHAR),
	postal_cd VARCHAR2 (5 CHAR),
	race_cui VARCHAR2 (8 CHAR),
	religion VARCHAR2 (100 CHAR),
	ssn VARCHAR2 (9 CHAR),
	state VARCHAR2 (2 CHAR),
	work_phone VARCHAR2 (30 CHAR)
	) PARTITION BY RANGE(dob) (PARTITION P_pre1940 VALUES LESS THAN (to_date(''19400101'',''YYYYMMDD'')) ,PARTITION P_1940s VALUES LESS THAN (to_date(''19500101'',''YYYYMMDD'')) ,PARTITION P_1950s VALUES LESS THAN (to_date(''19600101'',''YYYYMMDD'')) ,PARTITION P_1960s VALUES LESS THAN (to_date(''19700101'',''YYYYMMDD'')) ,PARTITION P_1970s VALUES LESS THAN (to_date(''19800101'',''YYYYMMDD'')) ,PARTITION P_1980s VALUES LESS THAN (to_date(''19900101'',''YYYYMMDD'')) ,PARTITION P_1990s VALUES LESS THAN (to_date(''20000101'',''YYYYMMDD'')) ,PARTITION P_pre2020 VALUES LESS THAN (to_date(''20200101'',''YYYYMMDD'')) ,PARTITION P_MAX VALUES LESS THAN (MAXVALUE) )
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_provider_attr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_provider_attr (
	attr_cui VARCHAR2 (8 CHAR) NOT NULL,
	attr_end_dt DATE,
	attr_start_dt DATE,
	attr_value VARCHAR2 (255 CHAR) NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	prov_id VARCHAR2 (20 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_provider_info', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_provider_info (
	address VARCHAR2 (100 CHAR),
	amb_site_id NUMBER DEFAULT 0 NOT NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	city VARCHAR2 (100 CHAR),
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	cust_prv_1 VARCHAR2 (255 CHAR),
	cust_prv_10 VARCHAR2 (255 CHAR),
	cust_prv_11 VARCHAR2 (255 CHAR),
	cust_prv_12 VARCHAR2 (255 CHAR),
	cust_prv_13 VARCHAR2 (255 CHAR),
	cust_prv_14 VARCHAR2 (255 CHAR),
	cust_prv_15 VARCHAR2 (255 CHAR),
	cust_prv_16 NUMBER (38, 10),
	cust_prv_17 NUMBER (38, 10),
	cust_prv_18 NUMBER (38, 10),
	cust_prv_19 NUMBER (38, 10),
	cust_prv_2 VARCHAR2 (255 CHAR),
	cust_prv_20 NUMBER (38, 10),
	cust_prv_3 VARCHAR2 (255 CHAR),
	cust_prv_4 VARCHAR2 (255 CHAR),
	cust_prv_5 VARCHAR2 (255 CHAR),
	cust_prv_6 VARCHAR2 (255 CHAR),
	cust_prv_7 VARCHAR2 (255 CHAR),
	cust_prv_8 VARCHAR2 (255 CHAR),
	cust_prv_9 VARCHAR2 (255 CHAR),
	facility_ind NUMBER (1) DEFAULT 0 NOT NULL,
	npi VARCHAR2 (10 CHAR),
	pcp_ind NUMBER (1) DEFAULT 0 NOT NULL,
	prov_affil_id VARCHAR2 (40 CHAR),
	prov_id VARCHAR2 (20 CHAR) NOT NULL,
	prov_userdef_1 VARCHAR2 (100 CHAR),
	prov_userdef_2_id VARCHAR2 (40 CHAR),
	provider_name VARCHAR2 (255 CHAR),
	sec_provider_id VARCHAR2 (20 CHAR),
	sec_provider_id_2 VARCHAR2 (20 CHAR),
	specialty_id NUMBER (12),
	state VARCHAR2 (2 CHAR),
	zipcode VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_system_contract_dates', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_system_contract_dates (
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	max_pd_dt_inp DATE,
	max_pd_dt_med DATE,
	max_pd_dt_rx DATE,
	max_svc_dt_inp DATE,
	max_svc_dt_med DATE,
	max_svc_dt_rx DATE,
	min_pd_dt_inp DATE,
	min_pd_dt_med DATE,
	min_pd_dt_rx DATE,
	min_svc_dt_inp DATE,
	min_svc_dt_med DATE,
	min_svc_dt_rx DATE
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_system_dates', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_system_dates (
	client_ds_id NUMBER (10) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_cnt NUMBER (10) NOT NULL,
	clinical_event_max_dt DATE NOT NULL,
	clinical_event_min_dt DATE NOT NULL,
	clinical_event_perc_25_dt DATE NOT NULL,
	clinical_event_perc_50_dt DATE NOT NULL,
	clinical_event_perc_75_dt DATE NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_readmission', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_readmission (
	readmission_domain VARCHAR2 (8 CHAR) NOT NULL,
	readmission_type_cui VARCHAR2 (8 CHAR) NOT NULL,
	readmission_type_desc VARCHAR2 (100 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_condition_rule_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_condition_rule_grp (
	condition_id NUMBER (10) NOT NULL,
	condition_rule_grp_desc VARCHAR2 (4000 CHAR) NOT NULL,
	rule_grp VARCHAR2 (4000 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_condition_precursor', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_condition_precursor (
	cond_precursor_desc VARCHAR2 (100 CHAR) NOT NULL,
	condition_id NUMBER NOT NULL,
	precursor_cnt NUMBER (3) DEFAULT 1 NOT NULL,
	precursor_cnt_max_days NUMBER (4),
	precursor_cnt_min_days NUMBER (4) DEFAULT 0 NOT NULL,
	precursor_flg NUMBER NOT NULL,
	precursor_id NUMBER NOT NULL,
	sensitive_cat_id NUMBER (10) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_condition_rule_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_condition_rule_grp (
	condition_id NUMBER(10) NOT NULL,
	rule_grp VARCHAR2 (4000 CHAR) NOT NULL,
	rule_id NUMBER (10) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_assess_cui', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_assess_cui (
	assess_cui VARCHAR2 (8 CHAR) NOT NULL,
	exclude_hosp_ind NUMBER (1) DEFAULT 1 NOT NULL,
	lower_bound NUMBER,
	precursor_id NUMBER NOT NULL,
	qualitative_val VARCHAR2 (200 CHAR) NULL,
	upper_bound NUMBER,
	value_filter_id NUMBER (2) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_dcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_dcc (
	dcc VARCHAR2 (8 CHAR) NOT NULL,
	exclude_hosp_ind NUMBER (1) NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_grp (
	precursor_flg NUMBER NOT NULL,
	precursor_grp_id NUMBER NOT NULL,
	precursor_grp_precursor_desc VARCHAR2 (100 CHAR) NOT NULL,
	precursor_id NUMBER NOT NULL,
	sensitive_cat_id NUMBER(1) NOT NULL,
	sensitive_ind NUMBER(1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_evt_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_evt_detail (
	apr_drg_id NUMBER (6) NULL,
	drg_id NUMBER (6),
	precursor_id NUMBER NOT NULL,
	prindx_precursor_id NUMBER NULL,
	prinpx_precursor_id NUMBER NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_readmission', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_readmission (
	event_type_cui VARCHAR2 (8 CHAR),
	map_key VARCHAR2 (8 CHAR),
	readmission_domain VARCHAR2 (8 CHAR) NOT NULL,
	readmission_type_cui VARCHAR2 (8 CHAR) NOT NULL,
	tos_i_5 NUMBER NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_precur (
	coef_mult_is_1_ind NUMBER (1) DEFAULT 1 NOT NULL,
	grp_id NUMBER (5) NOT NULL,
	grp_precursor_desc VARCHAR2 (100 CHAR) NOT NULL,
	precursor_id NUMBER NOT NULL,
	req_in_all_timeframe_ind NUMBER (1) DEFAULT 0 NOT NULL,
	sensitive_cat_id NUMBER (10) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_population_req', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_population_req (
	bucket_id NUMBER NOT NULL,
	excl_precursor_id NUMBER NULL,
	req_gender VARCHAR2 (8 CHAR),
	req_in_all_timeframe_ind NUMBER (1) NULL,
	req_key VARCHAR2 (300 CHAR) NOT NULL,
	req_max_age NUMBER (3) NULL,
	req_min_age NUMBER (3) NULL,
	req_precursor_id NUMBER NULL,
	req_race VARCHAR2 (8 CHAR),
	score_population_id NUMBER (3) NOT NULL,
	score_req_type_id NUMBER (2) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_ocu_epi_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_ocu_epi_costs (
	admits NUMBER,
	age_cat2 NUMBER (3) NOT NULL,
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	complete NUMBER,
	contract_id VARCHAR2 (40 CHAR),
	em_svc_util NUMBER,
	enc NUMBER,
	er_util NUMBER,
	etg_id NUMBER (12),
	etg_resp_prov VARCHAR2 (20 CHAR),
	ia_time NUMBER (3) NOT NULL,
	lab_util NUMBER,
	los NUMBER,
	mri_util NUMBER,
	network_paid_status_id VARCHAR2 (40 CHAR),
	new_mem_attr_id NUMBER NOT NULL,
	outlier NUMBER (3) NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	pos_i NUMBER (3) NOT NULL,
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (12) NOT NULL,
	rad_util NUMBER,
	scripts NUMBER,
	sev_level NUMBER (3),
	sex NUMBER (1) NOT NULL,
	tos_i_5 NUMBER (12) NOT NULL,
	tx_ind NUMBER (3) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_ocu_epi_count', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_ocu_epi_count (
	complete NUMBER,
	epi_qty NUMBER,
	etg_id NUMBER (12) NOT NULL,
	ia_time NUMBER (3) NOT NULL,
	new_mem_attr_id NUMBER (12) NOT NULL,
	outlier NUMBER (3) NOT NULL,
	sev_level NUMBER (3),
	tx_ind NUMBER (3) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_ocu_epi_phm_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_ocu_epi_phm_costs (
	age_cat2 NUMBER (3) NOT NULL,
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	amt_req NUMBER,
	channel NUMBER (12),
	complete NUMBER,
	days_sup NUMBER,
	etg_id NUMBER (12),
	formulary NUMBER (3),
	gbo NUMBER (3) NOT NULL,
	generic NUMBER,
	ia_time NUMBER (3) NOT NULL,
	network_paid_status_id VARCHAR2 (40 CHAR),
	outlier NUMBER (3) NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	provider_status_id VARCHAR2 (40 CHAR),
	script_gen NUMBER,
	scripts NUMBER,
	sev_level NUMBER (3),
	sex NUMBER (1) NOT NULL,
	tos_i_5 NUMBER (12),
	tx_ind NUMBER (3) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_condition_precursor', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_condition_precursor (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	condition_id NUMBER NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	precursor_domain VARCHAR2 (16 CHAR),
	precursor_dt DATE NOT NULL,
	precursor_id NUMBER NOT NULL,
	precursor_modifier_flg NUMBER DEFAULT 0 NOT NULL,
	precursor_type VARCHAR2 (20 CHAR),
	precursor_value VARCHAR2 (50 CHAR),
	rule_grp VARCHAR2 (4000 CHAR),
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL,
	yr_month NUMBER (6)
	) PARTITION BY RANGE(condition_id) INTERVAL(1) (PARTITION P_CND_0 VALUES LESS THAN (0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_precursor', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_precursor (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	precursor_domain VARCHAR2 (16 CHAR),
	precursor_dtm DATE NOT NULL,
	precursor_end_dtm DATE,
	precursor_id NUMBER NOT NULL,
	precursor_modifier_flg NUMBER DEFAULT 0 NOT NULL,
	precursor_type VARCHAR2 (20 CHAR),
	precursor_value VARCHAR2 (50 CHAR),
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL
	) PARTITION BY Range(precursor_id) interval(1) (PARTITION P_PCR_0 VALUES less than(0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_score_grp_intn', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_score_grp_intn (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	coef_multiplier NUMBER (9, 4) NOT NULL,
	elig_cds_id NUMBER NOT NULL,
	grp_id NUMBER (5) NOT NULL,
	interaction_id NUMBER (4) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL,
	timeframe_id NUMBER NOT NULL
	) PARTITION BY Range(grp_id) interval(1) (PARTITION P_GRP_0 VALUES less than(0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_intn', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_intn (
	age_interaction_ind NUMBER (1) NOT NULL,
	age_range_max NUMBER (3),
	age_range_min NUMBER (3) NULL,
	cnt_grp_id NUMBER (4),
	cnt_interaction_ind NUMBER (1) NOT NULL,
	cnt_range_max NUMBER (5),
	cnt_range_min NUMBER (5),
	grp_id NUMBER (5) NOT NULL,
	grp_interaction_desc VARCHAR2 (200 CHAR) NOT NULL,
	grp_interaction_name VARCHAR2 (50 CHAR) NOT NULL,
	interaction_id NUMBER (4) NOT NULL,
	sensitive_cat_id NUMBER (3) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_score_grp_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_score_grp_precur (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	elig_cds_id NUMBER NOT NULL,
	grp_id NUMBER (5) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_cds_grp VARCHAR2 (4000 CHAR),
	precursor_domain VARCHAR2 (16 CHAR),
	precursor_id NUMBER NOT NULL,
	precursor_max_dt DATE,
	precursor_min_dt DATE,
	precursor_type VARCHAR2 (20 CHAR),
	precursor_value VARCHAR2 (50 CHAR),
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL,
	timeframe_id NUMBER NOT NULL
	) PARTITION BY RANGE(grp_id) INTERVAL(1) (PARTITION P_GRP_0 VALUES less than(0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_timeframe_age', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_timeframe_age (
	born_during_ind NUMBER (1) DEFAULT 0 NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	died_during_ind NUMBER (1) DEFAULT 0 NOT NULL,
	end_age NUMBER (3) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	start_age NUMBER (3) NOT NULL,
	timeframe_id NUMBER NOT NULL
	) PARTITION BY LIST (timeframe_id) (PARTITION P_time_0 values (0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_timeframe_ins', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_timeframe_ins (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	lob_cui VARCHAR2 (8 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	payer_cui VARCHAR2 (8 CHAR) NOT NULL,
	timeframe_id NUMBER NOT NULL
	) PARTITION BY RANGE (timeframe_id) INTERVAL(1) (PARTITION time_0 VALUES LESS THAN (0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_day', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_day (
	day_dt DATE NOT NULL,
	month_id INTEGER NOT NULL,
	prev_day_dt DATE NOT NULL,
	prev_month_day_dt DATE NOT NULL,
	prev_quarter_day_dt DATE NOT NULL,
	prev_year_day_dt DATE NOT NULL,
	quarter_id INTEGER NOT NULL,
	weekday_name VARCHAR2 (20 CHAR) NOT NULL,
	weekday_short_name VARCHAR2 (10 CHAR) NOT NULL,
	year_id INTEGER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_elig_cds', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_elig_cds (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	elig_cds_desc VARCHAR2 (200 CHAR) NOT NULL,
	elig_cds_grp VARCHAR2(4000 CHAR) NOT NULL,
	elig_cds_id NUMBER NOT NULL,
	elig_source_type_flg NUMBER NOT NULL,
	for_each_cds_ind NUMBER (1) NOT NULL,
	require_billing_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_measure', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_measure (
	active_ind NUMBER (1) NOT NULL,
	invert_ind NUMBER (1) NOT NULL,
	measure_cat2_id NUMBER (3) NOT NULL,
	measure_cd VARCHAR2 (20 CHAR) NOT NULL,
	measure_desc VARCHAR2 (400 CHAR) NULL,
	measure_id NUMBER NOT NULL,
	measure_set VARCHAR2 (20 CHAR) NOT NULL,
	measure_steward VARCHAR2 (100 CHAR) NULL,
	measure_type VARCHAR2 (2 CHAR) NOT NULL,
	measure_vers VARCHAR2 (20 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (3) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL,
	trend_ind NUMBER (1) NOT NULL,
	typical_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_member_cost', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_member_cost (
	amt_cob_anc NUMBER (38, 10),
	amt_cob_ip NUMBER (38, 10),
	amt_cob_op NUMBER (38, 10),
	amt_cob_prf NUMBER (38, 10),
	amt_cob_rx NUMBER (38, 10),
	amt_cob_tot NUMBER (38, 10),
	amt_eqv_anc NUMBER (19, 2) NULL,
	amt_eqv_ip NUMBER (19, 2) NULL,
	amt_eqv_op NUMBER (19, 2) NULL,
	amt_eqv_prf NUMBER (19, 2) NULL,
	amt_eqv_rx NUMBER (19, 2) NULL,
	amt_eqv_tot NUMBER (19, 2) NULL,
	amt_liab_anc NUMBER (38, 10),
	amt_liab_ip NUMBER (38, 10),
	amt_liab_op NUMBER (38, 10),
	amt_liab_prf NUMBER (38, 10),
	amt_liab_rx NUMBER (38, 10),
	amt_liab_tot NUMBER (38, 10),
	amt_np_anc NUMBER (19, 2) NULL,
	amt_np_ip NUMBER (19, 2) NULL,
	amt_np_op NUMBER (19, 2) NULL,
	amt_np_prf NUMBER (19, 2) NULL,
	amt_np_rx NUMBER (19, 2) NULL,
	amt_np_tot NUMBER (19, 2) NULL,
	amt_pay_anc NUMBER (19, 2) NULL,
	amt_pay_ip NUMBER (19, 2) NULL,
	amt_pay_op NUMBER (19, 2) NULL,
	amt_pay_prf NUMBER (19, 2) NULL,
	amt_pay_rx NUMBER (19, 2) NULL,
	amt_pay_tot NUMBER (19, 2) NULL,
	amt_req_anc NUMBER (38, 10),
	amt_req_ip NUMBER (38, 10),
	amt_req_op NUMBER (38, 10),
	amt_req_prf NUMBER (38, 10),
	amt_req_rx NUMBER (38, 10),
	amt_req_tot NUMBER (38, 10),
	client_id VARCHAR2 (16 CHAR),
	enc_anc NUMBER (19, 2),
	enc_ed_anc NUMBER (19, 2),
	enc_ed_ip NUMBER (19, 2),
	enc_ed_op NUMBER (19, 2),
	enc_ed_prf NUMBER (19, 2),
	enc_ed_rx NUMBER (19, 2),
	enc_ed_tot NUMBER (19, 2),
	enc_ip NUMBER (19, 2),
	enc_op NUMBER (19, 2),
	enc_prf NUMBER (19, 2),
	enc_rx NUMBER (19, 2),
	enc_tot NUMBER (19, 2),
	member VARCHAR2 (32 CHAR) NOT NULL,
	new_mem_attr_id NUMBER NOT NULL,
	year_mth_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_member_cost_contract', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_member_cost_contract (
	amt_cob_anc NUMBER (38, 10),
	amt_cob_anc_k NUMBER (38, 10),
	amt_cob_ip NUMBER (38, 10),
	amt_cob_ip_k NUMBER (38, 10),
	amt_cob_op NUMBER (38, 10),
	amt_cob_op_k NUMBER (38, 10),
	amt_cob_prf NUMBER (38, 10),
	amt_cob_prf_k NUMBER (38, 10),
	amt_cob_rx NUMBER (38, 10),
	amt_cob_rx_k NUMBER (38, 10),
	amt_cob_tot NUMBER (38, 10),
	amt_cob_tot_k NUMBER (38, 10),
	amt_eqv_anc NUMBER (38, 10),
	amt_eqv_anc_k NUMBER (38, 10),
	amt_eqv_ip NUMBER (38, 10),
	amt_eqv_ip_k NUMBER (38, 10),
	amt_eqv_op NUMBER (38, 10),
	amt_eqv_op_k NUMBER (38, 10),
	amt_eqv_prf NUMBER (38, 10),
	amt_eqv_prf_k NUMBER (38, 10),
	amt_eqv_rx NUMBER (38, 10),
	amt_eqv_rx_k NUMBER (38, 10),
	amt_eqv_tot NUMBER (38, 10),
	amt_eqv_tot_k NUMBER (38, 10),
	amt_liab_anc NUMBER (38, 10),
	amt_liab_anc_k NUMBER (38, 10),
	amt_liab_ip NUMBER (38, 10),
	amt_liab_ip_k NUMBER (38, 10),
	amt_liab_op NUMBER (38, 10),
	amt_liab_op_k NUMBER (38, 10),
	amt_liab_prf NUMBER (38, 10),
	amt_liab_prf_k NUMBER (38, 10),
	amt_liab_rx NUMBER (38, 10),
	amt_liab_rx_k NUMBER (38, 10),
	amt_liab_tot NUMBER (38, 10),
	amt_liab_tot_k NUMBER (38, 10),
	amt_np_anc NUMBER (38, 10),
	amt_np_anc_k NUMBER (38, 10),
	amt_np_ip NUMBER (38, 10),
	amt_np_ip_k NUMBER (38, 10),
	amt_np_op NUMBER (38, 10),
	amt_np_op_k NUMBER (38, 10),
	amt_np_prf NUMBER (38, 10),
	amt_np_prf_k NUMBER (38, 10),
	amt_np_rx NUMBER (38, 10),
	amt_np_rx_k NUMBER (38, 10),
	amt_np_tot NUMBER (38, 10),
	amt_np_tot_k NUMBER (38, 10),
	amt_pay_anc NUMBER (38, 10),
	amt_pay_anc_k NUMBER (38, 10),
	amt_pay_ip NUMBER (38, 10),
	amt_pay_ip_k NUMBER (38, 10),
	amt_pay_op NUMBER (38, 10),
	amt_pay_op_k NUMBER (38, 10),
	amt_pay_prf NUMBER (38, 10),
	amt_pay_prf_k NUMBER (38, 10),
	amt_pay_rx NUMBER (38, 10),
	amt_pay_rx_k NUMBER (38, 10),
	amt_pay_tot NUMBER (38, 10),
	amt_pay_tot_k NUMBER (38, 10),
	amt_req_anc NUMBER (38, 10),
	amt_req_anc_k NUMBER (38, 10),
	amt_req_ip NUMBER (38, 10),
	amt_req_ip_k NUMBER (38, 10),
	amt_req_op NUMBER (38, 10),
	amt_req_op_k NUMBER (38, 10),
	amt_req_prf NUMBER (38, 10),
	amt_req_prf_k NUMBER (38, 10),
	amt_req_rx NUMBER (38, 10),
	amt_req_rx_k NUMBER (38, 10),
	amt_req_tot NUMBER (38, 10),
	amt_req_tot_k NUMBER (38, 10),
	client_id VARCHAR2 (16 CHAR),
	enc_anc NUMBER (19, 2),
	enc_anc_k NUMBER (19, 2),
	enc_ed_anc NUMBER (19, 2),
	enc_ed_anc_k NUMBER (19, 2),
	enc_ed_ip NUMBER (19, 2),
	enc_ed_ip_k NUMBER (19, 2),
	enc_ed_op NUMBER (19, 2),
	enc_ed_op_k NUMBER (19, 2),
	enc_ed_prf NUMBER (19, 2),
	enc_ed_prf_k NUMBER (19, 2),
	enc_ed_rx NUMBER (19, 2),
	enc_ed_rx_k NUMBER (19, 2),
	enc_ed_tot NUMBER (19, 2),
	enc_ed_tot_k NUMBER (19, 2),
	enc_ip NUMBER (19, 2),
	enc_ip_k NUMBER (19, 2),
	enc_op NUMBER (19, 2),
	enc_op_k NUMBER (19, 2),
	enc_prf NUMBER (19, 2),
	enc_prf_k NUMBER (19, 2),
	enc_rx NUMBER (19, 2),
	enc_rx_k NUMBER (19, 2),
	enc_tot NUMBER (19, 2),
	enc_tot_k NUMBER (19, 2),
	member VARCHAR2 (32 CHAR) NOT NULL,
	new_mem_attr_con_id NUMBER NOT NULL,
	year_mth_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_month_timeframe', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_month_timeframe (
	timeframe_id NUMBER NOT NULL,
	yr_month NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_ocu_epi_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_ocu_epi_costs (
	adm_1000_epi NUMBER,
	admits NUMBER,
	age_cat2 NUMBER (3),
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	amt_pay_per_epi NUMBER,
	complete NUMBER,
	days_1000_epi NUMBER,
	em_svc_util NUMBER,
	enc NUMBER,
	enc_1000_epi NUMBER,
	epi_qty NUMBER,
	er_util NUMBER,
	etg_id NUMBER (12),
	ia_time NUMBER (3),
	lab_util NUMBER,
	los NUMBER,
	mri_util NUMBER,
	network_paid_status_id VARCHAR2 (40 CHAR),
	outlier NUMBER (3),
	pcp_assign VARCHAR2 (20 CHAR),
	pos_i NUMBER (3) NOT NULL,
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (12) NOT NULL,
	rad_util NUMBER,
	scripts NUMBER,
	scripts_1000_epi NUMBER,
	sev_level NUMBER (3),
	sex NUMBER (1),
	tos_i_5 NUMBER (12) NOT NULL,
	tx_ind NUMBER (3),
	year_mth_id NUMBER (3)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_hcc_dropped', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_hcc_dropped (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	destination_timeframe_id NUMBER NOT NULL,
	dropped_precursor_id NUMBER NOT NULL,
	elig_cds_id NUMBER NOT NULL,
	latest_type VARCHAR2 (20 CHAR) NOT NULL,
	latest_value VARCHAR2 (50 CHAR) NOT NULL,
	max_dt DATE NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	score_id NUMBER (5) NOT NULL,
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL,
	source_timeframe_id NUMBER NOT NULL
	) PARTITION BY RANGE(dropped_precursor_id) INTERVAL(1) (PARTITION P_DRPPRC_0 VALUES less than(0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_hcc_opportunity', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_hcc_opportunity (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	elig_cds_id NUMBER NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	py_coef_sum NUMBER (6, 4) NOT NULL,
	py_fully_coded_yrmonth NUMBER (6) NOT NULL,
	pytd_coded_id NUMBER (2) NOT NULL,
	pytd_coef_sum NUMBER (6, 4) NOT NULL,
	score_id NUMBER (5) NOT NULL,
	ty_fully_coded_yrmonth NUMBER (6),
	tytd_coded_id NUMBER (2) NOT NULL,
	tytd_coef_sum NUMBER (6, 4) NOT NULL
	) PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_hcc_opprtnty_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_hcc_opprtnty_detail (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	elig_cds_id NUMBER NOT NULL,
	interaction_ind NUMBER (1) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	py_id NUMBER NOT NULL,
	py_latest_type VARCHAR2 (20 CHAR),
	py_latest_value VARCHAR2 (50 CHAR),
	py_max_dt DATE,
	score_id NUMBER (5) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL,
	tytd_id NUMBER,
	tytd_latest_type VARCHAR2 (20 CHAR),
	tytd_latest_value VARCHAR2 (50 CHAR),
	tytd_max_dt DATE
	) PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_score', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_score (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	elig_cds_id NUMBER NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	score NUMBER (9, 4) NOT NULL,
	score_default_flg NUMBER DEFAULT 0 NOT NULL,
	score_id NUMBER (5) NOT NULL,
	timeframe_id NUMBER NOT NULL
	) PARTITION BY RANGE(score_id) INTERVAL(1) (PARTITION P_SCORE_0 VALUES LESS THAN (0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_score_markercat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_score_markercat (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	coef_sum NUMBER (9, 4) NOT NULL,
	elig_cds_id NUMBER NOT NULL,
	markercat_id NUMBER NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	score_id NUMBER (5) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL,
	timeframe_id NUMBER NOT NULL
	) PARTITION BY RANGE(score_id) INTERVAL(1) (PARTITION P_SCORE_0 VALUES LESS THAN(0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_patient_condition', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_patient_condition (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	condition_id NUMBER NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	precursor_domain_flg NUMBER NOT NULL,
	precursor_flg NUMBER NOT NULL,
	precursor_modifier_flg NUMBER DEFAULT 0 NOT NULL,
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL,
	yr_month NUMBER (6) NOT NULL
	) PARTITION BY RANGE(condition_id) INTERVAL(1) (PARTITION p_cond_0 VALUES LESS THAN (0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_condition_inferred', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_condition_inferred (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	condition_id NUMBER NOT NULL,
	inferred_ind NUMBER NOT NULL,
	inferred_prc_cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	inferred_prc_domain_flg NUMBER NOT NULL,
	inferred_prc_flg NUMBER NOT NULL,
	inferred_prc_modifier_flg NUMBER NOT NULL,
	inferred_precursor_cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	precursor_domain_flg NUMBER NOT NULL,
	precursor_flg NUMBER NOT NULL,
	precursor_modifier_flg NUMBER DEFAULT 0 NOT NULL,
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL,
	yr_month NUMBER (6) NOT NULL
	) PARTITION BY RANGE(condition_id) INTERVAL(1) (PARTITION P_cond_0 VALUES LESS THAN (0))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_timeframe', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_timeframe (
	data_end_dt DATE NOT NULL,
	end_dt DATE NOT NULL,
	start_dt DATE NOT NULL,
	timeframe_desc VARCHAR2 (50 CHAR) NOT NULL,
	timeframe_id NUMBER NOT NULL,
	timeframe_type VARCHAR2 (20 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('md_oadw_instance', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE md_oadw_instance (
	attribute_name VARCHAR2 (20 CHAR) NOT NULL,
	attribute_value VARCHAR2 (100 CHAR) NOT NULL,
	last_update_dtm DATE DEFAULT SYSDATE
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_diagnosis', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_diagnosis (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2 (16 CHAR),
	codetype VARCHAR2(16 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	diag_dtm TIMESTAMP,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hosp_dx_flag VARCHAR2(3 CHAR) NULL,
	localactiveind VARCHAR2(50 CHAR) NULL,
	localadmitflg VARCHAR2(255 CHAR) NULL,
	localdiagnosis VARCHAR2(255 CHAR) NULL,
	localdiagnosisproviderid VARCHAR2(255 CHAR) NULL,
	localdiagnosisstatus VARCHAR2(255 CHAR) NULL,
	localdischargeflg VARCHAR2(255 CHAR) NULL,
	localpresentonadmission VARCHAR2(255 CHAR) NULL,
	mappeddiagnosis VARCHAR2(255 CHAR) NULL,
	mappeddiagnosisstatus VARCHAR2(16 CHAR) NULL,
	mappedpresentonadmission VARCHAR2 (8 CHAR),
	modified_date TIMESTAMP,
	mpi VARCHAR2 (32 CHAR),
	orig_codetype VARCHAR2(16 CHAR) NULL,
	orig_mappeddiagnosis VARCHAR2(255 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	primarydiagnosis NUMBER (1) NULL,
	resolution_dt TIMESTAMP,
	row_source VARCHAR2 (10 CHAR),
	sourceid VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_specialty_ii', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_specialty_ii (
	client_id VARCHAR2 (16 CHAR),
	dts_version NUMBER (10, 0),
	local_code VARCHAR2 (255 CHAR),
	specialty_id VARCHAR2 (249 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_org_hier', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_org_hier (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	most_recent_ind NUMBER (1, 0) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	org_cd VARCHAR2 (150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_org_hier_evt', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_org_hier_evt (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	org_cd VARCHAR2 (150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_condition_precursor', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_condition_precursor (
	condition_id NUMBER (12) NOT NULL,
	condition_precursor_desc VARCHAR2 (100 CHAR) NOT NULL,
	precursor_id NUMBER (12) NOT NULL,
	sensitive_cat_id NUMBER (16) NOT NULL,
	sensitive_ind NUMBER (13) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_condition_rule', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_condition_rule (
	condition_id NUMBER (12) NOT NULL,
	condition_rule_desc VARCHAR2 (400 CHAR) NOT NULL,
	precursor_family_cnt NUMBER (20)  NULL,
	precursor_family_cnt_max_days NUMBER (29) NULL,
	precursor_family_cnt_min_days NUMBER (29) NULL,
	rule_id NUMBER (7) NOT NULL,
	sensitive_cat_id NUMBER (16) NOT NULL,
	sensitive_ind NUMBER (13) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_allergy', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_allergy (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dcc VARCHAR2(16 CHAR) NULL,
	encounterid VARCHAR2(249 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hts_generic VARCHAR2(100 CHAR) NULL,
	hts_generic_ext VARCHAR2(100 CHAR) NULL,
	hum_gen_med_key VARCHAR2(80 CHAR) NULL,
	hum_med_key VARCHAR2(16 CHAR) NULL,
	localallergencd VARCHAR2(249 CHAR) NULL,
	localallergendesc VARCHAR2(249 CHAR) NULL,
	localallergentype VARCHAR2(249 CHAR) NULL,
	localgpi VARCHAR2(249 CHAR) NULL,
	localndc VARCHAR2(249 CHAR) NULL,
	localstatus VARCHAR2(249 CHAR) NULL,
	map_used VARCHAR2(16 CHAR) NULL,
	mappedgpi VARCHAR2(249 CHAR) NULL,
	mappedndc VARCHAR2(249 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	ndc11 VARCHAR2(11 CHAR) NULL,
	onset_dt DATE  NOT NULL,
	patientid VARCHAR2(249 CHAR) NOT NULL,
	rxnorm_code VARCHAR2(25 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_appointment', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_appointment (
	appointment_dtm DATE  NOT NULL,
	appointment_reason VARCHAR2(249 CHAR) NULL,
	appointmentid VARCHAR2(249 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	local_appt_type VARCHAR2(249 CHAR) NULL,
	locationid VARCHAR2(249 CHAR) NOT NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	patientid VARCHAR2(249 CHAR) NOT NULL,
	providerid VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_care_management_pathway', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_care_management_pathway (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cp_attribute VARCHAR2(249 CHAR) NULL,
	cp_library_id VARCHAR2(249 CHAR) NULL,
	cp_library_name VARCHAR2(249 CHAR) NULL,
	cp_value VARCHAR2(249 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NULL,
	prog_id VARCHAR2(50 CHAR) NULL,
	updated_dtm DATE  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_care_management_program', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_care_management_program (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NULL,
	prog_desc VARCHAR2(249 CHAR) NULL,
	prog_duration VARCHAR2(50 CHAR) NULL,
	prog_id VARCHAR2(249 CHAR) NULL,
	prog_name VARCHAR2(249 CHAR) NULL,
	prog_owner VARCHAR2(249 CHAR) NULL,
	prog_status VARCHAR2(249 CHAR) NULL,
	prog_status_end_dt DATE  NULL,
	prog_status_reason VARCHAR2(249 CHAR) NULL,
	prog_status_st_dt DATE  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_claim', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_claim (
	allowedamount NUMBER  NULL,
	capitated_service_flag VARCHAR2(249 CHAR) NULL,
	capitation_amt NUMBER  NULL,
	charge NUMBER (10, 2) NULL,
	claim VARCHAR2(255 CHAR) NOT NULL,
	claim_mstrprovid VARCHAR2(249 CHAR) NULL,
	claimproviderid VARCHAR2(255 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	coinsurance_amt NUMBER  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	coord_benefits_amt NUMBER  NULL,
	copay_amt NUMBER  NULL,
	costamount NUMBER  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	deductible_amt NUMBER  NULL,
	denied_flag VARCHAR2(249 CHAR) NULL,
	ein VARCHAR2(249 CHAR) NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	fee_for_service_amt NUMBER  NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	localbillingproviderid VARCHAR2(255 CHAR) NULL,
	localcpt VARCHAR2(255 CHAR) NULL,
	localcptmod1 VARCHAR2(255 CHAR) NULL,
	localcptmod2 VARCHAR2(255 CHAR) NULL,
	localcptmod3 VARCHAR2(255 CHAR) NULL,
	localcptmod4 VARCHAR2(255 CHAR) NULL,
	localhcpcs VARCHAR2(255 CHAR) NULL,
	localicd9 VARCHAR2(255 CHAR) NULL,
	localrev VARCHAR2(249 CHAR) NULL,
	mappedcpt VARCHAR2(255 CHAR) NULL,
	mappedcptmod1 VARCHAR2(255 CHAR) NULL,
	mappedcptmod2 VARCHAR2(255 CHAR) NULL,
	mappedcptmod3 VARCHAR2(255 CHAR) NULL,
	mappedcptmod4 VARCHAR2(255 CHAR) NULL,
	mappedhcpcs VARCHAR2(255 CHAR) NULL,
	mappedicd9 VARCHAR2(255 CHAR) NULL,
	mappedrev VARCHAR2(4 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	network_paid_status VARCHAR2(30 CHAR) NULL,
	paidamount NUMBER  NULL,
	par_flag VARCHAR2(1 CHAR) NULL,
	pat_liability_amt NUMBER  NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	pos VARCHAR2(249 CHAR) NULL,
	post_dt DATE  NULL,
	pseudo_flag VARCHAR2(249 CHAR) NULL,
	quantity VARCHAR2(255 CHAR) NULL,
	seq NUMBER (10) NULL,
	service_dtm TIMESTAMP(3)  NOT NULL,
	techorprof CHAR(1) NULL,
	to_dt DATE  NULL,
	withhold_amt NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_clinicalencounter', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_clinicalencounter (
	admit_dtm TIMESTAMP(3)  NULL,
	admittingphysician VARCHAR2(255 CHAR) NULL,
	alt_encounterid VARCHAR2(255 CHAR) NULL,
	aprdrg_cd VARCHAR2(255 CHAR) NULL,
	aprdrg_rom VARCHAR2(255 CHAR) NULL,
	aprdrg_soi VARCHAR2(255 CHAR) NULL,
	arrival_dtm TIMESTAMP(3)  NOT NULL,
	attendingphysician VARCHAR2(255 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	discharge_dtm TIMESTAMP(3)  NULL,
	elos NUMBER (20, 4) NULL,
	encounterid VARCHAR2(255 CHAR) NOT NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	inferred_pat_type VARCHAR2(255 CHAR) NULL,
	inpatientlocation VARCHAR2(255 CHAR) NULL,
	localaccountstatus VARCHAR2(255 CHAR) NULL,
	localadmitsource VARCHAR2(255 CHAR) NULL,
	localdischargedisposition VARCHAR2(255 CHAR) NULL,
	localdrg VARCHAR2(255 CHAR) NULL,
	localdrgtype VARCHAR2(255 CHAR) NULL,
	localencountertype VARCHAR2(255 CHAR) NULL,
	localfinancialclass VARCHAR2(255 CHAR) NULL,
	localmdc VARCHAR2(255 CHAR) NULL,
	localpatienttype VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	pcpid VARCHAR2(255 CHAR) NULL,
	referproviderid VARCHAR2(255 CHAR) NULL,
	totalcharge NUMBER  NULL,
	totalcost NUMBER  NULL,
	visitid VARCHAR2(255 CHAR) NULL,
	wasplannedflg VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ebm_drugadherence', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ebm_drugadherence (
	calc_type VARCHAR2(1 CHAR) NULL,
	class_type VARCHAR2(3 CHAR) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	days_sup NUMBER (4) NULL,
	drug_class VARCHAR2(5 CHAR) NULL,
	elapsed_days NUMBER (4) NULL,
	event NUMBER (4) NULL,
	file_processing_month DATE  NULL,
	fill_beg_dt DATE  NULL,
	fill_end_dt DATE  NULL,
	first_fill_dt DATE  NULL,
	first_unique_rec_id VARCHAR2(28 CHAR) NULL,
	last_fill_dt DATE  NULL,
	last_unique_rec_id VARCHAR2(28 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	ndc VARCHAR2(11 CHAR) NULL,
	poss_ratio NUMBER (9, 2) NULL,
	process VARCHAR2(1 CHAR) NULL,
	prov VARCHAR2(20 CHAR) NULL,
	prov_part_code VARCHAR2(1 CHAR) NULL,
	prov_spec VARCHAR2(2 CHAR) NULL,
	report_case_id NUMBER (6) NULL,
	report_rule_id NUMBER (9) NULL,
	script_cnt NUMBER (4) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ebm_memberdetail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ebm_memberdetail (
	age NUMBER (3) NULL,
	age_in_months NUMBER (4) NULL,
	birth_date DATE  NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	file_processing_month_dt DATE  NULL,
	gender VARCHAR2(1 CHAR) NULL,
	imp_ob_prov VARCHAR2(20 CHAR) NULL,
	imp_ob_prov_flag VARCHAR2(1 CHAR) NULL,
	imp_ob_prov_spec VARCHAR2(2 CHAR) NULL,
	imp_prov VARCHAR2(20 CHAR) NULL,
	imp_prov_flag VARCHAR2(1 CHAR) NULL,
	imp_prov_spec VARCHAR2(2 CHAR) NULL,
	med NUMBER (4) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	pcp1 VARCHAR2(20 CHAR) NULL,
	pcp1_flag VARCHAR2(1 CHAR) NULL,
	pcp1_spec VARCHAR2(2 CHAR) NULL,
	pcp2 VARCHAR2(20 CHAR) NULL,
	pcp2_flag VARCHAR2(1 CHAR) NULL,
	pcp2_spec VARCHAR2(2 CHAR) NULL,
	pcp3 VARCHAR2(20 CHAR) NULL,
	pcp3_flag VARCHAR2(1 CHAR) NULL,
	pcp3_spec VARCHAR2(2 CHAR) NULL,
	process VARCHAR2(1 CHAR) NULL,
	report_per_end_dt DATE  NULL,
	rx NUMBER (4) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ebm_memberevent', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ebm_memberevent (
	age NUMBER (3) NULL,
	age_months NUMBER (4) NULL,
	care_cat VARCHAR2(3 CHAR) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	episode_from_dt DATE  NULL,
	episode_prov_spec VARCHAR2(2 CHAR) NULL,
	episode_provider VARCHAR2(20 CHAR) NULL,
	episode_thru_dt DATE  NULL,
	event NUMBER (4) NULL,
	event_from_dt DATE  NULL,
	event_thru_dt DATE  NULL,
	file_processing_month_dt DATE  NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	process VARCHAR2(1 CHAR) NULL,
	report_case_id NUMBER (6) NULL,
	unique_recid VARCHAR2(28 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ebm_memcondfile', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ebm_memcondfile (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cond_conf_qual VARCHAR2(1 CHAR) NULL,
	file_processing_month_dt DATE  NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	process VARCHAR2(1 CHAR) NULL,
	report_case_id NUMBER (6) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ebm_summaryresult', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ebm_summaryresult (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	comp_flag VARCHAR2(1 CHAR) NULL,
	ebm_flag VARCHAR2(1 CHAR) NULL,
	event NUMBER (4) NULL,
	file_processing_month_dt DATE  NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	process VARCHAR2(1 CHAR) NULL,
	report_case_id NUMBER (6) NULL,
	report_rule_id NUMBER (9) NULL,
	result_flag VARCHAR2(3 CHAR) NULL,
	rule_type_num NUMBER (4) NULL,
	task_number NUMBER (3) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_encountercarearea', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_encountercarearea (
	careareaend_dtm TIMESTAMP(3)  NULL,
	careareastart_dtm TIMESTAMP(3)  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounter_dtm TIMESTAMP(3)  NOT NULL,
	encounterid VARCHAR2(255 CHAR) NOT NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	localcareareacode VARCHAR2(255 CHAR) NULL,
	locallocationname VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	servicecode VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_encounterprovider', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_encounterprovider (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounter_dtm TIMESTAMP(3)  NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	providerid VARCHAR2(255 CHAR) NULL,
	providerrole VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_encounterreason', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_encounterreason (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NOT NULL,
	localreasontext VARCHAR2(2000 CHAR) NOT NULL,
	mappedreason VARCHAR2(16 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	reason_dtm DATE  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_facility', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_facility (
	charge_cost_ratio NUMBER  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	facilityid VARCHAR2(255 CHAR) NOT NULL,
	facilityname VARCHAR2(255 CHAR) NULL,
	facilitypostalcd VARCHAR2(10 CHAR) NULL,
	localfacilitytype VARCHAR2(255 CHAR) NULL,
	npi VARCHAR2(255 CHAR) NULL,
	specialty VARCHAR2(100 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_encounter_encounter_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_encounter_encounter_grp (
	client_ds_id NUMBER (22) NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	encounter_grp_num NUMBER (16) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NOT NULL,
	encounteridtype VARCHAR2(8 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patienttype VARCHAR2(8 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_encounter_grp_rel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_encounter_grp_rel (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	encounter_grp_num NUMBER (16) NOT NULL,
	encounter_grp_rel_type VARCHAR2(8 CHAR) NULL,
	rel_encounter_grp_num NUMBER (16) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_health_maintenance', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_health_maintenance (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	documented_dt TIMESTAMP(3)  NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hm_cui VARCHAR2(255 CHAR) NOT NULL,
	last_satisfied_dt TIMESTAMP(3)  NULL,
	localcode VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	next_due_dt TIMESTAMP(3)  NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_hedis_audit_output', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_hedis_audit_output (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	contributing_object_name VARCHAR2(32 CHAR) NULL,
	episode_identifier VARCHAR2(32 CHAR) NULL,
	hum_vers_yr VARCHAR2(16 CHAR) NOT NULL,
	measure_audit_key VARCHAR2(40 CHAR) NULL,
	measurement_end_dt DATE  NOT NULL,
	metric_code VARCHAR2(32 CHAR) NULL,
	metric_value VARCHAR2(1000 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	population_id VARCHAR2(32 CHAR) NULL,
	version VARCHAR2(30 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_hedis_measure_result', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_hedis_measure_result (
	actual_visit_count NUMBER  NULL,
	adjusted_probability NUMBER (22, 5) NULL,
	age NUMBER (22, 5) NULL,
	age_and_gender_weight NUMBER (22, 5) NULL,
	base_risk_weight NUMBER (22, 5) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	comorbidity_weight NUMBER (22, 5) NULL,
	days_count NUMBER  NULL,
	dcc_category VARCHAR2(32 CHAR) NULL,
	dcc_weight NUMBER (22, 5) NULL,
	denominator_exception_flag VARCHAR2(1 CHAR) NULL,
	denominator_exclusion_flag VARCHAR2(1 CHAR) NULL,
	denominator_flag VARCHAR2(1 CHAR) NULL,
	discharge_count NUMBER  NULL,
	episode_number VARCHAR2(32 CHAR) NULL,
	expected_visit_count NUMBER  NULL,
	gender VARCHAR2(32 CHAR) NULL,
	hum_vers_yr VARCHAR2(16 CHAR) NOT NULL,
	measure_id VARCHAR2(32 CHAR) NULL,
	measure_name VARCHAR2(32 CHAR) NULL,
	measurement_end_dt DATE  NOT NULL,
	member_month_count NUMBER  NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	numerator_exclusion_flag VARCHAR2(1 CHAR) NULL,
	numerator_flag VARCHAR2(1 CHAR) NULL,
	population_id VARCHAR2(32 CHAR) NULL,
	qualifying_dt DATE  NULL,
	result_answer VARCHAR2(32 CHAR) NULL,
	risk_score NUMBER (22, 5) NULL,
	run_dt DATE  NULL,
	services_count NUMBER  NULL,
	stratification_id VARCHAR2(32 CHAR) NULL,
	surgery_weight NUMBER (22, 5) NULL,
	version VARCHAR2(30 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_immunization', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_immunization (
	admin_dtm DATE  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dcc VARCHAR2(16 CHAR) NULL,
	documented_dt DATE  NULL,
	encounterid VARCHAR2(249 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hts_generic VARCHAR2(100 CHAR) NULL,
	hts_generic_ext VARCHAR2(100 CHAR) NULL,
	hum_gen_med_key VARCHAR2(80 CHAR) NULL,
	hum_med_key VARCHAR2(16 CHAR) NULL,
	localdeferredreason VARCHAR2(249 CHAR) NULL,
	localgpi VARCHAR2(249 CHAR) NULL,
	localimmunizationcd VARCHAR2(249 CHAR) NULL,
	localimmunizationdesc VARCHAR2(249 CHAR) NULL,
	localndc VARCHAR2(249 CHAR) NULL,
	localpatreportedflg VARCHAR2(249 CHAR) NULL,
	localroute VARCHAR2(249 CHAR) NULL,
	map_used VARCHAR2(16 CHAR) NULL,
	mappedgpi VARCHAR2(14 CHAR) NULL,
	mappedndc VARCHAR2(11 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	ndc11 VARCHAR2(11 CHAR) NULL,
	patientid VARCHAR2(249 CHAR) NOT NULL,
	rxnorm_code VARCHAR2(25 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_insurance', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_insurance (
	benefit_plan_code VARCHAR2(249 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	contract_type_code VARCHAR2(249 CHAR) NULL,
	coverage_class_code VARCHAR2(3 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	emp_acct_id VARCHAR2(249 CHAR) NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	enrollend_dt DATE  NULL,
	enrollstart_dt DATE  NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	groupnbr VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	insurance_dt TIMESTAMP(3)  NOT NULL,
	insuranceorder NUMBER (10) NULL,
	mappedpayorcode VARCHAR2(16 CHAR) NULL,
	mappedplanfincode VARCHAR2(16 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	payorcode VARCHAR2(255 CHAR) NULL,
	payorname VARCHAR2(255 CHAR) NULL,
	pharmacy_benefit_flag VARCHAR2(1 CHAR) NULL,
	plancode VARCHAR2(255 CHAR) NULL,
	planname VARCHAR2(255 CHAR) NULL,
	plantype VARCHAR2(255 CHAR) NULL,
	policynumber VARCHAR2(255 CHAR) NULL,
	product_code VARCHAR2(249 CHAR) NULL,
	product_name VARCHAR2(249 CHAR) NULL,
	sourceid VARCHAR2(255 CHAR) NULL,
	subscriber_flag VARCHAR2(1 CHAR) NULL,
	subscriber_id VARCHAR2(30 CHAR) NULL,
	subscriber_relation VARCHAR2(30 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_laborder', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_laborder (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	laborderid VARCHAR2(255 CHAR) NULL,
	localspecimentype VARCHAR2(255 CHAR) NULL,
	localtestdescription VARCHAR2(255 CHAR) NULL,
	localtestname VARCHAR2(255 CHAR) NULL,
	mappedtestdescription VARCHAR2(255 CHAR) NULL,
	mappedtestname VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	ordered_dtm TIMESTAMP(3)  NULL,
	orderingproviderid VARCHAR2(255 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	specimen_collect_dtm TIMESTAMP(3)  NULL,
	statuscode VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_labresult', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_labresult (
	available_dtm TIMESTAMP(3)  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	collected_dtm TIMESTAMP(3)  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	laborderid VARCHAR2(255 CHAR) NULL,
	labresultid VARCHAR2(2000 CHAR) NOT NULL,
	local_loinc_code VARCHAR2(25 CHAR) NULL,
	localcode VARCHAR2(255 CHAR) NULL,
	locallisresource VARCHAR2(200 CHAR) NULL,
	localname VARCHAR2(2000 CHAR) NULL,
	localresult VARCHAR2(2000 CHAR) NULL,
	localresult_inferred NUMBER  NULL,
	localresult_numeric NUMBER  NULL,
	localspecimentype VARCHAR2(255 CHAR) NULL,
	localtestname VARCHAR2(255 CHAR) NULL,
	localunits VARCHAR2(255 CHAR) NULL,
	localunits_inferred VARCHAR2(255 CHAR) NULL,
	mapped_qual_code VARCHAR2(16 CHAR) NULL,
	mappedcode VARCHAR2(255 CHAR) NULL,
	mappedloinc VARCHAR2(249 CHAR) NULL,
	mappedname VARCHAR2(2000 CHAR) NULL,
	mappedunits VARCHAR2(16 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	normalizedvalue NUMBER  NULL,
	normalrange VARCHAR2(255 CHAR) NULL,
	ordered_dtm DATE  NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	relativeindicator VARCHAR2(16 CHAR) NULL,
	resultstatus VARCHAR2(255 CHAR) NULL,
	resulttype VARCHAR2(16 CHAR) NULL,
	statuscode VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_labresult_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_labresult_qual (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	htslabcode VARCHAR2(15 CHAR) NULL,
	htslabresult VARCHAR2(15 CHAR) NULL,
	htsresultgroup VARCHAR2(15 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	qualitativeresult VARCHAR2(15 CHAR) NULL,
	result_dtm TIMESTAMP(3)  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_aco_exclusion', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_aco_exclusion (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_active_diag_ind', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_active_diag_ind (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_admit_diag', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_admit_diag (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_admit_source', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_admit_source (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_alcohol', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_alcohol (
	client_id VARCHAR2(50 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(150 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_alcohol_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_alcohol_detail (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_allergen', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_allergen (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_advanced_directive', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_advanced_directive (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(16 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_allergen_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_allergen_type (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_allergy_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_allergy_status (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_bmi_followup', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_bmi_followup (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_bp_followup', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_bp_followup (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_cad_plan_of_care', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_cad_plan_of_care (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_care_area', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_care_area (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_client_datasrc_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_client_datasrc_type (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_clin_pathways', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_clin_pathways (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_contact_src', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_contact_src (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	dts_version NUMBER  NOT NULL,
	is_primary_contact VARCHAR2(255 CHAR) NULL,
	priority_order NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_custom_proc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_custom_proc (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	codetype VARCHAR2(255 CHAR) NOT NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL,
	mappedvalue VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_daw', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_daw (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER (22) NULL,
	local_code VARCHAR2(50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_deceased_indicator', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_deceased_indicator (
	client_id VARCHAR2(255 CHAR) NOT  NULL,
	cui VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_depression_followup', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_depression_followup (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_diab_eye_exam', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_diab_eye_exam (
	client_id VARCHAR2(255 CHAR) NOT  NULL,
	cui VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_diagnosis_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_diagnosis_status (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_discharge_diag', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_discharge_diag (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER (22) NULL,
	local_code VARCHAR2(50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_discharge_disposition', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_discharge_disposition (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_drg_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_drg_type (
	client_id VARCHAR2(50 CHAR)  NULL,
	code VARCHAR2(50 CHAR) NULL,
	cui VARCHAR2(2000 CHAR) NULL,
	dts_version NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_ethnicity', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_ethnicity (
	client_id VARCHAR2(255 CHAR) NOT  NULL,
	cui VARCHAR2(255 CHAR) NOT NULL,
	description VARCHAR2(1000 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_ethnic_group', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_ethnic_group (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_exercise_level', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_exercise_level (
	client_id VARCHAR2(255 CHAR)  NULL,
	cui VARCHAR2(255 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_fac_order', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_fac_order (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	fac_exclude_flg VARCHAR2(1 CHAR) NULL,
	fac_order NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_financial_class', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_financial_class (
	client_id VARCHAR2(255 CHAR) NOT  NULL,
	cui VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_gender', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_gender (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_hospice_ind', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_hospice_ind (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_immun_defer_reason', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_immun_defer_reason (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_lab_codes', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_lab_codes (
	client_ds_id NUMBER (10) NOT NULL,
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL,
	mapping_context VARCHAR2(50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_language', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_language (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_marital_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_marital_status (
	client_id VARCHAR2(50 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(150 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_med_disc_reason', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_med_disc_reason (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_med_order_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_med_order_status (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_med_route', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_med_route (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_med_schedule', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_med_schedule (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_micro_result_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_micro_result_status (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_observation', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_observation (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	datasrc VARCHAR2(255 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL,
	local_name VARCHAR2(256 CHAR) NULL,
	localunit VARCHAR2(1000 CHAR) NULL,
	localunit_cui VARCHAR2(16 CHAR) NULL,
	obsregex VARCHAR2(1000 CHAR) NULL,
	obstype VARCHAR2(255 CHAR) NULL,
	zero_to_null CHAR(1) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_ordertype', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_ordertype (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_patient_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_patient_type (
	client_id VARCHAR2(255 CHAR) NOT  NULL,
	cui VARCHAR2(255 CHAR) NOT NULL,
	description VARCHAR2(1000 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_pcp_order', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_pcp_order (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	pcp_exclude_flg VARCHAR2(1 CHAR) NULL,
	pcp_order NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_poa', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_poa (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_predicate_values', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_predicate_values (
	client_ds_id NUMBER  NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	column_name VARCHAR2(255 CHAR) NOT NULL,
	column_value VARCHAR2(255 CHAR) NOT NULL,
	data_src VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	entity VARCHAR2(255 CHAR) NOT NULL,
	table_name VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_prob_list', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_prob_list (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	is_problemlist CHAR(1) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_program_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_program_status (
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_prog_cancel_reason', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_prog_cancel_reason (
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_prog_close_reason', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_prog_close_reason (
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_provider_role', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_provider_role (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_ptrep_med_action', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_ptrep_med_action (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_ptrep_med_category', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_ptrep_med_category (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_race', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_race (
	client_id VARCHAR2(255 CHAR) NOT  NULL,
	cui VARCHAR2(255 CHAR) NOT NULL,
	description VARCHAR2(1000 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_screening_tests', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_screening_tests (
	client_id VARCHAR2(255 CHAR) NOT  NULL,
	dts_version NUMBER  NOT NULL,
	hts_code VARCHAR2(255 CHAR) NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_service', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_service (
	client_id VARCHAR2(50 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(150 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_smoking_cessation', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_smoking_cessation (
	client_id VARCHAR2(50 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(200 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_smoking_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_smoking_status (
	client_id VARCHAR2(255 CHAR)  NULL,
	cui VARCHAR2(255 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_specialty', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_specialty (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_specimen_source', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_specimen_source (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_techorprof', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_techorprof (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(50 CHAR) NOT NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_tobacco_cessation', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_tobacco_cessation (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_tobacco_use', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_tobacco_use (
	client_id VARCHAR2(16 CHAR)  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	dts_version NUMBER  NULL,
	local_code VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_treatment_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_treatment_type (
	client_id VARCHAR2(7 CHAR) NOT  NULL,
	dts_version NUMBER  NOT NULL,
	hts_code VARCHAR2(255 CHAR) NOT NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL,
	local_unit VARCHAR2(20 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_unit', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_unit (
	cui VARCHAR2(50 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	local_code VARCHAR2(200 CHAR) NOT  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_upload_rules', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_upload_rules (
	client_ds_id NUMBER (22) NULL,
	client_id VARCHAR2(255 CHAR) NOT  NULL,
	datasource VARCHAR2(255 CHAR) NOT NULL,
	ds_display_name VARCHAR2(255 CHAR) NOT NULL,
	dts_version NUMBER  NOT NULL,
	id_sub_type VARCHAR2(255 CHAR) NULL,
	id_type VARCHAR2(255 CHAR) NULL,
	is_default_datasource NUMBER (1) NULL,
	regex VARCHAR2(255 CHAR) NOT NULL,
	rule_type VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_mborder', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_mborder (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	collected_dtm TIMESTAMP(3)  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hts_specimen_source VARCHAR2(16 CHAR) NULL,
	localordercode VARCHAR2(255 CHAR) NULL,
	localorderdesc VARCHAR2(255 CHAR) NULL,
	localorderstatus VARCHAR2(255 CHAR) NULL,
	localspecimenname VARCHAR2(255 CHAR) NULL,
	localspecimensource VARCHAR2(255 CHAR) NULL,
	mbprocorderid VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	ordered_dtm TIMESTAMP(3)  NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	received_dtm TIMESTAMP(3)  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_mbresult', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_mbresult (
	antibiotic_loinc VARCHAR2(50 CHAR) NULL,
	available_dtm TIMESTAMP(3)  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	culture_growth_cui VARCHAR2(16 CHAR) NULL,
	culture_unit_cui VARCHAR2(16 CHAR) NULL,
	culture_val_cui VARCHAR2(16 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	localantibioticcode VARCHAR2(255 CHAR) NULL,
	localantibioticname VARCHAR2(255 CHAR) NULL,
	localorganismcode VARCHAR2(255 CHAR) NULL,
	localorganismname VARCHAR2(255 CHAR) NULL,
	localorganismtype VARCHAR2(255 CHAR) NULL,
	localresulstatus VARCHAR2(255 CHAR) NULL,
	localsensitivity VARCHAR2(255 CHAR) NULL,
	localsensitivity_value VARCHAR2(255 CHAR) NULL,
	mbprocorderid VARCHAR2(255 CHAR) NULL,
	mbprocresultid VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	org_exclude_cui VARCHAR2(16 CHAR) NULL,
	organism_found_cui VARCHAR2(16 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	result_status_cui VARCHAR2(16 CHAR) NULL,
	sens_antibiotic_dcc VARCHAR2(50 CHAR) NULL,
	sens_result_cui VARCHAR2(16 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_observation', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_observation (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	local_obs_unit VARCHAR2(1000 CHAR) NULL,
	localcode VARCHAR2(255 CHAR) NULL,
	localresult VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	observation_dtm TIMESTAMP(3)  NOT NULL,
	obsresult VARCHAR2(255 CHAR) NULL,
	obstype VARCHAR2(255 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	result_dt TIMESTAMP(6)  NULL,
	statuscode VARCHAR2(255 CHAR) NULL,
	std_obs_unit VARCHAR2(32 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patient', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patient (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dateofbirth TIMESTAMP(3)  NULL,
	dateofdeath DATE  NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	inactive_flag VARCHAR2(1 CHAR) NULL,
	medicalrecordnumber VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patientaddr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patientaddr (
	address_dtm DATE  NOT NULL,
	address_line1 VARCHAR2(250 CHAR) NULL,
	address_line2 VARCHAR2(250 CHAR) NULL,
	address_type VARCHAR2(250 CHAR) NULL,
	city VARCHAR2(250 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(250 CHAR) NOT NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(250 CHAR) NOT NULL,
	state VARCHAR2(2 CHAR) NULL,
	zipcode VARCHAR2(10 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patientaddr_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patientaddr_summary (
	address_line1 VARCHAR2(250 CHAR) NULL,
	address_line2 VARCHAR2(250 CHAR) NULL,
	address_type VARCHAR2(250 CHAR) NULL,
	city VARCHAR2(250 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	multiple_values NUMBER  NULL,
	record_dtm DATE  NULL,
	state VARCHAR2(2 CHAR) NULL,
	zipcode VARCHAR2(10 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patientcontact', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patientcontact (
	cell_phone VARCHAR2(50 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	home_phone VARCHAR2(50 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(249 CHAR) NOT NULL,
	personal_email VARCHAR2(200 CHAR) NULL,
	update_dtm DATE  NOT NULL,
	work_email VARCHAR2(200 CHAR) NULL,
	work_phone VARCHAR2(50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patientcontact_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patientcontact_summary (
	cell_phone VARCHAR2(50 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	home_phone VARCHAR2(50 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	multiple_values NUMBER  NULL,
	personal_email VARCHAR2(200 CHAR) NULL,
	record_dtm DATE  NULL,
	work_email VARCHAR2(200 CHAR) NULL,
	work_phone VARCHAR2(50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patientdetail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patientdetail (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	localvalue VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patdetail_dtm TIMESTAMP(3)  NOT NULL,
	patientdetailqual VARCHAR2(32 CHAR) NULL,
	patientdetailtype VARCHAR2(32 CHAR) NOT NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patient_attribute', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patient_attribute (
	attribute_type_cui VARCHAR2(50 CHAR) NULL,
	attribute_value VARCHAR2(255 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	eff_date DATE  NULL,
	end_date DATE  NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patient_care_pathway', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patient_care_pathway (
	cc_assignment_dt DATE  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(20 CHAR)  NULL,
	closed_dt DATE  NULL,
	cp_id VARCHAR2(100 CHAR) NULL,
	cp_library_id VARCHAR2(255 CHAR) NULL,
	create_dt DATE  NULL,
	datasrc VARCHAR2(249 CHAR) NULL,
	first_completed_task_dt DATE  NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	owner_id VARCHAR2(100 CHAR) NULL,
	owner_name VARCHAR2(255 CHAR) NULL,
	patientid VARCHAR2(249 CHAR) NULL,
	prog_id VARCHAR2(255 CHAR) NULL,
	provider_npi VARCHAR2(100 CHAR) NULL,
	reg_mem_create_dt DATE  NULL,
	status VARCHAR2(255 CHAR) NULL,
	status_dt DATE  NULL,
	updated_dt DATE  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_patient_grp_mpi_diff', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_patient_grp_mpi_diff (
	client_ds_id NUMBER NOT NULL,
	client_id VARCHAR2 (20 CHAR) NOT NULL,
	datasrc VARCHAR2 (249 CHAR),
	hgpid VARCHAR2 (249 CHAR),
	mpi_status VARCHAR2 (32 CHAR),
	new_mpi VARCHAR2 (32 CHAR),
	old_mpi VARCHAR2 (32 CHAR),
	patientid VARCHAR2 (249 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patient_id', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patient_id (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(32 CHAR) NOT NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	id_subtype VARCHAR2(255 CHAR) NULL,
	idtype VARCHAR2(8 CHAR) NOT NULL,
	idvalue VARCHAR2(255 CHAR) NOT NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patient_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patient_summary (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	date_of_death DATE  NULL,
	display_id VARCHAR2(600 CHAR) NULL,
	dob VARCHAR2(8 CHAR) NULL,
	first_name VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	inactive_flag VARCHAR2(1 CHAR) NULL,
	last_name VARCHAR2(255 CHAR) NULL,
	local_death_ind VARCHAR2(255 CHAR) NULL,
	local_dod DATE  NULL,
	local_ethnicity VARCHAR2(255 CHAR) NULL,
	local_gender VARCHAR2(255 CHAR) NULL,
	local_language VARCHAR2(249 CHAR) NULL,
	local_marital_status VARCHAR2(249 CHAR) NULL,
	local_race VARCHAR2(255 CHAR) NULL,
	local_zipcode VARCHAR2(255 CHAR) NULL,
	mapped_death_ind VARCHAR2(16 CHAR) NULL,
	mapped_ethnicity VARCHAR2(16 CHAR) NULL,
	mapped_gender VARCHAR2(16 CHAR) NULL,
	mapped_language VARCHAR2(249 CHAR) NULL,
	mapped_marital_status VARCHAR2(249 CHAR) NULL,
	mapped_race VARCHAR2(16 CHAR) NULL,
	mapped_zipcode VARCHAR2(16 CHAR) NULL,
	medicalrecordnumber VARCHAR2(255 CHAR) NULL,
	middle_name VARCHAR2(249 CHAR) NULL,
	mob VARCHAR2(6 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mrace_infer_ind NUMBER (10, 0),
	patientid VARCHAR2(255 CHAR) NOT NULL,
	religion VARCHAR2(255 CHAR) NULL,
	ssdi_dod CHAR(1) NULL,
	ssdi_name_match CHAR(1) NULL,
	yob VARCHAR2(4 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_pat_mrace_infer', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_pat_mrace_infer (
	client_ds_id NUMBER (10, 0),
	client_id VARCHAR2 (16 CHAR),
	mapped_race VARCHAR2 (16 CHAR),
	mpi VARCHAR2 (32 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_pat_risk_attrib', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_pat_risk_attrib (
	at_risk_status VARCHAR2(30 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	contract VARCHAR2(249 CHAR) NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	end_dt DATE  NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	patientid VARCHAR2(249 CHAR) NOT NULL,
	providerid VARCHAR2(255 CHAR) NULL,
	start_dt DATE  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_pft_result', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_pft_result (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	fev1 NUMBER  NULL,
	fev1_fvc_ratio NUMBER  NULL,
	fvc NUMBER  NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	result_dt TIMESTAMP(3)  NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_client_rel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_client_rel (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	end_dt DATE  NULL,
	localrelshipcode VARCHAR2(255 CHAR) NOT NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	prov_status_id VARCHAR2(30 CHAR) NULL,
	providerid VARCHAR2(255 CHAR) NOT NULL,
	start_dt DATE  NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_client_rel_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_client_rel_summary (
	client_ds_id NUMBER (10) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	end_dt DATE  NULL,
	localrelshipcode VARCHAR2(255 CHAR) NOT NULL,
	mstrprovid NUMBER (18) NULL,
	prov_status_id VARCHAR2(30 CHAR) NULL,
	start_dt DATE  NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_fac_rel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_fac_rel (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	end_dt DATE  NULL,
	facilityid VARCHAR2(255 CHAR) NOT NULL,
	localrelshipcode VARCHAR2(255 CHAR) NOT NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	providerid VARCHAR2(255 CHAR) NOT NULL,
	start_dt DATE  NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_fac_rel_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_fac_rel_summary (
	client_ds_id NUMBER (10) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	end_dt DATE  NULL,
	facilityid VARCHAR2(255 CHAR) NOT NULL,
	localrelshipcode VARCHAR2(255 CHAR) NOT NULL,
	mstrprovid NUMBER (18) NULL,
	start_dt DATE  NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_pat_rel', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_pat_rel (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	end_dt DATE  NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	localrelshipcode VARCHAR2(255 CHAR) NOT NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	providerid VARCHAR2(255 CHAR) NOT NULL,
	start_dt DATE  NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_pat_rel_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_pat_rel_summary (
	client_ds_id NUMBER (10) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	end_dt DATE  NULL,
	localrelshipcode VARCHAR2(255 CHAR) NOT NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid NUMBER (18) NULL,
	providerid VARCHAR2(255 CHAR) NOT NULL,
	start_dt DATE  NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_spec (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(100 CHAR) NULL,
	local_code_order NUMBER  NULL,
	localproviderid VARCHAR2(100 CHAR) NOT NULL,
	localspecialtycode VARCHAR2(100 CHAR) NOT NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_rxadmin', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_rxadmin (
	administration_dtm TIMESTAMP(3)  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dcc VARCHAR2(16 CHAR) NULL,
	dispensed_dtm TIMESTAMP(3)  NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hts_generic VARCHAR2(100 CHAR) NULL,
	hts_generic_ext VARCHAR2(100 CHAR) NULL,
	hum_gen_med_key VARCHAR2(80 CHAR) NULL,
	hum_med_key VARCHAR2(16 CHAR) NULL,
	localdoseunit VARCHAR2(255 CHAR) NULL,
	localdrugdescription VARCHAR2(1000 CHAR) NULL,
	localdrugdescription_phi VARCHAR2(1000 CHAR) NULL,
	localform VARCHAR2(255 CHAR) NULL,
	localgenericdesc VARCHAR2(255 CHAR) NULL,
	localgpi VARCHAR2(255 CHAR) NULL,
	localinfusionduration VARCHAR2(255 CHAR) NULL,
	localinfusionrate VARCHAR2(255 CHAR) NULL,
	localinfusionvolume VARCHAR2(255 CHAR) NULL,
	localmedcode VARCHAR2(255 CHAR) NULL,
	localndc VARCHAR2(255 CHAR) NULL,
	localproviderid VARCHAR2(255 CHAR) NULL,
	localqtyofdoseunit VARCHAR2(255 CHAR) NULL,
	localroute VARCHAR2(255 CHAR) NULL,
	localstrengthperdoseunit VARCHAR2(255 CHAR) NULL,
	localstrengthunit VARCHAR2(255 CHAR) NULL,
	localtotaldose VARCHAR2(255 CHAR) NULL,
	map_used VARCHAR2(16 CHAR) NULL,
	mappedgpi VARCHAR2(14 CHAR) NULL,
	mappedndc VARCHAR2(11 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	ndc11 VARCHAR2(11 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	qtydispensed VARCHAR2(255 CHAR) NULL,
	rxadministrationid VARCHAR2(100 CHAR) NULL,
	rxnorm_code VARCHAR2(25 CHAR) NULL,
	rxorderid VARCHAR2(100 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_rxorder', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_rxorder (
	active_med_flag VARCHAR2(1 CHAR) NULL,
	allowedamount NUMBER  NULL,
	altmedcode VARCHAR2(255 CHAR) NULL,
	charge NUMBER  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	coinsurance_amt NUMBER  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	copay_amt NUMBER  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dcc VARCHAR2(16 CHAR) NULL,
	deductable_amt NUMBER  NULL,
	denied_flag VARCHAR2(249 CHAR) NULL,
	discontinue_dt TIMESTAMP(3)  NULL,
	discontinuereason VARCHAR2(250 CHAR) NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	expire_dt TIMESTAMP(3)  NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	fillnum NUMBER (4) NULL,
	formulary_indicator VARCHAR2(249 CHAR) NULL,
	generic_status VARCHAR2(249 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hts_generic VARCHAR2(100 CHAR) NULL,
	hts_generic_ext VARCHAR2(100 CHAR) NULL,
	hum_gen_med_key VARCHAR2(80 CHAR) NULL,
	hum_med_key VARCHAR2(16 CHAR) NULL,
	issue_dtm TIMESTAMP(3)  NULL,
	localdaw VARCHAR2(225 CHAR) NULL,
	localdaysupplied NUMBER  NULL,
	localdescription VARCHAR2(1000 CHAR) NULL,
	localdescription_phi VARCHAR2(1000 CHAR) NULL,
	localdischargemedflg VARCHAR2(255 CHAR) NULL,
	localdosefreq VARCHAR2(255 CHAR) NULL,
	localdoseunit VARCHAR2(255 CHAR) NULL,
	localduration VARCHAR2(255 CHAR) NULL,
	localform VARCHAR2(255 CHAR) NULL,
	localgenericdesc VARCHAR2(255 CHAR) NULL,
	localgpi VARCHAR2(255 CHAR) NULL,
	localinfusionduration VARCHAR2(255 CHAR) NULL,
	localinfusionrate VARCHAR2(255 CHAR) NULL,
	localinfusionvolume VARCHAR2(255 CHAR) NULL,
	localmedcode VARCHAR2(100 CHAR) NULL,
	localndc VARCHAR2(255 CHAR) NULL,
	localproviderid VARCHAR2(255 CHAR) NULL,
	localqtyofdoseunit VARCHAR2(255 CHAR) NULL,
	localroute VARCHAR2(255 CHAR) NULL,
	localstrengthperdoseunit VARCHAR2(255 CHAR) NULL,
	localstrengthunit VARCHAR2(255 CHAR) NULL,
	localtotaldose VARCHAR2(255 CHAR) NULL,
	map_used VARCHAR2(16 CHAR) NULL,
	mappedgpi VARCHAR2(14 CHAR) NULL,
	mappedgpi_conf NUMBER (1) NULL,
	mappedndc VARCHAR2(11 CHAR) NULL,
	mappedndc_conf NUMBER (1) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	ndc11 VARCHAR2(11 CHAR) NULL,
	network_paid_status VARCHAR2(30 CHAR) NULL,
	orderstatus VARCHAR2(255 CHAR) NULL,
	ordertype VARCHAR2(255 CHAR) NULL,
	ordervsprescription VARCHAR2(1 CHAR) NULL,
	paidamount NUMBER  NULL,
	pat_liability_amt NUMBER  NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	pseudo_flag VARCHAR2(249 CHAR) NULL,
	quantityperfill VARCHAR2(200 CHAR) NULL,
	rxid VARCHAR2(100 CHAR) NOT NULL,
	rxnorm_code VARCHAR2(25 CHAR) NULL,
	signature VARCHAR2(4000 CHAR) NULL,
	venue VARCHAR2(8 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_rx_patient_reported', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_rx_patient_reported (
	action_dt TIMESTAMP(3)  NULL,
	active_med_flag VARCHAR2(1 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	dcc VARCHAR2(16 CHAR) NULL,
	discontinue_dt TIMESTAMP(3)  NULL,
	discontinuereason VARCHAR2(250 CHAR) NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hts_generic VARCHAR2(100 CHAR) NULL,
	hts_generic_ext VARCHAR2(100 CHAR) NULL,
	hum_gen_med_key VARCHAR2(80 CHAR) NULL,
	hum_med_key VARCHAR2(16 CHAR) NULL,
	localactioncode VARCHAR2(255 CHAR) NULL,
	localcategorycode VARCHAR2(255 CHAR) NULL,
	localdoseunit VARCHAR2(255 CHAR) NULL,
	localdrugdescription VARCHAR2(1000 CHAR) NULL,
	localform VARCHAR2(255 CHAR) NULL,
	localgpi VARCHAR2(255 CHAR) NULL,
	localmedcode VARCHAR2(100 CHAR) NULL,
	localndc VARCHAR2(255 CHAR) NULL,
	localproviderid VARCHAR2(255 CHAR) NULL,
	localqtyofdoseunit VARCHAR2(255 CHAR) NULL,
	localroute VARCHAR2(255 CHAR) NULL,
	localstrengthperdoseunit VARCHAR2(255 CHAR) NULL,
	localstrengthunit VARCHAR2(255 CHAR) NULL,
	localtotaldose VARCHAR2(255 CHAR) NULL,
	map_used VARCHAR2(16 CHAR) NULL,
	mappedgpi VARCHAR2(14 CHAR) NULL,
	mappedndc VARCHAR2(11 CHAR) NULL,
	medreported_dt TIMESTAMP(3)  NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mstrprovid VARCHAR2(249 CHAR) NULL,
	ndc11 VARCHAR2(11 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	reportedmedid VARCHAR2(100 CHAR) NULL,
	rxnorm_code VARCHAR2(25 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_sre_cmrisksummary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_sre_cmrisksummary (
	age NUMBER (3) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cm_3mo_ip_prob NUMBER (13, 8) NULL,
	cm_3mo_ip_rel_risk NUMBER (13, 8) NULL,
	cm_3mo_risk NUMBER (9, 4) NULL,
	cm_anc_risk NUMBER (9, 4) NULL,
	cm_ed_prob NUMBER (13, 8) NULL,
	cm_ed_rel_risk NUMBER (13, 8) NULL,
	cm_enroll_length NUMBER (10, 0),
	cm_ip_prob NUMBER (13, 8) NULL,
	cm_ip_rel_risk NUMBER (13, 8) NULL,
	cm_ip_risk NUMBER (9, 4) NULL,
	cm_lab_risk NUMBER (13, 8) NULL,
	cm_op_risk NUMBER (9, 4) NULL,
	cm_partial_enroll VARCHAR2 (1 CHAR),
	cm_prof_risk NUMBER (9, 4) NULL,
	cm_risk NUMBER (13, 8) NULL,
	cm_rx_risk NUMBER (13, 8) NULL,
	database_version VARCHAR2(4 CHAR) NULL,
	demo_risk NUMBER (13, 8) NULL,
	error_status VARCHAR2(1 CHAR) NULL,
	gender VARCHAR2(1 CHAR) NULL,
	grouper_version VARCHAR2(4 CHAR) NULL,
	grouping_end_dt DATE  NULL,
	input_data_type VARCHAR2(1 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patient_id VARCHAR2(2 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_sre_marker_profile', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_sre_marker_profile (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	marker_id VARCHAR2(11 CHAR) NULL,
	marker_type VARCHAR2(4 CHAR) NULL,
	marker_value NUMBER (14, 8) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	patient_id VARCHAR2(2 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_treatment_administered', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_treatment_administered (
	administered_dtm TIMESTAMP(3)  NULL,
	administered_id VARCHAR2(255 CHAR) NULL,
	administered_prov_id VARCHAR2(100 CHAR) NULL,
	administered_quantity VARCHAR2(255 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(255 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	local_unit VARCHAR2(255 CHAR) NULL,
	localcode VARCHAR2(255 CHAR) NULL,
	master_hgprovid VARCHAR2(100 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	normalized_quantity VARCHAR2(255 CHAR) NULL,
	order_id VARCHAR2(249 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	std_unit_cui VARCHAR2(32 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_treatment_ordered', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_treatment_ordered (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(255 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	local_unit VARCHAR2(255 CHAR) NULL,
	localcode VARCHAR2(255 CHAR) NULL,
	master_hgprovid VARCHAR2(100 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	normalized_quantity VARCHAR2(255 CHAR) NULL,
	order_dtm TIMESTAMP(3)  NULL,
	order_id VARCHAR2(249 CHAR) NULL,
	order_prov_id VARCHAR2(100 CHAR) NULL,
	ordered_quantity VARCHAR2(255 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	std_unit_cui VARCHAR2(32 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_obstype_code', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_obstype_code (
	begin_range NUMBER  NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	conv_fact NUMBER  NULL,
	cui VARCHAR2(50 CHAR) NULL,
	datasrc VARCHAR2(255 CHAR) NULL,
	datatype VARCHAR2(255 CHAR) NULL,
	end_range NUMBER  NULL,
	exclude_flag CHAR(1) NULL,
	foam_restriction VARCHAR2(255 CHAR) NULL,
	function_applied VARCHAR2(255 CHAR) NULL,
	localunit VARCHAR2(1000 CHAR) NULL,
	localunit_cui VARCHAR2(50 CHAR) NULL,
	obscode VARCHAR2(255 CHAR) NULL,
	obsconvfactor NUMBER  NULL,
	obsregex VARCHAR2(1000 CHAR) NULL,
	obstype VARCHAR2(255 CHAR) NULL,
	obstype_std_units VARCHAR2(50 CHAR) NULL,
	obstype_std_units_desc VARCHAR2(100 CHAR) NULL,
	prefix CHAR(1) NULL,
	round_prec NUMBER  NULL,
	zero_to_null CHAR(1) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_treatment_type_code', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_treatment_type_code (
	begin_range NUMBER  NULL,
	client_id VARCHAR2(7 CHAR) NOT  NULL,
	conv_fact NUMBER  NULL,
	data_type VARCHAR2(10 CHAR) NULL,
	end_range NUMBER  NULL,
	function_applied VARCHAR2(255 CHAR) NULL,
	local_code VARCHAR2(255 CHAR) NOT NULL,
	local_unit VARCHAR2(20 CHAR) NULL,
	localunit_cui VARCHAR2(50 CHAR) NULL,
	round_prec NUMBER  NULL,
	tmttype_std_units_desc VARCHAR2(100 CHAR) NULL,
	treatment_type_cui VARCHAR2(50 CHAR) NULL,
	treatment_type_std_units VARCHAR2(50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_appt_location', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_appt_location (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	locationid VARCHAR2(249 CHAR) NOT NULL,
	locationname VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_med_dcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_med_dcc (
	client_ds_id NUMBER (10) NOT NULL,
	client_id VARCHAR2(16 CHAR)  NULL,
	datasrc VARCHAR2(255 CHAR) NOT NULL,
	dcc VARCHAR2(255 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	hts_generic VARCHAR2(255 CHAR) NULL,
	hts_generic_ext VARCHAR2(255 CHAR) NULL,
	hts_gpi VARCHAR2(255 CHAR) NULL,
	hum_gen_med_key VARCHAR2(255 CHAR) NULL,
	hum_med_key VARCHAR2(255 CHAR) NULL,
	localmedcode VARCHAR2(255 CHAR) NOT NULL,
	map_used VARCHAR2(255 CHAR) NULL,
	rxnorm_code VARCHAR2(249 CHAR) NULL,
	top_ndc VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_provider', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_provider (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	credentials VARCHAR2(255 CHAR) NULL,
	datasrc VARCHAR2(255 CHAR) NULL,
	dateofbirth DATE  NULL,
	emailaddress VARCHAR2(255 CHAR) NULL,
	first_name VARCHAR2(255 CHAR) NULL,
	gender VARCHAR2(255 CHAR) NULL,
	last_name VARCHAR2(255 CHAR) NULL,
	localclassification VARCHAR2(200 CHAR) NULL,
	localprimaryspecialty VARCHAR2(100 CHAR) NULL,
	localproviderid VARCHAR2(100 CHAR) NOT NULL,
	mappedcredentialtype VARCHAR2(50 CHAR) NULL,
	master_hgprovid NUMBER  NULL,
	middle_name VARCHAR2(255 CHAR) NULL,
	npi VARCHAR2(255 CHAR) NULL,
	primaryfacilityid VARCHAR2(255 CHAR) NULL,
	providerexclusionflag CHAR(1) NULL,
	providername VARCHAR2(255 CHAR) NULL,
	suffix VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_provider_contact', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_provider_contact (
	address_line1 VARCHAR2(250 CHAR) NULL,
	address_line2 VARCHAR2(250 CHAR) NULL,
	city VARCHAR2(250 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	email_address VARCHAR2(255 CHAR) NULL,
	local_contact_type VARCHAR2(255 CHAR) NULL,
	local_provider_id VARCHAR2(249 CHAR) NOT NULL,
	mapped_contact_type VARCHAR2(50 CHAR) NULL,
	master_hgprovid NUMBER  NULL,
	state VARCHAR2(250 CHAR) NULL,
	update_dt DATE  NOT NULL,
	work_phone VARCHAR2(50 CHAR) NULL,
	zipcode VARCHAR2(50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_provider_identifier', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_provider_identifier (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	id_type VARCHAR2(255 CHAR) NOT NULL,
	id_value VARCHAR2(255 CHAR) NOT NULL,
	master_hgprovid NUMBER (18) NULL,
	provider_id VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_provider_master', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_provider_master (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	emailaddress VARCHAR2(255 CHAR) NULL,
	localclassification VARCHAR2(200 CHAR) NULL,
	localprimaryspecialty VARCHAR2(255 CHAR) NULL,
	mappedcredentialtype VARCHAR2(50 CHAR) NULL,
	master_hgprovid VARCHAR2(249 CHAR) NULL,
	match_cnt NUMBER  NULL,
	npi VARCHAR2(10 CHAR) NULL,
	primaryfacilityid VARCHAR2(255 CHAR) NULL,
	providerexclusionflag VARCHAR2(1 CHAR) NULL,
	providername VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_contact_summary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_contact_summary (
	address_line1 VARCHAR2(250 CHAR) NULL,
	address_line2 VARCHAR2(250 CHAR) NULL,
	city VARCHAR2(250 CHAR) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	email_address VARCHAR2(255 CHAR) NULL,
	local_contact_type VARCHAR2(255 CHAR) NULL,
	mapped_contact_type VARCHAR2(50 CHAR) NULL,
	master_hgprovid NUMBER  NULL,
	npi VARCHAR2(255 CHAR) NULL,
	specialty_code VARCHAR2(100 CHAR) NULL,
	specialty_name VARCHAR2(255 CHAR) NULL,
	state VARCHAR2(250 CHAR) NULL,
	work_phone VARCHAR2(50 CHAR) NULL,
	zipcode VARCHAR2(50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_service_line', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_service_line (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	localservicecode VARCHAR2(250 CHAR) NOT NULL,
	servicecodedesc VARCHAR2(250 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_employer', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_employer (
	bussegment VARCHAR2(255 CHAR) NULL,
	client_ds_id NUMBER  NULL,
	client_id VARCHAR2(16 CHAR)  NULL,
	dts_version NUMBER  NOT NULL,
	employeraccountid VARCHAR2(255 CHAR) NULL,
	employeraccountiddescription VARCHAR2(255 CHAR) NULL,
	highemployeraccount VARCHAR2(255 CHAR) NULL,
	highemployeraccountdescription VARCHAR2(255 CHAR) NULL,
	industry VARCHAR2(255 CHAR) NULL,
	mapsource VARCHAR2(255 CHAR) NULL,
	midemployeraccount VARCHAR2(255 CHAR) NULL,
	midemployeraccountdescription VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_med_form', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_med_form (
	client_id VARCHAR2(50 CHAR) NOT  NULL,
	dts_version NUMBER  NOT NULL,
	hts_code VARCHAR2(50 CHAR) NOT NULL,
	localcode VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_cmsnpi', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_cmsnpi (
	employer_id_num VARCHAR2(10 CHAR) NULL,
	entity_type_code VARCHAR2(2 CHAR) NULL,
	last_update_dt DATE  NULL,
	npi VARCHAR2(15 CHAR)  NULL,
	npi_deactivation_dt DATE  NULL,
	npi_deactivation_reason_code VARCHAR2(50 CHAR) NULL,
	npi_reactivation_dt DATE  NULL,
	prov_bus_mail_addr_city VARCHAR2(50 CHAR) NULL,
	prov_bus_mail_addr_countrycode VARCHAR2(5 CHAR) NULL,
	prov_bus_mail_addr_postalcode VARCHAR2(20 CHAR) NULL,
	prov_bus_mail_addr_state VARCHAR2(50 CHAR) NULL,
	prov_credential VARCHAR2(50 CHAR) NULL,
	prov_first_line_bus_mail_addr VARCHAR2(80 CHAR) NULL,
	prov_firstname VARCHAR2(50 CHAR) NULL,
	prov_lastname_legalname VARCHAR2(100 CHAR) NULL,
	prov_middle_name VARCHAR2(50 CHAR) NULL,
	prov_name_prefix VARCHAR2(10 CHAR) NULL,
	prov_name_suffix VARCHAR2(10 CHAR) NULL,
	prov_org_name_legal_bus_name VARCHAR2(100 CHAR) NULL,
	prov_oth_credential VARCHAR2(50 CHAR) NULL,
	prov_second_line_bus_mail_addr VARCHAR2(80 CHAR) NULL,
	replacement_npi VARCHAR2(15 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_hcpcs_specialty_med', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_hcpcs_specialty_med (
	dcc VARCHAR2(26 CHAR) NULL,
	long_description VARCHAR2(256 CHAR) NULL,
	procedure_code VARCHAR2(26 CHAR)  NULL,
	specialty_ind VARCHAR2(5 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_ub04_rev_codes', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_ub04_rev_codes (
	long_desc VARCHAR2 (500 CHAR),
	rev_code VARCHAR2(249 CHAR)  NULL,
	short_desc VARCHAR2(100 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_pat_type_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_pat_type_tos (
	dts_version NUMBER  NOT NULL,
	inst_prof VARCHAR2(255 CHAR) NOT NULL,
	patient_type_cui VARCHAR2(8 CHAR) NOT  NULL,
	tos_i_5 NUMBER (9) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ref_imap_tos_proc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ref_imap_tos_proc (
	anes_tos VARCHAR2(249 CHAR) NULL,
	map_code VARCHAR2(249 CHAR)  NULL,
	op_tos VARCHAR2(249 CHAR) NULL,
	pcc_psc_cat2_id VARCHAR2(249 CHAR) NULL,
	pcc_type VARCHAR2(249 CHAR) NULL,
	prof_tos VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_v_provider_master', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_v_provider_master (
	client_id VARCHAR2 (16 CHAR),
	localprimaryspecialty VARCHAR2 (255 CHAR),
	mappedcredentialtype VARCHAR2 (50 CHAR),
	npi VARCHAR2 (10 CHAR),
	npiprimarycode VARCHAR2 (20 CHAR),
	npiprimaryspecialty VARCHAR2 (8 CHAR),
	npiprimspecgroup VARCHAR2 (255 CHAR),
	npiprimspecgroupname VARCHAR2 (100 CHAR),
	npiprimspecname VARCHAR2 (100 CHAR),
	primaryfacilityid VARCHAR2 (255 CHAR),
	primaryspecialty VARCHAR2 (50 CHAR),
	primspecgroupname VARCHAR2 (100 CHAR),
	primspecgrp VARCHAR2 (255 CHAR),
	primspecname VARCHAR2 (100 CHAR),
	prov_id VARCHAR2 (20 CHAR),
	providerexclusionflag VARCHAR2 (1 CHAR),
	providername VARCHAR2 (255 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_contract_rollup', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_contract_rollup (
	client_ds_id NUMBER  NULL,
	client_id VARCHAR2(16 CHAR) NULL,
	contract_desc VARCHAR2(150 CHAR) NULL,
	contract_hier NUMBER  NULL,
	contract_id VARCHAR2(30 CHAR)  NULL,
	contract_lv1 VARCHAR2(30 CHAR) NULL,
	contract_lv1_desc VARCHAR2(150 CHAR) NULL,
	contract_lv2 VARCHAR2(30 CHAR) NULL,
	contract_lv2_desc VARCHAR2(150 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patient_grp_mpi_diff', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patient_grp_mpi_diff (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	datasrc VARCHAR2(249 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	mpi_status VARCHAR2(32 CHAR) NULL,
	new_mpi VARCHAR2(32 CHAR) NULL,
	old_mpi VARCHAR2(32 CHAR) NULL,
	patientid VARCHAR2(249 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_network_paid_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_network_paid_status (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	dts_version NUMBER  NOT NULL,
	localcode VARCHAR2(255 CHAR) NOT NULL,
	mappedvalue VARCHAR2(10 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_prov_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_prov_status (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	dts_version NUMBER  NOT NULL,
	localcode VARCHAR2(255 CHAR) NOT NULL,
	mappedvalue VARCHAR2(10 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_risk_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_risk_status (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	dts_version NUMBER  NOT NULL,
	localcode VARCHAR2(255 CHAR) NOT NULL,
	mappedvalue VARCHAR2(10 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_netwrk_paid_status_rollup', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_netwrk_paid_status_rollup (
	client_ds_id NUMBER  NULL,
	client_id VARCHAR2(16 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NULL,
	network_paid_status VARCHAR2(30 CHAR)  NULL,
	network_paid_status_desc VARCHAR2(150 CHAR) NULL,
	network_paid_status_lv1 VARCHAR2(30 CHAR) NULL,
	network_paid_status_lv1_desc VARCHAR2(150 CHAR) NULL,
	network_paid_status_lv2 VARCHAR2(30 CHAR) NULL,
	network_paid_status_lv2_desc VARCHAR2(150 CHAR) NULL,
	network_paid_status_rollup VARCHAR2(1 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_affil', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_affil (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	eff_date DATE  NULL,
	end_date DATE  NULL,
	localproviderid VARCHAR2(255 CHAR) NULL,
	master_hgprovid NUMBER  NULL,
	prov_affil_id VARCHAR2(30 CHAR)  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_affil_rollup', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_affil_rollup (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	prov_affil_desc VARCHAR2(150 CHAR) NULL,
	prov_affil_id VARCHAR2(30 CHAR)  NULL,
	prov_affil_lv1 VARCHAR2(30 CHAR) NULL,
	prov_affil_lv1_desc VARCHAR2(150 CHAR) NULL,
	prov_affil_lv2 VARCHAR2(30 CHAR) NULL,
	prov_affil_lv2_desc VARCHAR2(150 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_status_rollup', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_status_rollup (
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	prov_status_desc VARCHAR2(150 CHAR) NULL,
	prov_status_id VARCHAR2(30 CHAR)  NULL,
	prov_status_lv1 VARCHAR2(30 CHAR) NULL,
	prov_status_lv1_desc VARCHAR2(150 CHAR) NULL,
	prov_status_lv2 VARCHAR2(30 CHAR) NULL,
	prov_status_lv2_desc VARCHAR2(150 CHAR) NULL,
	prov_status_rollup VARCHAR2(1 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_risk_status_rollup', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_risk_status_rollup (
	at_risk_rollup VARCHAR2(1 CHAR) NULL,
	at_risk_status VARCHAR2(30 CHAR)  NULL,
	at_risk_status_desc VARCHAR2(150 CHAR) NULL,
	at_risk_status_lv1 VARCHAR2(30 CHAR) NULL,
	at_risk_status_lv1_desc VARCHAR2(150 CHAR) NULL,
	at_risk_status_lv2 VARCHAR2(30 CHAR) NULL,
	at_risk_status_lv2_desc VARCHAR2(150 CHAR) NULL,
	client_ds_id NUMBER  NULL,
	client_id VARCHAR2(16 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_zcm_micro_proc_pattern', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_zcm_micro_proc_pattern (
	"PRIORITY" NUMBER (10, 0),
	client_id VARCHAR2(255 CHAR)  NULL,
	cui VARCHAR2(8 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	txt_pattern VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ebm_eventrule', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ebm_eventrule (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	event NUMBER (4) NULL,
	file_processing_month DATE  NULL,
	grp_mpi VARCHAR2(32 CHAR) NULL,
	report_case_id NUMBER (6) NULL,
	report_rule_id NUMBER (9) NULL,
	status_flg VARCHAR2(1 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ebm_eventruleservice', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ebm_eventruleservice (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	event NUMBER (4) NULL,
	file_processing_month DATE  NULL,
	grp_mpi VARCHAR2(32 CHAR) NULL,
	report_case_id NUMBER (6) NULL,
	report_rule_id NUMBER (9) NULL,
	uniq_rec_id VARCHAR2(28 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_ebm_eventstatement', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_ebm_eventstatement (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	event NUMBER (4) NULL,
	file_processing_month DATE  NULL,
	grp_mpi VARCHAR2(32 CHAR) NULL,
	report_case_id NUMBER (6) NULL,
	report_rule_id NUMBER (9) NULL,
	statement_cd VARCHAR2(1 CHAR) NULL,
	status_flg VARCHAR2(1 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_formulary_indicator', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_formulary_indicator (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(8 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	localcode VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_generic_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_generic_status (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cui VARCHAR2(8 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	localcode VARCHAR2(255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_cds_flg_bit', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_cds_flg_bit (
	bit_name VARCHAR2 (200 CHAR),
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_cds_source_type_bit', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_cds_source_type_bit (
	client_id VARCHAR2 (16 CHAR),
	source_type_flg NUMBER (10, 0),
	source_type_flg_name VARCHAR2 (7 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_insurance_last', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_insurance_last (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	lob_cui VARCHAR2 (8 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	no_enc_ind NUMBER (1) NOT NULL,
	payer_cui VARCHAR2 (8 CHAR) NOT NULL,
	plancode VARCHAR2 (255 CHAR),
	planname VARCHAR2 (255 CHAR),
	primary_ind NUMBER (10, 0),
	yr_month NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_insurance_primary', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_insurance_primary (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	last_ind NUMBER (1) NOT NULL,
	lob_cui VARCHAR2 (8 CHAR) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	no_enc_ind NUMBER (1) NOT NULL,
	payer_cui VARCHAR2 (8 CHAR) NOT NULL,
	plancode VARCHAR2 (255 CHAR),
	planname VARCHAR2 (255 CHAR),
	yr_month NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_month', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_month (
	month_id INTEGER NOT NULL,
	month_name VARCHAR2 (10 CHAR),
	month_short_name VARCHAR2 (10 CHAR),
	month_year_name VARCHAR2 (20 CHAR),
	month_year_short_name VARCHAR2 (20 CHAR),
	prev_month_id NUMBER (10, 0),
	prev_quarter_month_id NUMBER (10, 0),
	prev_year_month_id NUMBER (10, 0),
	quarter_id INTEGER NOT NULL,
	year_id INTEGER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_year', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_year (
	prev_year_id NUMBER (10, 0),
	year_id INTEGER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_month_ytd', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_month_ytd (
	month_id INTEGER NOT NULL,
	ytd_month_id INTEGER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_tos_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_tos_type (
	patient_type_cui VARCHAR2 (8 CHAR),
	pos VARCHAR2 (249 CHAR),
	spec_code NUMBER (10, 0),
	tos_map_type VARCHAR2 (249 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_proc_group', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_proc_group (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER (19, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	principal_ind NUMBER NOT NULL,
	proc_dtm TIMESTAMP(3) NOT NULL,
	proc_group_id NUMBER NOT NULL,
	prov_id VARCHAR2(20 CHAR) NOT NULL,
	sensitive_cat_id NUMBER NOT NULL,
	sensitive_ind NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_proc_group', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_proc_group (
	description VARCHAR2(255 CHAR) NOT NULL,
	external_code VARCHAR2(8 CHAR) NOT NULL,
	proc_group_id NUMBER(10) NOT NULL,
	proc_group_set VARCHAR2(8 CHAR) NOT NULL,
	sensitive_cat_id NUMBER(10) NOT NULL,
	sensitive_ind NUMBER(10) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_proc_group', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_proc_group (
	code_type VARCHAR2 (8 CHAR),
	proc_cd VARCHAR2 (255 CHAR),
	proc_group_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_prov_attrib_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_prov_attrib_precur (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR),
	domestic_ind NUMBER (10, 0),
	elig_cds_id NUMBER (10, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_type VARCHAR2 (255 CHAR),
	precursor_value VARCHAR2 (255 CHAR),
	prov_attrib_precursor_id NUMBER NOT NULL,
	prov_id VARCHAR2 (20 CHAR) NOT NULL,
	yr_month NUMBER (22) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_prov_attrib', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_prov_attrib (
	client_id VARCHAR2 (16 CHAR),
	deciding_precursor_id NUMBER (19, 0),
	domestic_ind NUMBER (10, 0),
	elig_cds_id NUMBER (10, 0),
	most_recent_ind NUMBER (10, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	prov_attrib_id NUMBER (19, 0),
	prov_id VARCHAR2 (20 CHAR) NOT NULL,
	yr_month NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_immunization', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_immunization (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	code_type VARCHAR(8 CHAR) NOT NULL,
	imm_cd VARCHAR(255 CHAR) NOT NULL,
	imm_dt DATE NOT NULL,
	immunization_ind NUMBER (1) NOT NULL,
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	pat_reported_ind NUMBER (1) NOT NULL,
	procedure_ind NUMBER (1) NOT NULL,
	rxadmin_ind NUMBER (1) NOT NULL,
	rxorder_ind NUMBER (1) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_immunization', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_immunization (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	code_type VARCHAR(8 CHAR) NOT NULL,
	imm_cd VARCHAR(20 CHAR) NOT NULL,
	imm_dt DATE NOT NULL,
	immunization_id NUMBER NOT NULL,
	immunization_ind NUMBER (1) NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	pat_reported_ind NUMBER (1) NOT NULL,
	procedure_ind NUMBER (1) NOT NULL,
	rxadmin_ind NUMBER (1) NOT NULL,
	rxorder_ind NUMBER (1) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_diag', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_diag (
	code_desc VARCHAR2 (500 CHAR),
	code_name VARCHAR2 (100 CHAR) NOT NULL,
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	diag_cd VARCHAR2 (20 CHAR) NOT NULL,
	icd_version NUMBER (10, 0),
	icddx VARCHAR2 (20 CHAR),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_proc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_proc (
	code_desc VARCHAR2 (500 CHAR),
	code_name VARCHAR2 (100 CHAR) NOT NULL,
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	proc_cd VARCHAR2 (20 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (1) NOT NULL,
	specialty_med_ind NUMBER (1) DEFAULT 0 NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_dcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_dcc (
	dcc VARCHAR2 (5 CHAR) NOT NULL,
	dcc_name VARCHAR2 (150 CHAR) NOT NULL,
	harmful_geriatric_med NUMBER (10, 0),
	pcc VARCHAR2 (3 CHAR) NOT NULL,
	pcc_name VARCHAR2 (120 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (1) NOT NULL,
	specialty_ind NUMBER (1) DEFAULT 0 NOT NULL,
	tcc VARCHAR2 (2 CHAR) NOT NULL,
	tcc_name VARCHAR2 (150 CHAR) NOT NULL,
	vaccine_ind NUMBER (1) DEFAULT 0 NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_pcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_pcc (
	pcc VARCHAR2 (3 CHAR) NOT NULL,
	pcc_name VARCHAR2 (120 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL,
	tcc VARCHAR2 (2 CHAR) NOT NULL,
	tcc_name VARCHAR2 (150 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_tcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_tcc (
	tcc VARCHAR2 (2 CHAR) NOT NULL,
	tcc_name VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_event_readmission', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_event_readmission (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	days_to_readmit NUMBER (3),
	elig_30_ind NUMBER (1) NOT NULL,
	elig_60_ind NUMBER (1) NOT NULL,
	elig_90_ind NUMBER (1) NOT NULL,
	elig_days NUMBER (3) NOT NULL,
	event_set_cd VARCHAR2 (2 CHAR) NOT NULL,
	idx_apr_drg_id NUMBER (6),
	idx_apr_drg_sensitive_ind NUMBER NOT NULL,
	idx_cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	idx_disch_prov_id VARCHAR2 (20 CHAR),
	idx_drg_id NUMBER (6),
	idx_drg_sensitive_ind NUMBER NOT NULL,
	idx_end_dtm DATE NOT NULL,
	idx_event_id NUMBER NOT NULL,
	idx_hosp_site_id NUMBER,
	idx_prindx VARCHAR2 (8 CHAR),
	idx_prindx_codetype VARCHAR2 (10 CHAR),
	idx_prindx_sensitive_ind NUMBER (1) NOT NULL,
	idx_prinpx VARCHAR2 (7 CHAR),
	idx_prinpx_codetype VARCHAR2 (10 CHAR),
	idx_prinpx_sensitive_ind NUMBER (1) NOT NULL,
	idx_prov_id VARCHAR2 (20 CHAR),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	readm_30_ind NUMBER (1) NOT NULL,
	readm_60_ind NUMBER (1) NOT NULL,
	readm_90_ind NUMBER (1) NOT NULL,
	readm_apr_drg_id NUMBER (6),
	readm_apr_drg_sensitive_ind NUMBER NOT NULL,
	readm_cds_grp VARCHAR2 (4000 CHAR),
	readm_drg_id NUMBER (6),
	readm_drg_sensitive_ind NUMBER NOT NULL,
	readm_event_id NUMBER,
	readm_hosp_site_id NUMBER,
	readm_prindx VARCHAR2 (8 CHAR),
	readm_prindx_codetype VARCHAR2 (10 CHAR),
	readm_prindx_sensitive_ind NUMBER (1),
	readm_prov_id VARCHAR2 (20 CHAR),
	readm_start_dtm DATE,
	readmission_type_cui VARCHAR2 (8 CHAR) NOT NULL,
	sensitive_ind NUMBER NOT NULL
	) PARTITION BY LIST(readmission_type_cui) (PARTITION P_CH000000 VALUES (''CH000000''))
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_precursor_grp_mth', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_precursor_grp_mth (
	client_id VARCHAR2 (16 CHAR),
	max_dt TIMESTAMP,
	min_dt TIMESTAMP,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	precursor_domain VARCHAR2 (255 CHAR),
	precursor_grp_id NUMBER (10, 0),
	precursor_id NUMBER (10, 0),
	precursor_type VARCHAR2 (255 CHAR),
	precursor_value VARCHAR2 (255 CHAR),
	sensitive_ind NUMBER (10, 0),
	yr_month NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_precursor_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_precursor_grp (
	client_id VARCHAR2 (16 CHAR),
	max_dt TIMESTAMP,
	min_dt TIMESTAMP,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_cds_grp VARCHAR2 (4000 CHAR),
	precursor_flg NUMBER (19, 0),
	precursor_grp_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_pat_allergy', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_pat_allergy (
	allergen_key VARCHAR2 (25 CHAR),
	allergencd_cui VARCHAR2 (8 CHAR),
	allergentype_cui VARCHAR2 (8 CHAR),
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	clinical_event_id NUMBER,
	clinical_evt_key NUMBER,
	dcc VARCHAR2 (5 CHAR),
	inferred_ind NUMBER (1) DEFAULT 0 NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	onset_dt DATE NOT NULL,
	pcc VARCHAR2 (3 CHAR),
	sensitive_ind NUMBER (1) DEFAULT 0 NOT NULL
	) PARTITION BY HASH(mpi) (PARTITION P_01, PARTITION P_02, PARTITION P_03, PARTITION P_04, PARTITION P_05, PARTITION P_06, PARTITION P_07, PARTITION P_08)
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_evt_measure_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_evt_measure_precur (
	client_id VARCHAR2 (16 CHAR),
	event_dt TIMESTAMP,
	event_id NUMBER (19, 0),
	event_seq NUMBER (10, 0),
	event_set VARCHAR2 (16 CHAR),
	measure_id NUMBER (10, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_cds_grp VARCHAR2 (4000 CHAR),
	precursor_domain VARCHAR2 (255 CHAR),
	precursor_dt TIMESTAMP,
	precursor_id NUMBER (10, 0),
	precursor_type VARCHAR2 (255 CHAR),
	precursor_value VARCHAR2 (255 CHAR),
	sensitive_ind NUMBER (10, 0),
	timeframe_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_pat_evt_measure_precur_ex', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_pat_evt_measure_precur_ex (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	event_dt TIMESTAMP,
	event_id NUMBER (19, 0),
	event_seq NUMBER (10, 0),
	event_set VARCHAR2 (16 CHAR),
	measure_id NUMBER NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	precursor_cds_grp VARCHAR2 (4000 CHAR),
	precursor_domain VARCHAR2 (255 CHAR),
	precursor_dt TIMESTAMP NOT NULL,
	precursor_id NUMBER NOT NULL,
	precursor_type VARCHAR2 (255 CHAR),
	precursor_value VARCHAR2 (255 CHAR),
	sensitive_ind NUMBER (1) NOT NULL,
	timeframe_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_evt_measure', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_evt_measure (
	care_gap_ind NUMBER (10, 0),
	client_id VARCHAR2 (16 CHAR),
	denominator NUMBER (10, 0),
	event_dt TIMESTAMP,
	event_id NUMBER (19, 0),
	event_seq NUMBER (10, 0),
	event_set VARCHAR2 (16 CHAR),
	measure_id NUMBER (10, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	numerator NUMBER (10, 0),
	precursor_flg NUMBER (19, 0),
	sensitive_ind NUMBER (10, 0),
	timeframe_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_evt_measure_ex', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_evt_measure_ex (
	care_gap_ind NUMBER (10, 0),
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	denominator NUMBER (10, 0),
	event_dt TIMESTAMP,
	event_id NUMBER (19, 0),
	event_seq NUMBER (10, 0),
	event_set VARCHAR2 (16 CHAR),
	measure_id NUMBER NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	numerator NUMBER (10, 0),
	precursor_flg NUMBER (19, 0),
	sensitive_ind NUMBER (1) NOT NULL,
	timeframe_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_measure_trend_rlp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_measure_trend_rlp (
	agg_denominator NUMBER NOT NULL,
	agg_lvl_1_title VARCHAR (100 CHAR) NOT NULL,
	agg_lvl_1_value VARCHAR2 (100 CHAR),
	agg_lvl_2_title VARCHAR2 (100 CHAR),
	agg_lvl_2_value VARCHAR2 (100 CHAR),
	agg_numerator NUMBER NOT NULL,
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	measure_id NUMBER NOT NULL,
	timeframe_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_clinical_event_cond', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_clinical_event_cond (
	bill_claim_ind NUMBER (10, 0),
	client_id VARCHAR2 (16 CHAR),
	clinical_event_id NUMBER (19, 0),
	condition_id NUMBER (10, 0),
	em_ind NUMBER (10, 0),
	em_narrow_ind NUMBER (10, 0),
	em_wide_ind NUMBER (10, 0),
	etg_qual_evt_ind NUMBER (10, 0),
	hosp_dx_ind NUMBER (10, 0),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	principal_dx_ind NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_zip', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_zip (
	cens_reg_desc VARCHAR2(30 CHAR) NOT NULL,
	cens_reg_id NUMBER (10, 0) NOT NULL,
	county_desc VARCHAR2(40 CHAR) NOT NULL,
	county_id NUMBER (10, 0) NOT NULL,
	latitude NUMBER (38, 10),
	longitude NUMBER (38, 10),
	median_hh_inc VARCHAR2 (50 CHAR),
	median_hh_inc_numeric NUMBER (10, 0),
	pct_bachelors_deg_or_more NUMBER (19, 4),
	pct_below_200pct_poverty NUMBER (19, 4),
	pct_eight_grade_or_less NUMBER (19, 4),
	pct_grade_sch_or_less NUMBER (19, 4),
	pct_some_hs_or_more NUMBER (19, 4),
	per_capita_inc VARCHAR2 (50 CHAR),
	per_capita_inc_numeric NUMBER (10, 0),
	state_cd VARCHAR2 (2 CHAR) NOT NULL,
	state_id NUMBER (3) NOT NULL,
	zip VARCHAR2 (10 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_attr_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_attr_ext (
	account_id VARCHAR2 (40 CHAR) NOT NULL,
	age_cat2 NUMBER (3) NOT NULL,
	at_risk_status_id VARCHAR2 (40 CHAR),
	cat_status NUMBER (3) NOT NULL,
	cat_status_cost3 NUMBER (3) NOT NULL,
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_1_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_2_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_3_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_4_id VARCHAR2 (40 CHAR) NOT NULL,
	new_mem_attr_id NUMBER NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	sex NUMBER (1) NOT NULL,
	zip VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_attr_con_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_attr_con_ext (
	account_id VARCHAR2 (40 CHAR),
	age_cat2 NUMBER (10, 0),
	at_risk_status_id VARCHAR2 (40 CHAR),
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	contract_id VARCHAR2 (40 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	mem_userdef_3_id VARCHAR2 (40 CHAR),
	mem_userdef_4_id VARCHAR2 (40 CHAR),
	new_mem_attr_con_id NUMBER (10, 0),
	pcp_assign VARCHAR2 (20 CHAR),
	product_id VARCHAR2 (40 CHAR),
	sex NUMBER (10, 0),
	zip VARCHAR2 (5 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_admits', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_admits (
	admit NUMBER,
	age_cat2 NUMBER (3) NOT NULL,
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	amt_req NUMBER,
	at_risk_status_id VARCHAR2 (40 CHAR),
	avoidable_admit_flag NUMBER,
	cat_status_cost3 NUMBER (3) NOT NULL,
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	end_year_mth_id NUMBER (10, 0),
	etg_id NUMBER (12),
	ia_time NUMBER (3) NOT NULL,
	los NUMBER,
	mem_userdef_1_id VARCHAR2 (40 CHAR) NOT NULL,
	network_paid_status_id VARCHAR2 (40 CHAR),
	new_mem_attr_id NUMBER (12) NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	poa VARCHAR2 (1 CHAR) NOT NULL,
	pqi NUMBER,
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	readmit_07 NUMBER (1) NOT NULL,
	readmit_30 NUMBER (1) NOT NULL,
	readmit_60 NUMBER (1) NOT NULL,
	readmit_90 NUMBER (1) NOT NULL,
	readmit_index_07 NUMBER (1) NOT NULL,
	readmit_index_30 NUMBER (1) NOT NULL,
	readmit_index_60 NUMBER (1) NOT NULL,
	readmit_index_90 NUMBER (1) NOT NULL,
	rrisk NUMBER (10, 4),
	sex NUMBER (1) NOT NULL,
	tos_i_5 NUMBER (12) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL,
	zip VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_admits', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_admits (
	admit NUMBER,
	age_cat2 NUMBER (3) NOT NULL,
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	amt_req NUMBER,
	at_risk_status_id VARCHAR2 (40 CHAR),
	avoidable_admit_flag NUMBER,
	cat_status_cost3 NUMBER (3) NOT NULL,
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	end_year_mth_id NUMBER (10, 0),
	etg_id NUMBER (12),
	ia_time NUMBER (3) NOT NULL,
	los NUMBER,
	mem_userdef_1_id VARCHAR2 (40 CHAR) NOT NULL,
	network_paid_status_id VARCHAR2 (40 CHAR),
	new_mem_attr_id NUMBER (12) NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	poa VARCHAR2 (1 CHAR) NOT NULL,
	pqi NUMBER,
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	readmit_07 NUMBER,
	readmit_30 NUMBER,
	readmit_60 NUMBER,
	readmit_90 NUMBER,
	readmit_index_07 NUMBER,
	readmit_index_30 NUMBER,
	readmit_index_60 NUMBER,
	readmit_index_90 NUMBER,
	sex NUMBER (1) NOT NULL,
	tos_i_5 NUMBER (12) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL,
	zip VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_ocu_pop_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_ocu_pop_costs (
	admit_source NUMBER (1) NOT NULL,
	admits NUMBER,
	age_cat2 NUMBER (3) NOT NULL,
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	amt_req NUMBER,
	at_risk_status_id VARCHAR2 (40 CHAR),
	cat_status_cost3 NUMBER (3) NOT NULL,
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	disrel NUMBER (12),
	drg_id VARCHAR2 (12 CHAR) NOT NULL,
	em_svc_util NUMBER,
	enc NUMBER,
	er_util NUMBER,
	ia_time NUMBER (3) NOT NULL,
	lab_util NUMBER,
	los NUMBER,
	mem_userdef_1_id VARCHAR2 (40 CHAR) NOT NULL,
	mri_util NUMBER,
	network_paid_status_id VARCHAR2 (40 CHAR) NOT NULL,
	new_mem_attr_id NUMBER NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	pos_i NUMBER (3),
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR) NOT NULL,
	prv_sp_4 NUMBER (12) NOT NULL,
	rad_util NUMBER,
	scripts NUMBER,
	sex NUMBER (1) NOT NULL,
	tos_i_5 NUMBER (12) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL,
	year_mth_pd NUMBER (3) NOT NULL,
	zip VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_ocu_pop_phm_costs', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_ocu_pop_phm_costs (
	age_cat2 NUMBER (3) NOT NULL,
	amt_eqv NUMBER,
	amt_np NUMBER,
	amt_pay NUMBER,
	amt_req NUMBER,
	at_risk_status_id VARCHAR2 (40 CHAR),
	cat_status_cost3 NUMBER (3) NOT NULL,
	channel NUMBER (12),
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	days_sup NUMBER,
	formulary NUMBER (3),
	gbo NUMBER (3) NOT NULL,
	generic NUMBER,
	ia_time NUMBER (3) NOT NULL,
	mem_userdef_1_id VARCHAR2 (40 CHAR) NOT NULL,
	ndc VARCHAR2 (11 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	new_mem_attr_id NUMBER NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	presc_prov VARCHAR2 (20 CHAR),
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	provider_status_id VARCHAR2 (40 CHAR),
	script_gen NUMBER,
	scripts NUMBER,
	sex NUMBER (1) NOT NULL,
	tos_i_5 NUMBER (12),
	year_mth_id NUMBER (3) NOT NULL,
	year_mth_pd NUMBER (3) NOT NULL,
	zip VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ocu_member', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ocu_member (
	age_cat2 NUMBER (3) NOT NULL,
	at_risk_status_id VARCHAR2 (40 CHAR),
	cat_status_cost3 NUMBER (3) NOT NULL,
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	ia_time NUMBER (3) NOT NULL,
	mem_userdef_1_id VARCHAR2 (40 CHAR) NOT NULL,
	mm NUMBER,
	mm_rx NUMBER,
	new_mem_attr_id NUMBER NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	retrorisk NUMBER,
	sex NUMBER (1) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL,
	zip VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ocu_member_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ocu_member_ext (
	age_tot NUMBER,
	mm NUMBER,
	mm_rx NUMBER,
	new_mem_attr_id NUMBER NOT NULL,
	prisk NUMBER,
	rrisk NUMBER,
	subscr_months NUMBER,
	year_mth_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_attr_member_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_attr_member_ext (
	account_id VARCHAR2 (40 CHAR) NOT NULL,
	age NUMBER (12) NOT NULL,
	age_cat2 NUMBER (3) NOT NULL,
	at_risk_status_id VARCHAR2 (40 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR) NOT NULL,
	biz_segment_id VARCHAR2 (40 CHAR) NOT NULL,
	cat_status NUMBER (3) NOT NULL,
	cat_status_cost3 NUMBER (3) NOT NULL,
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	contract_type_id VARCHAR2 (40 CHAR) NOT NULL,
	county_id NUMBER (12) NOT NULL,
	coverage_class NUMBER (3),
	coverage_status_id VARCHAR2 (40 CHAR) NOT NULL,
	ia_time NUMBER (3) NOT NULL,
	iatime_lag NUMBER (1) NOT NULL,
	industry NUMBER (3),
	last_enroll NUMBER (1) NOT NULL,
	med NUMBER (1) NOT NULL,
	med_qual NUMBER (1) NOT NULL,
	mem_eff_dt DATE NOT NULL,
	mem_end_dt DATE NOT NULL,
	mem_userdef_1_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_2_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_3_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_4_id VARCHAR2 (40 CHAR) NOT NULL,
	member VARCHAR2 (32 CHAR) NOT NULL,
	member_attr_id NUMBER (12) NOT NULL,
	mm NUMBER (19, 2) NOT NULL,
	mm_rx NUMBER (19, 2) NOT NULL,
	mpg_def_id NUMBER (12),
	new_mem_attr_id NUMBER NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	phm_qual NUMBER (1) NOT NULL,
	premium_tot NUMBER (19, 2),
	prisk NUMBER (10, 4),
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	rrisk NUMBER (10, 4),
	rx NUMBER (1) NOT NULL,
	sex NUMBER (1) NOT NULL,
	sub_eff_dt DATE NOT NULL,
	sub_end_dt DATE NOT NULL,
	subscr_months NUMBER (19, 2) NOT NULL,
	subscriber_id VARCHAR2 (32 CHAR) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL,
	zip VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_mem_attr_member_con_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_mem_attr_member_con_ext (
	account_id VARCHAR2 (40 CHAR) NOT NULL,
	age NUMBER (12) NOT NULL,
	age_cat2 NUMBER (3) NOT NULL,
	at_risk_status_id VARCHAR2 (40 CHAR),
	benefit_plan_id VARCHAR2 (40 CHAR) NOT NULL,
	biz_segment_id VARCHAR2 (40 CHAR) NOT NULL,
	cat_status NUMBER (3) NOT NULL,
	cat_status_cost3 NUMBER (3) NOT NULL,
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	contract_type_id VARCHAR2 (40 CHAR) NOT NULL,
	county_id NUMBER (12) NOT NULL,
	coverage_class NUMBER (3),
	coverage_status_id VARCHAR2 (40 CHAR) NOT NULL,
	ia_time NUMBER (3) NOT NULL,
	iatime_lag NUMBER (1) NOT NULL,
	industry NUMBER (3),
	last_enroll NUMBER (1) NOT NULL,
	med NUMBER (1) NOT NULL,
	med_qual NUMBER (1) NOT NULL,
	mem_eff_dt DATE NOT NULL,
	mem_end_dt DATE NOT NULL,
	mem_userdef_1_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_2_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_3_id VARCHAR2 (40 CHAR) NOT NULL,
	mem_userdef_4_id VARCHAR2 (40 CHAR) NOT NULL,
	member VARCHAR2 (32 CHAR) NOT NULL,
	member_attr_id NUMBER (12) NOT NULL,
	mm NUMBER (19, 2) NOT NULL,
	mm_rx NUMBER (19, 2) NOT NULL,
	mpg_def_id NUMBER (12),
	new_mem_attr_con_id NUMBER NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_imp VARCHAR2 (20 CHAR),
	phm_qual NUMBER (1) NOT NULL,
	premium_tot NUMBER (19, 2),
	prisk NUMBER (10, 4),
	product_id VARCHAR2 (40 CHAR) NOT NULL,
	rrisk NUMBER (10, 4),
	rx NUMBER (1) NOT NULL,
	sex NUMBER (1) NOT NULL,
	sub_eff_dt DATE NOT NULL,
	sub_end_dt DATE NOT NULL,
	subscr_months NUMBER (19, 2) NOT NULL,
	subscriber_id VARCHAR2 (32 CHAR) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL,
	zip VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_member_contract_recent', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_member_contract_recent (
	at_risk_status_id VARCHAR2 (40 CHAR),
	contract_id VARCHAR2 (40 CHAR),
	current_contract_ind NUMBER (1),
	current_ind NUMBER (10, 0),
	current_pcp_ind NUMBER (1),
	last_elig_yrmth NUMBER (3),
	last_pcp_yrmth NUMBER (3),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR) NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	pcp_name VARCHAR2 (249 CHAR),
	product_id VARCHAR2 (40 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_elig_contract', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_elig_contract (
	at_risk_status_id VARCHAR2 (40 CHAR),
	contract_id VARCHAR2 (40 CHAR) NOT NULL,
	med NUMBER (1) NOT NULL,
	mem_userdef_1_id VARCHAR2 (40 CHAR) NOT NULL,
	member VARCHAR2 (32 CHAR) NOT NULL,
	pcp_assign VARCHAR2 (20 CHAR),
	rx NUMBER (1) NOT NULL,
	year_mth_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_dict_month', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_dict_month (
	month_id INTEGER NOT NULL,
	month_name VARCHAR2 (10 CHAR),
	month_short_name VARCHAR2 (10 CHAR),
	month_year_name VARCHAR2 (20 CHAR),
	month_year_short_name VARCHAR2 (20 CHAR),
	prev_month_id NUMBER (10, 0),
	prev_quarter_month_id NUMBER (10, 0),
	prev_year_month_id NUMBER (10, 0),
	prior_year_mth_id NUMBER (10, 0),
	quarter_id INTEGER NOT NULL,
	year_id INTEGER NOT NULL,
	year_mth_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_measure_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_measure_precur (
	denominator_ind NUMBER NOT NULL,
	measure_id NUMBER NOT NULL,
	measure_precursor_desc VARCHAR2 (400 CHAR) NOT NULL,
	numerator_ind NUMBER NOT NULL,
	precursor_flg NUMBER NOT NULL,
	precursor_id NUMBER NOT NULL,
	sensitive_cat_id NUMBER(1) NOT NULL,
	sensitive_ind NUMBER(1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_member_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_member_detail (
	at_risk_status VARCHAR2(40 CHAR) NULL,
	benefitplan VARCHAR2(30 CHAR) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	contract_id VARCHAR2(40 CHAR) NULL,
	contracttype VARCHAR2(30 CHAR) NULL,
	coveragestatus VARCHAR2(30 CHAR) NULL,
	cust_mem_attr1 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr10 VARCHAR2 (255 CHAR),
	cust_mem_attr11 VARCHAR2 (255 CHAR),
	cust_mem_attr12 VARCHAR2 (255 CHAR),
	cust_mem_attr13 VARCHAR2 (255 CHAR),
	cust_mem_attr14 VARCHAR2 (255 CHAR),
	cust_mem_attr15 VARCHAR2 (255 CHAR),
	cust_mem_attr16 NUMBER (38, 10),
	cust_mem_attr17 NUMBER (38, 10),
	cust_mem_attr18 NUMBER (38, 10),
	cust_mem_attr19 NUMBER (38, 10),
	cust_mem_attr2 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr20 NUMBER (38, 10),
	cust_mem_attr3 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr4 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr5 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr6 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr7 VARCHAR2 (255 CHAR),
	cust_mem_attr8 VARCHAR2 (255 CHAR),
	cust_mem_attr9 VARCHAR2 (255 CHAR),
	date_of_death DATE  NULL,
	deceased_flag VARCHAR2(1 CHAR) NULL,
	dental_benefit VARCHAR2(1 CHAR) NULL,
	dob DATE  NULL,
	ecds_flag VARCHAR2(1 CHAR) NULL,
	eff_dt DATE  NOT NULL,
	emp_acct_id VARCHAR2(30 CHAR) NULL,
	employee_type VARCHAR2 (30 CHAR),
	employeraccountid VARCHAR2 (30 CHAR),
	end_dt DATE  NULL,
	ethnicity NUMBER  NULL,
	gender VARCHAR2(1 CHAR) NULL,
	healthplansource VARCHAR2(15 CHAR) NULL,
	hra_ind NUMBER (10, 0),
	hsa_ind NUMBER (10, 0),
	lineofbusinessid NUMBER  NULL,
	medical VARCHAR2(1 CHAR) NULL,
	mem_userdef_1 VARCHAR2 (30 CHAR),
	mem_userdef_2 VARCHAR2 (30 CHAR),
	mem_userdef_3 VARCHAR2 (30 CHAR),
	mem_userdef_4 VARCHAR2 (30 CHAR),
	mentalhealth VARCHAR2(1 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NOT NULL,
	other_language VARCHAR2(2 CHAR) NULL,
	pcp_affil VARCHAR2 (30 CHAR),
	pcpid VARCHAR2(20 CHAR) NULL,
	primary_coverage_flag VARCHAR2(1 CHAR) NULL,
	product_dtl_code VARCHAR2 (30 CHAR),
	productcode VARCHAR2(30 CHAR) NULL,
	race NUMBER  NULL,
	risk_type VARCHAR2 (30 CHAR),
	sec_member_id_1 VARCHAR2 (30 CHAR),
	sec_member_id_2 VARCHAR2 (30 CHAR),
	spoken_language VARCHAR2(2 CHAR) NULL,
	subscriberflag VARCHAR2(1 CHAR) NULL,
	subscriberid VARCHAR2(32 CHAR) NULL,
	written_language VARCHAR2(2 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_contract', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_contract (
	cds_grp VARCHAR2(4000 CHAR) NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT NULL,
	contract_desc VARCHAR2(150 CHAR) NULL,
	contract_hier NUMBER(10,0) NULL,
	contract_id VARCHAR2(40 CHAR) NOT NULL,
	contract_lv1 VARCHAR2(30 CHAR) NULL,
	contract_lv1_desc VARCHAR2(150 CHAR) NULL,
	contract_lv2 VARCHAR2(30 CHAR) NULL,
	contract_lv2_desc VARCHAR2(150 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_attribution_order', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_attribution_order (
	attrib_hier NUMBER (10, 0),
	client_id VARCHAR2 (16 CHAR),
	prov_attrib_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_patient_info', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_patient_info (
	addr_line_1 VARCHAR2 (100 CHAR),
	addr_line_2 VARCHAR2 (100 CHAR),
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	city VARCHAR2 (50 CHAR),
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	curr_account_id VARCHAR2 (40 CHAR),
	curr_at_risk_status_id VARCHAR2 (40 CHAR),
	curr_contract_id VARCHAR2 (40 CHAR),
	curr_payer_pcp VARCHAR2 (20 CHAR),
	curr_payer_pcp_affil_id VARCHAR2 (40 CHAR),
	death_ind_cui VARCHAR2 (8 CHAR),
	dob DATE,
	dod DATE,
	email VARCHAR2 (100 CHAR),
	employee_cat VARCHAR2 (255 CHAR),
	ethnicity_cui VARCHAR2 (8 CHAR),
	final_attrib_curr_ind NUMBER (1),
	final_attrib_prov_affil_id VARCHAR2 (40 CHAR),
	final_attrib_prov_id VARCHAR2 (20 CHAR),
	first_name VARCHAR2 (30 CHAR),
	gender_cui VARCHAR2 (8 CHAR),
	home_phone VARCHAR2 (30 CHAR),
	language_cui VARCHAR2 (8 CHAR),
	last_name VARCHAR2 (50 CHAR),
	marital_status_cui VARCHAR2 (8 CHAR),
	middle_name VARCHAR2 (30 CHAR),
	mobile_phone VARCHAR2 (30 CHAR),
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	mrace_infer_ind NUMBER (10, 0),
	mrn VARCHAR2 (20 CHAR),
	postal_cd VARCHAR2 (5 CHAR),
	race_cui VARCHAR2 (8 CHAR),
	religion VARCHAR2 (100 CHAR),
	sdoh_education_level VARCHAR2 (100 CHAR),
	sdoh_language_cd VARCHAR2 (100 CHAR),
	ssn VARCHAR2 (9 CHAR),
	state VARCHAR2 (2 CHAR),
	vip_cat VARCHAR2 (255 CHAR),
	work_phone VARCHAR2 (30 CHAR)
	) PARTITION BY RANGE(dob) (PARTITION P_pre1940 VALUES LESS THAN (to_date(''19400101'',''YYYYMMDD'')) ,PARTITION P_1940s VALUES LESS THAN (to_date(''19500101'',''YYYYMMDD'')) ,PARTITION P_1950s VALUES LESS THAN (to_date(''19600101'',''YYYYMMDD'')) ,PARTITION P_1960s VALUES LESS THAN (to_date(''19700101'',''YYYYMMDD'')) ,PARTITION P_1970s VALUES LESS THAN (to_date(''19800101'',''YYYYMMDD'')) ,PARTITION P_1980s VALUES LESS THAN (to_date(''19900101'',''YYYYMMDD'')) ,PARTITION P_1990s VALUES LESS THAN (to_date(''20000101'',''YYYYMMDD'')) ,PARTITION P_pre2020 VALUES LESS THAN (to_date(''20200101'',''YYYYMMDD'')) ,PARTITION P_MAX VALUES LESS THAN (MAXVALUE) )
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_encounter_grp_facility', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_encounter_grp_facility (
	admit_dtm TIMESTAMP,
	admitted_er VARCHAR2 (1 CHAR),
	admittingphys_ds_id NUMBER (19, 0),
	admittingphys_mstr_id NUMBER (19, 0),
	admittingphysician VARCHAR2 (255 CHAR),
	aprdrg VARCHAR2 (6 CHAR),
	aprdrg_risk VARCHAR2 (6 CHAR),
	aprdrg_sev VARCHAR2 (6 CHAR),
	arrival_dtm TIMESTAMP,
	baseinclude VARCHAR2 (1 CHAR),
	charge NUMBER (38, 10),
	client_id VARCHAR2 (16 CHAR),
	clientplanned VARCHAR2 (1 CHAR),
	cms_ddisp VARCHAR2 (1 CHAR),
	cms_non_surgcancer VARCHAR2 (1 CHAR),
	cms_psych VARCHAR2 (1 CHAR),
	cms_rehab VARCHAR2 (1 CHAR),
	cms_rehabp VARCHAR2 (1 CHAR),
	cmsinclude VARCHAR2 (1 CHAR),
	cmsplanned VARCHAR2 (1 CHAR),
	convert_ip VARCHAR2 (1 CHAR),
	cost NUMBER (38, 10),
	cost_charge_ratio NUMBER (38, 10),
	discharge_dtm TIMESTAMP,
	display_ds_id NUMBER (10, 0),
	display_encounterid VARCHAR2 (255 CHAR),
	display_id_type VARCHAR2 (249 CHAR),
	drg VARCHAR2 (255 CHAR),
	drgtypecui VARCHAR2 (8 CHAR),
	elos NUMBER (38, 10),
	encounter_grp_num NUMBER (19, 0),
	encounter_grp_type VARCHAR2 (8 CHAR),
	encounterservice VARCHAR2 (8 CHAR),
	facility_ds_id NUMBER (10, 0),
	facilityid VARCHAR2 (255 CHAR),
	finclass VARCHAR2 (8 CHAR),
	insuranceplan VARCHAR2 (255 CHAR),
	lastattphys_ds_id NUMBER (19, 0),
	lastattphys_mstr_id NUMBER (19, 0),
	lastattphysician VARCHAR2 (255 CHAR),
	lastattteam VARCHAR2 (255 CHAR),
	lastattteam_ds_id NUMBER (10, 0),
	lastattteam_mstr_id NUMBER (10, 0),
	lastlocation VARCHAR2 (255 CHAR),
	localadmitsource VARCHAR2 (255 CHAR),
	localdischargedisposition VARCHAR2 (255 CHAR),
	mappedzipcode VARCHAR2 (8 CHAR),
	master_facility_cd VARCHAR2 (255 CHAR),
	mdc VARCHAR2 (249 CHAR),
	mpi VARCHAR2 (32 CHAR),
	prindx VARCHAR2 (10 CHAR),
	prindx_codetype VARCHAR2 (16 CHAR),
	prinpx VARCHAR2 (10 CHAR),
	prinpx_codetype VARCHAR2 (16 CHAR),
	prov_id VARCHAR2 (20 CHAR),
	servicecode VARCHAR2 (255 CHAR),
	siteofcare_cd VARCHAR2 (296 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_encounter_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_encounter_grp (
	admit_dtm TIMESTAMP,
	admitted_er VARCHAR2 (1 CHAR),
	admittingphys_ds_id NUMBER (19, 0),
	admittingphys_mstr_id NUMBER (19, 0),
	admittingphysician VARCHAR2 (255 CHAR),
	aprdrg VARCHAR2 (6 CHAR),
	aprdrg_risk VARCHAR2 (6 CHAR),
	aprdrg_sev VARCHAR2 (6 CHAR),
	arrival_dtm TIMESTAMP,
	baseinclude VARCHAR2 (1 CHAR),
	charge NUMBER (38, 10),
	client_id VARCHAR2 (16 CHAR),
	clientplanned VARCHAR2 (1 CHAR),
	cms_ddisp VARCHAR2 (1 CHAR),
	cms_non_surgcancer VARCHAR2 (1 CHAR),
	cms_psych VARCHAR2 (1 CHAR),
	cms_rehab VARCHAR2 (1 CHAR),
	cms_rehabp VARCHAR2 (1 CHAR),
	cmsinclude VARCHAR2 (1 CHAR),
	cmsplanned VARCHAR2 (1 CHAR),
	convert_ip VARCHAR2 (1 CHAR),
	cost NUMBER (38, 10),
	cost_charge_ratio NUMBER (38, 10),
	discharge_dtm TIMESTAMP,
	display_ds_id NUMBER (10, 0),
	display_encounterid VARCHAR2 (255 CHAR),
	display_id_type VARCHAR2 (249 CHAR),
	drg VARCHAR2 (255 CHAR),
	drgtypecui VARCHAR2 (8 CHAR),
	elos NUMBER (38, 10),
	encounter_grp_num NUMBER (19, 0),
	encounter_grp_type VARCHAR2 (8 CHAR),
	encounterservice VARCHAR2 (8 CHAR),
	facility_ds_id NUMBER (10, 0),
	facilityid VARCHAR2 (255 CHAR),
	finclass VARCHAR2 (8 CHAR),
	insuranceplan VARCHAR2 (255 CHAR),
	lastattphys_ds_id NUMBER (19, 0),
	lastattphys_mstr_id NUMBER (19, 0),
	lastattphysician VARCHAR2 (255 CHAR),
	lastattteam VARCHAR2 (255 CHAR),
	lastattteam_ds_id NUMBER (10, 0),
	lastattteam_mstr_id NUMBER (10, 0),
	lastlocation VARCHAR2 (255 CHAR),
	localadmitsource VARCHAR2 (255 CHAR),
	localdischargedisposition VARCHAR2 (255 CHAR),
	mappedzipcode VARCHAR2 (8 CHAR),
	master_facility_cd VARCHAR2 (255 CHAR),
	mdc VARCHAR2 (249 CHAR),
	mpi VARCHAR2 (32 CHAR),
	prindx VARCHAR2 (10 CHAR),
	prindx_codetype VARCHAR2 (16 CHAR),
	prinpx VARCHAR2 (10 CHAR),
	prinpx_codetype VARCHAR2 (16 CHAR),
	prov_id VARCHAR2 (20 CHAR),
	servicecode VARCHAR2 (255 CHAR),
	siteofcare_cd VARCHAR2 (296 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_prov_attribute', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_prov_attribute (
	attribute_type_cui VARCHAR2(50 CHAR) NULL,
	attribute_value VARCHAR2(255 CHAR) NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	eff_dt DATE  NULL,
	end_dt DATE  NULL,
	localproviderid VARCHAR2(100 CHAR) NOT NULL,
	master_hgprovid NUMBER  NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_patient_summary_grp_mpi', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_patient_summary_grp_mpi (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	date_of_death DATE  NULL,
	display_id VARCHAR2(4000 CHAR) NULL,
	dob VARCHAR2(8 CHAR) NULL,
	first_name VARCHAR2(255 CHAR) NULL,
	inactive_flag VARCHAR2(1 CHAR) NULL,
	last_name VARCHAR2(255 CHAR) NULL,
	local_dod DATE  NULL,
	mapped_death_ind VARCHAR2(16 CHAR) NULL,
	mapped_ethnicity VARCHAR2(16 CHAR) NULL,
	mapped_gender VARCHAR2(16 CHAR) NULL,
	mapped_language VARCHAR2(249 CHAR) NULL,
	mapped_marital_status VARCHAR2(249 CHAR) NULL,
	mapped_race VARCHAR2(16 CHAR) NULL,
	mapped_zipcode VARCHAR2(16 CHAR) NULL,
	middle_name VARCHAR2 (249 CHAR),
	mob VARCHAR2(6 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	mrace_infer_ind NUMBER (10, 0),
	patientid_cnt NUMBER  NULL,
	religion VARCHAR2(255 CHAR) NULL,
	ssdi_dod VARCHAR2(1 CHAR) NULL,
	ssdi_name_match VARCHAR2(1 CHAR) NULL,
	yob VARCHAR2(4 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_provider_affil', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_provider_affil (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	eff_dt DATE NULL,
	end_dt DATE NULL,
	prov_affil_id VARCHAR2 (30 CHAR) NOT NULL,
	prov_id VARCHAR2 (22 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_prov_affil', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_prov_affil (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	prov_affil_desc VARCHAR2 (150 CHAR) NULL,
	prov_affil_id VARCHAR2 (30 CHAR) NULL,
	prov_affil_lv1 VARCHAR2 (30 CHAR) NULL,
	prov_affil_lv1_desc VARCHAR2 (150 CHAR) NULL,
	prov_affil_lv2 VARCHAR2 (30 CHAR) NULL,
	prov_affil_lv2_desc VARCHAR2 (150 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_account', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_account (
	account_desc VARCHAR2(150 CHAR) NULL,
	account_id VARCHAR2(30 CHAR)  NULL,
	account_lv1 VARCHAR2(30 CHAR) NULL,
	account_lv1_desc VARCHAR2(150 CHAR) NULL,
	account_lv2 VARCHAR2(30 CHAR) NULL,
	account_lv2_desc VARCHAR2(150 CHAR) NULL,
	biz_segment_id VARCHAR2(30 CHAR) NULL,
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT NULL,
	industry NUMBER(10,0) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_disease', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_disease (
	disease_desc VARCHAR2(60 CHAR) NULL,
	disease_desc_mask VARCHAR2(60 CHAR) NULL,
	disease_id NUMBER  NULL,
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_drg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_drg (
	drg_admittyp VARCHAR2 (3 CHAR),
	drg_code VARCHAR2 (4 CHAR),
	drg_desc VARCHAR2 (200 CHAR),
	drg_id VARCHAR2 (12 CHAR),
	drg_level VARCHAR2 (2 CHAR),
	drg_version VARCHAR2 (3 CHAR),
	drg_wgt NUMBER (10, 4),
	mdc NUMBER (10, 0),
	riflag NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ebm_rules', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ebm_rules (
	author VARCHAR2 (25 CHAR),
	enabled NUMBER (1),
	ext_flag NUMBER (10, 0),
	labdata_req NUMBER (1),
	labresults_req NUMBER (1),
	nqf_endorsed NUMBER (1),
	nqf_similar NUMBER (1),
	rpt_case_id NUMBER (10, 0),
	rpt_rule_id NUMBER (10, 0),
	rule_desc VARCHAR2 (212 CHAR),
	rule_type_id NUMBER (10, 0),
	rx_req NUMBER (1),
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg (
	chronic NUMBER (3) NULL,
	etg_id NUMBER (6) NULL,
	etg_impact VARCHAR2(8 CHAR) NULL,
	etg_impact_desc VARCHAR2(150 CHAR) NULL,
	family NUMBER (6) NULL,
	mpc NUMBER (6) NULL,
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0),
	tx_ind NUMBER (3) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_tx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_tx (
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0),
	tx_code NUMBER (10, 0),
	tx_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_base', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_base (
	base VARCHAR2 (6 CHAR),
	base_desc VARCHAR2 (50 CHAR),
	base_desc_long VARCHAR2 (100 CHAR),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_comorb', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_comorb (
	comorb_code NUMBER (10, 0),
	comorb_desc VARCHAR2 (150 CHAR),
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_cond', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_cond (
	cond_desc VARCHAR2 (150 CHAR),
	cond_status NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_family', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_family (
	family NUMBER (6) NULL,
	family_desc VARCHAR2(80 CHAR) NULL,
	family_desc_mask VARCHAR2(80 CHAR) NULL,
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_impact', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_impact (
	base VARCHAR2 (6 CHAR),
	etg VARCHAR2 (9 CHAR),
	etg_desc VARCHAR2 (150 CHAR),
	etg_impact VARCHAR2 (8 CHAR),
	etg_short VARCHAR2 (60 CHAR),
	prim_cond_code NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_sev', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_sev (
	etg_id NUMBER (10, 0),
	etg_sev_desc VARCHAR2 (150 CHAR),
	etg_sev_id NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0),
	sev_level NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_etg_unit', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_etg_unit (
	etg_unit VARCHAR2 (9 CHAR),
	etg_unit_desc VARCHAR2 (75 CHAR),
	etg_unit_id NUMBER (10, 0),
	family NUMBER (10, 0),
	mpc NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_dcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_dcc (
	chronic NUMBER (1),
	dcc VARCHAR2 (5 CHAR),
	gen_name VARCHAR2 (255 CHAR),
	pcc VARCHAR2 (3 CHAR),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_icddx', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_icddx (
	ccs_dx_cat VARCHAR2 (4 CHAR),
	ccsr_dx_cat VARCHAR2 (6 CHAR),
	icd_version NUMBER (10, 0),
	icddx VARCHAR2 (7 CHAR),
	icddx_desc VARCHAR2 (150 CHAR),
	planned_dx_flag NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_mdc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_mdc (
	mdc NUMBER (10, 0),
	mdc_desc VARCHAR2 (150 CHAR),
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_icdproc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_icdproc (
	ccs_proc_cat VARCHAR2 (4 CHAR),
	ccsr_proc_cat VARCHAR2 (6 CHAR),
	icd_version NUMBER (10, 0),
	icdproc VARCHAR2 (7 CHAR),
	icdproc_desc VARCHAR2 (150 CHAR),
	planned_proc_flag NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_ndc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_ndc (
	brand_name VARCHAR2 (50 CHAR),
	brand_name_mask VARCHAR2 (50 CHAR),
	dcc VARCHAR2 (5 CHAR),
	ndc VARCHAR2 (11 CHAR),
	ndc_desc VARCHAR2 (50 CHAR),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_pcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_pcc (
	pcc VARCHAR2 (3 CHAR),
	pcc_desc VARCHAR2 (120 CHAR),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0),
	tcc VARCHAR2 (2 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg (
	peg_cat_desc VARCHAR2 (150 CHAR),
	peg_cat_id NUMBER (10, 0),
	peg_ppc NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_peg_target', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_peg_target (
	peg_target NUMBER (10, 0),
	peg_target_desc VARCHAR2 (150 CHAR),
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_proccode', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_proccode (
	proccode VARCHAR2 (15 CHAR),
	proccode_desc VARCHAR2 (100 CHAR),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_revenue', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_revenue (
	revenue VARCHAR2 (15 CHAR),
	revenue_desc VARCHAR2 (190 CHAR),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_contract', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_contract (
	client_ds_id NUMBER (10, 0),
	contract VARCHAR2 (30 CHAR),
	contract_desc VARCHAR2 (150 CHAR),
	contract_hier NUMBER (10, 0),
	contract_id VARCHAR2 (40 CHAR),
	contract_lv1 VARCHAR2 (30 CHAR),
	contract_lv1_desc VARCHAR2 (150 CHAR),
	contract_lv1_id VARCHAR2 (100 CHAR),
	contract_lv2 VARCHAR2 (30 CHAR),
	contract_lv2_desc VARCHAR2 (150 CHAR),
	contract_lv2_id VARCHAR2 (100 CHAR),
	map_srce_e VARCHAR2 (6 CHAR),
	riflag NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_account_by_lvl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_account_by_lvl (
	account_desc VARCHAR2 (150 CHAR),
	account_id VARCHAR2 (100 CHAR),
	client_id VARCHAR2 (16 CHAR),
	lvl NUMBER (10, 0),
	parent_account_id VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_contract_by_lvl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_contract_by_lvl (
	client_id VARCHAR2 (16 CHAR),
	contract_desc VARCHAR2 (150 CHAR),
	contract_id VARCHAR2 (100 CHAR),
	lvl NUMBER (10, 0),
	parent_contract_id VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_prov_affil_by_lvl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_prov_affil_by_lvl (
	client_id VARCHAR2 (16 CHAR),
	lvl NUMBER (10, 0),
	parent_prov_affil_id VARCHAR2 (150 CHAR),
	prov_affil_desc VARCHAR2 (150 CHAR),
	prov_affil_id VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_util_spec_cat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_util_spec_cat (
	def_util_spec_cat NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL,
	util_spec1 VARCHAR2 (90 CHAR),
	util_spec2 VARCHAR2 (90 CHAR),
	util_spec_cat_cd NUMBER (10, 0),
	util_spec_cat_desc VARCHAR2 (90 CHAR),
	util_spec_id1 NUMBER (10, 0),
	util_spec_id2 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_utl_spc_cat_cpaoly', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_utl_spc_cat_cpaoly (
	def_util_spec_cat NUMBER (10, 0),
	sensitive_cat_id NUMBER(10,0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL,
	util_spec0 VARCHAR2 (90 CHAR),
	util_spec1 VARCHAR2 (90 CHAR),
	util_spec2 VARCHAR2 (90 CHAR),
	util_spec_cat_cd NUMBER (10, 0),
	util_spec_cat_desc VARCHAR2 (90 CHAR),
	util_spec_id0 NUMBER (10, 0),
	util_spec_id1 NUMBER (10, 0),
	util_spec_id2 NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_ql_claims', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_ql_claims (
	account_id VARCHAR2 (40 CHAR),
	age NUMBER (10, 0),
	amt_req NUMBER (19, 2),
	amt_req_k NUMBER (19, 2),
	at_risk_status_id VARCHAR2 (40 CHAR),
	cat_status NUMBER (10, 0),
	cat_status_cost3 NUMBER (10, 0),
	claim_id VARCHAR2 (30 CHAR),
	clm_exclude NUMBER (10, 0),
	clm_id_n VARCHAR2 (30 CHAR),
	clm_type VARCHAR2 (1 CHAR),
	conf_num NUMBER (19, 0),
	contract_id VARCHAR2 (40 CHAR),
	cost1 NUMBER (19, 2),
	cost1_k NUMBER (19, 2),
	cost2 NUMBER (19, 2),
	cost2_k NUMBER (19, 2),
	cost3 NUMBER (19, 2),
	cost3_k NUMBER (19, 2),
	cost4 NUMBER (19, 2),
	cost4_k NUMBER (19, 2),
	cost5 NUMBER (19, 2),
	cost5_k NUMBER (19, 2),
	cost6 NUMBER (19, 2),
	cost6_k NUMBER (19, 2),
	days_sup NUMBER (10, 0),
	diag1 VARCHAR2 (8 CHAR),
	diag10 VARCHAR2 (8 CHAR),
	diag2 VARCHAR2 (8 CHAR),
	diag3 VARCHAR2 (8 CHAR),
	diag4 VARCHAR2 (8 CHAR),
	diag5 VARCHAR2 (8 CHAR),
	diag6 VARCHAR2 (8 CHAR),
	diag7 VARCHAR2 (8 CHAR),
	diag8 VARCHAR2 (8 CHAR),
	diag9 VARCHAR2 (8 CHAR),
	enc_k NUMBER (19, 2),
	encounter NUMBER (19, 2),
	episode_id NUMBER (19, 0),
	etg_id NUMBER (10, 0),
	from_dt TIMESTAMP,
	ia_time NUMBER (10, 0),
	icd_version NUMBER (10, 0),
	line_nat VARCHAR2 (10 CHAR),
	map_srce_n VARCHAR2 (6 CHAR),
	mem_userdef_1_id VARCHAR2 (40 CHAR),
	mem_userdef_2_id VARCHAR2 (40 CHAR),
	member VARCHAR2 (32 CHAR),
	mod_n VARCHAR2 (4 CHAR),
	network_paid_status_id VARCHAR2 (40 CHAR),
	network_status NUMBER (1),
	pay_dt TIMESTAMP,
	poa VARCHAR2 (1 CHAR),
	pos_i NUMBER (10, 0),
	proc_srv VARCHAR2 (15 CHAR),
	proc_srv_desc VARCHAR2 (200 CHAR),
	product_id VARCHAR2 (40 CHAR),
	provider_id VARCHAR2 (20 CHAR),
	provider_status_id VARCHAR2 (40 CHAR),
	prv_sp_4 NUMBER (10, 0),
	qlc_id NUMBER (19, 0),
	sev_level NUMBER (10, 0),
	sex NUMBER (1),
	svc_grp VARCHAR2 (30 CHAR),
	svc_qty NUMBER (19, 2),
	svc_qty_k NUMBER (19, 2),
	to_dt TIMESTAMP,
	tos_i_5 NUMBER (10, 0),
	zip VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_hm_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_hm_type (
	cui VARCHAR2 (50 CHAR),
	cui_name VARCHAR2 (100 CHAR),
	domain_cui VARCHAR2 (50 CHAR),
	domain_name VARCHAR2 (100 CHAR),
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_diag_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_diag_status (
	diag_status_cui VARCHAR2 (8 CHAR) NOT NULL,
	diag_status_desc VARCHAR2 (100 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_drg_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_drg_type (
	drg_type_cui VARCHAR2 (8 CHAR) NOT NULL,
	drg_type_desc VARCHAR2 (100 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('md_domain_concept', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE md_domain_concept (
	concept_cui VARCHAR2 (50 CHAR),
	concept_name VARCHAR2 (100 CHAR),
	domain_cui VARCHAR2 (50 CHAR),
	domain_name VARCHAR2 (100 CHAR),
	first_valid_dt DATE  NULL,
	is_other VARCHAR2 (255 CHAR),
	last_valid_dt DATE  NULL,
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_attr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_attr (
	attr_cui VARCHAR2 (8 CHAR),
	attr_desc VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_tos (
	enc_top NUMBER NOT NULL,
	enc_tos NUMBER NOT NULL,
	etg_tos NUMBER NOT NULL,
	pcp_serv NUMBER NOT NULL,
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0),
	tos1 VARCHAR2 (100 CHAR),
	tos1_id NUMBER NOT NULL,
	tos2 VARCHAR2 (100 CHAR),
	tos2_id NUMBER NOT NULL,
	tos3 VARCHAR2 (100 CHAR),
	tos3_id NUMBER NOT NULL,
	tos4 VARCHAR2 (100 CHAR) NULL,
	tos4_id VARCHAR2 (100 CHAR) NULL,
	tos5 VARCHAR2 (100 CHAR),
	tos5_id NUMBER NOT NULL,
	tos_i VARCHAR2 (200 CHAR),
	tos_i_short VARCHAR2 (200 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_obstype', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_obstype (
	begin_range NUMBER  NULL,
	datatype VARCHAR2(255 CHAR) NULL,
	dts_version NUMBER  NOT NULL,
	end_range NUMBER  NULL,
	foam_restriction VARCHAR2(255 CHAR) NULL,
	obstype VARCHAR2(255 CHAR) NOT  NULL,
	obstype_cui VARCHAR2(50 CHAR) NOT NULL,
	obstype_std_units VARCHAR2(50 CHAR) NULL,
	round_prec NUMBER  NULL,
	sensitive_ind NUMBER (1) NULL,
	validated_ind NUMBER (1) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_map_assessment_cui', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_map_assessment_cui (
	client_id VARCHAR2 (16 CHAR),
	cui VARCHAR2 (50 CHAR),
	local_code VARCHAR2 (255 CHAR),
	map_cui VARCHAR2 (8 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_service_code', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_service_code (
	code_desc VARCHAR2 (255 CHAR),
	code_type NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0),
	serv_code VARCHAR2 (15 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_tos (
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0),
	tos1 VARCHAR2 (100 CHAR),
	tos1_id NUMBER (10, 0),
	tos2 VARCHAR2 (100 CHAR),
	tos2_id NUMBER (10, 0),
	tos3 VARCHAR2 (120 CHAR),
	tos3_id NUMBER (10, 0),
	tos4 VARCHAR2 (255 CHAR),
	tos5 VARCHAR2 (255 CHAR),
	tos_i VARCHAR2 (255 CHAR),
	tos_i_4 NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	tos_i_short VARCHAR2 (255 CHAR),
	util_spec_cat_cd NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_proceduredo', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_proceduredo (
	actualproc_dtm TIMESTAMP(3)  NULL,
	client_ds_id NUMBER  NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	codetype VARCHAR2(255 CHAR) NULL,
	datasrc VARCHAR2(249 CHAR) NOT NULL,
	encounterid VARCHAR2(255 CHAR) NULL,
	facilityid VARCHAR2(255 CHAR) NULL,
	hgpid VARCHAR2(249 CHAR) NULL,
	hosp_px_flag VARCHAR2(3 CHAR) NULL,
	localbillingproviderid VARCHAR2(255 CHAR) NULL,
	localcode VARCHAR2(255 CHAR) NULL,
	localname VARCHAR2(1000 CHAR) NULL,
	localprincipleindicator VARCHAR2(255 CHAR) NULL,
	mappedcode VARCHAR2(255 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NULL,
	orderingproviderid VARCHAR2(255 CHAR) NULL,
	orig_codetype VARCHAR2(16 CHAR) NULL,
	orig_mappedcode VARCHAR2(255 CHAR) NULL,
	patientid VARCHAR2(255 CHAR) NOT NULL,
	performing_mstrprovid VARCHAR2(249 CHAR) NULL,
	performingproviderid VARCHAR2(255 CHAR) NULL,
	proc_end_dtm DATE  NULL,
	procedure_dtm TIMESTAMP(3)  NOT NULL,
	procseq VARCHAR2(32 CHAR) NULL,
	referproviderid VARCHAR2(255 CHAR) NULL,
	sourceid VARCHAR2(255 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_organism', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_organism (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR),
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_event_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_event_type (
	event_type_cui VARCHAR2 (50 CHAR) NOT NULL,
	event_type_description VARCHAR2 (100 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_spec (
	prv_sp_4 NUMBER (10, 0),
	sp1 VARCHAR2 (12 CHAR),
	sp1_id NUMBER (10, 0),
	sp2 VARCHAR2 (30 CHAR),
	sp2_id NUMBER (10, 0),
	sp3 VARCHAR2 (40 CHAR),
	sp3_id NUMBER (10, 0),
	sp4 VARCHAR2 (40 CHAR),
	specialty_id VARCHAR2 (3 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_pos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_pos (
	place_of_svc VARCHAR2 (10 CHAR) NOT NULL,
	pos_desc VARCHAR2 (249 CHAR) NOT NULL,
	pos_i NUMBER NOT NULL,
	sensitive_cat_id NUMBER (3) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_proc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_proc (
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	exclude_hosp_ind NUMBER (1) DEFAULT 1 NOT NULL,
	precursor_id NUMBER NOT NULL,
	proc_cd VARCHAR2 (20 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_org_hier', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_org_hier (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	org_cd VARCHAR2 (150 CHAR) NOT NULL,
	org_desc VARCHAR2 (150 CHAR),
	org_lv1_cd VARCHAR2 (150 CHAR),
	org_lv1_desc VARCHAR2 (150 CHAR),
	org_lv2_cd VARCHAR2 (150 CHAR),
	org_lv2_desc VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_org_hier_by_lvl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_org_hier_by_lvl (
	client_id VARCHAR2 (16 CHAR),
	lvl NUMBER (10, 0),
	org_cd VARCHAR2 (150 CHAR),
	org_desc VARCHAR2 (150 CHAR),
	parent_org_cd VARCHAR2 (150 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cds_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cds_grp (
	cds_grp VARCHAR2(4000 CHAR) NOT NULL,
	client_ds_id NUMBER NOT NULL,
	client_id VARCHAR2(16 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_cds_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_cds_grp (
	cds_grp VARCHAR2 (4000 CHAR) NOT NULL,
	cds_grp_desc VARCHAR2 (4000 CHAR),
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	source_type_grp VARCHAR2 (4000 CHAR),
	source_type_grp_desc VARCHAR2 (4000 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_cc_case', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_cc_case (
	care_coord_assgnd_dt TIMESTAMP,
	care_coord_start_dt TIMESTAMP,
	care_plan_subtype VARCHAR2 (255 CHAR),
	care_plan_type VARCHAR2 (255 CHAR),
	care_plan_type_opt_out_dt TIMESTAMP,
	care_plan_type_opt_out_ind NUMBER (10, 0),
	care_tier VARCHAR2 (255 CHAR),
	case_billing_diag_cd VARCHAR2 (255 CHAR),
	case_close_rsn VARCHAR2 (255 CHAR),
	case_closed_by_id VARCHAR2 (255 CHAR),
	case_closed_dt TIMESTAMP,
	case_closed_sys_dtm TIMESTAMP,
	case_created_by_id VARCHAR2 (255 CHAR),
	case_created_dt TIMESTAMP,
	case_desc VARCHAR2 (400 CHAR),
	case_last_mod_dtm TIMESTAMP,
	case_last_task_edit_dt TIMESTAMP,
	case_nbr VARCHAR2 (255 CHAR),
	case_origin_cat VARCHAR2 (255 CHAR),
	case_origin_dtl VARCHAR2 (80 CHAR),
	case_owner_id VARCHAR2 (255 CHAR),
	case_priority VARCHAR2 (255 CHAR),
	case_rsn VARCHAR2 (255 CHAR),
	case_status VARCHAR2 (255 CHAR),
	case_status_before_closed VARCHAR2 (255 CHAR),
	case_subject VARCHAR2 (255 CHAR),
	cc_case_id VARCHAR2 (26 CHAR) NOT NULL,
	client_ds_id INTEGER NOT NULL,
	client_id VARCHAR2 (16 CHAR),
	consent_given_dt TIMESTAMP,
	consent_mode VARCHAR2 (255 CHAR),
	consent_notes VARCHAR2 (255 CHAR),
	consent_status VARCHAR2 (255 CHAR),
	datasrc VARCHAR2 (249 CHAR),
	hgpid NUMBER (19, 0),
	mpi VARCHAR2 (32 CHAR),
	patient_enrolled_dt TIMESTAMP,
	patient_enrolled_ind NUMBER (10, 0),
	patientid VARCHAR2 (255 CHAR) NOT NULL,
	record_type_id VARCHAR2 (255 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_cc_case_tier_history', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_cc_case_tier_history (
	case_tier VARCHAR2 (255 CHAR),
	case_tier_created_by_id VARCHAR2 (255 CHAR),
	case_tier_elapsed_dy NUMBER (6, 2),
	case_tier_end_dt TIMESTAMP,
	case_tier_nm VARCHAR2 (255 CHAR),
	case_tier_start_dt TIMESTAMP,
	cc_case_id VARCHAR2 (26 CHAR) NOT NULL,
	cc_case_tier_hist_id VARCHAR2 (26 CHAR) NOT NULL,
	client_ds_id INTEGER NOT NULL,
	client_id VARCHAR2 (16 CHAR),
	datasrc VARCHAR2 (249 CHAR),
	hgpid NUMBER (19, 0),
	mpi VARCHAR2 (32 CHAR),
	patientid VARCHAR2 (255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_cc_case_status_history', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_cc_case_status_history (
	case_owner_id VARCHAR2 (255 CHAR),
	case_stat_elapsed_hr NUMBER (7, 2),
	case_stat_end_dtm TIMESTAMP,
	case_stat_last_mod_by_id VARCHAR2 (255 CHAR),
	case_stat_nm VARCHAR2 (255 CHAR),
	case_stat_start_dtm TIMESTAMP,
	case_status VARCHAR2 (255 CHAR),
	cc_case_id VARCHAR2 (26 CHAR) NOT NULL,
	cc_case_stat_hist_id VARCHAR2 (26 CHAR) NOT NULL,
	client_ds_id INTEGER NOT NULL,
	client_id VARCHAR2 (16 CHAR),
	datasrc VARCHAR2 (249 CHAR),
	hgpid NUMBER (19, 0),
	mpi VARCHAR2 (32 CHAR),
	patientid VARCHAR2 (255 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_dict_cc_care_plan_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_dict_cc_care_plan_type (
	care_plan_type VARCHAR2 (255 CHAR) NOT NULL,
	care_plan_type_nm VARCHAR2 (255 CHAR),
	client_ds_id INTEGER NOT NULL,
	client_id VARCHAR2 (16 CHAR),
	datasrc VARCHAR2 (249 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_dict_cc_care_plan_subtype', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_dict_cc_care_plan_subtype (
	care_plan_subtype VARCHAR2 (255 CHAR) NOT NULL,
	care_plan_subtype_nm VARCHAR2 (255 CHAR),
	client_ds_id INTEGER NOT NULL,
	client_id VARCHAR2 (16 CHAR),
	datasrc VARCHAR2 (249 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_dict_cc_case_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_dict_cc_case_status (
	case_status VARCHAR2 (255 CHAR) NOT NULL,
	case_status_nm VARCHAR2 (255 CHAR),
	client_ds_id INTEGER NOT NULL,
	client_id VARCHAR2 (16 CHAR),
	datasrc VARCHAR2 (249 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_member_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_member_detail (
	at_risk_status VARCHAR2(30 CHAR) NULL,
	benefitplan VARCHAR2(30 CHAR) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	contracttype VARCHAR2(30 CHAR) NULL,
	coveragestatus VARCHAR2(30 CHAR) NULL,
	cust_mem_attr1 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr10 VARCHAR2 (255 CHAR),
	cust_mem_attr11 VARCHAR2 (255 CHAR),
	cust_mem_attr12 VARCHAR2 (255 CHAR),
	cust_mem_attr13 VARCHAR2 (255 CHAR),
	cust_mem_attr14 VARCHAR2 (255 CHAR),
	cust_mem_attr15 VARCHAR2 (255 CHAR),
	cust_mem_attr16 NUMBER (38, 10),
	cust_mem_attr17 NUMBER (38, 10),
	cust_mem_attr18 NUMBER (38, 10),
	cust_mem_attr19 NUMBER (38, 10),
	cust_mem_attr2 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr20 NUMBER (38, 10),
	cust_mem_attr3 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr4 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr5 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr6 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr7 VARCHAR2 (255 CHAR),
	cust_mem_attr8 VARCHAR2 (255 CHAR),
	cust_mem_attr9 VARCHAR2 (255 CHAR),
	date_of_death DATE  NULL,
	deceased_flag VARCHAR2(1 CHAR) NULL,
	dental_benefit VARCHAR2(1 CHAR) NULL,
	dob DATE  NULL,
	ecds_flag VARCHAR2(1 CHAR) NULL,
	eff_dt DATE  NOT NULL,
	emp_acct_id VARCHAR2(30 CHAR) NULL,
	employee_type VARCHAR2 (30 CHAR),
	employeraccountid VARCHAR2(30 CHAR) NULL,
	end_dt DATE  NULL,
	ethnicity NUMBER  NULL,
	gender VARCHAR2(1 CHAR) NULL,
	healthplansource VARCHAR2(15 CHAR) NULL,
	hra_ind NUMBER (10, 0),
	hsa_ind NUMBER (10, 0),
	lineofbusinessid NUMBER  NULL,
	medical VARCHAR2(1 CHAR) NULL,
	mem_userdef_1 VARCHAR2 (30 CHAR),
	mem_userdef_2 VARCHAR2 (30 CHAR),
	mem_userdef_3 VARCHAR2 (30 CHAR),
	mem_userdef_4 VARCHAR2 (30 CHAR),
	mentalhealth VARCHAR2(1 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NOT NULL,
	other_language VARCHAR2(2 CHAR) NULL,
	pcp_affil VARCHAR2 (30 CHAR),
	pcpid VARCHAR2(20 CHAR) NULL,
	primary_coverage_flag VARCHAR2(1 CHAR) NULL,
	product_dtl_code VARCHAR2 (30 CHAR),
	productcode VARCHAR2(30 CHAR) NULL,
	race NUMBER  NULL,
	risk_type VARCHAR2 (30 CHAR),
	sec_member_id_1 VARCHAR2 (30 CHAR),
	sec_member_id_2 VARCHAR2 (30 CHAR),
	spoken_language VARCHAR2(2 CHAR) NULL,
	subscriberflag VARCHAR2(1 CHAR) NULL,
	subscriberid VARCHAR2(32 CHAR) NULL,
	written_language VARCHAR2(2 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_member_detail_ii', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_member_detail_ii (
	at_risk_status VARCHAR2(30 CHAR) NULL,
	benefitplan VARCHAR2(30 CHAR) NULL,
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	contract_id VARCHAR2(30 CHAR) NULL,
	contracttype VARCHAR2(30 CHAR) NULL,
	coveragestatus VARCHAR2(30 CHAR) NULL,
	cust_mem_attr1 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr10 VARCHAR2 (255 CHAR),
	cust_mem_attr11 VARCHAR2 (255 CHAR),
	cust_mem_attr12 VARCHAR2 (255 CHAR),
	cust_mem_attr13 VARCHAR2 (255 CHAR),
	cust_mem_attr14 VARCHAR2 (255 CHAR),
	cust_mem_attr15 VARCHAR2 (255 CHAR),
	cust_mem_attr16 NUMBER (38, 10),
	cust_mem_attr17 NUMBER (38, 10),
	cust_mem_attr18 NUMBER (38, 10),
	cust_mem_attr19 NUMBER (38, 10),
	cust_mem_attr2 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr20 NUMBER (38, 10),
	cust_mem_attr3 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr4 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr5 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr6 VARCHAR2(255 CHAR) NULL,
	cust_mem_attr7 VARCHAR2 (255 CHAR),
	cust_mem_attr8 VARCHAR2 (255 CHAR),
	cust_mem_attr9 VARCHAR2 (255 CHAR),
	date_of_death DATE  NULL,
	deceased_flag VARCHAR2(1 CHAR) NULL,
	dental_benefit VARCHAR2(1 CHAR) NULL,
	dob DATE  NULL,
	ecds_flag VARCHAR2(1 CHAR) NULL,
	eff_dt DATE  NOT NULL,
	emp_acct_id VARCHAR2(30 CHAR) NULL,
	employee_type VARCHAR2 (30 CHAR),
	employeraccountid VARCHAR2(30 CHAR) NULL,
	end_dt DATE  NULL,
	ethnicity NUMBER  NULL,
	gender VARCHAR2(1 CHAR) NULL,
	healthplansource VARCHAR2(15 CHAR) NULL,
	hra_ind NUMBER (10, 0),
	hsa_ind NUMBER (10, 0),
	lineofbusinessid NUMBER  NULL,
	medical VARCHAR2(1 CHAR) NULL,
	mem_userdef_1 VARCHAR2 (30 CHAR),
	mem_userdef_2 VARCHAR2 (30 CHAR),
	mem_userdef_3 VARCHAR2 (30 CHAR),
	mem_userdef_4 VARCHAR2 (30 CHAR),
	mentalhealth VARCHAR2(1 CHAR) NULL,
	mpi VARCHAR2(32 CHAR) NOT NULL,
	other_language VARCHAR2(2 CHAR) NULL,
	pcp_affil VARCHAR2 (30 CHAR),
	pcpid VARCHAR2(20 CHAR) NULL,
	primary_coverage_flag VARCHAR2(1 CHAR) NULL,
	product_dtl_code VARCHAR2 (30 CHAR),
	productcode VARCHAR2(30 CHAR) NULL,
	race NUMBER  NULL,
	risk_type VARCHAR2 (30 CHAR),
	sec_member_id_1 VARCHAR2 (30 CHAR),
	sec_member_id_2 VARCHAR2 (30 CHAR),
	spoken_language VARCHAR2(2 CHAR) NULL,
	subscriberflag VARCHAR2(1 CHAR) NULL,
	subscriberid VARCHAR2(32 CHAR) NULL,
	written_language VARCHAR2(2 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_provider_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_provider_detail (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cust_prov_attr1 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr10 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr11 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr12 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr13 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr14 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr15 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr16 NUMBER (16, 6) NULL,
	cust_prov_attr17 NUMBER (16, 6) NULL,
	cust_prov_attr18 NUMBER (16, 6) NULL,
	cust_prov_attr19 NUMBER (16, 6) NULL,
	cust_prov_attr2 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr20 NUMBER (16, 6) NULL,
	cust_prov_attr3 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr4 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr5 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr6 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr7 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr8 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr9 VARCHAR2(255 CHAR) NULL,
	fourth_specialty VARCHAR2(15 CHAR) NULL,
	npi VARCHAR2(10 CHAR) NULL,
	pcpflag VARCHAR2(1 CHAR) NULL,
	prov_geo_lat NUMBER (38, 10),
	prov_geo_lon NUMBER (38, 10),
	prov_id VARCHAR2(20 CHAR) NOT NULL,
	prov_userdef_1 VARCHAR2 (100 CHAR),
	prov_userdef_2 VARCHAR2 (30 CHAR),
	provaddress1 VARCHAR2(50 CHAR) NULL,
	provaddress2 VARCHAR2(50 CHAR) NULL,
	provaffiliationid VARCHAR2(30 CHAR) NULL,
	provcity VARCHAR2(30 CHAR) NULL,
	provemail VARCHAR2(50 CHAR) NULL,
	provider_status VARCHAR2(30 CHAR) NULL,
	providerfirstname VARCHAR2(40 CHAR) NULL,
	providerlastname VARCHAR2(40 CHAR) NULL,
	providername VARCHAR2(50 CHAR) NULL,
	provphone VARCHAR2(50 CHAR) NULL,
	provstate VARCHAR2(2 CHAR) NULL,
	provzip VARCHAR2(10 CHAR) NULL,
	sec_prov_id VARCHAR2 (20 CHAR),
	secondaryspecialty VARCHAR2(15 CHAR) NULL,
	specialty VARCHAR2(15 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_provider_detail_spans', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_provider_detail_spans (
	client_id VARCHAR2(16 CHAR) NOT  NULL,
	cust_prov_attr1 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr10 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr11 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr12 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr13 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr14 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr15 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr16 NUMBER (16, 6) NULL,
	cust_prov_attr17 NUMBER (16, 6) NULL,
	cust_prov_attr18 NUMBER (16, 6) NULL,
	cust_prov_attr19 NUMBER (16, 6) NULL,
	cust_prov_attr2 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr20 NUMBER (16, 6) NULL,
	cust_prov_attr3 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr4 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr5 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr6 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr7 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr8 VARCHAR2(255 CHAR) NULL,
	cust_prov_attr9 VARCHAR2(255 CHAR) NULL,
	final_flag VARCHAR2(1 CHAR) NULL,
	final_network_flag VARCHAR2(1 CHAR) NULL,
	npi VARCHAR2(10 CHAR) NULL,
	pcpflag VARCHAR2(1 CHAR) NULL,
	prov_eff_dt DATE  NULL,
	prov_end_dt DATE  NULL,
	prov_geo_lat NUMBER (9,6) NULL,
	prov_geo_lon NUMBER (9,6) NULL,
	prov_id VARCHAR2(20 CHAR) NOT NULL,
	prov_userdef_1 VARCHAR2(100 CHAR) NULL,
	prov_userdef_2 VARCHAR2(30 CHAR) NULL,
	provaddress1 VARCHAR2(50 CHAR) NULL,
	provaddress2 VARCHAR2(50 CHAR) NULL,
	provaffiliationid VARCHAR2(30 CHAR) NULL,
	provcity VARCHAR2(30 CHAR) NULL,
	provemail VARCHAR2(50 CHAR) NULL,
	provider_status VARCHAR2(30 CHAR) NULL,
	providerfirstname VARCHAR2(40 CHAR) NULL,
	providerlastname VARCHAR2(40 CHAR) NULL,
	providername VARCHAR2(50 CHAR) NULL,
	provphone VARCHAR2(50 CHAR) NULL,
	provstate VARCHAR2(2 CHAR) NULL,
	provzip VARCHAR2(10 CHAR) NULL,
	sec_prov_id VARCHAR2(20 CHAR) NULL,
	secondaryspecialty VARCHAR2(15 CHAR) NULL,
	specialty VARCHAR2(15 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_labresult_claims', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_labresult_claims (
	claimheader VARCHAR2 (20 CHAR),
	client_id VARCHAR2 (16 CHAR),
	healthplansource VARCHAR2 (15 CHAR),
	loinc VARCHAR2 (7 CHAR),
	mpi VARCHAR2 (32 CHAR),
	service_dt TIMESTAMP,
	testresultnumber NUMBER (38, 10),
	testresulttext VARCHAR2 (25 CHAR),
	testresultunits VARCHAR2 (25 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_medical_claims', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_medical_claims (
	admin_fee_amt NUMBER (38, 10),
	admitsource VARCHAR2 (1 CHAR),
	allowedamount NUMBER (38, 10),
	amt_oth1 NUMBER (38, 10),
	amt_oth2 NUMBER (38, 10),
	amt_oth3 NUMBER (38, 10),
	amt_oth4 NUMBER (38, 10),
	attend_prov_id VARCHAR2 (25 CHAR),
	billing_prov_id VARCHAR2 (20 CHAR),
	capamount NUMBER (38, 10),
	capsvcflag VARCHAR2 (1 CHAR),
	claim_prov_affil_id VARCHAR2 (30 CHAR),
	claimheader VARCHAR2 (20 CHAR),
	claimid VARCHAR2 (255 CHAR),
	claimline VARCHAR2 (10 CHAR),
	claimsource VARCHAR2 (6 CHAR),
	client_id VARCHAR2 (16 CHAR),
	cobamount NUMBER (38, 10),
	coinsamount NUMBER (38, 10),
	contract_id VARCHAR2 (30 CHAR),
	copayamount NUMBER (38, 10),
	cust_med_attr1 VARCHAR2 (255 CHAR),
	cust_med_attr10 VARCHAR2 (255 CHAR),
	cust_med_attr11 VARCHAR2 (255 CHAR),
	cust_med_attr12 VARCHAR2 (255 CHAR),
	cust_med_attr13 VARCHAR2 (255 CHAR),
	cust_med_attr14 VARCHAR2 (255 CHAR),
	cust_med_attr15 VARCHAR2 (255 CHAR),
	cust_med_attr16 NUMBER (38, 10),
	cust_med_attr17 NUMBER (38, 10),
	cust_med_attr18 NUMBER (38, 10),
	cust_med_attr19 NUMBER (38, 10),
	cust_med_attr2 VARCHAR2 (255 CHAR),
	cust_med_attr20 NUMBER (38, 10),
	cust_med_attr3 VARCHAR2 (255 CHAR),
	cust_med_attr4 VARCHAR2 (255 CHAR),
	cust_med_attr5 VARCHAR2 (255 CHAR),
	cust_med_attr6 VARCHAR2 (255 CHAR),
	cust_med_attr7 VARCHAR2 (255 CHAR),
	cust_med_attr8 VARCHAR2 (255 CHAR),
	cust_med_attr9 VARCHAR2 (255 CHAR),
	deductamount NUMBER (38, 10),
	denied_ind VARCHAR2 (30 CHAR),
	deniedflag VARCHAR2 (1 CHAR),
	dischargestatus VARCHAR2 (3 CHAR),
	drg VARCHAR2 (3 CHAR),
	drggrouper VARCHAR2 (3 CHAR),
	drgoutlier VARCHAR2 (1 CHAR),
	drgseverity VARCHAR2 (2 CHAR),
	employeraccountid VARCHAR2 (30 CHAR),
	ffsamount NUMBER (38, 10),
	from_dt TIMESTAMP,
	healthplansource VARCHAR2 (15 CHAR),
	icd_diag_11 VARCHAR2 (8 CHAR),
	icd_diag_12 VARCHAR2 (8 CHAR),
	icd_diag_13 VARCHAR2 (8 CHAR),
	icd_diag_14 VARCHAR2 (8 CHAR),
	icd_diag_15 VARCHAR2 (8 CHAR),
	icd_diag_16 VARCHAR2 (8 CHAR),
	icd_diag_17 VARCHAR2 (8 CHAR),
	icd_diag_18 VARCHAR2 (8 CHAR),
	icd_diag_19 VARCHAR2 (8 CHAR),
	icd_diag_20 VARCHAR2 (8 CHAR),
	icd_diag_21 VARCHAR2 (8 CHAR),
	icd_diag_22 VARCHAR2 (8 CHAR),
	icd_diag_23 VARCHAR2 (8 CHAR),
	icd_diag_24 VARCHAR2 (8 CHAR),
	icd_diag_25 VARCHAR2 (8 CHAR),
	icd_proc_10 VARCHAR2 (7 CHAR),
	icd_proc_11 VARCHAR2 (7 CHAR),
	icd_proc_12 VARCHAR2 (7 CHAR),
	icd_proc_13 VARCHAR2 (7 CHAR),
	icd_proc_14 VARCHAR2 (8 CHAR),
	icd_proc_15 VARCHAR2 (8 CHAR),
	icd_proc_16 VARCHAR2 (8 CHAR),
	icd_proc_17 VARCHAR2 (8 CHAR),
	icd_proc_18 VARCHAR2 (8 CHAR),
	icd_proc_19 VARCHAR2 (8 CHAR),
	icd_proc_20 VARCHAR2 (8 CHAR),
	icd_proc_21 VARCHAR2 (8 CHAR),
	icd_proc_22 VARCHAR2 (8 CHAR),
	icd_proc_23 VARCHAR2 (8 CHAR),
	icd_proc_24 VARCHAR2 (8 CHAR),
	icd_proc_25 VARCHAR2 (8 CHAR),
	icd_proc_7 VARCHAR2 (7 CHAR),
	icd_proc_8 VARCHAR2 (7 CHAR),
	icd_proc_9 VARCHAR2 (7 CHAR),
	icdcodetype VARCHAR2 (2 CHAR),
	icddiag1 VARCHAR2 (8 CHAR),
	icddiag10 VARCHAR2 (8 CHAR),
	icddiag2 VARCHAR2 (8 CHAR),
	icddiag3 VARCHAR2 (8 CHAR),
	icddiag4 VARCHAR2 (8 CHAR),
	icddiag5 VARCHAR2 (8 CHAR),
	icddiag6 VARCHAR2 (8 CHAR),
	icddiag7 VARCHAR2 (8 CHAR),
	icddiag8 VARCHAR2 (8 CHAR),
	icddiag9 VARCHAR2 (8 CHAR),
	icdproc1 VARCHAR2 (7 CHAR),
	icdproc2 VARCHAR2 (7 CHAR),
	icdproc3 VARCHAR2 (7 CHAR),
	icdproc4 VARCHAR2 (7 CHAR),
	icdproc5 VARCHAR2 (7 CHAR),
	icdproc6 VARCHAR2 (7 CHAR),
	mpi VARCHAR2 (32 CHAR),
	network_paid_status VARCHAR2 (30 CHAR),
	networkstatus VARCHAR2 (1 CHAR),
	not_covered_amt NUMBER (38, 10),
	ordering_prov_id VARCHAR2 (20 CHAR),
	other_carrier_pay_amt NUMBER (38, 10),
	paidamount NUMBER (38, 10),
	patliabamount NUMBER (38, 10),
	payment_dt TIMESTAMP,
	placeofservice VARCHAR2 (3 CHAR),
	poa VARCHAR2 (1 CHAR),
	poa_10 VARCHAR2 (1 CHAR),
	poa_11 VARCHAR2 (1 CHAR),
	poa_12 VARCHAR2 (1 CHAR),
	poa_13 VARCHAR2 (1 CHAR),
	poa_2 VARCHAR2 (1 CHAR),
	poa_3 VARCHAR2 (1 CHAR),
	poa_4 VARCHAR2 (1 CHAR),
	poa_5 VARCHAR2 (1 CHAR),
	poa_6 VARCHAR2 (1 CHAR),
	poa_7 VARCHAR2 (1 CHAR),
	poa_8 VARCHAR2 (1 CHAR),
	poa_9 VARCHAR2 (1 CHAR),
	proc_code_modifier2 VARCHAR2 (4 CHAR),
	proc_code_modifier3 VARCHAR2 (4 CHAR),
	proc_code_modifier4 VARCHAR2 (4 CHAR),
	procedurecode VARCHAR2 (8 CHAR),
	proceduremodifier VARCHAR2 (4 CHAR),
	provider_status VARCHAR2 (30 CHAR),
	pseudoflag VARCHAR2 (1 CHAR),
	quantity NUMBER (10, 0),
	requestedamount NUMBER (38, 10),
	revenuecode VARCHAR2 (4 CHAR),
	service_dt TIMESTAMP,
	spec_rx_ind VARCHAR2 (30 CHAR),
	specialty VARCHAR2 (15 CHAR),
	svc_prov_id VARCHAR2 (20 CHAR),
	to_dt TIMESTAMP,
	tos VARCHAR2 (30 CHAR),
	type_of_service VARCHAR2 (249 CHAR),
	typeofbill VARCHAR2 (3 CHAR),
	withamount NUMBER (38, 10)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_pharmacy_claims', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_pharmacy_claims (
	adjusted_rx_cnt NUMBER (38, 10),
	admin_fee_amt NUMBER (38, 10),
	allowedamount NUMBER (38, 10),
	capitated_service_ind NUMBER (10, 0),
	claimheader VARCHAR2 (20 CHAR),
	claimsource VARCHAR2 (6 CHAR),
	client_id VARCHAR2 (16 CHAR),
	coinsamount NUMBER (38, 10),
	contract_id VARCHAR2 (30 CHAR),
	coord_benefits_amt NUMBER (38, 10),
	copayamount NUMBER (38, 10),
	cust_attr_1 VARCHAR2 (255 CHAR),
	cust_attr_10 VARCHAR2 (255 CHAR),
	cust_attr_11 VARCHAR2 (255 CHAR),
	cust_attr_12 VARCHAR2 (255 CHAR),
	cust_attr_13 VARCHAR2 (255 CHAR),
	cust_attr_14 VARCHAR2 (255 CHAR),
	cust_attr_15 VARCHAR2 (255 CHAR),
	cust_attr_16 NUMBER (38, 10),
	cust_attr_17 NUMBER (38, 10),
	cust_attr_18 NUMBER (38, 10),
	cust_attr_19 NUMBER (38, 10),
	cust_attr_2 VARCHAR2 (255 CHAR),
	cust_attr_20 NUMBER (38, 10),
	cust_attr_3 VARCHAR2 (255 CHAR),
	cust_attr_4 VARCHAR2 (255 CHAR),
	cust_attr_5 VARCHAR2 (255 CHAR),
	cust_attr_6 VARCHAR2 (255 CHAR),
	cust_attr_7 VARCHAR2 (255 CHAR),
	cust_attr_8 VARCHAR2 (255 CHAR),
	cust_attr_9 VARCHAR2 (255 CHAR),
	daw NUMBER (10, 0),
	dayssupply NUMBER (10, 0),
	deductamount NUMBER (38, 10),
	denied_ind VARCHAR2 (30 CHAR),
	deniedflag VARCHAR2 (1 CHAR),
	dispensingfee NUMBER (38, 10),
	employeraccountid VARCHAR2 (30 CHAR),
	fillnum NUMBER (10, 0),
	formulary VARCHAR2 (1 CHAR),
	genericstatus VARCHAR2 (1 CHAR),
	ingredientcost NUMBER (38, 10),
	mpi VARCHAR2 (32 CHAR),
	ndc VARCHAR2 (11 CHAR),
	network_paid_status VARCHAR2 (30 CHAR),
	networkstatus VARCHAR2 (1 CHAR),
	not_covered_amt NUMBER (38, 10),
	other_1_amt NUMBER (38, 10),
	other_2_amt NUMBER (38, 10),
	other_3_amt NUMBER (38, 10),
	other_4_amt NUMBER (38, 10),
	other_carrier_pay_amt NUMBER (38, 10),
	paidamount NUMBER (38, 10),
	patliabamount NUMBER (38, 10),
	payment_dt TIMESTAMP,
	pharmacyid VARCHAR2 (20 CHAR),
	pharmacytype VARCHAR2 (1 CHAR),
	presc_prov_id VARCHAR2 (20 CHAR),
	provider_status VARCHAR2 (30 CHAR),
	pseudoflag VARCHAR2 (1 CHAR),
	quantity NUMBER (10, 0),
	quantity_dispensed NUMBER (10, 0),
	requestedamount NUMBER (38, 10),
	rxid VARCHAR2 (100 CHAR),
	sales_tax_amt NUMBER (38, 10),
	service_dt TIMESTAMP,
	spec_rx_ind VARCHAR2 (30 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_pharmacy_clinical', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_pharmacy_clinical (
	administration_dt TIMESTAMP,
	client_id VARCHAR2 (16 CHAR),
	code VARCHAR2 (15 CHAR),
	code_taxonomy VARCHAR2 (10 CHAR),
	healthplansource VARCHAR2 (15 CHAR),
	mpi VARCHAR2 (32 CHAR),
	pharmacy_clinical_id VARCHAR2 (30 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_physician_key', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_physician_key (
	client_id VARCHAR2 (16 CHAR),
	prov_id VARCHAR2 (20 CHAR),
	providerkey VARCHAR2 (20 CHAR),
	specialty VARCHAR2 (15 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_bpo_clinical_doc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_bpo_clinical_doc (
	client_id VARCHAR2 (16 CHAR),
	clinical_document_id VARCHAR2 (30 CHAR),
	code VARCHAR2 (25 CHAR),
	code_taxonomy VARCHAR2 (10 CHAR),
	documentation_dt TIMESTAMP,
	healthplansource VARCHAR2 (15 CHAR),
	mpi VARCHAR2 (32 CHAR),
	phq9_version VARCHAR2 (1 CHAR),
	result VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('md_oadw_etl_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE md_oadw_etl_status (
	end_time TIMESTAMP,
	etl_name VARCHAR2 (100 CHAR),
	is_completed NUMBER (10, 0),
	start_time TIMESTAMP
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_cc_user', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_cc_user (
	active_ind NUMBER (10, 0),
	care_coordinator_ind NUMBER (10, 0),
	client_ds_id NUMBER(10,0) NOT NULL,
	client_id VARCHAR2 (16 CHAR),
	datasrc VARCHAR2 (249 CHAR),
	last_login_dt TIMESTAMP,
	user_email VARCHAR2 (255 CHAR),
	user_first_nm VARCHAR2 (40 CHAR),
	user_id VARCHAR2 (255 CHAR) NOT NULL,
	user_last_nm VARCHAR2 (80 CHAR),
	user_nm VARCHAR2 (200 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_facility_ext', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_facility_ext (
	client_ds_id NUMBER (10, 0),
	client_id VARCHAR2 (16 CHAR),
	enc_grp_ind NUMBER (10, 0),
	facility_postal_cd VARCHAR2 (10 CHAR),
	facilityid VARCHAR2 (255 CHAR),
	hgfacid NUMBER (19, 0),
	master_facility_cd VARCHAR2 (255 CHAR),
	master_facility_nm VARCHAR2 (255 CHAR),
	master_hgfacid NUMBER (19, 0),
	master_siteofcare_id NUMBER (19, 0),
	patient_type_cui VARCHAR2 (8 CHAR),
	siteofcare_cd VARCHAR2 (296 CHAR),
	siteofcare_nm VARCHAR2 (554 CHAR),
	siteofcare_postal_cd VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_map_pos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_map_pos (
	pos_desc VARCHAR2 (150 CHAR),
	pos_i NUMBER (10, 0),
	sensitive_cat_id NUMBER (10, 0) NOT NULL,
	sensitive_ind NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_proc_etg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_proc_etg (
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	etg NUMBER (5) NOT NULL,
	etg_cd NUMBER (5) NOT NULL,
	proc_cd VARCHAR2 (20 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_score', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_score (
	active_ind NUMBER (1) DEFAULT 1 NOT NULL,
	precalc_ind NUMBER (1) NOT NULL,
	qualitative_ind NUMBER (1) DEFAULT 1 NOT NULL,
	quantitative_ind NUMBER (1) DEFAULT 1 NOT NULL,
	score_desc VARCHAR2 (400 CHAR) NOT NULL,
	score_display_name VARCHAR2 (100 CHAR) NOT NULL,
	score_family_id NUMBER (3) NOT NULL,
	score_id NUMBER (5) NOT NULL,
	score_name VARCHAR2 (50 CHAR) NOT NULL,
	score_population_id NUMBER (3) NOT NULL,
	score_type_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_score_family', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_score_family (
	protected_ind NUMBER (1) NOT NULL,
	score_family_id NUMBER (3) NOT NULL,
	score_family_name VARCHAR2 (50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_admit_source', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_admit_source (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_allergen', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_allergen (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_allergen_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_allergen_type (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_antibiotic_sens', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_antibiotic_sens (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_carearea', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_carearea (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_deceased_ind', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_deceased_ind (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_defer_rsn', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_defer_rsn (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_discharge_disp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_discharge_disp (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_ethnicity', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_ethnicity (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_financial_class', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_financial_class (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_gender', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_gender (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_ins_company', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_ins_company (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_language', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_language (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_marital_status', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_marital_status (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_med_route', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_med_route (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_poa', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_poa (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_race', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_race (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_specimen_source', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_specimen_source (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_unit', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_unit (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_hosp_service', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_hosp_service (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR),
	domain_cui VARCHAR2 (8 CHAR),
	domain_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_cui_prov_role', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_cui_prov_role (
	cui VARCHAR2 (8 CHAR),
	cui_name VARCHAR2 (100 CHAR),
	domain_cui VARCHAR2 (8 CHAR),
	domain_name VARCHAR2 (100 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_sdoh_indices', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_sdoh_indices (
	address VARCHAR2 (40 CHAR),
	city VARCHAR2 (50 CHAR),
	client_id VARCHAR2 (16 CHAR),
	dob TIMESTAMP,
	education_level VARCHAR2 (50 CHAR),
	financial_insecurity NUMBER (10, 0),
	first_name VARCHAR2 (50 CHAR),
	food_insecurity NUMBER (10, 0),
	gender VARCHAR2 (1 CHAR),
	health_ownership_segment VARCHAR2 (30 CHAR),
	housing_insecurity NUMBER (10, 0),
	language_cd VARCHAR2 (50 CHAR),
	last_name VARCHAR2 (50 CHAR),
	mpi VARCHAR2 (32 CHAR),
	social_isolation NUMBER (10, 0),
	social_vulnerability NUMBER (10, 0),
	socioeconomic_status NUMBER (10, 0),
	state VARCHAR2 (2 CHAR),
	transportation_insecurity NUMBER (10, 0),
	zip VARCHAR2 (10 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_pat_score_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_pat_score_qual (
	client_id VARCHAR2 (16 CHAR) NOT NULL,
	default_flg NUMBER DEFAULT 0 NOT NULL,
	elig_cds_id NUMBER NOT NULL,
	mpi VARCHAR2 (32 CHAR) NOT NULL,
	score_id NUMBER (5) NOT NULL,
	score_qual_id NUMBER (10, 0) NOT NULL,
	timeframe_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_msdrg_output', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_msdrg_output (
	drg VARCHAR2 (3 CHAR),
	encounter_grp_num NUMBER (19, 0),
	mdc NUMBER (10, 0),
	mpi VARCHAR2 (32 CHAR),
	return_code VARCHAR2 (2 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_iqiindividual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_iqiindividual (
	age NUMBER (10, 0),
	agecat NUMBER (10, 0),
	apr_drg NUMBER (10, 0),
	aprdrg_risk_mortality NUMBER (10, 0),
	dqtr NUMBER (10, 0),
	drg NUMBER (10, 0),
	encounter_grp_num NUMBER (19, 0),
	hospid NUMBER (19, 0),
	mdc NUMBER (10, 0),
	paycat NUMBER (10, 0),
	racecat NUMBER (10, 0),
	sex NUMBER (10, 0),
	sexcat NUMBER (10, 0),
	tpiq08 NUMBER (10, 0),
	tpiq09 NUMBER (10, 0),
	tpiq09_with_cancer NUMBER (10, 0),
	tpiq09_without_cancer NUMBER (10, 0),
	tpiq11 NUMBER (10, 0),
	tpiq11_endo_ruptured NUMBER (10, 0),
	tpiq11_endo_unruptured NUMBER (10, 0),
	tpiq11_open_ruptured NUMBER (10, 0),
	tpiq11_open_unruptured NUMBER (10, 0),
	tpiq12 NUMBER (10, 0),
	tpiq15 NUMBER (10, 0),
	tpiq16 NUMBER (10, 0),
	tpiq17 NUMBER (10, 0),
	tpiq17_hemstroke_intracer NUMBER (10, 0),
	tpiq17_hemstroke_subarach NUMBER (10, 0),
	tpiq17_ischemstroke NUMBER (10, 0),
	tpiq18 NUMBER (10, 0),
	tpiq19 NUMBER (10, 0),
	tpiq20 NUMBER (10, 0),
	tpiq30 NUMBER (10, 0),
	tpiq31 NUMBER (10, 0),
	tpiq33 NUMBER (10, 0),
	tpiqmhat08 NUMBER (18, 10),
	tpiqmhat09_with_cancer NUMBER (18, 10),
	tpiqmhat09_without_cancer NUMBER (18, 10),
	tpiqmhat11_endo_ruptured NUMBER (18, 10),
	tpiqmhat11_endo_unruptured NUMBER (18, 10),
	tpiqmhat11_open_ruptured NUMBER (18, 10),
	tpiqmhat11_open_unruptured NUMBER (18, 10),
	tpiqmhat12 NUMBER (18, 10),
	tpiqmhat15 NUMBER (18, 10),
	tpiqmhat16 NUMBER (18, 10),
	tpiqmhat17_hemstroke_intracer NUMBER (18, 10),
	tpiqmhat17_hemstroke_subarach NUMBER (18, 10),
	tpiqmhat17_ischemstroke NUMBER (18, 10),
	tpiqmhat18 NUMBER (18, 10),
	tpiqmhat19 NUMBER (18, 10),
	tpiqmhat20 NUMBER (18, 10),
	tpiqmhat30 NUMBER (18, 10),
	tpiqmhat31 NUMBER (18, 10),
	trnsfer NUMBER (10, 0),
	year NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_psiindividual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_psiindividual (
	age NUMBER (10, 0),
	agecat NUMBER (10, 0),
	aids NUMBER (10, 0),
	alcohol NUMBER (10, 0),
	anemdef NUMBER (10, 0),
	arth NUMBER (10, 0),
	bldloss NUMBER (10, 0),
	chf NUMBER (10, 0),
	chrnlung NUMBER (10, 0),
	coag NUMBER (10, 0),
	depress NUMBER (10, 0),
	dm NUMBER (10, 0),
	dmcx NUMBER (10, 0),
	dqtr NUMBER (10, 0),
	drg NUMBER (10, 0),
	drug NUMBER (10, 0),
	encounter_grp_num NUMBER (19, 0),
	hospid NUMBER (19, 0),
	htn_c NUMBER (10, 0),
	hypothy NUMBER (10, 0),
	liver NUMBER (10, 0),
	los NUMBER (10, 0),
	lymph NUMBER (10, 0),
	lytes NUMBER (10, 0),
	mdc NUMBER (10, 0),
	mdrg NUMBER (10, 0),
	mets NUMBER (10, 0),
	neuro NUMBER (10, 0),
	obese NUMBER (10, 0),
	para NUMBER (10, 0),
	paycat NUMBER (10, 0),
	perivasc NUMBER (10, 0),
	ppps02 NUMBER (10, 0),
	ppps03 NUMBER (10, 0),
	ppps04 NUMBER (10, 0),
	ppps04_dvt_pe NUMBER (10, 0),
	ppps04_gihemorrhage NUMBER (10, 0),
	ppps04_pneumonia NUMBER (10, 0),
	ppps04_sepsis NUMBER (10, 0),
	ppps04_shock NUMBER (10, 0),
	ppps05 NUMBER (10, 0),
	ppps06 NUMBER (10, 0),
	ppps07 NUMBER (10, 0),
	ppps08 NUMBER (10, 0),
	ppps09 NUMBER (10, 0),
	ppps10 NUMBER (10, 0),
	ppps11 NUMBER (10, 0),
	ppps12 NUMBER (10, 0),
	ppps13 NUMBER (10, 0),
	ppps14 NUMBER (10, 0),
	ppps14_nonopen NUMBER (10, 0),
	ppps14_open NUMBER (10, 0),
	ppps15 NUMBER (10, 0),
	ppps18 NUMBER (10, 0),
	ppps19 NUMBER (10, 0),
	psych NUMBER (10, 0),
	pulmcirc NUMBER (10, 0),
	racecat NUMBER (10, 0),
	renlfail NUMBER (10, 0),
	sex NUMBER (10, 0),
	sexcat NUMBER (10, 0),
	tpps02 NUMBER (10, 0),
	tpps03 NUMBER (10, 0),
	tpps04 NUMBER (10, 0),
	tpps04_dvt_pe NUMBER (10, 0),
	tpps04_gihemorrhage NUMBER (10, 0),
	tpps04_pneumonia NUMBER (10, 0),
	tpps04_sepsis NUMBER (10, 0),
	tpps04_shock NUMBER (10, 0),
	tpps05 NUMBER (10, 0),
	tpps06 NUMBER (10, 0),
	tpps07 NUMBER (10, 0),
	tpps08 NUMBER (10, 0),
	tpps09 NUMBER (10, 0),
	tpps10 NUMBER (10, 0),
	tpps11 NUMBER (10, 0),
	tpps12 NUMBER (10, 0),
	tpps13 NUMBER (10, 0),
	tpps14 NUMBER (10, 0),
	tpps14_nonopen NUMBER (10, 0),
	tpps14_open NUMBER (10, 0),
	tpps15 NUMBER (10, 0),
	tpps18 NUMBER (10, 0),
	tpps19 NUMBER (10, 0),
	tppsmhat02 NUMBER (18, 10),
	tppsmhat03 NUMBER (18, 10),
	tppsmhat04_dvt_pe NUMBER (18, 10),
	tppsmhat04_gihemorrhage NUMBER (18, 10),
	tppsmhat04_pneumonia NUMBER (18, 10),
	tppsmhat04_sepsis NUMBER (18, 10),
	tppsmhat04_shock NUMBER (18, 10),
	tppsmhat06 NUMBER (18, 10),
	tppsmhat07 NUMBER (18, 10),
	tppsmhat08 NUMBER (18, 10),
	tppsmhat09 NUMBER (18, 10),
	tppsmhat10 NUMBER (18, 10),
	tppsmhat11 NUMBER (18, 10),
	tppsmhat12 NUMBER (18, 10),
	tppsmhat13 NUMBER (18, 10),
	tppsmhat14_nonopen NUMBER (18, 10),
	tppsmhat14_open NUMBER (18, 10),
	tppsmhat15 NUMBER (18, 10),
	trnsfer NUMBER (10, 0),
	tumor NUMBER (10, 0),
	ulcer NUMBER (10, 0),
	valve NUMBER (10, 0),
	wghtloss NUMBER (10, 0),
	year NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l1_pdiindividual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_pdiindividual (
	age NUMBER (10, 0),
	ageday NUMBER (10, 0),
	agedcat NUMBER (10, 0),
	bwhtcat NUMBER (10, 0),
	d_dxccsr_bld001_123 NUMBER (10, 0),
	d_dxccsr_bld002_123 NUMBER (10, 0),
	d_dxccsr_bld003_123 NUMBER (10, 0),
	d_dxccsr_bld005_123 NUMBER (10, 0),
	d_dxccsr_bld006_123 NUMBER (10, 0),
	d_dxccsr_bld007_123 NUMBER (10, 0),
	d_dxccsr_bld008_123 NUMBER (10, 0),
	d_dxccsr_cir001_123 NUMBER (10, 0),
	d_dxccsr_cir003_123 NUMBER (10, 0),
	d_dxccsr_cir005_123 NUMBER (10, 0),
	d_dxccsr_cir006_123 NUMBER (10, 0),
	d_dxccsr_cir007_123 NUMBER (10, 0),
	d_dxccsr_cir008_123 NUMBER (10, 0),
	d_dxccsr_cir014_123 NUMBER (10, 0),
	d_dxccsr_cir015_123 NUMBER (10, 0),
	d_dxccsr_cir016_123 NUMBER (10, 0),
	d_dxccsr_cir017_123 NUMBER (10, 0),
	d_dxccsr_cir019_123 NUMBER (10, 0),
	d_dxccsr_cir021_123 NUMBER (10, 0),
	d_dxccsr_cir025_123 NUMBER (10, 0),
	d_dxccsr_cir026_123 NUMBER (10, 0),
	d_dxccsr_cir031_123 NUMBER (10, 0),
	d_dxccsr_cir032_123 NUMBER (10, 0),
	d_dxccsr_cir033_123 NUMBER (10, 0),
	d_dxccsr_cir036_123 NUMBER (10, 0),
	d_dxccsr_cir039_123 NUMBER (10, 0),
	d_dxccsr_dig001_123 NUMBER (10, 0),
	d_dxccsr_dig002_123 NUMBER (10, 0),
	d_dxccsr_dig003_123 NUMBER (10, 0),
	d_dxccsr_dig004_123 NUMBER (10, 0),
	d_dxccsr_dig006_123 NUMBER (10, 0),
	d_dxccsr_dig007_123 NUMBER (10, 0),
	d_dxccsr_dig008_123 NUMBER (10, 0),
	d_dxccsr_dig009_123 NUMBER (10, 0),
	d_dxccsr_dig010_123 NUMBER (10, 0),
	d_dxccsr_dig011_123 NUMBER (10, 0),
	d_dxccsr_dig012_123 NUMBER (10, 0),
	d_dxccsr_dig016_123 NUMBER (10, 0),
	d_dxccsr_dig017_123 NUMBER (10, 0),
	d_dxccsr_dig018_123 NUMBER (10, 0),
	d_dxccsr_dig019_123 NUMBER (10, 0),
	d_dxccsr_dig020_123 NUMBER (10, 0),
	d_dxccsr_dig022_123 NUMBER (10, 0),
	d_dxccsr_dig024_123 NUMBER (10, 0),
	d_dxccsr_dig025_123 NUMBER (10, 0),
	d_dxccsr_ear001_123 NUMBER (10, 0),
	d_dxccsr_ear004_123 NUMBER (10, 0),
	d_dxccsr_ear006_123 NUMBER (10, 0),
	d_dxccsr_end001_123 NUMBER (10, 0),
	d_dxccsr_end007_123 NUMBER (10, 0),
	d_dxccsr_end008_123 NUMBER (10, 0),
	d_dxccsr_end009_123 NUMBER (10, 0),
	d_dxccsr_end011_123 NUMBER (10, 0),
	d_dxccsr_end012_123 NUMBER (10, 0),
	d_dxccsr_end013_123 NUMBER (10, 0),
	d_dxccsr_end015_123 NUMBER (10, 0),
	d_dxccsr_end016_123 NUMBER (10, 0),
	d_dxccsr_eye001_123 NUMBER (10, 0),
	d_dxccsr_eye005_123 NUMBER (10, 0),
	d_dxccsr_eye006_123 NUMBER (10, 0),
	d_dxccsr_eye007_123 NUMBER (10, 0),
	d_dxccsr_eye008_123 NUMBER (10, 0),
	d_dxccsr_eye010_123 NUMBER (10, 0),
	d_dxccsr_fac003_123 NUMBER (10, 0),
	d_dxccsr_fac004_123 NUMBER (10, 0),
	d_dxccsr_fac006_123 NUMBER (10, 0),
	d_dxccsr_fac009_123 NUMBER (10, 0),
	d_dxccsr_fac010_123 NUMBER (10, 0),
	d_dxccsr_fac012_123 NUMBER (10, 0),
	d_dxccsr_fac014_123 NUMBER (10, 0),
	d_dxccsr_fac015_123 NUMBER (10, 0),
	d_dxccsr_fac016_123 NUMBER (10, 0),
	d_dxccsr_fac017_123 NUMBER (10, 0),
	d_dxccsr_fac021_123 NUMBER (10, 0),
	d_dxccsr_fac022_123 NUMBER (10, 0),
	d_dxccsr_fac023_123 NUMBER (10, 0),
	d_dxccsr_fac024_123 NUMBER (10, 0),
	d_dxccsr_fac025_123 NUMBER (10, 0),
	d_dxccsr_gen002_123 NUMBER (10, 0),
	d_dxccsr_gen003_123 NUMBER (10, 0),
	d_dxccsr_gen004_123 NUMBER (10, 0),
	d_dxccsr_gen006_123 NUMBER (10, 0),
	d_dxccsr_gen007_123 NUMBER (10, 0),
	d_dxccsr_gen008_123 NUMBER (10, 0),
	d_dxccsr_gen011_123 NUMBER (10, 0),
	d_dxccsr_gen016_123 NUMBER (10, 0),
	d_dxccsr_gen021_123 NUMBER (10, 0),
	d_dxccsr_inf002_123 NUMBER (10, 0),
	d_dxccsr_inf003_123 NUMBER (10, 0),
	d_dxccsr_inf004_123 NUMBER (10, 0),
	d_dxccsr_inf008_123 NUMBER (10, 0),
	d_dxccsr_inj004_123 NUMBER (10, 0),
	d_dxccsr_inj005_123 NUMBER (10, 0),
	d_dxccsr_inj008_123 NUMBER (10, 0),
	d_dxccsr_inj009_123 NUMBER (10, 0),
	d_dxccsr_inj010_123 NUMBER (10, 0),
	d_dxccsr_inj012_123 NUMBER (10, 0),
	d_dxccsr_inj016_123 NUMBER (10, 0),
	d_dxccsr_inj017_123 NUMBER (10, 0),
	d_dxccsr_inj019_123 NUMBER (10, 0),
	d_dxccsr_inj026_123 NUMBER (10, 0),
	d_dxccsr_inj028_123 NUMBER (10, 0),
	d_dxccsr_inj030_123 NUMBER (10, 0),
	d_dxccsr_inj031_123 NUMBER (10, 0),
	d_dxccsr_inj033_123 NUMBER (10, 0),
	d_dxccsr_inj036_123 NUMBER (10, 0),
	d_dxccsr_inj037_123 NUMBER (10, 0),
	d_dxccsr_mal001_123 NUMBER (10, 0),
	d_dxccsr_mal002_123 NUMBER (10, 0),
	d_dxccsr_mal003_123 NUMBER (10, 0),
	d_dxccsr_mal004_123 NUMBER (10, 0),
	d_dxccsr_mal005_123 NUMBER (10, 0),
	d_dxccsr_mal006_123 NUMBER (10, 0),
	d_dxccsr_mal007_123 NUMBER (10, 0),
	d_dxccsr_mal008_123 NUMBER (10, 0),
	d_dxccsr_mal009_123 NUMBER (10, 0),
	d_dxccsr_mal010_123 NUMBER (10, 0),
	d_dxccsr_mbd002_123 NUMBER (10, 0),
	d_dxccsr_mbd005_123 NUMBER (10, 0),
	d_dxccsr_mbd007_123 NUMBER (10, 0),
	d_dxccsr_mbd014_123 NUMBER (10, 0),
	d_dxccsr_mbd015_123 NUMBER (10, 0),
	d_dxccsr_mus011_123 NUMBER (10, 0),
	d_dxccsr_mus022_123 NUMBER (10, 0),
	d_dxccsr_mus023_123 NUMBER (10, 0),
	d_dxccsr_mus026_123 NUMBER (10, 0),
	d_dxccsr_mus028_123 NUMBER (10, 0),
	d_dxccsr_neo045_123 NUMBER (10, 0),
	d_dxccsr_neo048_123 NUMBER (10, 0),
	d_dxccsr_neo056_123 NUMBER (10, 0),
	d_dxccsr_neo059_123 NUMBER (10, 0),
	d_dxccsr_neo060_123 NUMBER (10, 0),
	d_dxccsr_neo064_123 NUMBER (10, 0),
	d_dxccsr_neo070_123 NUMBER (10, 0),
	d_dxccsr_neo072_123 NUMBER (10, 0),
	d_dxccsr_neo073_123 NUMBER (10, 0),
	d_dxccsr_neo074_123 NUMBER (10, 0),
	d_dxccsr_nvs007_123 NUMBER (10, 0),
	d_dxccsr_nvs008_123 NUMBER (10, 0),
	d_dxccsr_nvs009_123 NUMBER (10, 0),
	d_dxccsr_nvs010_123 NUMBER (10, 0),
	d_dxccsr_nvs013_123 NUMBER (10, 0),
	d_dxccsr_nvs016_123 NUMBER (10, 0),
	d_dxccsr_nvs019_123 NUMBER (10, 0),
	d_dxccsr_nvs020_123 NUMBER (10, 0),
	d_dxccsr_pnl001_123 NUMBER (10, 0),
	d_dxccsr_pnl002_123 NUMBER (10, 0),
	d_dxccsr_pnl004_123 NUMBER (10, 0),
	d_dxccsr_pnl005_123 NUMBER (10, 0),
	d_dxccsr_pnl006_123 NUMBER (10, 0),
	d_dxccsr_pnl007_123 NUMBER (10, 0),
	d_dxccsr_pnl008_123 NUMBER (10, 0),
	d_dxccsr_pnl009_123 NUMBER (10, 0),
	d_dxccsr_pnl010_123 NUMBER (10, 0),
	d_dxccsr_pnl011_123 NUMBER (10, 0),
	d_dxccsr_pnl012_123 NUMBER (10, 0),
	d_dxccsr_pnl013_123 NUMBER (10, 0),
	d_dxccsr_rsp002_123 NUMBER (10, 0),
	d_dxccsr_rsp003_123 NUMBER (10, 0),
	d_dxccsr_rsp004_123 NUMBER (10, 0),
	d_dxccsr_rsp005_123 NUMBER (10, 0),
	d_dxccsr_rsp006_123 NUMBER (10, 0),
	d_dxccsr_rsp007_123 NUMBER (10, 0),
	d_dxccsr_rsp008_123 NUMBER (10, 0),
	d_dxccsr_rsp009_123 NUMBER (10, 0),
	d_dxccsr_rsp010_123 NUMBER (10, 0),
	d_dxccsr_rsp011_123 NUMBER (10, 0),
	d_dxccsr_rsp012_123 NUMBER (10, 0),
	d_dxccsr_rsp016_123 NUMBER (10, 0),
	d_dxccsr_rsp017_123 NUMBER (10, 0),
	d_dxccsr_skn001_123 NUMBER (10, 0),
	d_dxccsr_skn002_123 NUMBER (10, 0),
	d_dxccsr_skn005_123 NUMBER (10, 0),
	d_dxccsr_skn007_123 NUMBER (10, 0),
	d_dxccsr_sym002_123 NUMBER (10, 0),
	d_dxccsr_sym003_123 NUMBER (10, 0),
	d_dxccsr_sym004_123 NUMBER (10, 0),
	d_dxccsr_sym005_123 NUMBER (10, 0),
	d_dxccsr_sym006_123 NUMBER (10, 0),
	d_dxccsr_sym010_123 NUMBER (10, 0),
	d_dxccsr_sym012_123 NUMBER (10, 0),
	d_dxccsr_sym013_123 NUMBER (10, 0),
	d_dxccsr_sym014_123 NUMBER (10, 0),
	d_dxccsr_sym016_123 NUMBER (10, 0),
	d_dxccsr_sym017_123 NUMBER (10, 0),
	dqtr NUMBER (10, 0),
	drg NUMBER (10, 0),
	encounter_grp_num NUMBER (19, 0),
	fipstco VARCHAR2 (5 CHAR),
	gppd01 NUMBER (10, 0),
	gppd08 NUMBER (10, 0),
	gppd10 NUMBER (10, 0),
	gppd12 NUMBER (10, 0),
	hospid NUMBER (19, 0),
	hppd01 NUMBER (10, 0),
	hppd10 NUMBER (10, 0),
	los NUMBER (10, 0),
	mdc NUMBER (10, 0),
	mdrg NUMBER (10, 0),
	odc903 NUMBER (10, 0),
	odc904 NUMBER (10, 0),
	pagecat NUMBER (10, 0),
	paycat NUMBER (10, 0),
	popcat NUMBER (10, 0),
	racecat NUMBER (10, 0),
	sex NUMBER (10, 0),
	sexcat NUMBER (10, 0),
	tapd14 NUMBER (10, 0),
	tapd15 NUMBER (10, 0),
	tapd16 NUMBER (10, 0),
	tapd18 NUMBER (10, 0),
	tapd90 NUMBER (10, 0),
	tapd91 NUMBER (10, 0),
	tapd92 NUMBER (10, 0),
	tpnq03 NUMBER (10, 0),
	tppd01 NUMBER (10, 0),
	tppd05 NUMBER (10, 0),
	tppd08 NUMBER (10, 0),
	tppd09 NUMBER (10, 0),
	tppd10 NUMBER (10, 0),
	tppd12 NUMBER (10, 0),
	tpps17 NUMBER (10, 0),
	trnsfer NUMBER (10, 0),
	trnsfer_alt NUMBER (10, 0),
	year NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_condition_set_cd', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_condition_set_cd (
	condition_id NUMBER NOT NULL,
	external_set_cd VARCHAR2 (20 CHAR) NOT NULL,
	external_set_cd_desc VARCHAR2 (200 CHAR) NULL,
	external_set_cd_short_desc VARCHAR2 (200 CHAR) NULL,
	external_set_cd_type VARCHAR2 (20 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_hedis_audit_precursor', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_hedis_audit_precursor (
	measure_id VARCHAR2 (10 CHAR) NOT NULL,
	metric_code_clm VARCHAR2 (20 CHAR) NULL,
	metric_code_desc VARCHAR2 (100 CHAR) NOT NULL,
	metric_code_dt VARCHAR2 (20 CHAR) NULL,
	metric_code_val VARCHAR2 (20 CHAR) NULL,
	precursor_domain VARCHAR2 (20 CHAR) NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_age', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_age (
	age_range_max NUMBER (3) NOT NULL,
	age_range_min NUMBER (3) NOT NULL,
	coef_multiplier NUMBER (11, 6) NOT NULL,
	grp_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_prov_attrib_prectype', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_prov_attrib_prectype (
	prov_attrib_precur_type_desc VARCHAR2 (100 CHAR) NOT NULL,
	prov_attrib_precur_type_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_sensitive_category', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_sensitive_category (
	sensitive_cat_desc VARCHAR2 (100 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (3) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_drg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_drg (
	code_type VARCHAR2 (10 CHAR),
	drg_cd VARCHAR2 (4 CHAR),
	precursor_id NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_age_coef', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_age_coef (
	age_coef NUMBER (9, 4) NOT NULL,
	age_range_max NUMBER (3) NOT NULL,
	age_range_min NUMBER (3) NOT NULL,
	age_sq_coef NUMBER (9, 4) NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_division_region', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_division_region (
	cens_division NUMBER (10, 0) NOT NULL,
	cens_division_desc VARCHAR2 (30 CHAR),
	cens_reg NUMBER (10, 0),
	cens_reg_desc VARCHAR2 (30 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_elig_prov_code', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_elig_prov_code (
	code NUMBER (12) NOT NULL,
	code_type VARCHAR2 (20 CHAR) NOT NULL,
	elig_prov_id NUMBER (3) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_precursor_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_precursor_grp (
	precursor_grp_desc VARCHAR2 (400 CHAR) NOT NULL,
	precursor_grp_id NUMBER NOT NULL,
	sensitive_cat_id NUMBER NOT NULL,
	sensitive_ind NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_score_trans', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_score_trans (
	score_transformation_desc VARCHAR2 (200 CHAR) NOT NULL,
	score_transformation_id NUMBER (2) NOT NULL,
	score_transformation_name VARCHAR2 (25 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_epi_numer_dtl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_epi_numer_dtl (
	age_cat2 NUMBER (3) NOT NULL,
	amt_np NUMBER (19, 2) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	encounters NUMBER (19, 2) NOT NULL,
	etg_id NUMBER (3) NOT NULL,
	sev_level NUMBER NOT NULL,
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	tos1_id NUMBER NOT NULL,
	year NUMBER (4) NOT NULL,
	year_mnth NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_score_markercat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_score_markercat (
	markercat_desc VARCHAR2 (400 CHAR) NOT NULL,
	markercat_id NUMBER NOT NULL,
	markercat_name VARCHAR2 (50 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_trans', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_trans (
	grp_id NUMBER (5) NOT NULL,
	precursor_id NUMBER NOT NULL,
	score_transformation_id NUMBER (2) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_timeframe', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_timeframe (
	score_id NUMBER (5) NOT NULL,
	timeframe_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_date_range', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_date_range (
	month_code VARCHAR2 (15 CHAR) NOT NULL,
	year NUMBER (4) NOT NULL,
	year_code VARCHAR2 (10 CHAR) NOT NULL,
	year_mnth NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_phrmcy_numer_dtl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_phrmcy_numer_dtl (
	age_cat2 NUMBER (3) NOT NULL,
	amt_np NUMBER (19, 2) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	channel NUMBER (12) NULL,
	days_sup NUMBER (12) NOT NULL,
	gbo NUMBER (3) NOT NULL,
	generic NUMBER (12) NOT NULL,
	lag_months NUMBER (12) NOT NULL,
	script NUMBER (12) NOT NULL,
	script_gen NUMBER (12) NOT NULL,
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	tos_i_5 NUMBER (12) NOT NULL,
	year NUMBER (4) NOT NULL,
	year_mnth NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_prov_attrib_continue', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_prov_attrib_continue (
	continue_desc VARCHAR2 (400 CHAR) NOT NULL,
	continue_id NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_phm_num_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_phm_num_detail (
	age_cat2 NUMBER (10, 0),
	amt_np NUMBER (19, 2),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	channel NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	days_sup NUMBER (10, 0),
	gbo NUMBER (10, 0),
	generic NUMBER (10, 0),
	lag_ind NUMBER (10, 0),
	lag_months NUMBER (10, 0),
	rrisk_cat NUMBER (10, 0),
	script NUMBER (10, 0),
	script_gen NUMBER (10, 0),
	sex NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	year NUMBER (10, 0),
	year_mth NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_hedis_metric_code', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_hedis_metric_code (
	hedis_measure_id VARCHAR2 (10 CHAR) NOT NULL,
	metric_code VARCHAR2 (20 CHAR) NULL,
	metric_code_desc VARCHAR2 (100 CHAR),
	metric_code_type VARCHAR2 (20 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_cond_precur_rule', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_cond_precur_rule (
	condition_id NUMBER (12) NOT NULL,
	precursor_cnt NUMBER (13) NOT NULL,
	precursor_cnt_max_days NUMBER (22) NULL,
	precursor_cnt_min_days NUMBER (22) NULL,
	precursor_id NUMBER (12) NOT NULL,
	rule_id NUMBER (7) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_score_agg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_score_agg (
	score_aggregation_desc VARCHAR2 (200 CHAR) NOT NULL,
	score_aggregation_id NUMBER (2) NOT NULL,
	score_aggregation_name VARCHAR2 (25 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_dem_yr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_dem_yr (
	age_cat2 NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	mm NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	num_members NUMBER (10, 0),
	rrisk NUMBER (12, 4),
	rrisk_cat NUMBER (10, 0),
	sex NUMBER (10, 0),
	tot_age NUMBER (10, 0),
	year NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_admit_numer_dtl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_admit_numer_dtl (
	admit_type VARCHAR2 (3 CHAR) NOT NULL,
	admits NUMBER (10) NOT NULL,
	age_cat2 NUMBER (3) NOT NULL,
	amt_np NUMBER (19, 2) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	drg_id VARCHAR2 (12 CHAR) NOT NULL,
	fac_ip NUMBER (1) NOT NULL,
	lag_months NUMBER (12) NOT NULL,
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	tos_i_5 NUMBER (12) NOT NULL,
	year NUMBER (4) NOT NULL,
	year_mnth NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_admit_denom_dtl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_admit_denom_dtl (
	admit_type VARCHAR2 (3 CHAR) NOT NULL,
	admits NUMBER (10) NOT NULL,
	age_cat2 NUMBER (3) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	days NUMBER (10) NOT NULL,
	den_30 NUMBER (10) NOT NULL,
	den_60 NUMBER (10) NOT NULL,
	den_90 NUMBER (10) NOT NULL,
	drg_id VARCHAR2 (12 CHAR) NOT NULL,
	lag_months NUMBER (12) NOT NULL,
	num_30 NUMBER (10) NOT NULL,
	num_60 NUMBER (10) NOT NULL,
	num_90 NUMBER (10) NOT NULL,
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	year NUMBER (4) NOT NULL,
	year_mnth NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_intn_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_intn_precur (
	grp_id NUMBER (5) NOT NULL,
	interaction_id NUMBER (4) NOT NULL,
	precursor_id_1 NUMBER NOT NULL,
	precursor_id_2 NUMBER
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_sre', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_sre (
	marker_id VARCHAR2 (11 CHAR) NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_family', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_family (
	precursor_family_id NUMBER NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_date_range', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_date_range (
	month_code VARCHAR2 (10 CHAR),
	year NUMBER (10, 0),
	year_code VARCHAR2 (15 CHAR),
	year_mth NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_intn_hier', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_intn_hier (
	grp_id NUMBER (5) NOT NULL,
	interaction_id_exclude NUMBER (4) NOT NULL,
	interaction_id_exists NUMBER (4) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_timing_hier', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_timing_hier (
	"PRIORITY" NUMBER (10, 0),
	bucket_id NUMBER NOT NULL,
	grp_id NUMBER (5) NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_pop_num_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_pop_num_detail (
	admit NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	amt_np NUMBER (19, 2),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	em_svc_flag NUMBER (10, 0),
	encounters NUMBER (19, 2),
	er_util NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	lab_util NUMBER (19, 2),
	lag_ind NUMBER (10, 0),
	lag_months NUMBER (10, 0),
	los NUMBER (10, 0),
	mri_util NUMBER (19, 2),
	rad_util NUMBER (19, 2),
	rrisk_cat NUMBER (10, 0),
	script NUMBER (10, 0),
	sex NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	year NUMBER (10, 0),
	year_mth NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_value_filter', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_value_filter (
	value_filter_desc VARCHAR2 (200 CHAR) NOT NULL,
	value_filter_id NUMBER (2) NOT NULL,
	value_filter_name VARCHAR2 (25 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_intn_coef', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_intn_coef (
	coef NUMBER (9, 4) NOT NULL,
	interaction_id NUMBER (4) NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_sourcetype', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_sourcetype (
	elig_source_type_flg NUMBER NOT NULL,
	for_each_cds_ind NUMBER (1) NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_measure_category', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_measure_category (
	measure_cat1_desc VARCHAR2 (400 CHAR) NOT NULL,
	measure_cat1_id NUMBER NOT NULL,
	measure_cat2_cd VARCHAR2 (10 CHAR) NOT NULL,
	measure_cat2_desc VARCHAR2 (400 CHAR) NOT NULL,
	measure_cat2_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_hcc_dropped', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_hcc_dropped (
	destination_timeframe_id NUMBER NOT NULL,
	elig_source_type_flg NUMBER NOT NULL,
	score_id NUMBER (5) NOT NULL,
	source_timeframe_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_disprev_denom_dtl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_disprev_denom_dtl (
	age_cat2 NUMBER (3) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	disease_id NUMBER (8) NOT NULL,
	mm NUMBER (19, 2) NOT NULL,
	num_members NUMBER (19, 2) NOT NULL,
	rrisk NUMBER (12, 4) NULL,
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	year NUMBER (4) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_survival', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_survival (
	baseline_survival NUMBER (5, 4) NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_markercat_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_markercat_precur (
	markercat_id NUMBER NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_dp_den_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_dp_den_detail (
	age_cat2 NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	disease_id NUMBER (10, 0),
	mm NUMBER (19, 2),
	num_members NUMBER (19, 2),
	rrisk NUMBER (12, 4),
	rrisk_cat NUMBER (10, 0),
	sex NUMBER (10, 0),
	year NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_hedis_exception', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_hedis_exception (
	measure_name VARCHAR2 (32 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_prov_attrib_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_prov_attrib_precur (
	active_ind NUMBER (1) NOT NULL,
	elig_prov_id NUMBER (3) NOT NULL,
	elig_source_type_flg NUMBER NOT NULL,
	lookback_months NUMBER (3) NOT NULL,
	num_yr_months NUMBER (4) NOT NULL,
	proc_group_id NUMBER NULL,
	prov_attrib_precur_type_id NUMBER (3) NOT NULL,
	prov_attrib_precursor_desc VARCHAR2 (400 CHAR) NULL,
	prov_attrib_precursor_id NUMBER NOT NULL,
	prov_attrib_precursor_name VARCHAR2 (250 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_precur_coef', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_precur_coef (
	coef NUMBER (9, 4) NOT NULL,
	precursor_id NUMBER NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_cond_precur_family', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_cond_precur_family (
	condition_id NUMBER NOT NULL,
	precursor_family_cnt NUMBER (3) DEFAULT 1 NOT NULL,
	precursor_family_cnt_max_days NUMBER (4),
	precursor_family_cnt_min_days NUMBER (4) NOT NULL,
	precursor_family_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_condition', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_condition (
	active_ind NUMBER (1) NOT NULL,
	chronic_ind NUMBER (1) NOT NULL,
	condition_desc VARCHAR2 (100 CHAR) NOT NULL,
	condition_id NUMBER NOT NULL,
	condition_name VARCHAR2 (100 CHAR) NOT NULL,
	condition_set_name VARCHAR2 (40 CHAR) NOT NULL,
	external_set_cd VARCHAR2 (20 CHAR),
	inferred_months NUMBER (3) NOT NULL,
	sensitive_cat_id NUMBER (10, 0),
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precur_hm_defer', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precur_hm_defer (
	dcc VARCHAR2 (8 CHAR) NULL,
	defer_rsn_cui VARCHAR2 (200 CHAR) NULL,
	hm_type_cui VARCHAR2 (8 CHAR) NULL,
	precursor_id NUMBER NULL,
	precursor_type VARCHAR2 (50 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_ebm_precursor', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_ebm_precursor (
	denominator_ind NUMBER (1) NOT NULL,
	ebm_precursor_desc VARCHAR2 (100 CHAR) NOT NULL,
	ebm_result VARCHAR2 (10 CHAR) NOT NULL,
	numerator_ind NUMBER (1) NOT NULL,
	precursor_flg NUMBER NOT NULL,
	precursor_id NUMBER NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_adm_num_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_adm_num_detail (
	admit_type VARCHAR2 (3 CHAR),
	admits NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	amt_np NUMBER (19, 2),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	drg_id VARCHAR2 (12 CHAR),
	fac_ip NUMBER (10, 0),
	lag_ind NUMBER (10, 0),
	lag_months NUMBER (10, 0),
	sex NUMBER (10, 0),
	tos_i_5 NUMBER (10, 0),
	year NUMBER (10, 0),
	year_mth NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_imap_etg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_imap_etg (
	chronic NUMBER (1) NOT NULL,
	etg_id NUMBER (4) NOT NULL,
	etg_impact NUMBER (8) NOT NULL,
	etg_impact_desc VARCHAR2 (300 CHAR) NOT NULL,
	family NUMBER (4) NOT NULL,
	mpc NUMBER (2) NOT NULL,
	tx_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_threshold', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_threshold (
	grp_id NUMBER (5) NOT NULL,
	precursor_id NUMBER NOT NULL,
	threshold_max NUMBER NULL,
	threshold_min NUMBER
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_score_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_score_type (
	score_type_desc VARCHAR2 (500 CHAR) NOT NULL,
	score_type_display_name VARCHAR2 (50 CHAR) NOT NULL,
	score_type_id NUMBER (3) NOT NULL,
	score_type_model_name VARCHAR2 (50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_score_grp_markercat', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_score_grp_markercat (
	grp_id NUMBER (5) NOT NULL,
	markercat_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_immunization_cui', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_immunization_cui (
	immunization_cui VARCHAR2 (8 CHAR) NOT NULL,
	immunization_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_epi_denom_dtl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_epi_denom_dtl (
	age_cat2 NUMBER (3) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	epi_qty NUMBER (19, 2) NOT NULL,
	etg_id NUMBER (3) NOT NULL,
	sev_level NUMBER (3) NOT NULL,
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	tot_rrisk NUMBER (12, 4) NOT NULL,
	year NUMBER (4) NOT NULL,
	year_mnth NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp (
	grp_id NUMBER (5) NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_hcc_coded', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_hcc_coded (
	hcc_coded_desc VARCHAR2 (50 CHAR) NOT NULL,
	hcc_coded_id NUMBER (2) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precur_pos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precur_pos (
	place_of_svc VARCHAR2 (10 CHAR) NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_pop_numer_dtl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_pop_numer_dtl (
	admit NUMBER (8) NOT NULL,
	age_cat2 NUMBER (3) NOT NULL,
	amt_np NUMBER (19, 2) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	encounters NUMBER (19, 2) NOT NULL,
	er_util NUMBER (19, 2),
	lab_util NUMBER (19, 2),
	lag_months NUMBER (12) NOT NULL,
	los NUMBER (8) NOT NULL,
	mri_util NUMBER (19, 2),
	rad_util NUMBER (19, 2),
	script NUMBER (8),
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	tos_i_5 NUMBER (8) NOT NULL,
	year NUMBER (4) NOT NULL,
	year_mnth NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_agegender_coef', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_agegender_coef (
	age_range_max NUMBER (3) NOT NULL,
	age_range_min NUMBER (3) NOT NULL,
	coef NUMBER (9, 4) NOT NULL,
	coef_multiplier NUMBER (9, 4) NOT NULL,
	gender VARCHAR2 (8 CHAR) NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_score_req_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_score_req_type (
	score_req_type_desc VARCHAR2 (50 CHAR) NOT NULL,
	score_req_type_id NUMBER (2) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_prov_attrib_family', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_prov_attrib_family (
	prov_attrib_family_id NUMBER (3) NOT NULL,
	prov_attrib_family_name VARCHAR2 (50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_gender_coef', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_gender_coef (
	coef NUMBER (9, 4) NOT NULL,
	coef_multiplier NUMBER (9, 4) NOT NULL,
	gender VARCHAR2 (8 CHAR) NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_immunization', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_immunization (
	immunization_desc VARCHAR2 (255 CHAR),
	immunization_id NUMBER NOT NULL,
	sensitive_cat_id NUMBER,
	sensitive_ind NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_evt_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_evt_type (
	event_type_cui VARCHAR2 (8 CHAR) NOT NULL,
	exclude_ip_convert_ind NUMBER (1) DEFAULT 0 NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precur_spec', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precur_spec (
	precursor_id NUMBER NULL,
	specialty_id VARCHAR2 (249 CHAR) NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_score_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_score_qual (
	lower_bound NUMBER (10, 4),
	score_id NUMBER (5) NOT NULL,
	score_qual_id NUMBER (10, 0) NOT NULL,
	upper_bound NUMBER (10, 4)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_diag', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_diag (
	code_type VARCHAR2 (8 CHAR) NOT NULL,
	diag_cd VARCHAR2 (12 CHAR) NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_precursor_domain', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_precursor_domain (
	precursor_domain_cd VARCHAR2 (16 CHAR) NOT NULL,
	precursor_domain_desc VARCHAR2 (100 CHAR) NOT NULL,
	precursor_domain_flg NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_pop_den_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_pop_den_detail (
	age_cat2 NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	mm NUMBER (19, 2),
	mm_rx NUMBER (19, 2),
	rrisk NUMBER (12, 4),
	rrisk_cat NUMBER (10, 0),
	sex NUMBER (10, 0),
	year NUMBER (10, 0),
	year_mth NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_activity_type', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_activity_type (
	activity_type_cd VARCHAR2 (8 CHAR) NOT NULL,
	activity_type_desc VARCHAR2 (1000 CHAR) NOT NULL,
	activity_type_flg NUMBER NOT NULL,
	activity_type_name VARCHAR2 (50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_proc_group_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_proc_group_detail (
	detail_type VARCHAR2(9 CHAR) NOT NULL,
	event_type_cui VARCHAR2 (8 CHAR),
	modifier VARCHAR2 (2 CHAR),
	proc_group_id NUMBER (10, 0) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_score_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_score_grp (
	diag_timeframe_restriction_ind NUMBER (1) NOT NULL,
	grp_id NUMBER (5) NOT NULL,
	grp_name VARCHAR2 (50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_hcc_opportunity', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_hcc_opportunity (
	elig_source_type_flg NUMBER NOT NULL,
	py_timeframe_id NUMBER NOT NULL,
	pytd_timeframe_id NUMBER NOT NULL,
	score_id NUMBER (5) NOT NULL,
	tytd_timeframe_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_prov_attrib_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_prov_attrib_precur (
	"PRIORITY" NUMBER (10, 0),
	continue_id NUMBER (1) NULL,
	grouping_precursor_id NUMBER NULL,
	grouping_type VARCHAR2 (20 CHAR) NULL,
	min_percent_threshold NUMBER (5, 4) NULL,
	min_threshold NUMBER NULL,
	prov_attrib_id NUMBER (5) NOT NULL,
	prov_attrib_precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_pop_denom_dtl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_pop_denom_dtl (
	age_cat2 NUMBER (3) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	mm NUMBER (19, 2) NOT NULL,
	mm_rx NUMBER (19, 2) NOT NULL,
	rrisk NUMBER (12, 4) NOT NULL,
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	year NUMBER (4) NOT NULL,
	year_mnth NUMBER (6) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precur_diag_hccfilter', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precur_diag_hccfilter (
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_dict_custom_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_dict_custom_tos (
	tos1_id NUMBER (3) NULL,
	tos_custom_desc VARCHAR2 (200 CHAR) NOT NULL,
	tos_custom_id NUMBER (9) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_tos5_custom', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_tos5_custom (
	tos5_label VARCHAR2 (255 CHAR) NOT NULL,
	tos_custom_id NUMBER (12) NOT NULL,
	tos_i_5 NUMBER (12) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precur_cui', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precur_cui (
	cui VARCHAR2 (10 CHAR) NOT NULL,
	exclude_hosp_ind NUMBER NOT NULL,
	precursor_domain_cd VARCHAR2 (20 CHAR) NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_proc_etg_elig', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_proc_etg_elig (
	code_type VARCHAR2 (24 CHAR) NOT NULL,
	proc_cd VARCHAR2 (10 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_imap_age', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_imap_age (
	age NUMBER (3) NOT NULL,
	age_cat1 NUMBER (3) NOT NULL,
	age_cat2 NUMBER (3) NOT NULL,
	age_lab1 VARCHAR2 (5 CHAR) NOT NULL,
	age_lab2 VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_map_custom_tos', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_map_custom_tos (
	tos5_label VARCHAR2 (255 CHAR) NOT NULL,
	tos_custom_desc VARCHAR2 (100 CHAR) NOT NULL,
	tos_custom_id NUMBER (12) NOT NULL,
	tos_i_5 NUMBER (12) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_precursor', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_precursor (
	active_ind NUMBER (1) DEFAULT 1 NOT NULL,
	precursor_desc VARCHAR2 (400 CHAR),
	precursor_domain_cd VARCHAR2 (16 CHAR) NULL,
	precursor_id NUMBER NOT NULL,
	precursor_name VARCHAR2 (100 CHAR) NOT NULL,
	sensitive_cat_id NUMBER (10) NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_ebm_adherence', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_ebm_adherence (
	adherence_rule_id NUMBER,
	report_case_id NUMBER NULL,
	report_rule_id NUMBER NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_epi_den_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_epi_den_detail (
	age_cat2 NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	epi_qty NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	sex NUMBER (10, 0),
	year NUMBER (10, 0),
	year_mth NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_disprev_numer_dtl', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_disprev_numer_dtl (
	age_cat2 NUMBER (3) NOT NULL,
	amt_np NUMBER (19, 2) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	disease_id NUMBER (8) NOT NULL,
	disease_related_id NUMBER (8) NOT NULL,
	encounters NUMBER (19, 2) NOT NULL,
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	tos1_id NUMBER (8) NOT NULL,
	tos2_id NUMBER (8) NOT NULL,
	year NUMBER (4) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_score_default_flg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_score_default_flg (
	score_default_flg NUMBER NOT NULL,
	score_default_flg_desc VARCHAR2 (200 CHAR) NOT NULL,
	score_default_flg_name VARCHAR2 (50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_benchmk_demographics_yr', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_benchmk_demographics_yr (
	age_cat2 NUMBER (3) NOT NULL,
	cens_reg NUMBER (3) NOT NULL,
	mm NUMBER (19, 2) NOT NULL,
	mm_rx NUMBER (19, 2) NOT NULL,
	num_members NUMBER (8) NOT NULL,
	rrisk NUMBER (19, 2) NULL,
	sex NUMBER (1) NOT NULL,
	state NUMBER (3) NULL,
	tot_age NUMBER (8) NOT NULL,
	year NUMBER (4) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_intercept', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_intercept (
	intercept NUMBER (9, 4) NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_map_sensitive_category', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_map_sensitive_category (
	sensitive_cat_id NUMBER (3) NOT NULL,
	sensitive_hierarchy NUMBER NOT NULL,
	sensitive_text VARCHAR2 (100 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_prov_attrib', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_prov_attrib (
	active_ind NUMBER (1) NOT NULL,
	for_each_cds_ind NUMBER (1) NULL,
	num_yr_months NUMBER (4) NULL,
	precalc_ind NUMBER (1) NOT NULL,
	prov_attrib_desc VARCHAR2 (400 CHAR) NOT NULL,
	prov_attrib_family_id NUMBER (3) NOT NULL,
	prov_attrib_id NUMBER (5) NOT NULL,
	prov_attrib_name VARCHAR2 (100 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_map_region', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_map_region (
	cens_division NUMBER(10,0) NOT NULL,
	cens_division_desc VARCHAR2 (30 CHAR) NOT NULL,
	cens_reg NUMBER(10,0) NOT NULL,
	cens_reg_desc VARCHAR2 (30 CHAR) NOT NULL,
	city VARCHAR2 (35 CHAR),
	county_desc VARCHAR2 (40 CHAR) NOT NULL,
	county_id NUMBER(10,0) NOT NULL,
	msa VARCHAR2 (35 CHAR),
	state NUMBER(10,0) NOT NULL,
	state_desc VARCHAR2 (2 CHAR) NOT NULL,
	zip VARCHAR2 (5 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_modifier', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_modifier (
	precursor_modifier_cui VARCHAR2 (8 CHAR) NOT NULL,
	precursor_modifier_desc VARCHAR2 (200 CHAR) NOT NULL,
	precursor_modifier_flg NUMBER NOT NULL,
	precursor_modifier_name VARCHAR2 (100 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_dp_num_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_dp_num_detail (
	age_cat2 NUMBER (10, 0),
	amt_np NUMBER (19, 2),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	disease_id NUMBER (10, 0),
	disease_related_id NUMBER (10, 0),
	encounters NUMBER (19, 2),
	rrisk_cat NUMBER (10, 0),
	sex NUMBER (10, 0),
	tos1_id NUMBER (10, 0),
	tos2_id NUMBER (10, 0),
	year NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_intn_cnt', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_intn_cnt (
	cnt_grp_id NUMBER (4) NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precur_pcc', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precur_pcc (
	pcc CHAR (3) NULL,
	precursor_id NUMBER NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_score_population', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_score_population (
	score_population_desc VARCHAR2 (400 CHAR) NOT NULL,
	score_population_id NUMBER (3) NOT NULL,
	score_population_name VARCHAR2 (50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_elig_prov', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_elig_prov (
	domestic_only_ind NUMBER (1) NOT NULL,
	elig_prov_desc VARCHAR2 (400 CHAR) NOT NULL,
	elig_prov_id NUMBER (3) NOT NULL,
	elig_prov_name VARCHAR2 (100 CHAR) NOT NULL,
	use_pcp_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_precursor_cond', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_precursor_cond (
	condition_id NUMBER NOT NULL,
	precursor_id NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_precur_rlp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_precur_rlp (
	aggregate_precursor_id NUMBER NOT NULL,
	base_precursor_id NUMBER NOT NULL,
	grp_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_relative_risk', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_relative_risk (
	conversion_factor NUMBER (9, 4) NOT NULL,
	score_id NUMBER (5) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_cond_precur_fam_rule', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_cond_precur_fam_rule (
	condition_id NUMBER (12) NOT NULL,
	precursor_id NUMBER (12) NOT NULL,
	rule_id NUMBER (7) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_proc_hcc_elig', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_proc_hcc_elig (
	code_type VARCHAR2 (8 CHAR) NOT NULL,
	proc_cd VARCHAR2 (10 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_proc_peg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_proc_peg (
	code_type VARCHAR2 (10 CHAR) NOT NULL,
	peg_id VARCHAR2 (9 CHAR) NOT NULL,
	proc_cd VARCHAR2 (20 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l4_dict_score_qual', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l4_dict_score_qual (
	score_qual_desc VARCHAR2(400 CHAR) NOT NULL,
	score_qual_id NUMBER (10, 0) NOT NULL,
	score_qual_name VARCHAR2(200 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_hedis_precursor', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_hedis_precursor (
	denominator_ind NUMBER (1) NOT NULL,
	hedis_precursor_desc VARCHAR2 (100 CHAR) NOT NULL,
	hedis_result VARCHAR2 (10 CHAR) NOT NULL,
	numerator_ind NUMBER (1) NOT NULL,
	precursor_flg NUMBER NOT NULL,
	precursor_id NUMBER NOT NULL,
	sensitive_ind NUMBER (1) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ahrq_map_measure_precur', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ahrq_map_measure_precur (
	column_name VARCHAR2 (30 CHAR),
	column_value NUMBER (10, 0),
	measure_id NUMBER (10, 0),
	precursor_id NUMBER (10, 0),
	table_name VARCHAR2 (30 CHAR)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_score_cnt_grp', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_score_cnt_grp (
	cnt_grp_desc VARCHAR2 (200 CHAR) NOT NULL,
	cnt_grp_id NUMBER (4) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_hier', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_hier (
	grp_id NUMBER (5) NOT NULL,
	precursor_id_exclude NUMBER NOT NULL,
	precursor_id_exists NUMBER NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_map_score_grp_agg', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_map_score_grp_agg (
	grp_id NUMBER (5) NOT NULL,
	precursor_id NUMBER NOT NULL,
	score_aggregation_id NUMBER (2) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l3_dict_precursor_family', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l3_dict_precursor_family (
	precursor_family_desc VARCHAR2 (200 CHAR) NOT NULL,
	precursor_family_id NUMBER NOT NULL,
	precursor_family_name VARCHAR2 (50 CHAR) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_epi_num_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_epi_num_detail (
	admit NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	amt_np NUMBER (19, 2),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	em_svc_flag NUMBER (10, 0),
	encounters NUMBER (19, 2),
	er_util NUMBER (19, 2),
	etg_id NUMBER (10, 0),
	lab_util NUMBER (19, 2),
	los NUMBER (10, 0),
	mri_util NUMBER (19, 2),
	rad_util NUMBER (19, 2),
	script NUMBER (10, 0),
	sev_level NUMBER (10, 0),
	sex NUMBER (10, 0),
	tos1_id NUMBER (10, 0),
	year NUMBER (10, 0),
	year_mth NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_bmk_adm_den_detail', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_bmk_adm_den_detail (
	admit_type VARCHAR2 (3 CHAR),
	admits NUMBER (10, 0),
	age_cat2 NUMBER (10, 0),
	cat_status NUMBER (10, 0),
	cens_division NUMBER (10, 0),
	cens_reg NUMBER (10, 0),
	coverage_class NUMBER (10, 0),
	days NUMBER (10, 0),
	den_30 NUMBER (10, 0),
	den_60 NUMBER (10, 0),
	den_90 NUMBER (10, 0),
	drg_id VARCHAR2 (12 CHAR),
	lag_ind NUMBER (10, 0),
	lag_months NUMBER (10, 0),
	num_30 NUMBER (10, 0),
	num_60 NUMBER (10, 0),
	num_90 NUMBER (10, 0),
	sex NUMBER (10, 0),
	year NUMBER (10, 0),
	year_mth NUMBER (10, 0)
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    
-- This table is sourced from Combined Schema
DROP_IF_EXISTS('l2_ii_imap_codes', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l2_ii_imap_codes (
	code NUMBER (9) NULL,
	code_str VARCHAR2 (30 CHAR) NULL,
	codetype_id NUMBER (9) NOT NULL
	) 
	PCTFREE 0 NOLOGGING COMPRESS';
    END;
/


package com.optum.oadw.datatools.ii.iiUtils

import java.io.File

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ConverterUtilsTest extends FlatSpec {

  behavior of "converter utils methods"

  val spark = TestSparkSession.createSparkSession

  it should "get file extension correctly" in {
    //Arrange
    val resourceName = "/ii/dataTypeMapForTest.txt"

    //Act
    val configMap = ConverterUtils.readAllConfig(resourceName)

    //Assert
    configMap.size shouldBe 8
    configMap.keySet should contain allOf ("l1_ii_ql_ocu_pop_tos", "l1_ii_mem_enroll_contract", "l1_ii_map_icddx", "l1_ii_map_clm_type", "l1_ii_map_ed_etg_cs", "l1_ii_peer_epi_count_peg", "l1_ii_map_ebm_rule_types", "l1_ii_map_industry")
    configMap("l1_ii_ql_ocu_pop_tos").length shouldBe 28
    configMap("l1_ii_mem_enroll_contract").length shouldBe 18
    configMap("l1_ii_ql_ocu_pop_tos").filter(c => c.columnName.equalsIgnoreCase("amt_coin")).head.dataTypeSpec should contain allOf (19, 2)
  }

  it should "get correct normalized file name for ii file name" in {
    //Arrange
    val iiFileName = "l1_ii_ql_ocu_pop_tos"
    val expectedName = "ql_ocu_pop_tos"

    //Act
    val actualName = ConverterUtils.getIIFileNameNormalized(iiFileName)

    //Assert
    actualName shouldBe expectedName
  }

  it should "getEmptyParquetIIDBVersionFilesPath provide upper-case clientID in path when client ID passed in with lower case h" in {
    //Arrange
    val clientId = "h123456"
    val expectedName = s"hdfs:///${clientId.toUpperCase}/stg/external/ii/0/nodate"

    //Act
    val actualName = ConverterUtils.getEmptyParquetFilesPath("hdfs:///", clientId, "stg")

    //Assert
    actualName shouldBe expectedName
  }

  it should "getEmptyParquetIIDBVersionFilesPath provide expected s3 bucket path when s3 and client bucket provided" in {
    //Arrange
    val clientId = "datalake.h-984216.e1.d354.phi"
    val expectedName = s"s3://${clientId}/stg/external/ii/0/nodate"

    //Act
    val actualName = ConverterUtils.getEmptyParquetFilesPath("s3://", clientId, "stg")

    //Assert
    actualName shouldBe expectedName
  }

  it should "getEmptyParquetFilesPath provide upper-case clientID in path when client ID passed in with lower case h" in {
    //Arrange
    val clientId = "h123456"
    val expectedName = s"hdfs:///${clientId.toUpperCase}/stg/external/ii/0/nodate/data"

    //Act
    val actualName = ConverterUtils.getEmptyParquetFilesPath("hdfs:///", clientId, "stg") + "/data"

    //Assert
    actualName shouldBe expectedName
  }

  it should "getEmptyParquetFilesPath provide expected s3 bucket path when s3 and client bucket provided" in {
    //Arrange
    val clientId = "datalake.h-984216.e1.d354.phi"
    val expectedName = s"s3://${clientId}/stg/external/ii/0/nodate/data"

    //Act
    val actualName = ConverterUtils.getEmptyParquetFilesPath("s3://", clientId, "stg") + "/data"

    //Assert
    actualName shouldBe expectedName
  }

  it should "get correct normalized file name for bz2 file name" in {
    //Arrange
    val bZ2FFileName = "35021_H704847_QL_EMP_SPEC.txt.bz2"
    val expectedName = "QL_EMP_SPEC"

    //Act
    val actualName = ConverterUtils.getBZ2FileNameNormalized(bZ2FFileName)

    //Assert
    actualName shouldBe expectedName
  }

  it should "get correct path when process id is given" in {
    //Arrange
    val basePath = "testBasePath/"
    val clientId = "testClientId"
    val env = "dev"
    val processId = "testProcessId"
    val expectedPath = s"$basePath${clientId.toUpperCase}/$env/external/ii/$processId/"

    //Act
    val actualPath = ConverterUtils.getBz2HDFSPathForProcessId(basePath, clientId, env, processId)

    //Assert
    actualPath shouldBe expectedPath
  }

  it should "get correct date path for given process id" in {
    //Arrange
    val allDateDirsUnderProcessId: Map[String, String] = Map(
      "20180905" -> "somePath1",
      "20180906" -> "somePath2",
      "20170905" -> "somePath3"
    )
    val expected = Some("20180906", "somePath2")

    //Act
    val actual = ConverterUtils.getLatestDateDir(allDateDirsUnderProcessId)

    //Assert
    actual shouldBe expected
  }

  it should "give None in case no date directories are present" in {
    //Arrange
    val allDateDirsUnderProcessId: Map[String, String] = Map.empty
    val expected = None

    //Act
    val actual = ConverterUtils.getLatestDateDir(allDateDirsUnderProcessId)

    //Assert
    actual shouldBe expected
  }

  it should "get correct parquet location from bz2 location" in {
    //Arrange
    val bz2FilePath = "/optum/data_factory/testClientId/dev/external/ii/processId1/20180905/landed/SSPP_UNIQ_MEMBER.txt.bz2"
    val expected = "/optum/data_factory/testClientId/dev/external/ii/processId1/20180905/data/SSPP_UNIQ_MEMBER"

    //Act
    val actual = ConverterUtils.getDestinationDirForModelFromBz2Location(bz2FilePath, "SSPP_UNIQ_MEMBER")

    //Assert
    actual shouldBe expected
  }

  it should "get correct file name after stripping bz2 and txt entensions" in {
    //Arrange
    val bz2FileName = "SSPP_UNIQ_MEMBER.txt.bz2"
    val expected = "SSPP_UNIQ_MEMBER"

    //Act
    val actual = ConverterUtils.stripFileExtension(bz2FileName)

    //Assert
    actual shouldBe expected
  }

  it should "be able to read bz2 file with double pipe delimiter when column names in schema and file are not at same position and data as tabs in it" in {
    //Arrange
    val schema = StructType(Seq(StructField("month_code", StringType), StructField("year", IntegerType), StructField("year_code", StringType), StructField("year_mth", IntegerType)))
    val file = new File(this.getClass.getClassLoader.getResource("ii/BMK_DATE_RANGE.txt.bz2").getFile)

    //Act
    val dfOpt = ConverterUtils.getDataFrameForDoublePipeBz2(file.getAbsolutePath, spark, schema)
    val dataCollect = dfOpt.get.collect()

    dataCollect.length shouldBe 24
    dfOpt.get.schema.fieldNames.toList should contain allOf("year_code", "month_code", "year", "year_mth")
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("month_code")).get.dataType.simpleString shouldBe "string"
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("year")).get.dataType.simpleString shouldBe "int"
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("year_code")).get.dataType.simpleString shouldBe "string"
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("year_mth")).get.dataType.simpleString shouldBe "int"

    //data and column level checks
    dataCollect(0).getString(0) shouldBe "PPM1"
    dataCollect(1).getString(0) shouldBe "PPM2"
    dataCollect(2).getString(0) shouldBe "PPM3"

    dataCollect(0).getInt(1) shouldBe 2015
    dataCollect(1).getInt(1) shouldBe 2015
    dataCollect(2).getInt(1) shouldBe 2015

    dataCollect(0).getString(2) shouldBe "PP    "
    dataCollect(1).getString(2) shouldBe "PP   "
    dataCollect(2).getString(2) shouldBe "PP    "

    dataCollect(0).getInt(3) shouldBe 201507
    dataCollect(1).getInt(3) shouldBe 201508
    dataCollect(2).getInt(3) shouldBe 201509
  }

  it should "be able to read bz2 file with double pipe delimiter when column names in schema and file are at same position" in {
    //Arrange
    val schema = StructType(Seq(StructField("year_mth", IntegerType), StructField("year", IntegerType), StructField("year_code", StringType), StructField("month_code", StringType)))
    val file = new File(this.getClass.getClassLoader.getResource("ii/BMK_DATE_RANGE.txt.bz2").getFile)

    //Act
    val dfOpt = ConverterUtils.getDataFrameForDoublePipeBz2(file.getAbsolutePath, spark, schema)

    //Assert
    dfOpt.get.collect().length shouldBe 24
    dfOpt.get.schema.fieldNames.toList should contain allOf("year_code", "month_code", "year", "year_mth")
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("month_code")).get.dataType.simpleString shouldBe "string"
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("year")).get.dataType.simpleString shouldBe "int"
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("year_code")).get.dataType.simpleString shouldBe "string"
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("year_mth")).get.dataType.simpleString shouldBe "int"
  }

  it should "should give None as df opt on empty bz2 file" in {
    //Arrange
    val schema = StructType(Seq(StructField("abc", StringType), StructField("xyz", IntegerType)))
    val file = new File(this.getClass.getClassLoader.getResource("ii/ADM_COSTS.txt.bz2").getFile)

    //Act
    val dfOpt = ConverterUtils.getDataFrameForDoublePipeBz2(file.getAbsolutePath, spark, schema)

    //Assert
    dfOpt shouldBe None
    Validation.schemaValidationErrors.length shouldNot equal(0)
  }

  it should "should not error out on empty bz2 file with header" in {
    //Arrange
    val schema = StructType(Seq(
      StructField("admit_act_tot", IntegerType),
      StructField("conf_num", DecimalType(38, 0)),
      StructField("cost3_peer_tot", DecimalType(28, 6)),
      StructField("cost_act_tot", DecimalType(28, 6)),
      StructField("cost_peer_tot", DecimalType(28, 6)),
      StructField("days_act_tot", DecimalType(28, 6)),
      StructField("days_peer_tot", DecimalType(28, 6)),
      StructField("drg_admittyp", StringType),
      StructField("drg_id", StringType),
      StructField("drg_unit_id", StringType),
      StructField("fac_qty_elig_peer", IntegerType),
      StructField("ia_time", IntegerType),
      StructField("peer_def_id", IntegerType),
      StructField("product_id", StringType),
      StructField("provider_id", StringType),
      StructField("readmit_07_act_tot", IntegerType),
      StructField("readmit_07_peer_tot", DecimalType(28, 6)),
      StructField("readmit_30_act_tot", IntegerType),
      StructField("readmit_30_peer_tot", DecimalType(28, 6)),
      StructField("readmit_60_act_tot", IntegerType),
      StructField("readmit_60_peer_tot", DecimalType(28, 6)),
      StructField("readmit_90_act_tot", IntegerType),
      StructField("readmit_90_peer_tot", DecimalType(28, 6)),
      StructField("readmit_index_07_act_tot", IntegerType),
      StructField("readmit_index_30_act_tot", IntegerType),
      StructField("readmit_index_60_act_tot", IntegerType),
      StructField("readmit_index_90_act_tot", IntegerType),
      StructField("cost2_act_tot", DecimalType(28, 6)),
      StructField("cost2_peer_tot", DecimalType(28, 6)),
      StructField("cost3_act_tot", DecimalType(28, 6))
    ))
    val file = new File(this.getClass.getClassLoader.getResource("ii/ADM_COSTS_WITH_HEADER.txt.bz2").getFile)

    //Act
    val dfOpt =  ConverterUtils.getDataFrameForDoublePipeBz2(file.getAbsolutePath, spark, schema)

    //Assert
    dfOpt.get.schema.fieldNames.toList should contain allOf("admit_act_tot", "conf_num", "cost2_act_tot", "cost2_peer_tot", "cost3_act_tot", "cost3_peer_tot", "cost_act_tot", "cost_peer_tot", "days_act_tot", "days_peer_tot", "drg_admittyp",
      "drg_id", "drg_unit_id", "fac_qty_elig_peer", "ia_time", "peer_def_id", "product_id", "provider_id", "readmit_07_act_tot", "readmit_07_peer_tot", "readmit_30_act_tot", "readmit_30_peer_tot", "readmit_60_act_tot", "readmit_60_peer_tot",
      "readmit_90_act_tot", "readmit_90_peer_tot", "readmit_index_07_act_tot", "readmit_index_30_act_tot", "readmit_index_60_act_tot", "readmit_index_90_act_tot")
  }

  it should "be able to read text file with double-quotes and backslash as literals" in {
    //Arrange
    val schema = StructType(Seq(StructField("col1", StringType), StructField("col2", StringType), StructField("col3", StringType)))
    val file = new File(this.getClass.getClassLoader.getResource("ii/double_quote_literal.txt").getFile)

    //Act
    val dfOpt = ConverterUtils.getDataFrameForDoublePipeBz2(file.getAbsolutePath, spark, schema)
    val dataCollect = dfOpt.get.collect()

    dataCollect.length shouldBe 12
    dfOpt.get.schema.fieldNames.toList should contain allOf("col1", "col2", "col3")
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("col1")).get.dataType.simpleString shouldBe "string"
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("col2")).get.dataType.simpleString shouldBe "string"
    dfOpt.get.schema.find(f => f.name.equalsIgnoreCase("col3")).get.dataType.simpleString shouldBe "string"

    //data and column level checks
    dataCollect(0).getString(0) shouldBe "just one dq"
    dataCollect(1).getString(0) shouldBe "two dqs"
    dataCollect(2).getString(0) shouldBe "random backslash"
    dataCollect(3).getString(0) shouldBe "check existing logic"
    dataCollect(4).getString(0) shouldBe null
    dataCollect(5).getString(0) shouldBe null
    dataCollect(6).getString(0) shouldBe "escape backslash"
    dataCollect(7).getString(0) shouldBe "escaped quote"
    dataCollect(8).getString(0) shouldBe "unmatched single quote"
    dataCollect(9).getString(0) shouldBe "matched single quote"
    dataCollect(10).getString(0) shouldBe "single pipe"
    dataCollect(11).getString(0) shouldBe "single pipe at data boundary"

    dataCollect(0).getString(1) shouldBe "no \" end"
    dataCollect(1).getString(1) shouldBe "here \"it is\""
    dataCollect(2).getString(1) shouldBe "\"example xyz"
    dataCollect(3).getString(1) shouldBe "two  tabs"
    dataCollect(4).getString(1) shouldBe null
    dataCollect(5).getString(1) shouldBe "sometext"
    dataCollect(6).getString(1) shouldBe "\\\\\"abc"
    dataCollect(7).getString(1) shouldBe "abc \"123 \\\"456\""
    dataCollect(8).getString(1) shouldBe "abc '12345"
    dataCollect(9).getString(1) shouldBe "abc '12345'"
    dataCollect(10).getString(1) shouldBe "123|456|789"
    dataCollect(11).getString(1) shouldBe "|abcdef"

    dataCollect(0).getString(2) shouldBe "should see no \" end"
    dataCollect(1).getString(2) shouldBe "should see here \"it is\""
    dataCollect(2).getString(2) shouldBe "should see \"example xyz"
    dataCollect(3).getString(2) shouldBe "should see two  tabs"
    dataCollect(4).getString(2) shouldBe null
    dataCollect(5).getString(2) shouldBe "should see sometext"
    dataCollect(6).getString(2) shouldBe "should see \\\\\"abc"
    dataCollect(7).getString(2) shouldBe "should see abc \"123 \\\"456\""
    dataCollect(8).getString(2) shouldBe "should see '12345"
    dataCollect(9).getString(2) shouldBe "should see '12345'"
    dataCollect(10).getString(2) shouldBe "should see 123|456|789"
    dataCollect(11).getString(2) shouldBe "should see |abcdef"
  }

  it should "return the correct files, included and excluded for happy path" in {
    //Arrange
    val filesMap = Map(
      "9999_clientId_ocu_member_contract.txt.bz2" -> "some hdfs path for 9999_clientId_ocu_member_contract.txt.bz2",
      "9999_clientId_services_rx.txt.bz2" -> "some hdfs path for 9999_clientId_services_rx.txt.bz2",
      "9999_clientId_services_med.txt.bz2" -> "some hdfs path for 9999_clientId_services_med.txt.bz2",
      "9999_clientId_allergies.txt.bz2" -> "some hdfs path for 9999_clientId_allergies.txt.bz2",
      "9999_clientId_mem_attr_member.txt.bz2" -> "some hdfs path for 9999_clientId_mem_attr_member.txt.bz2",
      "9999_clientId_some_other_file.txt.bz2" -> "some hdfs path for 9999_clientId_some_other_file.txt.bz2"
    )

    val include = Some(Seq("l1_ii_mem_attr_member", "l1_ii_services_med"))
    val exclude = Some(Seq("l1_ii_ocu_member_contract", "l1_ii_some_other_file"))

    //Act
    val actualFiles = ConverterUtils.getBz2Files(filesMap, include, exclude, 2)

    //Assert
    actualFiles.size shouldBe 2
    actualFiles.keySet.toList should contain allOf("9999_clientId_mem_attr_member.txt.bz2", "9999_clientId_services_med.txt.bz2")
  }

  it should "return the correct files, when there are no models to include" in {
    //Arrange
    val filesMap = Map(
      "9999_clientId_ocu_member_contract.txt.bz2" -> "some hdfs path for 9999_clientId_ocu_member_contract.txt.bz2",
      "9999_clientId_services_rx.txt.bz2" -> "some hdfs path for 9999_clientId_services_rx.txt.bz2",
      "9999_clientId_services_med.txt.bz2" -> "some hdfs path for 9999_clientId_services_med.txt.bz2",
      "9999_clientId_allergies.txt.bz2" -> "some hdfs path for 9999_clientId_allergies.txt.bz2",
      "9999_clientId_mem_attr_member.txt.bz2" -> "some hdfs path for 9999_clientId_mem_attr_member.txt.bz2",
      "9999_clientId_some_other_file.txt.bz2" -> "some hdfs path for 9999_clientId_some_other_file.txt.bz2"
    )

    val include = None
    val exclude = Some(Seq("l1_ii_ocu_member_contract", "l1_ii_some_other_file"))

    //Act
    val actualFiles = ConverterUtils.getBz2Files(filesMap, include, exclude, 2)

    //Assert
    actualFiles.size shouldBe 4
    actualFiles.keySet.toList should contain allOf("9999_clientId_services_rx.txt.bz2", "9999_clientId_services_med.txt.bz2", "9999_clientId_allergies.txt.bz2", "9999_clientId_mem_attr_member.txt.bz2")
  }

  it should "return the correct files, when there are no models to exclude" in {
    //Arrange
    val filesMap = Map(
      "9999_clientId_ocu_member_contract.txt.bz2" -> "some hdfs path for 9999_clientId_ocu_member_contract.txt.bz2",
      "9999_clientId_services_rx.txt.bz2" -> "some hdfs path for 9999_clientId_services_rx.txt.bz2",
      "9999_clientId_services_med.txt.bz2" -> "some hdfs path for 9999_clientId_services_med.txt.bz2",
      "9999_clientId_allergies.txt.bz2" -> "some hdfs path for 9999_clientId_allergies.txt.bz2",
      "9999_clientId_mem_attr_member.txt.bz2" -> "some hdfs path for 9999_clientId_mem_attr_member.txt.bz2",
      "9999_clientId_some_other_file.txt.bz2" -> "some hdfs path for 9999_clientId_some_other_file.txt.bz2"
    )

    val include = Some(Seq("l1_ii_mem_attr_member", "l1_ii_services_med"))
    val exclude = None

    //Act
    val actualFiles = ConverterUtils.getBz2Files(filesMap, include, exclude, 2)

    //Assert
    actualFiles.size shouldBe 2
    actualFiles.keySet.toList should contain allOf("9999_clientId_mem_attr_member.txt.bz2", "9999_clientId_services_med.txt.bz2")
  }

  it should "return the correct files, when there are no models to exclude or include" in {
    //Arrange
    val filesMap = Map(
      "9999_clientId_ocu_member_contract.txt.bz2" -> "some hdfs path for 9999_clientId_ocu_member_contract.txt.bz2",
      "9999_clientId_services_rx.txt.bz2" -> "some hdfs path for 9999_clientId_services_rx.txt.bz2",
      "9999_clientId_services_med.txt.bz2" -> "some hdfs path for 9999_clientId_services_med.txt.bz2",
      "9999_clientId_allergies.txt.bz2" -> "some hdfs path for 9999_clientId_allergies.txt.bz2",
      "9999_clientId_mem_attr_member.txt.bz2" -> "some hdfs path for 9999_clientId_mem_attr_member.txt.bz2",
      "9999_clientId_some_other_file.txt.bz2" -> "some hdfs path for 9999_clientId_some_other_file.txt.bz2"
    )

    val include = None
    val exclude = None

    //Act
    val actualFiles = ConverterUtils.getBz2Files(filesMap, include, exclude, 2)

    //Assert
    actualFiles.size shouldBe 6
    actualFiles.keySet.toList.sorted shouldBe filesMap.keySet.toList.sorted
  }

  it should "return the correct config, when there are some models to exclude and some to include" in {
    //Arrange
    val resourceName = "dataTypeMapForTest.txt"

    val include = Some(Seq("l1_ii_ql_ocu_pop_tos", "l1_ii_map_industry"))
    val exclude = Some(Seq("l1_ii_map_ebm_rule_types", "l1_ii_mem_enroll_contract"))

    //Act
    val actualFiles = ConverterUtils.getConfigMap(resourceName, include, exclude)

    //Assert
    actualFiles.size shouldBe 2
    actualFiles.keySet.toList should contain allOf("l1_ii_ql_ocu_pop_tos", "l1_ii_map_industry")
  }

  it should "return the correct config, when there are no models to include" in {
    //Arrange
    val resourceName = "dataTypeMapForTest.txt"

    val include = None
    val exclude = Some(Seq("l1_ii_map_ebm_rule_types", "l1_ii_mem_enroll_contract"))

    //Act
    val actualFiles = ConverterUtils.getConfigMap(resourceName, include, exclude)

    //Assert
    actualFiles.size shouldBe 6
    actualFiles.keySet.toList should contain allOf("l1_ii_ql_ocu_pop_tos", "l1_ii_map_icddx", "l1_ii_map_clm_type", "l1_ii_map_ed_etg_cs", "l1_ii_peer_epi_count_peg", "l1_ii_map_industry")
  }

  it should "return the correct config, when there are no models to exclude" in {
    //Arrange
    val resourceName = "dataTypeMapForTest.txt"

    val include = Some(Seq("l1_ii_ql_ocu_pop_tos", "l1_ii_map_industry"))
    val exclude = None

    //Act
    val actualFiles = ConverterUtils.getConfigMap(resourceName, include, exclude)

    //Assert
    actualFiles.size shouldBe 2
    actualFiles.keySet.toList should contain allOf("l1_ii_ql_ocu_pop_tos", "l1_ii_map_industry")
  }

  it should "return the correct config, when there are no models to exclude and no models to include" in {
    //Arrange
    val resourceName = "dataTypeMapForTest.txt"

    val include = None
    val exclude = None

    //Act
    val actualFiles = ConverterUtils.getConfigMap(resourceName, include, exclude)

    //Assert
    actualFiles.size shouldBe 8
  }

  it should "test getSynonymMap()" in {
    val inputFileName = "IIExternalDataTypeMap-8-1.txt"
    val synonymMap = ConverterUtils.getSynonymMap(inputFileName)
    synonymMap.size shouldBe 1
    synonymMap.keySet.toList should contain ("map_ntwrk_paid_status")
    synonymMap.values.toList should contain ("map_network_paid_status")
  }
}

object TestSparkSession {
  def createSparkSession: SparkSession = {
    SparkSession.builder()
      .master("local[*]")
      .appName("Test Suite")
      .config("spark.ui.enabled", value = false)
      .config("spark.driver.bindAddress", value = "127.0.0.1")
      .config("spark.executor.memory", "2g")
      .config("spark.driver.host", "localhost")
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .config("spark.kryo.unsafe", "true")
      .config("spark.kryoserializer.buffer", "64k")
      .config("spark.serializer.objectStreamReset", "-1")
      .config("spark.broadcast.compress", "false")
      .config("spark.rdd.compress", "false")
      .config("spark.shuffle.compress", "false")
      .config("spark.sql.inMemoryColumnarStorage.compressed", "false")
      .config("spark.sql.optimizer.metadataOnly ", "false")
      .config("spark.sql.inMemoryColumnarStorage.compressed ", "false")
      .config("spark.sql.orc.compression.codec ", "false")
      .config("spark.sql.shuffle.partitions", "4")
      .config("spark.sql.optimizer.maxIterations", "28")
      .getOrCreate()
  }

  private val sync = new Object
}
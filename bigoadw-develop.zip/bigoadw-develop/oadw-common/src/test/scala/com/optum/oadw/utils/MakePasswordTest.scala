package com.optum.oadw.utils

import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner
import org.scalatest.Matchers._


@RunWith(classOf[JUnitRunner])
class MakePasswordTest extends FlatSpec {

  behavior of "MakePassword"

  it should "encrypt & decrypt password correctly" in {

    val securePassword = "oCSPYhuMZCmNIv3c0EQh60NfzC5FbGrL"
    val makePassword = new MakePassword
    val encryptedPassword = makePassword.encrypt(securePassword)
    println(s"$securePassword -> $encryptedPassword")
    val decryptedPassword = makePassword.decrypt(encryptedPassword)

    decryptedPassword shouldBe securePassword
  }
}

package com.optum.oadw.utils

import scala.collection.mutable
import org.scalatest.Matchers._
import org.scalatest.FlatSpec
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class FeatureManagerTest extends FlatSpec{

  object TestFeature extends Enumeration {
    type FeatureTest = Value

    val TestFeature1 = Value("test_feature_1")
    val TestFeature2 = Value("test_feature_2")

  }

  it should "all feature flags are true by default" in {
    val expected  = mutable.Map[Enumeration#Value,Boolean]()
    val featureManager = new FeatureManager(TestFeature)
    TestFeature.values.foreach(expected.update(_,true))

    val actual = featureManager.AllFeatures

    actual shouldBe expected
  }

  it should "feature disable override should disable expected feature" in {

    //Arrange
    val featureManager = new FeatureManager(TestFeature)
    val expected  = mutable.Map[Enumeration#Value,Boolean]()
    expected.update(TestFeature.TestFeature1,false)

    //Act
    featureManager.disable(TestFeature.TestFeature1)

    //Assert
    featureManager.DisabledFeatures.contains(TestFeature.TestFeature1) shouldBe true
  }


  it should "multiple feature disable override should disable expected features" in {

    //Arrange
    val featureManager = new FeatureManager(TestFeature)
    val expected  = mutable.Map[Enumeration#Value,Boolean]()
    expected.update(TestFeature.TestFeature1,false)
    expected.update(TestFeature.TestFeature2,false)
    val disable_features = s"${TestFeature.TestFeature1},${TestFeature.TestFeature2}"

    //Act

    featureManager.disable(disable_features)

    //Assert
    featureManager.DisabledFeatures.contains(TestFeature.TestFeature1) shouldBe true
    featureManager.DisabledFeatures.contains(TestFeature.TestFeature2) shouldBe true
  }

  it should "feature enable override should enable expected feature" in {

    //Arrange
    val featureManager = new FeatureManager(TestFeature)
    val expected = mutable.Map[Enumeration#Value,Boolean]()
    expected.update(TestFeature.TestFeature1, true)

    //Act
    featureManager.disable(TestFeature.TestFeature1)
    featureManager.DisabledFeatures.contains(TestFeature.TestFeature1) shouldBe true

    //Assert
    featureManager.enable(TestFeature.TestFeature1)
    featureManager.EnabledFeatures.contains(TestFeature.TestFeature1) shouldBe true
  }

  it should "multiple feature enable should enable expected feature" in {

    //Arrange
    val featureManager = new FeatureManager(TestFeature)
    val expected  = mutable.Map[Enumeration#Value,Boolean]()
    expected.update(TestFeature.TestFeature1,false)
    expected.update(TestFeature.TestFeature2,false)

    val enable_features = s"${TestFeature.TestFeature1},${TestFeature.TestFeature2}"

    //Act
    featureManager.disable(enable_features)
    featureManager.DisabledFeatures.contains(TestFeature.TestFeature1) shouldBe true
    featureManager.DisabledFeatures.contains(TestFeature.TestFeature2) shouldBe true

    //Assert
    featureManager.enable(enable_features)
    featureManager.EnabledFeatures.contains(TestFeature.TestFeature1) shouldBe true
    featureManager.EnabledFeatures.contains(TestFeature.TestFeature2) shouldBe true

  }

  it should "return false when disabled_feature is checked with isEnable" in {

    //Arrange
    val featureManager = new FeatureManager(TestFeature)
    val expected = mutable.Map[Enumeration#Value, Boolean]()
    expected.update(TestFeature.TestFeature1, false)

    //Act
    featureManager.disable(TestFeature.TestFeature1)
    featureManager.DisabledFeatures.contains(TestFeature.TestFeature1) shouldBe true

    //Assert
    featureManager.isEnable(TestFeature.TestFeature1) shouldBe false
  }

  it should "return true when enabled_feature is checked with isEnable" in {

    //Arrange
    val featureManager = new FeatureManager(TestFeature)
    val expected = mutable.Map[Enumeration#Value, Boolean]()
    expected.update(TestFeature.TestFeature1, true)

    //Act
    featureManager.enable(TestFeature.TestFeature1)
    featureManager.EnabledFeatures.contains(TestFeature.TestFeature1) shouldBe true

    //Assert
    featureManager.isEnable(TestFeature.TestFeature1) shouldBe true
  }

  it should "throw exception when feature_name does not exist" in {
    val featureManager = new FeatureManager(TestFeature)
    intercept[NoSuchElementException]{
      featureManager.enable("feature_name_not_exists")
    }

    intercept[NoSuchElementException]{
      featureManager.disable("feature_name_not_exists")
    }
  }
}
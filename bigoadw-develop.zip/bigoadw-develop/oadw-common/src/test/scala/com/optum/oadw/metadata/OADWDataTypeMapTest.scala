package com.optum.oadw.metadata

import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.{FlatSpec, MustMatchers}

@RunWith(classOf[JUnitRunner])
class OADWDataTypeMapTest extends FlatSpec with MustMatchers {

  behavior of "OADWDataTypeMap"

  it should "not contain duplicate enties in the map" in {
    val mapping = OADWDataTypeMap.tableColumnMapping
    val keys = mapping.groupBy(x => (x.tableName, x.columnName.toLowerCase)).map(v => (v._1, v._2.map(t => t.dataType.toLowerCase).distinct)).filter(_._2.length > 1)
    keys.toList.sortBy(_._1).foreach(x => println(s"""\"${x._1}\", \"${x._2}\""""))
    keys.size mustBe 0
  }
}

package com.optum.oadw.utils

import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ConfigFuncsTest extends FlatSpec {
  behavior of "replaceTokens"

  it should "return original template when no replacement values supplied" in {
    val template = "foo bar baz"

    val result = ConfigFuncs.replaceTokens(template)

    result shouldBe "foo bar baz"
  }

  it should "replace tokens with values from supplied map" in {
    val template = "{{foo}} bar {{baz}}"
    val replacementVals = Map("foo" -> "123", "baz" -> "456")

    val result = ConfigFuncs.replaceTokens(template, replacementVals)

    result shouldBe "123 bar 456"
  }

  it should "should overlay multiple replacement value maps taking values left to right" in {
    val template = "{{foo}} bar {{baz}}"
    val replacementVals = Seq(
      Map("foo" -> "123", "xx" -> "78"),
      Map("foo" -> "67", "baz" -> "99"))

    val result = ConfigFuncs.replaceTokens(template, replacementVals : _*)

    result shouldBe "123 bar 99"
  }

  it should "throw when a replace token is not found" in {
    val template = "{{foo}}"
    val replacementVals = Map("bar" -> "baz")

    intercept[IllegalArgumentException] {
      ConfigFuncs.replaceTokens(template, replacementVals)
    }
  }

  it should "work with replacement strings with various symbols" in {
    val template = "{{foo}}"
    val replacementVals = Map("foo" -> "/xyz/${date:yyyy-MM-dd}")

    val result = ConfigFuncs.replaceTokens(template, replacementVals)

    result shouldBe "/xyz/${date:yyyy-MM-dd}"
  }

  it should "recursively replace inner replacements" in {
    val template = "{{foo}}"
    val replacementVals = Map(
      "foo" -> "{{member}}",
      "member" -> "Marietta"
    )

    val result = ConfigFuncs.replaceTokens(template, replacementVals)

    result shouldBe "Marietta"
  }
}
package com.optum.oadw.utils

import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class SystemUtilsTest extends FlatSpec {

  behavior of "system utils methods"

  it should "return true in case of correct format string" in {
    //Arrange
    val dateStr = "08302018"
    val format = "MMddyyyy"
    val expectedResponse = true

    //Act
    val actual = SystemUtils.isCorrectDateFormat(dateStr, format)

    //Assert
    actual shouldBe expectedResponse
  }

  it should "return false in case of wrong format string" in {
    //Arrange
    val dateStr = "08-30-2018"
    val format = "MMddyyyy"
    val expectedResponse = false

    //Act
    val actual = SystemUtils.isCorrectDateFormat(dateStr, format)

    //Assert
    actual shouldBe expectedResponse
  }
}
package com.optum.oadw.utils

import java.io.File

import org.junit.ClassRule
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner
import org.scalatest.Matchers._

@RunWith(classOf[JUnitRunner])
class FileUtilsTest extends FlatSpec {

  val _tempFolder = new TemporaryFolder()

  @ClassRule
  def tempFolder = _tempFolder

  behavior of "file util methods"

  it should "get file extension correctly" in {
    //Arrange
    val fileName = "somefile.extension"

    //Act
    val ext = FileUtils.getFileExtension(fileName)

    //Assert
    ext shouldBe "extension"
  }

  it should "get file name correctly" in {
    //Arrange
    val fullPath = "/some/path/with/filename.extension"

    //Act
    val fileName = FileUtils.getFileName(fullPath)

    //Assert
    fileName shouldBe "filename.extension"
  }

  it should "correctly write file content" in {
    //Arrange
    tempFolder.create()
    val baseDir = tempFolder.newFolder()
    val relativePath = "relPath"
    val baseDirPath = baseDir.getAbsolutePath
    FileUtils.ensureDirExists(s"$baseDirPath/$relativePath")
    val content = "some content"
    val fileName = "someFile"
    val extension = "txt"

    //Act
    FileUtils.writeContentAsFile(content, fileName, extension, relativePath, baseDirPath)

    //Assert
    val file = new File(s"$baseDirPath/$relativePath/$fileName.$extension")
    file.exists() shouldBe true
    scala.io.Source.fromFile(file).getLines().mkString("\n").trim shouldBe content
  }

  it should "ensure trailing character" in {
    //Arrange
    val inputNoSlash = "input"
    val inputSlash = "input/"

    //Act
    val output1 = FileUtils.ensureTrailingCharacter(inputNoSlash, '/')
    val output2 = FileUtils.ensureTrailingCharacter(inputSlash, '/')

    //Assert
    output1 shouldBe s"$inputNoSlash/"
    output2 shouldBe s"$inputNoSlash/"
  }

  it should "ensure trailing character is not present" in {
    //Arrange
    val inputNoSlash = "input"
    val inputSlash = "input/"

    //Act
    val output1 = FileUtils.ensureNonTrailingCharacter(inputNoSlash, '/')
    val output2 = FileUtils.ensureNonTrailingCharacter(inputSlash, '/')

    //Assert
    output1 shouldBe inputNoSlash
    output2 shouldBe inputNoSlash
  }

  it should "correctly replace file extension" in {
    //Arrange
    val newExt = "newExt"
    val fileName = "fileName"
    val oldExtension = "oldExt"
    val path = "/some/path/"
    val file1 = s"$fileName.$oldExtension"
    val file2 = s"$path$fileName.$oldExtension"
    val file3 = s"$path$fileName.$oldExtension.$oldExtension"
    val expected1 = s"$fileName.$newExt"
    val expected2 = s"$path$fileName.$newExt"
    val expected3 = s"$path$fileName.$oldExtension.$newExt"

    //Act
    val actual1 = FileUtils.replaceFileExtension(file1, newExt)
    val actual2 = FileUtils.replaceFileExtension(file2, newExt)
    val actual3 = FileUtils.replaceFileExtension(file3, newExt)

    //Assert
    actual1 shouldBe expected1
    actual2 shouldBe expected2
    actual3 shouldBe expected3
  }

  it should "get files with matching pattern" in {
    //Arrange
    tempFolder.create()
    val pattern = "filePattern"
    val file1 = tempFolder.newFile(s"${pattern}_1")
    val file2 = tempFolder.newFile(s"${pattern}_2")
    val file3 = tempFolder.newFile(s"${pattern}_3")

    //Act
    val files = FileUtils.getFilesMatchingPattern(pattern, file1.getParentFile.getAbsolutePath)

    //Assert
    files.length shouldBe 3
  }
}
package com.optum.oadw.metadata


import com.optum.oadw.utils.DatatypeValidatorHelper
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.FlatSpec

import scala.util.matching.Regex

@RunWith(classOf[JUnitRunner])
class OracleDatatypeValidatorTest extends FlatSpec {
  // More invalid datatypes can be added to this list in future
  private val invalidDatatypePatterns = List{"\\s+VARCHAR\\d*\\s*\\(\\d+\\)".r}
  // Look for "AS <invalid datatype> in view definitions
  private val invalidCastPatterns: List[Regex] = invalidDatatypePatterns.map(p => ("\\s+AS" + p.toString()).r)

  private val sampleBadTableInput = "inputs/sample_bad_oracle_schema.sql"
  private val sampleBadViewInput = "inputs/sample_bad_oracle_view.sql"
  private val tableFilter = "'CREATE TABLE"
  private val viewFilter = "'CREATE OR REPLACE VIEW"

  private def lineFilterFn(l: String) : Boolean = {
    l.startsWith("--") || (l.startsWith("DROP_IF_EXISTS") && l.endsWith(";"))
  }

  private def tnameFn(th : String) :String = {
    th.split("TABLE")(1).trim.stripSuffix("(").trim.toLowerCase
  }

  private def vnameFn(vh : String) : String = {
    vh.split("\\s+").last.toLowerCase
  }


  it should "throw IllegalStateException for sample bad table input" in {
    assertThrows[java.lang.IllegalStateException] {
      DatatypeValidatorHelper.checkInvalidDatatypes(sampleBadTableInput, invalidDatatypePatterns, invalidCastPatterns,
      lineFilterFn, tableFilter, viewFilter, tnameFn, vnameFn)
    }
  }

  it should "throw IllegalStateException for sample bad view input" in {
    assertThrows[java.lang.IllegalStateException] {
      DatatypeValidatorHelper.checkInvalidDatatypes(sampleBadViewInput, invalidDatatypePatterns, invalidCastPatterns,
        lineFilterFn, tableFilter, viewFilter, tnameFn, vnameFn)
    }
  }

  it should "test oadw_combined_schema.sql for invalid datatypes" in {
    DatatypeValidatorHelper.checkInvalidDatatypes("oracle-schema/oadw_combined_schema.sql",
      invalidDatatypePatterns, invalidCastPatterns, lineFilterFn, tableFilter, viewFilter, tnameFn, vnameFn)
  }

  it should "test epsilon_combined_schema.sql for invalid datatypes" in {
    DatatypeValidatorHelper.checkInvalidDatatypes("oracle-schema/epsilon_combined_schema.sql",
      invalidDatatypePatterns, invalidCastPatterns, lineFilterFn, tableFilter, viewFilter, tnameFn, vnameFn)
  }

}

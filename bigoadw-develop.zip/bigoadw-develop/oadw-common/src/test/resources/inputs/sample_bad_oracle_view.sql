CREATE OR REPLACE FUNCTION safe_to_number (p_txt IN VARCHAR2
                                          ,p_format IN VARCHAR2 := NULL)
  RETURN NUMBER
  DETERMINISTIC
IS
  v_number  number;
BEGIN
  IF p_format IS NOT NULL THEN
    v_number := to_number(p_txt, p_format);
  ELSE
    v_number := to_number(p_txt);
    if to_char(v_number)='~' then
      v_number := NULL;
    END IF;
  END IF;
  RETURN v_number;
EXCEPTION WHEN value_error THEN
  RETURN NULL;
END safe_to_number;
/


-- Auto-generated content from ii_external_schema.hql
DECLARE
    PROCEDURE DROP_IF_EXISTS (objectName IN VARCHAR2, objectType IN VARCHAR2 )
    IS
    v_counter number:=0;
    BEGIN

        IF (objectType = 'TABLE') THEN
        select count(*) into v_counter from user_tables where table_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName || ' CASCADE CONSTRAINTS PURGE';
        end if;
        END IF;

        IF (objectType = 'VIEW') THEN
        select count(*) into v_counter from user_views where view_name = upper(objectName);
        if v_counter > 0 then
            execute immediate 'DROP ' || objectType || ' ' || objectName;
        end if;
        END IF;

        commit;

    END;
BEGIN

-- This table is sourced from II
DROP_IF_EXISTS('l1_sample1', 'TABLE');
EXECUTE IMMEDIATE 'CREATE TABLE l1_sample1 (
	col1 VARCHAR2 (40 CHAR),
	col2 VARCHAR2 (40 CHAR),
	col3 NUMBER (38, 10),
	col4 TIMESTAMP
	)
	PCTFREE 0 NOLOGGING COMPRESS';

-- This view is sourced from II
DROP_IF_EXISTS('l2_ii_subscriber', 'VIEW');
EXECUTE IMMEDIATE 'CREATE OR REPLACE VIEW l2_sample1
AS SELECT col1, CAST(col2 AS VARCHAR2 (4000)) AS col2, col3 FROM l1_sample1';

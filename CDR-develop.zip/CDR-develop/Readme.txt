Custom CDR scale

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.centricityv2_patient_cache
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object PATIENT_PART1_CACHE extends FETableInfo[centricityv2_patient_cache] {

  override def name: String = "PATIENT_PART1_CACHE"

  override def dependsOn: Set[String] = Set("CENTRICV2_REGISTRATION", "CENTRICV2_PATIENTETHNICITY", "CENTRICV2_PATIENTRACE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val genderField = if (groupId == "H302436") "'c.'||sex" else "Sex"
    val MRNRegistration = if (groupId == "H770494") "R.PATIENTID" else "R.Medrecno"

    sparkSession.sql(
      """
        | select *,
        | row_number() over (partition by patientid order by lastupdateddate desc nulls first ) as rownumber
        | ,row_number() over (partition by patientid,lower(firstname) order by lastupdateddate desc nulls first ) as first_row
        | ,row_number() over (partition by patientid,lower(mi) order by lastupdateddate desc nulls first ) as mi_row
        | ,row_number() over (partition by patientid,lower(lastname) order by lastupdateddate desc nulls first ) as last_row
        | ,row_number() over (partition by patientid,lower(city) order by lastupdateddate desc nulls last ) as city_row
        | ,row_number() over (partition by patientid,lower(state) order by lastupdateddate desc nulls first ) as state_row
        | ,row_number() over (partition by patientid,zipcode order by lastupdateddate desc nulls first ) as zip_row
        | ,row_number() over (partition by patientid,lower(gender) order by lastupdateddate desc nulls first ) as gender_row
        | ,row_number() over (partition by patientid,lower(nullif(concat_ws('', addressline1, addressline2, city, state, zipcode), '')) order by lastupdateddate desc nulls first ) as adder_row
        | ,row_number() over (partition by patientid,homephone,workphone  order by lastupdateddate desc nulls first ) as contact_row
        | ,row_number() over (partition by patientid,maritalstatus order by lastupdateddate desc nulls first ) as marital_row
        | ,row_number() over (partition by patientid,language order by lastupdateddate desc nulls first ) as language_row
        | ,row_number() over (partition by patientid,deathindicator order by lastupdateddate desc nulls first ) as deathindicator_row
        | ,row_number() over (partition by patientid order by ethn_last_modified desc nulls last, lastupdateddate desc nulls last ) as ethnicity_row
        | ,row_number() over (partition by patientid order by race_last_modified desc nulls last, lastupdateddate desc nulls last ) as race_row
        | from ( SELECT
        |  '{groupid}' as groupid
        |,'registration'                                  as datasrc
        |,{client_ds_id}                                 as client_ds_id
        | ,R.Pid                                       AS patientid
        |,{MRN_Registration}                            AS medicalrecordnumber
        |,R.Dateofbirth                               AS dateofbirth
        |,R.Dateofdeath                               AS dateofdeath
        |,R.Pstatus                                   AS deathindicator
        |,case when R.race <> '0' then R.race when R.ethnicitymid <> '0' then cast(R.ethnicitymid as string) when PE.patientethnicitymid <> '0' then cast(PE.patientethnicitymid as string) else null end  AS ethnicity
        |,R.Firstname                                 AS firstname
        |,{gender_field}                                   AS gender
        |,coalesce(R.preflang,nvl2(R.languageid,concat_ws('', {client_ds_id}, '.', R.languageid),null))                                  AS language
        |,case when nullif(substr(R.Lastname,1,5), '') = '<MRG>' then nullif(substr(R.Lastname,6), '')  else R.Lastname end AS lastname
        |,case when nullif(substr(R.Lastname,1,5), '') = '<MRG>' then 'Y' else 'N' end as inactive
        |,R.Maritalstatus                             AS maritalstatus
        |,R.Middlename                                AS mi
        |,case when R.race <> '0' then R.race  when R.racemid <> '0' then cast(R.racemid as string) when PR.patientracemid <> '0' then cast(PR.patientracemid as string) else null end as race
        |,R.Db_Updated_Date                           AS lastupdateddate
        |,case when length(R.STATE) = 2 then R.state else null end   AS state
        |--,nullif(substr(nullif(trim(regexp_replace(R.Zip, 'O', '0')), ''),1,5), '')                AS zipcode
        |,regexp_replace(substr(trim(R.Zip),1,5),'O','0') AS zipcode
        |,R.Address1                                  AS addressline1
        |,R.Address2                                  AS addressline2
        |,NULL					                              AS address_type
        |,R.City                                      AS city
        |,R.Workphone                                 AS workphone
        |,R.Altphone                                  AS homephone
        |,R.Email                                     AS email
        |,regexp_replace(R.cellphone,'[^0-9]',' ')    AS cell_phone
        |,PR.lastmodified as race_last_modified
        |,PE.lastmodified as ethn_last_modified
        |  FROM CENTRICV2_REGISTRATION R
        |  left join CENTRICV2_PATIENTRACE PR on R.pid = PR.pid
        |  left join CENTRICV2_PATIENTETHNICITY PE on R.pid = PE.pid
        |          where ispatient='Y'
        |          and   lower(lastname) not like 'yytrain%'
        |
        |)
    """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{gender_field}", genderField).
        replace("{MRN_Registration}", MRNRegistration)
    )

  }

}

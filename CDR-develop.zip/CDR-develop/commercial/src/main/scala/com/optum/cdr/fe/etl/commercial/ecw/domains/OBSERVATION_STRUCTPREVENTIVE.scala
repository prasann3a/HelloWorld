package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, observation}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_STRUCTPREVENTIVE extends FETableInfo[observation]{

  override def name: String = "OBSERVATION_STRUCTPREVENTIVE"

  override def dependsOn: Set[String] = Set("STRUCTPREVENTIVE", CDRFEParquetNames.clinicalencounter, "ZCM_OBSTYPE_CODE", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val detailIds = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTPREVENTIVE", "OBSERVATION",
      "STRUCTPREVENTIVE", "DETAILID").mkString(",")

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,obsdate
        |       ,localcode
        |       ,localresult
        |       ,obstype
        |       ,null              AS obsresult
        |       ,local_obs_unit
        |       ,obstype_std_units AS std_obs_unit
        |FROM
        |(
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                                                              AS groupid
        |		       ,'structpreventive'                                                                                                       AS datasrc
        |		       ,{client_ds_id}                                                                                                           AS client_ds_id
        |		       ,CASE WHEN prev.DetailID IN ({detail_ids}) THEN CASE
        |		             WHEN prev.notes IS NOT NULL THEN nullif(SUBSTR(prev.notes,1,255),'')
        |		             WHEN prev.notes IS NULL AND nullif(SUBSTR(prev.Hum_value,1,255),'') IS NOT NULL THEN 'Pt Advised' END ELSE NULL END AS localresult
        |		       ,concat_ws('','{client_ds_id_prefix}',prev.Itemid)                                                                        AS localcode
        |		       ,prev.Hum_Date                                                                                                            AS obsdate
        |		       ,cEnc.Patientid                                                                                                           AS patientid
        |		       ,cEnc.Encounterid                                                                                                         AS encounterid
        |		       ,z.obstype
        |		       ,z.obsregex
        |		       ,z.obsconvfactor
        |		       ,z.datatype
        |		       ,z.begin_range
        |		       ,z.end_range
        |		       ,z.ROUND_PREC
        |		       ,z.localunit                                                                                                              AS local_obs_unit
        |		       ,z.obstype_std_units
        |		       ,z.localunit_cui
        |		       ,z.conv_Fact
        |		       ,z.function_applied
        |		       ,ROW_NUMBER() OVER (PARTITION BY cEnc.PatientID,cEnc.EncounterID,prev.Itemid,z.obstype ORDER BY prev.Hum_Date DESC NULLS LAST) rn
        |		FROM
        |		(
        |			SELECT  *
        |			FROM
        |			(
        |				SELECT  prev.*
        |				       ,ROW_NUMBER() OVER (PARTITION BY prev.EncounterID,prev.Itemid ORDER BY prev.Hum_Date DESC NULLS LAST,prev.notes NULLS last) rn
        |				FROM STRUCTPREVENTIVE prev
        |				WHERE coalesce(prev.notes,prev.hum_value) IS NOT NULL
        |				AND prev.Hum_Date IS NOT NULL
        |			)
        |			WHERE rn=1
        |		) prev
        |		JOIN {CLINICALENCOUNTER} cEnc
        |		  ON (prev.encounterid = cEnc.encounterid AND cEnc.client_ds_id = {client_ds_id})
        |		JOIN ZCM_OBSTYPE_CODE z
        |		  ON (z.obscode = concat_ws('', '{client_ds_id_prefix}', prev.itemid) AND z.groupid = '{groupid}' AND z.datasrc = 'structpreventive')
        |	)
        |	WHERE rn = 1
        |)
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{detail_ids}", detailIds)
    )
  }


}

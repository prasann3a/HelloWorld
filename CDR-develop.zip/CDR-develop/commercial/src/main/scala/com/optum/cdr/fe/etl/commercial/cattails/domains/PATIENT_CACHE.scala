package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.cdr.fe.etl.commercial.cattails_patient_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PATIENT_CACHE extends FEQueryAndMetadata[cattails_patient_cache]{

  override def name: String = "PATIENT_CACHE"

  override def dependsOn: Set[String] = Set("PATIENT_HISTORIES_TB", "PATIENTS_TB", "PATIENT_FAC_GRP_SEG_TB")

  override def sparkSql: String =

      """
        |with dedup_pat_hist as (select   *
        |                         from ( select ph.patient_id
        |                                      ,PH.Ethnicity_Id AS Ethnicity_Id
        |                                      ,PH.Oral_Language_Code AS Oral_Language_Code
        |                                      ,PH.Current_Marital_Status_Id AS Current_Marital_Status_Id
        |                                      ,row_number() over (partition by patient_id order by last_modified_date desc nulls last) as pht_rn
        |                                from PATIENT_HISTORIES_TB ph
        |                              )
        |                         where pht_rn=1 )
        |, dedup_pat as (select    *
        |                   from (select  PT.Patient_Id AS patient_id
        |                                ,PT.Mhn AS Mhn
        |                                ,PT.Dob AS Dob
        |                                ,PT.Deceased_Date AS Deceased_Date
        |                                ,PT.Deceased_Code AS Deceased_Code
        |                                ,PT.First_Name AS first_name
        |                                ,PT.Gender_Code AS Gender_Code
        |                                ,PT.Last_Name AS last_name
        |                                ,PT.Middle_Name AS middle_name
        |                                ,pt.last_modified_date as updatedate
        |                                ,row_number() over (partition by Patient_ID  order by Last_Modified_Date desc nulls last ) as pat_rn
        |                           from PATIENTS_TB pt
        |                           WHERE lower(pt.last_name) not like '%patient%' )
        |                   where pat_rn = 1)
        |, dedup_pat_grp as (select    *
        |                     from (select PFG.patient_id
        |                                 ,PFG.Current_Activity_Code
        |                                 ,row_number() over (partition by Patient_ID  order by Last_Modified_Date desc nulls last ) as pat_grp_rn
        |                            from PATIENT_FAC_GRP_SEG_TB PFG )
        |                     where pat_grp_rn=1)
        |SELECT '{groupid}' as groupid
        |  ,'patients_tb' as datasrc
        |  ,{client_ds_id} as client_ds_id
        |  ,PTP.Patient_Id AS patientid
        |  ,PTP.Mhn AS alternativepatientid
        |  ,PTP.Dob AS dateofbirth
        |  ,PTP.Deceased_Date AS dateofdeath
        |  ,concat_ws('', '{client_ds_id}', '.', PTP.Deceased_Code) AS deathindicator
        |  ,concat_ws('', '{client_ds_id}', '.', PHT.Ethnicity_Id) AS ethnicity
        |  ,PTP.First_Name AS firstname
        |  ,concat_ws('', '{client_ds_id}', '.', PTP.Gender_Code) AS gender
        |  ,Case when PFG.Current_Activity_Code = 'N' then 'Y' else 'N' end AS inactiveflag
        |  ,concat_ws('', '{client_ds_id}', '.', PHT.Oral_Language_Code) AS language
        |  ,PTP.Last_Name AS lastname
        |  ,concat_ws('', '{client_ds_id}', '.', PHT.Current_Marital_Status_Id) AS maritalstatus
        |  ,PTP.Middle_Name AS middlename
        |  ,ptp.updatedate as patdetail_timestamp
        |FROM DEDUP_PAT PTP
        |INNER JOIN DEDUP_PAT_GRP PFG ON (PFG.PATIENT_ID = PTP.PATIENT_ID)
        |left outer JOIN DEDUP_PAT_HIST PHT ON (PTP.Patient_ID = PHT.Patient_ID)
      """
      .stripMargin

}

package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object DIAGNOSIS extends FEQueryAndMetadata[diagnosis]{

  override def name: String = CDRFEParquetNames.diagnosis

  override def dependsOn: Set[String] = Set("ASPRO_DIAGNOSIS", "ENCOUNTERS", "HXDIAGNOSIS")

  override def sparkSql: String =
    """
      |SELECT  groupid
      |       ,datasrc
      |       ,patientid
      |       ,encounterid
      |       ,facilityid
      |       ,dx_timestamp
      |       ,localdiagnosis
      |       ,primarydiagnosis
      |       ,localpresentonadmission
      |       ,codetype
      |       ,mappeddiagnosis
      |       ,localdiagnosisstatus
      |       ,client_ds_id
      |       ,LOCALACTIVEIND
      |FROM
      |(
      |	SELECT  distinct groupid
      |	       ,datasrc
      |	       ,patientid
      |	       ,encounterid
      |	       ,facilityid
      |	       ,dx_timestamp
      |	       ,localdiagnosis
      |	       ,primarydiagnosis
      |	       ,localpresentonadmission
      |	       ,codetype
      |	       ,mappeddiagnosis
      |	       ,localdiagnosisstatus
      |	       ,{client_ds_id} as client_ds_id
      |	       ,LOCALACTIVEIND
      |	FROM
      |	(
      |		SELECT  DISTINCT '{groupid}'                                                   AS groupid
      |		       ,'diagnosis'                                                            AS datasrc
      |		       ,d.imredemec_code                                                       AS patientid
      |		       ,d.imreenc_code                                                         AS encounterid
      |		       ,NULL                                                                   AS facilityid
      |		       ,d.dx_onsetdate                                                         AS dx_timestamp
      |		       ,d.dx_code                                                              AS localdiagnosis
      |		       ,NULL                                                                   AS primarydiagnosis
      |		       ,NULL                                                                   AS localpresentonadmission
      |		       ,CASE WHEN upper(d.dx_source) like 'ICD9' THEN 'ICD9'
      |		             WHEN upper(d.dx_source) like 'ICD10' THEN 'ICD10'
      |		             WHEN upper(d.dx_source) like 'SNOMED' THEN 'SNOMED' ELSE null END AS codetype
      |		       ,CASE WHEN d.dx_source='ICD9' AND d.dx_code = '250.' THEN '250.00'
      |		             WHEN d.dx_source='ICD9' AND d.dx_code <> '250.' AND d.dx_code like '%.' THEN nullif(rtrim('.',d.dx_Code),'')
      |		             WHEN d.dx_source IN ('ICD9','ICD10') THEN d.dx_code ELSE null END AS mappeddiagnosis
      |		       ,d.dx_category                                                          AS localdiagnosisstatus
      |		       ,concat_ws('','asp.',d.Dx_Activity)                                     AS localactiveind
      |		       ,ROW_NUMBER() OVER (PARTITION BY d.imreenc_code,d.imreenc_code,d.dx_code,d.dx_onsetdate ORDER BY d.dx_onsetdate DESC nulls last) rownumber
      |		FROM ASPRO_DIAGNOSIS d
      |		WHERE d.tag_systemdate > TO_DATE('20050101','yyyyMMdd')
      |		AND d.dx_source <> 'FREETEXT'
      |		AND d.dx_category IN ( '24','29')
      |
      |          union
      |
      |		SELECT  DISTINCT '{groupid}'                                                   AS groupid
      |		       ,'diagnosis'                                                            AS datasrc
      |		       ,d.imredemec_code                                                       AS patientid
      |		       ,d.imreenc_code                                                         AS encounterid
      |		       ,NULL                                                                   AS facilityid
      |		       ,e.enc_chartpulltime                                                    AS dx_timestamp
      |		       ,d.dx_code                                                              AS localdiagnosis
      |		       ,NULL                                                                   AS primarydiagnosis
      |		       ,NULL                                                                   AS localpresentonadmission
      |		       ,CASE WHEN upper(d.dx_source) like 'ICD9' THEN 'ICD9'
      |		             WHEN upper(d.dx_source) like 'ICD10' THEN 'ICD10'
      |		             WHEN upper(d.dx_source) like 'SNOMED' THEN 'SNOMED' ELSE null END AS codetype
      |		       ,CASE WHEN d.dx_source='ICD9' AND d.dx_code = '250.' THEN '250.00'
      |		             WHEN d.dx_source='ICD9' AND d.dx_code <> '250.' AND d.dx_code like '%.' THEN nullif(rtrim('.',d.dx_Code),'')
      |		             WHEN d.dx_source IN ('ICD9','ICD10') THEN d.dx_code ELSE null END AS mappeddiagnosis
      |		       ,d.dx_category                                                          AS localdiagnosisstatus
      |		       ,concat_ws('','asp.',d.Dx_Activity)                                     AS localactiveind
      |		       ,ROW_NUMBER() OVER (PARTITION BY d.imreenc_code,d.imreenc_code,d.dx_code,e.enc_chartpulltime ORDER BY e.enc_chartpulltime DESC nulls last) rownumber
      |		FROM ASPRO_DIAGNOSIS d
      |		LEFT OUTER JOIN ENCOUNTERS e
      |		ON (e.imreenc_code = d.imreenc_code)
      |		WHERE d.tag_systemdate > TO_DATE('20050101','yyyyMMdd')
      |		AND d.dx_source <> 'FREETEXT'
      |		AND d.dx_category IN ('24','29')
      |	)
      |	WHERE rownumber = 1
      |	AND dx_timestamp is not null
      |	AND patientid is not null
      |)
      |
      |UNION ALL
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,patientid
      |       ,encounterid
      |       ,facilityid
      |       ,dx_timestamp
      |       ,localdiagnosis
      |       ,primarydiagnosis
      |       ,localpresentonadmission
      |       ,codetype
      |       ,mappeddiagnosis
      |       ,localdiagnosisstatus
      |       ,client_ds_id
      |       ,null as LOCALACTIVEIND
      |FROM
      |(
      |	SELECT  distinct groupid
      |	       ,datasrc
      |	       ,patientid
      |	       ,encounterid
      |	       ,facilityid
      |	       ,dx_timestamp
      |	       ,localdiagnosis
      |	       ,primarydiagnosis
      |	       ,localpresentonadmission
      |	       ,codetype
      |	       ,mappeddiagnosis
      |	       ,localdiagnosisstatus
      |	       ,{client_ds_id} as client_ds_id
      |	FROM
      |	(
      |		SELECT  DISTINCT '{groupid}'                                                    AS groupid
      |		       ,'hxdiagnosis'                                                           AS datasrc
      |		       ,d.patient_id                                                            AS patientid
      |		       ,d.imreenc_code                                                          AS encounterid
      |		       ,NULL                                                                    AS facilityid
      |		       ,d.onset_date                                                            AS dx_timestamp
      |		       ,d.source_code                                                           AS localdiagnosis
      |		       ,NULL                                                                    AS primarydiagnosis
      |		       ,NULL                                                                    AS localpresentonadmission
      |		       ,CASE WHEN upper(d.source) like 'ICD9' THEN 'ICD9'
      |		             WHEN upper(d.source) like 'ICD10' THEN 'ICD10'
      |		             WHEN upper(d.source) like 'SNOMED' THEN 'SNOMED' ELSE null END     AS codetype
      |		       ,CASE WHEN d.source='ICD9' AND d.source_code = '250.' THEN '250.00'
      |		             WHEN d.source='ICD9' AND d.source_code <> '250.' AND d.source_code like '%.' THEN nullif(rtrim('.',d.source_Code),'')
      |		             WHEN d.source IN ('ICD9','ICD10') THEN d.source_code ELSE null END AS mappeddiagnosis
      |		       ,d.category_code                                                         AS localdiagnosisstatus
      |		       ,ROW_NUMBER() OVER (PARTITION BY d.imreenc_code,d.imreenc_code,d.source_code,d.onset_date ORDER BY d.onset_date DESC nulls last) rownumber
      |		FROM HXDIAGNOSIS d
      |		WHERE d.tag_systemdate > TO_DATE('20050101','yyyyMMdd')
      |		AND d.source_code <> 'FREETEXT'
      |		AND d.category_code IN ('24','29')
      |
      |          union
      |
      |		SELECT  DISTINCT '{groupid}'                                                    AS groupid
      |		       ,'hxdiagnosis'                                                           AS datasrc
      |		       ,d.patient_id                                                            AS patientid
      |		       ,d.imreenc_code                                                          AS encounterid
      |		       ,NULL                                                                    AS facilityid
      |		       ,d.tag_systemdate                                                        AS dx_timestamp
      |		       ,d.source_code                                                           AS localdiagnosis
      |		       ,NULL                                                                    AS primarydiagnosis
      |		       ,NULL                                                                    AS localpresentonadmission
      |		       ,CASE WHEN upper(d.source) like 'ICD9' THEN 'ICD9'
      |		             WHEN upper(d.source) like 'ICD10' THEN 'ICD10'
      |		             WHEN upper(d.source) like 'SNOMED' THEN 'SNOMED' ELSE null END     AS codetype
      |		       ,CASE WHEN d.source='ICD9' AND d.source_code = '250.' THEN '250.00'
      |		             WHEN d.source='ICD9' AND d.source_code <> '250.' AND d.source_code like '%.' THEN nullif(rtrim('.',d.source_Code),'')
      |		             WHEN d.source IN ('ICD9','ICD10') THEN d.source_code ELSE null END AS mappeddiagnosis
      |		       ,d.category_code                                                         AS localdiagnosisstatus
      |		       ,ROW_NUMBER() OVER (PARTITION BY d.imreenc_code,d.imreenc_code,d.source_code,d.tag_systemdate ORDER BY d.tag_systemdate DESC nulls last) rownumber
      |		FROM HXDIAGNOSIS d
      |		WHERE d.tag_systemdate > TO_DATE('20050101','yyyyMMdd')
      |		AND d.source_code <> 'FREETEXT'
      |		AND d.category_code IN ('24','29')
      |	)
      |	WHERE rownumber = 1
      |	AND dx_timestamp is not null
      |	AND patientid is not null
      |)
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object ZH_FACILITY extends FEQueryAndMetadata[zh_facility]{

  override def name: String = CDRFEParquetNames.zh_facility

  override def dependsOn: Set[String] = Set("LSS_DPBRLOCATION")

  override def sparkSql: String =
    """
      |SELECT facilityid,facilityname,facilitypostalcd,npi
      |FROM (
      |   SELECT x.*
      |       ,row_number() over (partition by facilityid order by RowUpdateDateTime desc nulls last, FacilityName desc) as rownumber
      |   from (
      |       SELECT
      |          NULLIF(CONCAT_WS('', dpb.Sourceid, dpb.Locationid), '') AS facilityid
      |         ,dpb.Name AS facilityname
      |         ,dpb.Postalcodeid AS facilitypostalcd
      |         ,dpb.Npinumber AS npi
      |         ,dpb.RowUpdateDateTime
      |       FROM LSS_DPBRLOCATION dpb
      |       WHERE NULLIF(CONCAT_WS('', dpb.Sourceid, dpb.Locationid), '') is not null
      |       AND dpb.Name is not null
      |     ) x
      |) where rownumber = 1
    """.stripMargin
}

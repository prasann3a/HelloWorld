package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.oap.cdr.models.int_claim_labresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object INT_CLAIM_LABRESULT extends FEQueryAndMetadata[int_claim_labresult] {

  override def name: String = CDRFEParquetNames.int_claim_labresult

  override def dependsOn: Set[String] = Set("LABRESULTS","REF_TERM_DICT_LOINC")

  override def sparkSql: String =
    """
      |select groupid, client_ds_id, datasrc, abnormal_flag, claim_header_id, claim_header_id as encounterid, fasting_status, loinc_code, loinc_name, result_name, member_id, reference_range, result_code, result_date, source_code, test_result_number, test_result_text, test_result_units, test_order_name
      |from
      |(
      |select
      |       distinct '{groupid}'			as 	groupid,
      |       {client_ds_id} 			as 	client_ds_id,
      |	   'labresults' 				as 	datasrc,
      |       nullif(replace(Abnl_Cd,'NA',''), '')   	as 	abnormal_flag,
      |       nullif(substr(UPPER(sha1(nullif(concat_ws('', Loinc_Cd, Lab_Tst_Nm, uniq_mbr_id, upper(date_format(srvc_dt, 'dd-MMM-yy')), lab_rslt_txt, lab_rslt_nbr), ''))),1,100), '')  as 	claim_header_id,
      |       Fasting_Sts 					as 	fasting_status,
      |       Loinc_Cd                 	as 	loinc_code,
      |       nullif(substr(ref.Long_Common_Name,1,249), '') as loinc_name,
      |	   Lab_Tst_Nm					as	result_name,
      |       Uniq_Mbr_Id 					as 	member_id,
      |       nullif(replace(Ref_Rng,'NA',''), '')  	as 	reference_range,
      |       coalesce(Loinc_Cd,nullif(substr(Lab_Tst_Nm,1,25), ''))	as 	result_code,
      |       case when date_trunc('DAY', srvc_dt) in (to_date('9999-12-31','yyyy-MM-dd'),to_date('9000-12-31','yyyy-MM-dd')) then null
      |            when (date_trunc('DAY', srvc_dt) <= to_date('1900-01-01','yyyy-MM-dd') or srvc_dt > current_date) then null
      |       else srvc_dt end 			as 	result_date,
      |       Enty_Nm 						as  source_code ,
      |       case when '{groupid}' in ('H969222','H969488') then
      |            case when lab_rslt_nbr =0 AND lab_rslt_txt is not null then null else lab_rslt_nbr end
      |       else Lab_Rslt_Nbr end 				as 	test_result_number,
      |       Lab_Rslt_Txt 				as 	test_result_text,
      |       nullif(replace(Uom,'NA',''), '') 		as 	test_result_units,
      |       Lab_Tst_Nm as test_order_name
      |  from LABRESULTS lab
      |  left join REF_TERM_DICT_LOINC ref on (lab.loinc_cd = ref.loinc_num)
      | where not (Loinc_Cd is null and Lab_Tst_Nm is null)
      |
      |)
    """.stripMargin

}

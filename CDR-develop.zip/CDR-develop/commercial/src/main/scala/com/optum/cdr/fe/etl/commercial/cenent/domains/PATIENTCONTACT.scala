package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.patientcontact
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object PATIENTCONTACT extends FEQueryAndMetadata[patientcontact] {

  override def name: String = CDRFEParquetNames.patientcontact

  override def dependsOn: Set[String] = Set("PRSNPH", "PERSON")

  override def sparkSql: String =
    """
     |select groupid, datasrc, client_ds_id, update_dt, patientid, personal_email, home_phone, work_phone
     |from
     |(
     |SELECT  a.*,
     |  row_number() over (partition by patientid,update_dt,home_phone,personal_email,work_phone order by update_dt desc nulls last) as rn
     |FROM (
     |SELECT '{groupid}' as groupid
     |	,'prsnph' as datasrc
     |	,{client_ds_id} as client_ds_id
     |	,Prsnph.Data_Update_Ts  AS update_dt
     |	,Prsnph.Person_Num  AS patientid
     |	,CASE WHEN prsnph.type_cde = 'HM' THEN Prsnph.Phn END AS home_phone
     |	,Person.Email_Addr_Ln  AS personal_email
     |	,CASE WHEN prsnph.type_cde = 'WK' THEN Prsnph.Phn END  AS work_phone
     |FROM PRSNPH
     |     LEFT OUTER JOIN PERSON ON (person.num = prsnph.person_num)
     |) a
     |)
     |where  patientid IS NOT NULL AND  update_dt IS NOT NULL  AND rn =1
    """.stripMargin

}
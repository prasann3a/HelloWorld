package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object CLAIM extends FEQueryAndMetadata[claim]{

  override def name: String = CDRFEParquetNames.claim

  override def dependsOn: Set[String] = Set("MED3000_CHARGE_PROCEDURES","MED3000_ZH_PROC_MASTER","MED3000_CHARGE_TICKET_MASTER")

  override def sparkSql: String =
    """
      select groupid, datasrc, client_ds_id, claimid, patientid, servicedate, mappedcptmod1, mappedcptmod2, mappedcptmod3, mappedcptmod4, claimproviderid, mappedcpt, encounterid, localbillingproviderid, localcpt, localcptmod1, localcptmod2, localcptmod3, localcptmod4, quantity, seq
 |from
 |(
 |select a.*,
 |       row_number() over (partition by seq order by update_date desc nulls last) as rank_claim
 |  from (
 |select
 |       '{groupid}' 		as groupid
 |       ,'charge_procs' 	as datasrc
 |       ,{client_ds_id} 	as client_ds_id
 |       ,proc.Icchart_Ct_Id  	as claimid
 |       ,chg_mast.Blind_Key  	as patientid
 |       ,chg_mast.Charge_Date  	as servicedate
 |       ,proc.Proc_Mod1  		as mappedcptmod1
 |       ,proc.Proc_Mod2  		as mappedcptmod2
 |       ,proc.Proc_Mod3  		as mappedcptmod3
 |       ,proc.Proc_Mod4  		as mappedcptmod4
 |       ,chg_mast.Clinician  	as claimproviderid
 |       ,lpad(proc.Procedure_Code,5,'0')  as mappedcpt
 |       ,chg_mast.Appt_Id  		as encounterid
 |       ,chg_mast.Clinician  	as localbillingproviderid
 |       ,proc.Procedure_Code  	as localcpt
 |       ,proc.Proc_Mod1  		as localcptmod1
 |       ,proc.Proc_Mod2  		as localcptmod2
 |       ,proc.Proc_Mod3  		as localcptmod3
 |       ,proc.Proc_Mod4  		as localcptmod4
 |       ,proc.Units  			as quantity
 |       ,proc.Ct_Proc_Seq  		as seq
 |	   ,proc.Update_Date
 |  from MED3000_CHARGE_PROCEDURES proc
 | inner join MED3000_ZH_PROC_MASTER proc_mast on (proc.Procedure_Code = proc_mast.Procedure_Code)
 | inner join MED3000_CHARGE_TICKET_MASTER chg_mast on (proc.ICChart_CT_ID = chg_mast.ICChart_CT_ID)
 |
 | ) a
 |)
 |where rank_claim = 1  and claimid is not null and patientid is not null and servicedate is not null
    """.stripMargin
}

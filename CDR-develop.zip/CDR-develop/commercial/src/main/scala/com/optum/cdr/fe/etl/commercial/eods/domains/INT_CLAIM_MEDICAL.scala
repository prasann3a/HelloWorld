package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.eods_int_claim_medical
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_MEDICAL  extends FETableInfo[eods_int_claim_medical] {

  override def name: String = CDRFEParquetNames.int_claim_medical

  override def dependsOn: Set[String] = Set("MEDCLAIM")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId

    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val codetypecol = """ case when Icd_Ver_Cd_Typ  = '9'  then 'ICD9' when Icd_Ver_Cd_Typ= '10' then 'ICD10' else null END """

    val col_servicing_prov_spcltycol = """ case when substr('{groupid}',1,4) = 'H969' then null else srvc_prov_spcl  END """

    sparkSession.sql(
      """
        |
        |select groupid, client_ds_id, datasrc, admit_date, admit_source_code, admit_type_code, admit_prov_id, allowed_amt, billing_prov_id, coord_benifits_amt, capitated_service_flag, capitation_amt, claim_adj_type, claim_header_id, claim_line_id, claim_type, coinsurance_amt, copay_amt, diag_rel_grp_code, diag_rel_grp_grouper, diag_rel_grp_severity, deductable_amt, denied_flag, denied_reason, discharge_date, discharge_status_code, fee_for_service_amt, facility_code, icd_diag_cd1_adm_diag_flag, icd_diag_cd1_poa_indicator, icd_diag_cd2_poa_indicator, icd_diag_cd3_poa_indicator, icd_diag_cd4_poa_indicator, icd_diag_cd5_poa_indicator, icd_diag_cd6_poa_indicator, icd_diag_cd7_poa_indicator, icd_diag_cd8_poa_indicator, icd_diag_cd9_poa_indicator, icd_diag_cd10_poa_indicator, icd_diag_cd11_poa_indicator, icd_diag_cd12_poa_indicator, icd_diag_cd13_poa_indicator, icd_diag_cd14_poa_indicator, icd_diag_cd15_poa_indicator, icd_diag_cd16_poa_indicator, icd_diag_cd17_poa_indicator, icd_diag_cd18_poa_indicator, icd_diag_cd19_poa_indicator, icd_diag_cd20_poa_indicator, icd_diag_cd21_poa_indicator, icd_diag_cd22_poa_indicator, icd_diag_cd23_poa_indicator, icd_diag_cd1, icd_diag_cd2, icd_diag_cd3, icd_diag_cd4, icd_diag_cd5, icd_diag_cd6, icd_diag_cd7, icd_diag_cd8, icd_diag_cd9, icd_diag_cd10, icd_diag_cd11, icd_diag_cd12, icd_diag_cd13, icd_diag_cd14, icd_diag_cd15, icd_diag_cd16, icd_diag_cd17, icd_diag_cd18, icd_diag_cd19, icd_diag_cd20, icd_diag_cd21, icd_diag_cd22, icd_diag_cd23, icd_diag_cd1_type, icd_diag_cd2_type, icd_diag_cd3_type, icd_diag_cd4_type, icd_diag_cd5_type, icd_diag_cd6_type, icd_diag_cd7_type, icd_diag_cd8_type, icd_diag_cd9_type, icd_diag_cd10_type, icd_diag_cd11_type, icd_diag_cd12_type, icd_diag_cd13_type, icd_diag_cd14_type, icd_diag_cd15_type, icd_diag_cd16_type, icd_diag_cd17_type, icd_diag_cd18_type, icd_diag_cd19_type, icd_diag_cd20_type, icd_diag_cd21_type, icd_diag_cd22_type, icd_diag_cd23_type, icd_proc_cd_1, icd_proc_cd_2, icd_proc_cd_3, icd_proc_cd_4, icd_proc_cd_5, icd_proc_cd_6, icd_proc_cd_7, icd_proc_cd_8, icd_proc_cd_9, icd_proc_cd_10, icd_proc_cd_11, icd_proc_cd_12, icd_proc_cd_13, icd_proc_cd_14, icd_proc_cd_15, icd_proc_cd_1_type, icd_proc_cd_2_type, icd_proc_cd_3_type, icd_proc_cd_4_type, icd_proc_cd_5_type, icd_proc_cd_6_type, icd_proc_cd_7_type, icd_proc_cd_8_type, icd_proc_cd_9_type, icd_proc_cd_10_type, icd_proc_cd_11_type, icd_proc_cd_12_type, icd_proc_cd_13_type, icd_proc_cd_14_type, icd_proc_cd_15_type, member_id, network_status_flag, ordering_prov_id, pat_liability_amt, payment_amt, pay_process_date, place_of_service, principle_proc_cd, principle_proc_icd_type, proc_cd_modifier_1, proc_cd_modifier_2, proc_cd_modifier_3, proc_code, pseudo_flag, quantity_of_service, requested_amt, revenue_code, service_date, service_from_date, service_to_date, servicing_prov_id, servicing_prov_spclty_cd, servicing_prov_spclty_desc, source_code, submitted_date, type_of_bill_code, type_of_service, referring_prov_id, withhold_amt, payer_code, payer_name, network_status_flag as par_flag
        |from
        |(
        |select
        |       distinct '{groupid}' 		as 	groupid,
        |       {client_ds_id} 		as 	client_ds_id,
        |	   'medclaim' 				as 	datasrc,
        |       case when to_date(Admit_Dt,'yyyy-MM-dd') in (to_date('9999-12-31','yyyy-MM-dd'),to_date('9000-12-31','yyyy-MM-dd')) then null
        |            when (to_date(Admit_Dt,'yyyy-MM-dd') <= to_date('1900-01-01','yyyy-MM-dd') or Admit_Dt > current_date) then null
        |       else Admit_Dt end 		as 	admit_date,
        |       Admit_Src_Typ 			as 	admit_source_code,
        |       Admit_Typ 				as 	admit_type_code,
        |       case when Admit_Prov_Id = '999999999' then null else Admit_Prov_Id end as admit_prov_id,
        |       Allw_Amt 				as 	allowed_amt,
        |       case when Bil_Prov_Id = '999999999' then null else Bil_Prov_Id end as billing_prov_id,
        |       Cob_Amt 					as 	coord_benifits_amt,
        |       Capitated_Srvc_Flg 		as 	capitated_service_flag,
        |       Cptn_Amt 				as 	capitation_amt,
        |       Clm_Adj_Typ 				as 	claim_adj_type,
        |       Clm_Head_Id 				as 	claim_header_id,
        |       Clm_Ln_Id 				as 	claim_line_id,
        |       Clm_Typ 					as 	claim_type,
        |       Coins_Amt 				as 	coinsurance_amt,
        |       Copay_Amt 				as 	copay_amt,
        |       coalesce(case when drg_cd_pd in ( '0', '00', '000', '0000') or drg_cd_pd is null then
        |          case when length(drg_code_derived) = 5 and nullif(substr(drg_code_derived,1,2), '') = '00' then nullif(substr(drg_code_derived,3,3), '')
        |            else drg_code_derived end else drg_cd_pd end,  drg_cd_bil)  as diag_rel_grp_code,
        |      'MSDRG'      			       as 	diag_rel_grp_grouper,
        |       Drg_Sev_Lvl_Pd 			as 	diag_rel_grp_severity,
        |       Ded_Amt 					as 	deductable_amt,
        |       Clm_Deny_Flg 			as	denied_flag ,
        |       Deny_Rsn_Cd 				as 	denied_reason,
        |       case when date_trunc('DAY', Dschrg_Dt) in (to_date('9999-12-31','yyyy-MM-dd'),to_date('9000-12-31','yyyy-MM-dd')) then null
        |            when (date_trunc('DAY', Dschrg_Dt) <= to_date('1900-01-01','yyyy-MM-dd') or Dschrg_Dt > current_date) then null
        |       else Dschrg_Dt end 		as 	discharge_date ,
        |       Dschrg_Sts_Cd 			as 	discharge_status_code,
        |       Fee_For_Srvc_Amt 		as 	fee_for_service_amt,
        |       null  					as 	facility_code,
        |	   case when admit_diag_cd=Icd_Diag_Cd_1 then 'Y' else 'N' end 	as	icd_diag_cd1_adm_diag_flag,
        |	   Prs_On_Admis_Flg_1		as	icd_diag_cd1_poa_indicator,
        |       Prs_On_Admis_Flg_2		as	icd_diag_cd2_poa_indicator,
        |       Prs_On_Admis_Flg_3		as	icd_diag_cd3_poa_indicator,
        |       Prs_On_Admis_Flg_4		as	icd_diag_cd4_poa_indicator,
        |       Prs_On_Admis_Flg_5		as	icd_diag_cd5_poa_indicator,
        |       Prs_On_Admis_Flg_6		as	icd_diag_cd6_poa_indicator,
        |       Prs_On_Admis_Flg_7		as	icd_diag_cd7_poa_indicator,
        |       Prs_On_Admis_Flg_8		as	icd_diag_cd8_poa_indicator,
        |       Prs_On_Admis_Flg_9		as	icd_diag_cd9_poa_indicator,
        |       Prs_On_Admis_Flg_10		as	icd_diag_cd10_poa_indicator,
        |       Prs_On_Admis_Flg_11		as	icd_diag_cd11_poa_indicator,
        |       Prs_On_Admis_Flg_12		as	icd_diag_cd12_poa_indicator,
        |       Prs_On_Admis_Flg_13		as	icd_diag_cd13_poa_indicator,
        |       Prs_On_Admis_Flg_14		as	icd_diag_cd14_poa_indicator,
        |       Prs_On_Admis_Flg_15		as	icd_diag_cd15_poa_indicator,
        |       Prs_On_Admis_Flg_16		as	icd_diag_cd16_poa_indicator,
        |       Prs_On_Admis_Flg_17		as	icd_diag_cd17_poa_indicator,
        |       Prs_On_Admis_Flg_18		as	icd_diag_cd18_poa_indicator,
        |       Prs_On_Admis_Flg_19		as	icd_diag_cd19_poa_indicator,
        |       Prs_On_Admis_Flg_20		as	icd_diag_cd20_poa_indicator,
        |       Prs_On_Admis_Flg_21		as	icd_diag_cd21_poa_indicator,
        |       Prs_On_Admis_Flg_22		as	icd_diag_cd22_poa_indicator,
        |       Prs_On_Admis_Flg_23		as	icd_diag_cd23_poa_indicator,
        |       Icd_Diag_Cd_1			as	icd_diag_cd1,
        |       Icd_Diag_Cd_2			as	icd_diag_cd2,
        |       Icd_Diag_Cd_3			as	icd_diag_cd3,
        |       Icd_Diag_Cd_4			as	icd_diag_cd4,
        |       Icd_Diag_Cd_5			as	icd_diag_cd5,
        |       Icd_Diag_Cd_6			as	icd_diag_cd6,
        |       Icd_Diag_Cd_7			as	icd_diag_cd7,
        |       Icd_Diag_Cd_8			as	icd_diag_cd8,
        |       Icd_Diag_Cd_9			as	icd_diag_cd9,
        |       Icd_Diag_Cd_10			as	icd_diag_cd10,
        |       Icd_Diag_Cd_11			as	icd_diag_cd11,
        |       Icd_Diag_Cd_12			as	icd_diag_cd12,
        |       Icd_Diag_Cd_13			as	icd_diag_cd13,
        |       Icd_Diag_Cd_14			as	icd_diag_cd14,
        |       Icd_Diag_Cd_15			as	icd_diag_cd15,
        |       Icd_Diag_Cd_16			as	icd_diag_cd16,
        |       Icd_Diag_Cd_17			as	icd_diag_cd17,
        |       Icd_Diag_Cd_18			as	icd_diag_cd18,
        |       Icd_Diag_Cd_19			as	icd_diag_cd19,
        |       Icd_Diag_Cd_20			as	icd_diag_cd20,
        |       Icd_Diag_Cd_21			as	icd_diag_cd21,
        |       Icd_Diag_Cd_22			as	icd_diag_cd22,
        |       Icd_Diag_Cd_23			as	icd_diag_cd23,
        |       {codetype}				as	icd_diag_cd1_type,
        |       {codetype}				as	icd_diag_cd2_type,
        |       {codetype}				as	icd_diag_cd3_type,
        |       {codetype}				as	icd_diag_cd4_type,
        |       {codetype}				as	icd_diag_cd5_type,
        |       {codetype}				as	icd_diag_cd6_type,
        |       {codetype}				as	icd_diag_cd7_type,
        |       {codetype}				as	icd_diag_cd8_type,
        |       {codetype}				as	icd_diag_cd9_type,
        |       {codetype}				as	icd_diag_cd10_type,
        |       {codetype}				as	icd_diag_cd11_type,
        |       {codetype}				as	icd_diag_cd12_type,
        |       {codetype}				as	icd_diag_cd13_type,
        |       {codetype}				as	icd_diag_cd14_type,
        |       {codetype}				as	icd_diag_cd15_type,
        |       {codetype}				as	icd_diag_cd16_type,
        |       {codetype}				as	icd_diag_cd17_type,
        |       {codetype}				as	icd_diag_cd18_type,
        |       {codetype}				as	icd_diag_cd19_type,
        |       {codetype}				as	icd_diag_cd20_type,
        |       {codetype}				as	icd_diag_cd21_type,
        |       {codetype}				as	icd_diag_cd22_type,
        |       {codetype}				as	icd_diag_cd23_type,
        |       Icd_Proc_Cd_1			as	icd_proc_cd_1,
        |       Icd_Proc_Cd_2			as	icd_proc_cd_2,
        |       Icd_Proc_Cd_3			as	icd_proc_cd_3,
        |       Icd_Proc_Cd_4			as	icd_proc_cd_4,
        |       Icd_Proc_Cd_5			as	icd_proc_cd_5,
        |       Icd_Proc_Cd_6			as	icd_proc_cd_6,
        |       Icd_Proc_Cd_7			as	icd_proc_cd_7,
        |       Icd_Proc_Cd_8			as	icd_proc_cd_8,
        |       Icd_Proc_Cd_9			as	icd_proc_cd_9,
        |       Icd_Proc_Cd_10			as	icd_proc_cd_10,
        |       Icd_Proc_Cd_11			as	icd_proc_cd_11,
        |       Icd_Proc_Cd_12			as	icd_proc_cd_12,
        |       Icd_Proc_Cd_13			as	icd_proc_cd_13,
        |       Icd_Proc_Cd_14			as	icd_proc_cd_14,
        |       Icd_Proc_Cd_15			as	icd_proc_cd_15,
        |       {codetype}				as	icd_proc_cd_1_type,
        |       {codetype}				as	icd_proc_cd_2_type,
        |       {codetype}				as	icd_proc_cd_3_type,
        |       {codetype}				as	icd_proc_cd_4_type,
        |       {codetype}				as	icd_proc_cd_5_type,
        |       {codetype}				as	icd_proc_cd_6_type,
        |       {codetype}				as	icd_proc_cd_7_type,
        |       {codetype}				as	icd_proc_cd_8_type,
        |       {codetype}				as	icd_proc_cd_9_type,
        |       {codetype}				as	icd_proc_cd_10_type,
        |       {codetype}				as	icd_proc_cd_11_type,
        |       {codetype}				as	icd_proc_cd_12_type,
        |       {codetype}				as	icd_proc_cd_13_type,
        |       {codetype}				as	icd_proc_cd_14_type,
        |       {codetype}				as	icd_proc_cd_15_type,
        |       Uniq_Mbr_Id            	as 	member_id,
        |       Ntwk_Sts_Flg 			as 	network_status_flag,
        |       case when Ordr_Prov_Id = '999999999' then null else Ordr_Prov_Id end as ordering_prov_id,
        |       Ptnt_Liab_Amt 			as 	pat_liability_amt,
        |       Pay_Amt             		as 	payment_amt,
        |       Pay_Proc_Dt              as 	pay_process_date,
        |       case when  REGEXP_INSTR(Plsrv_Cd,'[^a-zA-Z0-9 ]') > 0 or REGEXP_INSTR(Plsrv_Cd, '[a-zA-Z]') > 0 then null
        |	   else  Plsrv_Cd end      	as 	place_of_service,
        |       Icd_Proc_Cd_1      		as 	principle_proc_cd,
        |       {codetype}               	as 	principle_proc_icd_type ,
        |       Proc_Cd_Mod_1    		as 	proc_cd_modifier_1,
        |       Proc_Cd_Mod_2  			as 	proc_cd_modifier_2,
        |       Proc_Cd_Mod_3  			as 	proc_cd_modifier_3,
        |       Proc_Cd 					as 	proc_code,
        |       Pseudo_Clm_Flg 			as 	pseudo_flag ,
        |       Qty_Of_Srvc        		as 	quantity_of_service,
        |       case when Ref_Prov_Id = '999999999' then null else Ref_Prov_Id end as referring_prov_id,
        |       Req_Amt       			as 	requested_amt,
        |	   case when REGEXP_INSTR(RVNU_CD, '[a-zA-Z]') > 0 or RVNU_CD IN ('99','999','9999','0000','000') THEN NULL  ELSE RVNU_CD end as revenue_code,
        |       case when date_trunc('DAY', Srvc_from_dt) in (to_date('9999-12-31','yyyy-MM-dd'),to_date('9000-12-31','yyyy-MM-dd')) then null
        |            when (date_trunc('DAY', Srvc_from_dt) <= to_date('1900-01-01','yyyy-MM-dd') or Srvc_from_dt> current_date) then null
        |       else Srvc_from_dt end         as 	service_date ,
        |       case when date_trunc('DAY', Srvc_From_Dt) in (to_date('9999-12-31','yyyy-MM-dd'),to_date('9000-12-31','yyyy-MM-dd')) then null
        |            when (date_trunc('DAY', Srvc_From_Dt) <= to_date('1900-01-01','yyyy-MM-dd') or Srvc_From_Dt > current_date) then null
        |       else Srvc_From_Dt end    as 	service_from_date,
        |       case when date_trunc('DAY', Srvc_To_Dt) in (to_date('9999-12-31','yyyy-MM-dd'),to_date('9000-12-31','yyyy-MM-dd')) then null
        |            when (date_trunc('DAY', Srvc_To_Dt) <= to_date('1900-01-01','yyyy-MM-dd') or Srvc_To_Dt > current_date) then null
        |       else Srvc_To_Dt end      as 	service_to_date,
        |       Srvc_Prov_Id         	as 	servicing_prov_id,
        |       {col_servicing_prov_spclty} as servicing_prov_spclty_cd,
        |       {col_servicing_prov_spclty} as servicing_prov_spclty_desc,
        |       Enty_Nm           		as 	source_code,
        |       Sbmt_Dt 					as 	submitted_date,
        |       Typ_Of_Bil_Cd    		as 	type_of_bill_code,
        |       Srvc_Ln_Tos         		as 	type_of_service ,
        |       Wthld_Amt 				as 	withhold_amt,
        |       Hlth_Pln_Src_Id          as  payer_code,
        |       Hlth_Pln_Payr_Nm         as  payer_name
        |  from MEDCLAIM
        |
        |
        |)
      """.stripMargin
        .replace("{client_ds_id}", clientDsId.toString)
        .replace("{codetype}", codetypecol)
        .replace("{col_servicing_prov_spclty}", col_servicing_prov_spcltycol)
        .replace("{groupid}", groupId.toString)
    )
  }

  override def ignoreExtraColumnsInDataFrame: Boolean = true

}

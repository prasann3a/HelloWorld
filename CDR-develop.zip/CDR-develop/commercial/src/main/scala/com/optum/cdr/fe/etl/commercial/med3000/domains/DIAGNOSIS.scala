package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object DIAGNOSIS extends FEQueryAndMetadata[diagnosis]{

  override def name: String = CDRFEParquetNames.diagnosis

  override def dependsOn: Set[String] = Set("DIAGNOSIS_TEMP_CHARGE","DIAGNOSIS_TEMP_PAT")

  override def sparkSql: String =
    """
     select * from DIAGNOSIS_TEMP_CHARGE
     union all
     select * from DIAGNOSIS_TEMP_PAT
    """.stripMargin
}

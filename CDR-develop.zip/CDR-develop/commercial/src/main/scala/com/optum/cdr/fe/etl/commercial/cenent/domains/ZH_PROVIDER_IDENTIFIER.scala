package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_provider_identifier
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, RuntimeVariables}


object ZH_PROVIDER_IDENTIFIER extends FEQueryAndMetadata[zh_provider_identifier] {

  override def name: String = CDRFEParquetNames.zh_provider_identifier

  override def dependsOn: Set[String] = Set("ASSCID")

  override def sparkSql: String =
    """
      |select groupid, client_ds_id, id_type, id_value, provider_id
      |from
      |(
      |SELECT a.*,
      |       case when '{prov_exception}' = 'EXCEPTION'  then id_type_2 else id_type_1 end as id_type
      |  FROM (
      |SELECT '{groupid}' as groupid,
      |	      'asscid' as datasrc
      |	      ,{client_ds_id} as client_ds_id
      |	      ,CASE Id_type_cde
      |	         WHEN 'PROVB' THEN 'State License'
      |	         WHEN 'PROVD' THEN 'NPI'
      |	         WHEN 'PROVC' THEN 'UPIN' END  AS id_type_1
      |	      ,CASE Id_type_cde
      |	         WHEN 'PROVG' THEN 'UPIN'
      |          WHEN 'PROVB' THEN 'State License' END AS id_type_2
      |	      ,Id  AS id_value
      |	      ,Assoct_Num  AS provider_id
      |FROM ASSCID
      |WHERE Id_type_cde in ('PROVB','PROVD','PROVC','PROVG')
      |) a
      |)
      |where provider_id IS NOT NULL AND id_type IS NOT NULL AND id_value IS NOT NULL
    """.stripMargin

  override protected def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val provException = if (loaderVars.groupId == "H984216" ) {"EXCEPTION"} else {"UNDEFINED"}

    sparkSql.replace("{groupid}", loaderVars.groupId)
      .replace("{client_ds_id}", loaderVars.clientDsId.toString)
      .replace("{prov_exception}", provException)
  }
}
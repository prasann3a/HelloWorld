package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object TEMP_CLAIM_PART1 extends FEQueryAndMetadata[claim] {

  override def name: String = "TEMP_CLAIM_PART1"

  override def dependsOn: Set[String] = Set("TEMP_CLAIM_PROC_CACHE1")

  override def sparkSql: String =
    """
      |select distinct groupid, datasrc, client_ds_id, claimid, patientid, servicedate, facilityid,
      |claimproviderid, encounterid, localcpt, seq, claimproviderid as localbillingproviderid
      |from
      |(
      |TEMP_CLAIM_PROC_CACHE1
      |)
      |where servicedate IS NOT NULL AND claimid IS NOT NULL AND patientid IS NOT NULL
    """.stripMargin

}

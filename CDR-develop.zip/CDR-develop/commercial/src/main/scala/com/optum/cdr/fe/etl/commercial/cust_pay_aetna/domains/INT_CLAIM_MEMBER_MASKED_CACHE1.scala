package com.optum.cdr.fe.etl.commercial.cust_pay_aetna.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_member
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_MEMBER_MASKED_CACHE1 extends FETableInfo[int_claim_member] {

  override def name: String = "INT_CLAIM_MEMBER_MASKED_CACHE1"
  override def dependsOn: Set[String] = Set("AETACOE6","ZO_BPO_MAP_EMPLOYER")
  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString

    // masked_claim_member.sql
    sparkSession.sql(
      s"""
         |with ym as (SELECT  distinct eff_mm FROM AETACOE6),
         |     org as (select distinct org_cd from AETACOE6 where org_cd is not null),
         |     cross_table as (select
         |                     'Masked' as mbr_first_nm
         |                    ,'Claim' as mbr_last_nm
         |                    ,'00000000000000000000' as member_id
         |                    ,to_date('19000101','yyyyMMdd') as dob
         |                    ,'U' as gender
         |                    ,eff_mm,org_cd from YM cross join ORG)
         |
         |select groupid, datasrc, client_ds_id, contract_id, member_eff_date, financial_class, member_gender_code,
         |       medical_benefit_flag, member_dob, member_fname, member_id, member_lname, payer_code, payer_name,
         |       pharmacy_benefit_flag, plan_code, plan_name, alternate_member_id, eligibile_member_month, emp_acct_id,
         |       member_end_date, member_addr_1, member_addr_2, member_city, member_state_code, member_zip_code,
         |       pcp_id, pcp_name, pcp_npi, pcp_spclty_cd, pcp_spclty_desc, product_code, product_name, subscriber_flag, subscriber_id
         |from
         |(
         |  select
         |        '{groupid}' 					as groupid
         |        ,'AETACOE6' 					as datasrc
         |        ,{client_ds_id} 					as client_ds_id
         |        ,org_cd as contract_id
         |        ,safe_to_date(eff_mm,'yyyyMM') 		as member_eff_date
         |        ,bme.employeraccountid   			as financial_class
         |        ,gender 				as member_gender_code
         |        ,'Y' 				as medical_benefit_flag
         |        ,dob 					as member_dob
         |        ,mbr_first_nm 				as member_fname
         |        ,member_id 					as member_id
         |        ,mbr_last_nm 				as member_lname
         |        ,bme.employeraccountid 				as payer_code
         |        ,bme.employeraccountid 				as payer_name
         |        ,'Y' 					as pharmacy_benefit_flag
         |        ,bme.employeraccountid 				as plan_code
         |        ,bme.employeraccountid 				as plan_name
         |        ,null 				as alternate_member_id
         |        ,eff_mm 					as eligibile_member_month
         |        ,null 				as emp_acct_id
         |        ,last_day(safe_to_date(eff_mm,'yyyyMM')) 	as member_end_date
         |        ,null 			as member_addr_1
         |        ,null 			as member_addr_2
         |        ,null 				as member_city
         |        ,null               as member_state_code
         |        ,null						as member_zip_code
         |        ,null as pcp_id
         |        ,null as pcp_name
         |        ,null as pcp_npi
         |        ,null as pcp_spclty_cd
         |        ,null as pcp_spclty_desc
         |        ,bme.employeraccountid 				as product_code
         |        ,bme.employeraccountid 				as product_name
         |        ,'Y' as subscriber_flag
         |        ,member_id 					as subscriber_id
         |from CROSS_TABLE
         |cross join ZO_BPO_MAP_EMPLOYER bme on bme.client_ds_id = {client_ds_id}
         |)
       """.stripMargin.replace("{client_ds_id}",clientDsId).replace("{groupid}",groupId)
    )
  }

}

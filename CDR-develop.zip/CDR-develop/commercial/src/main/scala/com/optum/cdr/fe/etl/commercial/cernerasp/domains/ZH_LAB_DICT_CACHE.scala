package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_lab_dict
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object ZH_LAB_DICT_CACHE extends FETableInfo[labcache]{

  override def name:String="LABCACHE"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {


    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }


    sparkSession.sql(
      s"""
         |with dedup_refcode as (select   display ,element_code from
         |                        (
         |                        select a.display, a.element_code ,row_number() over (partition by element_code order by length(display) desc nulls first) as rw
         |                        from REFERENCECODE  a
         |                         )
         |                         where rw=1
         |                        )
         |
         |select groupid,datasrc,client_ds_id,localcode,localbodysite,localrefrange,localname,localunits
         |from (
         |          select /*+ Broadcast(tblunits,tblsite) */
         |         '{groupid}' 													as groupid
         |         ,'result' 													as datasrc
         |         ,{client_ds_id}													as client_ds_id
         |         ,rsl.code 													as localcode
         |         ,tblsite.description 												as localbodysite
         |         ,case when rsl.normal_low is null and rsl.normal_high is null then null
         |               else concat_ws('', rsl.normal_low, ' - ', rsl.normal_high) end	                                                as localrefrange
         |         ,rfr.display 													as localname
         |         ,tblunits.description 											as localunits
         |         ,row_number() over (partition by rsl.code order by rsl.code desc nulls first) 	as rw
         |       from RESULT rsl
         |       inner join DEDUP_REFCODE rfr on (rfr.element_code = rsl.code)
         |       left outer join  TBL_UNITS tblunits on (tblunits.element_code = rsl.units)
         |       left outer join TBL_SITE tblsite on (tblsite.element_code = rsl.site)
         |       where rsl.code is not null
         |       )
         |       where rw=1
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
    )
  }

  override def dependsOn: Set[String] = Set("RESULT","REFERENCECODE","TBL_UNITS","TBL_SITE")

}

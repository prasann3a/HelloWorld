package com.optum.cdr.fe.etl.commercial.cigna_cm.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_member
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_MEMBER extends FETableInfo[int_claim_member] {

  override def name: String = CDRFEParquetNames.int_claim_member
  override def dependsOn: Set[String] = Set("CIGNA_CM_ELIGIBILITY","CIGNA_CM_DEMO_SUPPLEMENTAL","ZO_BPO_MAP_EMPLOYER")
  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString
    val productCodeSelect = if (clientDsId.toString.equals("10758")) "case when dm.product='CIGNA CONNECT' then dm.product else lg.Ben_Plan_Num end"
                            else "lg.Ben_Plan_Num"

    sparkSession.sql(
      s"""
         |with demo as
         | (
         |   select * from
         |                (select d.*, row_number() over (partition by enterprise_id,account_number,npi  order by fileid desc nulls last) as rank_enc
         |                 from CIGNA_CM_DEMO_SUPPLEMENTAL d
         |                ) where rank_enc = 1
         | )
         |select groupid, datasrc, client_ds_id, contract_id, member_eff_date, financial_class, member_gender_code, medical_benefit_flag, member_dob, member_fname, member_id, member_lname, payer_code, payer_name, pharmacy_benefit_flag, plan_code, plan_name, alternate_member_id, benefit_plan_code, contract_type_code, coverage_status_code, member_end_date, member_addr_1, member_city, member_mname, member_ssn, member_state_code, member_zip_code, pcp_npi, pcp_id, subscriber_flag, subscriber_id, subscriber_ssn, emp_acct_id, member_phone, product_code
         |from
         |    (
         |     SELECT
         |           '{groupid}'                    as groupid
         |          ,'eligibility'                  as datasrc
         |          ,{client_ds_id}                 as client_ds_id
         |          ,bme.employeraccountid          as contract_id
         |          ,lg.Mbr_Mth_Frst_Of_Mth_Dt      as member_eff_date
         |          ,bme.employeraccountid          as financial_class
         |          ,coalesce(lg.Membr_Gender, dm.gender) as member_gender_code
         |          ,'Y'                            as medical_benefit_flag
         |          ,lg.Membr_Brth_Dt               as member_dob
         |          ,lg.Membr_First_Nm              as member_fname
         |          ,lg.Indiv_Enterprise_Id         as member_id
         |          ,lg.Membr_Last_Nm               as member_lname
         |          ,bme.employeraccountid          as payer_code
         |          ,bme.employeraccountid          as payer_name
         |          ,lg.Cvrg_Phrm_Ind               as pharmacy_benefit_flag
         |          ,bme.employeraccountid          as plan_code
         |          ,bme.employeraccountid          as plan_name
         |          ,lg.Membr_Ami                   as alternate_member_id
         |          ,lg.Ben_Plan_Num                as benefit_plan_code
         |          ,case when lg.Coverage_Type = '1' then   'Employee Only'
         |                when lg.Coverage_Type = '2' then  'Employee and Spouse'
         |                when lg.Coverage_Type = '3' then  'Employee and Child'
         |                when lg.Coverage_Type = '4' then  'Family'
         |                when lg.Coverage_Type = '5' then  'Other'
         |                else null end  as contract_type_code
         |          ,lg.Cigna_Relshp_Cd             as coverage_status_code
         |          ,coalesce(dm.Account_name, lg.client_acct_num)                   as EMP_ACCT_ID
         |          ,lg.Mbr_Mth_End_Of_Mth_Dt       as member_end_date
         |          ,coalesce(lg.Membr_Home_Addr_Ln_1, dm.PATIENT_ADDRESS_1)         as member_addr_1
         |          ,coalesce(lg.Membr_Home_Addr_City_Nm, dm.Patient_City)           as member_city
         |          ,lg.Membr_Mid_Nm                as member_mname
         |          ,dm.Home_Phonenumber            as member_phone
         |          ,nullif(substr(lg.lgcy_subscrbr_num,1,9), '')  as member_ssn
         |          ,coalesce(lg.Membr_Home_Addr_Ste_Cd, dm.Patient_State)           as member_state_code
         |          ,coalesce(lg.Membr_Zip_Cd, dm.Patient_Zip_Code)                  as member_zip_code
         |          ,coalesce(dm.NPI, lg.Natl_Prov_Id)                               as pcp_npi
         |          ,coalesce(dm.Npi, lg.Natl_Prov_Id, dm.Physician_id, lg.prov_id)  as pcp_id
         |          ,case when upper(lg.Cigna_Relshp_Cd) =  'EE' then  'Y'  else  'N' end as subscriber_flag
         |          ,case when upper(lg.Cigna_Relshp_Cd) =  'EE' then  lg.indiv_enterprise_id  else null end as subscriber_id
         |          ,case when lg.Cigna_Relshp_Cd = 'EE' and length(lg.lgcy_subscrbr_num) > 9 then nullif(substr(lg.lgcy_subscrbr_num,1,9), '') else null end   as subscriber_ssn
         |          ,{product_code_select}               as product_code
         |          ,row_number() over (partition by membr_first_nm, membr_last_nm, membr_home_addr_ln_1, indiv_enterprise_id, cigna_relshp_cd, mbr_mth_frst_of_mth_dt, mbr_mth_end_of_mth_dt order by lg.fileid desc nulls last) as rw_id
         |     from CIGNA_CM_ELIGIBILITY lg
         |     left join DEMO dm on lg.Indiv_Enterprise_Id = dm.ENTERPRISE_ID and  lg.CLIENT_ACCT_NUM = dm.ACCOUNT_NUMBER and lg.Natl_Prov_Id = dm.NPI
         |     CROSS JOIN ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
         |    )
         |    where rw_id = 1
       """.stripMargin.replace("{client_ds_id}",clientDsId).replace("{groupid}",groupId).replace("{product_code_select}",productCodeSelect)
    )
  }
}

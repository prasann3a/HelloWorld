package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.clinicalencounter
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object CLINICALENCOUNTER extends FETableInfo[clinicalencounter] {

  import java.util.TimeZone

  System.setProperty("user.timezone", "")
  TimeZone.setDefault(null)

  override def name: String = CDRFEParquetNames.clinicalencounter

  override def dependsOn: Set[String] = Set("CENTRICV2_DOCUMENTS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    sparkSession.conf.set("spark.sql.datetime.java8API.enabled", true)
    sparkSession.conf.set("spark.sql.session.timeZone", "America/New_York")

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOC_XID",
      "INCLUSION", "INCLUSION", "INCLUSION").mkString(",").replace("'", "")

    val docXidInclusion = if (docXidInclusionMpv.toLowerCase() == "NO_MPV_MATCHES".toLowerCase() || docXidInclusionMpv.toLowerCase() == "null") "" else
      "  and  t.XID in ( " + docXidInclusionMpv + " ) "

    sparkSession.sql(
      """
        |select groupid, datasrc, client_ds_id,  encounterid, facilityid, patientid,
        | localpatienttype, admittime, dischargetime, arrivaltime
        |from
        |(
        |select       '{groupid}'                as groupid
        |              ,'document'             as datasrc
        |              ,{client_ds_id}          as client_ds_id
        |              ,t.usrid                as provider
        |              ,'VISIT'                as  providerrole
        |              ,t.sdid                 AS encounterid
        |              ,t.pid                  AS patientid
        |              ,t.Locofcare            AS facilityid
        |              ,t.Doctype              AS localpatienttype
        |,max(case when doctype in (2,11,12) then date_format(to_utc_timestamp(CAST(-315619200  + CAST(t.clinicaldate AS DOUBLE)/CAST(1000000 AS DOUBLE) AS TIMESTAMP), "America/New_York"), 'yyyy-MM-dd HH:mm:ss')
        |    else null end) over (partition by t.sdid) as admittime
        |,max(case when doctype = 15 then date_format(to_utc_timestamp(CAST(-315619200  + CAST(t.clinicaldate AS DOUBLE)/CAST(1000000 AS DOUBLE) AS TIMESTAMP), "America/New_York"), 'yyyy-MM-dd HH:mm:ss')
        |    else null end) over  (partition by t.sdid) as dischargetime
        |,row_number() over (partition by t.sdid order by t.DB_UPDATED_DATE desc nulls last) rownumber
        |,date_format(to_utc_timestamp(CAST(-315619200  + CAST(t.clinicaldate AS DOUBLE)/CAST(1000000 AS DOUBLE) AS TIMESTAMP), "America/New_York"), 'yyyy-MM-dd HH:mm:ss')   as arrivaltime
        |from CENTRICV2_DOCUMENTS t
        |            where (t.pubtime is not null or t.pubtime > 0)
        |             {xid_condition}
        |            and (t.change is null OR t.change in (0,1,2))
        |            and t.finalsign = 1
        |            and t.status = 'S'
        |)
        |where encounterid is not null and arrivaltime is not null and  localpatienttype <>  '24' and rownumber =1
    """.stripMargin
        .replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{xid_condition}", docXidInclusion))

  }
}
package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.patient_id
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT_ID extends FEQueryAndMetadata[patient_id]{

override def name: String = CDRFEParquetNames.patient_id

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT", "TEMP_PATIENT_CACHE")

override def sparkSql: String =
  """
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,'SSN' AS idtype
    |       ,ssn   AS idvalue
    |       ,client_ds_id
    |FROM
    |(
    |   TEMP_PATIENT_CACHE
    |)
    |WHERE ssn_row = 1
    |AND ssn IS NOT NULL
    |UNION ALL
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,idtype
    |       ,idvalue
    |       ,client_ds_id
    |FROM
    |(
    |	SELECT  DISTINCT '{groupid}'                                      AS groupid
    |	       ,{client_ds_id}                                            AS client_ds_id
    |	       ,'pat_visit'                                               AS datasrc
    |	       ,Psn_Int_Id                                                AS patientid
    |	       ,'MRN'                                                     AS idtype
    |	       ,CASE WHEN med_rec_no <> '0' THEN med_rec_no ELSE NULL END AS idvalue
    |	FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT
    |	WHERE Row_Sta_CD <> 'D'
    |	AND Psn_Int_Id IS NOT NULL
    |)
    |WHERE idvalue IS NOT NULL
  """.stripMargin
}

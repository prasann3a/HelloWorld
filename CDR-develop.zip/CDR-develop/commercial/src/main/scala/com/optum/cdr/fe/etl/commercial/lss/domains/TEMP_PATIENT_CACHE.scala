package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object TEMP_PATIENT_CACHE extends FEQueryAndMetadata[lss_temp_patient_cache]{

  override def name: String = "LSS_TEMP_PATIENT_CACHE"

  override def dependsOn: Set[String] = Set("LSS_PBRPATIENTS", "LSS_PBRACCOUNTS", "LSS_PBRACCOUNTDEMOGRAPHICS")

  override def sparkSql: String =
    """
      |SELECT x.*
      |      ,row_number() over (partition by PatientID order by RowUpdateDateTime desc nulls first  ) as rownumber
      | 	   ,row_number() over (partition by patientid,lower(firstname) order by RowUpdateDateTime desc nulls first ) as first_row
      | 	   ,row_number() over (partition by patientid,lower(lastname) order by RowUpdateDateTime desc nulls first ) as last_row
      | 	   ,row_number() over (partition by patientid,lower(gender) order by RowUpdateDateTime desc nulls first ) as gender_row
      | 	   ,row_number() over (partition by patientid,maritalstatus order by RowUpdateDateTime desc nulls first ) as marital_row
      | 	   ,row_number() over (partition by patientid,language order by RowUpdateDateTime desc nulls first ) as language_row
      | 	   ,row_number() over (partition by patientid,deathindicator order by RowUpdateDateTime desc nulls first ) as deathindicator_row
      | 	   ,row_number() over (partition by patientid,race order by RowUpdateDateTime desc nulls last  ) as race_row
      |FROM (
      |    SELECT 'pbrpatients' as datasrc
      |           ,nullif(concat_ws('', pbr.Sourceid, pbr.Patientid), '') AS patientid
      |           ,pbr.Birthdatetime AS dateofbirth
      |           ,pbr.Deceaseddatetime AS dateofdeath
      |           ,case when pbr.Deceased ='Y' then 'Y' else 'N' end AS deathindicator
      |           ,nullif(regexp_substr(pbr.name, '[A-Za-z]+', instr(pbr.name,',')+1, 1), '') AS firstname
      |           ,pbr.Sex AS gender
      |           ,case when pbr.Active = 'N' then 'Y' else 'N' end AS inactiveflag
      |           ,pbr.Languageid AS language
      |           ,nullif(substr(pbr.Name,1,  instr(pbr.Name,',')-1), '') AS lastname
      |           ,d.Maritalstatusid AS maritalstatus
      |           ,pbr.Raceid AS race
      |           ,pbr.RowUpdateDateTime
      |    FROM LSS_PBRPATIENTS  pbr
      |    left outer join LSS_PBRACCOUNTS  a on (pbr.sourceid=a.sourceid and  pbr.patientid=a.patientid)
      |    left outer join LSS_PBRACCOUNTDEMOGRAPHICS  d on (a.sourceid=d.sourceid and a.accountid=d.accountid)
      |    WHERE 1=1
      |     AND nullif(concat_ws('', pbr.Sourceid, pbr.Patientid), '') is not null
      |) x
    """.stripMargin
}

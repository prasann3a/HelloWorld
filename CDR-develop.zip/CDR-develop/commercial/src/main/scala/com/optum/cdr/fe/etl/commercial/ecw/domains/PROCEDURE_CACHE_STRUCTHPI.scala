package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_STRUCTHPI extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_STRUCTHPI"

  override def dependsOn: Set[String] = Set("STRUCTHPI", "ENC", "MAP_CUSTOM_PROC", "ZH_ITEMS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localcode
        |       ,encounterid
        |       ,patientid
        |       ,proceduredate
        |       ,localname
        |       ,codetype
        |       ,mappedcode
        |FROM
        |(
        |	SELECT  t.*
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                                                               AS groupid
        |		       ,'structhpi'                                                                                                               AS datasrc
        |		       ,{client_ds_id}                                                                                                            AS client_ds_id
        |		       ,concat_ws('','{client_ds_id_prefix}',s.catid)                                                                             AS localcode
        |		       ,e.encounterid                                                                                                             AS encounterid
        |		       ,e.patientid                                                                                                               AS patientid
        |		       ,s.hum_date                                                                                                                AS proceduredate
        |		       ,zhi.itemname                                                                                                              AS localname
        |		       ,'CUSTOM'                                                                                                                  AS codetype
        |		       ,mcp.mappedvalue                                                                                                           AS mappedcode
        |		       ,row_number() over (partition by e.encounterid,s.catid,s.hum_date,mcp.mappedvalue ORDER BY e.modifieddate desc nulls last) AS rownumber
        |		FROM STRUCTHPI s
        |		INNER JOIN ENC e
        |		  ON (s.encounterid = e.encounterid)
        |		INNER JOIN MAP_CUSTOM_PROC mcp
        |		  ON (mcp.localcode = concat_ws('', '{client_ds_id_prefix}', s.catid) AND mcp.datasrc = 'structhpi' AND mcp.groupid = '{groupid}')
        |		LEFT OUTER JOIN ZH_ITEMS zhi
        |		  ON (s.catid = zhi.itemid)
        |		WHERE (s.hum_value is not null or s.hum_value <> 'n/a')
        |		AND e.patientid is not null
        |		AND s.catid is not null
        |		AND s.hum_date is not null
        |	) t
        |	WHERE rownumber = 1
        |)
        |WHERE proceduredate IS NOT NULL
      """.stripMargin
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }


}

package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROCEDURE extends FEQueryAndMetadata[proceduredo]{

  override def name: String = CDRFEParquetNames.proceduredo

  override def dependsOn: Set[String] = Set("PROCEDURE_CHARGE_PROCS","PROCEDURE_PAT_PROCS","PROCEDURE_PAT_HM")

  override def sparkSql: String =
    """
    select * from PROCEDURE_CHARGE_PROCS
    union all
    select * from PROCEDURE_PAT_PROCS
    union all
    select * from PROCEDURE_PAT_HM
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.patientcontact
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTCONTACT extends FEQueryAndMetadata[patientcontact] {

  override def name: String = CDRFEParquetNames.patientcontact

  override def dependsOn: Set[String] = Set("ADDRESS", "ASPRO_PATIENT")

  override def sparkSql: String =
    """
      |SELECT datasrc,update_dt,patientid,personal_email,home_phone,cell_phone
      |FROM (
      |SELECT DISTINCT
      |	'patient' AS datasrc
      |	,Address.Tag_Systemdate  AS update_dt
      |	,Patient.Imredem_Code   AS patientid
      |	,Address.Addr_Carphone   AS cell_phone
      |	,Address.Addr_Phone      AS home_phone
      |	,Address.Addr_Emailaddress  AS personal_email
      |	,ROW_NUMBER() OVER(PARTITION BY Patient.Imredem_Code, Address.Addr_Emailaddress
      |	                   ORDER BY Address.Tag_Systemdate DESC NULLS LAST) rn
      |FROM ADDRESS Address
      |    JOIN ASPRO_PATIENT Patient ON (Patient.Dem_HomeADDR = Address.IMREADDR_Code)
      |WHERE coalesce(Address.Addr_Carphone,Address.Addr_Phone,Address.Addr_Emailaddress) IS NOT NULL) a
      |WHERE a.rn=1
      |AND patientid IS NOT NULL
      |AND update_dt IS NOT NULL
    """.stripMargin
}


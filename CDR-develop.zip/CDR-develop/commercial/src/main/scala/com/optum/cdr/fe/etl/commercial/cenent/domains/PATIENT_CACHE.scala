package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.etl.commercial.cenent_patient_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object PATIENT_CACHE extends FEQueryAndMetadata[cenent_patient_cache] {

  override def name: String = "PATIENT_CACHE"

  override def dependsOn: Set[String] = Set("PERSON")

  override def sparkSql: String =
    """
      |SELECT '{groupid}' as groupid
      |,'person' as datasrc
      |,{client_ds_id} as client_ds_id
      |,num  AS patientid
      |,Birth_Dttm AS dateofbirth
      |,CASE WHEN deceased_flg = 'Y' THEN data_update_ts ELSE NULL END  AS dateofdeath
      |,Deceased_Flg AS death_ind
      |,CASE WHEN Ethnic_Group_Cde IS NOT NULL THEN concat_ws('', 'ce.', Ethnic_Group_Cde) ELSE Ethnic_Group_Cde END AS ethnicity
      |,CASE WHEN Race_Cde IS NOT NULL THEN concat_ws('', 'ce.', Race_Cde) ELSE Race_Cde END AS race
      |,Marital_Status_Cde AS Maritalstatus
      |,First_Nm  AS firstname
      |,last_Nm  AS lastname
      |,Mid_Nm  AS middlename
      |,CASE WHEN Soc_Sec_Num NOT IN ('000000000','999999999','555555555','111111111','123456789') THEN Soc_Sec_Num
      |      ELSE NULL END AS ssn
      |,Gender_Cde AS gender
      |,COALESCE(DATA_CREATE_TS, DATA_UPDATE_TS) AS PATDETAIL_TIMESTAMP
      |,Language_Cde AS language
      |,ROW_NUMBER() OVER (PARTITION BY num ORDER BY DATA_UPDATE_TS  DESC NULLS LAST) AS rownumber
      |,ROW_NUMBER() OVER (PARTITION BY num, UPPER(First_Nm) ORDER BY DATA_UPDATE_TS  DESC NULLS LAST) AS first_row
      |,ROW_NUMBER() OVER (PARTITION BY num, UPPER(last_Nm) ORDER BY DATA_UPDATE_TS  DESC NULLS LAST) AS last_row
      |,ROW_NUMBER() OVER (PARTITION BY num, UPPER(mid_Nm) ORDER BY DATA_UPDATE_TS  DESC NULLS LAST) AS middle_row
      |,ROW_NUMBER() OVER (PARTITION BY num, UPPER(Gender_Cde)
      |                      ORDER BY DATA_UPDATE_TS  DESC NULLS LAST) AS gender_row
      |,ROW_NUMBER() OVER (PARTITION BY num, UPPER(coalesce(Ethnic_Group_Cde,Race_cde))
      |                      ORDER BY DATA_UPDATE_TS  DESC NULLS LAST) AS ethnicity_row
      |,ROW_NUMBER() OVER (PARTITION BY num, UPPER(Race_cde) ORDER BY DATA_UPDATE_TS  DESC NULLS LAST) AS race_row
      |,ROW_NUMBER() OVER (PARTITION BY num, UPPER(Marital_Status_Cde) ORDER BY DATA_UPDATE_TS  DESC NULLS LAST) AS mstatus_row
      |,ROW_NUMBER() OVER (PARTITION BY num ORDER BY Deceased_flg DESC nulls first, DATA_UPDATE_TS  DESC NULLS LAST) AS death_row
      |,ROW_NUMBER() OVER (PARTITION BY num, Soc_Sec_Num ORDER BY DATA_UPDATE_TS  DESC NULLS LAST) AS ssn_row
      |,ROW_NUMBER() OVER (PARTITION BY num, UPPER(Language_Cde) ORDER BY DATA_UPDATE_TS DESC NULLS LAST) AS language_row
      |FROM PERSON
    """.stripMargin
}
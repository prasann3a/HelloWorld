package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object LABRESULT extends FETableInfo[labresult]{

  override def name:String=CDRFEParquetNames.labresult

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select * from
         |(
         |LABRESULTCACHE
         |)
         |where localresult_numeric is not null
         |
         |UNION ALL
         |
         |select * from
         |(
         |NONNUMERIC_LABRESULT
         |)
         |
       """.stripMargin)
  }

  override def dependsOn: Set[String] = Set("NONNUMERIC_LABRESULT","LABRESULTCACHE")
}

package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_FLOWSHEET extends FETableInfo[observation] {

  override def name: String = "OBSERVATION_FLOWSHEET"

  override def dependsOn: Set[String] = Set("FLOWSHEET", "ASPRO_PATIENT", "PROCRESULTS", "ZCM_OBSTYPE_CODE", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val CH003043InclusionPattern = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "FLOWSHEET", "OBSERVATION", "CH003043_INCLUSION_PATTERN", "CELLDATA").mkString(",")

    sparkSession.sql(
      """
        |select groupid, datasrc, patientid, obsdate, localcode, obstype, localresult, client_ds_id
        |from
        |(
        |select
        |	'{groupid}' 			as groupid,
        |	'flowsheet' 		as datasrc
        |	,{client_ds_id} 		as client_ds_id
        |	,CASE WHEN zc.obstype = 'CH003043' AND
        |              (rlike(LOWER(flw.celldata), {CH003043_inclusion_pattern}) OR 'NO_MPV_MATCHES' IN ({CH003043_inclusion_pattern})) THEN flw.celldata
        |              WHEN zc.obstype <> 'CH003043' THEN flw.celldata END  AS localresult
        |	,flw.column_desc 	as localcode
        |	,flw.row_desc 		as obsdate
        |	,pat.imredem_code 	as patientid
        |	,zc.obstype 		as obstype
        |	,ROW_NUMBER () OVER (PARTITION BY pat.imredem_code, flw.column_desc, flw.row_desc, zc.obstype
        |	                     ORDER BY flw.tag_lastupdate, flw.celldata) rn
        |from FLOWSHEET flw
        |inner join
        |(
        |    select
        |    dem_externalid
        |    ,imredem_code
        |    from
        |    (
        |        select
        |        dem_externalid
        |        ,imredem_code
        |        ,row_number() over (partition by p.dem_externalid order by p.tag_systemdate desc nulls first) as rw
        |        from ASPRO_PATIENT p
        |    )
        |    where rw =1
        |) pat
        |on pat.dem_externalid = flw.dem_externalid
        |inner join ZCM_OBSTYPE_CODE zc on (zc.groupid ='{groupid}'  and zc.datasrc='flowsheet' and flw.column_desc = zc.obscode)
        |where flw.celldata is not null
        |and flw.column_desc is not null
        |and flw.row_desc is not null
        |and pat.imredem_code is not null
        |)
        |where localresult IS NOT NULL AND rn = 1
      """.stripMargin
         .replace("{CH003043_inclusion_pattern}", CH003043InclusionPattern)
         .replace("{groupid}", groupId)
         .replace("{client_ds_id}", clientDsId)
    )
  }

}


package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.zh_lab_dict
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object LAB_MAP_DICT extends FEQueryAndMetadata[zh_lab_dict] {

  override def name: String = CDRFEParquetNames.zh_lab_dict

  override def dependsOn: Set[String] = Set("ZH_XCNCPT", "ZCM_OBSTYPE_CODE")

  override def sparkSql: String =
    """
      |SELECT distinct groupid, client_ds_id, localcode, localdesc, localname ,local_loinc_code
      |FROM
      |(
      |SELECT
      |       '{groupid}'       AS groupid
      |       ,{client_ds_id}   AS client_ds_id
      |       ,zxc.num          AS localcode
      |       ,zxc.long_nm      AS localdesc
      |       ,zxc.nm           AS localname
      |	      ,zxc.Loinc_Cde    AS local_loinc_code
      |FROM ZH_XCNCPT zxc
      |INNER JOIN ZCM_OBSTYPE_CODE c on (c.groupid = '{groupid}' AND
      |                             c.datasrc = 'findng' AND
      |                             c.obstype = 'LABRESULT' AND
      |                             zxc.num=c.obscode)
      |WHERE zxc.concept_type_cde ='FINDNG'
      |
      |UNION ALL
      |SELECT
      |       '{groupid}'       AS groupid
      |       ,{client_ds_id}   AS client_ds_id
      |       ,zxc.num          AS localcode
      |       ,zxc.long_nm      AS localdesc
      |       ,zxc.nm           AS localname
      |	   ,zxc.Loinc_Cde       AS local_loinc_code
      |FROM ZH_XCNCPT zxc
      |WHERE zxc.concept_type_cde = 'LAB'
      |)
    """.stripMargin
}
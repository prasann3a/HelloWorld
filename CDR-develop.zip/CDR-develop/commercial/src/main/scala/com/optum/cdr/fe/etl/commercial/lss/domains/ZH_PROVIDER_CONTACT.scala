package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.zh_provider_contact
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object ZH_PROVIDER_CONTACT extends FEQueryAndMetadata[zh_provider_contact]{

  override def name: String = CDRFEParquetNames.zh_provider_contact

  override def dependsOn: Set[String] = Set("LSS_DPBRPROVIDER")

  override def sparkSql: String =
    """
      |SELECT  datasrc
      |       ,localproviderid   AS local_provider_id
      |       ,addressline1      AS address_line1
      |       ,city
      |       ,state
      |       ,zipcode
      |       ,workphone         AS work_phone
      |       ,lastupdatedate    AS update_date
      |       ,localcontacttype  AS local_contact_type
      |       ,mappedcontacttype AS mapped_contact_type
      |FROM
      |(
      |	SELECT  x.*
      |	       ,row_number() over (partition by LocalProviderID,LocalContactType,lastupdatedate ORDER BY FileID desc nulls first ) AS rownumber
      |	FROM
      |	(
      |		SELECT  'dpbrprovider'                                       AS datasrc
      |		       ,dpb.Rowupdatedatetime                                AS lastupdatedate
      |		       ,'OFFICE'                                             AS localcontacttype
      |		       ,nullif(concat_ws('',dpb.Sourceid,dpb.Providerid),'') AS localproviderid
      |		       ,dpb.Address                                          AS addressline1
      |		       ,dpb.City                                             AS city
      |		       ,'CH003087'                                           AS mappedcontacttype
      |		       ,dpb.State                                            AS state
      |		       ,dpb.Officephone                                      AS workphone
      |		       ,dpb.Postalcodeid                                     AS zipcode
      |		       ,dpb.FileID
      |		FROM LSS_DPBRPROVIDER dpb
      |		WHERE nullif(concat_ws('', Address, City, State, Postalcodeid, dpb.Officephone), '') is not null
      |		AND dpb.Rowupdatedatetime is not null
      |		AND nullif(concat_ws('', dpb.Sourceid, dpb.Providerid), '') is not null
      |	) x
      |)
      |WHERE rownumber = 1
    """.stripMargin
}

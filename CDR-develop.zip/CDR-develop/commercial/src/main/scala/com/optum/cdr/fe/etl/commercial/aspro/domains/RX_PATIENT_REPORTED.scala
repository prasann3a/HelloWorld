package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.rx_patient_reported
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object RX_PATIENT_REPORTED extends FEQueryAndMetadata[rx_patient_reported]{

  override def name: String = CDRFEParquetNames.rx_patient_reported

  override def dependsOn: Set[String] = Set("ASPRO_HX_MEDICATION", "ZH_DRUGS")

  override def sparkSql: String =
    """
      |SELECT
      |datasrc
      |,encounterid
      |,localmedcode
      |,patientid
      |,localdrugdescription
      |,NULL  AS localcategorycode
      |,localdoseunit
      |,localform
      |,NULL  AS localproviderid
      |,NULL  AS localactioncode
      |,NULL  AS actiontime
      |,NULL  AS localndc
      |,localgpi
      |,localqtyofdoseunit
      |,localroute
      |,localstrengthperdoseunit
      |,localstrengthunit
      |,NULL AS localtotaldose
      |,reportedmedid
      |,medreportedtime
      |,discontinuedate
      |FROM
      |(
      |SELECT m.*, ROW_NUMBER() OVER (PARTITION BY reportedmedid ORDER BY medreportedtime DESC NULLS LAST) rn
      |FROM
      |(
      |SELECT 'hx_medications' AS datasrc
      |	,Hx_Medication.Patient_Id  AS patientid
      |	,Hx_Medication.End_Date    AS discontinuedate
      |	,Zh_Drugs.Drug_Dose        AS localdoseunit
      |	,coalesce(Zh_Drugs.Drug_Title, Hx_Medication.Originaltitle) AS localdrugdescription
      |	,Hx_Medication.Imreenc_Code  AS encounterid
      |	,Hx_Medication.Doseunit      AS localform
      |	,Hx_Medication.Gpi  AS localgpi
      |	,Hx_Medication.Source_Code   AS localmedcode
      |	,Hx_Medication.Intake  AS localqtyofdoseunit
      |	,Zh_Drugs.Drug_Route   AS localroute
      |	,Zh_Drugs.Drug_Strength  AS localstrengthperdoseunit
      |	,Hx_Medication.Dose      AS localstrengthunit
      |	,coalesce(Hx_Medication.Start_Date ,Hx_Medication.Tag_Systemdate ) AS medreportedtime
      |	,concat_ws('',hx_medication.imreenc_code,hx_medication.hxmedication_id) AS reportedmedid
      |FROM ASPRO_HX_MEDICATION as hx_medication
      |     LEFT OUTER JOIN ZH_DRUGS as zh_drugs ON (hx_medication.source_code = zh_drugs.drug_code)
      |WHERE Hx_Medication.source_code not in ('FREETEXT', 'NONE', 'RECONCIL')
      |)m
      |)
      |WHERE rn = 1
    """.stripMargin
}

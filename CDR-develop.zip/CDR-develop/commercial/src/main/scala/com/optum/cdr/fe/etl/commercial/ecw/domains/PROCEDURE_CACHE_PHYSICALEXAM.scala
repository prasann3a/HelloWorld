package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_PHYSICALEXAM extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_PHYSICALEXAM"

  override def dependsOn: Set[String] = Set("PHYSICALEXAM", "ENC", "MAP_CUSTOM_PROC", "ZH_ITEMS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localcode
        |       ,encounterid
        |       ,patientid
        |       ,proceduredate
        |       ,localname
        |       ,codetype
        |       ,mappedcode
        |       ,proceduredate AS actualprocdate
        |FROM
        |(
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                     AS groupid
        |		       ,'physicalexam'                                  AS datasrc
        |		       ,{client_ds_id}                                  AS client_ds_id
        |		       ,concat_ws('','{client_ds_id_prefix}',pe.itemid) AS localcode
        |		       ,Enc.Patientid                                   AS patientid
        |		       ,enc.enc_date                                    AS proceduredate
        |		       ,enc.Encounterid                                 AS encounterid
        |		       ,zh_items.itemname                               AS localname
        |		       ,Map_Custom_Proc.Mappedvalue                     AS mappedcode
        |		       ,'CUSTOM'                                        AS codetype
        |		       ,ROW_NUMBER() OVER (PARTITION BY enc.encounterid,pe.itemid,enc.enc_date,map_custom_proc.mappedvalue ORDER BY enc.modifieddate DESC NULLS LAST) rn
        |		FROM PHYSICALEXAM pe
        |		JOIN ENC
        |		  ON (pe.encounterid = enc.encounterid)
        |		JOIN MAP_CUSTOM_PROC
        |		  ON (map_custom_proc.groupid = '{groupid}' AND map_custom_proc.datasrc = 'physicalexam' AND map_custom_proc.localcode = concat_ws('', '{client_ds_id_prefix}	', pe.itemid))
        |		LEFT OUTER JOIN ZH_ITEMS
        |		  ON (pe.itemid = zh_items.itemid)
        |		WHERE pe.itemid IS NOT NULL
        |		AND NVL(pe.value, 'n/a') <> 'n/a'
        |	)
        |	WHERE rn = 1
        |)
        |WHERE patientid IS NOT NULL
        |AND proceduredate IS NOT NULL
      """.stripMargin
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }


}

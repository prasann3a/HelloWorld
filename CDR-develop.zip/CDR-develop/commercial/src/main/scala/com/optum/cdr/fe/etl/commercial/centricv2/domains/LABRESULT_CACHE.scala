package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.centricv2_labresult_cache
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object LABRESULT_CACHE extends FETableInfo[centricv2_labresult_cache] {

  override def name: String = "LABRESULT_CACHE"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES", "CENTRICV2_ZH_HIERGRPS", "CENTRICV2_DOCUMENTS", "CENTRICV2_OBSERVATIONS", "CENTRICV2_ZH_OBSHEAD", "CENTRICV2_CLINICALDOCUMENTS", "LABMAPPERDICT")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId

    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName,df) => df.createOrReplaceTempView(depName) }

    val constNoMpvMatches = "NO_MPV_MATCHES"
    val nullMatch = "null"


    val zhobsGroupidMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "RESULTS", "LABRESULT", "ZH_OBSHEAD", "GROUPID").mkString(",").replace("'", "")
    val zhobsGroupid = if (zhobsGroupidMpv == constNoMpvMatches) "null" else zhobsGroupidMpv

    val zhobsHdidMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "RESULTS", "LABRESULT", "ZH_OBSHEAD", "HDID").mkString(",").replace("'", "")
    val zhobsHdid = if (zhobsHdidMpv == constNoMpvMatches) "null" else zhobsHdidMpv

    val obsXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "OBS_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",").replace("'", "")
    val obsXidInclusion = if (obsXidInclusionMpv == constNoMpvMatches || obsXidInclusionMpv == nullMatch) "" else " AND obs.xid in ( " + obsXidInclusionMpv + " ) "

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOC_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",").replace("'", "")
    val docXidInclusion = if (docXidInclusionMpv == constNoMpvMatches || docXidInclusionMpv == nullMatch) "" else " AND doc.xid in ( " + docXidInclusionMpv + " ) "


    val df = sparkSession.sql(
      """
        |select lab.*
        |, row_number() over (partition by nullif(concat_ws('', LabresultID, LocalResultCode), '') order by datecollected  desc nulls last) as lab_row
        |from ( SELECT  '{groupid}'             as groupid
        |,'results'                         as datasrc
        |,{client_ds_id}                     as client_ds_id
        |,obs.Obsid                         AS labresultid
        |,obs.Hdid                          AS localresultcode
        |,safe_to_number(obs.Obsvalue)      AS localresult_numeric
        |, obs.Obsvalue                     AS localresult
        |,(nullif(substr(obs.Obsvalue,1,case when instr_3params(obs.Obsvalue,' ',25) = 0
        |                                    then length(obs.Obsvalue)
        |                                    else instr_3params(obs.Obsvalue,' ',25) end), '')) as localresult_25
        |,obs.Pid                           AS patientid
        |,null                              AS datecollected
        |,coalesce(obs.obsdate,obs.lupd_date)	AS dateavailable
        |,obs.Sdid                          AS encounterid
        |,zh_obs.Description           AS localresultname
        |,case when zh_obs.groupid = '2141' then zh_obs.Description else null end  AS localspecimensource
        |,zh_obs.Unit                        AS localunits
        |,obs.Range                         AS normalrange
        |,nvl(obs.Obstype,'UNK')             AS resulttype
        |,zh_obs.Loinccode                   AS local_loinc_code
        |  from CENTRICV2_OBSERVATIONS obs
        |         INNER JOIN CENTRICV2_ZH_OBSHEAD zh_obs ON (obs.hdid = zh_obs.hdid)
        |         INNER JOIN CENTRICV2_ZH_HIERGRPS  zh_hiergrps ON (zh_obs.groupid = zh_hiergrps.groupid)
        |         INNER JOIN CENTRICV2_DOCUMENTS doc ON (doc.SDID=Obs.SDID and doc.pid = obs.pid)
        |               WHERE (obs.state IS NULL or obs.state NOT IN ('D','I','P','S'))
        |               AND (obs.Change IS NULL or obs.Change IN ('0','1','2'))
        |               AND doc.finalsign = 1
        |               AND doc.status = 'S'
        |               {obs_xid_condition}
        |	        {dox_xid_condition}
        |		AND (zh_obs.groupid not in ({list_zhobs_groupid})
        |        or obs.hdid in ({list_zhobs_hdid}))
        |  ) lab
    """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{obs_xid_condition}", obsXidInclusion).
        replace("{dox_xid_condition}", docXidInclusion).
        replace("{list_zhobs_groupid}", zhobsGroupid).
        replace("{list_zhobs_hdid}", zhobsHdid)
    )

    val df1 = sparkSession.sql(
      """
        |with dd_documents AS(
        |  select summary, pid, sdid, clinicaldate
        |  from(
        |        select summary, pid, sdid, clinicaldate, row_number() over (partition by sdid order by db_updated_date desc nulls last, fileid desc) as rn
        |        from CENTRICV2_DOCUMENTS doc
        |        where doctype = '7' and finalsign = '1' and status = 'S'
        |        and upper(summary) in (select localcode from LABMAPPERDICT where client_ds_id={client_ds_id})
        |        {dox_xid_condition}
        |        )
        |  where rn = '1'
        |  ),
        |
        |dd_clinicaldocuments AS(
        |  select sdid, ddid, lupd_date, fileid, data, data_extracted, rn
        |	 from(
        |		    select sdid, ddid, lupd_date, fileid, data, data_extracted
        |			  , row_number() over (partition by sdid order by lupd_date desc nulls last, data_extracted desc nulls last, fileid desc) as rn
        |		    from
        |		    (
        |			    select sdid, ddid, lupd_date, fileid, data
        |				  , nullif(substr(regexp_extract(upper(data),'(! SARS.*|COMMENT:.TAB.*)',1),1,59),'') as data_extracted
        |			    from CENTRICV2_CLINICALDOCUMENTS
        |		    )
        |	     )
        |	where rn = '1'
        |  )
        |
        |Select groupid, datasrc, client_ds_id, labresultid, localcode as localresultcode, null as localresult_numeric, localresult,
        |	null as localresult_25, patientid, null as datecollected, dateavailable, encounterid, localname as localresultname,
        |    null as localspecimensource, null as localunits, null as normalrange, null as resulttype, null as local_loinc_code, rn	from
        |  (select
        |	'{grpid}' as groupid
        |	,'clinicaldocuments' as datasrc
        |	,{client_ds_id} as client_ds_id
        |	,cln.Ddid AS labresultid
        |	,upper(doc.Summary) AS localcode
        |	,doc.Pid AS patientid
        |	,doc.Sdid AS encounterid
        |	,upper(doc.Summary) AS localname
        |	,date_add('1960-01-01' ,cast(doc.clinicaldate/1000000/3600/24 as int)) AS dateavailable
        |	,data_extracted AS localresult
        |	,row_number() over(partition by cln.ddid order by cln.lupd_date desc nulls last, cln.fileid desc) as rn
        |  from dd_documents doc
        |  inner join dd_clinicaldocuments cln on (cln.sdid = doc.sdid)
        |) a
        |where rn=1 and patientid is not null and dateavailable is not null and localresult is not null
        |    """.stripMargin.
        replace("{grpid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{obs_xid_condition}", obsXidInclusion).
        replace("{dox_xid_condition}", docXidInclusion).
        replace("{list_zhobs_groupid}", zhobsGroupid).
        replace("{list_zhobs_hdid}", zhobsHdid)
    )

    df.unionAll(df1)

  }

}



package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{clinicalencounter, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object CLINICALENCOUNTER extends FETableInfo[clinicalencounter]{

override def name: String = CDRFEParquetNames.clinicalencounter

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT", "MCKESSON_PGN_V1_TMR410_VISIT_DRG", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val sta_list = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ENCOUNTER_EXC","CLINICALENCOUNTER","PAT_VISIT","VST_STA_CD").mkString(",")
    val loc_ids = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LOCALPATIENTTYPE","CLINICALENCOUNTER","PAT_VISIT","LOC_LVL_3_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
       | WITH uni_visit AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  v.*
       |	       ,ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
       |	WHERE Psn_Int_Id IS NOT NULL
       |	AND Vst_Int_Id IS NOT NULL
       |	AND Vst_Sta_CD NOT IN ({sta_list})
       |)
       |WHERE rn = 1
       |AND row_sta_cd <> 'D' ),
       |uni_drg AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  d.*
       |	       ,ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_TMR410_VISIT_DRG d
       |)
       |WHERE rn = 1
       |AND row_sta_cd <> 'D' )
       |SELECT  groupid
       |       ,datasrc
       |       ,client_ds_id
       |       ,arrivaltime
       |       ,encounterid
       |       ,patientid
       |       ,facilityid
       |       ,localpatienttype
       |       ,admittime
       |       ,alt_encounterid
       |       ,dischargetime
       |       ,localadmitsource
       |       ,localdischargedisposition
       |       ,inpatientlocation
       |       ,localencountertype
       |       ,localdrgtype
       |       ,localdrg
       |       ,aprdrg_rom
       |       ,aprdrg_cd
       |       ,localmdc
       |       ,aprdrg_soi
       |FROM
       |(
       |	SELECT  '{groupid}'                                                                                        AS groupid
       |	       ,'pat_visit'                                                                                        AS datasrc
       |	       ,{client_ds_id}                                                                                     AS client_ds_id
       |	       ,COALESCE(safe_to_date_length(uni_visit.arv_date_time,'yyyy-MM-dd HH:mm:ss',19),uni_visit.adm_ts) AS arrivaltime
       |	       ,uni_visit.Vst_Int_Id                                                                               AS encounterid
       |	       ,uni_visit.Psn_Int_Id                                                                               AS patientid
       |	       ,uni_visit.adm_ts                                                                                   AS admittime
       |	       ,uni_visit.Vst_Ext_Id                                                                               AS alt_encounterid
       |	       ,uni_visit.Dschrg_Ts                                                                                AS dischargetime
       |	       ,uni_visit.Org_Int_Id                                                                               AS facilityid
       |	       ,NVL2(uni_visit.Adm_Src_Cd,concat_ws('','{client_ds_id_prefix}',uni_visit.Adm_Src_Cd),NULL)         AS localadmitsource
       |	       ,'MSDRG'                                                                                            AS localdrgtype
       |	       ,COALESCE(uni_Visit.Drg_Cd,uni_drg.Drg_Cd,uni_Drg.Icd9_Drg_Cd)                                      AS localdrg
       |	       ,NVL2(uni_visit.Dschg_Sta_Cd,concat_ws('','{client_ds_id_prefix}',uni_visit.Dschg_Sta_Cd),NULL)     AS localdischargedisposition
       |	       ,uni_drg.Rsk_Mrt_Cd                                                                                 AS aprdrg_rom
       |	       ,COALESCE(uni_drg.Apr_Drg_Cd,uni_drg.Icd9_Apr_Drg_Cd)                                               AS aprdrg_cd
       |	       ,uni_drg.Mdc_Cd                                                                                     AS localmdc
       |	       ,uni_drg.Svr_Ill_Cd                                                                                 AS aprdrg_soi
       |	       ,CASE WHEN '1' IN ({loc_ids}) THEN NVL2(uni_visit.pat_cat_cd,concat_ws('','{client_ds_id_prefix}',uni_visit.pat_cat_cd,'-',uni_visit.pat_ty,'-',uni_visit.loc_lvl_3_id),NULL) ELSE concat_ws('','{client_ds_id_prefix}',uni_visit.pat_cat_cd,'-',uni_visit.pat_ty) END AS localpatienttype
       |	       ,NULL                                                                                               AS inpatientlocation
       |	       ,NULL                                                                                               AS localencountertype
       |	FROM UNI_VISIT
       |	LEFT OUTER JOIN UNI_DRG
       |	ON (uni_visit.vst_int_id = uni_drg.vst_int_id )
       |)
       |WHERE arrivaltime IS NOT NULL
       """
        .stripMargin
        .replace("{sta_list}", sta_list)
        .replace("{loc_ids}", loc_ids)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", runtimeVar.clientDsId.toString + ".")
    )
  }
}

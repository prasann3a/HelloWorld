package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.{map_predicate_values, zh_provider_identifier}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROVIDERIDENTIFIER extends FETableInfo[zh_provider_identifier]{
  override def name: String = CDRFEParquetNames.zh_provider_identifier

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TPM115_CAR_GVR_LIC","MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val gvrLicIds = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "PROVIDERID_INC","ZH_PROVIDER_IDENTIFIER","CAR_GVR_LIC","CAR_GVR_LIC_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |select groupid, client_ds_id, provider_id, id_type, id_value
        |from
        |(
        |SELECT '{groupid}'     AS groupid
        |,{client_ds_id} 	    AS client_ds_id
        |,zl.Car_Gvr_Int_Id  AS provider_id
        |,dtl.Cod_Dtl_Ext_Id AS id_type
        |,zl.Car_Gvr_Lic_No  AS id_value
        |,ROW_NUMBER() OVER (PARTITION BY zl.Car_Gvr_Int_Id, dtl.Cod_Dtl_Ext_Id
        |                    ORDER BY zl.Lst_Mod_Ts  DESC NULLS LAST, zl.fileid DESC nulls first) rn
        |FROM MCKESSON_PGN_V1_TPM115_CAR_GVR_LIC zl
        |     JOIN MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL dtl ON (zl.car_gvr_lic_id = dtl.cod_dtl_int_id )
        |WHERE zl.Car_Gvr_Int_Id IS NOT NULL
        |  AND dtl.Cod_Dtl_Ext_Id IS NOT NULL
        |  AND zl.Car_Gvr_Lic_No IS NOT NULL
        |  AND zl.row_sta_cd <> 'D'
        |  AND dtl.row_sta_cd <> 'D'
        |  AND zl.car_gvr_lic_id IN ({gvr_lic_ids})
        |
        |)
        |where rn = 1
      """
        .stripMargin
        .replace("{gvr_lic_ids}", gvrLicIds)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }

}

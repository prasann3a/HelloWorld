package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.{map_predicate_values, prov_pat_rel}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROVIDERPATIENTRELATION extends FETableInfo[prov_pat_rel]{
  override def name: String = CDRFEParquetNames.prov_pat_rel

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TPM114_CAR_GVR_FUNC","MCKESSON_PGN_V1_TSM042_PSN_CARE_GIVER","MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_TPM315_VISIT_CARE_GIVER")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val funcIntList = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "PCP_INC","PROV_PAT_REL","CAR_GVR_FUNC","FUNC_INT_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH uni_func AS
        |(SELECT * FROM
        |(SELECT d.*, ROW_NUMBER() OVER (PARTITION BY func_aso_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM114_CAR_GVR_FUNC d
        |  WHERE car_gvr_int_id IS NOT NULL
        |    AND func_int_id IN ({func_int_list})
        |   )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'  ),
        |uni_func2 AS
        |(SELECT * FROM
        |(SELECT d.*, ROW_NUMBER() OVER (PARTITION BY func_aso_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM114_CAR_GVR_FUNC d
        |  WHERE car_gvr_int_id IS NOT NULL
        |    AND func_aso_int_id IS NOT NULL
        |    AND Func_Eff_Ts IS NOT NULL
        |    AND func_int_id IN ({func_int_list})
        |   )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'  ),
        |uni_visit AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        |  )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'
        |   AND Vst_Int_Id IS NOT NULL
        |   AND Psn_Int_Id IS NOT NULL )
        |select groupid, datasrc, client_ds_id, providerid, patientid, localrelshipcode, startdate, enddate
        |from
        |(
        |SELECT '{groupid}'     AS groupid
        |,'psn_care_giver'   AS datasrc
        |,{client_ds_id} 	    AS client_ds_id
        |,gvr.Car_Gvr_Int_Id AS providerid
        |,gvr.Psn_Int_Id     AS patientid
        |,'PCP'		    AS localrelshipcode
        |,gvr.Car_Gvr_Eff_Ts AS startdate
        |,NULL               AS enddate
        |,ROW_NUMBER() OVER (PARTITION BY gvr.Psn_Int_Id, gvr.Car_Gvr_Int_Id, gvr.Car_Gvr_Eff_Ts
        |                    ORDER BY gvr.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM MCKESSON_PGN_V1_TSM042_PSN_CARE_GIVER gvr
        |     JOIN UNI_FUNC ON (gvr.car_gvr_int_id = uni_func.car_gvr_int_id)
        |WHERE gvr.row_sta_cd <> 'D'
        |  AND gvr.Psn_Int_Id IS NOT NULL
        |  AND gvr.Car_Gvr_Eff_Ts IS NOT NULL
        |
        |)
        |where rn = 1
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, providerid, patientid, localrelshipcode, startdate, enddate
        |from
        |(
        |SELECT '{groupid}'     AS groupid
        |,'visit_care_giver' AS datasrc
        |,{client_ds_id} 	    AS client_ds_id
        |,uni_func2.Car_Gvr_Int_Id AS providerid
        |,uni_visit.Psn_Int_Id    AS patientid
        |,'PCP'		    AS localrelshipcode
        |,uni_func2.Func_Eff_Ts    AS startdate
        |,NULL               AS enddate
        |,ROW_NUMBER() OVER (PARTITION BY gvr.vst_int_id, gvr.seq_no, gvr.func_aso_int_id
        |                    ORDER BY gvr.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM MCKESSON_PGN_V1_TPM315_VISIT_CARE_GIVER gvr
        |     JOIN UNI_FUNC2 ON (gvr.func_aso_int_id = uni_func2.func_aso_int_id)
        |     JOIN UNI_VISIT ON (gvr.vst_int_id = uni_visit.vst_int_id)
        |WHERE gvr.row_sta_cd <> 'D'
        |
        |)
        |where rn = 1
      """
        .stripMargin
        .replace("{func_int_list}", funcIntList)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }

}

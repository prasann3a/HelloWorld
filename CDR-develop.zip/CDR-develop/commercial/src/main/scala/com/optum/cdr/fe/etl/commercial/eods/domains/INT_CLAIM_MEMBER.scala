package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.oap.cdr.models.int_claim_member
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object INT_CLAIM_MEMBER extends FEQueryAndMetadata[int_claim_member] {

  override def name: String = CDRFEParquetNames.int_claim_member

  override def dependsOn: Set[String] = Set("MEMBER")

  override def sparkSql: String =
    """
      |
      |select groupid, client_ds_id, datasrc, coverage_class_code, coverage_status_code, member_eff_date, member_end_date, member_dod, financial_class, member_gender_code, hicn, medical_benefit_flag, member_addr_1, member_addr_2, member_city, member_dob, member_fname, member_id, member_lname, member_mname, member_phone, member_ssn, member_state_code, member_zip_code, pcp_id, pcp_npi, payer_code, payer_name, pcp_start_date, pcp_end_date, pharmacy_benefit_flag, plan_code, plan_name, source_code, subscriber_flag, subscriber_id, member_language, member_death_ind, product_code, product_name
      |from
      |(
      |select
      |       distinct '{groupid}' 		as 	groupid,
      |       {client_ds_id} 		as 	client_ds_id,
      |	   'member' 				as 	datasrc,
      |       Cov_Clss_Cd 				as 	coverage_class_code,
      |       lob					as financial_class,
      |       Cov_Sts 					as 	coverage_status_code,
      |	   Mbr_Eff_Dt 				as 	member_eff_date,
      |        case when (Mbr_End_Dt is null or date_format(Mbr_End_Dt,'yyyy-MM-dd') = '9999-12-31' or Mbr_End_Dt > current_date) then
      |	        NULL else Mbr_End_Dt end as member_end_date,
      |	   Gdr_Cd 					as 	member_gender_code,
      |       Lt_Hic_Nbr 				as 	hicn,
      |       Med_Ben_Flg 				as 	medical_benefit_flag,
      |       Mbr_Adr_1 				as 	member_addr_1,
      |       Mbr_Adr_2 				as 	member_addr_2,
      |	   Mbr_Cty					as 	member_city,
      |	   Mbr_Dob as member_dob,
      |	   Mbr_Dod	 as member_dod,
      |	   Spoken_Lang              as  member_language,
      |	   Dcsd_Ind					as  member_death_ind,
      |       Mbr_Fst_Nm				as 	member_fname,
      |       Uniq_Mbr_Id 				as 	member_id,
      |       Mbr_Lst_Nm				as 	member_lname,
      |       Mbr_Midl_Nm 				as 	member_mname,
      |       case when Mbr_Tel_Nbr='9999999999' then null else Mbr_Tel_Nbr end as member_phone,
      |       Mbr_Ssn 					as 	member_ssn,
      |       case when Mbr_St_Cd ='NA' then null else Mbr_St_Cd end as member_state_code,
      |       case when Mbr_Zip in ('99999', '00000') then null when length(Mbr_Zip)>5 then nullif(substr(Mbr_Zip,1,5), '') else Mbr_Zip end	as member_zip_code,
      |       Pcp_Prov_Id 				as 	pcp_id,
      |       case when length(Pcp_Nat_Prov_Id)<10 then null else Pcp_Nat_Prov_Id end as pcp_npi,
      | 	   nvl(Hlth_Pln_Nm, 'NA')				as 	payer_code,
      |	   nvl(Hlth_Pln_Nm, 'NA')				as 	payer_name,
      |       pcp_eff_dt	as	pcp_start_date,
      |       pcp_eff_end_dt		as 	pcp_end_date,
      |       Phrm_Ben_Flg 			as 	pharmacy_benefit_flag,
      |       Enty_Nm					   	as 	source_code,
      |       Sbscr_Flg 					as 	subscriber_flag,
        |       Sbscr_Nbr 					as	subscriber_id,
      |       NVL(Pln_Ben_Pkg, 'NA') as plan_code,
      |       NVL(Pln_Ben_Pkg, 'NA') as plan_name,
      |       NVL(PRDCT_CD, 'NA') as product_code,
      |       NVL(PRDCT_CD, 'NA') as product_name
      |  from MEMBER
      |
      |
      |)
    """.stripMargin


}

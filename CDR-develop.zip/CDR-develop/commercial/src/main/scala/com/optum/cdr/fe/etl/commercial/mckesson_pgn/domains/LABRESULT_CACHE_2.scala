package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.map_predicate_values
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.cdr.fe.etl.commercial.mckesson_pgn_labresult_cache
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE_2 extends FETableInfo[mckesson_pgn_labresult_cache]{
  override def name: String = "LABRESULT_CACHE_2"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_ZH_TLB800_TEST_CODE_MST","MCKESSON_PGN_V1_TLB290_LABRESULT_DTL")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val list_Test = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "INCLUSION","LABRESULT","TLB290_LABRESULT_DTL","TST_COD_INT_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH Pat_visit AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |    FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        |   )
        | WHERE rn = 1
        |   AND nvl(row_sta_cd,'X') <> 'D'  )
        |
        |, Test_Cod AS
        |(SELECT * FROM
        |(SELECT CM.*, ROW_NUMBER() OVER (PARTITION BY tst_cod_int_id ORDER BY lst_mod_ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |  FROM MCKESSON_PGN_V1_ZH_TLB800_TEST_CODE_MST CM
        |  )
        | WHERE rn = 1
        |   AND nvl(row_sta_cd,'X') <> 'D'  )
        |
        |
        |
        |Select v.*,safe_to_number(Localresult) as localresult_numeric
        |	from (SELECT
        |         '{groupid}' as groupid
        |	,'labresult_dtl' as datasrc
        |	,{client_ds_id} as client_ds_id
        |	,concat_ws('', 'ld.', TLD.Lab_Dtl_Int_Id) AS labresultid
        |	,TLD.Tst_Cod_Int_Id AS localcode
        |	,TPV.Psn_Int_Id AS patientid
        |	,TLD.Vst_Int_Id AS encounterid
        |	,ZTT.Tst_Cod_Ds AS LOCALNAME
        |	,ZTT.Tst_Cod_Abr_Cd AS LOCALTESTNAME
        |	,safe_to_date_length(nullif(substr(TLD.Dta_Cd,0,19), ''),'yyyy-MM-dd HH:mm:ss',0) AS dateavailable
        |	,coalesce(safe_to_date_length(TLD.Pfr_Bye_Int_Id,'yyyy-MM-dd HH:mm:ss',0),safe_to_date_length(TLD.Pfr_Bye_Int_Id,'yyyy-MM-dd',0)) AS LABORDEREDDATE
        |	,TLD.Chi_Ord_Int_Id As LABORDERID
        |	,TLD.Rsu_Val_Ds AS LOCALRESULT
        |	, ROW_NUMBER() OVER (PARTITION BY TLD.lab_dtl_int_id ORDER BY TLD.lst_mod_ts DESC NULLS LAST,
        |                              TLD.FileID DESC NULLS LAST) res_no
        |FROM MCKESSON_PGN_V1_TLB290_LABRESULT_DTL TLD
        |INNER JOIN PAT_VISIT TPV ON TLD.vst_int_id = TPV.vst_int_id
        |LEFT JOIN TEST_COD ZTT ON  TLD.tst_cod_int_id = ZTT.tst_cod_int_id
        |WHERE TLD.TST_COD_INT_ID in ({list_Test})
        |AND nvl(TLD.row_sta_cd,'X') <> 'D'
        |and TLD.Dta_Cd is not null
        |) v
      """
        .stripMargin
        .replace("{list_Test}", list_Test)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }


}

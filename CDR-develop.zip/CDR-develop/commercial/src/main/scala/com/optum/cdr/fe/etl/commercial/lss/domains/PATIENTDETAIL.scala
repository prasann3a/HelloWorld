package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTDETAIL extends FEQueryAndMetadata[patientdetail]{

  override def name: String = CDRFEParquetNames.patientdetail

  override def dependsOn: Set[String] = Set("LSS_TEMP_PATIENT_CACHE")

  override def sparkSql: String =
    """
      |select datasrc,patientid,RowUpdateDateTime as patdetail_timestamp,'FIRST_NAME' as patientdetailtype,firstname as localvalue
      |from LSS_TEMP_PATIENT_CACHE
      |where first_row = 1  and firstname is not null and patientid is not null
      |union
        |select datasrc,patientid,RowUpdateDateTime as patdetail_timestamp,'LAST_NAME' as patientdetailtype,lastname as localvalue
        |from LSS_TEMP_PATIENT_CACHE
        |where last_row = 1  and lastname is not null and patientid is not null
      |union
        |select datasrc,patientid,RowUpdateDateTime as patdetail_timestamp,'MARITAL' as patientdetailtype,maritalstatus as localvalue
        |from LSS_TEMP_PATIENT_CACHE
        |where marital_row = 1  and maritalstatus is not null and patientid is not null
      |union
        |select datasrc,patientid,RowUpdateDateTime as patdetail_timestamp,'LANGUAGE' as patientdetailtype,language as localvalue
        |from LSS_TEMP_PATIENT_CACHE
        |where language_row = 1  and language is not null and patientid is not null
      |union
        |select datasrc,patientid,RowUpdateDateTime as patdetail_timestamp,'DECEASED' as patientdetailtype,deathindicator as localvalue
        |from LSS_TEMP_PATIENT_CACHE
        |where deathindicator_row = 1  and deathindicator is not null and patientid is not null
      |union
        |select datasrc,patientid,RowUpdateDateTime as patdetail_timestamp,'RACE' as patientdetailtype,race as localvalue
        |from LSS_TEMP_PATIENT_CACHE
        |where race_row = 1  and race is not null and patientid is not null
      |union
        |select datasrc,patientid,RowUpdateDateTime as patdetail_timestamp,'GENDER' as patientdetailtype,gender as localvalue
        |from LSS_TEMP_PATIENT_CACHE
        |where gender_row = 1  and gender is not null and patientid is not null
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.cdr.fe.etl.commercial.mckesson_pgn_procedure_cache
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_2 extends FEQueryAndMetadata[mckesson_pgn_procedure_cache]{
  override def name: String = "PROCEDURE_CACHE_2"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_ZH_TSM911_CPT4_REF","MCKESSON_PGN_V1_TPM319_VISIT_CPT4")

  override def sparkSql: String =
    """
      |WITH uni_visit2 AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
      |   WHERE vst_int_id IS NOT NULL )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'
      |   AND Psn_Int_Id IS NOT NULL ),
      |uni_cpt42 AS
      |(SELECT * FROM
      |   (SELECT r.*, ROW_NUMBER() OVER (PARTITION BY cpt4_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
      |      FROM MCKESSON_PGN_V1_ZH_TSM911_CPT4_REF r
      |     WHERE cpt4_int_id IS NOT NULL )
      | WHERE rn = 1
      |   AND  row_sta_cd <> 'D')
      |
      |SELECT m.*
      |      ,NULL as quantity
      |      ,NULL as charge
      |      ,ROW_NUMBER() OVER (PARTITION BY claimid,localcpt,localcptmod1,localcptmod2,localcptmod3,localcptmod4
      |                               ORDER BY Lst_Mod_Ts DESC NULLS LAST) clm_rn
      |      ,ROW_NUMBER() OVER (PARTITION BY patientid, encounterid,proceduredate,localcode
      |                               ORDER BY Lst_Mod_Ts DESC NULLS LAST) proc_rn
      |FROM (
      |SELECT '{groupid}'         	 AS groupid
      |      ,'visit_cpt4'              AS datasrc
      |      ,{client_ds_id}             AS client_ds_id
      |      ,vc4.Cpt4_Int_Id	 	 AS localcode
      |      ,uni_visit2.Psn_Int_Id      AS patientid
      |      ,COALESCE(safe_to_date_length(uni_visit2.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit2.adm_ts) AS proceduredate
      |      ,uni_visit2.Vst_Int_Id 	 AS encounterid
      |      ,NULL		         AS orderingproviderid
      |      ,uni_cpt42.Cpt4_Desc     	 AS localname
      |      ,vc4.Cpt4_Seq_No		 AS procseq
      |      ,NULL 			 AS hosp_px_flag
      |      ,'CPT4'	                 AS codetype
      |      ,nullif(SUBSTR(uni_cpt42.Cpt4_Ext_Id,1,5), '')   AS mappedcode
      |      ,vc4.Car_Gvr_Int_Id        AS performingproviderid
      |      ,NULL     		 AS actualprocdate
      |      ,nullif(SUBSTR(uni_Cpt42.Cpt4_Ext_Id,1,5), '')	 AS localcpt
      |      ,COALESCE(safe_to_date_length(uni_visit2.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit2.adm_ts) AS servicedate
      |      ,concat_ws('', vc4.vst_int_id, '.', vc4.cpt4_int_id, '.', upper(date_format(COALESCE(safe_to_date_length(uni_visit2.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit2.adm_ts),'dd-MMM-yy')))
      |                                 AS claimid
      |      ,NULL		         AS facilityid
      |      ,vc4.Cpt4_Seq_No		 AS seq
      |      ,vc4.Nrv_Cd 		 AS localrev
      |      ,CASE WHEN rlike(vc4.Nrv_Cd, '^[0-9]{4}$') THEN vc4.Nrv_Cd
      |            WHEN rlike(vc4.Nrv_Cd, '^[0-9]{3}$') THEN LPAD(vc4.Nrv_Cd, 4, '0') ELSE NULL END AS mappedrev
      |      ,nullif(SUBSTR(uni_Cpt42.Cpt4_Ext_Id,1,5), '')  AS mappedcpt
      |      ,vc4.Modifier1_Cd AS mappedcptmod1
      |      ,vc4.Modifier2_Cd AS mappedcptmod2
      |      ,vc4.Modifier3_Cd AS mappedcptmod3
      |      ,vc4.Modifier4_Cd AS mappedcptmod4
      |      ,vc4.Modifier1_Cd AS localcptmod1
      |      ,vc4.Modifier2_Cd AS localcptmod2
      |      ,vc4.Modifier3_Cd AS localcptmod3
      |      ,vc4.Modifier4_Cd AS localcptmod4
      |      ,NULL             AS post_dt
      |      ,NULL             AS claimproviderid
      |      ,vc4.Lst_Mod_Ts
      |      ,NULL
      |      ,NULL
      |FROM MCKESSON_PGN_V1_TPM319_VISIT_CPT4 vc4
      |   JOIN UNI_VISIT2 ON (uni_visit2.vst_int_id = vc4.vst_int_id)
      |   JOIN UNI_CPT42 ON (vc4.cpt4_int_id = uni_cpt42.cpt4_int_id)
      |WHERE vc4.row_sta_cd <> 'D'
      |) m
    """.stripMargin


}

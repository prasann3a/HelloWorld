package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.treatment_administered
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.sparkdataloader.CDRFEParquetNames

object TREATMENT_ADMINISTERED extends FEQueryAndMetadata[treatment_administered] {
  override def name: String = CDRFEParquetNames.treatment_administered

  override def dependsOn: Set[String] = Set("MCKESSON_CCDBA_PAT_RESULTS","MCKESSON_ENT_PATIENT","ZCM_TREATMENT_TYPE_CODE")

  override def sparkSql: String =
    """
      |WITH uni_res AS
      |(SELECT * FROM
      |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY result_seq ORDER BY perform_ddt DESC NULLS LAST) rn
      | FROM MCKESSON_CCDBA_PAT_RESULTS p
      | WHERE label_Seq IS NOT NULL
      |   AND pat_seq IS NOT NULL
      |   AND result_Value IS NOT NULL )
      | WHERE rn = 1),
      | uni_pat AS
      | (SELECT * FROM (
      | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
      |    FROM MCKESSON_ENT_PATIENT p
      |   WHERE pat_seq IS NOT NULL )
      |) WHERE rn = 1)
      |select datasrc, encounterid, patientid, order_id, administered_id, administered_date, localcode, cui, administered_quantity, std_unit_cui, NULL as normalized_quantity, administered_prov_id, NULL as master_hgprovid, NULL as hgpid, NULL as grp_mpi, LOCAL_UNIT
      |from
      |(
      |SELECT 'ccdba_pat_results'  AS datasrc
      |	,uni_res.result_seq   AS administered_id
      |	,uni_res.Perform_Ddt  AS administered_date
      |	,concat_ws('', '{client_ds_id}', 'a.', uni_res.label_Seq)    AS localcode
      |	,uni_pat.cpi_seq      AS patientid
      |	,NULL 		      AS administered_prov_id
      |	,uni_res.pat_seq      AS encounterid
      |	,NULL 		      AS order_id
      |	,uni_res.result_Value AS administered_quantity
      |	,z.local_unit 		      	       AS local_unit
      |	,z.treatment_type_cui         	       AS cui
      |	,z.treatment_type_std_units            AS std_unit_cui
      |	,ROW_NUMBER() OVER (PARTITION BY uni_pat.cpi_seq,uni_res.pat_seq,uni_res.label_Seq,uni_res.Perform_Ddt
      |	                    ORDER BY uni_res.perform_ddt DESC NULLS LAST) rn
      |FROM UNI_RES
      |     JOIN ZCM_TREATMENT_TYPE_CODE z ON (z.groupid = '{groupid}' AND z.local_code = concat_ws('', '{client_ds_id}', 'a.', uni_res.label_Seq))
      |     JOIN UNI_PAT ON (uni_pat.pat_seq = uni_res.pat_seq)
      |
      |)
      |where rn = 1
    """
    .stripMargin

}

package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object DIAGNOSIS_TEMP_CHARGE extends FEQueryAndMetadata[diagnosis]{

  override def name: String = "DIAGNOSIS_TEMP_CHARGE"

  override def dependsOn: Set[String] = Set("MED3000_CHARGE_DIAGNOSES","MED3000_CHARGE_TICKET_MASTER","MED3000_ZH_LOCATION")

  override def sparkSql: String =
    """
     select groupid, datasrc, client_ds_id, dx_timestamp, localdiagnosis, patientid, codetype, primarydiagnosis, encounterid, facilityid, mappeddiagnosis, localdiagnosisproviderid
 |from
 |(
 |select a.*,
 |       row_number() over (partition by localdiagnosis,mappeddiagnosis,dx_timestamp,patientid,encounterid order by Update_Date desc nulls last) as rank_diag
 |  from (
 |select
 |       '{groupid}' 			as groupid
 |	   ,'charge_diags' 		as datasrc
 |       ,{client_ds_id} 		as client_ds_id
 |       ,mast.Charge_Date  	as dx_timestamp
 |       ,diag.Diagnosis_Code as localdiagnosis
 |       ,mast.Blind_Key  	as patientid
 |       ,NULL                as codetype
 |       ,mast.Appt_Id  		as encounterid
 |       ,loc.Record_No  		as facilityid
 |       ,mast.Clinician  	as localdiagnosisproviderid
 |       ,case when diag.Diagnosis_Code_Order = '1' then '1' else '0'  end as primarydiagnosis
 |       ,diag.Diagnosis_Code as mappeddiagnosis
 |	   ,diag.Update_Date
 |  from MED3000_CHARGE_DIAGNOSES diag
 | inner join MED3000_CHARGE_TICKET_MASTER mast on (diag.ICChart_CT_ID = mast.ICChart_CT_ID)
 |  left join MED3000_ZH_LOCATION loc on (mast.Location = loc.Code)
 |) a
 |
 |
 |)
 |where dx_timestamp is not null and patientid is not null and rank_diag =1
 |
    """.stripMargin




}

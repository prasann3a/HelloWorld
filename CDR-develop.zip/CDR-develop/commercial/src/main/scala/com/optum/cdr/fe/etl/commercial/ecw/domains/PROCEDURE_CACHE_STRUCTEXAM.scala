package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_STRUCTEXAM extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_STRUCTEXAM"

  override def dependsOn: Set[String] = Set("STRUCTEXAM", "ENC", "ZH_ITEMS", "ZH_PROPERTIES", "MAP_CUSTOM_PROC", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listDetailid = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTEXAM", "PROCEDUREDO",
      "STRUCTEXAM", "DETAILID_2").mkString(",")
    val listItemid = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTEXAM", "PROCEDUREDO",
      "STRUCTEXAM", "ITEMID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localcode
        |       ,encounterid
        |       ,patientid
        |       ,proceduredate
        |       ,localname
        |       ,codetype
        |       ,mappedcode
        |       ,proceduredate AS actualprocdate
        |FROM
        |(
        |	SELECT  t.*
        |	       ,Map_Custom_Proc.Mappedvalue AS mappedcode
        |	       ,ROW_NUMBER() OVER (PARTITION BY t.encounterid,t.catid,t.enc_date,map_custom_proc.mappedvalue ORDER BY t.modifieddate DESC NULLS LAST) rn
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                                               AS groupid
        |		       ,'structexam'                                                                                              AS datasrc
        |		       ,{client_ds_id}                                                                                            AS client_ds_id
        |		       ,CASE WHEN se.itemid IN ({list_itemid}) THEN concat_ws('','{client_ds_id_prefix}',se.detailid,'_',se.itemid) ELSE concat_ws('','{client_ds_id_prefix}',se.catid,'_',se.itemid) END AS localcode
        |		       ,Enc.Patientid                                                                                             AS patientid
        |		       ,CASE WHEN se.detailid IN ({list_detailid}) THEN nvl(safe_to_date(se.value,'MM/dd/yyyy'),safe_to_date(se.value,'MM-dd-yyyy')) ELSE enc.enc_date END AS proceduredate
        |		       ,enc.Encounterid                                                                                           AS encounterid
        |		       ,concat_ws('',zh_items.itemname,'_',prop.Hum_name)                                                         AS localname
        |		       ,'CUSTOM'                                                                                                  AS codetype
        |		       ,enc.modifieddate
        |		       ,se.catid
        |		       ,enc.enc_date
        |		FROM STRUCTEXAM se
        |		JOIN ENC
        |			ON (se.encounterid = enc.encounterid)
        |		LEFT OUTER JOIN ZH_ITEMS
        |			ON (se.catid = zh_items.itemid)
        |		LEFT OUTER JOIN ZH_PROPERTIES prop
        |			ON (prop.propid = se.itemid)
        |		WHERE se.catid IS NOT NULL
        |		AND NVL(LOWER(se.value), 'n/a') NOT IN ('no', 'n/a')
        |	) t
        |	JOIN MAP_CUSTOM_PROC
        |		ON (map_custom_proc.groupid = '{groupid}' AND map_custom_proc.datasrc = 'structexam' AND map_custom_proc.localcode = t.localcode )
        |)
        |WHERE rn = 1
        |AND patientid IS NOT NULL
        |AND proceduredate IS NOT NULL
      """.stripMargin
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{list_detailid}", listDetailid)
        .replace("{list_itemid}", listItemid)
    )
  }
}

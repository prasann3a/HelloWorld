package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object OBSERVATION extends FETableInfo[observation]{

  override def name:String=CDRFEParquetNames.observation

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select * from OBSERVATION1
         | UNION ALL
         | select * from OBSERVATION2
       """.stripMargin)

  }

  override def dependsOn: Set[String] = Set("OBSERVATION1","OBSERVATION2")
}
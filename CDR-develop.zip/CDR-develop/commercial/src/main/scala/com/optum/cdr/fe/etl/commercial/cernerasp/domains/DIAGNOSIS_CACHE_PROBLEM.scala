package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{diagnosis, map_predicate_values}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object DIAGNOSIS_CACHE_PROBLEM extends FETableInfo[diagnosis]{

  override def name: String = "DIAGNOSIS_CACHE_PROBLEM"

  override def dependsOn: Set[String] = Set("PROBLEM", "REFERENCETERMINOLOGY", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listIcd9 = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "ICD9","DIAGNOSIS","DIAGNOSIS","TERMINOLOGY").mkString(",")
    val listSnomed = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "SNOMED","DIAGNOSIS","DIAGNOSIS","TERMINOLOGY").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,client_ds_id
        |       ,datasrc
        |       ,patientid
        |       ,localdiagnosis
        |       ,dx_timestamp
        |       ,mappeddiagnosis
        |       ,resolutiondate
        |       ,codetype
        |       ,localactiveind
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                                                    AS groupid
        |	       ,{client_ds_id}                                                                                                 AS client_ds_id
        |	       ,'problem'                                                                                                      AS datasrc
        |	       ,p.unique_person_identifier                                                                                     AS patientid
        |	       ,p.unique_terminology_identifier                                                                                AS localdiagnosis
        |	       ,coalesce(p.active_status_date_time,status_date_time,onset_date_time)                                           AS dx_timestamp
        |	       ,CASE WHEN rt.terminology IN ({list_snomed}) THEN nullif(ltrim('{SNOMED}',rt.concept),'') ELSE rt.code END      AS mappeddiagnosis
        |	       ,p.actual_resolution_date_time                                                                                  AS resolutiondate
        |	       ,CASE WHEN rt.terminology IN ({list_snomed}) THEN 'SNOMED' WHEN rt.terminology IN ({list_icd9}) THEN 'ICD9' END AS codetype
        |	       ,nvl2(p.status,concat_ws('',{client_ds_id},'.',p.status),null)                                                  AS localactiveind
        |	       ,row_number() over (partition by p.unique_terminology_identifier,p.unique_person_identifier,coalesce(p.active_status_date_time,status_date_time,onset_date_time) ORDER BY coalesce(p.active_status_date_time,status_date_time,onset_date_time) desc nulls last) AS rownumber
        |	FROM PROBLEM p
        |	INNER JOIN REFERENCETERMINOLOGY rt ON (rt.unique_terminology_identifier = p.unique_terminology_identifier)
        |	WHERE p.unique_person_identifier is not null
        |	AND p.unique_terminology_identifier is not null
        |	AND p.active <> '0'
        |	AND p.status <> '3302'
        |	AND rt.terminology IN ({list_icd9},{list_snomed})
        |)
        |WHERE rownumber = 1
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{list_icd9}", listIcd9)
        .replace("{list_snomed}", listSnomed)
    )
  }
}

package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_FACILITY extends FEQueryAndMetadata[zh_facility]{

override def name: String = CDRFEParquetNames.zh_facility

override def dependsOn: Set[String] = Set("ZH_LOCATION", "ADDRESS")

override def sparkSql: String =
  """
    |SELECT  groupid
    |       ,facilityid
    |       ,facilityname
    |       ,facilitypostalcd
    |       ,client_ds_id
    |FROM
    |(
    |	SELECT  '{groupid}'                           AS groupid
    |	       ,f.location_id                         AS facilityid
    |	       ,MIN(nullif(trim(f.location_name),'')) AS facilityname
    |	       ,MIN(nullif(trim(a.addr_zip),''))      AS facilitypostalcd
    |	       ,{client_ds_id}                        AS client_ds_id
    |	FROM ZH_LOCATION f
    |	LEFT OUTER JOIN ADDRESS a
    |	ON (f.IMREADDR_CODE=a.IMREADDR_CODE)
    |	GROUP BY  f.location_id
    |)
  """.stripMargin
}

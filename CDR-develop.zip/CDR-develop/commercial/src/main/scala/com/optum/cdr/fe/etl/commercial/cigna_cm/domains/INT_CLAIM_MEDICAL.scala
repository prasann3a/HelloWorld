package com.optum.cdr.fe.etl.commercial.cigna_cm.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_medical
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_MEDICAL extends FETableInfo[int_claim_medical] {

  override def name: String = CDRFEParquetNames.int_claim_medical

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString

    sparkSession.sql(
      s"""
         |select groupid, datasrc, client_ds_id, claim_header_id, contract_id, member_id, payer_code, payer_name, place_of_service, quantity_of_service, service_date, servicing_prov_id, admit_date, requested_amt, billing_prov_name, billing_prov_id, billing_prov_npi, diag_Rel_grp_code, diag_rel_grp_grouper, denied_flag, denied_reason, discharge_date, discharge_status_code, ein, encounterid, financial_class, icd_diag_cd1, icd_diag_cd2, icd_diag_cd3, icd_diag_cd4, icd_diag_cd5, icd_diag_cd6, icd_diag_cd7, icd_diag_cd8, icd_diag_cd9, icd_diag_cd10, icd_diag_cd_type as icd_diag_cd1_type, icd_diag_cd_type as icd_diag_cd2_type, icd_diag_cd_type as icd_diag_cd3_type, icd_diag_cd_type as icd_diag_cd4_type, icd_diag_cd_type as icd_diag_cd5_type, icd_diag_cd_type as icd_diag_cd6_type, icd_diag_cd_type as icd_diag_cd7_type, icd_diag_cd_type as icd_diag_cd8_type, icd_diag_cd_type as icd_diag_cd9_type, icd_diag_cd_type as icd_diag_cd10_type, icd_proc_cd_1, icd_proc_cd_2, icd_proc_cd_3, icd_proc_cd_4, icd_proc_cd_5, icd_proc_cd_type as icd_proc_cd_1_type, icd_proc_cd_type as icd_proc_cd_2_type, icd_proc_cd_type as icd_proc_cd_3_type, icd_proc_cd_type as icd_proc_cd_4_type, icd_proc_cd_type as icd_proc_cd_5_type, network_paid_status, par_flag, pay_process_date, principle_proc_cd, icd_proc_cd_type as principle_proc_icd_type, proc_cd_modifier_1, proc_cd_modifier_2, proc_code, referring_prov_id, revenue_code, service_from_date, service_to_date, servicing_prov_name, servicing_prov_npi, servicing_prov_spclty_cd, type_of_bill_code, FACILITY_CODE
         |from
         |(
         |SELECT  distinct
         |     '{groupid}' as groupid
         |    ,'Medical' as datasrc
         |    ,{client_ds_id} as client_ds_id
         |    ,nullif(concat_ws('', Indiv_Entpr_Id, Rndr_Prov_Npi, Rndr_Prov_Id, upper(date_format(Svc_Beg_Dt, 'dd-MMM-yy')), upper(date_format(Svc_End_Dt, 'dd-MMM-yy')), Derv_Pos_Cd, Proc_Cd, Revnu_Cd, Proc_Cd_Mod_Cd_1), '')  as claim_header_id
         |    ,bme.Employeraccountid as contract_id
         |    ,mdc.Indiv_Entpr_Id as member_id
         |    ,bme.Employeraccountid as payer_code
         |    ,bme.Employeraccountid as payer_name
         |    ,case when Derv_Pos_Cd =  '*' then  null  else  Derv_Pos_Cd end as place_of_service
         |    ,cast(float(safe_to_number(Derv_Su_Cnt)) as String) as quantity_of_service
         |    ,mdc.Svc_Beg_Dt as service_date
         |    ,case when coalesce(rndr_prov_npi, rndr_prov_id) =  '*' then  null  when {client_ds_id}=10758 then
         |      coalesce(Rndr_Prov_Id,Rndr_Prov_Npi) else coalesce(Rndr_Prov_Npi,Rndr_Prov_Id) end as servicing_prov_id
         |    ,mdc.Admsn_Dt as admit_date
         |    ,safe_to_number(mdc.Derv_Chrg_Amt) as requested_amt
         |    ,mdc.Bill_Prov_Nm as billing_prov_name
         |    ,case when Bill_Prov_Npi =  '*' then  null  else  Bill_Prov_Npi end as billing_prov_id
         |    ,case when Bill_Prov_Npi =  '*' then  null  else  Bill_Prov_Npi end as billing_prov_npi
         |    ,case when Drg_Cd =  '*' then  null  else  Drg_Cd end as diag_Rel_grp_code
         |    ,case when Drg_Cd =  '*' then  null when Drg_Cd is null then  null  else  'MSDRG' end as diag_rel_grp_grouper
         |    ,case when Rsn_Not_Covrd_Cd =  'DN' then  'Y'  else  'N' end as denied_flag
         |    ,mdc.Rmk_Cd as denied_reason
         |    ,mdc.Dischrg_Dt as discharge_date
         |    ,mdc.Dischrg_Stat_Cd as discharge_status_code
         |    ,case when Bill_Prov_Ein =  '*' then  null  else  Bill_Prov_Ein end as ein
         |    ,nullif(concat_ws('', Indiv_Entpr_Id, Rndr_Prov_Npi, Rndr_Prov_Id, upper(date_format(Svc_Beg_Dt, 'dd-MMM-yy')), upper(date_format(Svc_End_Dt, 'dd-MMM-yy')), Derv_Pos_Cd, Proc_Cd, Revnu_Cd, Proc_Cd_Mod_Cd_1), '') as encounterid
         |    ,bme.Employeraccountid as financial_class
         |    ,mdc.Clm_Diag_Cd_1 as icd_diag_cd1
         |    ,mdc.Clm_Diag_Cd_2 as icd_diag_cd2
         |    ,mdc.Clm_Diag_Cd_3 as icd_diag_cd3
         |    ,mdc.Clm_Diag_Cd_4 as icd_diag_cd4
         |    ,mdc.Clm_Diag_Cd_5 as icd_diag_cd5
         |    ,mdc.Clm_Diag_Cd_6 as icd_diag_cd6
         |    ,mdc.Clm_Diag_Cd_7 as icd_diag_cd7
         |    ,mdc.Clm_Diag_Cd_8 as icd_diag_cd8
         |    ,mdc.Clm_Diag_Cd_9 as icd_diag_cd9
         |    ,mdc.Clm_Diag_Cd_10 as icd_diag_cd10
         |    ,case when Icd_Vrsn_Cd =  '09' then  'ICD9' when Icd_Vrsn_Cd =  '10' then  'ICD10'  else  null end as icd_diag_cd_type
         |    ,case when Icd_Proc_Cd_1 =  '*' then  null  else  Icd_Proc_Cd_1 end as icd_proc_cd_1
         |    ,case when Icd_Proc_Cd_2 =  '*' then  null  else  Icd_Proc_Cd_2 end as icd_proc_cd_2
         |    ,case when Icd_Proc_Cd_3 =  '*' then  null  else  Icd_Proc_Cd_3 end as icd_proc_cd_3
         |    ,case when Icd_Proc_Cd_4 =  '*' then  null  else  Icd_Proc_Cd_4 end as icd_proc_cd_4
         |    ,case when Icd_Proc_Cd_5 =  '*' then  null  else  Icd_Proc_Cd_5 end as icd_proc_cd_5
         |    ,case when Icd_Vrsn_Cd =  '09' then  'ICD9' when Icd_Vrsn_Cd =  '10' then  'ICD10'  else  null end as icd_proc_cd_type
         |    ,mdc.Ben_Nt_Lvl_Cd as network_paid_status
         |    ,case when Prov_Partcpnt_Agrmt_Cd =  'PAR' then  'Y' when Prov_Partcpnt_Agrmt_Cd =  'Y' then  'Y' when Prov_Partcpnt_Agrmt_Cd =  'NONPAR' then 'N' when Prov_Partcpnt_Agrmt_Cd =  'N' then  'N'  else  null end as par_flag
         |    ,mdc.Pd_Dt as pay_process_date
         |    ,case when Icd_Proc_Cd_1 =  '*' then  null  else  Icd_Proc_Cd_1 end as principle_proc_cd
         |    ,case when Proc_Cd_Mod_Cd_1 <> '*' and Proc_Ty_Cd in ('HC', 'CP') then Proc_Cd_Mod_Cd_1 else null end as proc_cd_modifier_1
         |    ,case when Proc_Cd_Mod_Cd_2 <> '*' and Proc_Ty_Cd in ('HC', 'CP') then Proc_Cd_Mod_Cd_2 else null end as proc_cd_modifier_2
         |    ,case when Proc_Cd <> '*' and Proc_Ty_Cd in ('HC', 'CP') then Proc_Cd else null end as proc_code
         |    ,case When Refrl_Prov_Npi in ('*','NA') then null else Refrl_Prov_Npi end as referring_prov_id
         |    ,case when Revnu_Cd =  '*' then  null  else  Revnu_Cd end as revenue_code
         |    ,mdc.Svc_Beg_Dt as service_from_date
         |    ,mdc.Svc_End_Dt as service_to_date
         |    ,case when Rndr_Prov_Nm =  '*' then  null  else  Rndr_Prov_Nm end as servicing_prov_name
         |    ,case when Rndr_Prov_Npi =  '*' then  null  else  Rndr_Prov_Npi end as servicing_prov_npi
         |    ,case when Rndr_Prov_Speclty_Cd =  '*' then  null  else  Rndr_Prov_Speclty_Cd end as servicing_prov_spclty_cd
         |    ,mdc.Ty_Of_Bill_Cd as type_of_bill_code
         |    ,case when BILL_PROV_NPI =  '*' then  null  else  BILL_PROV_NPI end as FACILITY_CODE
         |FROM CIGNA_CM_MEDICAL mdc
         |CROSS JOIN ZO_BPO_MAP_EMPLOYER bme ON (bme.client_ds_id = {client_ds_id})
         |)
       """.stripMargin
        .replace("{client_ds_id}",clientDsId).replace("{groupid}",groupId)

    )
  }
 override def dependsOn: Set[String] = Set("CIGNA_CM_MEDICAL","ZO_BPO_MAP_EMPLOYER")
  override def ignoreExtraColumnsInDataFrame: Boolean = true
}
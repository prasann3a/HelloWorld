package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{encounterprovider, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ENCOUNTERPROVIDER extends FETableInfo[encounterprovider]{

override def name: String = CDRFEParquetNames.encounterprovider

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM114_CAR_GVR_FUNC", "MCKESSON_PGN_V1_TPM300_PAT_VISIT", "MCKESSON_PGN_V1_TPM315_VISIT_CARE_GIVER", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val func_int_list = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "PCP_EXC","PROV_PAT_REL","CAR_GVR_FUNC","FUNC_INT_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
       | WITH uni_func AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  d.*
       |	       ,ROW_NUMBER() OVER (PARTITION BY func_aso_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_TPM114_CAR_GVR_FUNC d
       |	WHERE func_aso_int_id IS NOT NULL
       |	AND func_int_id NOT IN ({func_int_list})
       |)
       |WHERE rn = 1
       |AND row_sta_cd <> 'D' ), uni_visit AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  v.*
       |	       ,ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
       |	WHERE Psn_Int_Id IS NOT NULL
       |	AND Vst_Int_Id IS NOT NULL
       |)
       |WHERE rn = 1
       |AND row_sta_cd <> 'D' )
       |SELECT  groupid
       |       ,datasrc
       |       ,client_ds_id
       |       ,encounterid
       |       ,patientid
       |       ,encountertime
       |       ,providerid
       |       ,providerrole
       |       ,facilityid
       |FROM
       |(
       |	SELECT  '{groupid}'                                                                                AS groupid
       |	       ,'visit_care_giver'                                                                         AS datasrc
       |	       ,{client_ds_id}                                                                             AS client_ds_id
       |	       ,gvr.Aso_Eff_Ts                                                                             AS encountertime
       |	       ,uni_func.Car_Gvr_Int_Id                                                                    AS providerid
       |	       ,uni_visit.Psn_Int_Id                                                                       AS patientid
       |	       ,gvr.Vst_Int_Id                                                                             AS encounterid
       |	       ,NULL                                                                                       AS facilityid
       |	       ,NVL2(uni_func.Func_Int_Id,concat_ws('','{client_ds_id_prefix}',uni_func.Func_Int_Id),NULL) AS providerrole
       |	       ,ROW_NUMBER() OVER (PARTITION BY gvr.vst_int_id,uni_func.Car_Gvr_Int_Id,uni_func.Func_Int_Id ORDER BY gvr.Lst_Mod_Ts DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_TPM315_VISIT_CARE_GIVER gvr
       |	JOIN UNI_FUNC
       |	ON (gvr.func_aso_int_id = uni_func.func_aso_int_id)
       |	JOIN UNI_VISIT
       |	ON (gvr.vst_int_id = uni_visit.vst_int_id)
       |	WHERE gvr.Aso_Eff_Ts IS NOT NULL
       |	AND gvr.row_sta_cd <> 'D'
       |)
       |WHERE rn = 1
       """
        .stripMargin
        .replace("{func_int_list}", func_int_list)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", runtimeVar.clientDsId.toString + ".")
    )
  }
}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, observation}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_STRUCTEXAM extends FETableInfo[observation]{

  override def name: String = "OBSERVATION_STRUCTEXAM"

  override def dependsOn: Set[String] = Set("STRUCTEXAM", "ENC", "ZH_PROPERTIES", "ZCM_OBSTYPE_CODE", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val listDetailid = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTEXAM", "OBSERVATION",
      "OBSERVATION", "DETAILID").mkString(",")

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,obsdate
        |       ,localcode
        |       ,localresult
        |       ,obstype
        |       ,null AS obsresult
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                                                           AS groupid
        |	       ,'structexam'                                                                                                          AS datasrc
        |	       ,'{client_ds_id}'                                                                                                      AS client_ds_id
        |	       ,e.encounterid                                                                                                         AS encounterid
        |	       ,e.patientid                                                                                                           AS patientid
        |	       ,e.enc_date                                                                                                            AS obsdate
        |	       ,concat_ws('','{client_ds_id_prefix}',s.itemid)                                                                        AS localcode
        |	       ,s.value                                                                                                               AS localresult
        |	       ,zcm.obstype                                                                                                           AS obstype
        |	       ,row_number() over (partition by e.encounterid,s.catid,e.patientid,e.enc_date ORDER BY e.modifieddate desc nulls last) AS rownumber
        |	FROM STRUCTEXAM s
        |	INNER JOIN ENC e
        |	  ON (s.encounterid = e.encounterid)
        |	INNER JOIN ZH_PROPERTIES zh
        |	  ON (s.itemid = zh.propid)
        |	INNER JOIN ZCM_OBSTYPE_CODE zcm
        |	  ON (zcm.groupid = '{groupid}' AND zcm.datasrc = 'structexam' AND zcm.obscode = concat_ws('', '{client_ds_id_prefix}', s.itemid))
        |	WHERE e.patientid is not null
        |	AND e.enc_date is not null
        |	AND s.itemid is not null
        |	AND s.detailid IN ({list_detailid})
        |)
        |WHERE rownumber = 1
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{list_detailid}", listDetailid)
    )
  }


}

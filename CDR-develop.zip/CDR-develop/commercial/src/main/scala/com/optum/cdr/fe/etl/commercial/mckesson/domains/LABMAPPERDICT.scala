package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader,CDRFEParquetNames}
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.cdr.fe.core.LoaderRunTimeVariables
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.oap.cdr.models.zh_lab_dict

object LABMAPPERDICT extends FETableInfo[zh_lab_dict] {
  override def name: String = CDRFEParquetNames.zh_lab_dict

  override def dependsOn: Set[String] = Set("MCKESSON_ZH_CCDEV_PCQ_LABEL", "ZCM_OBSTYPE_CODE","MCKESSON_ZH_CCDEV_ANC_RES_CODE_SEQS","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val code_sys_list = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "ZH_CCDEV_ANC_RES_CODE_SEQS", "LABMAPPERDICT", "ZH_CCDEV_ANC_RES_CODE_SEQS", "CODING_SYSTEM").mkString(",")

    sparkSession.sql(s"""
                        |select localcode, localname as localdesc, localname, localunits
                        |from
                        |(
                        |SELECT Distinct zh.Label_Seq     AS localcode
                        |	,zh.label_name    AS localname
                        |	,NULL		  AS localunits
                        | FROM MCKESSON_ZH_CCDEV_PCQ_LABEL zh
                        |    JOIN ZCM_OBSTYPE_CODE zcm ON (zcm.groupid = '{groupid}' AND
                        |    				  zcm.datasrc = 'ccdba_pat_results' AND
                        |    				  zcm.obstype = 'LABRESULT'  AND
                        |                                  zcm.obscode = zh.label_seq)
                        |
                        |)
                        |
                        |union all
                        |
                        |select localcode, localname as localdesc, localname, localunits
                        |from
                        |(
                        | SELECT Distinct Result_Label_Seq AS localcode
                        |	  ,result_lname      AS localname
                        |	  ,Result_Units     AS localunits
                        |   FROM MCKESSON_ZH_CCDEV_ANC_RES_CODE_SEQS
                        |   WHERE Result_Label_Seq IS NOT NULL
                        |   AND coding_system IN ({code_sys_list})
                        |
 |)
    """.stripMargin.replace("{code_sys_list}",code_sys_list).replace("{groupid}",groupId))
  }

}

package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.aspro_labresult_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object GTT_LABRESULT_NONNUMERIC_VITALS extends FEQueryAndMetadata[aspro_labresult_cache]{

  override def name: String = "GTT_LABRESULT_NONNUMERIC_VITALS"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE_VITALS")

  override def sparkSql: String =
    """
      |select groupid, datasrc, encounterid, patientid, labresultid, vital_pulse_ox as localresult
      |, 'vitals_pulse_ox' as localcode, 'vitals_pulse_ox' as localname, datecollected, dateavailable
      |, dateavailable as labresult_date, (substr(vital_pulse_ox,1,case when instr_3params(vital_pulse_ox,' ',25) = 0
      |                                  then length(vital_pulse_ox)
      |                                  else instr_3params(vital_pulse_ox,' ',25) end)) as localresult_25, client_ds_id
      |from
      |(
      |LABRESULT_CACHE_VITALS
      |)
      |where vital_pulse_ox is not null and pulse_ox_numeric is null
    """.stripMargin
}

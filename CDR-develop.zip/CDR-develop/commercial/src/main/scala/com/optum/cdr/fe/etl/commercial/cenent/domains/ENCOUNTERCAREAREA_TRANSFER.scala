package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.encountercarearea
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object ENCOUNTERCAREAREA_TRANSFER extends FETableInfo[encountercarearea] {

  override def name: String = "ENCOUNTERCAREAREA_TRANSFER"

  override def dependsOn: Set[String] = Set("ENCNTR", "MAP_PREDICATE_VALUES", "TRANSFER", "ZH_VT")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val listEncntrTypCd = mpvList(mapPredicateValues, groupId, clientDsId.toString,"TRANSFER_DISCH","ENCOUNTERCAREAREA","ENCNTR","ENCNTR_TYPE_CDE").mkString(",")

    sparkSession.sql(
      """
        |with dedup_encounter as
        |( select * from (
        |  select enc.*
        |         ,row_number() over (partition by num ORDER BY data_ts DESC NULLS LAST) rn
        |  from ENCNTR enc
        |  where enc.Num is not null
        |        AND enc.Begin_Dttm is not null AND enc.Pat_Person_Num is not null and encntr_type_cde NOT IN ({list_encntr_typ_cd})
        |
        |  ) where rn=1
        |)
        |,dedup_transfer as
        |(select * from (
        |    select trans.*
        |         ,row_number() over (partition by acct_num, in_date, in_time ORDER BY date_modified DESC NULLS LAST, TRANSACTION_DATE desc nulls last,TRANSACTION_TIME desc nulls last) rn
        |    from TRANSFER trans
        |
        |  ) where rn=1
        |)
        |
        |select groupid, datasrc, patientid, encounterid, encountertime, servicecode, facilityid, localcareareacode, careareastarttime, careareaendtime, client_ds_id, locallocationname
        |from
        |(
        |SELECT '{groupid}' as groupid,'transfer' as datasrc
        |  ,{client_ds_id} as client_ds_id
        |  ,enc.Num AS encounterid
        |  ,enc.Begin_Dttm AS encountertime
        |  ,enc.Pat_Person_Num AS patientid
        |  ,enc.Fac_Num AS facilityid
        |  ,case when trn.out_date is not null then safe_to_date(nullif(concat_ws('', nullif(substr(trn.out_date,1,10), ''), LPAD(nullif(substr(trn.out_time,1,4), ''),4,'0')), ''), 'yyyy-MM-ddHHmm') else null end AS careareaendtime
        |  ,safe_to_date(nullif(concat_ws('', date_format(trn.in_date,'MM/dd/yyyy'), LPAD(nullif(substr(trn.in_time,1,4), ''),4,'0')), ''), 'MM/dd/yyyyHHmm') AS careareastarttime
        |  ,concat_ws('', {client_ds_id}, '.', trn.NS_VT0021)  AS localcareareacode
        |  ,ZHV.Vt_Descr AS locallocationname
        |  ,trn.Service AS servicecode
        |FROM DEDUP_TRANSFER trn
        |INNER JOIN DEDUP_ENCOUNTER enc ON (enc.prim_acct_num = trn.acct_num)
        |LEFT OUTER JOIN ZH_VT ZHV ON (trn.NS_VT0021 = ZHV.vt_name1 and vt_NUM9 = 21)
        |WHERE enc.encntr_cat_cde = 'ACTV' and LPAD(nullif(substr(trn.in_time,1,4), ''),4,'0')<2400
        |)
      """.stripMargin
        .replace("{list_encntr_typ_cd}", listEncntrTypCd)
        .replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId.toString )
    )
  }
}
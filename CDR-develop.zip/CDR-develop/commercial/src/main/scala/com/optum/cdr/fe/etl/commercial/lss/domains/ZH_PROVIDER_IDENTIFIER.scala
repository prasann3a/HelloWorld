package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.zh_provider_identifier
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object ZH_PROVIDER_IDENTIFIER extends FEQueryAndMetadata[zh_provider_identifier]{

  override def name: String = CDRFEParquetNames.zh_provider_identifier

  override def dependsOn: Set[String] = Set("LSS_DPBRPROVIDER")

  override def sparkSql: String =
    """
      |SELECT idtype     AS id_type
      |       ,idvalue    AS id_value
      |       ,providerid AS provider_id
      |FROM
      |(
      |	SELECT  x.*
      |	       ,row_number() over (partition by ProviderID,IDType ORDER BY RowUpdateDateTime desc nulls first,idvalue desc nulls first ) AS rownumber
      |	FROM
      |	(
      |		SELECT 'dpbrprovider'                                       AS datasrc
      |		       ,'DEA'                                                AS idtype
      |		       ,dpb.Misproviderdeanumber                             AS idvalue
      |		       ,nullif(concat_ws('',dpb.Sourceid,dpb.Providerid),'') AS providerid
      |		       ,dpb.RowUpdateDateTime
      |		FROM LSS_DPBRPROVIDER dpb
      |		WHERE dpb.Misproviderdeanumber is not null
      |	) x
      | where x.providerid is not null
      |)
      |WHERE rownumber = 1
    """.stripMargin
}

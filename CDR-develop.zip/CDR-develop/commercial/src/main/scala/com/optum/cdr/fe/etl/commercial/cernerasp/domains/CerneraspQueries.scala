package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.cdr.fe.etl.commercial.unit_remap
import com.optum.cdr.fe.utils.nonnumeric_labs_localresult_25.NONNUMERIC_LABRESULT
import com.optum.oap.cdr.models.{map_custom_proc, map_predicate_values, map_screening_tests, map_unit, metadata_lab, unit_conversion, zcm_obstype_code}
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object CerneraspQueries extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = CerneraspInitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = CerneraspQueryRegistry.queries
}

object CerneraspQueriesDrugAssign extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = CerneraspInitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = CerneraspQueryRegistry.queries ++ CerneraspQueryRegistry.drug_assign_queries
}

object CerneraspInitialDependencies {
  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    // Stage tables
    FELoadFromParquet[manualhealthmaintenance](name="MANUALHEALTHMAINTENANCE",parquetLocation=s"$baseParquetLocation",tableName="MANUALHEALTHMAINTENANCE")
    ,FELoadFromParquet[visit](name="VISIT",parquetLocation=s"$baseParquetLocation",tableName ="VISIT")
    ,FELoadFromParquet[referencehealthplan](name="REFERENCEHEALTHPLAN",parquetLocation=s"$baseParquetLocation",tableName ="REFERENCEHEALTHPLAN")
    ,FELoadFromParquet[ins](name="CERNERASP_INSURANCE",parquetLocation=s"$baseParquetLocation",tableName ="INSURANCE")
    ,FELoadFromParquet[input_allergy](name = "ALLERGY", parquetLocation = s"$baseParquetLocation", tableName = "ALLERGY")
    ,FELoadFromParquet[referenceterminology](name = "REFERENCETERMINOLOGY", parquetLocation = s"$baseParquetLocation", tableName = "REFERENCETERMINOLOGY")
    ,FELoadFromParquet[input_immunization](name = "INPUT_IMMUNIZATION", parquetLocation = s"$baseParquetLocation", tableName = "IMMUNIZATION")
    ,FELoadFromParquet[referencecode](name = "REFERENCECODE", parquetLocation = s"$baseParquetLocation", tableName = "REFERENCECODE")
    ,FELoadFromParquet[charge](name = "CHARGE", parquetLocation = s"$baseParquetLocation", tableName = "CHARGE")
    ,FELoadFromParquet[chargedetail](name = "CHARGEDETAIL", parquetLocation = s"$baseParquetLocation", tableName = "CHARGEDETAIL")
    ,FELoadFromParquet[medications](name = "MEDICATIONS", parquetLocation = s"$baseParquetLocation", tableName = "MEDICATIONS")
    ,FELoadFromParquet[referencemedication](name = "REFERENCEMEDICATION", parquetLocation = s"$baseParquetLocation", tableName = "REFERENCEMEDICATION")
    ,FELoadFromParquet[medicationdetails](name = "MEDICATIONDETAILS", parquetLocation = s"$baseParquetLocation", tableName = "MEDICATIONDETAILS")
    ,FELoadFromParquet[medicationreconciliation](name = "MEDICATIONRECONCILIATION", parquetLocation = s"$baseParquetLocation", tableName = "MEDICATIONRECONCILIATION")
    ,FELoadFromParquet[medicationreconciliationdetail](name = "MEDICATIONRECONCILIATIONDETAIL", parquetLocation = s"$baseParquetLocation", tableName = "MEDICATIONRECONCILIATIONDETAIL")
    ,FELoadFromParquet[input_diagnosis](name = "INPUT_DIAGNOSIS", parquetLocation = s"$baseParquetLocation", tableName = "DIAGNOSIS")
    ,FELoadFromParquet[problem](name = "PROBLEM", parquetLocation = s"$baseParquetLocation", tableName = "PROBLEM")
    ,FELoadFromParquet[relation](name = "RELATION", parquetLocation = s"$baseParquetLocation", tableName = "RELATION")
    ,FELoadFromParquet[address](name = "ADDRESS", parquetLocation = s"$baseParquetLocation", tableName = "ADDRESS")
    ,FELoadFromParquet[result](name="RESULT",parquetLocation =s"$baseParquetLocation",tableName="RESULT")
    ,FELoadFromParquet[identifiers](name="IDENTIFIERS",parquetLocation =s"$baseParquetLocation",tableName="IDENTIFIERS")
    ,FELoadFromParquet[schedulepersonappointment](name="SCHEDULEPERSONAPPOINTMENT",parquetLocation =s"$baseParquetLocation",tableName="SCHEDULEPERSONAPPOINTMENT")
    ,FELoadFromParquet[scheduleresourceappointment](name="SCHEDULERESOURCEAPPOINTMENT",parquetLocation =s"$baseParquetLocation",tableName="SCHEDULERESOURCEAPPOINTMENT")
    ,FELoadFromParquet[schedules](name="SCHEDULES",parquetLocation =s"$baseParquetLocation",tableName="SCHEDULES")
    ,FELoadFromParquet[referencelocation](name="REFERENCELOCATION",parquetLocation =s"$baseParquetLocation",tableName="REFERENCELOCATION")
    ,FELoadFromParquet[phone](name="PHONE",parquetLocation =s"$baseParquetLocation",tableName="PHONE")
    ,FELoadFromParquet[referencepersonnel](name="REFERENCEPERSONNEL",parquetLocation =s"$baseParquetLocation",tableName="REFERENCEPERSONNEL")
    ,FELoadFromParquet[socialhistory](name = "SOCIALHISTORY", parquetLocation = s"$baseParquetLocation", tableName = "SOCIALHISTORY")
    ,FELoadFromParquet[person](name = "PERSON", parquetLocation = s"$baseParquetLocation", tableName = "PERSON")
    ,FELoadFromParquet[personinfo](name = "PERSONINFO", parquetLocation = s"$baseParquetLocation", tableName = "PERSONINFO")
    ,FELoadFromParquet[procedurepersonnel](name = "PROCEDUREPERSONNEL", parquetLocation = s"$baseParquetLocation", tableName = "PROCEDUREPERSONNEL")
    ,FELoadFromParquet[procedure](name = "PROCEDURE", parquetLocation = s"$baseParquetLocation", tableName = "PROCEDURE")
    ,FELoadFromParquet[orders](name = "ORDERS", parquetLocation = s"$baseParquetLocation", tableName = "ORDERS")
    ,FELoadFromParquet[orderdetails](name = "ORDERDETAILS", parquetLocation = s"$baseParquetLocation", tableName = "ORDERDETAILS")


    // Mapping tables
    ,FELoadFromParquet[map_unit](name = "MAP_UNIT", parquetLocation = s"$mappingParquetPath", tableName = "MAP_UNIT")
    ,FELoadFromParquet[unit_remap](name = "UNIT_REMAP", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_REMAP")
    ,FELoadFromParquet[metadata_lab](name = "METADATA_LAB", parquetLocation = s"$mappingParquetPath", tableName = "METADATA_LAB")
    ,FELoadFromParquet[unit_conversion](name = "UNIT_CONVERSION", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_CONVERSION")
    ,FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PREDICATE_VALUES")
    ,FELoadFromParquet[map_screening_tests](name="MAP_SCREENING_TESTS",parquetLocation=s"$mappingParquetPath",tableName="MAP_SCREENING_TESTS")
    ,FELoadFromParquet[zcm_obstype_code](name="ZCM_OBSTYPE_CODE",parquetLocation=s"$mappingParquetPath",tableName="ZCM_OBSTYPE_CODE")
    ,FELoadFromParquet[map_custom_proc](name="MAP_CUSTOM_PROC",parquetLocation=s"$mappingParquetPath",tableName="MAP_CUSTOM_PROC")

  )

}

object CerneraspQueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
         HEALTH_MAINTENANCE
        ,INSURANCE
        ,ALLERGIES
        ,IMMUNIZATION
        ,CLAIM
        ,RX_PAT_REP_CACHE_MEDICATIONS
        ,RX_PAT_REP_CACHE_MEDICATIONRECONCILIATION
        ,RX_PAT_REP
        ,DIAGNOSIS_CACHE_CHARGE
        ,DIAGNOSIS_CACHE_DIAGNOSIS
        ,DIAGNOSIS_CACHE_PROBLEM
        ,DIAGNOSIS
        ,PROV_PAT_REL
        ,APPOINTMENT_CACHE
        ,APPOINTMENT
        ,ZH_APPT_LOCATION
        ,ZH_FACILITY_CACHE
        ,ZH_FACILITY
        ,PATIENTADDR
        ,PATIENTCONTACT
        ,TEMP_CLINICALENCOUNTER_CACHE
        ,CLINICALENCOUNTER
        ,ENCOUNTERPROVIDER
        ,OBSERVATION_PART_1
        ,OBSERVATION_PART_2
        ,OBSERVATION
        ,PATIENT_CACHE
        ,PATIENT_DETAIL
        ,PATIENT
        ,PATIENT_ID_CACHE
        ,PATIENT_ID
        ,ZH_PROVIDER_CACHE
        ,ZH_PROVIDER
        ,ZH_PROVIDER_IDENTIFIER
        ,ZH_LAB_DICT_TABL_UNITS
        ,ZH_LAB_DICT_TBL_SITE
        ,ZH_LAB_DICT_CACHE
        ,ZH_LAB_DICT
        ,PROCEDUREDO1
        ,PROCEDUREDO2
        ,PROCEDUREDO3
        ,PROCEDUREDO4
        ,PROCEDUREDO
    ,LABRESULTRFR
    ,LABRESULTTBLUNITS
        ,LABRESULTCACHE
        ,GTT_LABRESULT_NONNUMERIC
        ,NONNUMERIC_LABRESULT
        ,LABRESULT
        ,RXORDER1
        ,RXORDER2
        ,RXORDER3
        ,RXORDER
  )

  val drug_assign_queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    MEDICATION_MAP_SRC
    , MEDICATION_MAP_SRC_ALLERGY
    , MEDICATION_MAP_SRC_MEDICATIONS
    , MEDICATION_MAP_SRC_ORDERS
    , MEDICATION_MAP_SRC_MEDICATIONRECONCILIATION
    , MEDICATION_MAP_SRC_IMMUNIZATION
  )

}

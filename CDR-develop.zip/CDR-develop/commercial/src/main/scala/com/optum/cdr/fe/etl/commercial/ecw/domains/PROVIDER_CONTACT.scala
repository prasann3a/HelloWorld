package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.zh_provider_contact
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROVIDER_CONTACT extends FEQueryAndMetadata[zh_provider_contact]{

  override def name: String = CDRFEParquetNames.zh_provider_contact

  override def dependsOn: Set[String] = Set("USERS", "DOCTORS")

  override def sparkSql: String =
    """
      WITH uni_users AS
 |(SELECT * FROM (
 |   SELECT u.*, ROW_NUMBER() OVER (PARTITION BY hum_uid ORDER BY mdate DESC NULLS LAST) rn
 |   FROM USERS u
 |   WHERE usertype in ('1','2','5','9')
 |   and coalesce (Upaddress,Upaddress2,Upcity,Upstate,Zipcode,Uemail) is not null
 |   )
 |  WHERE rn = 1),
 |uni_doctors AS
 |(SELECT * FROM (
 |   SELECT d.*, ROW_NUMBER() OVER (PARTITION BY doctorid ORDER BY modifieddate DESC NULLS LAST) rn
 |   FROM DOCTORS d
 |
 |   )
 |  WHERE rn = 1)
 |
 |select groupid, client_ds_id, datasrc, local_provider_id, address_line1, address_line2, city, state, zipcode, email_address, update_date, local_contact_type
 |from
 |(
 |SELECT  '{groupid}' as groupid,'DOCTORS' as datasrc
 |	,{client_ds_id} as client_ds_id
 |	,srs.Mdate AS update_date
 |	,'PROVIDER' AS local_contact_type
 |	,srs.Hum_Uid AS local_provider_id
 |	,srs.Upaddress AS address_line1
 |	,srs.Upaddress2 AS address_line2
 |	,srs.Upcity AS city
 |	,srs.Uemail AS email_address
 |	,srs.Upstate AS state
 |	,srs.Zipcode AS zipcode
 |FROM UNI_USERS srs
 |INNER JOIN UNI_DOCTORS dct ON (srs.Hum_Uid=dct.DoctorID)
 |WHERE srs.Mdate is not null
 | AND srs.Hum_Uid is not null
 |
 |)
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.cattails.domains


import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.verify.MedicationMapSrcVerify
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC extends FETableInfo[medication_map_src]{

  override def name: String = CDRFEParquetNames.medication_map_src

  override def dependsOn: Set[String] = Set("ITEM_DETAIL_MEDICATIONS_TB", "MECCA_TERM_DETAILS_TB", "MED_DRUGS_TB")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val srcMedMapInput = sparkSession.sql(
      """
	     |select groupid, client_ds_id, datasrc, localmedcode, localmeddescription as localdescription, localgenericdescription as localgeneric, num_recs,
         |localndc, has_ndc,no_ndc,ndc_src
         |from
         |(
         |SELECT '{groupid}' as groupid,'item_detail_medications_tb' as datasrc
         |     ,{client_ds_id} as client_ds_id
         |     ,MTD.Mectrm_Id AS localmedcode
         |     ,MTD.Term_Desc AS localmeddescription
         |     ,MTD.Formatted_Term_Desc AS localgenericdescription
         |     ,count(*) as num_recs
         |     ,null as localndc
         |     ,0 as has_ndc
         |     ,count(*) as no_ndc
         |     ,cast(null as String) as ndc_src
         |FROM ITEM_DETAIL_MEDICATIONS_TB IDM
         |INNER JOIN MECCA_TERM_DETAILS_TB MTD ON (IDM.MECTRMDTL_ID = MTD.MECTRMDTL_ID)
         |WHERE MTD.Mectrm_Id is not null
         |AND MTD.Term_Desc is not null

         |GROUP BY MTD.Mectrm_Id,MTD.Term_Desc,MTD.Formatted_Term_Desc
         |)

         |union all

         |select groupid, client_ds_id, datasrc, localmedcode, localmeddescription as localdescription, localgenericdescription as localgeneric, num_recs,
         |localndc,has_ndc,no_ndc,ndc_src
         |from
         |(
         |SELECT '{groupid}' as groupid,'med_events_tb' as datasrc
         |    ,{client_ds_id} as client_ds_id
         |    ,MDT.Med_Drug_Id AS localmedcode
         |    ,MDT.Drug_Name AS localmeddescription
         |    ,MDT.Generic_Name AS localgenericdescription
         |    ,count(*) as num_recs
         |    ,null as localndc
         |    ,0 as has_ndc
         |    ,count(*) as no_ndc
         |    ,cast(null as String) as ndc_src
         |FROM MED_DRUGS_TB MDT
         |WHERE MDT.Med_Drug_Id is not null
         |AND MDT.Drug_Name is not null

         |group by MDT.Med_Drug_Id,MDT.Drug_Name,MDT.Generic_Name
         |)
""".stripMargin.replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId))
    MedicationMapSrcVerify.run(srcMedMapInput)
  }
}

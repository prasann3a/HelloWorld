package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object RXORDER extends FEQueryAndMetadata[rxorder] {

  override def name: String = CDRFEParquetNames.rxorder

  override def dependsOn: Set[String] = Set("MEDICATIONS", "ZH_DRUGS")

  override def sparkSql: String =
    """
      |select groupid, datasrc, encounterid, patientid, rxid, localmedcode, localproviderid, issuedate, discontinuedate, quantityperfill,
      |fillnum, signature, altmedcode, orderstatus, localdescription, venue, localdaysupplied, localstrengthperdoseunit, localstrengthunit,
      |localroute, localform, localqtyofdoseunit, localdoseunit, localtotaldose, localdosefreq, localduration, localndc, localgpi,
      |localdaw, ordervsprescription, client_ds_id
      |from
      |(
      |select
      |med.groupid, med.datasrc, med.encounterid, med.patientid, med.rxid, med.localmedcode, med.localproviderid, med.issuedate, med.discontinuedate
      |	       , med.quantityperfill, med.fillnum, med.signature, med.altmedcode, med.orderstatus, med.localdescription, med.venue, med.localdaysupplied
      |	       , med.localstrengthperdoseunit, med.localstrengthunit, med.localroute, med.localform, med.localqtyofdoseunit, med.localdoseunit
      |	       , med.localtotaldose, med.localdosefreq, med.localduration, med.localndc, med.localgpi,med.localdaw
      |	       ,'P' as ordervsprescription
      |	       ,{client_ds_id} as client_ds_id
      |from
      |(select '{groupid}'                               as groupid,
      |        'medications'                         as datasrc
      |       ,m.imreenc_code                         as encounterid
      |       ,m.imredemec_code                       as patientid
      |       ,concat_ws('', m.imreenc_code, '_', m.imremed_code)   as rxid
      |       ,m.med_code                             as localmedcode
      |       ,m.supervisor_id                       AS localproviderid
      |       ,coalesce(m.med_dateordered,m.med_startdate,m.tag_systemdate)     as issuedate
      |       ,m.med_enddate                         as discontinuedate
      |       ,m.med_quantity                         as quantityperfill
      |       ,null                                   as fillnum
      |       ,m.med_comment                           as signature
      |       ,null                                   as altmedcode
      |       ,concat_ws('', 'asp.', m.med_status)                  AS orderstatus
      |       ,COALESCE(zd.Drug_Title, m.Med_Originaltitle) AS localdescription
      |       ,'1'                                   as venue
      |       ,m.med_days                            as localdaysupplied
      |       ,zd.drug_strength                      as localstrengthperdoseunit
      |       ,m.med_dose                             as localstrengthunit
      |       ,zd.drug_route                          as localroute
      |       ,m.med_doseunit                         as localform
      |       ,m.med_intake                           as localqtyofdoseunit
      |       ,zd.drug_dose                           as localdoseunit
      |       ,safe_to_number(m.med_dose) * safe_to_number(m.med_intake) as localtotaldose
      |       ,m.med_frequency                       as localdosefreq
      |       ,null                                   as localduration
      |
      |       ,NULL                                  AS localndc
      |       ,m.med_gpi                              as localgpi
      |       ,m.med_dispenseaswritten								as localdaw
      |      ,ROW_NUMBER() OVER (PARTITION BY m.imredemec_code,m.imreenc_code,m.imremed_code ORDER BY m.tag_systemdate DESC nulls last) rownumber
      |from MEDICATIONS m
      |left outer join ZH_DRUGS zd on (zd.drug_code = m.med_code)
      |where m.tag_systemdate is not null
      |and   m.tag_systemdate >= to_date('20050101','yyyyMMdd')
      |and   m.imredemec_code is not null
      |and   nullif(concat_ws('', m.imreenc_code, m.imremed_code), '') is not null
      |and   m.med_status <> 6
      |
      |) med
      |where med.rownumber=1
      |
      |)
    """.stripMargin

}


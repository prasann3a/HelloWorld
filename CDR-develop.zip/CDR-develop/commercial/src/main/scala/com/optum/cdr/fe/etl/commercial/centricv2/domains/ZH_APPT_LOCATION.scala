package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.zh_appt_location
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object ZH_APPT_LOCATION extends FEQueryAndMetadata[zh_appt_location]{

  override def name: String = "ZH_APPT_LOCATION"

  override def dependsOn: Set[String] = Set(
    "CENTRICV2_ZH_LOCATIONREG"
    , "CENTRICV2_ZH_DOCTORFACILITY"
  )

  override def sparkSql: String =
  """
    |select locationid, locationname
    |from
    |(
    |select
    |    'locationreg'  as datasrc
    |    ,zlz.name       as locationname
    |    ,zlz.locid      as locationid
    |from CENTRICV2_ZH_LOCATIONREG  zlz
    |where 1=1
    |and zlz.name    is not null
    |and zlz.locid   is not null
    |)
    |
    |union
    |
    |select locationid, locationname
    |from
    |(
    |select
    |    'doctorfacility'  as datasrc
    |    ,zlz.Orgname       as locationname
    |    ,zlz.Doctorfacilityid      as locationid
    |from CENTRICV2_ZH_DOCTORFACILITY  zlz
    |where 1=1
    |and zlz.Doctorfacilityid  is not null
    |)
  """.stripMargin

}

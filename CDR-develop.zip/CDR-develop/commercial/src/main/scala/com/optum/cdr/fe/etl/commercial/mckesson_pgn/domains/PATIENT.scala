package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT extends FEQueryAndMetadata[patient]{

override def name: String = CDRFEParquetNames.patient

override def dependsOn: Set[String] = Set("TEMP_PATIENT_CACHE")

override def sparkSql: String =
  """
    |SELECT  groupid
    |       ,datasrc
    |       ,client_ds_id
    |       ,patientid
    |       ,dateofbirth
    |       ,dateofdeath
    |       ,medicalrecordnumber
    |       ,inactive_flag
    |FROM
    |(
    |   TEMP_PATIENT_CACHE
    |)
    |WHERE rownumber = 1
  """.stripMargin
}

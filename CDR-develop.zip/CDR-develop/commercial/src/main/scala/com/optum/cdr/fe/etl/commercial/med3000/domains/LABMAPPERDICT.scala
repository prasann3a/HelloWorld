package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.zh_lab_dict
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object LABMAPPERDICT extends FEQueryAndMetadata[zh_lab_dict]{

  override def name: String = CDRFEParquetNames.zh_lab_dict

  override def dependsOn: Set[String] = Set("MED3000_LAB_RESULT","MED3000_PATIENT_HM","ZCM_OBSTYPE_CODE","MED3000_ZH_VITALS_MASTER")

  override def sparkSql: String =
    """|select groupid, client_ds_id, localcode, localname, localdesc, localunits
       |from
       |(
       |select
       |        '{groupid}' 				as groupid
       |       ,'lab_result' 			as datasrc
       |       ,{client_ds_id} 			as client_ds_id
       |       ,lab.Resulted_Test_Id  	as localcode
       |       ,lower(lab.Resulted_Test_Desc)  as localdesc
       |       ,lower(lab.Resulted_Test_Desc)  as localname
       |       ,lower(lab.Units)  		as localunits
       |       ,row_number() over (partition by lab.Resulted_Test_Id,lower(lab.Units) order by length(lab.Resulted_Test_Desc) desc nulls last) as rank_labdict
       |  from MED3000_LAB_RESULT lab
       |
       |)
       |where localcode is not null and rank_labdict = 1
       |
       |union all
       |
       |select groupid, client_ds_id, localcode, localname, localdesc, localunits
       |from
       |(
       |select '{groupid}' 			as groupid
       |       ,'pat_hm' 			as datasrc
       |       ,{client_ds_id} 				as client_ds_id
       |       ,hm.Hm_Master_Key  	as localcode
       |       ,hm.Item_Link_Description  	as localdesc
       |       ,hm.Item_Link_Description  	as localname
       |       ,z.Localunit  				as localunits
       |       ,row_number() over (partition by hm.Hm_Master_Key order by length(hm.Item_Link_Description) desc nulls last) as rank_labdict
       |  from MED3000_PATIENT_HM hm
       | inner join ZCM_OBSTYPE_CODE z
       |    on (z.groupid='{groupid}' and z.datasrc='pat_hm'  and hm.Hm_Master_Key = z.obscode and Obstype = 'LABRESULT')
       |
       |
       |)
       |where localcode is not null and rank_labdict = 1
       |
       |union all
       |
       |select groupid, client_ds_id, localcode, localname, localdesc, localunits
       |from
       |(
       |select
       |       '{groupid}' 				as groupid
       |       ,'pat_vitals' 			as datasrc
       |       ,{client_ds_id} 			as client_ds_id
       |       ,vit.Vitals_Master_Key  	as localcode
       |       ,vit.Vitals_Label  		as localdesc
       |       ,vit.Vitals_Label  		as localname
       |       ,z.Localunit  			as localunits
       |       ,row_number() over (partition by vit.Vitals_Master_Key  order by length(vit.Vitals_Label) desc nulls last) as rank_labdict
       |  from MED3000_ZH_VITALS_MASTER vit
       | inner join ZCM_OBSTYPE_CODE z
       |    on (z.groupid='{groupid}' and z.datasrc='pat_vitals'  and vit.Vitals_Master_Key  = z.obscode and Obstype = 'LABRESULT')
       |
       |
       |)
       |where localcode is not null and rank_labdict = 1""".stripMargin
}

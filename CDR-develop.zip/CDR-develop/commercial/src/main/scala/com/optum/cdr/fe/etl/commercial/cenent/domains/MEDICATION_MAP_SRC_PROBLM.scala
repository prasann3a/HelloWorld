package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.verify.MedicationMapSrcVerify
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_PROBLM extends FETableInfo[medication_map_src]{
  override def name: String = "MEDICATION_MAP_SRC_PROBLM"

  override def dependsOn: Set[String] = Set("PROBLM","ZH_XCNCPT")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs
        from
        (
        SELECT '{groupid}' as groupid
                ,'problm' as datasrc
          ,{client_ds_id} as client_ds_id
                ,problm.Xcncpt_Descr_Num as localmedcode
                ,NULL  as localndc
                ,Zh_Xcncpt.Nm as localdescription
                ,sum(case when NULL is null then 1 else 0 end) as no_ndc
                ,sum(case when NULL is null then 0 else 1 end) as has_ndc
                ,count(*) as num_recs
        FROM PROBLM problm
              LEFT OUTER JOIN ZH_XCNCPT ON (problm.xcncpt_descr_num =zh_xcncpt.num)
        WHERE zh_xcncpt.concept_type_cde = 'ALLRGY'
        GROUP BY problm.Xcncpt_Descr_Num, Zh_Xcncpt.Nm)
       """.replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId))
  }
}

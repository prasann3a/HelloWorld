package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{laborder, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object LABORDER extends FETableInfo[laborder]{

  override def name: String = CDRFEParquetNames.laborder

  override def dependsOn: Set[String] = Set("LABDATA", CDRFEParquetNames.clinicalencounter, "ZH_ITEMS", "VITALS", "ZH_VITALTYPES", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val parentIdList = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LABORDER", "LABORDER",
      "ZH_ITEMS", "PARENTID").mkString(",")

    val vitalIdList = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LABORDER", "VITALS",
      "VITALS", "VITALID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH dedup_labdata AS (
        |      SELECT  *
        |      FROM
        |      (
        |            SELECT  l.*
        |                  ,ROW_NUMBER() OVER (PARTITION BY Reportid ORDER BY received DESC NULLS LAST,modifieddate DESC nulls last) rn
        |            FROM LABDATA l
        |      )
        |      WHERE rn = 1
        |)
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,laborderid
        |       ,encounterid
        |       ,patientid
        |       ,localtestname
        |       ,laborder_date
        |       ,orderingproviderid
        |       ,localtestdescription
        |       ,null as dateordered
        |       ,specimincollecttime
        |       ,localspecimentype
        |FROM
        |(
        |	SELECT  '{groupid}'                                                          AS groupid
        |	       ,'labdorders'                                                         AS datasrc
        |	       ,{client_ds_id}                                                       AS client_ds_id
        |	       ,Labdata.Reportid                                                     AS laborderid
        |	       ,Labdata.Encounterid                                                  AS encounterid
        |	       ,Enc.Patientid                                                        AS patientid
        |	       ,Zh_Items.Itemname                                                    AS localtestname
        |	       ,CASE WHEN Labdata.Ordphyid = '0' THEN null ELSE Labdata.Ordphyid END AS orderingproviderid
        |	       ,Zh_Items.Itemdesc                                                    AS localtestdescription
        |	       ,CASE WHEN Labdata.Colldate IN ('0001-01-01 00:00:00','1901-01-01 00:00:00','1901-01-01 00:00:00.0','0001-01-01','1901-01-01') THEN NULL
        |	             WHEN Labdata.Colldate IS NULL THEN labdata.modifieddate
        |              ELSE safe_to_date(nullif(concat_ws('',date_format(Labdata.colldate,'yyyy-MM-dd'),Labdata.colltime),''),'yyyy-MM-ddHH:mm:ss') END AS specimincollecttime
        |	       ,Labdata.modifieddate                                                 AS laborder_date
        |	       ,concat_ws('',Labdata.collsource,'_',Labdata.colldescription)         AS localspecimentype
        |	FROM DEDUP_LABDATA labdata
        |	JOIN {CLINICALENCOUNTER} enc
        |	      ON (Labdata.Encounterid = enc.EncounterID)
        |	LEFT OUTER JOIN ZH_ITEMS
        |	      ON (Labdata.ItemID = Zh_Items.ItemID)
        |	WHERE enc.client_ds_id = {client_ds_id}
        |	AND Zh_Items.ParentID IN ({parent_id_list})
        |	AND (labdata.DeleteFlag <> '1' or labdata.Cancelled <> '1')
        |	AND Enc.Patientid is not null
        |	AND Labdata.modifieddate is not null
        |)
        |
        |UNION ALL
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,laborderid
        |       ,encounterid
        |       ,patientid
        |       ,localtestname
        |       ,laborder_date
        |       ,null as orderingproviderid
        |       ,localtestdescription
        |       ,dateordered
        |       ,null as specimincollecttime
        |       ,null as localspecimentype
        |
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                 AS groupid
        |	       ,'vitals'                                                                    AS datasrc
        |	       ,{client_ds_id}                                                              AS client_ds_id
        |	       ,vitals.id                                                                   AS laborderid
        |	       ,vitals.encounterid                                                          AS encounterid
        |	       ,Enc.Patientid                                                               AS patientid
        |	       ,CASE WHEN {client_ds_id} = 2063 THEN 'SpO2' ELSE Zh_vitaltypes.hum_type END AS localtestname
        |	       ,coalesce(vitals.updatedtime,enc.arrivaltime)                                AS dateordered
        |	       ,zh_vitaltypes.hum_type                                                      AS localtestdescription
        |	       ,current_date                                                                AS laborder_date
        |	FROM VITALS vitals
        |	JOIN {CLINICALENCOUNTER} enc
        |	      ON (vitals.Encounterid = enc.EncounterID)
        |	LEFT OUTER JOIN ZH_VITALTYPES zh_vitaltypes
        |	      ON (vitals.vitalid = zh_vitaltypes.itemid)
        |	WHERE enc.client_ds_id = {client_ds_id}
        |	AND vitals.hum_value is not null
        |	AND vitals.vitalid IN ({vital_id_list})
        |	AND Enc.Patientid is not null
        |)
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{parent_id_list}", parentIdList)
        .replace("{vital_id_list}", vitalIdList)
    )
  }
}

package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.laborder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object LABORDER extends FEQueryAndMetadata[laborder] {

  override def name: String = CDRFEParquetNames.laborder

  override def dependsOn: Set[String] = Set("ORDERZ", "ZH_XSERVC")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localtestname, patientid, dateordered, encounterid, facilityid, laborderid, localtestdescription, statuscode, laborder_date
      |from
      |(
      |SELECT
      |       t.*
      |      ,row_number() OVER (PARTITION BY laborderid ORDER BY laborder_date DESC NULLS LAST)    AS rownumber
      |FROM (SELECT
      |        '{groupid}'                                                                           AS groupid
      |       ,'orderz'                                                                              AS datasrc
      |       ,{client_ds_id}                                                                        AS client_ds_id
      |       ,zxs.nm                                                                                AS localtestname
      |       ,o.pat_person_num                                                                      AS patientid
      |       ,o.begin_dttm                                                                          AS dateordered
      |       ,o.encntr_num                                                                          AS encounterid
      |       ,o.fac_num                                                                             AS facilityid
      |       ,nullif(concat_ws('', o.pat_person_num, date_format(o.data_create_ts, 'yyyyMMddHHmmss'), o.serv_descr_num), '')     AS laborderid
      |       ,zxs.nm                                                                                AS localtestdescription
      |       ,nullif(concat_ws('', o.order_status_cde, o.order_substatus_cde), '')                                             AS statuscode
      |       ,o.data_create_ts                                                                      AS laborder_date
      |FROM ORDERZ o
      |LEFT JOIN ZH_XSERVC zxs
      |     ON (zxs.num = o.serv_descr_num)
      |WHERE o.serv_type_cde = 'LAB' and nullif(concat_ws('', o.order_status_cde, o.order_substatus_cde), '') in('A','AU','IE','IX', 'AF') ) t
      |)
      |where rownumber = 1
    """.stripMargin
}
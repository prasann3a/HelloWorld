package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.prov_spec
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object PROV_SPEC extends FEQueryAndMetadata[prov_spec]{

  override def name: String = CDRFEParquetNames.prov_spec

  override def dependsOn: Set[String] = Set("LSS_DPBRPROVIDER")

  override def sparkSql: String =
    """
      |SELECT  localproviderid
      |       ,localspecialtycode
      |FROM
      |(
      |	SELECT  x.*
      |	       ,row_number() over (partition by LocalProviderID ORDER BY RowUpdateDateTime desc nulls first ) AS rownumber
      |	FROM
      |	(
      |		SELECT  'dpbrprovider'                                       AS datasrc
      |		       ,nullif(concat_ws('',dpb.Sourceid,dpb.Providerid),'') AS localproviderid
      |		       ,dpb.Specialtyid                                      AS localspecialtycode
      |		       ,dpb.RowUpdateDateTime
      |		FROM LSS_DPBRPROVIDER dpb
      |		WHERE nullIF(concat_ws('', dpb.Sourceid, dpb.Providerid), '') is not null
      |		AND dpb.Specialtyid is not null
      |	) x
      |)
      |WHERE rownumber = 1
    """.stripMargin
}

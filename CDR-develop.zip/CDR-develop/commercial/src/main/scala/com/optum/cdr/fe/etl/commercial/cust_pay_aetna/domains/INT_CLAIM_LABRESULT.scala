package com.optum.cdr.fe.etl.commercial.cust_pay_aetna.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.int_claim_labresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_LABRESULT extends FETableInfo[int_claim_labresult]
{
  override def name: String = CDRFEParquetNames.int_claim_labresult

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString
    val maskedIdInclusion = mpvList(mapPredicateValues, groupId, clientDsId,"MASKED_CLAIMS","INTERMEDIATE_CLAIMS","INTERMEDIATE_CLAIMS","CLIENT_DS_ID")
    val maskedIdInclusionList = if (maskedIdInclusion.toString.equals("'Y'")) "' '" else "'00000000000000000000'"

    sparkSession.sql(
      s"""
         |with ll as
         |(
         | select
         |        LA.fileid, max(LA.transact_date) as transact_date
         | from AETNLABD LA
         | group by LA.fileid
         |)
         |select groupid, datasrc, client_ds_id, claim_header_id, collection_date, loinc_code, labresult_id, member_id, result_date, test_order_name, abnormal_flag, encounterid, fasting_status, loinc_name, order_date, ordering_prov_id, ordering_prov_npi, reference_range, result_code, result_name, test_order_code, test_result_text, test_result_units
         |from
         |(
         | select
         |       '{groupid}'                as groupid
         |      ,'AETNLABD'                 as datasrc
         |      ,{client_ds_id}          	as client_ds_id
         |      ,concat_ws('', member_id, '_', date_format(srv_start_dt,'yyyyMMdd'), '_', loinc_cd, '_', lab_result_txt) as claim_header_id
         |      ,collection_dt          as collection_date
         |      ,loinc_cd               as loinc_code
         |      ,concat_ws('', member_id, '_', date_format(srv_start_dt,'yyyyMMdd'), '_', loinc_cd, '_', lab_result_txt) as labresult_id
         |      ,member_id              as member_id
         |      ,srv_start_dt           as result_date
         |      ,coalesce(case when upper(lab_test_nm) in ('NA', 'NULL') then null else lab_test_nm end, loinc_description) as test_order_name
         |      ,case when lab_abn_text not in ('NA', 'N') then 'Y' else 'N' end  as abnormal_flag
         |      ,concat_ws('', member_id, '_', date_format(srv_start_dt,'yyyyMMdd'), '_', loinc_cd, '_', lab_result_txt) as encounterid
         |      ,fasting_ind            as fasting_status
         |      ,loinc_description      as loinc_name
         |      ,collection_dt          as order_date
         |      ,case when ordering_prv_npi_nbr = '0' then null else ordering_prv_npi_nbr end	as ordering_prov_id
         |      ,case when ordering_prv_npi_nbr = '0' then null else ordering_prv_npi_nbr end   as ordering_prov_npi
         |      ,case when upper(lab_nrml_rslt_rng) in ('NA', 'NOT APPLICABLE') then concat_ws('', round(safe_to_number(lab_low_range), 1), '-', round(safe_to_number(lab_high_range), 1))
         |            when upper(lab_nrml_rslt_rng) in ('NULL','SEE NOTES','SEE NOTE:','SEE BELOW','N/A','NOT ESTABLISHED','NOT ESTAB.') then null
         |            else lab_nrml_rslt_rng
         |            end			    as reference_range
         |      ,loinc_cd               as result_code
         |      ,coalesce(case when upper(lab_test_nm) in ('NA', 'NULL') then null else lab_test_nm end, loinc_description) as result_name
         |      ,loinc_cd               as test_order_code
         |      ,lab_result_txt         as test_result_text
         |      ,lab_units_txt          as test_result_units
         |      ,row_number() over (partition by concat_ws('', member_id, '_', date_format(srv_start_dt,'yyyyMMdd'), '_', loinc_cd, '_', lab_result_txt) order by ll.transact_date desc nulls last ) as rw_id
         | from AETNLABD lb
         | inner join LL on ll.fileid = lb.fileid
         | where member_id <> {masked_id_inclusion}
         |)
         |where rw_id = 1
       """.stripMargin
        .replace("{client_ds_id}",clientDsId).replace("{groupid}",groupId).replace("{masked_id_inclusion}",maskedIdInclusionList)
    )
  }

  override def dependsOn: Set[String] = Set("AETNLABD","MAP_PREDICATE_VALUES")

}

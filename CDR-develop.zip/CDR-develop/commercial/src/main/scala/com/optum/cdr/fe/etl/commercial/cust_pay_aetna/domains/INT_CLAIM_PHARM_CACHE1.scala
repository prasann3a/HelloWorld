package com.optum.cdr.fe.etl.commercial.cust_pay_aetna.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.int_claim_pharm
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_PHARM_CACHE1 extends FETableInfo[int_claim_pharm]
{
  override def name: String = "INT_CLAIM_PHARM_CACHE1"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val maskedIdInclusion = mpvList(mapPredicateValues, groupId, clientDsId,"MASKED_CLAIMS","INTERMEDIATE_CLAIMS","INTERMEDIATE_CLAIMS","CLIENT_DS_ID").mkString
    val maskedIdInclusionList = if (maskedIdInclusion.toString.equals("'Y'")) "' '" else "'00000000000000000000'"
    val exclsnCriteria = clientDsId.toString match {
      case "10910" => " and ad.org_cd is not null"
      case "10951" => " and ad.org_cd is not null"
      case _  => " "
    }

    sparkSession.sql(
      s"""
         |with ll as
         |(
         |select
         |   fileid, max(transact_date) as transact_date
         |from AETNDRUG
         |group by fileid
         |)
         |select groupid, datasrc, client_ds_id, claim_id, contract_id, days_supply, member_id, metric_quantity, ndc_name, ndc, quantity_per_fill, rx_id, service_date, copay_amount, deductible_amount, dispensing_fee, ingredient_cost_paid, payment_amount, sales_tax_amt, encounterid, generic_status, localdaw, pay_process_date, pharmacy_id, pharmacy_name, presc_prov_fname, presc_prov_name, presc_prov_id, presc_prov_npi
         |from
         |(
         |select
         |'{groupid}'                			as groupid
         |,'AETNDRUG'              			as datasrc
         |,{client_ds_id}             			as client_ds_id
         |,ad.rx_claim_id          			as claim_id
         |,ad.org_cd 					as contract_id
         |,safe_to_number(ad.days_supply_cnt)     	as days_supply
         |,ad.member_id            			as member_id
         |,safe_to_number(ad.unts_dispensed_qty)  	as metric_quantity
         |,ad.label_nm             			as ndc_name
         |,ad.ndc_cd               			as ndc
         |,safe_to_number(ad.unts_dispensed_qty)  	as quantity_per_fill
         |,ad.rx_claim_id          			as rx_id
         |,ad.disp_dt              			as service_date
         |,safe_to_number(ad.srv_copay_amt)  		as copay_amount
         |,safe_to_number(ad.app_to_per_ded_amt)		as deductible_amount
         |,safe_to_number(ad.prof_fee_amt)  		as dispensing_fee
         |,safe_to_number(ad.sub_ing_cost_amt)  		as ingredient_cost_paid
         |,safe_to_number(ad.paid_amt)            	as payment_amount
         |,safe_to_number(ad.sales_tax_amt)       	as sales_tax_amt
         |,ad.rx_claim_id 				as encounterid
         |,ad.generic_cd 					as generic_status
         |,case when daw_cd is not null
         | then concat_ws('', {client_ds_id}, '.', ad.daw_cd)
         | else null end 					as localdaw
         |,ad.process_dt           			as pay_process_date
         |,NULLIF(ad.nabp_nbr,'9')             		as pharmacy_id
         |,ad.nabp_provider_name 				as pharmacy_name
         |,case when lower(ad.prescribing_provider_name) = '\\\\n' then null else ad.prescribing_provider_name end
         | as presc_prov_fname
         |,case when lower(ad.prescribing_provider_name) = '\\\\n' then null else ad.prescribing_provider_name end
         | 	as presc_prov_name
         |,case when ad.prescriber_id in ('NA','U') then null else ad.prescriber_id end as presc_prov_id
         |,case when ad.prescriber_id in ('NA','U') then null else ad.prescriber_id end as presc_prov_npi
         |,row_number() over (partition by ad.rx_claim_id order by ll.transact_date desc nulls last ) as rw_id
         |from AETNDRUG ad
         |inner join LL on ll.fileid = ad.fileid
         |where ad.org_cd is not null
         |and ad.member_id <> {masked_id_inclusion}
         |)
         |where rw_id = 1
       """.stripMargin
        .replace("{client_ds_id}",clientDsId).replace("{groupid}",groupId).replace("{masked_id_inclusion}",maskedIdInclusionList)

    )
  }

  override def dependsOn: Set[String] = Set("AETNDRUG","MAP_PREDICATE_VALUES","ZO_BPO_MAP_EMPLOYER")

}

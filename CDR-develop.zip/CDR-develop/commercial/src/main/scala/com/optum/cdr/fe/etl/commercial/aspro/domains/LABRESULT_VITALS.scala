package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_VITALS extends FEQueryAndMetadata[labresult]{

  override def name: String = "LABRESULT_VITALS"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE_VITALS")

  override def sparkSql: String =
    """
      |select groupid, datasrc, labresultid, encounterid, patientid, datecollected, dateavailable, vital_pulse_ox as localresult
      |, pulse_ox_numeric as localresult_numeric, pulse_ox_numeric as localresult_inferred, 'vitals_pulse_ox' as localcode
      |, 'vitals_pulse_ox' as localname, dateavailable as labresult_date, client_ds_id
      |from
      |(
      |LABRESULT_CACHE_VITALS
      |)
      |where vital_pulse_ox is not null and pulse_ox_numeric is not null
    """.stripMargin
}

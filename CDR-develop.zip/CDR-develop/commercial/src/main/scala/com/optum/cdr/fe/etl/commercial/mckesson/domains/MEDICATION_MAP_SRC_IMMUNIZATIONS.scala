package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_IMMUNIZATIONS extends FETableInfo[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_IMMUNIZATIONS"

  override def dependsOn: Set[String] = Set("MCKESSON_HHS_CPI_IMMUNIZATION","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val excl_status = mpvList(mapPredicateValues, groupId, clientDsId, "HHS_CPI_IMMUNIZATION", "IMMUNIZATION", "HHS_CPI_IMMUNIZATION", "IMM_STATUS_LSEQ").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs
        from
        (
        SELECT '{groupid}' AS groupid
                ,'hhs_cpi_immunization' AS datasrc
            ,{client_ds_id} AS client_ds_id
                ,Vaccine_Code AS localmedcode
                ,NULL AS localndc
                ,vaccine_name AS localdescription
                ,COUNT(*) AS no_ndc
                ,0        AS has_ndc
                ,COUNT(*) AS num_recs
        FROM MCKESSON_HHS_CPI_IMMUNIZATION
        WHERE cpi_seq IS NOT NULL
        AND imm_status_lseq NOT IN ({excl_status})
        GROUP BY  vaccine_code, vaccine_name
        )
            """.replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId)
        .replace("{excl_status}", excl_status))
  }
}

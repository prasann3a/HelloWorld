package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object TEMP_DIAGNOSIS_PART3 extends FEQueryAndMetadata[diagnosis] {

  override def name: String = "TEMP_DIAGNOSIS_PART3"

  override def dependsOn: Set[String] = Set("ENCRDN", "ENCNTR")

  override def sparkSql: String =
    """
      |select distinct groupid, datasrc, client_ds_id, patientid, encounterid, dx_timestamp, null as localactiveind,
      |null as localdiagnosisstatus, null as localdiagnosisproviderid, localdiagnosis, primarydiagnosis,
      |null as resolutiondate, mappeddiagnosis, localadmitflg, localdischargeflg, hosp_dx_flag, codetype, facilityid
      |from
      |(
      |select * from (
      |SELECT '{groupid}' as groupid
      |  ,'mrcode' as datasrc
      |	,{client_ds_id} as client_ds_id
      |	,encrdn.Data_Create_Ts AS dx_timestamp
      |	,encrdn.Nomen_Id AS localdiagnosis
      |	,encntr.Pat_Person_Num AS patientid
      |	,case when encrdn.nomen_type_cde= 'ICD10' then 'ICD10' when encrdn.nomen_type_cde='ICD9' then 'ICD9' else null end AS codetype
      |	,encntr.Fac_Num AS facilityid
      |	,encrdn.Mrcode_Inpat_Flg AS hosp_dx_flag
      |	,case when encrdn.mrcode_inpat_flg='Y' and encrdn.mrcode_seq_num='0'then 'Y' else null end AS localadmitflg
      |	,case when encrdn.mrcode_inpat_flg='Y' and encrdn.mrcode_seq_num<>'0'then 'Y' else null end AS localdischargeflg
      |	,encntr.Num AS encounterid
      |	,encrdn.Nomen_Id AS mappeddiagnosis
      |	,case when safe_to_number(mrcode_seq_num)=1 then safe_to_number(mrcode_seq_num) else 0 end as primarydiagnosis
      |FROM ENCRDN encrdn
      |INNER JOIN ENCNTR encntr ON (encntr.prim_acct_num = encrdn.acount_num)
      |WHERE mrcode_type_cde = 'D'
      | AND encrdn.Data_Create_Ts is not null
      | AND encrdn.Nomen_Id is not null
      | AND encntr.Pat_Person_Num is not null
      |
      | ) mrcode
      | WHERE mrcode.codetype is not null
      |
      |)
    """.stripMargin

}

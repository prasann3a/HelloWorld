package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object FACILITY extends FEQueryAndMetadata[zh_facility]{

  override def name: String = CDRFEParquetNames.zh_facility

  override def dependsOn: Set[String] = Set("ZH_FACILITY_ATTRIBUTES_TB")

  override def sparkSql: String =

  """
    |select groupid, facilityid, facilityname, facilitypostalcd, client_ds_id
    |from
    |(
    |select *
    |  from (SELECT '{groupid}' as groupid,'zh_facility_attributes_tb' as datasrc
    |               ,{client_ds_id} as client_ds_id
    |               ,ZFA.Facility_Num AS facilityid
    |               ,ZFA.Facility_Name AS facilityname
    |               ,ZFA.Postal_Code AS facilitypostalcd
    |               ,row_number() over (partition by Facility_Num
    |                                       order by Last_Modified_Date desc nulls first, length(Facility_Name) desc nulls first) as rnbr
    |          FROM ZH_FACILITY_ATTRIBUTES_TB ZFA
    |         WHERE ZFA.Facility_Num is not null
    |           AND ZFA.Facility_Name is not null
    |               )
    | where rnbr=1
    |)
  """
  .stripMargin

}

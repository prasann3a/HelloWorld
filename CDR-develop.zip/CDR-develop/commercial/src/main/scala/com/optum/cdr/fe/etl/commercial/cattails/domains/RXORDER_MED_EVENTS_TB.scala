package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXORDER_MED_EVENTS_TB extends FETableInfo[rxorder]{

  override def name: String = "RXORDER_MED_EVENTS_TB"

  override def dependsOn: Set[String] = Set("MED_EVENTS_TB", "MED_DISP_DRUG_DTLS_TB", "MED_PAT_SCRIPT_DISP_DTLS_TB", "MED_DRUGS_TB", "MED_ATTRIBUTES_TB", "MED_PATIENT_SCRIPTS_TB", "MED_PAT_SCRIPT_DISP_DTLS_TB", "MAP_PREDICATE_VALUES", "MED_EVENT_ITEMS_TB", "PATIENT_FAC_GRP_SEG_TB", "MED_PAT_SCRIPT_DTLS_TB")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val rxOrderAttrStrUnit = mpvList(mapPredicateValues, groupId, clientDsId.toString,"LOCALSTRENGTHUNIT","RXORDER","MED_ATTRIBUTES_TB","ATTRIBUTE_DESC").mkString(",")
    val rxOrderAttrDoseUnit = mpvList(mapPredicateValues, groupId, clientDsId.toString,"LOCALSTRENGTHPERDOSEUNIT","RXORDER","MED_ATTRIBUTES_TB","ATTRIBUTE_DESC").mkString(",")
    val rxOrderAttrRoute = mpvList(mapPredicateValues, groupId, clientDsId.toString,"LOCALROUTE","RXORDER","MED_ATTRIBUTES_TB","ATTRIBUTE_DESC").mkString(",")

    sparkSession.sql(
      """
        |WITH
        |MEI_DEDUPE AS
        |(SELECT t.*
        | FROM (SELECT EVENT_ID,EVENT_ITEM_ID,MED_ITEM_ID,EVENT_DATE_TIME,ACTV_STAT_PATIENT_SCRIPT_ID
        |             ,row_number () over ( Partition by EVENT_ID,EVENT_ITEM_ID,MED_ITEM_ID order by  LAST_MODIFIED_DATE desc nulls first ) as rownumber
        |       FROM MED_EVENT_ITEMS_TB  ) t
        | WHERE t.rownumber = 1
        |),
        |PFG_DEDUPE AS
        |(SELECT t.*
        | FROM (SELECT PATIENT_ID
        |             ,row_number () over ( Partition by PATIENT_ID order by  LAST_MODIFIED_DATE desc nulls first ) as rownumber
        |       FROM PATIENT_FAC_GRP_SEG_TB  ) t
        | WHERE t.rownumber = 1
        |),
        |MPSD_DEDUPE AS
        |(SELECT t.*
        | FROM (SELECT PATIENT_SCRIPT_ID,MED_ATTRIBUTE_ID
        |            ,row_number () over ( Partition by PATIENT_SCRIPT_ID,MED_ATTRIBUTE_ID order by  FIleID desc nulls first ) as rownumber
        |       FROM MED_PAT_SCRIPT_DTLS_TB  ) t
        | WHERE t.rownumber = 1
        |),
        |MPSDD_DEDUPE AS
        |(SELECT t.*
        | FROM (SELECT PATIENT_SCRIPT_ID
        |             ,row_number () over ( Partition by PATIENT_SCRIPT_ID order by  FIleID desc nulls first ) as rownumber
        |       FROM MED_PAT_SCRIPT_DISP_DTLS_TB  ) t
        | WHERE t.rownumber = 1
        |),
        |MPS_DEDUPE AS
        |(SELECT t.*
        | FROM (SELECT PATIENT_SCRIPT_ID,MED_DRUG_ID,EXPIRATION_DATE
        |             ,row_number () over ( Partition by PATIENT_SCRIPT_ID order by  FILEID desc nulls first ) as rownumber
        |       FROM MED_PATIENT_SCRIPTS_TB  ) t
        | WHERE t.rownumber = 1
        |),
        |MAT_DEDUPE AS
        |(
        | SELECT t.*
        | FROM (SELECT ATTRIBUTE_TYPE_ID,ATTRIBUTE_TYPE_DESC,MED_ATTRIBUTE_ID,ATTRIBUTE_DESC,STRENGTH_NUMERIC_VALUE
        |             ,row_number () over ( Partition by MED_ATTRIBUTE_ID order by  FILEID desc nulls first ) as rownumber
        |       FROM MED_ATTRIBUTES_TB  ) t
        | WHERE t.rownumber = 1
        |),
        |MDT_DEDUPE AS
        |(SELECT t.*
        | FROM (SELECT Med_Drug_Id,Drug_Name,Generic_Name
        |             ,row_number () over ( Partition by Med_Drug_Id order by  FIleID desc nulls first ) as rownumber
        |       FROM MED_DRUGS_TB  ) t
        | WHERE t.rownumber = 1
        |),
        |uni_disp_dtls AS
        |(SELECT t.*
        | FROM (SELECT patient_script_id, dispensable_drug_id
        |             ,row_number() over ( Partition by PATIENT_SCRIPT_ID order by FIleID desc nulls first ) as rownumber
        |       FROM MED_PAT_SCRIPT_DISP_DTLS_TB  ) t
        | WHERE t.rownumber = 1
        |),
        |uni_drug_dtls AS
        |(SELECT t.*
        | FROM (SELECT dispensable_drug_id, Drug_Form_Desc, Strength_Unit_Desc, Strength_Value
        |            ,row_number() over (Partition by DISPENSABLE_DRUG_ID order by LAST_MODIFIED_DATE DESC NULLS LAST) as rownumber
        |       FROM MED_DISP_DRUG_DTLS_TB  ) t
        | WHERE t.rownumber = 1
        |)
        |select groupid, datasrc, client_ds_id, issuedate, ordervsprescription, patientid, rxid, localdaysupplied, encounterid, expiredate, facilityid, localdosefreq, localdoseunit, localdescription, localduration, localgenericdesc, localmedcode, localproviderid, localqtyofdoseunit, localroute, localstrengthperdoseunit, localstrengthunit, localtotaldose, fillnum, venue, ordertype, localform
        |from
        |(
        |SELECT
        |       groupid, client_ds_id, datasrc, ordervsprescription, issuedate, patientid, encounterid, rxid,
        |       localgenericdesc, localmedcode, localproviderid, facilityid, localdescription, venue, ordertype, localform,
        |       max(localdaysupplied) as localdaysupplied, max(expiredate) as expiredate, max(localdosefreq) as localdosefreq,
        |       max(localdoseunit) as localdoseunit, max(localduration) as localduration, max(localqtyofdoseunit) as localqtyofdoseunit,
        |       max(localroute) as localroute, max(localstrengthperdoseunit) as localstrengthperdoseunit,
        |       max(localstrengthunit) as localstrengthunit, max(localtotaldose) as localtotaldose, max(fillnum) as fillnum
        |FROM (
        |SELECT
        |  '{groupid}' as groupid,
        |  'med_events_tb' as datasrc
        |  ,{client_ds_id} as client_ds_id
        |  ,'P' AS ordervsprescription
        |  ,MEI.Event_Date_Time AS issuedate
        |  ,MET.Patient_Id AS patientid
        |  ,MET.Event_Id AS encounterid
        |  ,concat_ws('', MPS.Patient_Script_Id, '_', upper(date_format(MET.EVENT_DATE_TIME, 'dd-MMM-yy'))) AS rxid
        |  ,MDT.Generic_Name AS localgenericdesc
        |  ,MDT.Med_Drug_Id AS localmedcode
        |  ,MET.Provider_Id AS localproviderid
        |  ,MET.Facility_Num AS facilityid
        |  ,MDT.Drug_Name AS localdescription
        |  ,case when MAT.ATTRIBUTE_TYPE_ID = 7 then MAT.STRENGTH_NUMERIC_VALUE else null end AS localdaysupplied
        |  ,case when date_format(MPS.EXPIRATION_DATE,'yyyy-MM-dd') <> '1800-01-01' then MPS.EXPIRATION_DATE else null end AS expiredate
        |  ,case when MAT.ATTRIBUTE_TYPE_ID = 2 then MAT.ATTRIBUTE_DESC else null end AS localdosefreq
        |  ,case when MAT.ATTRIBUTE_TYPE_ID = 13 then MAT.ATTRIBUTE_DESC else null end AS localdoseunit
        |  ,case when MAT.ATTRIBUTE_TYPE_ID =3 then MAT.ATTRIBUTE_DESC else null end AS localduration
        |  ,case when MAT.ATTRIBUTE_TYPE_ID = 13 then MAT.ATTRIBUTE_DESC else null end AS localqtyofdoseunit
        |  ,case when MAT.ATTRIBUTE_TYPE_ID IN ({rx_order_attr_route})  then MAT.ATTRIBUTE_DESC else null end AS localroute
        |  ,case when MAT.ATTRIBUTE_TYPE_ID IN ({rx_order_attr_dose_unit}) then NVL(uni_drug_dtls.Strength_Value, MAT.STRENGTH_NUMERIC_VALUE) else null end AS localstrengthperdoseunit
        |  ,case when MAT.ATTRIBUTE_TYPE_ID IN ({rx_order_attr_str_unit}) then NVL(uni_drug_dtls.STRENGTH_UNIT_DESC, nullif(regexp_replace_5param(MAT.ATTRIBUTE_DESC,'[\\.0-9,\\-]+','',1,1), ''))
        |           else null end AS localstrengthunit
        |  ,case when MAT.ATTRIBUTE_TYPE_ID = 11 then MAT.STRENGTH_NUMERIC_VALUE else null end AS localtotaldose
        |  ,case when MAT.ATTRIBUTE_TYPE_ID = 5 then MAT.ATTRIBUTE_DESC else null end AS fillnum
        |  , '1' as venue
        |  , 'CH002047' as ordertype
        |  ,uni_drug_dtls.Drug_Form_Desc AS localform
        |FROM MED_EVENTS_TB MET
        |INNER JOIN MEI_DEDUPE MEI ON (MEI.EVENT_ID = MET.EVENT_ID)
        |INNER JOIN PFG_DEDUPE PFG ON (PFG.Patient_ID = MET.Patient_Id)
        |INNER JOIN MPS_DEDUPE MPS ON (MEI.ACTV_STAT_PATIENT_SCRIPT_ID = MPS.PATIENT_SCRIPT_ID)
        |INNER JOIN MPSD_DEDUPE MPSD ON (MPS.PATIENT_SCRIPT_ID = MPSD.PATIENT_SCRIPT_ID)
        |INNER JOIN MPSDD_DEDUPE MPSDD ON (MPS.PATIENT_SCRIPT_ID = MPSDD.PATIENT_SCRIPT_ID)
        |INNER JOIN MAT_DEDUPE MAT ON (MPSD.MED_ATTRIBUTE_ID = MAT.MED_ATTRIBUTE_ID )
        |INNER JOIN MDT_DEDUPE MDT ON (MPS.MED_DRUG_ID = MDT.MED_DRUG_ID)
        |INNER JOIN UNI_DISP_DTLS ON mps.patient_script_id = uni_disp_dtls.patient_script_id
        |INNER JOIN UNI_DRUG_DTLS ON uni_disp_dtls.dispensable_drug_id = uni_drug_dtls.dispensable_drug_id
        |WHERE MEI.Event_Date_Time is not null
        | AND MET.Patient_Id is not null
        | AND MPS.Patient_Script_Id is not null
        |
        |)
        |GROUP BY groupid, client_ds_id, datasrc, ordervsprescription, issuedate, patientid, encounterid, rxid,
        |         localgenericdesc, localmedcode, localproviderid, facilityid, localdescription, venue, ordertype, localform
        |)
        |
      """.stripMargin
        .replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId.toString )
        .replace("{rx_order_attr_str_unit}", rxOrderAttrStrUnit )
        .replace("{rx_order_attr_dose_unit}", rxOrderAttrDoseUnit )
        .replace("{rx_order_attr_route}", rxOrderAttrRoute )
    )
  }

}

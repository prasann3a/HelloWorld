package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_RXORDER_CCDBA_O_PAT extends FETableInfo[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_RXORDER_CCDBA_O_PAT"

  override def dependsOn: Set[String] = Set("CCDBA_O_PAT","ZH_CCDEV_O_ITEM","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val ogrp_id = mpvList(mapPredicateValues, groupId, clientDsId, "CCDBA_O_PAT", "MEDS", "CCDBA_O_PAT", "OGROUP_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """WITH uni_opat AS
        (SELECT * FROM (
            SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY order_ddt DESC NULLS LAST) rn
            FROM CCDBA_O_PAT i
            WHERE Order_Seq IS NOT NULL)
        WHERE rn = 1)
        select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs
        from
        (
        SELECT '{groupid}' AS groupid
                ,'ccdba_o_pat' AS datasrc
            ,{client_ds_id} AS client_ds_id
                ,COUNT(*) AS no_ndc
                ,0 AS has_ndc
                ,COUNT(*) AS num_recs
                ,localmedcode, localndc, localdescription
        FROM (SELECT uni_opat.Order_Item_Seq AS localmedcode
                ,NULL AS localndc
                ,LOWER(zh.Order_Name) AS localdescription
            FROM UNI_OPAT
            JOIN ZH_CCDEV_O_ITEM zh ON (uni_opat.order_item_seq = zh.order_item_seq)
            WHERE zh.ogroup_id IN ({ogrp_id}))
        GROUP BY  localmedcode, localndc, localdescription
        )
        """.replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId)
        .replace("{ogrp_id}", ogrp_id))
  }
}

package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.patientdetail
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT_DETAIL extends FEQueryAndMetadata[patientdetail]{

  override def name: String = CDRFEParquetNames.patientdetail

  override def dependsOn: Set[String] = Set("TEMP_PATIENT_CACHE")

  override def sparkSql: String =
    """
     select  datasrc, patientid, nvl(lastupdateddate,current_date) as patdetail_timestamp, 'FIRST_NAME' as patientdetailtype, firstname as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where firstname_row = 1  and firstname is not null and patientid is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as patdetail_timestamp, 'LAST_NAME' as patientdetailtype, lastname as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where lastname_row = 1  and lastname is not null and patientid is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as patdetail_timestamp, 'MIDDLE_NAME' as patientdetailtype, middlename as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where middle_row = 1  and middlename is not null and patientid is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as patdetail_timestamp, 'GENDER' as patientdetailtype, gender as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where gender_row = 1  and gender is not null and patientid is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as patdetail_timestamp, 'LANGUAGE' as patientdetailtype, language as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where language_row = 1 and language is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as PATDETAIL_TIMESTAMP, 'ETHNICITY' as patientdetailtype, ethnicity as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where ethnic_row = 1 and ethnicity is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as PATDETAIL_TIMESTAMP, 'RACE' as patientdetailtype, race as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where race_row = 1 and race is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as PATDETAIL_TIMESTAMP, 'MARITAL' as patientdetailtype, maritalstatus as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where marital_row = 1 and maritalstatus is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as patdetail_timestamp, 'CITY' as patientdetailtype, city as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where city_row = 1  and city is not null and patientid is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as patdetail_timestamp, 'STATE' as patientdetailtype, state as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where state_row = 1  and state is not null and patientid is not null
 |
 |union all
 |
 |select  datasrc, patientid, nvl(lastupdateddate,current_date) as patdetail_timestamp, 'ZIPCODE' as patientdetailtype, zipcode as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where zipcode_row = 1  and zipcode is not null and patientid is not null
 |
 |union all
 |
 |select  datasrc,  patientid, lastupdateddate as patdetail_timestamp, 'DECEASED' as patientdetailtype, deathindicator as localvalue
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where deathindicator_row = 1  and deathindicator is not null and patientid is not null
    """.stripMargin
}

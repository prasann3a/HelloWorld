package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.etl.commercial.mckesson_labresult_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE_2 extends FEQueryAndMetadata[mckesson_labresult_cache]{
  override def name: String = "LABRESULT_CACHE_2"

  override def dependsOn: Set[String] = Set("MCKESSON_CCDBA_PAT_RESULTS","MCKESSON_ENT_PATIENT","MCKESSON_ZH_CCDEV_PCQ_LABEL","ZCM_OBSTYPE_CODE")

  override def sparkSql: String =
    """
      |WITH uni_pat AS
      |(SELECT * FROM
      |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY result_seq ORDER BY perform_ddt DESC NULLS LAST) rn
      | FROM MCKESSON_CCDBA_PAT_RESULTS p
      | WHERE Result_Seq IS NOT NULL
      |   AND Perform_Ddt IS NOT NULL )
      | WHERE rn = 1)
      |SELECT '{groupid}' AS groupid
      |,'ccdba_pat_results' AS datasrc
      |,{client_ds_id} AS client_ds_id
      |,uni_pat.Result_Seq AS labresultid
      |,uni_pat.Label_Seq  AS localcode
      |,uni_pat.Result_Number_1 AS localresult
      |,safe_to_number(uni_pat.Result_Number_1) as localresult_numeric
      |,ent.Cpi_Seq         AS patientid
      |,uni_pat.Perform_Ddt AS datecollected
      |,NULL		     AS labordereddate
      |,uni_pat.Perform_Ddt AS dateavailable
      |,uni_pat.pat_seq     AS encounterid
      |,NULL 		     AS facilityid
      |,NULL		     AS laborderid
      |,zh.Label_Name       AS localname
      |,zh.label_name       AS localtestname
      |,uni_pat.units       AS localunits
      |,NULL		     AS normalrange
      |,NULL		     AS resulttype
      |,NULL  		     AS statuscode
      |,uni_pat.Perform_Ddt  AS labresult_date
      |,ROW_NUMBER() OVER (PARTITION BY uni_pat.Result_Seq
      |                    ORDER BY uni_pat.perform_ddt DESC NULLS LAST) res_row
      |FROM UNI_PAT
      |    JOIN MCKESSON_ENT_PATIENT ent ON (uni_pat.pat_seq = ent.pat_seq)
      |    JOIN MCKESSON_ZH_CCDEV_PCQ_LABEL zh ON (uni_pat.label_seq = zh.label_seq)
      |    JOIN ZCM_OBSTYPE_CODE zcm ON (zcm.groupid = '{groupid}' AND
      |    				  zcm.datasrc = 'ccdba_pat_results' AND
      |    				  zcm.obstype = 'LABRESULT'  AND
      |                                  zcm.obscode = uni_pat.label_seq)
      |WHERE ent.Cpi_Seq IS NOT NULL
    """.stripMargin


}

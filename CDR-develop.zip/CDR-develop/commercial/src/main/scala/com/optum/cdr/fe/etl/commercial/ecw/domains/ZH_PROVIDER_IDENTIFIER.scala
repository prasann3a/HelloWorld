package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.zh_provider_identifier
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_PROVIDER_IDENTIFIER extends FEQueryAndMetadata[zh_provider_identifier]{

  override def name: String = CDRFEParquetNames.zh_provider_identifier

  override def dependsOn: Set[String] = Set("DOCTORS")

  override def sparkSql: String =
    """
      |WITH uni_prov AS (
      |SELECT  *
      |FROM
      |(
      |	SELECT  d.*
      |	       ,CASE WHEN d.npi IN ('9999999999','0000000000','1111111111','1234567890','0123456789') THEN null ELSE d.Npi END AS npi_std
      |	       ,ROW_NUMBER() OVER (PARTITION BY doctorid ORDER BY modifieddate DESC NULLS LAST) rn
      |	FROM DOCTORS d
      |	WHERE COALESCE(deano, npi) IS NOT NULL
      |)
      |WHERE rn = 1)
      |
      |SELECT  groupid
      |       ,client_ds_id
      |       ,id_type
      |       ,id_value
      |       ,provider_id
      |FROM
      |(
      |	SELECT  '{groupid}'    AS groupid
      |	       ,{client_ds_id} AS client_ds_id
      |	       ,id_type
      |	       ,id_value
      |	       ,Doctorid       AS provider_id
      |	FROM
      |	(
      |		SELECT  *
      |		FROM
      |		(
      |			SELECT  *
      |			FROM
      |			(
      |				SELECT  unpivot_base.*
      |				       ,stack(2,deano,'DEA',npi_std,'NPI') AS (id_value,id_type)
      |				FROM UNI_PROV unpivot_base
      |			)
      |			WHERE id_value is not null
      |		)
      |	)
      |)
    """.stripMargin
}

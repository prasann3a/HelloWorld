package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.patientaddr
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTADDR extends FEQueryAndMetadata[patientaddr]{

  override def name: String = CDRFEParquetNames.patientaddr

  override def dependsOn: Set[String] = Set("PATIENT_HISTORIES_TB", "PATIENT_FAC_GRP_SEG_TB")

  override def sparkSql: String =

  """
    |with dedupe as (
    |SELECT  *
    |from (
    |SELECT Case when date_format(PHT.From_Date, 'yyyyMMdd') = '18000101'
    |            then null else PHT.From_Date end as from_date
    |       ,Case when date_format(PHT.Thru_Date, 'yyyyMMdd') = '44441231'
    |             then PHT.Last_Modified_Date
    |             else PHT.Thru_Date end as Thru_Date
    |       ,PHT.Last_Modified_Date
    |       ,pht.fileid
    |       ,PHT.Patient_Id AS patientid
    |       ,coalesce(pht.current_state,pht.state) AS state
    |       ,coalesce(pht.current_zip_5,pht.zip_5) AS zipcode
    |       ,coalesce(pht.current_street_1,pht.street_1) AS address_line1
    |       ,coalesce(pht.current_street_2,pht.street_2) AS address_line2
    |       ,coalesce(pht.current_city,pht.city) AS city
    |       ,row_number() over (partition by PHT.Patient_Id
    |                                        ,coalesce(pht.current_state,pht.state)
    |                                        ,coalesce(pht.current_zip_5,pht.zip_5)
    |                                        ,coalesce(pht.current_street_1,pht.street_1)
    |                                        ,coalesce(pht.current_street_2,pht.street_2)
    |                                        ,coalesce(pht.current_city,pht.city)
    |                               order by pht.FileID desc nulls first) as rownumber
    |      FROM PATIENT_HISTORIES_TB PHT
    |      INNER JOIN PATIENT_FAC_GRP_SEG_TB PFG ON (pfg.PATIENT_ID = pht.PATIENT_ID)
    |        WHERE (length(coalesce(pht.current_zip_5,pht.zip_5)) = 5 or coalesce(pht.current_zip_5,pht.zip_5) is null)
    |          AND (length(coalesce(pht.current_state,pht.state)) = 2 or coalesce(pht.current_state,pht.state) is null)
    |          AND coalesce(coalesce(pht.current_state,pht.state)
    |                       ,coalesce(pht.current_zip_5,pht.zip_5)
    |                       ,coalesce(pht.current_street_1,pht.street_1)
    |                       ,coalesce(pht.current_street_2,pht.street_2)
    |                       ,coalesce(pht.current_city,pht.city) ) is not null
    |           AND PHT.Patient_Id is not null
    |            )
    |where rownumber = 1)
    |select groupid, client_ds_id, datasrc, patientid, address_date, address_line1, address_line2, city, state, zipcode
    |from
    |(
    |select *
    |from (
    |select   '{groupid}' as groupid, 'patient_histories_tb' as datasrc
    |      ,{client_ds_id} as client_ds_id
    |      ,address_date
    |      ,patientid
    |      ,address_line1
    |      ,address_line2
    |      ,city
    |      ,state
    |      ,zipcode
    |      ,row_number() over (partition by patientid,address_line1,address_line2,city,state,zipcode
    |                              order by address_date desc nulls first) as rnbr
    |from
    |(
    |select * from
    |(
    |select pht.*,
    |stack(3,from_date,'FROM_DATE',Thru_Date,'THRU_DATE',Last_Modified_Date,'LAST_MODIFIED_DATE') as (address_date, source)
    |from
    |DEDUPE pht
    |)
    |where address_date is not null
    |) )
    |where rnbr =1
    |)
  """
  .stripMargin

}

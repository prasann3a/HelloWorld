package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.oap.cdr.models.zh_prov_attribute
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_PROV_ATTRIBUTE extends FEQueryAndMetadata[zh_prov_attribute] {

  override def name: String = CDRFEParquetNames.zh_prov_attribute

  override def dependsOn: Set[String] = Set("PROVIDER")

  override def sparkSql: String =
    """
      |
      |select groupid, client_ds_id, localproviderid, attribute_type_cui, attribute_value
      |from
      |(
      |select a.*
      |      ,row_number () over (partition by  localproviderid, attribute_type_cui order by prov_eff_end_dt desc nulls last,prov_eff_strt_dt desc nulls last ,attribute_value ) as provider_rank
      |  from (
      |select '{groupid}' 	    as groupid
      |       ,{client_ds_id} 	as client_ds_id
      |       ,Uniq_Prov_Id    as localproviderid
      |       ,prov_eff_strt_dt
      |       ,prov_eff_end_dt
      |	   ,attribute_type_cui
      |	   ,nullif(replace(attribute_value,'NA',''), '')  as attribute_value
      |  from
      |(
      |select * from
      |(
      |select unpivot_base.*,
      |stack(4,Bus_Seg,'CH002486',Prov_Rgn,'CH002487',Mkt_Desg,'CH002488',Prov_Affil_Id,'CH002489') as (attribute_value, attribute_type_cui)
      |from
      |PROVIDER unpivot_base
      |)
      |where attribute_value is not null
      |)) a
      | where attribute_value is not null
      |
      |)
      |where localproviderid is not null and provider_rank = 1
      |
    """.stripMargin

}

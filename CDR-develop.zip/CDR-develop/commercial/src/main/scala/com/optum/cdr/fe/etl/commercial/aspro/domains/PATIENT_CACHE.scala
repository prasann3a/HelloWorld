package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.aspro_patient_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PATIENT_CACHE extends FEQueryAndMetadata[aspro_patient_cache]{

  override def name: String = "PATIENT_CACHE"

  override def dependsOn: Set[String] = Set("ASPRO_PATIENT", "ADDRESS")

  override def sparkSql: String =
    """
      |SELECT  p.imredem_code                                                                                                                      AS patientid
      |       ,p.dem_externalid                                                                                                                    AS mrn
      |       ,p.dem_firstname                                                                                                                     AS firstname
      |       ,p.dem_lastname                                                                                                                      AS lastname
      |       ,a.addr_city                                                                                                                         AS city
      |       ,a.addr_state                                                                                                                        AS state
      |       ,p.dem_sex                                                                                                                           AS gender
      |       ,p.dem_race_code                                                                                                                     AS race
      |       ,p.dem_ethnicity_code                                                                                                                AS ethnicity
      |       ,p.dem_ssnum                                                                                                                         AS ssn
      |       ,p.tag_systemdate                                                                                                                    AS updatedate
      |       ,a.addr_zip                                                                                                                          AS std_zip
      |       ,null                                                                                                                                AS facilityid
      |       ,null                                                                                                                                AS encounterid
      |       ,concat_ws('','asp.',p.dem_deceased)                                                                                                 AS pat_status
      |       ,p.Dem_Language                                                                                                                      AS language
      |       ,p.Dem_Maritalstatus                                                                                                                 AS marital
      |       ,first_value(dem_dateofbirth) over (partition by p.imredem_code ORDER BY nvl2(dem_dateofbirth,1,0),p.tag_systemdate desc nulls last) AS dob
      |       ,first_value(dem_dateofdeath) over (partition by p.imredem_code ORDER BY nvl2(dem_dateofdeath,1,0),p.tag_systemdate desc nulls last) AS dod
      |       ,row_number() over (partition by p.imredem_code,upper(p.dem_lastname) ORDER BY p.tag_systemdate desc nulls last )                    AS last_row
      |       ,row_number() over (partition by p.imredem_code,upper(p.dem_firstname) ORDER BY p.tag_systemdate desc nulls last )                   AS first_row
      |       ,row_number() over (partition by p.imredem_code,upper(a.addr_city) ORDER BY p.tag_systemdate desc nulls last )                       AS city_row
      |       ,row_number() over (partition by p.imredem_code,upper(a.addr_state) ORDER BY p.tag_systemdate desc nulls last )                      AS state_row
      |       ,row_number() over (partition by p.imredem_code,a.addr_zip ORDER BY p.tag_systemdate desc nulls last )                               AS zip_row
      |       ,row_number() over (partition by p.imredem_code,p.dem_sex ORDER BY p.tag_systemdate desc nulls last )                                AS gender_row
      |       ,row_number() over (partition by p.imredem_code,p.dem_race_code ORDER BY p.tag_systemdate desc nulls last )                          AS race_row
      |       ,row_number() over (partition by p.imredem_code,p.dem_ethnicity_code ORDER BY p.tag_systemdate desc nulls last )                     AS ethnic_row
      |       ,row_number() over (partition by p.imredem_code,p.dem_deceased ORDER BY p.tag_systemdate desc nulls last )                           AS status_row
      |       ,row_number() over (partition by p.imredem_code,p.dem_ssnum ORDER BY p.tag_systemdate desc nulls last )                              AS ssn_row
      |       ,ROW_NUMBER() OVER (PARTITION BY p.imredem_code,upper(p.Dem_Language) ORDER BY p.tag_systemdate DESC NULLS LAST)                     AS language_row
      |       ,ROW_NUMBER() OVER (PARTITION BY p.imredem_code,upper(p.Dem_Maritalstatus) ORDER BY p.tag_systemdate DESC NULLS LAST)                AS marital_row
      |       ,row_number() over (partition by p.imredem_code ORDER BY p.tag_systemdate desc nulls last)                                           AS rownumber
      |FROM ASPRO_PATIENT p
      |LEFT OUTER JOIN ADDRESS a
      |ON (p.dem_homeaddr = a.imreaddr_code)
      |WHERE p.dem_patienttype<>2
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_pharm
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_PHARM extends FETableInfo[int_claim_pharm] {

  override def name: String = CDRFEParquetNames.int_claim_pharm

  override def dependsOn: Set[String] = Set("RXCLAIM")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId

    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val (prov_h969333_presc_npi_incl,prov_presc_npi) = groupId match {
      case "H969333" => ("""left join ref_cmsnpi Cms on (Cms.NPI =rx.Prov_Npi and Cms.entity_type_code = '1')""","""Cms.NPI""")
      case  _        => ("""-----""", """rx.Prov_Npi""")
    }


    sparkSession.sql(
      """
        |
        |select groupid, client_ds_id, datasrc, allowed_amount, claim_adj_type, claim_id, claim_id as encounterid, coinsurance_amount, copay_amount, days_supply, requested_amount, deductible_amount, denied_flag, denied_reason, dispensing_fee, formulary_indicator, generic_status, ingredient_cost_paid, member_id, metric_quantity, ndc_name, ndc, network_status_flag, patient_liability_amount, payment_amount, pay_process_date, quantityperfill as quantity_per_fill, pharmacy_id, pharmacy_name, pharmacy_type_code, presc_prov_id, presc_prov_npi, pseudo_flag, claim_id as rx_id, service_date, source_code
        |from
        |(
        |select groupid,
        |		client_ds_id,
        |		datasrc,
        |		claim_adj_type,
        |		claim_id,
        |		denied_flag,
        |		denied_reason,
        |		formulary_indicator,
        |		generic_status,
        |		Uniq_Mbr_Id  as member_id,
        |		metric_quantity ,
        |		ndc_name,
        |		ndc,
        |		network_status_flag,
        |		pharmacy_id,
        |		pharmacy_name,
        |		pharmacy_type_code,
        |		max(Uniq_Prov_Id) over(partition by claim_id) as	presc_prov_id,
        |		presc_prov_npi,
        |		pseudo_flag,
        |		service_date,
        |		source_code,
        |		safe_to_number(quantity_per_fill)  as quantityperfill,
        |		allowedamount  		as allowed_amount,
        |		coinsuranceamount  	as coinsurance_amount,
        |		copayamount  		as copay_amount,
        |		dayssupply  		as days_supply,
        |	    deductibleamount  	as deductible_amount,
        |		dispensingfee  		as dispensing_fee,
        |		ingredientcostpaid  as ingredient_cost_paid,
        |		patientliabilityamount as patient_liability_amount,
        |		paymentamount 	 	as payment_amount,
        |		requestedamt 		as requested_amount,
        |		max(payprocessdate) over(partition by claim_id) as pay_process_date
        |  from (
        |select
        |       distinct '{groupid}' 					as 	groupid,
        |       {client_ds_id} 					as 	client_ds_id,
        |	   'rxclaim' 		    				as 	datasrc,
        |	   Allw_Amt 			as 	allowedamount,
        |       Clm_Adj_Typ 							as 	claim_adj_type,
        |       case when '{groupid}' = 'H969892' then
        |	        concat_ws('', uniq_mbr_id, '_', uniq_prov_id, '_', rx_nbr, '_', upper(date_format(dt_of_srvc, 'dd-MMM-yy')))
        |	   else concat_ws('', Uniq_Mbr_Id, '_', upper(date_format(Dt_Of_Srvc, 'dd-MMM-yy')), '_', Ndc)	end as claim_id,
        |       Coins_Amt 			as 	coinsuranceamount,
        |       Copay_Amt 			as 	copayamount,
        |       Day_Spl				as 	dayssupply,
        |       Ded_Amt 				as 	deductibleamount,
        |       Deny_Flg 							as 	denied_flag,
        |       Deny_Rsn_Cd 							as 	denied_reason,
        |       Dspns_Fee  			as 	dispensingfee,
        |       Frmlry_Ind							as 	formulary_indicator,
        |       Gnrc_Sts 							as 	generic_status,
        |       Ingr_Cst_Pd 		as 	ingredientcostpaid,
        |       Uniq_Mbr_Id,
        |       Mtrc_Qty 							as 	metric_quantity ,
        |	   Qty									as  quantity_per_fill,
        |       case when Drg_Lbl_Nm in ('NA','?') then null else Drg_Lbl_Nm end	as 	ndc_name,
        |       case when length(ndc) <11 then null else ndc end 				as 	ndc,
        |       Ntwk_Sts_Flg 						as 	network_status_flag,
        |       Ptnt_Liab_Amt  		as 	patientliabilityamount,
        |       Pay_Amt			as 	paymentamount,
        |       case when date_trunc('DAY', Pay_Proc_Dt) in (to_date('9999-12-31','yyyy-MM-dd'),to_date('9000-12-31','yyyy-MM-dd')) then null
        |            when (date_trunc('DAY', Pay_Proc_Dt) <= to_date('1900-01-01','yyyy-MM-dd') or Pay_Proc_Dt > current_date) then null
        |       else Pay_Proc_Dt end         		as 	payprocessdate ,
        |       Phrm_Id 								as 	pharmacy_id,
        |       Phrm_Nm 								as 	pharmacy_name,
        |       Phrm_Typ_Cd 							as 	pharmacy_type_code,
        |	Uniq_Prov_Id,
        |      {prov_presc_npi}                                     	as 	presc_prov_npi,
        |       Pseudo_Clm_Flg 						as 	pseudo_flag,
        |	   Req_Amt              as  requestedamt,
        |       case when date_trunc('DAY', Dt_Of_Srvc) in (to_date('9999-12-31','yyyy-MM-dd'),to_date('9000-12-31','yyyy-MM-dd')) then null
        |            when (date_trunc('DAY', Dt_Of_Srvc) <= to_date('1900-01-01','yyyy-MM-dd') or Dt_Of_Srvc > current_date) then null
        |       else Dt_Of_Srvc end 					as 	service_date,
        |       Enty_Nm 								as  source_code
        |  from RXCLAIM rx
        |  {prov_h969333_presc_npi_incl}
        |
        |)
        |)
        |where claim_id is not null
        |
    """.stripMargin
        .replace("{groupid}", groupId.toString)
        .replace("{client_ds_id}", clientDsId.toString)
        .replace("{prov_h969333_presc_npi_incl}", prov_h969333_presc_npi_incl)
        .replace("{prov_presc_npi}", prov_presc_npi)
    )

  }
}

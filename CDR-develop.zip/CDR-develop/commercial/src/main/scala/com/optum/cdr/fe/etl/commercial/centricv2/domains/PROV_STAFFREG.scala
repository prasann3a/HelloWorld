package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROV_STAFFREG extends FETableInfo[zh_provider] {

  override def name: String = "PROV_STAFFREG"

  override def dependsOn: Set[String] = Set("CENTRICV2_ZH_STAFFREG","CENTRICV2_ZH_DOCTORFACILITY","CENTRICV2_REGISTRATION")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val sqlQuery =
      """
        |select GROUPID, CLIENT_DS_ID, DATASRC, LOCALPROVIDERID, CREDENTIALS, EMAILADDRESS, FIRST_NAME, MIDDLE_NAME, LAST_NAME, NPI
        |from
        |(
        |select distinct
        |       '{groupid}' as GROUPID
        |       ,'{client_ds_id}' as CLIENT_DS_ID
        |       ,'zh_staffreg' as DATASRC
        |       ,pvid as LOCALPROVIDERID
        |       ,npi as NPI
        |       ,firstname as FIRST_NAME
        |       ,middlename as MIDDLE_NAME
        |       ,lastname as LAST_NAME
        |       , null as CREDENTIALS
        |       , null as EMAILADDRESS
        |  from CENTRICV2_ZH_STAFFREG p
        |
        |)
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId)

    sparkSession.sql(sqlQuery)
  }

}
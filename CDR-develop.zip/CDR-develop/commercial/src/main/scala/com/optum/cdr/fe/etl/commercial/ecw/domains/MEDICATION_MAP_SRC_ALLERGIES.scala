package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object MEDICATION_MAP_SRC_ALLERGIES extends FEQueryAndMetadata[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_ALLERGIES"

  override def dependsOn: Set[String] = Set("INPUT_ALLERGIES", "ZH_ITEMS")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localmedcode, localdescription, localndc, num_recs as no_ndc, 0 as has_ndc, num_recs
      |from
      |(
      |SELECT groupid,datasrc
      |    ,client_ds_id
      |    ,nullif(SUBSTR(localallergencd,1,100), '')  AS localmedcode
      |    ,localallergendesc as localdescription
      |    ,normalize_NDC(localndc) as localndc
      |    ,sum(nvl2(localndc,0,1)) as no_ndc
      |    ,sum(nvl2(localndc,1,0)) as has_ndc
      |    ,count(*) as num_recs
      |FROM
      |(   SELECT '{groupid}' as groupid
      |    ,'allergies' as datasrc
      |    ,{client_ds_id} as client_ds_id
      |    ,CASE WHEN Allergies.ItemID in ('0','-1') THEN Allergies.Drug ELSE allergies.itemid END AS localallergencd
      |    ,CASE WHEN Allergies.ItemID in ('0','-1') THEN Allergies.Drug ELSE zh_items.itemname END AS localallergendesc
      |    ,Allergies.Ndc_Code  AS localndc
      |    FROM (SELECT * FROM
      |          (SELECT a.*, ROW_NUMBER() OVER (PARTITION BY nullif(concat_ws('', Encounterid, DisplayIndex), ''),Drug
      |                                          ORDER BY modifieddate DESC NULLS LAST) rn
      |           FROM INPUT_ALLERGIES a  )
      |          WHERE rn = 1 ) allergies
      |    LEFT OUTER JOIN ZH_ITEMS ON (Allergies.ItemID = ZH_Items.ItemID)
      |    WHERE Allergies.AllergyType NOT in ('3','4','5')
      |)
      |where localallergencd is not NULL
      |group by groupid,datasrc
      |    ,client_ds_id
      |    ,localallergencd,
      |    localallergendesc
      |    ,normalize_NDC(localndc)
      |)
    """.stripMargin

}

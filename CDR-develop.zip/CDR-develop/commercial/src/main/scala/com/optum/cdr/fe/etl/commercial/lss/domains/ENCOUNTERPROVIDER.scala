package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.encounterprovider
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object ENCOUNTERPROVIDER extends FEQueryAndMetadata[encounterprovider]{

  override def name: String = CDRFEParquetNames.encounterprovider

  override def dependsOn: Set[String] = Set("LSS_PBRACCOUNTTRANSACTIONS", "LSS_PBRACCOUNTS")

  override def sparkSql: String =
    """
      |with act_trans as
      |(
      |     SELECT *
      |       , stack(2, providerid, 'PERFORM', referinproviderid, 'REFER') as (provider, providerrole)
      |     FROM LSS_PBRACCOUNTTRANSACTIONS
      |),
      |act_trans_up as
      |(
      |  SELECT sourceid, accountid, transactionid, type, servicedatetime, locationid, RowUpdateDateTime
      |     , CONCAT_WS('', sourceid, provider) as providerid, providerrole
      |  FROM act_trans
      |  WHERE provider is not null
      |),
      |act as
      |(
      |     SELECT t.*
      |         ,row_number() over ( Partition by SourceID, AccountID order by RowUpdateDateTime desc nulls first, PatientID desc nulls first) as act_rownumber
      |     FROM   LSS_PBRACCOUNTS t
      |),
      |act_qry as
      |(
      |  SELECT *
      |  FROM act
      |  WHERE act_rownumber = 1
      |)
      |SELECT datasrc,encounterid,facilityid,patientid,providerid,providerrole,encountertime
      |FROM (
      |   SELECT   x.*
      |         ,row_number() over (partition by EncounterID, ProviderID, LocalProviderRoleCode order by RowUpdateDateTime desc nulls first) as rownumber
      |   FROM (
      |       SELECT
      |          'pbraccounttransactions' as datasrc
      |           ,pbr.Servicedatetime AS encountertime
      |           ,CONCAT_WS('', pbr.Sourceid, act.Patientid) AS patientid
      |           ,CONCAT_WS('', pbr.Sourceid, pbr.Locationid) AS facilityid
      |           ,CONCAT_WS('', pbr.Sourceid, pbr.Accountid, pbr.Locationid, UPPER(DATE_FORMAT(pbr.Servicedatetime, 'dd-MMM-yy'))) AS encounterid
      |           ,providerrole AS localproviderrolecode
      |           ,pbr.RowUpdateDateTime
      |           ,pbr.providerid
      |           ,pbr.providerrole
      |       FROM act_trans_up pbr
      |       INNER JOIN act_qry act ON (pbr.sourceid=act.sourceid and pbr.accountid=act.accountid)
      |       WHERE pbr.Servicedatetime is not null
      |         ) x
      |     ) where rownumber = 1
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_prov
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object INT_CLAIM_PROV2 extends FETableInfo[int_claim_prov] {

  override def name: String = CDRFEParquetNames.int_claim_prov

  override def dependsOn: Set[String] = Set("MEMBER", CDRFEParquetNames.int_claim_prov)

  override def tableOrder: Int = 2

  override def saveMode: SaveMode = SaveMode.Append

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId

    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val (prov_h969333_npi_incl2,prov_npi2) = groupId match {
      case "H969333" => ("""left join ref_cmsnpi Cms on (Cms.NPI =a.Pcp_Nat_Prov_Id and  Cms.entity_type_code = '1')""","""Cms.NPI""")
      case _ => ("""---""","""Pcp_Nat_Prov_Id""")
    }

    sparkSession.sql(
      """
        |
        |select groupid, client_ds_id, datasrc, prov_id, prov_npi, source_code
        |from
        |(
        |select distinct '{groupid}' 		as 	groupid,
        |       {client_ds_id} 		as 	client_ds_id,
        |	   'member_pcp' 			as 	datasrc,
        |	   Pcp_Prov_Id 			    as 	prov_id,
        |	   {prov_npi2}               as  prov_npi,
        |	   Enty_Nm 					as 	source_code
        |  from MEMBER a
        |{prov_h969333_npi_incl2}
        |where PCP_PROV_ID <> '999999'
        |
        |)
        |
    """.stripMargin
        .replace("{groupid}", groupId.toString)
        .replace("{client_ds_id}", clientDsId.toString)
        .replace("{prov_h969333_npi_incl2}", prov_h969333_npi_incl2)
        .replace("{prov_npi2}", prov_npi2)
    )
  }
}

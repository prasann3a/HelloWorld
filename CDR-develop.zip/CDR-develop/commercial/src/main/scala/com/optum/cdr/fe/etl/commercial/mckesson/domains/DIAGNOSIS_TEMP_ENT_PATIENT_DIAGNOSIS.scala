package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.diagnosis
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object DIAGNOSIS_TEMP_ENT_PATIENT_DIAGNOSIS extends FETableInfo[diagnosis]{
  override def name: String = "DIAGNOSIS_TEMP_ENT_PATIENT_DIAGNOSIS"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","ENT_PATIENT_DIAGNOSIS","MCKESSON_ENT_PATIENT","MCKESSON_ZH_ENT_CONFIG_CODE_SET")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val diag_primary = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DIAGNOSIS_PRIMARY", "DIAGNOSIS", "ENT_PATIENT_DIAGNOSIS", "DIAGNOSIS_TYPE_LSEQ").mkString(",")
    val excl_diag = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DIAGNOSIS_EXC", "DIAGNOSIS", "ENT_PATIENT_DIAGNOSIS", "DIAGNOSIS_TYPE_LSEQ").mkString(",")

    sparkSession.sql(
      s"""
         |WITH uni_diag AS
         |(SELECT * FROM (
         |   (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY patient_diagnosis_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |      FROM ENT_PATIENT_DIAGNOSIS p
         |     WHERE pat_seq IS NOT NULL
         |       AND Created_Dt IS NOT NULL
         |       AND (diagnosis_code_seq IS NOT NULL OR diagnosis_code IS NOT NULL)
         |       AND (diagnosis_type IS NULL OR diagnosis_type NOT IN ({excl_diag}))
         | 	))
         | WHERE rn = 1),
         | uni_pat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |   WHERE cpi_seq IS NOT NULL )
         |) WHERE rn = 1)
         |select datasrc, patientid, encounterid, dx_timestamp, localdiagnosis, primarydiagnosis, mappeddiagnosis, codetype, facilityid, hosp_dx_flag, localdiagnosisstatus, localactiveind, resolutiondate, localpresentonadmission, localdiagnosisstatus as localdischargeflg, localdiagnosisstatus as localadmitflg
         |from
         |(
         |SELECT  'ent_patient_diagnosis' AS datasrc
         |	,uni_diag.Created_Dt  	AS dx_timestamp
         |	,COALESCE(uni_diag.diagnosis_code,zh.Code_Value)  AS localdiagnosis
         |	,uni_pat.cpi_seq  	AS patientid
         |	,NVL2(Diagnosis_Status_Lseq, concat_ws('', {client_ds_id}, '.', Diagnosis_Status_Lseq), NULL) AS localactiveind
         |	,NVL2(Diagnosis_Type_Lseq, concat_ws('', {client_ds_id}, '.', Diagnosis_Type_Lseq), NULL) AS localdiagnosisstatus
         |	,CASE WHEN uni_diag.coding_system LIKE 'I%9%' THEN 'ICD9'
         |	      WHEN uni_diag.coding_system LIKE 'I%10%' THEN 'ICD10'
         |	      ELSE NULL END 	AS codetype
         |	,uni_diag.pat_seq  	AS encounterid
         |	,NVL2(uni_diag.Present_On_Admission_Fl, concat_ws('', {client_ds_id}, '.', uni_diag.Present_On_Admission_Fl), NULL)
         |	      		AS localpresentonadmission
         |	,NULL  		AS facilityid
         |	,CASE WHEN diagnosis_type_lseq IN ({diag_primary}) THEN '1' ELSE '0' END  AS primarydiagnosis
         |	,COALESCE(uni_diag.diagnosis_code,zh.Code_Value) AS mappeddiagnosis
         |	,'Y'		AS hosp_dx_flag
         |	,NULL		AS resolutiondate
         |        ,ROW_NUMBER() OVER (PARTITION BY uni_pat.cpi_seq, uni_diag.Created_Dt, uni_diag.pat_seq,
         |                                         COALESCE(uni_diag.diagnosis_code,zh.Code_Value)
         |                            ORDER BY uni_diag.modified_dt DESC NULLS LAST) AS rn
         |FROM UNI_DIAG
         |   JOIN UNI_PAT ON (uni_diag.pat_seq = uni_pat.pat_seq)
         |   LEFT OUTER JOIN MCKESSON_ZH_ENT_CONFIG_CODE_SET zh ON uni_diag.Diagnosis_code_seq = Zh.Code_Set_Seq
         |
 |)
         |where rn = 1
       """.stripMargin.replace("{diag_primary}",diag_primary).replace("{excl_diag}",excl_diag).replace("{client_ds_id}",clientDsId))

  }


}

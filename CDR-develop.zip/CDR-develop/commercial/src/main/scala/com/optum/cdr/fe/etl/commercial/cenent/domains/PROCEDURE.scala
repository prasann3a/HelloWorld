package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object PROCEDURE extends FEQueryAndMetadata[proceduredo] {

  override def name: String = CDRFEParquetNames.proceduredo

  override def dependsOn: Set[String] = Set("TEMP_PROCEDURE_PART1", "TEMP_PROCEDURE_PART2", "PROCEDUREDO_FINDING")

  override def sparkSql: String =
    """
      SELECT * FROM TEMP_PROCEDURE_PART1

      UNION ALL

      SELECT * FROM TEMP_PROCEDURE_PART2

      UNION ALL

      SELECT * FROM PROCEDUREDO_FINDING
    """.stripMargin

}
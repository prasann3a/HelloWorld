package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object OBSERVATION extends FEQueryAndMetadata[observation] {

  override def name: String = CDRFEParquetNames.observation

  override def dependsOn: Set[String] = Set("FINDNG", "SERVCE", "ZH_XCNCPT", "ZCM_OBSTYPE_CODE")

  override def sparkSql: String =
    """
     |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, facilityid, local_obs_unit, statuscode, std_obs_unit
     |from
     |(
     |SELECT * FROM (
     |SELECT '{groupid}' as groupid,
     |	'findng' as datasrc
     |	,{client_ds_id} as client_ds_id
     |	,Findng.Txt  AS localresult
     |	,Findng.Concept_Descr_Num  AS localcode
     |	,Findng.Data_Ts  AS obsdate
     |	,Findng.Pat_Person_Num  AS patientid
     |	,Servce.Encntr_Num  AS encounterid
     |	,Findng.Findng_Fac_Num  AS facilityid
     |	,COALESCE(Zh_Xcncpt.Concept_Meas_Unit_Id, z.localunit)   AS local_obs_unit
     |	,Findng.Data_Status_Cde  AS statuscode
     |	,z.obstype
     |	, null as obsresult
     |	, z.obstype_std_units as std_obs_unit
     |	,ROW_NUMBER() OVER (PARTITION BY Findng.Pat_Person_Num, Servce.Encntr_Num, z.obscode, z.obstype, Findng.Data_Ts
     |                    ORDER BY Findng.Data_Ts DESC NULLS LAST) rn
     |FROM FINDNG
     |     JOIN SERVCE ON (servce.pat_person_num = findng.pat_person_num and
     |                                   servce.data_create_ts = findng.serv_data_create_ts)
     |     JOIN ZH_XCNCPT ON (zh_xcncpt.num=findng.concept_descr_num)
     |     JOIN ZCM_OBSTYPE_CODE z on (z.obscode = Findng.Concept_Descr_Num AND
     |				    z.groupid = '{groupid}' AND
     |				    z.datasrc = 'findng' AND
     |				    z.obstype <>'LABRESULT')
     |WHERE finding_type_cde IN ('OUTPUT', 'FINDNG'))
     |WHERE rn = 1
     |)
     |where obsdate IS NOT NULL AND patientid IS NOT NULL
     |
     |union all
     |
     |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, facilityid, local_obs_unit, statuscode, std_obs_unit
     |from
     |(
     |SELECT * FROM (
     |SELECT '{groupid}' as groupid,
     |	'findngs' as datasrc
     |	,{client_ds_id} as client_ds_id
     |	,Findng.Txt  AS localresult
     |	,concat_ws('', Zh_Xcncpt.nm, '_', Findng.txt)  AS localcode
     |	,Findng.Data_Ts  AS obsdate
     |	,Findng.Pat_Person_Num  AS patientid
     |	,Servce.Encntr_Num  AS encounterid
     |	,Findng.Findng_Fac_Num  AS facilityid
     |	,COALESCE(Zh_Xcncpt.Concept_Meas_Unit_Id, z.localunit)  AS local_obs_unit
     |	,Findng.Data_Status_Cde  AS statuscode
     |	,z.obstype
     |	, null as obsresult
     |	, z.obstype_std_units as std_obs_unit
     |	,ROW_NUMBER() OVER (PARTITION BY Findng.Pat_Person_Num, Servce.Encntr_Num, z.obscode, z.obstype, Findng.Data_Ts
     |                    ORDER BY Findng.Data_Ts DESC NULLS LAST) rn
     |FROM FINDNG
     |     JOIN SERVCE ON (servce.pat_person_num = findng.pat_person_num and
     |                                   servce.data_create_ts = findng.serv_data_create_ts)
     |     JOIN ZH_XCNCPT ON (zh_xcncpt.num=findng.concept_descr_num)
     |     JOIN ZCM_OBSTYPE_CODE z on (z.obscode = concat_ws('', Zh_Xcncpt.nm, '_', Findng.txt) AND
     |				    z.groupid = '{groupid}' AND
     |				    z.datasrc = 'findngs')
     |WHERE finding_type_cde = 'FINDNG')
     |WHERE rn = 1
     |)
     |where obsdate IS NOT NULL AND patientid IS NOT NULL
    """.stripMargin

}
package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_PAT_HM extends FEQueryAndMetadata[proceduredo]{

  override def name: String = "PROCEDURE_PAT_HM"

  override def dependsOn: Set[String] = Set("MED3000_PATIENT_HM","MED3000_ZH_HM_MASTER","MED3000_MAP_CUSTOM_PROC")

  override def sparkSql: String =
    """
      select groupid, datasrc, client_ds_id, localcode, patientid, proceduredate, localname, mappedcode, codetype
 |from
 |(
 |select '{groupid}'       as groupid
 |       ,'pat_hm'      as datasrc
 |       ,{client_ds_id}   as client_ds_id
 |       ,hm.Hm_Master_Key    as localcode
 |       ,hm.Blind_Key      as patientid
 |       ,hm.Label_Date         as proceduredate
 |       ,mast.Health_Maint_Label   as localname
 |       ,map.Mappedvalue   as mappedcode
 |       ,'CUSTOM'        as codetype
 |       ,ROW_NUMBER() OVER (PARTITION BY Hm.Blind_Key,hm.Hm_Master_Key,hm.Label_Date, map.Mappedvalue ORDER BY Hm.Update_Date DESC nulls last) as rank_proc
 |  from MED3000_PATIENT_HM hm
 | inner join MED3000_ZH_HM_MASTER mast on (hm.HM_Master_Key = mast.HM_Master_Key)
 | inner join MED3000_MAP_CUSTOM_PROC map on (hm.Hm_Master_key = map.LocalCode and map.groupid = '{groupid}' and datasrc = 'pat_hm' )
 |
 |
 |)
 |where  proceduredate is not null and patientid is not null
    """.stripMargin


}

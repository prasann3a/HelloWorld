package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.patient_id
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT_ID extends FEQueryAndMetadata[patient_id]{

  override def name: String = CDRFEParquetNames.patient_id

  override def dependsOn: Set[String] = Set("PATIENT_FAC_GRP_SEG_TB", "PATIENTS_TB", "PATIENT_HISTORIES_TB")

  override def sparkSql: String =

  """
    |With Patient_Fac as
    |(
    |Select  distinct PATIENT_ID from PATIENT_FAC_GRP_SEG_TB
    |)
    |
    |select groupid, patientid, datasrc, idtype, idvalue, client_ds_id
    |from
    |(
    |select  * from (
    |SELECT '{groupid}' as groupid, 'ssn' as datasrc
    |       ,{client_ds_id} as client_ds_id
    |       ,'SSN' AS idtype
    |       ,coalesce(pht.ssn,ptp.ssn) AS idvalue
    |       ,PTP.Patient_Id AS patientid
    |       ,row_number() over (partition by ptp.Patient_ID order by ptp.Last_Modified_Date desc nulls first) as rownumber
    |FROM PATIENTS_TB PTP
    |     INNER JOIN PATIENT_HISTORIES_TB   PHT ON (pht.Patient_ID = Ptp.Patient_ID)
    |     INNER JOIN PATIENT_FAC pfg on (pfg.patient_id = Ptp.PATIENT_ID)
    |WHERE coalesce(pht.SSN,ptp.SSN) <> '000000000'
    |  AND PTP.Patient_Id is not null
    |      )
    |where rownumber=1
    |)
  """
  .stripMargin

}

package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.allergy
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ALLERGY extends FEQueryAndMetadata[allergy]{

override def name: String = CDRFEParquetNames.allergy

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TSM255_PERSON_ALLERGY")

override def sparkSql: String =
  """
    |SELECT  groupid
    |       ,datasrc
    |       ,client_ds_id
    |       ,localallergencd
    |       ,onsetdate
    |       ,patientid
    |       ,encounterid
    |       ,localallergendesc
    |       ,localstatus
    |       ,localallergentype
    |FROM
    |(
    |	SELECT  '{groupid}'                                                                    AS groupid
    |	       ,'person_allergy'                                                               AS datasrc
    |	       ,{client_ds_id}                                                                 AS client_ds_id
    |	       ,pa.Alg_Desc                                                                    AS localallergencd
    |	       ,COALESCE(pa.Allergy_Id_Ts,pa.Ety_Ts,pa.Utc_Ety_Ts)                             AS onsetdate
    |	       ,pa.Psn_Int_Id                                                                  AS patientid
    |	       ,NULL                                                                           AS encounterid
    |	       ,UPPER(pa.Alg_Desc)                                                             AS localallergendesc
    |	       ,NULL                                                                           AS localndc
    |	       ,NVL2(pa.act_fg,concat_ws('','{client_ds_id}','.',pa.act_fg),NULL)           AS localstatus
    |	       ,NVL2(pa.Alg_Type_Id,concat_ws('','{client_ds_id}','.',pa.Alg_Type_Id),NULL) AS localallergentype
    |	       ,ROW_NUMBER() OVER (PARTITION BY pa.Psn_Int_Id,COALESCE(pa.Allergy_Id_Ts,pa.Ety_Ts,pa.Utc_Ety_Ts),pa.Allergy_Int_Id ORDER BY pa.Lst_Mod_Ts DESC NULLS LAST) rn
    |	FROM MCKESSON_PGN_V1_TSM255_PERSON_ALLERGY pa
    |	WHERE pa.row_sta_cd <> 'D'
    |	AND pa.Psn_Int_Id IS NOT NULL
    |	AND (pa.Alg_Desc <> 'NKA' OR pa.Alg_Desc NOT LIKE 'NO KNOWN%')
    |)
    |WHERE rn = 1
    |AND onsetdate IS NOT NULL
  """.stripMargin
}

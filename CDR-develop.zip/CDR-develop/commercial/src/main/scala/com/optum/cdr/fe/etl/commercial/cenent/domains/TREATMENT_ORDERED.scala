package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.treatment_ordered
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object TREATMENT_ORDERED extends FETableInfo[treatment_ordered] {

  override def name: String = CDRFEParquetNames.treatment_ordered

  override def dependsOn: Set[String] = Set("ORDERZ", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val orderList = mpvList(mapPredicateValues, groupId, clientDsId.toString,"ORDERZ","TREATMENT_ORDERED","ORDERZ","SERV_DESCR_NUM").mkString(",")

    sparkSession.sql(
      s"""
      |select groupid, datasrc, client_ds_id, localcode, order_date, patientid, order_id, order_prov_id, encounterid
      |from
      |(
      |select
      |       distinct '{groupid}'    as groupid
      |       ,'orderz' 			as datasrc
      |	   ,{client_ds_id} 		as client_ds_id
      |	   ,rdr.Serv_Descr_Num 	as localcode
      |	   ,rdr.Begin_Dttm 		as order_date
      |	   ,rdr.Pat_Person_Num 	as patientid
      |	   ,nullif(concat_ws('', rdr.Pat_Person_Num, date_format(rdr.data_create_ts,'yyyyMMddHHmmss'), rdr.serv_descr_num), '') as order_id
      |	   ,rdr.assoc_Num 		as order_prov_id
      |	   ,rdr.Encntr_Num 		as encounterid
      |  from ORDERZ rdr
      | where rdr.serv_descr_num in ({order_list})
      |
      |)
      |where patientid is not null
    """.stripMargin
        .replace("{order_list}", orderList)
        .replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId.toString )
    )
  }
}


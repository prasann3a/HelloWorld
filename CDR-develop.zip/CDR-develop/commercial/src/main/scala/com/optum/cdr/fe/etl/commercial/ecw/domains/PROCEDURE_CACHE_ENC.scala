package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_ENC extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_ENC"

  override def dependsOn: Set[String] = Set("ENC", "ZH_VISITCODES", "MAP_CUSTOM_PROC", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listVisitstscodeid = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ECW", "PROCEDURE",
      "ENC", "VISITSTSCODEID").mkString(",")
    val listStatus = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ECW", "PROCEDURE",
      "ENC", "STATUS").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localcode
        |       ,patientid
        |       ,proceduredate
        |       ,localname
        |       ,referproviderid
        |       ,actualprocdate
        |       ,performingproviderid
        |       ,codetype
        |       ,mappedcode
        |       ,facilityid
        |       ,encounterid
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                            AS groupid
        |	       ,'enc'                                                                                  AS datasrc
        |	       ,{client_ds_id}                                                                         AS client_ds_id
        |	       ,concat_ws('',{client_ds_id},'.',e.visittype)                                           AS localcode
        |	       ,e.patientid                                                                            AS patientid
        |	       ,e.enc_date                                                                             AS proceduredate
        |	       ,zh.description                                                                         AS localname
        |	       ,e.refprid                                                                              AS referproviderid
        |	       ,e.enc_date                                                                             AS actualprocdate
        |	       ,e.doctorid                                                                             AS performingproviderid
        |	       ,'CUSTOM'                                                                               AS codetype
        |	       ,mcp.mappedvalue                                                                        AS mappedcode
        |	       ,nullif(e.facilityid,'0')                                                               AS facilityid
        |	       ,e.encounterid                                                                          AS encounterid
        |	       ,row_number() over (partition by e.encounterid ORDER BY e.modifieddate desc nulls last) AS rownumber
        |	FROM ENC e
        |	LEFT OUTER JOIN ZH_VISITCODES zh
        |		ON (zh.hum_name = e.visittype)
        |	INNER JOIN MAP_CUSTOM_PROC mcp
        |		ON (mcp.groupid = '{groupid}' AND mcp.datasrc = 'enc' AND mcp.localcode = concat_ws('', {client_ds_id}, '.', e.visittype))
        |	WHERE e.patientid is not null
        |	AND e.visittype is not null
        |	AND e.enc_date is not null
        |	AND e.deleteflag <> '1'
        |	AND e.status not IN ({list_status})
        |	AND e.visitstscodeid not IN ({list_visitstscodeid})
        |)
        |WHERE rownumber = 1
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{list_visitstscodeid}", listVisitstscodeid)
        .replace("{list_status}", listStatus)
    )
  }


}

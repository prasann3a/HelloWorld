package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
object GTT_LABRESULT_NONNUMERIC extends FETableInfo[gtt_labres_cerner_numeric]{

  override def name:String= "GTT_LABRESULT_NONNUMERIC"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select groupid, datasrc, encounterid, patientid, labresultid, localresult, localcode, localname, localunits, dateavailable as labresult_date, client_ds_id, dateavailable, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25
         |from
         |(
         |   LABRESULTCACHE
         |)
         |where localresult_numeric is null
       """.stripMargin)
  }

  override def dependsOn: Set[String] = Set("LABRESULTCACHE")
}

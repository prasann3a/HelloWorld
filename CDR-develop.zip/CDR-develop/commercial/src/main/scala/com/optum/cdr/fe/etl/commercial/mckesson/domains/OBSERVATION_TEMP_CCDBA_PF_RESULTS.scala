package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_TEMP_CCDBA_PF_RESULTS extends FETableInfo[observation] {
  override def name: String = "OBSERVATION_TEMP_CCDBA_PF_RESULTS"

  override def dependsOn: Set[String] = Set("ZCM_OBSTYPE_CODE","CCDBA_PF_RESULTS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select datasrc, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid
         |from
         |(
         |SELECT 'pf_results' 		AS datasrc
         |	,res.result_value	AS localresult
         |	,concat_ws('', {client_ds_id}, '.', res.Label_Seq) AS localcode
         |	,res.Perform_Ddt	AS obsdate
         |	,res.cpi_seq  		AS patientid
         |	,res.pat_seq  		AS encounterid
         |	,NULL		 	AS facilityid
         |	,z.obstype
         |	,z.localunit 		AS local_obs_unit
         |    	,z.obstype_std_units 	AS std_obs_unit
         |	,res.result_value	AS obsresult
         |	,ROW_NUMBER() OVER (PARTITION BY res.cpi_seq,res.pat_seq,res.label_seq,res.Perform_Ddt,z.obstype
         |			    ORDER BY CHART_DDT DESC NULLS LAST) obs_rn
         |FROM CCDBA_PF_RESULTS res
         |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
         |				z.datasrc = 'pf_results' AND
         |				z.obscode = concat_ws('', {client_ds_id}, '.', res.Label_Seq))
         |WHERE res.cpi_seq IS NOT NULL
         |  AND res.Perform_Ddt IS NOT NULL
         |  AND res.Label_Seq IS NOT NULL
         |
         |)
         |where obs_rn = 1
       """.stripMargin.replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId))
  }


}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.etl.commercial.gtt_prov_pat_rel
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}
import org.apache.spark.storage.StorageLevel

object GTT_PROV_PAT_REL_ZH_PCP extends FEQueryAndMetadata[gtt_prov_pat_rel]{

  override def name: String = "GTT_PROV_PAT_REL_ZH_PCP"

  override def dependsOn: Set[String] = Set("ZH_PCPHISTORY", "PATIENT")

  override def sparkSql: String =
    """
    WITH uni_hist AS
 |(SELECT * FROM (
 |   SELECT h.*, ROW_NUMBER() OVER (PARTITION BY pid, pcpid, pcpstartdate ORDER BY pcpstartdate) rn
 |   FROM ZH_PCPHISTORY h
 |   WHERE pcpid IS NOT NULL
 |   AND   pcpid <> '0'
 |   AND   pid IS NOT NULL
 |   AND   pcpstartdate IS NOT NULL)
 | WHERE rn = 1
 |  ),
 |aco_hist AS
 |(SELECT *
 | FROM UNI_HIST u
 |      JOIN PATIENT  c ON (u.pid = c.patientid AND
 |                                                c.client_ds_id = {client_ds_id}))
 |select groupid, datasrc, client_ds_id, providerid, patientid, localrelshipcode, startdate, enddate
 |from
 |(
 |SELECT '{groupid}' as groupid
 |	,'zh_pcp' as datasrc
 |	,{client_ds_id} as client_ds_id
 |	,'PCP'  AS localrelshipcode
 |	,p.patientid
 |	,p.providerid
 |	,p.startdate
 |	,current_date as enddate
 |
 |
 |FROM (
 |	SELECT  pid  AS patientid
 |		,pcpid  AS providerid
 |		,pcpstartdate  AS startdate
 |
 |	FROM ACO_HIST
 |	) p
 |
 |)
    """.stripMargin



}


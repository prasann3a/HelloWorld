package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.patient_id
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT_ID extends FEQueryAndMetadata[patient_id]{

  override def name: String = CDRFEParquetNames.patient_id

  override def dependsOn: Set[String] = Set("MED3000_MPI_XREF")

  override def sparkSql: String =
    """
     select  datasrc, patientid, idtype, idvalue
 |from
 |(
 |select a.*
 |       ,row_number() over (partition by patientid,idtype order by lastupdateddate desc nulls last ) as ssn_mrn_row
 |from (
 |select '{groupid}' 				as groupid
 |       ,'mpi_xref' 				as datasrc
 |       ,{client_ds_id} 			as client_ds_id
 |	   ,Case When ID_Type = 'SSN' then 'SSN'
 | 	         when ID_Type = 'MR'  then 'GPP_ID'
 |		end as idtype
 |       ,Mpi_Xref.Id  			as idvalue
 |       ,Mpi_Xref.Blind_Key  	as patientid
 |       ,Mpi_Xref.Update_Date    as lastupdateddate
 |  from MED3000_MPI_XREF MPI_XREF
 | where Mpi_Xref.Id is not null ) a
 |
 |
 |)
 |where ssn_mrn_row = 1  and idtype is not null and patientid is not null
    """.stripMargin
}

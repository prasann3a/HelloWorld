package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.cdr.models.{immunization => cdr_immunization}
import org.apache.spark.storage.StorageLevel

object IMMUNIZATION extends FEQueryAndMetadata[cdr_immunization]{

  override def name: String = "IMMUNIZATION"

  override def dependsOn: Set[String] = Set("CENTRICV2_IMMUNIZATION")

  override def sparkSql: String =
    """
      |with
 |dup as
 |(
 |  select a.*,
 |  row_number() over
 |  (
 |    partition by pid, coalesce (vaccineName, vaccineGroupName), administeredDate
 |    order by db_updated_date desc
 |  ) as ranking
 |  from CENTRICV2_IMMUNIZATION a
 |),
 |dedup as (select * from dup where ranking = 1)
 |select
 |'immunization' as datasrc
 |,mmn.pid as patientID
 |,case
 | when (mmn.administeredDate < to_date('01-JAN-1900') or mmn.administeredDate > current_date)
 |   then null
 | when mmn.wasGiven in ('Y', 'U') then mmn.administeredDate
 | end as adminDate
 |,mmn.db_create_date as documentedDate
 |,case
 | when mmn.reasonRemoved is not null then reasonRemoved
 | when mmn.reasonNotGiven is not null then reasonNotGiven
 | when mmn.wasGiven = 'N' then
 | regexp_extract(mmn.administeredcomments,'(pt\\s*|patient\\s*)*\\.*(refuse|refuse|decline|contraindicate|disease|defer)(s|d)*',0)
 | end as localDeferredReason
 |,mmn.sdid as encounterID
 |,coalesce (mmn.vaccineName, mmn.vaccineGroupName) as localImmunizationCD
 |,coalesce (mmn.vaccineName, mmn.vaccineGroupName) as localImmunizationDesc
 |,mmn.NDC as localNDC
 |,mmn.GPI as localGPI
 |,mmn.route as localRoute
 |from dedup mmn
 |where
 |nvl(mmn.reasonRemoved, 'x') not in ('Entered In Error','Migration Error') and
 |nvl(mmn.filedInError, 'N') <> 'Y' and
 |coalesce (mmn.vaccineName, mmn.vaccineGroupName) is not null and
 |mmn.pid is not null
""".stripMargin

  override def cacheDataFrame: Option[StorageLevel] = None

  override def saveDataFrameToParquet: Boolean = true

}

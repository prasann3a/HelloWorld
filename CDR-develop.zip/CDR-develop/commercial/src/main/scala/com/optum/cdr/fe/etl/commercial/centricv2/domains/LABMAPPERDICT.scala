package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.zh_lab_dict
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object LABMAPPERDICT extends FETableInfo[zh_lab_dict] {

  override def name: String = "LABMAPPERDICT"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES", "CENTRICV2_ZH_OBSHEAD","CENTRICV2_DOCUMENTS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val constNoMpvMatches = "'NO_MPV_MATCHES'"
    val nullValue = "'null'"

    val listZhobsHdidMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "RESULTS", "LABRESULT", "ZH_OBSHEAD", "HDID").mkString(",")
    val listZhobsHdid1 = if (listZhobsHdidMpv == constNoMpvMatches) "null" else listZhobsHdidMpv
    val listZhobsHdid = if (listZhobsHdid1 == nullValue) "null" else listZhobsHdid1

    val listZhobsGroupidMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "RESULTS", "LABRESULT", "ZH_OBSHEAD", "GROUPID").mkString(",")
    val listZhobsGroupid1 = if (listZhobsGroupidMpv == constNoMpvMatches) "null" else listZhobsGroupidMpv
    val listZhobsGroupid = if (listZhobsGroupid1 == nullValue) "null" else listZhobsGroupid1


    val listsum = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOCUMENTS", "ZH_LAB_DICT", "DOCUMENTS", "SUMMARY").mkString(",")
    val listsum_1 = if (listsum == constNoMpvMatches) "null" else listsum
    val regexpfilter = if (listsum_1 == nullValue) "null" else listsum_1
    val regexpcond = if (listsum_1 == nullValue) " AND 1=2" else " AND 1=1"



    val sqlQuery =
      """
        |        select groupid, localresultcode as localcode, localresultname as localname,
        |                localresultdescription as localdesc, localunits, datatype as localdatatype,
        |                client_ds_id, local_loinc_code
        |         from (
        |        SELECT  '{groupid}'                   as groupid
        |        ,{client_ds_id}                   as client_ds_id
        |        ,obshead.Hdid                   AS localresultcode
        |        ,obshead.Obstype                AS datatype
        |        ,obshead.Description            AS localresultdescription
        |        ,obshead.Name                   AS localresultname
        |        ,obshead.Unit                   AS localunits
        |        ,obshead.Loinccode              AS local_loinc_code
        |        FROM CENTRICV2_ZH_OBSHEAD obshead
        |        where (obshead.groupid not in ({list_zhobs_groupid})
        |        or obshead.hdid in ({list_zhobs_hdid}))
        |        )
        |
        |        union
        |
        |        select groupid, localresultcode as localcode, localresultname as localname,
        |                localresultdescription as localdesc, localunits, datatype as localdatatype,
        |                client_ds_id, local_loinc_code
        |        from (
        |         SELECT
        |	    '{groupid}'                       as groupid
        |	    ,{client_ds_id}                   as client_ds_id
        |	    ,upper(dcm.Summary)               AS localresultcode
        |	    ,null                             AS datatype
        |	    ,null                             AS localresultdescription
        |	    ,upper(dcm.Summary)               AS localresultname
        |	    ,null                             AS localunits
        |	    ,null                             AS local_loinc_code
        |        FROM CENTRICV2_DOCUMENTS dcm
        |        WHERE dcm.Doctype = 7
        |        AND rlike(dcm.Summary, concat('(?i)',{reg_exp_filter}))
        |        AND dcm.Summary is not null
        |        {reg_exp_cond}
        |        )
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{list_zhobs_groupid}", listZhobsGroupid).
        replace("{list_zhobs_hdid}", listZhobsHdid).
        replace("{reg_exp_filter}", regexpfilter).
        replace("{reg_exp_cond}", regexpcond)

    sparkSession.sql(sqlQuery)
  }

}
package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object CLAIM_RESULTS extends FEQueryAndMetadata[claim] {

  override def name: String = "CLAIM_RESULTS"

  override def dependsOn: Set[String] = Set("CLAIM_PROC_RESULT_CACHE")

  override def sparkSql: String =
    """
      |select
      |groupid, datasrc, client_ds_id, encounterid, patientid, servicedate,
      |claimproviderid, claimproviderid as localbillingproviderid, claimid, localcpt, cptcode as mappedcpt
      |from
      |(
      |CLAIM_PROC_RESULT_CACHE
      |)
      |where claimid is not null and servicedate is not null and patientid is not null and obs_not_done = 'N' and claim_rn=1
    """.stripMargin


}
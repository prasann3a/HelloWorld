package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.patientdetail
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTDETAIL extends FEQueryAndMetadata[patientdetail]{

  override def name: String = CDRFEParquetNames.patientdetail

  override def dependsOn: Set[String] = Set("PATIENT_CACHE")

  override def sparkSql: String =

  """
    |select groupid, datasrc, patientid, 'LAST_NAME' as patientdetailtype, lastname as localvalue, patdetail_timestamp, client_ds_id
    |from
    |(
    |PATIENT_CACHE
    |)
    |where lastname is not null
    |
    |union all
    |
    |select groupid, datasrc, patientid, 'FIRST_NAME' as patientdetailtype, firstname as localvalue, patdetail_timestamp, client_ds_id
    |from
    |(
    |PATIENT_CACHE
    |)
    |where firstname is not null
    |
    |union all
    |
    |select groupid, datasrc, patientid, 'DECEASED' as patientdetailtype, deathindicator as localvalue, patdetail_timestamp, client_ds_id
    |from
    |(
    |PATIENT_CACHE
    |)
    |where deathindicator is not null
    |
    |union all
    |
    |select groupid, datasrc, patientid, 'ETHNICITY' as patientdetailtype, ethnicity as localvalue, patdetail_timestamp, client_ds_id
    |from
    |(
    |PATIENT_CACHE
    |)
    |where ethnicity is not null
    |
    |union all
    |
    |select groupid, datasrc, patientid, 'GENDER' as patientdetailtype, gender as localvalue, patdetail_timestamp, client_ds_id
    |from
    |(
    |PATIENT_CACHE
    |)
    |where gender is not null
    |
    |union all
    |
    |select groupid, datasrc, patientid, 'MIDDLE_NAME' as patientdetailtype, middlename as localvalue, patdetail_timestamp, client_ds_id
    |from
    |(
    |PATIENT_CACHE
    |)
    |where middlename is not null
    |
    |union all
    |
    |select groupid, datasrc, patientid, 'MARITAL' as patientdetailtype, maritalstatus as localvalue, patdetail_timestamp, client_ds_id
    |from
    |(
    |PATIENT_CACHE
    |)
    |where maritalstatus is not null
    |
    |union all
    |
    |select groupid, datasrc, patientid, 'LANGUAGE' as patientdetailtype, language as localvalue, patdetail_timestamp, client_ds_id
    |from
    |(
    |PATIENT_CACHE
    |)
    |where language is not null
    |
  """
  .stripMargin

}

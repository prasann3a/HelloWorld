package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object MEDICATION_MAP_SRC_OLDRXMAIN extends FEQueryAndMetadata[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_OLDRXMAIN"

  override def dependsOn: Set[String] = Set("OLDRXMAIN", "ZH_ITEMS")

  override def sparkSql: String =
    """
      |WITH rxmn AS
      |(SELECT * FROM (
      |	(SELECT m.*, ROW_NUMBER() OVER (PARTITION BY oldrxid ORDER BY modifieddate
      |	       DESC nulls last) rn
      |	FROM OLDRXMAIN m  ))
      | WHERE rn = 1 )
      |select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs
      |from
      |(
      |SELECT '{groupid}' as groupid
      |        ,'oldrxmain' as datasrc
      |	,{client_ds_id} as client_ds_id
      |        ,rxmn.itemid as localmedcode
      |        ,normalize_NDC (rxmn.ndc_code) as localndc
      |        ,Zh_Items.Itemname as localdescription
      |        ,sum(case when rxmn.ndc_code is null then 1 else 0 end) as no_ndc
      |        ,sum(case when rxmn.ndc_code is null then 0 else 1 end) as has_ndc
      |        ,count(*) as num_recs
      |FROM RXMN
      |
      |     LEFT OUTER JOIN ZH_ITEMS ON (rxmn.ItemID = zh_items.itemid)
      |GROUP BY
      |        rxmn.itemid
      |        ,normalize_NDC (rxmn.ndc_code)
      |        ,Zh_Items.Itemname
      |)
    """.stripMargin

}

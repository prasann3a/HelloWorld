package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.prov_pat_rel
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, RuntimeVariables}


object PROV_PAT_REL extends FEQueryAndMetadata[prov_pat_rel] {

  override def name: String = CDRFEParquetNames.prov_pat_rel

  override def dependsOn: Set[String] = Set("ACCT", "ENCNTR")

  override def sparkSql: String =
    """
      |select groupid, datasrc, providerid, patientid, localrelshipcode, startdate, enddate, client_ds_id
      |from
      |(
      |select groupid,
      |       datasrc,
      |       client_ds_id,
      |	      providerid,
      |       patientid,
      |	      localrelshipcode,
      |       case when prev_pcpid is null then begin_date else startdate end as startdate,
      |	      case when enddate is null then NULL
      |            when enddate < startdate then startdate else enddate end  enddate,
      |	      case when '{prov_pat_exception}' = 'EXCEPTION'  then 'y' else 'n' end incl_rows
      |from (
      |select groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,localrelshipcode
      |       ,patientid
      |       ,startdate
      |       ,providerid
      |       ,endofyear
      |       ,date_sub(lead(startdate) OVER (partition by patientid order by startdate), 1) 			      as  enddate
      |	      ,lag(providerid) over (partition by patientid order by startdate,providerid)    as prev_pcpid
      |       ,to_date('20050101','yyyyMMdd')                                                 as begin_date
      |	   from (select j.* ,
      |                   (case when (lag (providerid) OVER (partition by patientid order by startdate asc nulls last,providerid) = providerid)   THEN null
      |                    else providerid
      |                    end) changed_ind
      |	           from (select p.*
      |       ,row_number() over (partition by patientid order by startdate desc nulls last) as rank_startdate
      |from (select
      |          distinct '{groupid}' 		as groupid
      |          ,'acct' 				          as datasrc
      |	         ,{client_ds_id} 		      as client_ds_id
      |	         ,'PCP' 				          as localrelshipcode
      |	         ,ncn.Pat_Person_Num 	    as patientid
      |	         ,acct.Acct_Primary_Prov  as providerid
      |	         ,acct.Lu_Date 			      as startdate
      |          ,concat_ws('', date_format(current_date,'yyyy'), '1231') as endofyear
      |	      from ACCT acct
      |       inner join ENCNTR ncn on (acct.acct_num = ncn.prim_acct_num)
      |where acct_primary_prov <>'0' ) p
      |   ) j
      |where patientid is not null
      |and providerid is not null
      |) x where changed_ind is not  null)
      |)
      |where patientid is not null and providerid is not null and startdate is not null and incl_rows = 'y'
    """.stripMargin

  override protected def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val provPatException = if (loaderVars.groupId == "H984216" ) {"EXCEPTION"} else {"UNDEFINED"}
    sparkSql.replace("{prov_pat_exception}", provPatException)
      .replace("{groupid}", loaderVars.groupId)
      .replace("{client_ds_id}", loaderVars.clientDsId.toString)
  }
}
package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE1 extends FEQueryAndMetadata[proceduredo]{

override def name: String = "PROCEDURE1"

override def dependsOn: Set[String] = Set("PROCEDURES", "ZH_PROVIDERS")

override def sparkSql: String =
  """
    |SELECT  groupid
    |       ,datasrc
    |       ,facilityid
    |       ,encounterid
    |       ,patientid
    |       ,sourceid
    |       ,performingproviderid
    |       ,referproviderid
    |       ,proceduredate
    |       ,localcode
    |       ,localname
    |       ,codetype
    |       ,procseq
    |       ,case when codetype in ('CPT4','HCPCS','ICD9') then substr(localcode,1,5) else null end as mappedcode
    |       ,orderingproviderid
    |       ,{client_ds_id} as client_ds_id
    |FROM
    |(
    |	SELECT  DISTINCT '{groupid}'                                                                                                                         AS groupid
    |	       ,'procedures'                                                                                                                                 AS datasrc
    |	       ,NULL                                                                                                                                         AS facilityid
    |	       ,p.imreenc_code                                                                                                                               AS encounterid
    |	       ,p.imredemec_code                                                                                                                             AS patientid
    |	       ,null                                                                                                                                         AS sourceid
    |	       ,CASE WHEN prv1.imreprov_code is not null THEN p.proc_completionprovcode ELSE null END                                                        AS performingproviderid
    |	       ,NULL                                                                                                                                         AS referproviderid
    |	       ,coalesce(p.proc_completiondate,p.proc_collecteddate)                                                                                         AS proceduredate
    |	       ,p.proc_code                                                                                                                                  AS localcode
    |	       ,p.proc_title                                                                                                                                 AS localname
    |	       ,CASE WHEN rlike(p.proc_code,'^[0-9]{4}[0-9A-Z]$') THEN 'CPT4'
    |	             WHEN rlike(p.proc_code,'^[A-Z]{1,1}[0-9]{4}$') THEN 'HCPCS'
    |	             WHEN rlike(p.proc_code,'^[0-9]{2,2}\\.[0-9]{1,2}$') THEN 'ICD9' ELSE p.proc_source END                                                  AS codetype
    |	       ,NULL                                                                                                                                         AS procseq
    |	       ,coalesce(null,CASE WHEN prv3.imreprov_code is not null THEN p.proc_contactprovcode else null end)                                            AS orderingproviderid
    |	       ,row_number() OVER (PARTITION BY p.imredemec_code,p.imreenc_code,p.proc_completiondate,p.proc_code ORDER BY p.tag_systemdate DESC nulls last) AS rownumber
    |	FROM PROCEDURES p
    |	LEFT OUTER JOIN
    |	(
    |		SELECT  *
    |		FROM ZH_PROVIDERS
    |	) prv1
    |	ON (p.proc_completionprovcode = prv1.imreprov_code)
    |	LEFT OUTER JOIN
    |	(
    |		SELECT  *
    |		FROM ZH_PROVIDERS
    |	) prv3
    |	ON (p.proc_contactprovcode = prv3.imreprov_code)
    |	WHERE p.proc_completionstatus = 3
    |	AND p.tag_systemdate > TO_DATE('20050101','yyyyMMdd')
    |)
    |WHERE rownumber=1
    |AND patientid is not null
  """.stripMargin
}

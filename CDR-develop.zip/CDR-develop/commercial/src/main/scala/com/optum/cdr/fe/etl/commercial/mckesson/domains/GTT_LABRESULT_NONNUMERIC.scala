package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.cdr.fe.etl.commercial.mckesson_gtt_labresult_nonnumeric
import org.apache.spark.storage.StorageLevel

object GTT_LABRESULT_NONNUMERIC extends FEQueryAndMetadata[mckesson_gtt_labresult_nonnumeric]{
  override def name: String = "GTT_LABRESULT_NONNUMERIC"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE_1","LABRESULT_CACHE_2")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, datecollected, LABORDEREDDATE, dateavailable, encounterid, laborderid, localname, normalrange, localtestname, localunits, LABRESULT_DATE, localresult_numeric, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then
      |       length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25
      |from
      |(
      |LABRESULT_CACHE_1
      |)
      |where res_row = 1 AND localresult_numeric IS NULL AND labresultid IS NOT NULL
      |
      |union all
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, datecollected, LABORDEREDDATE, dateavailable, encounterid, laborderid, localname, normalrange, localtestname, localunits, LABRESULT_DATE, localresult_numeric, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then
      |       length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25
      |from
      |(
      |LABRESULT_CACHE_2
      |)
      |where res_row = 1 AND localresult_numeric IS NULL AND labresultid IS NOT NULL
    """.stripMargin


}

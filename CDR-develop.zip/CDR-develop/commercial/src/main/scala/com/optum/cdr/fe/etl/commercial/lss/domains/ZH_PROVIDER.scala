package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object ZH_PROVIDER extends FEQueryAndMetadata[zh_provider]{

  override def name: String = CDRFEParquetNames.zh_provider

  override def dependsOn: Set[String] = Set("LSS_DPBRPROVIDER")

  override def sparkSql: String =
    """
      |SELECT datasrc
      |       ,localproviderid
      |       ,firstname AS first_name
      |       ,lastname  AS last_name
      |       ,credentials
      |FROM
      |(
      |	SELECT  x.*
      |	       ,row_number() over (partition by localproviderid ORDER BY RowUpdateDateTime desc nulls first,length(Name) desc nulls first ) AS rownumber
      |	FROM
      |	(
      |		SELECT 'dpbrprovider'                                                                         AS datasrc
      |		       ,nullif(concat_ws('', dpb.Sourceid, dpb.Providerid), '')                                   AS localproviderid
      |		       ,dpb.Title                                                                              AS credentials
      |		       ,nullif(regexp_substr(dpb.name,'[A-Za-z]+',instr(replace(name,',',','),',')+1,1),'') AS firstname
      |		       ,nullif(substr(dpb.name,1,instr(dpb.name,',')-1),'')                                    AS lastname
      |		       ,dpb.RowUpdateDateTime
      |		       ,dpb.name
      |		FROM LSS_DPBRPROVIDER dpb
      |	) x
      | WHERE x.localproviderid is not null
      |)
      |WHERE rownumber = 1
    """.stripMargin
}

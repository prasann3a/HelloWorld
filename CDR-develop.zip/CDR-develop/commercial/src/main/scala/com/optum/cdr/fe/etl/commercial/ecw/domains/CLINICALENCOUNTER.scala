package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{clinicalencounter, map_predicate_values, patient}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object CLINICALENCOUNTER extends FETableInfo[clinicalencounter]{

  override def name: String = CDRFEParquetNames.clinicalencounter

  override def dependsOn: Set[String] = Set("ENC", "EDI_INVOICE", "MAP_PREDICATE_VALUES", CDRFEParquetNames.patient)

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    loadedDependencies("ENC").as[enc].createOrReplaceTempView("ENC")
    loadedDependencies("EDI_INVOICE").as[edi_invoice].createOrReplaceTempView("EDI_INVOICE")
    loadedDependencies(CDRFEParquetNames.patient).as[patient].createOrReplaceTempView("PATIENT")

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val encStsCd = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ENCOUNTERS", "CLINICALENCOUNTER",
      "ENC", "STATUS").mkString(",")
    val visitstscodeidMpvList = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ENCOUNTERS", "CLINICALENCOUNTER",
      "ENC", "VISITSTSCODEID").mkString(",")

    val encDatasrcDf = sparkSession.sql(
      """
        |WITH enct AS (
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  m.*
        |			,ROW_NUMBER() OVER (PARTITION BY encounterid ORDER BY modifieddate DESC nulls last) rn
        |		FROM ENC m
        |	)
        |	WHERE rn = 1
        |	AND deleteflag <> '1'
        |	AND (status not in ('CANC',{enc_sts_cd}) OR status is null)
        |),
        |
        |inv AS (
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  e.*
        |			,ROW_NUMBER() OVER (PARTITION BY encounterid ORDER BY modifydate DESC nulls last) rn
        |		FROM EDI_INVOICE e
        |	)
        |	WHERE rn = 1
        |	AND deleteflag <> '1'
        |)
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,arrivaltime
        |       ,encounterid
        |       ,patientid
        |       ,facilityid
        |       ,localpatienttype
        |       ,totalcharge
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                               AS groupid
        |	       ,'enc'                                                                                     AS datasrc
        |	       ,{client_ds_id}                                                                            AS client_ds_id
        |	       ,safe_to_date_length(
        |             nullif(
        |                 concat_ws('',date_format(enct.Enc_Date,'yyyy-MM-dd')
        |                             ,CASE WHEN enct.Arrivedtime <> '00:00:00' THEN enct.arrivedtime WHEN enct.Timein <> '00:00:00' THEN enct.timein WHEN enct.Starttime is not null THEN enct.Starttime ELSE '00:00:00' END)
        |                 ,'')
        |             ,'yyyy-MM-ddHH:mm:ss'
        |             ,0) AS arrivaltime
        |	       ,enct.Encounterid                                                                          AS encounterid
        |	       ,enct.Patientid                                                                            AS patientid
        |	       ,CASE WHEN enct.Facilityid = '0' THEN NULL ELSE enct.Facilityid END                        AS facilityid
        |	       ,CASE WHEN Visittypeid = '0' AND Visittype Is Not Null THEN concat_ws('','{client_ds_id}','.',Enct.Visittype)
        |	             WHEN Visittypeid = '0' AND Visittype Is Null THEN Null
        |	             WHEN Visittypeid <> '0' THEN concat_ws('','{client_ds_id}','.',Enct.Visittypeid) END AS Localpatienttype
        |	       ,inv.Invoiceamount                                                                         AS t
        |	       ,inv.Invoiceamount                                                                         AS totalcharge
        |	       ,enct.deleteflag
        |	FROM ENCT
        |	JOIN {PATIENT} p ON (enct.patientid = p.patientid AND p.client_ds_id = {client_ds_id})
        |	LEFT OUTER JOIN INV ON (enct.EncounterID = inv.EncounterID)
        |	WHERE p.client_ds_id = {client_ds_id}
        |	AND enct.VISITSTSCODEID NOT IN ({visitstscodeidMpvList})
        |)
        |WHERE deleteflag <> '1'
        |AND arrivaltime IS NOT NULL
      """.stripMargin
        .replace("{PATIENT}", CDRFEParquetNames.patient)
        .replace("{enc_sts_cd}", encStsCd)
        .replace("{visitstscodeidMpvList}", visitstscodeidMpvList)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )

    encDatasrcDf.createOrReplaceTempView("encDatasrcDf")

    val ediInvoiceDatasrcDf = sparkSession.sql(
      """
        |WITH enc_ids AS (
        | SELECT encounterid
        | FROM ENC
        | WHERE status IN ('CANC', {enc_sts_cd})
        |)
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,arrivaltime
        |       ,encounterid
        |       ,patientid
        |       ,facilityid
        |       ,localpatienttype
        |       ,null as totalcharge
        |FROM
        |(
        |	SELECT  t.*
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                         AS groupid
        |		       ,'edi_invoice'                                                                       AS datasrc
        |		       ,{client_ds_id}                                                                      AS client_ds_id
        |		       ,ei.servicedt                                                                        AS arrivaltime
        |		       ,ei.encounterid                                                                      AS encounterid
        |		       ,ei.patientid                                                                        AS patientid
        |		       ,ei.invfacilityid                                                                    AS facilityid
        |		       ,concat_ws('','ps.',ei.invpos)                                                       AS localpatienttype
        |		       ,row_number() over (partition by ei.encounterid ORDER BY modifydate desc nulls last) AS rownumber
        |		FROM EDI_INVOICE ei
        |		LEFT OUTER JOIN encDatasrcDf c
        |		ON (c.client_ds_id = {client_ds_id} AND c.encounterid = ei.encounterid)
        |		WHERE ei.patientid is not null
        |		AND ei.encounterid is not null
        |   AND NOT EXISTS (SELECT 1 FROM enc_ids WHERE enc_ids.encounterid = ei.encounterid)
        |		AND ei.servicedt is not null
        |		AND ei.deleteflag <> '1'
        |		AND c.groupid is null
        |	) t
        |	WHERE t.rownumber = 1
        |)
        |WHERE '{groupid}' <> 'H458934'
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{enc_sts_cd}", encStsCd)
    )

    encDatasrcDf union ediInvoiceDatasrcDf
  }
}

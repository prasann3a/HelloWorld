package com.optum.cdr.fe.etl.commercial.huamana.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_member
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_MEMBER extends FETableInfo[int_claim_member] {
  override def name:String=CDRFEParquetNames.int_claim_member

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {

    import sparkSession.implicits._

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString

    sparkSession.sql(
      """
        |with dr as (
        |select
        |a.*,row_number() over (partition by mbr_pid order by enrol_date asc nulls last) as rank
        |from (
        |select distinct mbr_pid,enrol_date
        |from REMBX
        |)a
        |)
        |, dr1 as
        |(
        |select
        |s.mbr_pid,s.enrol_date,e.enrol_date as end_date
        |from DR s
        |left outer join DR e on s.mbr_pid = e.mbr_pid and s.rank+1 = e.rank
        |)
        |
        |select groupid, datasrc, client_ds_id, CONTRACT_ID, member_eff_date, financial_class, member_gender_code, MEDICAL_BENEFIT_FLAG, member_dob, member_fname, member_id, member_lname, payer_code, payer_name, plan_code, plan_name, ALTERNATE_MEMBER_ID, COVERAGE_STATUS_CODE, MEMBER_DEATH_IND, DENTAL_BENEFIT_IND, MEMBER_END_DATE, HICN, MEMBER_LANGUAGE, member_addr_1, member_addr_2, member_city, member_dod, member_phone, member_state_code, member_zip_code, pcp_id, pcp_name, pcp_npi, pcp_start_date, product_code, PRODUCT_NAME, SOURCE_CODE, subscriber_flag, subscriber_id
        |from
        |(
        |select
        | '{groupid}'		        as groupid
        |,'REMBX' 			as datasrc
        |,{client_ds_id}         	        as client_ds_id
        |,bme.employeraccountid 		as CONTRACT_ID
        |,mem.enrol_date   as MEMBER_EFF_DATE
        |,bme.employeraccountid     as FINANCIAL_CLASS
        |,mem.Mbr_Sex      as MEMBER_GENDER_CODE
        |,'Y'              as MEDICAL_BENEFIT_FLAG
        |,mem.Mbr_Bth      as MEMBER_DOB
        |,nullif(trim(nullif(substr(mem.mbr_nm, instr(mem.mbr_nm, ',') +1, instr_3params(concat_ws('', substr(mem.mbr_nm, instr(mem.mbr_nm, ',') +2), ' '), ' ', 1)), '')), '')  as MEMBER_FNAME
        |,mem.mbr_pid       as MEMBER_ID
        |,nullif(substr(mem.mbr_nm,1,instr(mem.mbr_nm,',')-1), '')  as MEMBER_LNAME
        |,bme.employeraccountid 		as payer_code
        |,bme.employeraccountid 		as payer_name
        |,coalesce(mem.Pbp_Id,bme.Employeraccountid)     as PLAN_CODE
        |,coalesce(mem.Pbp_Name,bme.Employeraccountid)   as PLAN_NAME
        |,mem.Mbr_Pid               as ALTERNATE_MEMBER_ID
        |,mem.Mbr_Rel_Cd            as COVERAGE_STATUS_CODE
        |,case when mem.Decea_Dt is not null then 'Y'
        |else 'N'               end as MEMBER_DEATH_IND
        |,case
        |when mem.Dntl_Plani = 'Y' then 1
        |when mem.Dntl_Plani = 'N' then 0 end as DENTAL_BENEFIT_IND
        |,case when end_date is not null then end_date - INTERVAL '1' SECOND else last_day(rpt_pe) end as MEMBER_END_DATE
        |,mem.Mcare_Id                           as HICN
        |,coalesce(mem.Verb_Lang,mem.Writ_Lan)   as MEMBER_LANGUAGE
        |,mem.Mbr_Addr1                          as MEMBER_ADDR_1
        |,mem.Mbr_Addr2                          as MEMBER_ADDR_2
        |,mem.Mbr_City                           as MEMBER_CITY
        |,safe_to_date(mem.Decea_Dt,'yyyyMMdd')  as MEMBER_DOD
        |,mem.Mbr_Phone                          as MEMBER_PHONE
        |,mem.Mbr_State                          as MEMBER_STATE_CODE
        |,mem.Mbr_Zip                            as MEMBER_ZIP_CODE
        |,case when mem.Gk_Serv_Ty = 'PCP'
        |then coalesce(mem.Npi,mem.Gk_Ctrct) else null end as PCP_ID
        |,case when mem.Gk_Serv_Ty = 'PCP'
        |then mem.Center_Nm else null end    as PCP_NAME
        |,case when mem.Gk_Serv_Ty = 'PCP'
        |then mem.Npi else null end          as PCP_NPI
        |,case when mem.Gk_Serv_Ty = 'PCP'
        |then mem.Mbr_Gk_Bd else null end    as PCP_START_DATE
        |,mem.Prod_Lob               as PRODUCT_CODE
        |,mem.Prod_Lob               as PRODUCT_NAME
        |,bme.employeraccountid 		as SOURCE_CODE
        |,case when mem.Mbr_Rel_Cd='01' then 'Y' else 'N' end as SUBSCRIBER_FLAG
        |,case when mem.Mbr_Rel_Cd='01' then mem.mbr_pid else  null end  as SUBSCRIBER_ID
        |,row_number() over (partition by mem.mbr_pid,mem.Enrol_Date,coalesce(mem.Npi,mem.Gk_Ctrct) order by mem.Enrol_Date,mem.Rpt_Pe desc nulls last ) as RN
        |from REMBX mem
        |left outer join DR1 on mem.mbr_pid = dr1.mbr_pid and mem.enrol_date = dr1.enrol_date
        |cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
        |where mem.Gk_Adj_Cd is null
        |
        |)
        |where RN=1
      """.stripMargin
        .replace("{groupid}",loaderVars.groupId)
        .replace("{client_ds_id}",clientDsId)
    )


  }

  override def dependsOn: Set[String] = Set("REMBX","ZO_BPO_MAP_EMPLOYER")
}

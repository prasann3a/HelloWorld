package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{immunization, map_predicate_values, patient}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object IMMUNIZATION extends FETableInfo[immunization] {

  override def name: String = CDRFEParquetNames.immunization

  override def dependsOn: Set[String] = Set("IMMUNIZATIONS", "ENC", "PATIENT", "ZH_ITEMS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    loadedDependencies("IMMUNIZATIONS").as[immunizations].createOrReplaceTempView("IMMUNIZATIONS")
    loadedDependencies("ENC").as[enc].createOrReplaceTempView("ENC")
    loadedDependencies("ZH_ITEMS").as[zh_items].createOrReplaceTempView("ZH_ITEMS")
    loadedDependencies("PATIENT").as[patient].createOrReplaceTempView("PATIENT")

    val predicate_values = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val column_valueDf = mpvList(predicate_values, runtimeVar.groupId, runtimeVar.clientDsId.toString, "IMMUNIZATIONS", "IMMUNIZATION", "ZH_ITEMS"
      , "PARENTID").mkString(",")

    sparkSession.sql(
      """
    WITH dedup_immu AS
    (SELECT * FROM (
      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY immunizationid ORDER BY modifieddate DESC NULLS LAST) rn
      FROM IMMUNIZATIONS i
      WHERE DELETEFLAG <> '1')
    WHERE rn = 1)
    ,dedup_enc AS
      (SELECT * FROM
      (SELECT b.*, ROW_NUMBER() OVER (PARTITION BY b.Encounterid
        ORDER BY b.ModifiedDate DESC NULLS LAST, b.fileid DESC NULLS LAST) rn
      FROM ENC b)
    WHERE rn = 1)
    select groupid, datasrc, client_ds_id, localimmunizationcd, patientid, admindate, documenteddate, encounterid, localimmunizationdesc, localpatreportedflg, localroute
    from
    (
      SELECT distinct '{groupid}' as groupid
    ,'immunizations' as datasrc
    ,{client_ds_id} as client_ds_id
    ,case when dedup_immu.Itemid in ('0', '-1') then null else dedup_immu.Itemid end AS localimmunizationcd
    ,dedup_immu.Patientid  AS patientid
    ,coalesce(enc.enc_date, dedup_immu.Modifieddate)  AS documenteddate
    ,dedup_immu.Encounterid  AS encounterid
    ,zh_items.itemname AS localimmunizationdesc
    ,dedup_immu.Historyflag  AS localpatreportedflg
    ,dedup_immu.Route  AS localroute
    ,case when lower(zh_items.itemname) like '%refused%' Then null else safe_to_date(nullif(concat_ws('', date_format(dedup_immu.Givendate, 'MM/dd/yyyy'), coalesce(dedup_immu.Giventime, '00:00:00')), ''),
    'MM/dd/yyyyHH:mm:ss') end AS admindate
    FROM DEDUP_IMMU
      JOIN PATIENT c ON (dedup_immu.patientid = c.patientid AND
      c.client_ds_id = {client_ds_id})
    LEFT OUTER JOIN DEDUP_ENC enc ON (enc.encounterid = dedup_immu.encounterid)
    INNER JOIN ZH_ITEMS ON (dedup_immu.ItemID = zh_items.itemid AND zh_items.parentid in ({column_valueDf}))

    )

  """.stripMargin
        .replace("{column_valueDf}", column_valueDf)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )

  }

}












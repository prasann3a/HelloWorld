package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_RXADMIN extends FETableInfo[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_RXADMIN"

  override def dependsOn: Set[String] = Set("CCDBA_MED_ORDER","ZH_CCDEV_DRUG","MCKESSON_ENT_PATIENT","ZH_DRUG1_FDB_PACKAGEDDRUG","CCDBA_MED_ADMIN","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val excl_id = mpvList(mapPredicateValues, groupId, clientDsId, "CCDBA_MED_ORDER", "MEDS", "CCDBA_MED_ORDER", "DRUG_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
      WITH uni_order AS
        (SELECT * FROM (
            SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY chart_ddt DESC NULLS LAST) rn
            FROM CCDBA_MED_ORDER i)
        WHERE rn = 1),
        uni_drug AS
        (SELECT * FROM (
            SELECT i.*, ROW_NUMBER() OVER (PARTITION BY drug_id ORDER BY change_dt DESC NULLS LAST) rn
            FROM ZH_CCDEV_DRUG i)
        WHERE rn = 1),
        uni_pat AS
        (SELECT * FROM (
        (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
            FROM MCKESSON_ENT_PATIENT p
            WHERE cpi_seq IS NOT NULL )
        ) WHERE rn = 1)
        select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs
        from
        (
        SELECT '{groupid}' AS groupid
                ,'ccdba_med_admin' AS datasrc
            ,{client_ds_id} AS client_ds_id
                ,SUM(CASE WHEN localndc IS NULL THEN 1 ELSE 0 END) AS no_ndc
                ,SUM(CASE WHEN localndc IS NULL THEN 0 ELSE 1 END) AS has_ndc
                ,COUNT(*) AS num_recs
                ,localmedcode, localndc, localdescription
        FROM (SELECT CASE WHEN admin.Drug_id IN ({excl_id}) THEN LOWER(uni_order.drug_name) ELSE admin.drug_id END AS localmedcode
                    ,normalize_NDC(CASE WHEN admin.Drug_id IN ({excl_id}) THEN NULL ELSE zh.Pmid END) AS localndc
                    ,CASE WHEN admin.Drug_id IN ({excl_id}) THEN LOWER(uni_order.drug_name) ELSE LOWER(COALESCE(uni_drug.sec_name, uni_order.drug_name)) END AS localdescription
            FROM CCDBA_MED_ADMIN admin
            JOIN UNI_PAT ON (admin.pat_seq = uni_pat.pat_seq)
            LEFT OUTER JOIN UNI_DRUG ON (admin.drug_id = uni_drug.drug_id)
            LEFT OUTER JOIN UNI_ORDER ON (admin.order_seq = uni_order.order_seq AND admin.drug_id = uni_order.drug_id)
            LEFT OUTER JOIN ZH_DRUG1_FDB_PACKAGEDDRUG zh ON (uni_order.drug_id = zh.pmid)
            WHERE (admin.dose_units <> 'INFO' OR admin.dose_units IS NULL))
        GROUP BY localmedcode, localndc, localdescription
        )
        """.replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId)
        .replace("{excl_id}", excl_id))
  }
}

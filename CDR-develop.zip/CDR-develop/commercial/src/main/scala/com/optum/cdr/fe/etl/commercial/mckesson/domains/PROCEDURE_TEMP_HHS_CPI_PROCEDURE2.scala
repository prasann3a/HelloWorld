package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.proceduredo
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object PROCEDURE_TEMP_HHS_CPI_PROCEDURE2 extends FETableInfo[proceduredo]{
  override def name: String = "PROCEDURE_TEMP_HHS_CPI_PROCEDURE2"

  override def dependsOn: Set[String] = Set("MCKESSON_HHS_CPI_PROCEDURE","MAP_CUSTOM_PROC","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val incl_proc = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "HHS_CPI_PROCEDURE", "PROCEDURE", "HHS_CPI_PROCEDURE", "PROCEDURE_REPORTED_BY_LSEQ").mkString(",")


    sparkSession.sql(
      s"""
         |WITH uni_proc AS
         |(SELECT * FROM
         |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY cpi_procedure_seq ORDER BY modified_dt DESC NULLS LAST) rn,
         |	CASE WHEN LOWER(description) LIKE '%mammogra%' THEN 'MAMMO'
         |	     WHEN LOWER(description) LIKE '%colonosco%' THEN 'COLONOSCOPY'
         |	     WHEN LOWER(description) LIKE '%sigmoid%' THEN 'SIGMOID'
         |             ELSE concat_ws('', '{client_ds_id}', '.', COALESCE(code, description)) END  AS localcode
         |  FROM MCKESSON_HHS_CPI_PROCEDURE p
         | WHERE coding_system IS NOT NULL
         |   AND procedure_reported_by_lseq IN ({incl_proc})
         |  )
         | WHERE rn = 1)
         |select datasrc, concat_ws('','{client_ds_id}','.',localcode) as localcode, encounterid, patientid, proceduredate, localname, codetype, mappedcode, actualprocdate, facilityid, hosp_px_flag
         |from
         |(
         |SELECT 'hhs_cpi_procedure' AS datasrc
         |	,uni_proc.localcode  AS localcode
         |	,uni_proc.cpi_seq  	AS patientid
         |	,COALESCE(uni_proc.performed_dt, uni_proc.created_dt)  AS proceduredate
         |	,uni_proc.Performed_Dt  AS actualprocdate
         |	,uni_proc.pat_seq  	AS encounterid
         |	,NULL			AS facilityid
         |	,uni_proc.Description   AS localname
         |	,map.Mappedvalue 	AS mappedcode
         |	,'CUSTOM'  		AS codetype
         |	,'Y'            	AS hosp_px_flag
         |	,ROW_NUMBER() OVER (PARTITION BY uni_proc.cpi_seq, uni_proc.pat_seq, COALESCE(uni_proc.performed_dt, uni_proc.created_dt), uni_proc.localcode
         |	                       ORDER BY uni_proc.modified_dt DESC NULLS LAST) rn
         |FROM UNI_PROC
         |   JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
         |                            map.datasrc = 'hhs_cpi_procedure' AND
         |   			    map.localcode = uni_proc.localcode)
         |
         |)
         |where proceduredate IS NOT NULL
         |and rn = 1
       """.stripMargin.replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId).replace("{incl_proc}",incl_proc))
  }
}

package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.cdr.fe.etl.commercial.med3000_gtt_labresult_nonnumeric

import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object LABRESULT_CACHE extends FEQueryAndMetadata[med3000_gtt_labresult_nonnumeric] {

  override def name: String = "TEMP_LABRESULT_CACHE"

  override def dependsOn: Set[String] = Set("MED3000_LAB_RESULT","MED3000_ORDERED_TEST","MED3000_PATIENT_HM","ZCM_OBSTYPE_CODE","MED3000_PATIENT_VITALS","MED3000_PATIENT_VITAL_SIGNS","MED3000_ZH_VITALS_MASTER")

  override def sparkSql: String =
    """
      select v.*
 |       ,safe_to_number(localresult) as localresult_numeric
 |       ,safe_to_number(localresult) as localresult_inferred
 |
 |  from (
 | Select groupid,
 |        datasrc,
 |        client_ds_id,
 |        labresultid,
 |        localcode,
 |        localresult,
 |        patientid,
 |        datecollected,
 |		    labordereddate,
 |        dateavailable,
 |        labresult_date,
 |  		  laborderid,
 |        localname,
 |        localspecimentype,
 |		    localtestname,
 |        localunits,
 |        normalrange
 |  from (
 |SELECT
 |       '{groupid}' 		   	as  groupid
 |       ,'lab_result' 		  as  datasrc
 |       ,{client_ds_id} 		as  client_ds_id
 |       ,lab.Icchart_Component_Number  	as  labresultid
 |       ,lab.Resulted_Test_Id  			as  localcode
 |       ,lab.Result_Value  				as  localresult
 |       ,lab.Blind_Key  					as  patientid
 |       ,ord.Specimen_Rcvd_Date_Time     as  datecollected
 |       ,safe_to_date(ord.Obs_Date_Time, 'yyyy-MM-dd')  as labordereddate
 |       ,safe_to_date(CAST(lab.Obs_Date_Time AS TIMESTAMP), 'yyyy-MM-dd')  as dateavailable
 |       ,safe_to_date(CAST(lab.Obs_Date_Time AS TIMESTAMP), 'yyyy-MM-dd')  as labresult_date
 |       ,lab.Icchart_Order_Number  		as  laborderid
 |       ,lab.Resulted_Test_Desc  		as  localname
 |       ,ord.Specimen_Source  			as  localspecimentype
 |       ,ord.Ordered_Test_Desc  			as  localtestname
 |       ,lab.Units  						as  localunits
 |       ,lab.Reference_Range  			as  normalrange
 |       ,row_number() over (partition by lab.Icchart_Component_Number order by lab.Update_Date desc nulls last) as rank_labresult
 |  from MED3000_LAB_RESULT lab
 |  left join MED3000_ORDERED_TEST ord on (ord.ICChart_Order_Number = lab.ICChart_Order_Number
 |   and ord.ICChart_Test_Number = lab.ICChart_Test_Number)
 | where lab.Obs_Date_Time is not null and lab.Blind_Key is  not null and lab.Icchart_Component_Number  is not null)
 | where rank_labresult =1
 |
 |       ) v
 |

    """.stripMargin
}

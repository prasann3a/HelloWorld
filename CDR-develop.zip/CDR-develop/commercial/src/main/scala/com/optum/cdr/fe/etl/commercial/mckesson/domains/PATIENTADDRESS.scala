package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.patientaddr

object PATIENTADDRESS extends FEQueryAndMetadata[patientaddr] {
  override def name: String = CDRFEParquetNames.patientaddr

  override def dependsOn: Set[String] = Set("ENT_CPI_ADDRESS", "ZH_ENT_CONFIG_LOV")

  override def sparkSql: String =
    """
      |select datasrc, address_date, patientid, state, zipcode, address_line1, address_line2, city, address_type
      |from
      |(
      |SELECT 'ent_cpi_contact' AS datasrc
      |	,a.Modified_Dt   AS address_date
      |	,a.cpi_seq       AS patientid
      |	,nullif(regexp_replace(a.state,'[^a-zA-Z]', ''), '') AS state
      |	,standardizePostalCode(a.postal_code) AS zipcode
      |	,a.address_line_1  AS address_line1
      |	,a.address_line_2  AS address_line2
      |	,a.city  	AS city
      |	,z.lov_value    AS address_type
      |FROM ENT_CPI_ADDRESS a
      |     LEFT OUTER JOIN ZH_ENT_CONFIG_LOV z on a.address_type_lseq = z.lov_seq
      |WHERE a.cpi_seq IS NOT NULL
      |AND   a.Modified_Dt IS NOT NULL
      |AND (LENGTH(nullif(regexp_replace(a.state,'[^a-zA-Z]', ''), '')) = 2 OR a.state IS NULL)
      |AND   COALESCE(a.address_line_1,a.address_line_2,a.city,a.state,a.postal_code) IS NOT NULL
      |
      |)
      |""".stripMargin

}

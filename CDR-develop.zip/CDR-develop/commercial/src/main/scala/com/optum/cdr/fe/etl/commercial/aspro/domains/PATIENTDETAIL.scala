package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.patientdetail
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTDETAIL extends FEQueryAndMetadata[patientdetail]{

  override def name: String = CDRFEParquetNames.patientdetail

  override def dependsOn: Set[String] = Set("PATIENT_CACHE")

  override def sparkSql: String =
    """
      |select null as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'FIRST_NAME' as patientdetailtype, firstname as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where first_row = 1  and firstname is not null
      |
      |union all
      |
      |select null as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'LAST_NAME' as patientdetailtype, lastname as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where last_row = 1  and lastname is not null
      |
      |union all
      |
      |select null as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'CITY' as patientdetailtype, city as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where city_row = 1  and city is not null
      |
      |union all
      |
      |select null as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'STATE' as patientdetailtype, state as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where state_row = 1  and state is not null
      |
      |union all
      |
      |select null as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'ZIPCODE' as patientdetailtype, std_zip as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where zip_row = 1  and std_zip is not null
      |
      |union all
      |
      |select null as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'GENDER' as patientdetailtype, gender as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where gender_row = 1  and gender is not null
      |
      |union all
      |
      |select null as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'RACE' as patientdetailtype, race as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where race_row = 1  and race is not null
      |
      |union all
      |
      |select null as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'ETHNICITY' as patientdetailtype, ethnicity as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where ethnic_row = 1  and ethnicity is not null
      |
      |union all
      |
      |select null as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'DECEASED' as patientdetailtype, pat_status as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where status_row = 1  and pat_status is not null
      |
      |union all
      |
      |select NULL as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'LANGUAGE' as patientdetailtype, language as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where language_row = 1 and language is not null
      |
      |union all
      |
      |select NULL as facilityid, '{groupid}' as groupid, 'patient' as datasrc, encounterid, patientid, updatedate as PATDETAIL_TIMESTAMP, 'MARITAL' as patientdetailtype, marital as localvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where marital_row = 1 and marital is not null
    """.stripMargin
}

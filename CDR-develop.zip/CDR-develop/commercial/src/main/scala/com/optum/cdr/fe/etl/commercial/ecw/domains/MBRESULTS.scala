package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.mbresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object MBRESULTS extends FEQueryAndMetadata[mbresult]{

  override def name: String = CDRFEParquetNames.mbresult

  override def dependsOn: Set[String] = Set("LABDATADETAIL","LABDATA", "ENC", "ZH_ITEMS","MAP_PREDICATE_VALUES")

  override def sparkSql: String =
    """
      |WITH DEDUPED_MICRO_ORGANISMS AS
      |        (
      |         SELECT  HUM_VALUE, PROPID, REPORTID
      |         FROM (
      |                SELECT
      |                HUM_VALUE, PROPID, REPORTID, ROW_NUMBER() OVER (PARTITION BY REPORTID, PROPID ORDER BY to_date(UPDATEDTIME, 'yyyy-MM-dd HH:mm:ss') DESC nulls first, FILEID DESC nulls first, ID DESC nulls first) AS RN
      |                FROM LABDATADETAIL
      |                )
      |         WHERE RN = '1'
      |         )
      |,DEDUPED_MICRO_ORDERS AS
      |           (
      |            SELECT
      |            ENCOUNTERID, REPORTID, ITEMID, RESULT, COLLDATE, COLLTIME, RESULTDATE, RESULTIME, COLLSOURCE, COLLDESCRIPTION, RESULTSTATUS, MODIFIEDDATE
      |            FROM   (
      |                    SELECT   A.*, ROW_NUMBER() OVER (PARTITION BY REPORTID, ITEMID, ENCOUNTERID ORDER BY to_date(MODIFIEDDATE, 'yyyy-MM-dd HH:mm:ss') DESC nulls first, FILEID DESC nulls first) AS RN
      |                    FROM LABDATA A
      |                    )
      |            WHERE RN = '1'
      |                  AND (DELETEFLAG <> '1'  or DELETEFLAG is null)
      |                  AND (CANCELLED <> '1' or CANCELLED is null)
      |                  AND RECEIVED = '1'
      |            )
      |,DEDUPED_ENCOUNTER AS
      |        (
      |        SELECT  ENCOUNTERID, FACILITYID, PATIENTID
      |        FROM    (
      |                SELECT ENCOUNTERID, FACILITYID, PATIENTID, ROW_NUMBER() OVER (PARTITION BY ENCOUNTERID ORDER BY to_date(MODIFIEDDATE, 'yyyy-MM-dd HH:mm:ss') DESC nulls first, FILEID DESC nulls first) AS RN
      |                FROM ENC A
      |                )
      |        WHERE RN = '1'
      |        )
      |,DEDUPED_DICT AS
      |        (
      |        SELECT  ITEMID, ITEMNAME
      |        FROM    (
      |                SELECT ITEMID, ITEMNAME, ROW_NUMBER() OVER (PARTITION BY ITEMID ORDER BY to_date(MODIFIEDDATE, 'yyyy-MM-dd HH:mm:ss') DESC nulls first, FILEID DESC nulls first) AS RN
      |                FROM ZH_ITEMS
      |                WHERE UPPER(ITEMNAME) IN (select column_value
      |                                     from MAP_PREDICATE_VALUES
      |                                     where groupid = '{groupid}'
      |                                           and client_ds_id = {client_ds_id}
      |                                           and entity = 'MBRESULT'
      |                                           and data_src = 'ZH_ITEMS'
      |                                           and table_name = 'ZH_ITEMS'
      |                                           and column_name = 'ITEMNAME_RESULT')
      |                )
      |        WHERE RN = '1'
      |        )
      |
      |select groupid, datasrc, client_ds_id, dateavailable, encounterid, facilityid, localorganismname, localresulstatus, mbprocorderid, mbprocresultid, patientid, mbresult_date
      |from
      |(
      |SELECT A.*, DATEAVAILABLE AS MBRESULT_DATE
      |FROM   (
      |        SELECT
      |                '{groupid}'                                        AS GROUPID,
      |                'labdatadetail'                                 AS DATASRC,
      |                {client_ds_id}                                   AS CLIENT_DS_ID,
      |                ENC.PATIENTID                                   AS PATIENTID,
      |                ENC.ENCOUNTERID                                 AS ENCOUNTERID,
      |                ORD.REPORTID                                    AS MBPROCORDERID,
      |                concat_ws('', ORG.REPORTID, '-', ORG.PROPID)                   AS MBPROCRESULTID,
      |                ENC.FACILITYID                                  AS FACILITYID,
      |                CASE WHEN ORD.resultdate IS NOT NULL THEN safe_to_date(nullif(concat_ws('', date_format(ORD.resultdate, 'yyyy-MM-dd'), ORD.resultime), ''), 'yyyy-MM-ddHH:mm:ss')
      |                     ELSE ORD.modifieddate END                  AS DATEAVAILABLE,
      |                CASE WHEN UPPER(ORG.HUM_VALUE) = 'COMMENT' THEN UPPER(ORD.RESULT)
      |                     ELSE COALESCE(UPPER(ORG.HUM_VALUE),UPPER(ORD.RESULT)) END              AS LOCALORGANISMNAME,
      |                ORD.RESULTSTATUS                                AS LOCALRESULSTATUS
      |        FROM DEDUPED_MICRO_ORGANISMS ORG
      |        INNER JOIN DEDUPED_MICRO_ORDERS ORD ON (ORG.REPORTID = ORD.REPORTID)
      |        INNER JOIN DEDUPED_ENCOUNTER ENC ON (ORD.ENCOUNTERID = ENC.ENCOUNTERID)
      |        INNER JOIN DEDUPED_DICT DICT ON (DICT.ITEMID = ORG.PROPID)
      |        ) a
      |WHERE LOCALORGANISMNAME IS NOT NULL
      |AND PATIENTID IS NOT NULL
      |AND DATEAVAILABLE IS NOT NULL
      |)
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.huamana.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_labresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_LABRESULT extends FETableInfo[int_claim_labresult]{

  override def name:String=CDRFEParquetNames.int_claim_labresult

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString

    sparkSession.sql(
      """
         |select groupid, datasrc, client_ds_id, claim_header_id, collection_date, loinc_code, labresult_id, member_id, result_date, test_order_name, loinc_name, ordering_prov_id, ordering_prov_npi, reference_range, RESULT_CODE, RESULT_NAME, specimen_source, TEST_RESULT_NUMBER, TEST_RESULT_TEXT, TEST_RESULT_UNITS
         |from
         |(
         |select
         | '{groupid}'		          as groupid
         |,'RELAB' 		          as datasrc
         |,{client_ds_id}         	          as client_ds_id
         |,RL.Lab_Result                    as CLAIM_HEADER_ID
         |,coalesce(safe_to_date(nullif(substr(RL.Collec_Dat,0,8), ''),'yyyyMMdd'),RL.Ser_Dte_Ke) as COLLECTION_DATE
         |,RL.Loinc_Code              as LOINC_CODE
         |,RL.Lab_Result 	            as LABRESULT_ID
         |,RB.Mbr_Pid                  as MEMBER_ID
         |,RL.Reciev_Dat              as RESULT_DATE
         |,TD.Long_Common_Name        as TEST_ORDER_NAME
         |,TD.Long_Common_Name        as LOINC_NAME
         |,RL.Ord_Prov_N              as ORDERING_PROV_ID
         |,RL.Ord_Prov_N              as ORDERING_PROV_NPI
         |,RL.Normal_Alp              as REFERENCE_RANGE
         |,RL.Loinc_Code              as RESULT_CODE
         |,TD.Long_Common_Name        as RESULT_NAME
         |,RL.Speci_Sour              as SPECIMEN_SOURCE
         |,nullif(regexp_extract(RL.Lab_Value,'^[0-9]\\d*(\\.\\d+)?$', 0), '')  as TEST_RESULT_NUMBER
         |,case when nullif(regexp_extract(RL.Lab_Value,'^[0-9]\\d*(\\.\\d+)?$', 0), '') is null then RL.Lab_Value else null end as TEST_RESULT_TEXT
         |,RL.Resul_Unit              as TEST_RESULT_UNITS
         |,row_number() over (partition by RL.Lab_Result order by RL.Rpt_Pe desc nulls last, RB.Rpt_Pe desc nulls last ) as RN
         |from RELAB RL
         |inner join REMBX RB on (RL.Mem_Umid = RB.Mem_Umid)
         |left outer join TERMDICTIOINC TD on ( RL.Loinc_Code = TD.Loinc_Num)
         |
         |
         |)
         |where RN=1
       """.stripMargin
        .replace("{groupid}",loaderVars.groupId)
        .replace("{client_ds_id}",clientDsId)
    )

  }

  override def dependsOn: Set[String] = Set("RELAB","REMBX","TERMDICTIOINC")
}

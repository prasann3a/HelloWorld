package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.sparkdataloader.CDRFEParquetNames
import com.optum.oap.cdr.models.patientcontact

object PATIENTCONTACT extends FEQueryAndMetadata[patientcontact]{
  override def name: String = CDRFEParquetNames.patientcontact

  override def dependsOn: Set[String] = Set("ENT_CPI_CONTACT")

  override def sparkSql: String =
    """
      |select datasrc, update_dt, patientid, work_phone, home_phone, cell_phone, personal_email
      |from
      |(
      |SELECT 'ent_patient_contact' AS datasrc
      |      ,Modified_Dt           AS update_dt
      |      ,cpi_seq               AS patientid
      |      ,NULL 		     AS cell_phone
      |      ,phone_number 	     AS home_phone
      |      ,NULL 		     AS work_phone
      |      ,CASE WHEN instr(email_address,'@') > 1 THEN email_address END   AS personal_email
      |      ,ROW_NUMBER() OVER (PARTITION BY cpi_seq, email_address ORDER BY Modified_Dt DESC NULLS LAST) rn
      |FROM ENT_CPI_CONTACT
      |WHERE cpi_seq IS NOT NULL
      |AND Modified_Dt IS NOT NULL
      |
      |)
      |where rn = 1
    """.stripMargin

}

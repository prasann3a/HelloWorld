package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.{map_predicate_values, rx_patient_reported}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENTREPORTEDMEDS extends FETableInfo[rx_patient_reported]{
  override def name: String = CDRFEParquetNames.rx_patient_reported

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TSM261_PSN_HOME_MEDS","MCKESSON_PGN_V1_ZH_TOR750_MED_IV")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val exclStaRsn = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "PSN_HOME_MEDS","RX_PATIENT_REPORTED","PSN_HOME_MEDS","STA_RSN_CD").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |select '{groupid}' as groupid, 'psn_home_meds' as datasrc, patientid, encounterid, discontinuedate, discontinuereason, localdrugdescription, localform, localgpi, localndc, localqtyofdoseunit, localroute, localstrengthperdoseunit, localstrengthunit, reportedmedid, medreportedtime, {client_ds_id} as client_ds_id, localmedcode, localdoseunit, localcategorycode, localtotaldose
        |from
        |(
        |SELECT A.*,
        |       concat_ws('', A.MED_SEQ_NO, '_', date_format(A.MEDREPORTEDTIME,'yyyy-MM-dd')) AS REPORTEDMEDID,
        |       ROW_NUMBER() OVER (PARTITION BY A.MED_SEQ_NO, A.MEDREPORTEDTIME ORDER BY A.LST_MOD_TS DESC NULLS LAST) RN
        |from
        |(
        |select * from
        |(
        |select unpivot_base.*,
        |stack(2,MEDREPORTEDTIME_ORG,'ORIGINAL',MEDREPORTEDTIME_UPD,'UPDATE') as (MEDREPORTEDTIME, DATETYPE)
        |from
        |(SELECT  P.PSN_INT_ID                                    AS PATIENTID
        |               ,P.VST_INT_ID             		        AS ENCOUNTERID
        |               ,P.MED_SEQ_NO
        |               ,COALESCE(P.MED_EFF_TS,P.ENTRY_DATE)             AS MEDREPORTEDTIME_ORG
        |               ,P.LST_MOD_TS                                    AS MEDREPORTEDTIME_UPD
        |               ,UPPER(P.MED_FREEFORM)		                AS LOCALMEDCODE
        |               ,UPPER(P.MED_FREEFORM)                           AS LOCALDRUGDESCRIPTION
        |               ,nullif(regexp_extract(P.DOSE_FREEFORM,'[\\\\.0-9,-/]+', 0), '')    AS LOCALSTRENGTHPERDOSEUNIT
        |               ,nullif(TRIM(nullif(regexp_replace_5param(P.DOSE_FREEFORM,'[\\\\.0-9,-/]+','',1,1), '')), '') AS LOCALSTRENGTHUNIT
        |               ,nullif(TRIM(nullif(regexp_replace_5param(regexp_replace_5param(P.Dose_Freeform, '[A-Za-z%(),]+','',1,0),'/$','',1,0), '')), '') AS localtotaldose
        |               ,concat_ws('', {client_ds_id}, '.', COALESCE(Z.MED_IV_RTE_DS,P.RTE_INT_ID)) AS LOCALROUTE
        |               ,CASE WHEN nullif(concat_ws('', P.MED_END_TS, P.OBS_TS), '') IS NULL THEN 'CURRENT' ELSE 'HISTORICAL' END AS LOCALCATEGORYCODE
        |               ,COALESCE(P.MED_END_TS,P.OBS_TS)                 AS DISCONTINUEDATE
        |               ,P.OBS_RSN_DS    			        AS DISCONTINUEREASON
        |               ,NULL    	 		                AS LOCALDOSEUNIT
        |               ,NULL                                            AS LOCALFORM
        |               ,NULL	                                        AS LOCALQTYOFDOSEUNIT
        |               ,NULL     			                AS LOCALNDC
        |               ,NULL	                                        AS LOCALGPI
        |               ,P.LST_MOD_TS
        |               ,P.ROW_STA_CD
        |        FROM MCKESSON_PGN_V1_TSM261_PSN_HOME_MEDS P
        |        LEFT OUTER JOIN MCKESSON_PGN_V1_ZH_TOR750_MED_IV Z ON P.MED_INT_ID = Z.MED_INT_ID
        |        WHERE P.PSN_INT_ID IS NOT NULL
        |        AND (P.STA_RSN_CD NOT IN ({excl_sta_rsn}) OR P.STA_RSN_CD IS NULL)----Normally 26861 as Entered in Error
        |
        |        ) unpivot_base
        |)
        |where MEDREPORTEDTIME is not null
        |)
        | A
        |WHERE A.LOCALMEDCODE IS NOT NULL
        |AND A.MEDREPORTEDTIME IS NOT NULL
        |
        |)
        |where rn = 1 AND ROW_STA_CD <> 'D'
      """
        .stripMargin
        .replace("{excl_sta_rsn}",exclStaRsn)
        .replace("{groupid}",runtimeVar.groupId)
        .replace("{client_ds_id}",runtimeVar.clientDsId.toString)
    )
  }

}

package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object PROCEDURE extends FEQueryAndMetadata[proceduredo]{

  override def name: String = CDRFEParquetNames.proceduredo

  override def dependsOn: Set[String] = Set("LSS_DPBRPROCEDURE", "LSS_PBRACCOUNTS", "LSS_PBRACCOUNTTRANSACTIONS")

  override def sparkSql: String =
    """
      |with proc as (
      |   select p.*
      |      ,row_number() over ( Partition by SourceID, ProcedureID order by RowUpdateDateTime desc nulls first, FileID desc nulls first) as proc_rownumber
      |   from LSS_DPBRPROCEDURE p
      |),
      |proc_qry as (
      |    select *
      |    from proc
      |    where proc_rownumber = 1
      |),
      |act as (
      |   select a.*
      |      ,row_number() over ( Partition by SourceID, AccountID order by RowUpdateDateTime desc nulls first, PatientID desc nulls first) as act_rownumber
      |   FROM  LSS_PBRACCOUNTS a
      |),
      |act_qry as
      |(
      |   select *
      |   from act
      |   WHERE  act_rownumber = 1
      |)
      |SELECT datasrc,encounterid,patientid,performingproviderid,referproviderid,proceduredate,localcode,localname,procseq
      |FROM (
      |     SELECT   x.*
      |         ,row_number() over ( partition by PatientID, EncounterID, LocalCode, ProcedureDate, Procseq
      |                               order by RowUpdateDateTime desc nulls first, FileID desc nulls first
      |                             ) as rownumber
      |     FROM (
      |         SELECT 'pbraccounttransactions' as datasrc
      |               , nullif(substr(pbr.Procedureid,1,5), '') AS localcode
      |               , CONCAT_WS('', pbr.Sourceid, act.Patientid) AS patientid
      |               , pbr.Servicedatetime AS proceduredate
      |               , pbr.Procedureinsdescription AS localname
      |               , pbr.Transactionid AS procseq
      |               , CONCAT_WS('', pbr.sourceid, pbr.Referinproviderid) AS referproviderid
      |               , pbr.Servicedatetime AS actualproceduredate
      |               , CONCAT_WS('', pbr.Sourceid, pbr.Accountid, pbr.Locationid, UPPER(DATE_FORMAT(pbr.Servicedatetime, 'dd-MMM-yy'))) AS encounterid
      |               , CONCAT_WS('', pbr.Sourceid, pbr.Providerid) AS performingproviderid
      |               , COALESCE(nullif(substr(dpb.inscode, 1,5), ''), nullif(substr(pbr.procedureid, 1,5), '')) AS standardcode
      |               , pbr.RowUpdateDateTime
      |               , pbr.FileID
      |         FROM LSS_PBRACCOUNTTRANSACTIONS pbr
      |         INNER JOIN act_qry act ON (act.sourceid=pbr.sourceid and act.accountid=pbr.accountid)
      |         LEFT JOIN proc_qry dpb ON (pbr.sourceid = dpb.sourceid and pbr.procedureid = dpb.procedureid)
      |         WHERE pbr.Type = 'C' and reversingtransactionid is null
      |               AND pbr.Procedureid is not null
      |               AND act.Patientid is not null
      |               AND pbr.Servicedatetime is not null
      |         ) x
      |) where rownumber = 1
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_WITHOUT_NONNUMERIC extends FEQueryAndMetadata[labresult]{

  override def name: String = "LABRESULT_WITHOUT_NONNUMERIC"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE1", "LABRESULT_CACHE2", "LABRESULT_CACHE3")

  override def sparkSql: String =
    """
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,labresultid
      |       ,localcode
      |       ,localresult
      |       ,patientid
      |       ,datecollected
      |       ,LABORDEREDDATE
      |       ,dateavailable
      |       ,encounterid
      |       ,laborderid
      |       ,locallisresource
      |       ,localname
      |       ,localtestname
      |       ,localunits
      |       ,labresult_date
      |       ,null as resulttype
      |       ,localresult_numeric
      |       ,localresult_numeric as localresult_inferred
      |       ,normalrange
      |FROM LABRESULT_CACHE1
      |WHERE localresult_numeric IS NOT NULL
      |AND labresultid IS NOT NULL
      |AND LABRESULT_DATE is not null
      |AND row1 = 1
      |
      |
      |UNION ALL
      |
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,labresultid
      |       ,localcode
      |       ,localresult
      |       ,patientid
      |       ,datecollected
      |       ,null as LABORDEREDDATE
      |       ,null as dateavailable
      |       ,encounterid
      |       ,laborderid
      |       ,null as locallisresource
      |       ,localname
      |       ,localtestname
      |       ,null as localunits
      |       ,labresult_date
      |       ,null as resulttype
      |       ,localresult_numeric
      |       ,localresult_numeric as localresult_inferred
      |       ,null as normalrange
      |FROM LABRESULT_CACHE2
      |WHERE localresult_numeric IS NOT NULL
      |AND dedup_row = 1
      |
      |
      |UNION ALL
      |
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,labresultid
      |       ,localcode
      |       ,localresult
      |       ,patientid
      |       ,datecollected
      |       ,null as LABORDEREDDATE
      |       ,dateavailable
      |       ,encounterid
      |       ,null as laborderid
      |       ,null as locallisresource
      |       ,localname
      |       ,localtestname
      |       ,localunits
      |       ,datecollected AS labresult_date
      |       ,resulttype
      |       ,localresult_numeric
      |       ,localresult_numeric as localresult_inferred
      |       ,normalrange
      |FROM LABRESULT_CACHE3
      |WHERE localresult_numeric is not null
      |AND rownumber = 1
    """.stripMargin


}

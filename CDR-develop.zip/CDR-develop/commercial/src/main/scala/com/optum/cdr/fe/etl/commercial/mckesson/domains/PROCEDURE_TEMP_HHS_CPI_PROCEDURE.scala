package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.proceduredo
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object PROCEDURE_TEMP_HHS_CPI_PROCEDURE extends FETableInfo[proceduredo]{
  override def name: String = "PROCEDURE_TEMP_HHS_CPI_PROCEDURE"

  override def dependsOn: Set[String] = Set("MCKESSON_HHS_CPI_PROCEDURE","MCKESSON_ZH_ENT_CONFIG_CODE_SET","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val incl_proc = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "HHS_CPI_PROCEDURE", "PROCEDURE", "HHS_CPI_PROCEDURE", "PROCEDURE_REPORTED_BY_LSEQ").mkString(",")

    sparkSession.sql(
      s"""
         |WITH uni_proc AS
         |(SELECT * FROM
         |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY cpi_procedure_seq ORDER BY modified_dt DESC NULLS LAST) rn
         | FROM MCKESSON_HHS_CPI_PROCEDURE p
         | WHERE coding_system IS NOT NULL
         |   AND (reportable_fl = 'Y' OR reportable_fl IS NULL)
         |   AND procedure_reported_by_lseq IN ({incl_proc})
         |  )
         | WHERE rn = 1)
         |select datasrc, localcode, encounterid, patientid, proceduredate, localname, codetype, mappedcode, actualprocdate, facilityid, hosp_px_flag
         |from
         |(
         |SELECT 'hhs_cpi_procedure' AS datasrc
         |	,uni_proc.code		AS localcode
         |	,uni_proc.cpi_seq  	AS patientid
         |	,COALESCE(uni_proc.performed_dt, uni_proc.created_dt)  AS proceduredate
         |	,uni_proc.Performed_Dt   AS actualprocdate
         |	,uni_proc.pat_seq  	AS encounterid
         |	,NULL		AS facilityid
         |	,uni_proc.Description    AS localname
         |	,zh.code_value	AS mappedcode
         |	,CASE WHEN UPPER(uni_proc.coding_system) LIKE '%CPT%4' THEN 'CPT4'
         |	      WHEN UPPER(uni_proc.coding_system) LIKE 'I%9%' THEN 'ICD9'
         |	      WHEN UPPER(uni_proc.coding_system) LIKE 'I%10%' THEN 'ICD10'
         |	      WHEN uni_proc.coding_system = 'SNOMED' THEN 'SNOMED' END 	AS codetype
         |	,'Y'            AS hosp_px_flag
         |	,ROW_NUMBER() OVER (PARTITION BY uni_proc.cpi_seq, uni_proc.pat_seq, COALESCE(uni_proc.performed_dt, uni_proc.created_dt), uni_proc.code
         |	         ORDER BY uni_proc.modified_dt DESC NULLS LAST) rn
         |FROM UNI_PROC
         |    LEFT OUTER JOIN MCKESSON_ZH_ENT_CONFIG_CODE_SET zh ON uni_proc.internal_code = zh.internal_code
         |
         |)
         |where proceduredate IS NOT NULL
         |and rn = 1
       """.stripMargin.replace("{incl_proc}",incl_proc))
  }
}

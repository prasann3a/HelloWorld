package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.health_maintenance
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}



object HEALTH_MAINTENANCE extends FETableInfo[health_maintenance]{



  override def name: String = CDRFEParquetNames.health_maintenance


  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
  val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
  val clientDsId = loaderVars.clientDsId.toString
  val groupId = loaderVars.groupId



  loadedDependencies.foreach {
    case (depName, df) => df.createOrReplaceTempView(depName)
  }


    sparkSession.sql(
    """
      |select groupid, client_ds_id, datasrc, patientid, documented_date, localcode, hm_cui, last_satisfied_date, next_due_date
       |from
       |(
       |select '{groupid}'	as groupid
       |	,'{cdsid}'	as client_ds_id
       |	,'manualhealthmaintenance'		as datasrc
       |	,m.unique_person_identifier	as patientid
       |	,m.update_date_time	as documented_date
       |	,m.expectation	as localcode
       |	,mst.hts_code	as hm_cui
       |	,m.last_satisfaction_date_time		as last_satisfied_date
       |	,m.due_date_time	as next_due_date
       |	,row_number() over (partition by m.expectation, m.unique_person_identifier order by m.update_date_time desc nulls last)	as rownumber
       |from MANUALHEALTHMAINTENANCE m
       |	inner join 	MAP_SCREENING_TESTS mst on (mst.groupid = '{groupid}' and mst.local_code = m.expectation)
       |where m.unique_person_identifier is not null
       |and m.expectation is not null
       |and m.hum_action not in ('5','4','15')
       |
 |)
       |where rownumber = 1
       |""".stripMargin
        .replace("{groupid}",groupId)
        .replace("{cdsid}",clientDsId)



    )

}

override def dependsOn: Set[String] = Set("MANUALHEALTHMAINTENANCE","MAP_SCREENING_TESTS")

override def saveDataFrameToParquet: Boolean = true
}

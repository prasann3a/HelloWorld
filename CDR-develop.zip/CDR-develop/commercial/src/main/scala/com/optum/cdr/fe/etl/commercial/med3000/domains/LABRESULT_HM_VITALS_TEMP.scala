package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.cdr.fe.etl.commercial.med3000_gtt_labresult_nonnumeric
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.sql.SaveMode

object LABRESULT_HM_VITALS_TEMP extends FEQueryAndMetadata[med3000_gtt_labresult_nonnumeric] {

  override def name: String = "TEMP_LABRESULT_CACHE"

  override def dependsOn: Set[String] = Set("TEMP_LABRESULT_CACHE","MED3000_PATIENT_HM","ZCM_OBSTYPE_CODE","MED3000_PATIENT_VITALS","MED3000_PATIENT_VITAL_SIGNS","MED3000_ZH_VITALS_MASTER")

  override def tableOrder: Int = 2

  override def saveMode: SaveMode = SaveMode.Append

  override def sparkSql: String =
    """
 |select v.*
 |       ,safe_to_number(localresult) as localresult_numeric
 |       ,safe_to_number(localresult) as localresult_inferred
 |  from (
 | Select groupid,
 |        datasrc,
 |        client_ds_id,
 |        labresultid,
 |        localcode,
 |        localresult,
 |        patientid,
 |        datecollected,
 |        dateavailable,
 |        labresult_date,
 |  	    localname,
 |        localunits
 |  from (
 |select  '{groupid}' 					as groupid
 |       ,'pat_hm' 					    as datasrc
 |       ,{client_ds_id} 				as client_ds_id
 |       ,hm.Patient_Hm_Identity  	as labresultid
 |       ,hm.Hm_Master_Key  			as localcode
 |       ,nullif(regexp_extract(hm.Item_Value, '^[0-9]+', 0), '')  as localresult
 |       ,hm.Blind_Key  				as patientid
 |       ,null                  as datecollected
 |       ,hm.Label_Date  				as dateavailable
 |	     ,hm.Label_Date           as labresult_date
 |       ,hm.Item_Link_Description  	as localname
 |       ,z.Localunit  				as localunits
 |	     ,row_number() over (partition by hm.Patient_Hm_Identity order by hm.Update_Date desc nulls last) as rank_labresult
 | from MED3000_PATIENT_HM hm
 | inner join ZCM_OBSTYPE_CODE z
 |    on (z.groupid='{groupid}' and z.datasrc='pat_hm'  and hm.Hm_Master_Key = z.obscode and Obstype = 'LABRESULT')
 | where hm.Label_Date is not null and hm.Blind_Key is  not null and hm.Patient_Hm_Identity  is not null)
 | where rank_labresult =1
 |
 |       ) v
 |
 |union all
 |
 |select v.*
 |       ,safe_to_number(localresult) as localresult_numeric
 |       ,safe_to_number(localresult) as localresult_inferred
 |  from (
 | Select groupid,
 |        datasrc,
 |        client_ds_id,
 |        labresultid,
 |        localcode,
 |        localresult,
 |        patientid,
 |		    datecollected,
 |        dateavailable,
 |        labresult_date,
 |  	    localname,
 |        localunits
 |  from (
 |select '{groupid}' 				as groupid
 |       ,'pat_vitals' 			as datasrc
 |       ,{client_ds_id} 			as client_ds_id
 |       ,nullif(concat_ws('', vit.Patient_Vital_Signs_Key, vit.Blind_Key, vit.Vitals_Master_Key), '')
 |                                as labresultid
 |       ,vit.Vitals_Master_Key  	as localcode
 |       ,nullif(regexp_extract(vit.Short_Text, '^[0-9]+', 0), '')  		as localresult
 |       ,vit.Blind_Key  				  as patientid
 |       ,signs.Visit_Date  			as datecollected
 |       ,signs.Visit_Date  			as dateavailable
 |	     ,signs.Visit_Date  			as labresult_date
 |       ,mast.Vitals_Label  			as localname
 |       ,z.Localunit  			    	as localunits
 |	     ,row_number() over (partition by nullif(concat_ws('', vit.Patient_Vital_Signs_Key, vit.Blind_Key, vit.Vitals_Master_Key), '') order by vit.Update_Date desc nulls last) as rank_labresult
 |  from MED3000_PATIENT_VITALS vit
 |  inner join ZCM_OBSTYPE_CODE z
 |    on (z.groupid='{groupid}' and z.datasrc='pat_vitals'  and vit.Vitals_Master_Key = z.obscode and Obstype = 'LABRESULT')
 | inner join MED3000_ZH_VITALS_MASTER mast on (vit.Vitals_Master_Key = mast.Vitals_Master_Key)
 | inner join MED3000_PATIENT_VITAL_SIGNS signs on (vit.Patient_Vital_Signs_Key = signs.Patient_Vital_Signs_Key)
 | where signs.Visit_Date is not null and vit.Blind_Key is  not null )
 | where rank_labresult =1
 |       ) v
    """.stripMargin
}

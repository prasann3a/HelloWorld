package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.insurance
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object INSURANCE extends FEQueryAndMetadata[insurance]{

  override def name: String = CDRFEParquetNames.insurance

  override def dependsOn: Set[String] = Set("EDI_INVOICE", "ZH_INSURANCE", "ZH_INSURANCEDETAIL", CDRFEParquetNames.clinicalencounter)

  override def sparkSql: String =
    """
      |WITH dedup_inv AS (
      |       SELECT  *
      |              FROM
      |              (
      |                     SELECT  i.*
      |                            ,ROW_NUMBER() OVER (PARTITION BY id ORDER BY modifydate DESC nulls last) rn
      |                     FROM EDI_INVOICE i
      |                     WHERE deleteflag <> '1'
      |              )
      |       WHERE rn = 1
      |)
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,patientid
      |       ,encounterid
      |       ,ins_timestamp
      |       ,plantype
      |       ,payorcode AS plancode
      |       ,payorname AS planname
      |       ,insuranceorder
      |       ,null as enrollenddt
      |       ,null as enrollstartdt
      |       ,null as groupnbr
      |       ,payorcode
      |       ,payorname
      |       ,sourceid
      |       ,null as policynumber
      |FROM
      |(
      |	SELECT  '{groupid}'                                                                                                      AS groupid
      |	       ,'edi_invoice'                                                                                                    AS datasrc
      |	       ,{client_ds_id}                                                                                                   AS client_ds_id
      |	       ,dedup_inv.Servicedt                                                                                              AS ins_timestamp
      |	       ,dedup_inv.Patientid                                                                                              AS patientid
      |	       ,dedup_inv.Encounterid                                                                                            AS encounterid
      |	       ,CASE WHEN COALESCE(Zh_Insurance.Insuranceclass,Zh_Insurance.insuranceprimarytype) IS NOT NULL THEN concat_ws('','{client_ds_id}','.i.',COALESCE(Zh_Insurance.Insuranceclass,Zh_Insurance.insuranceprimarytype))
      |                 ELSE NULL END AS plantype
      |	       ,CASE WHEN dedup_inv.PrimaryInsid <> '0' AND zh_insurance.insid = dedup_inv.primaryinsid THEN '1'
      |	             WHEN dedup_inv.secondaryInsid <> '0' AND zh_insurance.insid = dedup_inv.secondaryinsid THEN '2'
      |	             WHEN dedup_inv.tertiaryInsid <> '0' AND zh_insurance.insid = dedup_inv.tertiaryinsid THEN '3'
      |                 ELSE NULL END AS insuranceorder
      |	       ,Zh_Insurance.InsID                                                                                               AS payorcode
      |	       ,zh_insurance.insurancename                                                                                       AS payorname
      |	       ,dedup_inv.Id                                                                                                     AS sourceid
      |	FROM DEDUP_INV
      |	JOIN {CLINICALENCOUNTER} enc
      |	    ON (dedup_inv.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
      |	LEFT OUTER JOIN ZH_INSURANCE
      |	    ON (Zh_Insurance.InsID = dedup_inv.PrimaryInsid OR Zh_Insurance.InsID = dedup_inv.SecondaryInsid OR Zh_Insurance.InsID = dedup_inv.TertiaryInsid)
      |)
      |WHERE ins_timestamp IS NOT NULL
      |
      |UNION ALL
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,patientid
      |       ,null as encounterid
      |       ,ins_timestamp
      |       ,plantype
      |       ,plancode
      |       ,planname
      |       ,insuranceorder
      |       ,enrollenddt
      |       ,enrollstartdt
      |       ,groupnbr
      |       ,payorcode
      |       ,payorname
      |       ,null as sourceid
      |       ,policynumber
      |FROM
      |(
      |	SELECT  '{groupid}'                                                                                  AS groupid
      |	       ,'zh_insurancedetail'                                                                         AS datasrc
      |	       ,{client_ds_id}                                                                               AS client_ds_id
      |	       ,safe_to_date(COALESCE(Zh_Insurancedetail.startdate,Zh_Insurancedetail.enddate),'MM/dd/yyyy') AS ins_timestamp
      |	       ,Zh_Insurancedetail.Pid                                                                       AS patientid
      |	       ,safe_to_date(Zh_Insurancedetail.enddate,'MM/dd/yyyy')                                        AS enrollenddt
      |	       ,safe_to_date(Zh_Insurancedetail.startdate,'MM/dd/yyyy')                                      AS enrollstartdt
      |	       ,CASE WHEN COALESCE(Zh_Insurance.Insuranceclass,Zh_Insurance.insuranceprimarytype) IS NOT NULL THEN concat_ws('','{client_ds_id}','.i.',COALESCE(Zh_Insurance.Insuranceclass,Zh_Insurance.insuranceprimarytype))
      |                    ELSE NULL END AS plantype
      |	       ,Zh_Insurancedetail.Groupno                                                                   AS groupnbr
      |	       ,Zh_Insurancedetail.Insorder                                                                  AS insuranceorder
      |	       ,Zh_Insurance.Insid                                                                           AS payorcode
      |	       ,zh_insurance.insurancename                                                                   AS payorname
      |	       ,Zh_Insurancedetail.Insid                                                                     AS plancode
      |	       ,Zh_Insurance.Insurancename                                                                   AS planname
      |	       ,Zh_Insurancedetail.Subscriberno                                                              AS policynumber
      |	       ,Zh_Insurancedetail.deleteflag
      |	FROM ZH_INSURANCEDETAIL
      |	LEFT OUTER JOIN ZH_INSURANCE
      |	    ON (Zh_InsuranceDetail.Insid = Zh_Insurance.Insid)
      |)
      |WHERE DeleteFlag <> '1'
      |AND ins_timestamp IS NOT NULL
    """.stripMargin
    .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
}

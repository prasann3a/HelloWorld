package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.gtt_prov_pat_rel
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, RuntimeVariables}
import org.apache.spark.storage.StorageLevel

object GTT_PROV_PAT_REL extends FEQueryAndMetadata[gtt_prov_pat_rel] {

  override def name: String = "GTT_PROV_PAT_REL"

  override def dependsOn: Set[String] = Set("CENTRICV2_REGISTRATION")

  override def sparkSql: String =
    """
      |SELECT
      |	groupid,
      |	datasrc,
      |	providerid,
      |	patientid,
      |	localrelshipcode,
      |	enddate,
      |	client_ds_id,
      |CASE
      |		WHEN prov_rownumber = 1 THEN CAST(TO_DATE('{start_date}', 'yyyyMMdd') AS TIMESTAMP)
      |		ELSE startdate
      |END AS startdate
      |FROM
      |(
      |select 	z.*
      |	,row_number() over ( partition by patientid order by startdate ) as prov_rownumber
      | from (
      |select 	'{groupid}'             as groupid
      | ,'{client_ds_id}'             as client_ds_id
      |	,'registration'        as datasrc
      |	,case when cast(provid as BIGINT) <> 0 then provid else null  end as providerid
      |	,pid as patientid
      |	,'PCP' as localrelshipcode
      |	,db_updated_date as startdate
      |	,current_date as enddate
      |from
      |(
      |select * from
      |(
      |select unpivot_base.*,
      |stack(2, respprovid,'RESPPROVID',PCPID,'PCPID') as (provid, seq)
      |from
      |(select
          distinct pid,
          cast(respprovid as STRING) as respprovid,
          db_updated_date,
          PCPID
      |       from CENTRICV2_REGISTRATION
      |       where  db_updated_date is not null
      |      ) unpivot_base
      |)
      |where provid is not null
      |)
      |) z
      |where patientid is not null and providerid is not null
      |)
      """.stripMargin


  override protected def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val startDate = if (loaderVars.groupId.toLowerCase().stripMargin == "h064317") "20010101" else "20050101"

    sparkSql.replace("{groupid}", loaderVars.groupId).
      replace("{client_ds_id}", loaderVars.clientDsId.toString).
      replace("{start_date}", startDate)
  }

}
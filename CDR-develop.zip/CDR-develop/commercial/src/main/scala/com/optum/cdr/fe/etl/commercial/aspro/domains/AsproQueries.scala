package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.cdr.fe.etl.commercial.cenent.domains.InitialDependencies
import com.optum.cdr.fe.etl.commercial.unit_remap
import com.optum.cdr.fe.utils.load_prov_pat_rel.PROV_PAT_REL
import com.optum.cdr.fe.utils.nonnumeric_labs_localresult_25.NONNUMERIC_LABRESULT
import com.optum.oap.cdr.models.{map_custom_proc, map_observation, map_predicate_values, map_unit, metadata_lab, unit_conversion, zcm_obstype_code}
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object AsproQueries extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] =
    InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries
}

object AsproQueriesWithDrugAssign extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] =
    InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries ++ QueryRegistry.drug_assign_queries
}

object InitialDependencies {
  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      FELoadFromParquet[address](name = "ADDRESS", parquetLocation = s"$baseParquetLocation", tableName = "ADDRESS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[patient](name = "ASPRO_PATIENT", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[aspro_immunizations](name = "ASPRO_IMMUNIZATIONS", parquetLocation = s"$baseParquetLocation", tableName = "IMMUNIZATIONS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_drugs](name = "ZH_DRUGS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DRUGS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_drug_ndc](name = "ZH_DRUG_NDC", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DRUG_NDC", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[hxdiagnosis](name = "HXDIAGNOSIS", parquetLocation = s"$baseParquetLocation", tableName = "HXDIAGNOSIS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[encounters](name = "ENCOUNTERS", parquetLocation = s"$baseParquetLocation", tableName = "ENCOUNTERS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[laborders](name = "LABORDERS", parquetLocation = s"$baseParquetLocation", tableName = "LABORDERS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_labcatalog](name = "ZH_LABCATALOG", parquetLocation = s"$baseParquetLocation", tableName = "ZH_LABCATALOG", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[procedures](name = "PROCEDURES", parquetLocation = s"$baseParquetLocation", tableName = "PROCEDURES", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[aspro_hx_medication](name = "ASPRO_HX_MEDICATION", parquetLocation = s"$baseParquetLocation", tableName = "HX_MEDICATION", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_providers](name = "ZH_PROVIDERS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_PROVIDERS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[exp_insurance](name = "EXP_INSURANCE", parquetLocation = s"$baseParquetLocation", tableName = "EXP_INSURANCE", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_exp_insurance](name = "ZH_EXP_INSURANCE", parquetLocation = s"$baseParquetLocation", tableName = "ZH_EXP_INSURANCE", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[medications](name = "MEDICATIONS", parquetLocation = s"$baseParquetLocation", tableName = "MEDICATIONS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[scan_document](name = "SCAN_DOCUMENT", parquetLocation = s"$baseParquetLocation", tableName = "SCAN_DOCUMENT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[map_custom_proc](name = "MAP_CUSTOM_PROC", parquetLocation = s"$mappingParquetPath", tableName = "MAP_CUSTOM_PROC", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[vitals](name = "VITALS", parquetLocation = s"$baseParquetLocation", tableName = "VITALS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zcm_obstype_code](name = "ZCM_OBSTYPE_CODE", parquetLocation = s"$mappingParquetPath", tableName = "ZCM_OBSTYPE_CODE", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[aspro_diagnosis](name = "ASPRO_DIAGNOSIS", parquetLocation = s"$baseParquetLocation", tableName = "DIAGNOSIS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[procresults](name = "PROCRESULTS", parquetLocation = s"$baseParquetLocation", tableName = "PROCRESULTS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[flowsheet](name = "FLOWSHEET", parquetLocation = s"$baseParquetLocation", tableName = "FLOWSHEET", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PREDICATE_VALUES", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[pcp](name = "PCP", parquetLocation = s"$baseParquetLocation", tableName = "PCP", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_location](name = "ZH_LOCATION", parquetLocation = s"$baseParquetLocation", tableName = "ZH_LOCATION", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[labresults](name = "LABRESULTS", parquetLocation = s"$baseParquetLocation", tableName = "LABRESULTS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[map_observation](name = "MAP_OBSERVATION", parquetLocation = s"$mappingParquetPath", tableName = "MAP_OBSERVATION", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[map_unit](name = "MAP_UNIT", parquetLocation = s"$mappingParquetPath", tableName = "MAP_UNIT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[unit_remap](name = "UNIT_REMAP", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_REMAP", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[metadata_lab](name = "METADATA_LAB", parquetLocation = s"$mappingParquetPath", tableName = "METADATA_LAB", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[unit_conversion](name = "UNIT_CONVERSION", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_CONVERSION", ignoreExtraColumnsInDataFrame = true)
  )
}

object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      PATIENTCONTACT
    , IMMUNIZATION
    , ALLERGY
    , CLAIM
    , RX_PATIENT_REPORTED
    , ENCOUNTERPROVIDER1
    , ENCOUNTERPROVIDER2
    , ENCOUNTERPROVIDER
    , INSURANCE
    , RXORDER
    , CLINICALENCOUNTER
    , PROCEDURE_CACHE
    , PROCEDURE1
    , PROCEDURE2
    , PROCEDURE3
    , PROCEDURE4
    , PROCEDURE
    , PATIENT_CACHE
    , PATIENT_QUERY
    , PATIENTDETAIL
    , PATIENT_ID
    , OBSERVATION
    , OBSERVATION_CACHE
    , OBSERVATION_DIAGNOSIS
    , OBSERVATION_FLOWSHEET
    , OBSERVATION_VITALS
    , GTT_PROV_PAT_REL
    , PROV_PAT_REL
    , DIAGNOSIS
    , PROV_SPEC
    , ZH_FACILITY
    , ZH_PROVIDER_IDENTIFIER
    , ZH_PROVIDER
    , ZH_LAB_DICT
    , GTT_LABRESULT_NONNUMERIC
    , GTT_LABRESULT_NONNUMERIC_VITALS
    , GTT_LABRESULT_NONNUMERIC_PROCRESULTS
    , GTT_LABRESULT_NONNUMERIC_LABRESULTS
    , LABRESULT
    , LABRESULT_CACHE_LABRESULTS
    , LABRESULT_CACHE_PROCRESULTS
    , LABRESULT_CACHE_VITALS
    , LABRESULT_LABRESULTS
    , LABRESULT_PROCRESULTS
    , LABRESULT_VITALS
    , NONNUMERIC_LABRESULT
  )

  val drug_assign_queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    MEDICATION_MAP_SRC

  )
}

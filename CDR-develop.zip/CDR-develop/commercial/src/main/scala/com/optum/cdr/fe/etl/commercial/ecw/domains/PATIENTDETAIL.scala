package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.patientdetail
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTDETAIL extends FEQueryAndMetadata[patientdetail]{

  override def name: String = CDRFEParquetNames.patientdetail

  override def dependsOn: Set[String] = Set("ECW_USERS_CACHE", "ECW_PATS_CACHE")

  override def sparkSql: String =
    """
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.hum_uid as patientid
      |       ,'LAST_NAME' as patientdetailtype
      |       ,p.ulname as localvalue
      |       ,nvl(max(p.mdate),current_date) as patdetail_timestamp
      |from ECW_USERS_CACHE p
      |where exists (select pid from ECW_PATS_CACHE where pid = hum_uid )
      |and ulname is not null
      |
      |group by  p.hum_uid,ulname
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.hum_uid as patientid
      |       ,'FIRST_NAME' as patientdetailtype
      |       ,p.ufname as localvalue
      |       ,nvl(max(p.mdate),current_date) as patdetail_timestamp
      |from ECW_USERS_CACHE p
      |where exists (select pid from ECW_PATS_CACHE where pid = hum_uid )
      |and ufname is not null
      |
      |group by  p.hum_uid,ufname
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.hum_uid as patientid
      |       ,'MIDDLE_NAME' as patientdetailtype
      |       ,p.uminitial as localvalue
      |      ,nvl(max(p.mdate),current_date) as patdetail_timestamp
      |from ECW_USERS_CACHE p
      |where exists (select pid from ECW_PATS_CACHE where pid = hum_uid )
      |and uminitial is not null
      |
      |group by  p.hum_uid,uminitial
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.hum_uid as patientid
      |       ,'GENDER' as patientdetailtype
      |       ,coalesce(sex,emrsex) as localvalue
      |       ,nvl(max(p.mdate),current_date) as patdetail_timestamp
      |from ECW_USERS_CACHE p
      |where exists (select pid from ECW_PATS_CACHE where pid = hum_uid )
      |and coalesce(sex,emrsex) is not null
      |
      |group by  p.hum_uid,coalesce(sex,emrsex)
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.pid as patientid
      |       ,'RACE' as patientdetailtype
      |       ,race as localvalue
      |       ,nvl(max(p.modifieddate),current_date) as patdetail_timestamp
      |from ECW_PATS_CACHE p
      |where exists (select hum_uid from ECW_USERS_CACHE where pid = hum_uid )
      |and race is not null
      |
      |group by  p.pid,race
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.pid as patientid
      |       ,'ETHNICITY' as patientdetailtype
      |       ,coalesce(Ethnicity ,Race ) as localvalue
      |       ,nvl(max(p.modifieddate),current_date) as patdetail_timestamp
      |from ECW_PATS_CACHE p
      |where exists (select hum_uid from ECW_USERS_CACHE where pid = hum_uid )
      |and coalesce(Ethnicity ,Race ) is not null
      |
      |group by  p.pid,coalesce(Ethnicity ,Race )
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.pid as patientid
      |       ,'LANGUAGE' as patientdetailtype
      |       ,language as localvalue
      |       ,nvl(max(p.modifieddate),current_date) as patdetail_timestamp
      |from ECW_PATS_CACHE p
      |where exists (select hum_uid from ECW_USERS_CACHE where pid = hum_uid )
      |and language is not null
      |
      |group by  p.pid,language
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.pid as patientid
      |       ,'MARITAL' as patientdetailtype
      |       ,Maritalstatus as localvalue
      |       ,nvl(max(p.modifieddate),current_date) as patdetail_timestamp
      |from ECW_PATS_CACHE p
      |where exists (select hum_uid from ECW_USERS_CACHE where pid = hum_uid )
      |and Maritalstatus is not null
      |
      |group by  p.pid,Maritalstatus
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.hum_uid as patientid
      |       ,'CITY' as patientdetailtype
      |       ,upcity as localvalue
      |       ,nvl(max(p.mdate),current_date) as patdetail_timestamp
      |from ECW_USERS_CACHE p
      |where exists (select pid from ECW_PATS_CACHE where pid = hum_uid )
      |and upcity is not null
      |
      |group by  p.hum_uid,upcity
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.hum_uid as patientid
      |       ,'STATE' as patientdetailtype
      |       ,upstate as localvalue
      |       ,nvl(max(p.mdate),current_date) as patdetail_timestamp
      |from ECW_USERS_CACHE p
      |where exists (select pid from ECW_PATS_CACHE where pid = hum_uid )
      |and upstate is not null
      |
      |group by  p.hum_uid,upstate
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.hum_uid as patientid
      |       ,'ZIPCODE' as patientdetailtype
      |       ,zipcode as localvalue
      |       ,nvl(max(p.mdate),current_date) as patdetail_timestamp
      |from ECW_USERS_CACHE p
      |where exists (select pid from ECW_PATS_CACHE where pid = hum_uid )
      |and zipcode is not null
      |
      |group by  p.hum_uid,zipcode
      |)
      |
      |union all
      |
      |select groupid, client_ds_id, datasrc, patientid, patientdetailtype, localvalue, PATDETAIL_TIMESTAMP
      |from
      |(
      |select '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'patient' as datasrc
      |       ,p.pid as patientid
      |       ,'DECEASED' as patientdetailtype
      |
      |       ,CASE WHEN deceased = '1' THEN 'Y' ELSE 'DEFAULT' END AS localvalue
      |       ,nvl(max(p.modifieddate), current_date) as patdetail_timestamp
      |from ECW_PATS_CACHE p
      |where exists (select hum_uid from ECW_USERS_CACHE where pid = hum_uid )
      |
      |group by  p.pid,deceased
      |)
      |where localvalue IS NOT NULL
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, observation}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_HPI extends FETableInfo[observation]{

  override def name: String = "OBSERVATION_HPI"

  override def dependsOn: Set[String] = Set("HPI", CDRFEParquetNames.clinicalencounter, "ZCM_OBSTYPE_CODE", "MAP_PREDICATE_VALUES", "ENC")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val listPropid = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "HPI", "OBSERVATION",
      "OBSERVATION", "PROPID").mkString(",")

    val conditionLocalresult = if (runtimeVar.groupId == "H827927") "WHEN hpi.propid='27741' THEN regexp_substr(hpi.notes,'(use DASH diet)',1,1)" else "--"

    val obsdateColHpi = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "HPI", "OBSERVATION",
      "OBSERVATION", "OBSDATE_COL_NM").mkString(",")
    val obsdateColHpiCorrected = if (obsdateColHpi == "'NO_MPV_MATCHES'") "coalesce(hpi.createdate,hpi.hum_date)"
                                  else s"replace($obsdateColHpi,'\\'',NULL)"

    val encDateJoinHpi = if (obsdateColHpiCorrected.toLowerCase == "enc.enc_date") "JOIN ENC enc on (hpi.encounterid = enc.encounterid)" else "--"

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,obsdate
        |       ,localcode
        |       ,localresult
        |       ,obstype
        |       ,null              AS obsresult
        |       ,local_obs_unit
        |       ,obstype_std_units AS std_obs_unit
        |FROM
        |(
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                      AS groupid
        |		       ,'hpi'                                            AS datasrc
        |		       ,{client_ds_id}                                   AS client_ds_id
        |		       ,CASE WHEN hpi.propid IN ({list_propid}) THEN nullif(REGEXP_SUBSTR(nullif(SUBSTR(hpi.NOTES,INSTR(hpi.NOTES,'Total Score')+12,3),''),'[0-9]+',1,1),'')
        |             {condition_localresult}
        |             ELSE nullif(substr(hpi.notes,1,255),'') END AS localresult
        |		       ,concat_ws('','{client_ds_id_prefix}',Hpi.Propid) AS localcode
        |		       ,hpi.obsdate
        |		       ,cEnc.Patientid                                   AS patientid
        |		       ,cEnc.Encounterid                                 AS encounterid
        |		       ,z.obstype
        |		       ,z.obsregex
        |		       ,z.obsconvfactor
        |		       ,z.datatype
        |		       ,z.begin_range
        |		       ,z.end_range
        |		       ,z.ROUND_PREC
        |		       ,z.localunit                                      AS local_obs_unit
        |		       ,z.obstype_std_units
        |		       ,z.localunit_cui
        |		       ,z.conv_fact
        |		       ,z.function_applied
        |		       ,ROW_NUMBER() OVER (PARTITION BY cEnc.PatientID,cEnc.EncounterID,Hpi.Propid,z.obstype,hpi.obsdate ORDER BY hpi.obsdate DESC NULLS LAST) rn
        |		FROM
        |		(
        |			SELECT  encounterid
        |			       ,propid
        |			       ,obsdate
        |			       ,createdate
        |			       ,hum_date
        |			       ,notes
        |			FROM
        |			(
        |				SELECT  hpi.encounterid
        |				       ,hpi.propid
        |				       ,hpi.notes
        |				       ,hpi.createdate
        |				       ,hpi.hum_date
        |				       ,{obsdate_col_hpi} AS obsdate
        |				       ,ROW_NUMBER() OVER (PARTITION BY hpi.EncounterID,hpi.Propid,{obsdate_col_hpi} ORDER BY {obsdate_col_hpi} DESC NULLS LAST) rn
        |				FROM HPI
        |       {encDateJoinHpi}
        |				WHERE hpi.notes IS NOT NULL
        |				AND {obsdate_col_hpi} IS NOT NULL
        |				GROUP BY  hpi.encounterid
        |				         ,hpi.propid
        |				         ,hpi.createdate
        |				         ,hpi.hum_date
        |				         ,{obsdate_col_hpi}
        |				         ,hpi.notes
        |			) t
        |			WHERE rn = 1
        |		) hpi
        |		JOIN {CLINICALENCOUNTER} cEnc
        |		  ON (hpi.encounterid = cEnc.encounterid AND cEnc.client_ds_id = {client_ds_id})
        |		JOIN ZCM_OBSTYPE_CODE z
        |		  ON (z.obscode = concat_ws('', '{client_ds_id_prefix}', hpi.propid) AND z.groupid = '{groupid}' AND z.datasrc = 'hpi')
        |	)
        |	WHERE rn = 1
        |)
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{list_propid}", listPropid)
        .replace("{condition_localresult}", conditionLocalresult)
        .replace("{obsdate_col_hpi}", obsdateColHpiCorrected)
        .replace("{encDateJoinHpi}", encDateJoinHpi)
    )
  }


}

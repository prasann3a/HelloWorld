package com.optum.cdr.fe.etl.commercial.bcn.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object ELIG_MEMID_BCN_CACHE extends FEQueryAndMetadata[eligibility]{
  override def name: String = "ELIG_MEMID_BCN_CACHE"

  override def dependsOn: Set[String] = Set("ELIGIBILITY")

  override def sparkSql: String =
    """
      |WITH excl_memid_bcn_elig as(
      | SELECT  distinct concat_ws('',a.subscriber_id,'-',ltrim('0',a.member_suffix)) mem_id
      | FROM eligibility a
      | JOIN eligibility b ON (concat_ws('',a.subscriber_id,'-',ltrim('0',a.member_suffix)) = concat_ws('',b.subscriber_id,'-',ltrim('0',b.member_suffix)))
      | WHERE a.first_name <> b.first_name
      | AND a.birth_date <> b.birth_date
      |)
      |
      |SELECT  *
      |FROM eligibility m
      |WHERE subscriber_id is not null
      |AND member_suffix is not null
      |AND not exists (
      | SELECT  1
      | FROM excl_memid_bcn_elig
      | WHERE mem_id = concat_ws('',m.subscriber_id,'-',ltrim('0',m.member_suffix))
      |)
    """.stripMargin
}

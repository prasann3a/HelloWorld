package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.etl.commercial.ecw_rxorder_cache
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}
import org.apache.spark.storage.StorageLevel

object RXORDER_CACHE extends FEQueryAndMetadata[ecw_rxorder_cache]{

  override def name: String = "RXORDER_CACHE"

  override def dependsOn: Set[String] = Set("OLDRXMAIN", "OLDRXDETAIL", "ZH_DRUGREF", "ZH_ITEMS", CDRFEParquetNames.clinicalencounter)

  override def sparkSql: String =
    """
      |WITH rxmn AS (
      |	SELECT  *
      |	FROM
      |	(
      |		SELECT  m.*
      |		       ,ROW_NUMBER() OVER (PARTITION BY oldrxid ORDER BY modifieddate DESC nulls last) rn
      |		FROM OLDRXMAIN m
      |		WHERE m.itemid <> '0'
      |	)
      |	WHERE rn = 1
      |),
      |rxdtl AS (
      |	SELECT  *
      |	FROM
      |	(
      |		SELECT  d.*
      |		       ,row_number() over (partition by oldrxid,prop ORDER BY modifieddate desc nulls last) rn
      |		FROM OLDRXDETAIL d
      |	)
      |	WHERE rn = 1
      |)
      |
      |SELECT *,
      |       cast(safe_to_number_extras(Localqtyofdoseunit,0)*safe_to_number_extras(Localstrengthperdoseunit,0) as Integer) as localtotaldose
      |FROM
      |(
      | SELECT  groupid
      |        ,datasrc
      |        ,client_ds_id
      |        ,issuedate
      |        ,ordervsprescription
      |        ,patientid
      |        ,encounterid
      |        ,rxid
      |        ,altmedcode
      |        ,discontinuedate
      |        ,LOCALDESCRIPTION
      |        ,localmedcode
      |        ,localndc
      |        ,orderstatus
      |        ,signature
      |        ,venue
      |        ,localdaw
      |        ,PatientsFlag
      |        ,MAX(Localdaysupplied)         AS Localdaysupplied
      |        ,MAX(localdosefreq)            AS localdosefreq
      |        ,MAX(localdoseunit)            AS localdoseunit
      |        ,MAX(localduration)            AS localduration
      |        ,MAX(localcategorycode)        AS localcategorycode
      |        ,MAX(localform)                AS localform
      |        ,MAX(localqtyofdoseunit)       AS localqtyofdoseunit
      |        ,MAX(Localroute)               AS localroute
      |        ,MAX(Localstrengthperdoseunit) AS Localstrengthperdoseunit
      |        ,CASE WHEN '{groupid}' = 'H772763' THEN issuedate ELSE Medreportedtime END as Medreportedtime
      |        ,Rxid as reportedmedid
      |        ,MAX(localstrengthunit)        AS localstrengthunit
      |        ,MAX(localinfusionrate)        AS localinfusionrate
      |        ,MAX(quantityperfill)          AS quantityperfill
      |        ,ROW_NUMBER() OVER (PARTITION BY groupid,client_ds_id,rxid ORDER BY altmedcode) rnum
      |        ,ordertype
      | FROM
      | (
      | 	SELECT  '{groupid}'                                                                                                                          AS groupid
      | 	       ,'oldrxmain'                                                                                                                          AS datasrc
      | 	       ,{client_ds_id}                                                                                                                       AS Client_Ds_Id
      | 	       ,rxmn.itemid                                                                                                                          AS itemid
      | 	       ,CASE WHEN enct.arrivaltime is not null THEN enct.arrivaltime WHEN rxmn.Startdate IS NOT NULL AND date_format(rxmn.Startdate,'yyyy-MM-dd') not IN ('1900-01-01','1901-01-01') THEN safe_to_date(rxmn.Startdate,'dd-MMM-yy') END AS issuedate
      | 	       ,'P'                                                                                                                                  AS ordervsprescription
      | 	       ,enct.Patientid                                                                                                                       AS patientid
      | 	       ,rxmn.Oldrxid                                                                                                                         AS rxid
      | 	       ,Coalesce(Rxmn.Ndc_Code ,Zh_Drugref.Multumid )                                                                                        AS Altmedcode
      | 	       ,CASE WHEN Rxdtl.Prop = '49' THEN CASE
      |                   when  rlike(hum_value,'^[0-9]+$') then Safe_To_Number(hum_value)
      |                   when  rlike(lower(hum_value),'day') then Safe_To_Number(nullif(regexp_extract(hum_value,'[0-9]+',0),''))
      |                   when  rlike(lower(hum_value),'we?e?k') then Safe_To_Number(nullif(regexp_extract(hum_value,'[0-9]+',0),''))*7
      |                   when  rlike(lower(hum_value),'mo') then Safe_To_Number(nullif(regexp_extract(hum_value,'[0-9]+',0),''))*30
      |                   when rlike(lower(hum_value),'ye?a?r') then Safe_To_Number(nullif(regexp_extract(hum_value,'[0-9]+',0),''))*365 end
      |            ELSE Null END AS Localdaysupplied
      | 	       ,CASE WHEN safe_to_date(rxmn.Stopdate,'yyyy-MM-dd') IS NOT NULL THEN safe_to_date(rxmn.Stopdate,'yyyy-MM-dd') ELSE NULL END AS discontinuedate
      | 	       ,Rxmn.Encounterid                                                                                                                     AS Encounterid
      | 	       ,CASE WHEN Rxdtl.Prop = '46' THEN rxdtl.Hum_Value
      |                WHEN Rxdtl.Prop = '52' THEN nullif(regexp_extract(lower(hum_value), '(qd|bid|tid|q ?(am|hs|pm)|daily|(in the )?(morning|evening)|bedtime|(every|twice a) day|as (directed|needed))', 0), '') ELSE Null END AS Localdosefreq
      | 	       ,CASE WHEN rxdtl.prop = '10613' THEN rxdtl.Hum_Value
      |                WHEN rxdtl.prop = '53' THEN nullif(regexp_extract(lower(hum_value),'[a-z]+',0),'') ELSE NULL END                                AS localdoseunit
      | 	       ,Zh_Items.Itemname                                                                                                                    AS localdescription
      | 	       ,CASE WHEN rxdtl.prop = '49' THEN rxdtl.Hum_Value ELSE NULL END                                                                       AS localduration
      | 	       ,CASE WHEN rxdtl.prop = '10613' THEN rxdtl.Hum_Value
      |                WHEN rxdtl.prop = '53' THEN nullif(regexp_extract(lower(rxdtl.hum_value),'[a-z]+',0),'') ELSE NULL END                          AS localform
      | 	       ,rxmn.Itemid                                                                                                                          AS localmedcode
      | 	       ,rxmn.Ndc_Code                                                                                                                        AS localndc
      | 	       ,CASE WHEN rxdtl.prop = '53' THEN nullif(regexp_extract(hum_value,'[0-9]+',0),'') ELSE Null END                                       AS Localqtyofdoseunit
      | 	       ,CASE WHEN Rxdtl.Prop = '47' THEN rxdtl.Hum_Value ELSE Null END                                                                       AS Localroute
      | 	       ,CASE WHEN rxdtl.prop = '51' THEN nullif(regexp_extract(hum_value,'[\\.[0-9]-,]+',0),'') ELSE NULL END                                AS localstrengthperdoseunit
      | 	       ,CASE WHEN rxdtl.prop = '51' THEN nullif(regexp_extract(lower(hum_value),'(mc?g|unit|meq|%)([^a-z]+(act|ml))?',0),'') ELSE Null END          AS Localstrengthunit
      | 	       ,concat_ws('','{client_ds_id}','.o.',Rxmn.Doctorsflag)                                                                                AS orderstatus
      | 	       ,rxmn.Rxnotes                                                                                                                         AS signature
      | 	       ,'1'                                                                                                                                  AS venue
      | 	       ,Rxmn.Patientsflag
      | 	       ,concat_ws('',{client_ds_id},'.',rxmn.Doctorsflag)                                                                                    AS localcategorycode
      | 	       ,CASE WHEN Rxmn.Startdate Is Not Null AND date_format(Rxmn.Startdate,'yyyy-MM-dd') not IN ( '1900-01-01','1901-01-01') AND Rxmn.Startdate < current_date THEN Rxmn.Startdate ELSE Enct.Arrivaltime END AS Medreportedtime
      | 	       ,CASE WHEN '{groupid}' = 'H458934' THEN CASE
      | 	             WHEN Rxmn.Doctorsflag = '10' THEN 'DAW' ELSE Null END ELSE NULL END                                                             AS Localdaw
      | 	       ,CASE WHEN '{groupid}' = 'H969977' THEN null ELSE CASE
      | 	             WHEN rxdtl.prop IN ('46','51','52') AND (lower(rxdtl.Hum_Value) like '%hr%' or lower (rxdtl.Hum_Value) like '%hour%') THEN rxdtl.Hum_Value ELSE NULL END END AS localinfusionrate
      | 	       ,CASE WHEN rxdtl.prop IN ('53') THEN nullif(regexp_extract(hum_value,'[0-9]+',0),'') ELSE NULL END AS quantityperfill
      | 	       ,'CH002047'                                                                                                                           AS ordertype
      | 	FROM RXMN
      | 	JOIN {CLINICALENCOUNTER} enct ON (rxmn.EncounterID = enct.EncounterID)
      | 	LEFT OUTER JOIN RXDTL ON (rxmn.Oldrxid = rxdtl.Oldrxid)
      | 	LEFT OUTER JOIN ZH_DRUGREF ON (rxmn.ItemID = Zh_DrugRef.ECWID)
      | 	LEFT OUTER JOIN ZH_ITEMS ON (rxmn.ItemID = zh_items.itemid)
      | 	WHERE Enct.Client_Ds_Id = {client_ds_id}
      | )
      | GROUP BY  Groupid
      |          ,Datasrc
      |          ,Client_Ds_Id
      |          ,Issuedate
      |          ,Ordervsprescription
      |          ,Patientid
      |          ,Encounterid
      |          ,Rxid
      |          ,Altmedcode
      |          ,Discontinuedate
      |          ,Localdescription
      |          ,Localmedcode
      |          ,Localndc
      |          ,Orderstatus
      |          ,Signature
      |          ,Venue
      |          ,localdaw
      |          ,PatientsFlag
      |          ,medreportedtime
      |          ,ordertype
      |)
    """.stripMargin
      .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)


}

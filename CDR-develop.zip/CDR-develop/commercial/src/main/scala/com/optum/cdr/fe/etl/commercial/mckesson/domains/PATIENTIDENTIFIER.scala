package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.patient_id

object PATIENTIDENTIFIER extends FEQueryAndMetadata[patient_id]{
  override def name: String = CDRFEParquetNames.patient_id

  override def dependsOn: Set[String] = Set("MCKESSON_ENT_PATIENT")

  override def sparkSql: String =
    """
      |WITH uni_pat AS
      |(SELECT * FROM (
      |(SELECT Cpi_Seq, Soc_Sec_No, Patient_Id,
      |             ROW_NUMBER() OVER (PARTITION BY cpi_seq ORDER BY modified_dt DESC NULLS FIRST) rn
      |      FROM MCKESSON_ENT_PATIENT
      |      WHERE Cpi_Seq IS NOT NULL  )
      |) WHERE rn = 1)
      |select 'ent_patient' as datasrc, patientid, idtype, idvalue
      |from
      |(
      |SELECT Cpi_Seq AS patientid, idtype, idvalue
      |from
      |(
      |select * from
      |(
      |select unpivot_base.*,
      |stack(2,Soc_Sec_No,'SSN',Patient_Id,'ALTPATID') as (idvalue, idtype)
      |from
      |UNI_PAT unpivot_base
      |)
      |where idvalue is not null
      |)
      |)
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.observation

object OBSERVATION extends FEQueryAndMetadata[observation]{
  override def name: String = CDRFEParquetNames.observation

  override def dependsOn: Set[String] = Set("OBSERVATION_TMA100_CLINICAL_DOC","OBSERVATION_TPM300_PAT_VISIT")

  override def sparkSql: String =
    """
      |SELECT * FROM OBSERVATION_TMA100_CLINICAL_DOC
      |UNION ALL
      |SELECT * FROM OBSERVATION_TPM300_PAT_VISIT
    """.stripMargin

}

package com.optum.cdr.fe.etl.commercial.med3000.domains


import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object FACILITY extends FEQueryAndMetadata[zh_facility] {

  override def name: String = CDRFEParquetNames.zh_facility

  override def dependsOn: Set[String] = Set("MED3000_ZH_LOCATION")

  override def sparkSql: String =
    """select groupid, client_ds_id, facilityid, facilityname, facilitypostalcd, npi
      |from
      |(
      |select '{groupid}' 		as groupid
      |       ,'location' 		as datasrc
      |       ,{client_ds_id}  	as client_ds_id
      |       ,loc.Record_No  	as facilityid
      |       ,loc.Description  	     as facilityname
      |       ,nullif(replace(loc.Zip,'-',''), '')	 as facilitypostalcd
      |       ,loc.Npi  			     as npi
      |	   ,row_number() over (partition by loc.Record_No order by update_date desc nulls last) as rank_fac
      |  from MED3000_ZH_LOCATION loc
      |
      |
      |)
      |where rank_fac = 1 and facilityid is not null""".stripMargin
}

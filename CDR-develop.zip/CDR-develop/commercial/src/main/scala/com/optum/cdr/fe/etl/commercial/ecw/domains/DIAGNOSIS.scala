package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object DIAGNOSIS extends FETableInfo[diagnosis]{

  override def name: String = CDRFEParquetNames.diagnosis

  override def dependsOn: Set[String] = Set("INPUT_DIAGNOSIS", "ZH_ITEMS", "EDI_INVOICE", "EDI_INV_DIAGNOSIS", "EDI_INV_CPT", "PROBLEMLIST", "ZH_ITEMDETAIL",CDRFEParquetNames.clinicalencounter)

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    
    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val clinicalencounterTabJoin = if (runtimeVar.groupId.equals("H458934")) "inner join {CLINICALENCOUNTER} c ON (problemlist.encounterid = c.encounterid and c.client_ds_id = {client_ds_id})"
                                     else "left outer join {CLINICALENCOUNTER} c ON (problemlist.encounterid = c.encounterid and c.client_ds_id = {client_ds_id})"

    sparkSession.sql(
      """
        |WITH dedup_inv AS (
        |  SELECT  *
        |  FROM
        |  (
        |    SELECT  i.*
        |          ,ROW_NUMBER() OVER (PARTITION BY id ORDER BY modifydate DESC nulls last) rn
        |    FROM EDI_INVOICE i
        |    WHERE deleteflag <> '1'
        |  )
        |  WHERE rn = 1
        |),
        |dedup_diag AS (
        |    SELECT  *
        |    FROM
        |    (
        |        SELECT  c.*
        |            ,concat_ws('',c.invoiceid,'.',c.icdorder) AS invdxlink
        |            ,zh_items.supplierid
        |            ,ROW_NUMBER() OVER (PARTITION BY c.id,c.itemid ORDER BY c.modifieddate DESC nulls last) rn
        |        FROM EDI_INV_DIAGNOSIS c
        |        JOIN ZH_ITEMS
        |        ON (c.itemid = zh_items.itemid)
        |    )
        |    WHERE rn = 1
        |),
        |pivot_cpt AS (
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  unpivot_base.*
        |		       ,stack(4,invicd1,'1',invicd2,'2',invicd3,'3',invicd4,'4') AS (invdxlink,dx_order)
        |		FROM
        |		(
        |			SELECT  *
        |			FROM
        |			(
        |				SELECT  a.invoiceid
        |				       ,a.id
        |				       ,a.itemid
        |				       ,a.code
        |				       ,COALESCE(nullif(regexp_extract(revcodeid,'([0-9])+',0),''),nullif(regexp_extract(revcode,'([0-9])+',0),'')) AS rev_code
        |				       ,a.icd1
        |				       ,a.icd2
        |				       ,a.icd3
        |				       ,a.icd4
        |				       ,CASE WHEN icd1 is not null THEN concat_ws('',invoiceid,'.',icd1) ELSE null END                              AS invicd1
        |				       ,CASE WHEN icd2 is not null THEN concat_ws('',invoiceid,'.',icd2) ELSE null END                              AS invicd2
        |				       ,CASE WHEN icd3 is not null THEN concat_ws('',invoiceid,'.',icd3) ELSE null END                              AS invicd3
        |				       ,CASE WHEN icd4 is not null THEN concat_ws('',invoiceid,'.',icd4) ELSE null END                              AS invicd4
        |				       ,ROW_NUMBER() OVER (PARTITION BY nullif(concat_ws('',id,invoiceid),'') ORDER BY modifieddate DESC nulls last) rn
        |				FROM EDI_INV_CPT a
        |				WHERE deleteflag <> 1
        |			)
        |			WHERE rn = 1
        |		) unpivot_base
        |	)
        |	WHERE invdxlink is not null
        |)
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,patientid
        |       ,encounterid
        |       ,dx_timestamp
        |       ,localdiagnosis
        |       ,primarydiagnosis
        |       ,mappeddiagnosis
        |       ,codetype
        |       ,SOURCEID
        |       ,null as facilityid
        |       ,null as hosp_dx_flag
        |       ,null as localactiveind
        |       ,null as localdiagnosisstatus
        |       ,null as localdiagnosisproviderid
        |       ,null as resolutiondate
        |FROM
        |(
        |	SELECT  a.*
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                      AS groupid
        |		       ,'diagnosis'                                                      AS datasrc
        |		       ,{client_ds_id}                                                   AS client_ds_id
        |		       ,diagnosis.encounterid                                            AS encounterid
        |		       ,c.arrivaltime                                                    AS dx_timestamp
        |		       ,Diagnosis.Itemid                                                 AS localdiagnosis
        |		       ,c.Patientid                                                      AS patientid
        |		       ,CASE WHEN Diagnosis.supplierid = '10' THEN 'ICD10' ELSE NULL END AS codetype
        |		       ,NULL                                                             AS facilityid
        |		       ,Diagnosis.Primaryasmt                                            AS primarydiagnosis
        |		       ,Zh_Itemdetail.Value                                              AS mappeddiagnosis
        |		       ,Diagnosis.Encounterid                                            AS SOURCEID
        |		       ,ROW_NUMBER() OVER (PARTITION BY c.patientid,c.arrivaltime,diagnosis.encounterid,Diagnosis.Itemid ORDER BY diagnosis.modifieddate DESC NULLS LAST) AS rn
        |		FROM
        |		(
        |			SELECT  d.*
        |			       ,zh_items.Supplierid
        |			FROM INPUT_DIAGNOSIS d
        |			JOIN ZH_ITEMS ON (d.itemid = zh_items.itemid)
        |		) Diagnosis
        |		JOIN {CLINICALENCOUNTER} c ON (diagnosis.encounterid = c.encounterid AND c.client_ds_id = {client_ds_id})
        |		LEFT OUTER JOIN ZH_ITEMDETAIL ON (Diagnosis.ItemID = Zh_ItemDetail.ItemID AND Zh_ItemDetail.PropID = '13')
        |	) a
        |	WHERE rn = 1
        |)
        |WHERE dx_timestamp IS NOT NULL
        |
        |
        |UNION ALL
        |
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,patientid
        |       ,encounterid
        |       ,dx_timestamp
        |       ,localdiagnosis
        |       ,primarydiagnosis
        |       ,mappeddiagnosis
        |       ,codetype
        |       ,SOURCEID
        |       ,facilityid
        |       ,hosp_dx_flag
        |       ,null as localactiveind
        |       ,null as localdiagnosisstatus
        |       ,null as localdiagnosisproviderid
        |       ,null as resolutiondate
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                                                 AS groupid
        |	       ,'edi_inv_diagnosis'                                                                                         AS datasrc
        |	       ,{client_ds_id}                                                                                              AS client_ds_id
        |	       ,dedup_inv.Servicedt                                                                                         AS dx_timestamp
        |	       ,dedup_diag.Itemid                                                                                           AS localdiagnosis
        |	       ,dedup_inv.Patientid                                                                                         AS patientid
        |	       ,CASE WHEN dedup_diag.supplierid = '10' THEN 'ICD10' ELSE NULL END                                           AS codetype
        |	       ,dedup_inv.Encounterid                                                                                       AS encounterid
        |	       ,dedup_inv.Invfacilityid                                                                                     AS facilityid
        |	       ,dedup_diag.Primarycode                                                                                      AS primarydiagnosis
        |	       ,dedup_diag.Code                                                                                             AS mappeddiagnosis
        |	       ,CASE WHEN LENGTH(pivot_cpt.rev_code) = 3 THEN 'Y'
        |	             WHEN LENGTH(pivot_cpt.rev_code) = 4 THEN 'Y' ELSE 'N' END                                              AS hosp_dx_flag
        |	       ,CASE WHEN pivot_cpt.invoiceid is not null THEN concat_ws('',dedup_inv.Patientid,'.',pivot_cpt.invoiceid,'.',pivot_cpt.id)
        |	             WHEN pivot_cpt.invoiceid is null THEN concat_ws('',dedup_inv.Patientid,'.',dedup_inv.id) ELSE null END AS sourceid
        |	       ,ROW_NUMBER() OVER (PARTITION BY dedup_inv.patientid,dedup_inv.Servicedt,dedup_inv.encounterid,dedup_diag.Itemid,dedup_inv.id ,pivot_cpt.id ORDER BY dedup_inv.modifydate DESC NULLS LAST) AS rn
        |	FROM DEDUP_INV
        |	JOIN {CLINICALENCOUNTER} c
        |	ON (dedup_inv.encounterid = c.encounterid AND c.client_ds_id = {client_ds_id})
        |	JOIN DEDUP_DIAG
        |	ON (dedup_diag.invoiceid = dedup_inv.id)
        |	LEFT OUTER JOIN PIVOT_CPT
        |	ON dedup_diag.invoiceid = pivot_cpt.invoiceid AND dedup_diag.invdxlink = pivot_cpt.invdxlink
        |)
        |WHERE rn = 1
        |AND dx_timestamp IS NOT NULL
        |
        |
        |UNION ALL
        |
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,patientid
        |       ,encounterid
        |       ,dx_timestamp
        |       ,localdiagnosis
        |       ,null as primarydiagnosis
        |       ,mappeddiagnosis
        |       ,codetype
        |       ,null as SOURCEID
        |       ,null as facilityid
        |       ,null as hosp_dx_flag
        |       ,localactiveind
        |       ,localdiagnosisstatus
        |       ,localdiagnosisproviderid
        |       ,resolutiondate
        |FROM
        |(
        |	SELECT  a.*
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                      AS groupid
        |		       ,'problemlist'                                                                    AS datasrc
        |		       ,{client_ds_id}                                                                   AS client_ds_id
        |		       ,safe_to_date_length(coalesce(Problemlist.Addeddate,Problemlist.Logdate),'MM/dd/yyyy',0) AS dx_timestamp
        |		       ,Problemlist.Asmtid                                                               AS localdiagnosis
        |		       ,Problemlist.Patientid                                                            AS patientid
        |		       ,CASE WHEN problemlist.supplierid = '10' THEN 'ICD10' ELSE NULL END               AS codetype
        |		       ,CASE WHEN problemlist.resolved = '1' THEN 'Resolved'
        |		             WHEN problemlist.inactiveflag = '1' THEN 'Inactive' ELSE 'Active' END       AS localactiveind
        |		       ,Problemlist.Encounterid                                                          AS encounterid
        |		       ,Problemlist.Wustatus                                                             AS localdiagnosisstatus
        |		       ,Problemlist.Userid                                                               AS localdiagnosisproviderid
        |		       ,safe_to_date(problemlist.resolvedon,'MM/dd/yyyy')                                AS resolutiondate
        |		       ,Zh_Itemdetail.Value                                                              AS mappeddiagnosis
        |		       ,problemlist.deleteflag
        |		       ,problemlist.wustatus
        |		       ,ROW_NUMBER() OVER (PARTITION BY problemlist.slno ORDER BY problemlist.modifieddate DESC NULLS LAST) rn
        |		FROM
        |		(
        |			SELECT  p.*
        |			       ,zh_items.supplierid
        |			FROM PROBLEMLIST p
        |			JOIN ZH_ITEMS
        |			ON (p.asmtid = zh_items.itemid)
        |			WHERE p.DELETEFLAG <> '1'
        |			AND NVL(p.WUSTATUS, 'null') <> 'erroneous Dx'
        |		) problemlist
        |  {clinicalencounter_tab_join}
        |		LEFT OUTER JOIN ZH_ITEMDETAIL
        |		ON (PROBLEMLIST.ASMTID = ZH_ITEMDETAIL.ITEMID AND Zh_ItemDetail.PropID = '13')
        |	) a
        |	WHERE rn = 1
        |)
        |WHERE DELETEFLAG <> '1'
        |AND dx_timestamp IS NOT NULL
      """.stripMargin
        .replace("{clinicalencounter_tab_join}", clinicalencounterTabJoin)
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }
}

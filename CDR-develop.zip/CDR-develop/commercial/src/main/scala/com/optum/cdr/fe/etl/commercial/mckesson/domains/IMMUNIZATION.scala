package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.immunization
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader, CDRFEParquetNames}
import org.apache.spark.sql.{DataFrame, SparkSession}

object IMMUNIZATION extends FETableInfo[immunization] {
  override def name: String = CDRFEParquetNames.immunization

  override def dependsOn: Set[String] = Set("MCKESSON_HHS_CPI_IMMUNIZATION", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val exclStatus = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "HHS_CPI_IMMUNIZATION", "IMMUNIZATION", "HHS_CPI_IMMUNIZATION", "IMM_STATUS_LSEQ").mkString(",")

    sparkSession.sql(s"""
                        SELECT
                          datasrc,
                          localimmunizationcd,
                          patientid,
                          admindate,
                          documenteddate,
                          encounterid,
                          localimmunizationdesc,
                          localroute,
                          NVL2(localdeferredreason, CONCAT_WS('', $clientDsId, '.', localdeferredreason), NULL) as localdeferredreason
                        FROM
                        (
                        SELECT 'hhs_cpi_immunization' AS datasrc
                        	,Vaccine_Code               AS localimmunizationcd
                        	,cpi_seq                    AS patientid
                        	,COALESCE(Confirmed_Dt, Refused_Dt, Created_Dt) AS documenteddate
                        	,Confirmed_Pat_Seq          AS encounterid
                        	,CASE WHEN COALESCE(Imm_Contraindicated_Lseq, Imm_Deferred_Reason_Lseq, Imm_Refusal_Reason_Lseq) IS NULL
                                      THEN nvl2(refused_dt,'Refused',NULL)
                                      ELSE COALESCE(Imm_Contraindicated_Lseq, Imm_Deferred_Reason_Lseq, Imm_Refusal_Reason_Lseq)
                                 END                  AS localdeferredreason
                        	,vaccine_name               AS localimmunizationdesc
                        	,Imm_Route_Lseq             AS localroute
                        	,Administered_Dt            AS admindate
                        	,Inactive_Error_Fl
                        	,ROW_NUMBER() OVER (PARTITION BY cpi_seq, Administered_Dt, Confirmed_Pat_Seq, Vaccine_Code
                        	              ORDER BY modified_dt DESC NULLS LAST) AS rn
                        FROM MCKESSON_HHS_CPI_IMMUNIZATION
                        WHERE cpi_seq IS NOT NULL
                          AND imm_status_lseq NOT IN ($exclStatus)
                          AND nvl(Administered_Dt, current_date)  >= to_date('01011900', 'MMddyyyy')

                        )
                        WHERE  Inactive_Error_Fl <> 'Y' AND rn = 1
    """.stripMargin)
  }

}

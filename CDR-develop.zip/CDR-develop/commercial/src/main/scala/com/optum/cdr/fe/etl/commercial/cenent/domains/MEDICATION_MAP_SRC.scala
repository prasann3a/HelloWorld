package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.utils.verify.MedicationMapSrcVerify
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC extends FETableInfo[medication_map_src] {

  override def name: String = CDRFEParquetNames.medication_map_src

  override def dependsOn: Set[String] = Set("MEDICATION_MAP_SRC_ORDERZ", "MEDICATION_MAP_SRC_PROBLM", "MEDICATION_MAP_SRC_SERVCE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val srcMedMapInput = sparkSession.sql(
      """
         select * from MEDICATION_MAP_SRC_ORDERZ
         union all
         select * from MEDICATION_MAP_SRC_PROBLM
         union all
         select * from MEDICATION_MAP_SRC_SERVCE
      """.stripMargin
    )

    MedicationMapSrcVerify.run(srcMedMapInput)

  }

}
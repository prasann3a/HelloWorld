package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.cdr.fe.utils.nonnumeric_labs_localresult_25.NONNUMERIC_LABRESULT
import com.optum.oap.cdr.models.{map_predicate_values,zcm_obstype_code,map_unit,unit_remap,metadata_lab,unit_conversion,map_prov_contact_type,map_custom_proc}
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object MckessonPgnQueries extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries
}

object MckessonPgnQueriesWithDrugAssign extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries ++ QueryRegistry.drug_assign_queries
}

object InitialDependencies {
  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      FELoadFromParquet[t_laboratory_results](name = "MCKESSON_PGN_V1_T_LABORATORY_RESULTS", parquetLocation = s"$baseParquetLocation", tableName = "T_LABORATORY_RESULTS"),
      FELoadFromParquet[t_ptdata](name = "MCKESSON_PGN_V1_T_PTDATA", parquetLocation = s"$baseParquetLocation", tableName = "T_PTDATA"),
      FELoadFromParquet[t_ptheight](name = "MCKESSON_PGN_V1_T_PTHEIGHT", parquetLocation = s"$baseParquetLocation", tableName = "T_PTHEIGHT"),
      FELoadFromParquet[t_ptvitails](name = "MCKESSON_PGN_V1_T_PTVITAILS", parquetLocation = s"$baseParquetLocation", tableName = "T_PTVITAILS"),
      FELoadFromParquet[t_ptweight](name = "MCKESSON_PGN_V1_T_PTWEIGHT", parquetLocation = s"$baseParquetLocation", tableName = "T_PTWEIGHT"),
      FELoadFromParquet[tif120_gen_result](name = "MCKESSON_PGN_V1_TIF120_GEN_RESULT", parquetLocation = s"$baseParquetLocation", tableName = "TIF120_GEN_RESULT"),
      FELoadFromParquet[tcp500_rx_ads](name = "MCKESSON_PGN_V1_TCP500_RX_ADS", parquetLocation = s"$baseParquetLocation", tableName = "TCP500_RX_ADS"),
      FELoadFromParquet[tcp540_rx_ads_info](name = "MCKESSON_PGN_V1_TCP540_RX_ADS_INFO", parquetLocation = s"$baseParquetLocation", tableName = "TCP540_RX_ADS_INFO"),
      FELoadFromParquet[ted100_ed_visit](name = "MCKESSON_PGN_V1_TED100_ED_VISIT", parquetLocation = s"$baseParquetLocation", tableName = "TED100_ED_VISIT"),
      FELoadFromParquet[ted101_triage](name = "MCKESSON_PGN_V1_TED101_TRIAGE", parquetLocation = s"$baseParquetLocation", tableName = "TED101_TRIAGE"),
      FELoadFromParquet[tmc100_med_rcn_hdr](name = "MCKESSON_PGN_V1_TMC100_MED_RCN_HDR", parquetLocation = s"$baseParquetLocation", tableName = "TMC100_MED_RCN_HDR"),
      FELoadFromParquet[tom100_order_header](name = "MCKESSON_PGN_V1_TOM100_ORDER_HEADER", parquetLocation = s"$baseParquetLocation", tableName = "TOM100_ORDER_HEADER"),
      FELoadFromParquet[tom101_order_detail](name = "MCKESSON_PGN_V1_TOM101_ORDER_DETAIL", parquetLocation = s"$baseParquetLocation", tableName = "TOM101_ORDER_DETAIL"),
      FELoadFromParquet[trd100_reqseq_event](name = "MCKESSON_PGN_V1_TRD100_REQSEQ_EVENT", parquetLocation = s"$baseParquetLocation", tableName = "TRD100_REQSEQ_EVENT"),
      FELoadFromParquet[tom107_child_order](name = "MCKESSON_PGN_V1_TOM107_CHILD_ORDER", parquetLocation = s"$baseParquetLocation", tableName = "TOM107_CHILD_ORDER"),
      FELoadFromParquet[tsm020_address](name = "MCKESSON_PGN_V1_TSM020_ADDRESS", parquetLocation = s"$baseParquetLocation", tableName = "TSM020_ADDRESS"),
      FELoadFromParquet[tsm021_ent_adr](name = "MCKESSON_PGN_V1_TSM021_ENT_ADR", parquetLocation = s"$baseParquetLocation", tableName = "TSM021_ENT_ADR"),
      FELoadFromParquet[tsm042_psn_care_giver](name = "MCKESSON_PGN_V1_TSM042_PSN_CARE_GIVER", parquetLocation = s"$baseParquetLocation", tableName = "TSM042_PSN_CARE_GIVER"),
      FELoadFromParquet[tsm255_person_allergy](name = "MCKESSON_PGN_V1_TSM255_PERSON_ALLERGY", parquetLocation = s"$baseParquetLocation", tableName = "TSM255_PERSON_ALLERGY"),
      FELoadFromParquet[tsm261_psn_home_meds](name = "MCKESSON_PGN_V1_TSM261_PSN_HOME_MEDS", parquetLocation = s"$baseParquetLocation", tableName = "TSM261_PSN_HOME_MEDS"),
      FELoadFromParquet[tsm040_person_hdr](name = "MCKESSON_PGN_V1_TSM040_PERSON_HDR", parquetLocation = s"$baseParquetLocation", tableName = "TSM040_PERSON_HDR"),
      FELoadFromParquet[tsm047_adv_dir_hdr](name = "MCKESSON_PGN_V1_TSM047_ADV_DIR_HDR", parquetLocation = s"$baseParquetLocation", tableName = "TSM047_ADV_DIR_HDR"),
      FELoadFromParquet[tsm060_phone](name = "MCKESSON_PGN_V1_TSM060_PHONE", parquetLocation = s"$baseParquetLocation", tableName = "TSM060_PHONE"),
      FELoadFromParquet[tpm300_pat_visit](name = "MCKESSON_PGN_V1_TPM300_PAT_VISIT", parquetLocation = s"$baseParquetLocation", tableName = "TPM300_PAT_VISIT"),
      FELoadFromParquet[tpb105_charge_detail](name = "MCKESSON_PGN_V1_TPB105_CHARGE_DETAIL", parquetLocation = s"$baseParquetLocation", tableName = "TPB105_CHARGE_DETAIL"),
      FELoadFromParquet[zh_tsm910_icd9_ref](name = "MCKESSON_PGN_V1_ZH_TSM910_ICD9_REF", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TSM910_ICD9_REF"),
      FELoadFromParquet[tpm317_visit_procedure](name = "MCKESSON_PGN_V1_TPM317_VISIT_PROCEDURE", parquetLocation = s"$baseParquetLocation", tableName = "TPM317_VISIT_PROCEDURE"),
      FELoadFromParquet[tpm318_visit_diagnosis](name = "MCKESSON_PGN_V1_TPM318_VISIT_DIAGNOSIS", parquetLocation = s"$baseParquetLocation", tableName = "TPM318_VISIT_DIAGNOSIS"),
      FELoadFromParquet[tpm319_visit_cpt4](name = "MCKESSON_PGN_V1_TPM319_VISIT_CPT4", parquetLocation = s"$baseParquetLocation", tableName = "TPM319_VISIT_CPT4"),
      FELoadFromParquet[tpp310_pbm_lst](name = "MCKESSON_PGN_V1_TPP310_PBM_LST", parquetLocation = s"$baseParquetLocation", tableName = "TPP310_PBM_LST"),
      FELoadFromParquet[trs601_event_schedules](name = "MCKESSON_PGN_V1_TRS601_EVENT_SCHEDULES", parquetLocation = s"$baseParquetLocation", tableName = "TRS601_EVENT_SCHEDULES"),
      FELoadFromParquet[zh_trs200_resource](name = "MCKESSON_PGN_V1_ZH_TRS200_RESOURCE", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TRS200_RESOURCE"),
      FELoadFromParquet[trs603_event_resource_sched](name = "MCKESSON_PGN_V1_TRS603_EVENT_RESOURCE_SCHED", parquetLocation = s"$baseParquetLocation", tableName = "TRS603_EVENT_RESOURCE_SCHED"),
      FELoadFromParquet[trs600_master_schedules](name = "MCKESSON_PGN_V1_TRS600_MASTER_SCHEDULES", parquetLocation = s"$baseParquetLocation", tableName = "TRS600_MASTER_SCHEDULES"),
      FELoadFromParquet[zh_tsm180_mst_cod_dtl](name = "MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TSM180_MST_COD_DTL"),
      FELoadFromParquet[tpm311_visit_payor](name = "MCKESSON_PGN_V1_TPM311_VISIT_PAYOR", parquetLocation = s"$baseParquetLocation", tableName = "TPM311_VISIT_PAYOR"),
      FELoadFromParquet[zh_tas915_measurement](name = "MCKESSON_PGN_V1_ZH_TAS915_MEASUREMENT", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TAS915_MEASUREMENT"),
      FELoadFromParquet[zh_tor750_med_iv](name = "MCKESSON_PGN_V1_ZH_TOR750_MED_IV", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TOR750_MED_IV"),
      FELoadFromParquet[zh_tom200_order_code](name = "MCKESSON_PGN_V1_ZH_TOM200_ORDER_CODE", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TOM200_ORDER_CODE"),
      FELoadFromParquet[zh_tpm700_payor_plan](name = "MCKESSON_PGN_V1_ZH_TPM700_PAYOR_PLAN", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TPM700_PAYOR_PLAN"),
      FELoadFromParquet[zh_tpb900_chg_code_ms](name = "MCKESSON_PGN_V1_ZH_TPB900_CHG_CODE_MS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TPB900_CHG_CODE_MS"),
      FELoadFromParquet[zh_tsm911_cpt4_ref](name = "MCKESSON_PGN_V1_ZH_TSM911_CPT4_REF", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TSM911_CPT4_REF"),
      FELoadFromParquet[zh_tlb800_test_code_mst](name = "MCKESSON_PGN_V1_ZH_TLB800_TEST_CODE_MST", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TLB800_TEST_CODE_MST"),
      FELoadFromParquet[zh_t_grpmst](name = "MCKESSON_PGN_V1_ZH_T_GRPMST", parquetLocation = s"$baseParquetLocation", tableName = "ZH_T_GRPMST"),
      FELoadFromParquet[zh_t_fndmst](name = "MCKESSON_PGN_V1_ZH_T_FNDMST", parquetLocation = s"$baseParquetLocation", tableName = "ZH_T_FNDMST"),
      FELoadFromParquet[zh_t_catmst](name = "MCKESSON_PGN_V1_ZH_T_CATMST", parquetLocation = s"$baseParquetLocation", tableName = "ZH_T_CATMST"),
      FELoadFromParquet[zh_trx580_route](name = "MCKESSON_PGN_V1_ZH_TRX580_ROUTE", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TRX580_ROUTE"),
      FELoadFromParquet[zh_trx800_item_inventory](name = "MCKESSON_PGN_V1_ZH_TRX800_ITEM_INVENTORY", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TRX800_ITEM_INVENTORY"),
      FELoadFromParquet[zh_trx870_ndc](name = "MCKESSON_PGN_V1_ZH_TRX870_NDC", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TRX870_NDC"),
      FELoadFromParquet[trx100_therapy_order](name = "MCKESSON_PGN_V1_TRX100_THERAPY_ORDER", parquetLocation = s"$baseParquetLocation", tableName = "TRX100_THERAPY_ORDER"),
      FELoadFromParquet[trx101_therapy_item](name = "MCKESSON_PGN_V1_TRX101_THERAPY_ITEM", parquetLocation = s"$baseParquetLocation", tableName = "TRX101_THERAPY_ITEM"),
      FELoadFromParquet[tpp341_substance_hx](name = "MCKESSON_PGN_V1_TPP341_SUBSTANCE_HX", parquetLocation = s"$baseParquetLocation", tableName = "TPP341_SUBSTANCE_HX"),
      FELoadFromParquet[tpp350_immunization_hx](name = "MCKESSON_PGN_V1_TPP350_IMMUNIZATION_HX", parquetLocation = s"$baseParquetLocation", tableName = "TPP350_IMMUNIZATION_HX"),
      FELoadFromParquet[tpp380_pat_education](name = "MCKESSON_PGN_V1_TPP380_PAT_EDUCATION", parquetLocation = s"$baseParquetLocation", tableName = "TPP380_PAT_EDUCATION"),
      FELoadFromParquet[tpw100_ord_hdr](name = "MCKESSON_PGN_V1_TPW100_ORD_HDR", parquetLocation = s"$baseParquetLocation", tableName = "TPW100_ORD_HDR"),
      FELoadFromParquet[tpw102_ord_dtl](name = "MCKESSON_PGN_V1_TPW102_ORD_DTL", parquetLocation = s"$baseParquetLocation", tableName = "TPW102_ORD_DTL"),
      FELoadFromParquet[tpw120_rx_dtl](name = "MCKESSON_PGN_V1_TPW120_RX_DTL", parquetLocation = s"$baseParquetLocation", tableName = "TPW120_RX_DTL"),
      FELoadFromParquet[tmr410_visit_drg](name = "MCKESSON_PGN_V1_TMR410_VISIT_DRG", parquetLocation = s"$baseParquetLocation", tableName = "TMR410_VISIT_DRG"),
      FELoadFromParquet[tpm100_care_giver](name = "MCKESSON_PGN_V1_TPM100_CARE_GIVER", parquetLocation = s"$baseParquetLocation", tableName = "TPM100_CARE_GIVER"),
      FELoadFromParquet[tpm330_visit_event](name = "MCKESSON_PGN_V1_TPM330_VISIT_EVENT", parquetLocation = s"$baseParquetLocation", tableName = "TPM330_VISIT_EVENT"),
      FELoadFromParquet[zh_tsm950_location_ref](name = "MCKESSON_PGN_V1_ZH_TSM950_LOCATION_REF", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TSM950_LOCATION_REF"),
      FELoadFromParquet[tpm114_car_gvr_func](name = "MCKESSON_PGN_V1_TPM114_CAR_GVR_FUNC", parquetLocation = s"$baseParquetLocation", tableName = "TPM114_CAR_GVR_FUNC"),
      FELoadFromParquet[tpm115_car_gvr_lic](name = "MCKESSON_PGN_V1_TPM115_CAR_GVR_LIC", parquetLocation = s"$baseParquetLocation", tableName = "TPM115_CAR_GVR_LIC"),
      FELoadFromParquet[tpm315_visit_care_giver](name = "MCKESSON_PGN_V1_TPM315_VISIT_CARE_GIVER", parquetLocation = s"$baseParquetLocation", tableName = "TPM315_VISIT_CARE_GIVER"),
      FELoadFromParquet[tma100_clinical_doc](name = "MCKESSON_PGN_V1_TMA100_CLINICAL_DOC", parquetLocation = s"$baseParquetLocation", tableName = "TMA100_CLINICAL_DOC"),
      FELoadFromParquet[tsm030_organization](name = "MCKESSON_PGN_V1_TSM030_ORGANIZATION", parquetLocation = s"$baseParquetLocation", tableName = "TSM030_ORGANIZATION"),
      FELoadFromParquet[zh_tsm015_entity](name = "MCKESSON_PGN_V1_ZH_TSM015_ENTITY", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TSM015_ENTITY"),
      FELoadFromParquet[tlb200_lab_ord_dtl](name = "MCKESSON_PGN_V1_TLB200_LAB_ORD_DTL", parquetLocation = s"$baseParquetLocation", tableName = "TLB200_LAB_ORD_DTL"),
      FELoadFromParquet[tlb240_lab_ord_dtl_cmt](name = "MCKESSON_PGN_V1_TLB240_LAB_ORD_DTL_CMT", parquetLocation = s"$baseParquetLocation", tableName = "TLB240_LAB_ORD_DTL_CMT"),
      FELoadFromParquet[tlb280_reflab_dtl](name = "MCKESSON_PGN_V1_TLB280_REFLAB_DTL", parquetLocation = s"$baseParquetLocation", tableName = "TLB280_REFLAB_DTL"),
      FELoadFromParquet[tlb290_labresult_dtl](name = "MCKESSON_PGN_V1_TLB290_LABRESULT_DTL", parquetLocation = s"$baseParquetLocation", tableName = "TLB290_LABRESULT_DTL"),
      FELoadFromParquet[tmb875_specimen_source_master](name = "MCKESSON_PGN_V1_TMB875_SPECIMEN_SOURCE_MASTER", parquetLocation = s"$baseParquetLocation", tableName = "TMB875_SPECIMEN_SOURCE_MASTER"),
      FELoadFromParquet[tmb300_micro_ord_dtl](name = "MCKESSON_PGN_V1_TMB300_MICRO_ORD_DTL", parquetLocation = s"$baseParquetLocation", tableName = "TMB300_MICRO_ORD_DTL"),
      FELoadFromParquet[tmb305_micro_ord_suscept_dtl](name = "MCKESSON_PGN_V1_TMB305_MICRO_ORD_SUSCEPT_DTL", parquetLocation = s"$baseParquetLocation", tableName = "TMB305_MICRO_ORD_SUSCEPT_DTL"),
      FELoadFromParquet[tmb820_category_interpretation](name = "MCKESSON_PGN_V1_TMB820_CATEGORY_INTERPRETATION", parquetLocation = s"$baseParquetLocation", tableName = "TMB820_CATEGORY_INTERPRETATION"),

      FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PREDICATE_VALUES"),
      FELoadFromParquet[map_custom_proc](name = "MAP_CUSTOM_PROC", parquetLocation = s"$mappingParquetPath", tableName = "MAP_CUSTOM_PROC"),
      FELoadFromParquet[zcm_obstype_code](name = "ZCM_OBSTYPE_CODE", parquetLocation = s"$mappingParquetPath", tableName = "ZCM_OBSTYPE_CODE"),
      FELoadFromParquet[map_unit](name = "MAP_UNIT", parquetLocation = s"$mappingParquetPath", tableName = "MAP_UNIT"),
      FELoadFromParquet[unit_remap](name = "UNIT_REMAP", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_REMAP"),
      FELoadFromParquet[metadata_lab](name = "METADATA_LAB", parquetLocation = s"$mappingParquetPath", tableName = "METADATA_LAB"),
      FELoadFromParquet[unit_conversion](name = "UNIT_CONVERSION", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_CONVERSION"),
      FELoadFromParquet[map_prov_contact_type](name = "MAP_PROV_CONTACT_TYPE", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PROV_CONTACT_TYPE")

  )
}

object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    ALLERGY
    , DIAGNOSIS
    , APPOINTMENT
    , ZH_APPT_LOCATION
    , INSURANCE
    , IMMUNIZATION
    , CLINICALENCOUNTER
    , ENCOUNTERCAREAREA
    , ENCOUNTERPROVIDER
    , PATIENTADDRESS
    , TEMP_PATIENT_CACHE
    , PATIENT
    , PATIENT_ID
    , PATIENTDETAIL
    , ZH_SERVICE_LINE
    , PATIENTCONTACT
    , RXORDERSANDPRESCRIPTIONS
    , RXORDERSANDPRESCRIPTIONS_TEMP_TPM300_PAT_VISIT
    , RXORDERSANDPRESCRIPTIONS_TEMP_TPW102_ORD_DTL
    , OBSERVATION_CACHE_TMA100_CLINICAL_DOC
    , OBSERVATION_CACHE_TPM300_PAT_VISIT
    , OBSERVATION
    , OBSERVATION_TMA100_CLINICAL_DOC
    , OBSERVATION_TPM300_PAT_VISIT
    , LABRESULT_CACHE_1
    , LABRESULT_CACHE_2
    , LABRESULT_CACHE_3
    , LABRESULT_CACHE_4
    , LABRESULT_MCKESSON_PGN
    , GTT_LABRESULT_NONNUMERIC
    , NONNUMERIC_LABRESULT
    , LABRESULT
    , LABMAPPERDICT
    , RXMEDADMINISTRATIONS
    , PATIENTREPORTEDMEDS
    , ZH_FACILITY
    , PROVIDER
    , PROVIDERSPECIALTY
    , PROVIDERCONTACT
    , PROVIDERIDENTIFIER
    , PROVIDERPATIENTRELATION
    , PROCEDURE_CACHE_1
    , PROCEDURE_CACHE_2
    , PROCEDURE_CACHE_3
    , PROCEDURE_CACHE_4
    , PROCEDURE_CACHE_5
    , PROCEDURE_CACHE_6
    , PROCEDURE_CACHE_7
    , PROCEDURE_CACHE_8
    , PROCEDURE_CACHE_9
    , PROCEDURE
    , CLAIM
    , MBORDER
    , MBRESULT
  )

  val drug_assign_queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      MEDICATION_MAP_SRC
    )
}


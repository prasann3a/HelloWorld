package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.cdr.fe.etl.commercial.mckesson_pgn_labresult_cache
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE_1 extends FEQueryAndMetadata[mckesson_pgn_labresult_cache]{
  override def name: String = "LABRESULT_CACHE_1"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_T_LABORATORY_RESULTS")

  override def sparkSql: String =
    """
      |WITH uni_visit AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
      |  )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'
      |   AND Vst_Int_Id IS NOT NULL
      |   AND Psn_Int_Id IS NOT NULL )
      |SELECT t.*, safe_to_number(localresult) AS localresult_numeric
      |FROM
      |(
      |SELECT
      |'{groupid}' AS groupid
      |,'laboratory_results' AS datasrc
      |,{client_ds_id} AS client_ds_id
      |,concat_ws('', 'lr.', lab.T_Laboratory_Results_Int_Id) AS labresultid
      |,CASE WHEN lab.format_code <> 'RL**' THEN lab.format_code ELSE lab.alt_idn END  AS localcode
      |,COALESCE(lab.Data_Mixed, lab.Data_Numeric) AS localresult
      |,uni_visit.Psn_Int_Id AS patientid
      |,lab.Alt_Idn          AS local_loinc_code
      |,NULL                 AS datecollected
      |,lab.Ordered_Datetime AS labordereddate
      |,COALESCE(lab.Tst_Rls_Dt, lab.Tst_Rpt_Ts) AS dateavailable
      |,lab.Vst_Int_Id      AS encounterid
      |,NULL 		     AS facilityid
      |,NULL		     AS laborderid
      |,COALESCE(lab.result_description,lab.alt_dsc) AS localname
      |,COALESCE(lab.result_description,lab.alt_dsc) AS localtestname
      |,COALESCE(lab.Unit_Of_Measure,lab.Uom_Ds) AS localunits
      |,lab.Normal_Mixed     AS normalrange
      |,CASE WHEN lab.result_flag LIKE 'H%' THEN 'Abnormal'
      |      WHEN lab.result_flag LIKE 'L%' THEN 'Low' ELSE NULL END AS resulttype
      |,NULL  		      AS statuscode
      |,lab.Lst_Mod_Ts       AS labresult_date
      |,ROW_NUMBER() OVER (PARTITION BY lab.T_Laboratory_Results_Int_Id
      |                    ORDER BY lab.Lst_Mod_Ts DESC NULLS LAST, lab.fileID DESC NULLS LAST) res_row
      |FROM (SELECT * FROM MCKESSON_PGN_V1_T_LABORATORY_RESULTS
      |      WHERE format_code <> 'RL**' OR alt_idn IS NOT NULL) lab
      |    JOIN UNI_VISIT ON (lab.vst_int_id = uni_visit.vst_int_id)
      |WHERE lab.T_Laboratory_Results_Int_Id IS NOT NULL
      |  AND lab.Lst_Mod_Ts IS NOT NULL
      |  AND (NVL(lab.data_mixed,'null') <> 'CANCELED' OR lab.data_numeric IS NOT NULL)
      | ) t
    """.stripMargin
}

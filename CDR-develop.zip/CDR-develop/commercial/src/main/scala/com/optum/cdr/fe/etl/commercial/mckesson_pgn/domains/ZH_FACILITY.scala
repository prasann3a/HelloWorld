package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, zh_facility}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ZH_FACILITY extends FETableInfo[zh_facility]{

override def name: String = CDRFEParquetNames.zh_facility

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TSM030_ORGANIZATION", "MCKESSON_PGN_V1_ZH_TSM015_ENTITY", "MCKESSON_PGN_V1_TSM021_ENT_ADR", "MCKESSON_PGN_V1_TSM020_ADDRESS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val addrCd = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ZIPCODE","ZH_FACILITY","ENT_ADR","ADR_USE_CD").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
       |WITH org AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  o.*
       |	       ,row_number() over (partition by org_int_id ORDER BY lst_mod_ts desc nulls last,fileid desc nulls last,length(org_nm) desc nulls last) rn
       |	FROM MCKESSON_PGN_V1_TSM030_ORGANIZATION o
       |)
       |WHERE rn = 1
       |AND row_sta_cd <> 'D'
       |AND org_int_id is not null ),
       |
       |entity AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  a.*
       |	       ,row_number() over (partition by ent_int_id ORDER BY lst_mod_ts desc nulls last,fileid desc nulls first) rn
       |	FROM MCKESSON_PGN_V1_ZH_TSM015_ENTITY a
       |)
       |WHERE row_sta_cd <> 'D'
       |AND rn = 1 ),
       |
       |entity_addr AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  a.*
       |	       ,row_number() over (partition by ent_int_id,adr_int_id ORDER BY lst_mod_ts desc nulls last,fileid desc nulls first) rn
       |	FROM MCKESSON_PGN_V1_TSM021_ENT_ADR a
       |)
       |WHERE adr_use_cd IN ({addr_cd})
       |AND row_sta_cd <> 'D'
       |AND rn = 1 ),
       |
       |addr AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  a.*
       |	       ,row_number() over (partition by adr_int_id ORDER BY lst_mod_ts desc nulls last,fileid desc nulls first) rn
       |	FROM MCKESSON_PGN_V1_TSM020_ADDRESS a
       |)
       |WHERE row_sta_cd <> 'D'
       |AND rn = 1 )
       |
       |SELECT  groupid
       |       ,client_ds_id
       |       ,facilityid
       |       ,facilityname
       |       ,facilitypostalcd
       |       ,npi
       |       ,specialty
       |FROM
       |(
       |	SELECT  '{groupid}'                     AS groupid
       |	       ,{client_ds_id}                  AS client_ds_id
       |	       ,o.org_int_id                    AS facilityid
       |	       ,o.org_nm                        AS facilityname
       |	       ,standardizepostalcode(a.zip_cd) AS facilitypostalcd
       |	       ,o.org_npi_cd                    AS npi
       |	       ,o.org_txn_cd                    AS specialty
       |	       ,row_number() over (partition by org_int_id ORDER BY nvl2(zip_cd,1,0) desc nulls first,nvl2(org_npi_cd,1,0) desc nulls first,nvl2(org_txn_cd,1,0) desc nulls first,o.lst_mod_ts desc nulls last) rn
       |	FROM ORG o
       |	LEFT JOIN ENTITY e
       |	ON (o.org_int_id = e.ent_int_id)
       |	LEFT JOIN ENTITY_ADDR ea
       |	ON (e.ent_int_id = ea.ent_int_id)
       |	LEFT JOIN ADDR a
       |	ON (ea.adr_int_id = a.adr_int_id)
       |)
       |WHERE facilityid IS NOT NULL
       |AND rn = 1
       """
        .stripMargin
        .replace("{addr_cd}", addrCd)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }
}

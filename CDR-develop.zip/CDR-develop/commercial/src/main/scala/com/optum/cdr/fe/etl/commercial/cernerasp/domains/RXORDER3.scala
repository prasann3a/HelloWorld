package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXORDER3 extends FETableInfo[rxorder]{
  override def name:String ="RXORDER3"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_DAW= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DAW", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DISCON_REAON= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DISCON_REAON", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_QUANTITY_FILL= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "QUANTITY_FILL", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_REFILL= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "REFILL", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_SIGNATURE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "SIGNATURE", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_STRG_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STRG_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DOSE_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DOSE_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DURATION= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DURATION", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DURATION_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DURATION_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_FREQUENCY= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "FREQUENCY", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_QTY_DOSE_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "QTY_DOSE_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_ROUTE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "ROUTE", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_STRG_DOSE_UNIT=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STRG_DOSE_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_STRG_DOSE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STRG_DOSE", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_MED_STATUS= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "MED_STATUS", "RX", "MEDICATION", "STATUS").mkString(",")
    val list_HUM_TYPE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "RX_HUM_TYPE", "RX", "ORDERS", "HUM_TYPE").mkString(",")
    val list_HUM_ACTION= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "HUM_ACTION", "RX", "MEDICATIONRECONCILIATIONDETAIL", "HUM_ACTION").mkString(",")
    val list_RX_HUM_TYPE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "RX_HUM_TYPE", "RX", "ORDERS", "HUM_TYPE").mkString(",")
    val list_ORD_STATUS= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "ORD_STATUS", "RX", "ORDERS", "STATUS").mkString(",")

    sparkSession.sql(
      s"""

         |select groupid, datasrc, client_ds_id, issuedate, ordervsprescription, patientid, rxid, discontinuedate, discontinuereason, encounterid, localdosefreq, localdoseunit, localdescription, localform, localgenericdesc, localmedcode, localqtyofdoseunit, localroute, localstrengthperdoseunit, localstrengthunit, orderstatus, quantityperfill, signature, venue, ordertype
         |,nvl(safe_to_number(localstrengthperdoseunit),0) * nvl(safe_to_number(localqtyofdoseunit),0) as localtotaldose
         |,coalesce(case when rlike(lower(localdosefreq),'(once|daily)') then 1
         |when rlike(lower(localdosefreq),'(2|two).*we?e?k') then safe_to_number(quantityperfill)*3.5
         |when rlike(lower(localdosefreq),'(1|two).*we?e?k') then safe_to_number(quantityperfill)*7
         |when rlike(lower(localdosefreq),'q ?6') then safe_to_number(quantityperfill)/4
         |when rlike(lower(localdosefreq),'q ?4') then safe_to_number(quantityperfill)/2
         |else null end,safe_to_number(regexp_extract(regexp_extract(lower(SIGNATURE),'for [0-9]+ days'),'[0-9]+'))) as localDAYSUPPLIED
         |,coalesce(case when rlike(lower(localdosefreq),'(once|daily)') then 1
         |when rlike(lower(localdosefreq),'(2|two).*we?e?k') then safe_to_number(quantityperfill)*3.5
         |when rlike(lower(localdosefreq),'(1|two).*we?e?k') then safe_to_number(quantityperfill)*7
         |when rlike(lower(localdosefreq),'q ?6') then safe_to_number(quantityperfill)/4
         |when rlike(lower(localdosefreq),'q ?4') then safe_to_number(quantityperfill)/2
         |else null end,safe_to_number(regexp_extract(regexp_extract(lower(SIGNATURE),'for [0-9]+ days'),'[0-9]+'))) as localduration
         |from
         |(
         |select groupid,datasrc,client_ds_id,issuedate,ordervsprescription,patientid,rxid,discontinuedate,discontinuereason,encounterid
         |,localdescription,localform,localgenericdesc,localmedcode,localroute,localstrengthperdoseunit,localstrengthunit,orderstatus,
         | signature,venue,ordertype,localqtyofdoseunit,localDOSEUNIT,localdosefreq
         | ,max(case when lower(description) in ('duration','dispense quantity') then text_answer
         | when localqtyofdoseunit is not null then localqtyofdoseunit else null end)
         | over (partition by rxid) as QUANTITYPERFILL
         | from
         | (
         |select
         |	groupid,datasrc,client_ds_id,issuedate,ordervsprescription,patientid,rxid,discontinuedate,discontinuereason,encounterid
         |	,localdescription,localform,localgenericdesc,localmedcode,description,text_answer
         |	,localroute,localstrengthperdoseunit,localstrengthunit,orderstatus,signature,venue,ordertype
         |  ,max(case when lower(description) in ('volume dose','duration','dispense quantity') then text_answer
         |   when SIGNATURE is not null then regexp_extract(regexp_extract(lower(SIGNATURE),'[./0-9]+ ?(mc?g(.ml)?|ml|vial)'),'[0-9]+([./0-9]+)')
         |   else null end) over (partition by rxid) as localqtyofdoseunit
         |  ,max(case when lower(description) in ('volume dose','duration','dispense quantity') then text_answer
         |   when SIGNATURE is not null then regexp_extract(regexp_extract(lower(SIGNATURE),'[./0-9]+ ?(mc?g(.ml)?|ml|vial)'),'(mc?g(.ml)?|ml|vial)')
         |   else null end) over (partition by rxid) as localDOSEUNIT
         |  ,max(case when lower(description) in ('frequency') then text_answer
         |   when SIGNATURE is not null then regexp_extract(lower(SIGNATURE),'(daily|monthly)')
         |   else null end) over (partition by rxid) as localdosefreq
         |	from (
         |	select
         |		'{groupid}' 									as groupid
         |		,'orders' 									as datasrc
         |		,{client_ds_id} 									as client_ds_id
         |		,o.original_ordered_date_time 							as issuedate
         |		,max(case when o.placed_order_as in ('1','5') then 'P' when o.placed_order_as = '0' then 'O' end) over (partition by o.unique_order_identifier) 	as ordervsprescription
         |		,o.unique_person_identifier 							as patientid
         |		,o.unique_order_identifier 							as rxid
         |		,o.discontinue_date_time 							as discontinuedate
         |		,max(case when ord.detail_question in ({list_DISCON_REAON}) then concat_ws('', '{client_ds_id}', '.', ord.coded_answer) end) over (partition by o.unique_order_identifier) as discontinuereason
         |		,o.unique_visit_identifier 							as encounterid
         |		,o.ordered_as 																as localdescription
         |		,max(case when ord.detail_question in ({list_DOSE_UNIT}) then
         |		 	case when lower(ord.text_answer) = 'ml' then 'liquid' else ord.text_answer end
         |		 	else null end) over (partition by o.unique_order_identifier)									as localform
         |		,rfr.display 																as localgenericdesc
         |		,o.code 																as localmedcode
         |		,max(case when lower(rfr.description) like '%route of administration%' then ord.text_answer
         |     when o.ordered_as is not null then regexp_extract(lower(o.ordered_as),'(oral|topical|otic|rectal|nasal|vaginal|(inhalat|intra|subcut|transd|ophth)[a-z]+)')
         |     else null end) over (partition by o.unique_order_identifier) 		as localroute
         |		,max(case when lower(rfr.description) in ('strength dose','volume dose') then ord.text_answer
         |     when o.ordered_as is not null then regexp_extract(regexp_extract(lower(o.ordered_as), '[0-9,./]+ ?(mc?g|ml|meq|units?|g|each|dose|%)([/0-9](ml|mc?g))?'),'^[0-9,./]+')
         |     else null end) over (partition by o.unique_order_identifier) as localstrengthperdoseunit
         |		,max(case when lower(rfr.description) in ('strength dose unit','volume dose unit') then ord.text_answer
         |     when o.ordered_as is not null then regexp_replace(regexp_extract(lower(o.ordered_as), '[0-9,./]+ ?(mc?g|ml|meq|units?|g|each|dose|%)([/0-9](ml|mc?g))?'),'[0-9,. ]+','')
         |     else null end) over (partition by o.unique_order_identifier)as localstrengthunit
         |		,case when o.status is not null then concat_ws('', '{client_ds_id}', '.', o.status) end								as orderstatus
         |		,max(case when lower(rfr.description) in ('signature','special instructions') then ord.text_answer
         |     else null end) over (partition by o.unique_order_identifier)		as signature
         |		,'1' 																	as venue
         |		,'CH002047' 															        as ordertype
         |		,row_number() over (partition by o.unique_order_identifier order by o.Update_Date_Time desc nulls first)						as ordrw
         |    ,rfr.description as description
         |    ,ord.text_answer as text_answer
         |		from ORDERS o
         |	left outer join ORDERDETAILS ord
         |	on 		   	o.unique_order_identifier = ord.unique_order_identifier
         |	left outer join 	(select element_code, display ,description from (
         |    	          	select element_code, display,description
         |      		        ,row_number() over (partition by file_name, field, element_code order by fileid desc nulls first) as rw
         |              		from REFERENCECODE
         |
         |             	)
         |              where rw=1
         |              ) rfr
         |	on 			ord.detail_question = rfr.element_code
         |	where o.hum_type 						in ({list_RX_HUM_TYPE})
         |	and o.status 						not in ({list_ORD_STATUS})
         |	and o.original_ordered_date_time 	is not null
         |	and o.placed_order_as 				is not null
         |	and o.unique_person_identifier 		is not null
         |	and o.unique_order_identifier 		is not null
         |	)
         |where ordrw=1
         |)
         |)

       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_DAW}",list_DAW)
        .replace("{list_DISCON_REAON}",list_DISCON_REAON)
        .replace("{list_QUANTITY_FILL}",list_QUANTITY_FILL)
        .replace("{list_REFILL}",list_REFILL)
        .replace("{list_SIGNATURE}",list_SIGNATURE)
        .replace("{list_STRG_UNIT}",list_STRG_UNIT)
        .replace("{list_DOSE_UNIT}",list_DOSE_UNIT)
        .replace("{list_DURATION}",list_DURATION)
        .replace("{list_DURATION_UNIT}",list_DURATION_UNIT)
        .replace("{list_FREQUENCY}",list_FREQUENCY)
        .replace("{list_QTY_DOSE_UNIT}",list_QTY_DOSE_UNIT)
        .replace("{list_ROUTE}",list_ROUTE)
        .replace("{list_STRG_DOSE}",list_STRG_DOSE)
        .replace("{list_STRG_DOSE_UNIT}",list_STRG_DOSE_UNIT)
        .replace("{list_MED_STATUS}",list_MED_STATUS)
        .replace("{list_HUM_TYPE}",list_HUM_TYPE)
        .replace("{list_HUM_ACTION}",list_HUM_ACTION)
        .replace("{list_RX_HUM_TYPE}",list_RX_HUM_TYPE)
        .replace("{list_ORD_STATUS}",list_ORD_STATUS)



    )
  }




  override def dependsOn: Set[String] = Set("REFERENCECODE","MAP_PREDICATE_VALUES","ORDERS","ORDERDETAILS")
}
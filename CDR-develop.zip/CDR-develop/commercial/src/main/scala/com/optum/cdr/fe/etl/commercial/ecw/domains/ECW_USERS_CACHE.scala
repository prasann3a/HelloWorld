package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.ecw_users_cache
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.map_predicate_values
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object ECW_USERS_CACHE extends FETableInfo[ecw_users_cache]{

  override def name: String = "ECW_USERS_CACHE"

  override def dependsOn: Set[String] = Set("USERS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    loadedDependencies("USERS").as[users].createOrReplaceTempView("USERS")

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val exclUserStatus = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STATUSEXCLUSION", "PATIENT",
                                "USERS", "STATUS").mkString(",")

    val exclUsers = if (exclUserStatus.equals("Y")) "--" else ""

    sparkSession.sql(
      """
        |with curr_users AS (
        |SELECT  *
        |FROM
        |(
        |	SELECT  u.*
        |	       ,first_value(status) over (partition by hum_uid ORDER BY mdate desc nulls last)  AS last_status
        |	       ,first_value(delflag) over (partition by hum_uid ORDER BY mdate desc nulls last,delflag asc) AS last_delflag
        |	FROM USERS u
        |)
        |WHERE last_delflag <> '1'
        |{excl_users} AND last_status <> '1'
        |)
        |
        |SELECT  hum_uid
        |       ,upcity
        |       ,upstate
        |       ,zipcode
        |       ,sex
        |       ,emrsex
        |       ,ufname
        |       ,ulname
        |       ,uminitial
        |       ,ssn
        |       ,dob
        |       ,mdate
        |       ,last_status
        |FROM
        |(
        |	SELECT  eu.hum_uid
        |	       ,eu.upcity
        |	       ,eu.upstate
        |	       ,eu.zipcode
        |	       ,eu.sex
        |	       ,eu.emrsex
        |	       ,eu.ufname
        |	       ,eu.ulname
        |	       ,eu.uminitial
        |	       ,eu.ssn
        |	       ,safe_to_date(eu.dob,'MM/dd/yyyy') AS dob
        |	       ,MAX(eu.mdate)                     AS mdate
        |	       ,last_status
        |	FROM
        |	(
        |		SELECT  u.*
        |		FROM CURR_USERS u
        |	) eu
        |	GROUP BY  eu.hum_uid
        |	         ,eu.upcity
        |	         ,eu.upstate
        |	         ,eu.zipcode
        |	         ,eu.sex
        |	         ,eu.emrsex
        |	         ,eu.uminitial
        |	         ,eu.ssn
        |	         ,eu.ufname
        |	         ,eu.ulname
        |	         ,safe_to_date(eu.dob,'MM/dd/yyyy')
        |	         ,last_status
        |)
      """.stripMargin
        .replace("{excl_users}", exclUsers)
    )
  }
}

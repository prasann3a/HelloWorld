package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.zh_appt_location
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_APPT_LOCATION extends FEQueryAndMetadata[zh_appt_location]{

override def name: String = CDRFEParquetNames.zh_appt_location

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_ZH_TRS200_RESOURCE")

override def sparkSql: String =
  """
    |SELECT  '{groupid}'      AS groupid
    |       ,'{client_ds_id}' AS client_ds_id
    |       ,locationname
    |       ,locationid
    |FROM
    |(
    |	SELECT  DISTINCT rsc_ds AS locationname
    |	       ,rsc_int_id locationid
    |	FROM MCKESSON_PGN_V1_ZH_TRS200_RESOURCE
    |)
  """.stripMargin
}

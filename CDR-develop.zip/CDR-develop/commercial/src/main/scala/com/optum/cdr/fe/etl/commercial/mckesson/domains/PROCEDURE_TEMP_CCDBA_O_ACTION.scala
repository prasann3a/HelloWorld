package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_TEMP_CCDBA_O_ACTION extends FETableInfo[proceduredo]{
  override def name: String = "PROCEDURE_TEMP_CCDBA_O_ACTION"

  override def dependsOn: Set[String] = Set("CCDBA_O_ACTION","MCKESSON_ENT_PATIENT","CCDBA_O_PAT","MAP_CUSTOM_PROC","ZH_CCDEV_O_ITEM")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |WITH uni_action AS
         |(SELECT * FROM
         |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY modified_dt DESC NULLS LAST) rn
         | FROM CCDBA_O_ACTION p
         | WHERE pat_Seq IS NOT NULL
         |   AND action_Ddt IS NOT NULL )
         | WHERE rn = 1),
         |uni_epat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |   WHERE cpi_seq IS NOT NULL
         |     AND pat_seq IS NOT NULL )
         |) WHERE rn = 1),
         |uni_opat AS
         |(SELECT * FROM (
         |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY order_ddt DESC NULLS LAST) rn
         |      FROM CCDBA_O_PAT i
         |      WHERE pat_seq IS NOT NULL
         |        AND Order_Item_Seq IS NOT NULL
         |       )
         |WHERE rn = 1)
         |select datasrc, localcode, encounterid, patientid, proceduredate, localname, codetype, mappedcode, proceduredate as actualprocdate, facilityid, hosp_px_flag
         |from
         |(
         |SELECT 'ccdba_o_action' AS datasrc
         |	,concat_ws('', '{client_ds_id}', '.', uni_opat.Order_Item_Seq) AS localcode
         |	,uni_epat.cpi_seq  AS patientid
         |	,uni_action.action_Ddt  AS proceduredate
         |	,uni_action.pat_seq  AS encounterid
         |	,NULL		  AS facilityid
         |	,zh.Order_Name	  AS localname
         |	,Map.Mappedvalue  AS mappedcode
         |	,'CUSTOM'  	  AS codetype
         |	,'Y'              AS hosp_px_flag
         |	,ROW_NUMBER() OVER (PARTITION BY uni_epat.cpi_seq, uni_action.pat_seq, uni_action.action_Ddt, uni_opat.Order_Item_Seq
         |	 			ORDER BY uni_action.modified_dt DESC NULLS LAST) rn
         |FROM UNI_ACTION
         |   JOIN UNI_OPAT ON (uni_action.order_seq = uni_opat.order_seq)
         |   JOIN UNI_EPAT ON (uni_epat.pat_seq = uni_opat.pat_seq)
         |   JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
         |                            map.datasrc = 'ccdba_o_action' AND
         |   			    map.localcode = concat_ws('', '{client_ds_id}', '.', uni_opat.Order_Item_Seq))
         |   JOIN ZH_CCDEV_O_ITEM zh ON (uni_opat.Order_Item_Seq = zh.order_item_seq)
         |
 |)
         |where rn = 1 AND proceduredate IS NOT NULL
       """.stripMargin.replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId))
  }
}

package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.patientaddr
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object PATIENTADDR extends FEQueryAndMetadata[patientaddr] {

  override def name: String = CDRFEParquetNames.patientaddr

  override def dependsOn: Set[String] = Set("PRSNAD")

  override def sparkSql: String =
    """
     |select groupid, datasrc, client_ds_id, patientid, address_date, address_type, address_line1, address_line2, city, state, zipcode
     |from
     |(
     |SELECT
     |       '{groupid}'                        AS groupid
     |       ,'prsnad'                          AS datasrc
     |       ,{client_ds_id}                    AS client_ds_id
     |       ,pa.data_update_ts                 AS address_date
     |       ,pa.person_num                     AS patientid
     |       ,pa.state_cde                      AS state
     |       ,pa.postal_cde                     AS zipcode
     |       ,pa.street_ln                      AS address_line1
     |       ,pa.addl_dest_ln                   AS address_line2
     |       ,pa.type_cde                       AS address_type
     |       ,pa.city_nm                        AS city
     |       ,row_number() over (partition by person_num,data_update_ts,street_ln,addl_dest_ln,city_nm,state_cde,postal_cde
     |              order by data_update_ts desc nulls last) as rn
     |FROM PRSNAD pa
     |WHERE pa.inactv_ts IS NULL
     |AND coalesce( pa.street_ln,pa.addl_dest_ln , pa.city_nm, pa.state_cde,pa.postal_cde)  IS NOT NULL
     |)where patientid IS NOT NULL AND address_date IS NOT NULL AND rn = 1
    """.stripMargin

}




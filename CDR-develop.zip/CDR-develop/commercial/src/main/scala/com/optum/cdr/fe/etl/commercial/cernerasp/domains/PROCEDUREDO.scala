package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROCEDUREDO extends FETableInfo[proceduredo]{

  override def name:String="PROCEDUREDO"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
          select * from PROCEDURE1

          union all

          select * from PROCEDURE2

          union all

         select * from PROCEDURE3

          union all

          select * from PROCEDURE4


       """.stripMargin)

  }

  override def dependsOn: Set[String] = Set("PROCEDURE1","PROCEDURE2","PROCEDURE3","PROCEDURE4")
}

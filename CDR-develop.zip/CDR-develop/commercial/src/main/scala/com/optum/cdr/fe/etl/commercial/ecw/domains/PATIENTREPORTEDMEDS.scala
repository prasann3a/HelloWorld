package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.rx_patient_reported
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTREPORTEDMEDS extends FEQueryAndMetadata[rx_patient_reported]{

  override def name: String = CDRFEParquetNames.rx_patient_reported

  override def dependsOn: Set[String] = Set("RXORDER_CACHE")

  override def sparkSql: String =
    """
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,patientid
      |       ,encounterid
      |       ,localform
      |       ,localmedcode
      |       ,localndc
      |       ,localcategorycode
      |       ,discontinuedate
      |       ,LOCALDESCRIPTION as LOCALDRUGDESCRIPTION
      |       ,localqtyofdoseunit
      |       ,localroute
      |       ,localstrengthperdoseunit
      |       ,localstrengthunit
      |       ,medreportedtime
      |       ,reportedmedid
      |       ,localtotaldose
      |FROM RXORDER_CACHE
      |WHERE PatientsFlag = '1'
    """.stripMargin
}

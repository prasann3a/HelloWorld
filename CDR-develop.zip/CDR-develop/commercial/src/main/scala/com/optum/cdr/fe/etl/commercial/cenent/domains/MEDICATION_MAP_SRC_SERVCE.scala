package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.verify.MedicationMapSrcVerify
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_SERVCE extends FETableInfo[medication_map_src]{
  override def name: String = "MEDICATION_MAP_SRC_SERVCE"

  override def dependsOn: Set[String] = Set("ZH_XMEDCN","ZH_XSERVC","SERVCE","SERVME")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
            WITH uni_zxm AS
       ( SELECT * FROM (
         SELECT x.*, ROW_NUMBER() OVER (PARTITION BY SERV_DESCR_NUM ORDER BY DATA_TS DESC NULLS LAST) rn
         FROM ZH_XMEDCN x  )
         WHERE rn = 1)
        select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs
        from
        (
        SELECT '{groupid}' as groupid
                ,'servce' as datasrc
          ,{client_ds_id} as client_ds_id
                ,s.serv_descr_num as localmedcode
                ,uni_zxm.cde as localndc
                ,COALESCE(uni_zxm.Nm,Zh_Xservc.Nm) as localdescription
                ,sum(case when uni_zxm.cde is null then 1 else 0 end) as no_ndc
                ,sum(case when uni_zxm.cde is null then 0 else 1 end) as has_ndc
                ,count(*) as num_recs
        FROM SERVCE s
        JOIN SERVME sm
            ON (sm.serv_pat_person_num = s.pat_person_num AND sm.serv_data_create_ts = s.data_create_ts)
        LEFT JOIN UNI_ZXM
              ON (s.serv_descr_num = uni_zxm.serv_descr_num)
        LEFT JOIN ZH_XSERVC ON (s.serv_descr_num = zh_xservc.num)
        WHERE s.serv_type_cde = 'MED' AND s.result_cde <> 'Not Given'
        GROUP BY s.serv_descr_num, uni_zxm.cde, COALESCE(uni_zxm.Nm,Zh_Xservc.Nm)
        )
            """.replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId))
  }
}

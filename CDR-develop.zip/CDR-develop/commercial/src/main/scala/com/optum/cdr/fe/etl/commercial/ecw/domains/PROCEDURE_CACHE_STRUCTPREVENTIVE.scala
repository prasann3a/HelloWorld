package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_STRUCTPREVENTIVE extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_STRUCTPREVENTIVE"

  override def dependsOn: Set[String] = Set("STRUCTPREVENTIVE", "ENC", "ZH_ITEMS", "MAP_CUSTOM_PROC", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listDetailId1 = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTPREVENTIVE", "PROCEDUREDO",
      "STRUCTPREVENTIVE", "DETAILID_1").mkString(",")
    val listDetailId2 = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTPREVENTIVE", "PROCEDUREDO",
      "STRUCTPREVENTIVE", "DETAILID_2").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localcode
        |       ,encounterid
        |       ,patientid
        |       ,proceduredate
        |       ,localname
        |       ,codetype
        |       ,mappedcode
        |FROM
        |(
        |	SELECT  t.*
        |	       ,mcp.codetype                                                                                                                               AS codetype
        |	       ,mcp.mappedvalue                                                                                                                            AS mappedcode
        |	       ,row_number() over (partition by t.patientid,t.encounterid,t.localcode,t.proceduredate,mcp.mappedvalue ORDER BY t.hum_date desc nulls last) AS rownumber
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                                                AS groupid
        |		       ,'structpreventive'                                                                                         AS datasrc
        |		       ,{client_ds_id}                                                                                             AS client_ds_id
        |		       ,CASE WHEN s.detailid IN ({list_detail_id_1}) THEN concat_ws('','{client_ds_id_prefix}',zh.itemid,'.',s.detailid) ELSE concat_ws('','{client_ds_id_prefix}',zh.itemid) END AS localcode
        |		       ,e.encounterid                                                                                              AS encounterid
        |		       ,e.patientid                                                                                                AS patientid
        |		       ,CASE WHEN s.detailid IN ({list_detail_id_2}) THEN safe_to_date(s.hum_value,'MM/dd/yyyy') ELSE hum_date END AS proceduredate
        |		       ,zh.itemname                                                                                                AS localname
        |		       ,s.hum_date
        |		FROM STRUCTPREVENTIVE s
        |		INNER JOIN ENC e
        |			ON (s.encounterid = e.encounterid)
        |		LEFT OUTER JOIN ZH_ITEMS zh
        |			ON (s.itemid = zh.itemid)
        |		WHERE e.patientid is not null
        |	) t
        |	INNER JOIN MAP_CUSTOM_PROC mcp
        |		ON (mcp.groupid = '{groupid}' AND mcp.localcode = t.localcode AND mcp.datasrc = 'structpreventive' )
        |	WHERE t.proceduredate is not null
        |	AND t.localcode is not null
        |)
        |WHERE rownumber = 1
      """.stripMargin
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{list_detail_id_1}", listDetailId1)
        .replace("{list_detail_id_2}", listDetailId2)
    )
  }


}

package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}



object CLAIM extends FEQueryAndMetadata[claim] {

  override def name: String = CDRFEParquetNames.claim

  override def dependsOn: Set[String] = Set("TEMP_CLAIM_PART1", "TEMP_CLAIM_PART2")

  override def sparkSql: String =
    """
      SELECT * FROM TEMP_CLAIM_PART1
      UNION ALL
      SELECT * FROM TEMP_CLAIM_PART2
    """.stripMargin

}

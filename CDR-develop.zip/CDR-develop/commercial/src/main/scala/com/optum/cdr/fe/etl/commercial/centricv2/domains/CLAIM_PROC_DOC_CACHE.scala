package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.claim_proc_doc_cache
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object CLAIM_PROC_DOC_CACHE extends FETableInfo[claim_proc_doc_cache] {

  override def name: String = "CLAIM_PROC_DOC_CACHE"

  override def dependsOn: Set[String] = Set("CENTRICV2_OBSERVATIONS", "CENTRICV2_ZH_OBSHEAD", "CENTRICV2_DOCUMENTS", "MAP_CUSTOM_PROC", "MAP_PREDICATE_VALUES","PROCEDURE_ORDERS","PROCEDURE_RESULTS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOC_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")
    val obsXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "OBS_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")
    val whereclausempv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOCUMENTS", "INCLUSION", "CLAIM_PROC", "DOCUMENTS").mkString(",")


    val constNoMpvMatches = "'NO_MPV_MATCHES'"
    val docXidInclusion = if (docXidInclusionMpv == constNoMpvMatches) "" else " and d.xid in ( " + docXidInclusionMpv.replace("'", "") + " ) "
    val obsXidInclusion = if (obsXidInclusionMpv == constNoMpvMatches) "" else " and o.xid in ( " + obsXidInclusionMpv.replace("'", "") + " ) "
    val whereclausevalue = if (whereclausempv == constNoMpvMatches) "where 1=2" else "where 1=1"


    sparkSession.sql(
      """
        |with dedup_doc AS
        |        (SELECT * FROM
        |                (SELECT b.*, ROW_NUMBER() OVER (PARTITION BY b.sdid
        |                 ORDER BY b.db_updated_date  DESC NULLS LAST) rn
        |                 FROM CENTRICV2_DOCUMENTS b {where_clause})
        |   WHERE rn = 1)
        |,dedup_obs AS
        |        (select * from
        |                (select o.*, row_number() over (partition by o.pid,o.sdid, o.obsdate, o.hdid
        |                 order by o.db_updated_date desc nulls last, o.fileid desc nulls last) as rnum
        |                 from CENTRICV2_observations o {where_clause})
        |   where rnum = 1)
        |,proc_cte as
        |(
        |Select * from (
        |select concat_ws('',patientid,encounterid,localcode)  as pr_order_id from PROCEDURE_ORDERS
        |union
        |select concat_ws('',patientid,encounterid,localcode)  as pr_result_id from PROCEDURE_RESULTS)
        |)
        |select * from (
        |Select a.*,row_number() over (partition by a.patientid, a.claimid, a.encounterid, a.servicedate, a.localcpt
        |                                      order by db_updated_date desc nulls last) as claim_rn
        |       ,row_number() over (partition by a.patientid, a.encounterid, a.servicedate, a.localcode, a.stdcodetype
        |                                      order by db_updated_date desc nulls last) as proc_rownumber from
        |(select distinct '{groupid}'            as groupid
        |,'documents_mammo'                      as datasrc
        |,{client_ds_id}                         as client_ds_id
        |,o.Sdid                                 as claimid
        |,o.Sdid                                 as encounterid
        |,o.Pid                                  as patientid
        |,o.obsdate                              as servicedate
        |,nullif(o.usrid,-3)                     as claimproviderid
        |,case when zh.cptcode is not null
        |      then nullif(substr(zh.cptcode,1,5), '')
        |      when (zh.cptcode is null and rlike(zh.mlcode, '(?i)CPT.*(\\d|[a-z]){1}\\d{3}(\\d|[a-z]){1}'))
        |      then nullif(regexp_extract(zh.mlcode,'[a-zA-Z0-9]{5}', 0), '')
        |      else null end                     as cptcode
        |,coalesce(zh.Cptcode,zh.Mlcode)         as localcpt
        |,d.summary                              as localcode
        |,d.summary                              as localname
        |,case when mcp.mappedvalue  is not null  then  mcp.mappedvalue
        |       when rlike(coalesce(zh.Cptcode,zh.Mlcode) , '(?i)(^|CPT.*|J[^I].*|#.*)(\\d|[a-z]){1}\\d{3}(\\d|[a-z]){1}')
        |       then nullif(regexp_extract(coalesce(zh.Cptcode,zh.Mlcode), '[a-zA-Z0-9]{5}', 0), '')
        |       else null end                    AS standardcode
        |,'CUSTOM'                               as stdcodetype
        |,case      when lower(o.obsvalue) like '%decline%' then 'Y'
        |            when lower(o.obsvalue) like '%elsewhere%' then 'Y'
        |            when lower(o.obsvalue) like '%refuse%' then 'Y'
        |            when lower(o.obsvalue) like '%immune%' then 'Y'
        |            when lower(o.obsvalue) like '%defer%' then 'Y'
        |            when lower(o.obsvalue) like 'not%' then 'Y'
        |            when lower(o.obsvalue) like '%received at%' then 'Y'
        |            when lower(o.obsvalue) like '%recommend%' then 'Y'
        |            when lower(o.obsvalue) like '%not indicated%' then 'Y'
        |            when lower(o.obsvalue) like '%discuss%' and lower(o.description) not like '%fall%' then 'Y'
        |            when lower(o.description) like '%dup%' then 'Y'
        |            when lower(o.description) like '%err%' then 'Y'
        |            when lower(o.description) like '%wrong%' then 'Y'
        |            when lower(o.description) like '%not %' then 'Y'
        |            when lower(o.description) like '%incorrect%' then 'Y'
        |            else 'N' end                   as obs_not_done
        |,o.db_updated_date
        |from dedup_doc d
        |inner join dedup_obs o ON  (o.pid=d.pid and o.sdid=d.sdid)
        |inner join CENTRICV2_zh_obshead zh on (o.hdid=zh.hdid)
        |inner join map_custom_proc mcp  on (mcp.groupid = '{groupid}' and mcp.datasrc='documents_mammo'
        |and {client_ds_id}||'.'||d.summary=mcp.localcode)
        |left outer join proc_cte pc on concat_ws('',o.pid,o.sdid,o.hdid) = pc.pr_order_id
        |where doctype=8
        |and origin='E' and labresultstatus='F'
        |and (o.state IS NULL OR  o.state NOT IN ('D','I','P','S'))
        |and (o.Change IS NULL OR  o.Change IN ('0','1','2'))
        |and d.finalsign = 1 AND d.status ='S'
        |{dox_xid_condition}
        |{obs_xid_condition}
        |and pc.pr_order_id is null
        |) a
        |){where_clause}
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{dox_xid_condition}", docXidInclusion).
        replace("{obs_xid_condition}", obsXidInclusion).
        replace("{where_clause}", whereclausevalue)
    )

  }




}
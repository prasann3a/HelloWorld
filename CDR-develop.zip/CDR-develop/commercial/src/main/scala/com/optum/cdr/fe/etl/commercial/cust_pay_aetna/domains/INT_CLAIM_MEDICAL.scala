package com.optum.cdr.fe.etl.commercial.cust_pay_aetna.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.int_claim_medical
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_MEDICAL extends FETableInfo[int_claim_medical] {

  override def name: String = CDRFEParquetNames.int_claim_medical

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val maskedIdInclusion = mpvList(mapPredicateValues, groupId, clientDsId,"MASKED_CLAIMS","INTERMEDIATE_CLAIMS","INTERMEDIATE_CLAIMS","CLIENT_DS_ID")
    val maskedIdInclusionList = if (maskedIdInclusion.mkString.equals("'Y'")) "' '" else "'00000000000000000000'"

    sparkSession.sql(
      s"""
         |select groupid, datasrc, client_ds_id, claim_header_id, contract_id, encounterid, member_id, payer_code, payer_name, place_of_service, quantity_of_service, service_date, servicing_prov_id, admit_date, admit_source_code, admit_type_code, allowed_amt, coinsurance_amt, coord_benifits_amt, copay_amt, deductable_amt, payment_amt, requested_amt, capitated_service_flag, claim_type, diag_rel_grp_code, diag_rel_grp_grouper, denied_flag, discharge_date, discharge_status_code, ein, financial_class, icd_diag_cd1_poa_indicator, icd_diag_cd2_poa_indicator, icd_diag_cd3_poa_indicator, icd_diag_cd4_poa_indicator, icd_diag_cd5_poa_indicator, icd_diag_cd6_poa_indicator, icd_diag_cd7_poa_indicator, icd_diag_cd8_poa_indicator, icd_diag_cd9_poa_indicator, icd_diag_cd10_poa_indicator, icd_diag_cd1, icd_diag_cd2, icd_diag_cd3, icd_diag_cd4, icd_diag_cd5, icd_diag_cd6, icd_diag_cd7, icd_diag_cd8, icd_diag_cd9, icd_diag_cd10, icd_diag_cd1_type, icd_diag_cd2_type, icd_diag_cd3_type, icd_diag_cd4_type, icd_diag_cd5_type, icd_diag_cd6_type, icd_diag_cd7_type, icd_diag_cd8_type, icd_diag_cd9_type, icd_diag_cd10_type, icd_proc_cd_1, icd_proc_cd_2, icd_proc_cd_3, icd_proc_cd_4, icd_proc_cd_5, icd_proc_cd_6, icd_proc_cd_1_type, icd_proc_cd_2_type, icd_proc_cd_3_type, icd_proc_cd_4_type, icd_proc_cd_5_type, icd_proc_cd_6_type, par_flag, pay_process_date, principle_proc_cd, principle_proc_icd_type, proc_cd_modifier_1, proc_cd_modifier_2, proc_cd_modifier_3, proc_code, revenue_code, service_from_date, service_to_date, servicing_prov_npi, servicing_prov_spclty_cd, servicing_prov_spclty_desc, type_of_bill_code
         |from
         |(
         |select  distinct
         | '{groupid}' as groupid
         |,'AETACLAIM' as datasrc
         |,{client_ds_id} as client_ds_id
         |,concat_ws('', cl.member_Id, '_', date_format(cl.Srv_Start_Dt,'yyyy-MM-dd'), '_', cl.srv_prvdr_npi, '_', cl.type_class_cd, '_', cl.revenue_cd, '_', cl.prcdr_cd, '_', cl.prcdr_modifier_cd_1, '_', cl.prcdr_modifier_cd_2, '_', cl.prcdr_modifier_cd_3, cl.org_cd) as claim_header_id
         |,cl.org_cd as contract_id
         |,concat_ws('', cl.member_Id, '_', date_format(cl.Srv_Start_Dt,'yyyy-MM-dd'), '_', cl.srv_prvdr_npi, '_', cl.type_class_cd, '_', cl.revenue_cd, '_', cl.prcdr_cd, '_', cl.prcdr_modifier_cd_1, '_', cl.prcdr_modifier_cd_2, '_', cl.prcdr_modifier_cd_3, cl.org_cd) as encounterid
         |,cl.member_id as member_id
         |,bme.employeraccountid as payer_code
         |,bme.employeraccountid as payer_name
         |,case when cl.hcfa_plc_srv_cd = 'F' then '11'
         |	    when upper(cl.hcfa_plc_srv_cd) in ('N','U') then bpx.imputed_pos
         |	    else cl.hcfa_plc_srv_cd end as place_of_service
         |,cast(float(safe_to_number(cl.src_unit_cnt)/100) as String) AS quantity_of_service
         |,cl.srv_start_dt as service_date
         |,nullif(cl.Srv_Prvdr_Npi,'0') as servicing_prov_id
         |,case when to_date(cl.src_admit_dt, 'yyyy-MM-dd HH:mm:ss') = to_date('01011800', 'MMddyyyy') then null
         |	    else cl.src_admit_dt end as admit_date
         |,concat_ws('', 'CMS', '.', cl.hcfa_admit_src_cd) as admit_source_code
         |,cl.hcfa_admit_type_cd_1 as admit_type_code
         |,safe_to_number(cl.allowed_amt)/100 as allowed_amt
         |,safe_to_number(cl.coinsurance_amt)/100 as coinsurance_amt
         |,safe_to_number(cl.cob_paid_amt)/100 as coord_benifits_amt
         |,safe_to_number(cl.src_srv_copay_amt)/100 as copay_amt
         |,safe_to_number(cl.deductible_amt)/100 as deductable_amt
         |,safe_to_number(cl.paid_amt)/100 as payment_amt
         |,safe_to_number(cl.Billed_Amt)/100 as requested_amt
         |,case when cl.classification_cd ='C' then 'Y'
         |	    else 'N' end as capitated_service_flag
         |,case when cl.type_class_cd = 'N' then 'P'
         |	    when type_class_cd = 'F' then 'I'
         |	    else null end as claim_type
         |,cl.Drg_Cd as diag_rel_grp_code
         |,case when cl.Drg_Cd is not null then 'MSDRG' else null end as diag_rel_grp_grouper
         |,case when cl.clm_ln_status_cd='D' then 'Y'
         |	    else 'N' end as  denied_flag
         |,case when to_date(cl.src_discharge_dt, 'yyyy-MM-dd HH:mm:ss') = to_date('01011800', 'MMddyyyy') then null
         |	    else cl.src_discharge_dt end as discharge_date
         |,lpad(cl.dschrg_status_cd,'2','0') as discharge_status_code
         |,case when cl.provider_tax_id_nbr in ('000000000','999999999') then null
         |	    else cl.provider_tax_id_nbr end as ein
         |,bme.employeraccountid      				as financial_class
         |,cl.poa_cd_1                				as icd_diag_cd1_poa_indicator
         |,cl.poa_cd_2                				as icd_diag_cd2_poa_indicator
         |,cl.poa_cd_3                				as icd_diag_cd3_poa_indicator
         |,cl.poa_cd_4                				as icd_diag_cd4_poa_indicator
         |,cl.poa_cd_5                				as icd_diag_cd5_poa_indicator
         |,cl.poa_cd_6                				as icd_diag_cd6_poa_indicator
         |,cl.poa_cd_7                				as icd_diag_cd7_poa_indicator
         |,cl.poa_cd_8                				as icd_diag_cd8_poa_indicator
         |,cl.poa_cd_9                				as icd_diag_cd9_poa_indicator
         |,cl.poa_cd_10               				as icd_diag_cd10_poa_indicator
         |,cl.pri_icd9_dx_cd          				as icd_diag_cd1
         |,cl.icd9_dx_cd_2            				as icd_diag_cd2
         |,cl.icd9_dx_cd_3            				as icd_diag_cd3
         |,cl.icd9_dx_cd_4            				as icd_diag_cd4
         |,cl.icd9_dx_cd_5            				as icd_diag_cd5
         |,cl.icd9_dx_cd_6            				as icd_diag_cd6
         |,cl.icd9_dx_cd_7            				as icd_diag_cd7
         |,cl.icd9_dx_cd_8            				as icd_diag_cd8
         |,cl.icd9_dx_cd_9            				as icd_diag_cd9
         |,cl.icd9_dx_cd_10           				as icd_diag_cd10
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd1_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd2_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd3_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd4_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd5_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd6_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd7_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd8_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd9_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_diag_cd10_type
         |,cl.icd9_prcdr_cd_1         				as icd_proc_cd_1
         |,cl.icd9_prcdr_cd_2         				as icd_proc_cd_2
         |,cl.icd9_prcdr_cd_3         				as icd_proc_cd_3
         |,cl.icd9_prcdr_cd_4         				as icd_proc_cd_4
         |,cl.icd9_prcdr_cd_5         				as icd_proc_cd_5
         |,cl.icd9_prcdr_cd_6         				as icd_proc_cd_6
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_proc_cd_1_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_proc_cd_2_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_proc_cd_3_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_proc_cd_4_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_proc_cd_5_type
         |,case when upper(icd10_indicator)='Y' THEN 'ICD10' else 'ICD9' end  as icd_proc_cd_6_type
         |,cl.paid_prvdr_par_cd       				as par_flag
         |,case when cl.file_id='03' then cl.paid_dt
         |	    else cl.adjn_dt end as pay_process_date
         |,cl.icd9_prcdr_cd_1  as principle_proc_cd
         |,case when upper(Icd10_Indicator)='Y' then 'ICD10'
         |	    else 'ICD9' end as principle_proc_icd_type
         |,cl.prcdr_modifier_cd_1     				as proc_cd_modifier_1
         |,cl.prcdr_modifier_cd_2     				as proc_cd_modifier_2
         |,cl.prcdr_modifier_cd_3     				as proc_cd_modifier_3
         |,case when cl.prcdr_cd='A' then null
         |	else cl.prcdr_cd end as proc_code
         |,Case when length(cl.revenue_cd) in (1,2,3,4)	then lpad(cl.revenue_cd,4,0)
         |	else null end as revenue_code
         |,cl.srv_start_dt            				as service_from_date
         |,cl.srv_stop_dt             				as service_to_date
         |,case when cl.srv_prvdr_npi = '0'	then cl.srv_prvdr_id
         |	    else cl.srv_prvdr_npi end as servicing_prov_npi
         |,cl.provider_type_cd        				as servicing_prov_spclty_cd
         |,cl.provider_type_cd        				as servicing_prov_spclty_desc
         |,cl.hcfa_bill_type_cd       				as type_of_bill_code
         |from AETACLAIM cl
         |cross join ZO_BPO_MAP_EMPLOYER bme on bme.client_ds_id = {client_ds_id}
         |Left join REF_BILLTYPE_POS_XREF bpx on cl.hcfa_bill_type_cd = nullif(concat_ws('', bpx.bill_type, bpx.fac_type_cd), '')
         |where member_id <> {masked_id_inclusion}
         |)
       """.stripMargin
        .replace("{client_ds_id}",clientDsId).replace("{groupid}",groupId).replace("{masked_id_inclusion}",maskedIdInclusionList)
    )
  }
  override def dependsOn: Set[String] = Set("AETACLAIM","ZO_BPO_MAP_EMPLOYER","REF_BILLTYPE_POS_XREF","MAP_PREDICATE_VALUES")
  override def ignoreExtraColumnsInDataFrame: Boolean = true
}
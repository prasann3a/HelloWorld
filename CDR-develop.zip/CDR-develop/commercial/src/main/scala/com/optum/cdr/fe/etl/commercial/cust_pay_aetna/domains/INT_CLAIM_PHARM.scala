package com.optum.cdr.fe.etl.commercial.cust_pay_aetna.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.int_claim_pharm
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_PHARM extends FETableInfo[int_claim_pharm]
{
  override def name: String = CDRFEParquetNames.int_claim_pharm

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val maskedIdInclusion = mpvList(mapPredicateValues, groupId, clientDsId,"INT_CLAIM_PHARM","INT_CLAIM_PHARM","INT_CLAIM_PHARM","PHARMACY").mkString
    val maskedIdInclusionList = if (maskedIdInclusion.toString.equals(groupId)) "INT_CLAIM_PHARM_H367_CACHE1" else "INT_CLAIM_PHARM_CACHE1"
    sparkSession.sql(
      s"""
         |SELECT *
         |FROM {int_claim_pharma}
      """.stripMargin.replace("{int_claim_pharma}", maskedIdInclusionList.toString)
    )
  }
  override def dependsOn: Set[String] = Set("INT_CLAIM_PHARM_CACHE1","MAP_PREDICATE_VALUES","INT_CLAIM_PHARM_H367_CACHE1")
}

package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.patientcontact
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTCONTACT extends FEQueryAndMetadata[patientcontact]{

  override def name: String = CDRFEParquetNames.patientcontact

  override def dependsOn: Set[String] = Set("PATIENT_HISTORIES_TB", "PATIENT_FAC_GRP_SEG_TB")

  override def sparkSql: String =

  """
    |select groupid, client_ds_id, datasrc, patientid, update_dt, personal_email
    |from
    |(
    |select * from (
    |SELECT '{groupid}' as groupid,'patient_histories_tb' as datasrc
    |       ,{client_ds_id} as client_ds_id
    |       ,PHT.Patient_Id AS patientid
    |       ,PHT.Last_Modified_Date AS update_dt
    |       ,case when pht.EMAIL_ADDR like '%@%' then pht.EMAIL_ADDR else null end personal_email
    |       ,row_number() over (partition by pht.Patient_ID, pht.EMAIL_ADDR
    |                               order by pht.Last_Modified_Date desc nulls last, pht.FileID desc nulls first) as rownumber
    |  FROM PATIENT_HISTORIES_TB pht
    | INNER JOIN PATIENT_FAC_GRP_SEG_TB pfg ON (pfg.PATIENT_ID = pht.PATIENT_ID)
    | WHERE pht.EMAIL_ADDR is not null
    |   AND pht.Last_Modified_Date is not null
    |   AND pht.Patient_Id is not null
    |       )
    |where rownumber = 1
    |)
  """
  .stripMargin

}

package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.cenent_labresult_cache
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, RuntimeVariables}
import org.apache.spark.storage.StorageLevel


object LABRESULT_SERVCE_CACHE extends FEQueryAndMetadata[cenent_labresult_cache] {

  override def name: String = "LABRESULT_SERVCE_CACHE"

  override def dependsOn: Set[String] = Set("FINDNG", "ZCM_OBSTYPE_CODE", "ZH_XCNCPT", "ZH_LABNRM", "SERVCE", "ZH_XSERVC")

  override def sparkSql: String =
    """
      |WITH res_dtl AS
      |(SELECT * FROM (
      | SELECT d.*, z.long_nm, concat_ws('', l.range_txt, ' ', l.units_txt) AS normalrange,l.units_txt,z.Loinc_Cde,
      |           ROW_NUMBER() OVER (PARTITION BY d.pat_person_num, d.serv_data_create_ts, d.data_ts, data_src_finding_id
      |              ORDER BY data_src_finding_id DESC NULLS LAST) rn
      | FROM (SELECT f.*
      |       FROM FINDNG f
      |            JOIN ZCM_OBSTYPE_CODE c ON (c.groupid = '{groupid}' AND
      |                                   c.datasrc = 'findng' AND
      |                                   c.obstype = 'LABRESULT' AND
      |                                   c.obscode = f.concept_descr_num)
      |       WHERE f.finding_type_cde = 'FINDNG'
      |       UNION ALL
      |       SELECT *
      |       FROM FINDNG
      |       WHERE finding_type_cde = 'LAB' ) d
      |      LEFT OUTER JOIN ZH_XCNCPT z ON (z.num = d.concept_descr_num)
      |      LEFT OUTER JOIN ZH_LABNRM l ON (l.num = d.enscribe_norm_val_ptr))
      | WHERE rn = 1
      |
      |),
      |res_header AS
      |(SELECT * FROM (
      | SELECT s.*, x.nm, ROW_NUMBER() OVER (PARTITION BY s.pat_person_num, s.data_create_ts, s.data_ts
      |                   ORDER BY s.data_src_serv_id DESC NULLS LAST) rn
      | FROM SERVCE s
      |       LEFT OUTER JOIN ZH_XSERVC x ON (x.num = s.serv_descr_num))
      | WHERE rn = 1
      |  )
      |SELECT '{groupid}' as groupid
      |,'findng' as datasrc
      |,{client_ds_id} as client_ds_id
      |,concat_ws('', res_dtl.data_src_finding_id, '_', res_dtl.concept_descr_num) AS labresultid
      |,res_dtl.concept_descr_num AS localcode
      |,res_dtl.txt AS localresult
      |,safe_to_number(res_dtl.txt) as localresult_numeric
      |,res_dtl.pat_person_num AS patientid
      |,NULL AS datecollected
      |,res_dtl.Serv_Data_Create_Ts  AS labordereddate
      |,res_dtl.dttm AS dateavailable
      |,res_header.encntr_num AS encounterid
      |,res_header.fac_num AS facilityid
      |,CASE WHEN res_header.order_data_create_ts IS NOT NULL THEN
      |     nullif(concat_ws('', res_header.pat_person_num, date_format(res_header.order_data_create_ts,'yyyyMMddHHmmss'), res_header.serv_descr_num), '')
      | ELSE NULL END AS laborderid
      |,res_dtl.long_nm  AS localname
      |,res_header.Nm  AS localtestname
      |,coalesce(res_dtl.Meas_Unit_Id, res_dtl.Units_Txt) AS localunits
      |,res_dtl.normalrange AS normalrange
      |,res_dtl.abnorm_cde AS resulttype
      |,res_dtl.data_status_cde  AS statuscode
      |,res_header.data_ts AS labresult_date
      |,res_dtl.Loinc_Cde  AS local_loinc_code
      |,ROW_NUMBER() OVER (PARTITION BY concat_ws('', res_dtl.data_src_finding_id, '_', res_dtl.concept_descr_num)
      |                    ORDER BY res_header.data_ts DESC NULLS LAST) res_row
      |FROM RES_HEADER
      |     JOIN RES_DTL ON (res_header.pat_person_num = res_dtl.pat_person_num AND
      |                      res_header.data_create_ts= res_dtl.serv_data_create_ts AND
      |                      {incl_lab_exception}
      |					  )
    """.stripMargin

  override protected def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val inclLabVal = if (loaderVars.groupId == "H984216" ) {"EXCEPTION"} else {"UNDEFINED"}
    val inclLabExcp =  if (inclLabVal == "EXCEPTION") { " res_header.beg_dttm=res_dtl.dttm" } else { " res_header.data_ts = res_dtl.data_ts"}
    sparkSql.replace("{incl_lab_exception}", inclLabExcp)
            .replace("{groupid}", loaderVars.groupId)
            .replace("{client_ds_id}", loaderVars.clientDsId.toString)
  }
}
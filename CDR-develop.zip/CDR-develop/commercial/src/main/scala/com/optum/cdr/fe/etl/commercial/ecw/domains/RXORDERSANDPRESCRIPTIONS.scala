package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.{mpv, mpvList}
import com.optum.oap.cdr.models.{map_predicate_values, rxorder}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object RXORDERSANDPRESCRIPTIONS extends FETableInfo[rxorder]{

  override def name: String = CDRFEParquetNames.rxorder

  override def dependsOn: Set[String] = Set("IMMUNIZATIONS", "BILLINGDATA", "ZH_ITEMS", "ZH_ITEMDETAIL", "RXORDER_CACHE", "MAP_PREDICATE_VALUES", CDRFEParquetNames.patient, CDRFEParquetNames.clinicalencounter)

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val parentidCol = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "BILLINGDATA", "BILLINGDATA",
      "ZH_ITEMS", "PARENTID").mkString(",")

    mpv(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "RXORDER", "RXORDER AND PRESCRIPTIONS",
      "ZH_ITEMS", "PARENTID").createOrReplaceTempView("map_predicate_output")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,issuedate
        |       ,patientid
        |       ,encounterid
        |       ,rxid
        |       ,LOCALDESCRIPTION
        |       ,ordervsprescription
        |       ,localmedcode
        |       ,localroute
        |       ,localstrengthperdoseunit
        |       ,localstrengthunit
        |       ,venue
        |       ,ordertype
        |       ,localtotaldose
        |       ,localdoseunit
        |       ,altmedcode
        |       ,localdaysupplied
        |       ,discontinuedate
        |       ,LOCALDOSEFREQ
        |       ,localduration
        |       ,localform
        |       ,localndc
        |       ,localqtyofdoseunit
        |       ,orderstatus
        |       ,signature
        |       ,localdaw
        |       ,localinfusionrate
        |FROM RXORDER_CACHE
        |WHERE PatientsFlag <> '1'
        |AND rnum = 1
        |
        |
        |UNION ALL
        |
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,issuedate
        |       ,patientid
        |       ,encounterid
        |       ,rxid
        |       ,localdescription
        |       ,ordervsprescription
        |       ,localmedcode
        |       ,localroute
        |       ,localstrengthperdoseunit
        |       ,localstrengthunit
        |       ,venue
        |       ,ordertype
        |       ,localtotaldose
        |       ,localdoseunit
        |       ,null as altmedcode
        |       ,null as localdaysupplied
        |       ,null as discontinuedate
        |       ,null as LOCALDOSEFREQ
        |       ,null as localduration
        |       ,localform
        |       ,null as localndc
        |       ,localqtyofdoseunit
        |       ,null as orderstatus
        |       ,null as signature
        |       ,null as localdaw
        |       ,null as localinfusionrate
        |FROM
        |(
        |	SELECT  x.*
        |	       ,Zh_Items.Itemname AS localdescription
        |	       ,Coalesce(localroute_Itemid, nullif(regexp_extract(lower(Zh_Items.itemname),'(sq|iv$|inj|neb|nasal|oph?thalmic|otic|sublingual|topical|oral|po$)',0),'')) AS localroute
        |        ,nullif(regexp_extract(lower(Zh_Items.itemname),'(inj(ection)?|tablet|solution|syr(inge)?|susp|cream|liquid)',0),'') as localform
        |		     ,Coalesce(localstrengthperdoseunit_dose, nullif(regexp_replace(nullif(regexp_extract(Zh_Items.itemname, '[0-9/,.]+ ?(mc?g|ml|meq|%)([^a-z]+(ml|mg))?', 0), ''), '(mc?g|ml|meq|%|\\s)', ''),'')) AS localstrengthperdoseunit
        |		     ,Coalesce(localstrengthunit_dose, nullif(regexp_replace(nullif(regexp_extract(lower(Zh_Items.itemname), '(mc?g|ml|meq|%)([^a-z](ml|mg))?', 0), ''), '[0-9]\\s?', ''),'')) AS localstrengthunit
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                            AS groupid
        |		       ,'immunizations'                                                                        AS datasrc
        |		       ,{client_ds_id}                                                                         AS client_ds_id
        |		       ,Immunizations.Givendate                                                                AS issuedate
        |		       ,'O'                                                                                    AS ordervsprescription
        |		       ,Immunizations.Patientid                                                                AS patientid
        |		       ,Immunizations.Immunizationid                                                           AS rxid
        |		       ,CASE WHEN Immunizations.Encounterid = '0' THEN null ELSE Immunizations.Encounterid END AS encounterid
        |		       ,Immunizations.Itemid                                                                   AS localmedcode
        |          ,Immunizations.Route                                                                    AS localroute_Itemid
        |          ,nullif(regexp_extract(Immunizations.Dose,'[\\.[0-9]]+',0),'')                          AS localstrengthperdoseunit_dose
        |          ,nullif(trim(nullif(regexp_replace(Immunizations.Dose,'[\\.[0-9]]+',''),'')),'')        AS localstrengthunit_dose
        |		       ,Immunizations.Dose                                                                     AS localtotaldose
        |		       ,'1'                                                                                    AS venue
        |		       ,'CH002045'                                                                             AS ordertype
        |		       ,nullif(regexp_extract(Immunizations.Dose,'[\\.[0-9]]+',0),'')                          AS localqtyofdoseunit
        |		       ,nullif(trim(nullif(regexp_replace(Immunizations.Dose,'[\\.[0-9]]+',''),'')),'')        AS localdoseunit
        |		       ,ROW_NUMBER() OVER (PARTITION BY Immunizations.Immunizationid ORDER BY Immunizations.modifieddate DESC NULLS LAST) rn
        |		FROM IMMUNIZATIONS
        |		JOIN {PATIENT} c ON (immunizations.patientid = c.patientid AND c.client_ds_id = {client_ds_id})
        |		WHERE immunizations.deleteflag <> '1'
        |		AND immunizations.itemid not IN ('0', '-1')
        |	) x
        |	INNER JOIN ZH_ITEMS ON X.Localmedcode = Zh_Items.Itemid
        |	INNER JOIN MAP_PREDICATE_OUTPUT ON zh_items.parentid = map_predicate_output.column_value
        |	WHERE rn = 1
        |)
        |
        |
        |UNION ALL
        |
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,issuedate
        |       ,patientid
        |       ,encounterid
        |       ,rxid
        |       ,localdescription
        |       ,ordervsprescription
        |       ,localmedcode
        |       ,localroute
        |       ,localstrengthperdoseunit
        |       ,localstrengthunit
        |       ,venue
        |       ,ordertype
        |       ,null as localtotaldose
        |       ,localdoseunit
        |       ,null as altmedcode
        |       ,null as localdaysupplied
        |       ,null as discontinuedate
        |       ,null as LOCALDOSEFREQ
        |       ,null as localduration
        |       ,localform
        |       ,null as localndc
        |       ,null as localqtyofdoseunit
        |       ,null as orderstatus
        |       ,null as signature
        |       ,null as localdaw
        |       ,null as localinfusionrate
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                        AS groupid
        |	       ,'billingdata'                                                                      AS datasrc
        |	       ,{client_ds_id}                                                                     AS client_ds_id
        |	       ,ce.arrivaltime                                                                     AS issuedate
        |	       ,'P'                                                                                AS ordervsprescription
        |	       ,ce.patientid                                                                       AS patientid
        |	       ,bd.encounterid                                                                     AS encounterid
        |	       ,bd.id                                                                              AS rxid
        |	       ,zh.itemname                                                                        AS localdescription
        |	       ,zh.itemid                                                                          AS localmedcode
        |	       ,nullif(regexp_extract(lower(zh.itemname),'(im|sq|iv$|inj|neb|nasal|oph?thalmic|otic|sublingual|topical|oral|po$)',0),'') AS localroute
        |	       ,nullif(regexp_extract(lower(zh.itemname),'(cream|drops|elixir|neb(ulizer)?|inj(ection)?|ointment|((inhalation|ophthalmic|topical) )?solution|suspension|spacers|spray|tab(let)?s?)+',0),'') AS localform
        |	       ,nullif(regexp_replace(nullif(regexp_extract(lower(zh.itemname), '(mc?g|ml|meq|%)([^a-z](ml|mg))?', 0), ''), '[0-9]\\s?', ''),'') AS localdoseunit
        |	       ,nullif(regexp_replace(nullif(regexp_extract(zh.itemname, '[0-9/,.]+ ?(mc?g|ml|meq|%)([^a-z]+(ml|mg))?', 0), ''), '(mc?g|ml|meq|%|\\s)', ''),'') AS localstrengthperdoseunit
        |	       ,nullif(regexp_replace(nullif(regexp_extract(lower(zh.itemname), '(mc?g|ml|meq|%)([^a-z](ml|mg))?', 0), ''), '[0-9]\\s?', ''),'') AS localstrengthunit
        |	       ,'1'                                                                                AS venue
        |	       ,'CH002047'                                                                         AS ordertype
        |	       ,row_number() over (partition by bd.id ORDER BY bd.modifieddate desc nulls last)    AS rownumber
        |	FROM BILLINGDATA bd
        |	INNER JOIN {CLINICALENCOUNTER} ce ON (bd.encounterid = ce.encounterid AND ce.client_ds_id = '{client_ds_id}')
        |	LEFT OUTER JOIN ZH_ITEMS zh ON (bd.itemid = zh.itemid)
        |	LEFT OUTER JOIN ZH_ITEMDETAIL zh_id ON (zh.itemid = zh_id.itemid)
        |	WHERE bd.id is not null
        |	AND zh_id.value is null
        |	AND zh_id.propid = '13'
        |	AND ('NO_MPV_MATCHES' IN ({parentid_col}) or zh.parentid IN ({parentid_col}))
        |)
        |WHERE rownumber = 1
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{PATIENT}", CDRFEParquetNames.patient)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{parentid_col}", parentidCol)
    )
  }
}
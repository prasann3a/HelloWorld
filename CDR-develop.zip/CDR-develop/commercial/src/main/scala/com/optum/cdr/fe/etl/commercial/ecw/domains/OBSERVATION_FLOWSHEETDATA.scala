package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_FLOWSHEETDATA extends FETableInfo[observation]{

  override def name: String = "OBSERVATION_FLOWSHEETDATA"

  override def dependsOn: Set[String] = Set("FLOWSHEETDATA", CDRFEParquetNames.clinicalencounter, "ZCM_OBSTYPE_CODE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,obsdate
        |       ,localcode
        |       ,obsresult
        |       ,localresult
        |       ,obstype
        |       ,local_obs_unit
        |       ,std_obs_unit
        |FROM
        |(
        |	SELECT  a.*
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                              AS groupid
        |		       ,'flowsheetdata'                                                                          AS datasrc
        |		       ,{client_ds_id}                                                                           AS client_ds_id
        |		       ,nullif(SUBSTR(Flowsheetdata.Hum_Value,1,255),'')                                         AS localresult
        |		       ,concat_ws('','{client_ds_id_prefix}',Flowsheetdata.Flowsheetid,'_',Flowsheetdata.Itemid) AS localcode
        |		       ,cEnc.arrivaltime                                                                         AS obsdate
        |		       ,cEnc.Patientid                                                                           AS patientid
        |		       ,Flowsheetdata.Encounterid                                                                AS encounterid
        |		       ,z.obstype
        |		       ,z.localunit                                                                              AS local_obs_unit
        |		       ,z.obstype_std_units                                                                      AS std_obs_unit
        |		       ,null                                                                                     AS obsresult
        |		       ,ROW_NUMBER() OVER (PARTITION BY cEnc.Patientid,flowsheetdata.Encounterid,z.obscode,z.obstype,cEnc.arrivaltime ORDER BY flowsheetdata.modifieddate DESC NULLS LAST) rn
        |		FROM FLOWSHEETDATA
        |		JOIN {CLINICALENCOUNTER} cEnc
        |			ON (flowsheetdata.encounterid = cEnc.encounterid AND cEnc.client_ds_id = {client_ds_id})
        |		JOIN ZCM_OBSTYPE_CODE z
        |			ON (z.obscode = concat_ws('', '{client_ds_id_prefix}', Flowsheetdata.Flowsheetid, '_', Flowsheetdata.Itemid) AND z.groupid = '{groupid}' AND z.datasrc = 'flowsheetdata')
        |		WHERE Flowsheetdata.hum_value IS NOT NULL
        |	) a
        |	WHERE rn = 1
        |)
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
    )
  }
}

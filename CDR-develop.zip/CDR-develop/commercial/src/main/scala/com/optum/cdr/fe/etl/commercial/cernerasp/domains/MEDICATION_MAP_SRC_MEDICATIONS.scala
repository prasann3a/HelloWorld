package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_MEDICATIONS extends FETableInfo[medication_map_src] {

  override def name: String = "MEDICATION_MAP_SRC_MEDICATIONS"

  override def dependsOn: Set[String] = Set("MEDICATIONS", "REFERENCEMEDICATION")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql("""select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, localgeneric, localbrand, localgpi, localform, localstrength, no_ndc, has_ndc, num_recs, ndc_src
                       |        from
                       |        (
                       |        select
                       |                '{groupid}'                     as groupid
                       |                ,'medications'                  as datasrc
                       |                ,{client_ds_id}                         as client_ds_id
                       |                ,case when ct.desc_ct is null then mdc.unique_synonym_identifier else nullif(substr(mdc.ordered_as,1,100), '') end
                       |                                                as localmedcode
                       |                ,mdc.ordered_as                 as localdescription
                       |                ,rfr.ndc                        as localndc
                       |                ,null                           as localgeneric
                       |                ,null                           as localbrand
                       |                ,null                           as localgpi
                       |                ,null                           as localform
                       |                ,null                           as localstrength
                       |                ,count(*)                       as no_ndc
                       |                ,0                              as has_ndc
                       |                ,count(*)                       as num_recs
                       |                ,count(*)                       as ndc_src
                       |        from MEDICATIONS mdc
                       |        inner join (select unique_synonym_identifier, rxnorm, ndc
                       |                    from (
                       |                        select
                       |                        r.unique_synonym_identifier as unique_synonym_identifier
                       |                        ,r.rxnorm as rxnorm
                       |                        ,nullif(replace(r.ndc, '-', ''), '') as ndc
                       |                        ,row_number() over (partition by unique_synonym_identifier, ndc, rxnorm order by fileid desc nulls first) rn
                       |                        from REFERENCEMEDICATION r)
                       |                    where rn =1) rfr
                       |        on      ( mdc.unique_synonym_identifier = rfr.unique_synonym_identifier )
                       |        left outer join
                       |                (
                       |                select unique_synonym_identifier, COUNT(distinct ordered_as) as desc_ct
                       |                from MEDICATIONS group by unique_synonym_identifier
                       |                having COUNT(distinct ordered_as)>20
                       |                ) ct
                       |        on      ( mdc.unique_synonym_identifier = ct.unique_synonym_identifier )
                       |        where mdc.unique_synonym_identifier is not null
                       |        and mdc.ordered_as is not null
                       |        group by case when ct.desc_ct is null then mdc.unique_synonym_identifier else nullif(substr(mdc.ordered_as,1,100), '') end, mdc.ordered_as, rfr.ndc
                       |        )"""
                        .stripMargin
                        .replace("{groupid}", groupId)
                        .replace("{client_ds_id}", clientDsId))
  }

}

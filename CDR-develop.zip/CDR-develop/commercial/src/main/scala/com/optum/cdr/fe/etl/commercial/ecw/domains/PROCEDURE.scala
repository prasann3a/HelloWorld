package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROCEDURE extends FEQueryAndMetadata[proceduredo]{

  override def name: String = CDRFEParquetNames.proceduredo

  override def dependsOn: Set[String] = Set("PROCEDURE_CACHE_BILLINGDATA", "PROCEDURE_CACHE_BILLINGDATA_CUSTOM", "PROCEDURE_CACHE_EDI_INV_CPT", "PROCEDURE_CACHE_ENC", "PROCEDURE_CACHE_FLOWSHEETDATA", "PROCEDURE_CACHE_HPI", "PROCEDURE_CACHE_LABDATA", "PROCEDURE_CACHE_PHYSICALEXAM", "PROCEDURE_CACHE_REFERRAL", "PROCEDURE_CACHE_STRUCTEXAM", "PROCEDURE_CACHE_STRUCTHPI", "PROCEDURE_CACHE_STRUCTPREVENTIVE")

  override def sparkSql: String =
    """
      |select * from PROCEDURE_CACHE_BILLINGDATA
      |union all
      |select * from PROCEDURE_CACHE_BILLINGDATA_CUSTOM
      |union all
      |select * from PROCEDURE_CACHE_EDI_INV_CPT
      |union all
      |select * from PROCEDURE_CACHE_ENC
      |union all
      |select * from PROCEDURE_CACHE_FLOWSHEETDATA
      |union all
      |select * from PROCEDURE_CACHE_HPI
      |union all
      |select * from PROCEDURE_CACHE_LABDATA
      |union all
      |select * from PROCEDURE_CACHE_PHYSICALEXAM
      |union all
      |select * from PROCEDURE_CACHE_REFERRAL
      |union all
      |select * from PROCEDURE_CACHE_STRUCTEXAM
      |union all
      |select * from PROCEDURE_CACHE_STRUCTHPI
      |union all
      |select * from PROCEDURE_CACHE_STRUCTPREVENTIVE
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.etl.commercial.ecw_labresult_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE3 extends FEQueryAndMetadata[ecw_labresult_cache]{

  override def name: String = "LABRESULT_CACHE3"

  override def dependsOn: Set[String] = Set("HL7LABDATADETAIL", "ELECTRONICLABRESULTS")

  override def sparkSql: String =
    """
      |select  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,labresultid
      |       ,localcode
      |       ,localresult
      |       ,localresult_numeric
      |       ,patientid
      |       ,datecollected
      |       ,encounterid
      |       ,localname
      |       ,localtestname
      |       ,normalrange
      |       ,dateavailable
      |       ,localunits
      |       ,resulttype
      |       ,rownumber
      |from
      |(
      |  SELECT  '{groupid}'                                      AS groupid
      |         ,'hl7labdatadetail'                               AS datasrc
      |         ,{client_ds_id}                                   AS client_ds_id
      |         ,concat_ws('',hl7.Reportid,'_',hl7.Serialno)      AS labresultid
      |         ,concat_ws('','{client_ds_id}','.HL7.',hl7.Hl7id) AS localcode
      |         ,lct.Patientid                                    AS patientid
      |         ,lct.Encounterid                                  AS encounterid
      |         ,hl7.Name                                         AS localname
      |         ,lct.Ordername                                    AS localtestname
      |         ,hl7.Units                                        AS localunits
      |         ,hl7.Hum_Range                                    AS normalrange
      |         ,hl7.Flag                                         AS resulttype
      |         ,safe_to_date(
      |                       concat_ws('',date_format(colldate,'dd-MM-yyyy'),
      |                                 case WHEN safe_to_number(nullif(replace(colltime,':',''),'')) is not null THEN colltime else '00:00:00' end
      |                       )
      |                       ,'dd-MM-yyyyHH:mm:ss'
      |          )                                                AS datecollected
      |         ,lct.Datereceived                                 AS dateavailable
      |         ,hl7.Hum_Value                                    AS localresult
      |         ,safe_to_number(hl7.Hum_Value)                    AS localresult_numeric
      |         ,row_number() over (partition by hl7.reportid,hl7.serialno ORDER BY lct.fileid desc nulls first,hl7.fileid desc nulls last,datemodified desc nulls last,hl7.hum_value desc nulls last ) AS rownumber
      |  FROM HL7LABDATADETAIL hl7
      |  INNER JOIN ELECTRONICLABRESULTS lct ON (lct.reportid = hl7.Reportid)
      |  WHERE nullIF(concat_ws('', hl7.Reportid, hl7.Serialno), '') is not null
      |  AND lct.colldate is not null
      |  AND lct.Patientid is not null
      |)
    """.stripMargin
}

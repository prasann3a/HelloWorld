package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_PROVIDER extends FEQueryAndMetadata[zh_provider]{

override def name: String = CDRFEParquetNames.zh_provider

override def dependsOn: Set[String] = Set("ZH_PROVIDERS")

override def sparkSql: String =
  """
    |SELECT  GROUPID
    |       ,CLIENT_DS_ID
    |       ,DATASRC
    |       ,LOCALPROVIDERID
    |       ,NPI
    |       ,FIRST_NAME
    |       ,MIDDLE_NAME
    |       ,LAST_NAME
    |       ,CREDENTIALS
    |       ,SUFFIX
    |FROM
    |(
    |	SELECT  distinct '{groupid}' as GROUPID
    |	       ,'{client_ds_id}' as CLIENT_DS_ID
    |	       ,'zh_providers' as DATASRC
    |	       ,p.Imreprov_code as LOCALPROVIDERID
    |	       ,npi
    |	       ,prov_firstname as FIRST_NAME
    |	       ,prov_middleinitial as MIDDLE_NAME
    |	       ,prov_lastname as LAST_NAME
    |	       ,prov_suffix as CREDENTIALS
    |	       ,prov_suffix as SUFFIX
    |	FROM ZH_PROVIDERS p
    | where upper(prov_lastname) not like 'ZZZ%'
    |)
  """.stripMargin
}

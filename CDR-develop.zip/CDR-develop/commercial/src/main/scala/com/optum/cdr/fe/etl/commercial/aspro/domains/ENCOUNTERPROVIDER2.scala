package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.encounterprovider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}
import org.apache.spark.storage.StorageLevel

object ENCOUNTERPROVIDER2 extends FEQueryAndMetadata[encounterprovider] {

  override def name: String = "ENCOUNTERPROVIDER2"

  override def dependsOn: Set[String] = Set("PROCEDURE_CACHE")

  override def sparkSql: String =
    """
      |select datasrc, encounterid, facilityid, patientid, orderingproviderid as providerid, 'ordering provider' as providerrole, proceduredate as encountertime
      |from
      |(
      |PROCEDURE_CACHE
      |)
      |where ordprov_row=1 and patientid is not null and orderingproviderid is not null
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.mckesson_pgn_observation_cache
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.map_predicate_values
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_CACHE_TPM300_PAT_VISIT extends FETableInfo[mckesson_pgn_observation_cache]{
  override def name: String = "OBSERVATION_CACHE_TPM300_PAT_VISIT"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_ZH_TAS915_MEASUREMENT","MCKESSON_PGN_V1_T_PTVITAILS","ZCM_OBSTYPE_CODE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val vtlSgnIds = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LOCALRESULTPREFIX","OBSERVATION","PTVITAILS","VTL_SGN_INT_ID").mkString(",")
    val methodFlgExcl = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LOCALRESULTEXC","OBSERVATION","PTVITAILS","METHOD_FLAG").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |
        |WITH uni_visit AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        | WHERE Vst_Int_Id IS NOT NULL
        |   AND Psn_Int_Id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'  )
        |,meas_visit AS
        |(SELECT * FROM
        |(SELECT M.*, ROW_NUMBER() OVER (PARTITION BY vtl_sgn_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_ZH_TAS915_MEASUREMENT M
        |     )
        |  WHERE rn = 1 )
        |
        |SELECT t.*, safe_to_number(localresult) AS localresult_numeric
        |FROM
        |(SELECT
        |        '{groupid}' AS groupid
        |	,'ptvitails' 		AS datasrc
        |	,{client_ds_id} 		AS client_ds_id
        |	,CASE WHEN vtl.Vtl_Sgn_Int_Id IN ({vtl_sgn_ids}) THEN concat_ws('', vtl.Val_1, '/', vtl.Val_2) ELSE vtl.Val_1 END  AS localresult
        |	,NVL2(vtl.Vtl_Sgn_Int_Id, concat_ws('', '{client_ds_id}', '.', vtl.Vtl_Sgn_Int_Id), NULL) AS localcode
        |	,vtl.Entry_For_Date     AS obsdate
        |	,uni_visit.Psn_Int_Id  	AS patientid
        |	,vtl.vst_int_id  	AS encounterid
        |	,NULL		 	AS facilityid
        |	,z.obstype
        |	,CASE WHEN vtl.Method_Flag = 'F' THEN 'F' ELSE z.localunit END AS local_obs_unit
        |    	,z.obstype_std_units 	AS std_obs_unit
        |	,NULL 	                AS obsresult
        |	,ROW_NUMBER() OVER (PARTITION BY uni_visit.Psn_Int_Id,vtl.Vst_Int_Id,vtl.Vtl_Sgn_Int_Id,vtl.Entry_For_Date,z.obstype
        |			    ORDER BY vtl.Lst_Mod_Ts DESC NULLS LAST) obs_rn
        |
        |
        |	,concat_ws('', 'pv.', vtl.T_Ptvitails_Int_Id)   AS labresultid
        |
        |
        |
        |
        |        ,meas_visit.Msr_Ds        AS localname
        |        ,meas_visit.Msr_Ds        AS LOCALTESTNAME
        |        ,z.Localunit              AS LOCALUNITS
        |        ,vtl.Entry_For_Date       AS DATEAVAILABLE
        |        ,vtl.Lst_Mod_Ts           AS labresult_date
        |	,ROW_NUMBER() OVER
        |        (PARTITION BY uni_visit.Psn_Int_Id, vtl.Vst_Int_Id, vtl.Vtl_Sgn_Int_Id, vtl.Entry_For_Date, z.obstype
        |         ORDER BY vtl.Lst_Mod_Ts DESC NULLS LAST,vtl.fileid DESC NULLS LAST, vtl.T_Ptvitails_Int_Id desc NULLS LAST ) res_row
        |FROM MCKESSON_PGN_V1_T_PTVITAILS vtl
        |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
        |                                z.datasrc = 'ptvitails' AND
        |
        |				z.obscode = concat_ws('', '{client_ds_id}', '.', vtl.Vtl_Sgn_Int_Id))
        |    JOIN UNI_VISIT ON (vtl.vst_int_id = uni_visit.vst_int_id)
        |    LEFT JOIN MEAS_VISIT ON (vtl.vtl_sgn_int_id = meas_visit.vtl_sgn_int_id)
        |WHERE vtl.Entry_For_Date IS NOT NULL
        |  AND vtl.row_sta_cd <> 'D'
        |  AND vtl.strike_out_flag = '0'
        |  AND (vtl.Method_Flag NOT IN ({method_flg_excl}) OR vtl.Method_Flag IS NULL)
        | ) t
      """
        .stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{vtl_sgn_ids}", vtlSgnIds)
        .replace("{method_flg_excl}", methodFlgExcl)
    )
  }

}

package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.patient_id
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object PATIENT_ID extends FEQueryAndMetadata[patient_id]{

  override def name: String = CDRFEParquetNames.patient_id

  override def dependsOn: Set[String] = Set("LSS_PBRPATIENTS")

  override def sparkSql: String =
    """
      |SELECT datasrc
      |       ,patientid
      |       ,idtype
      |       ,idvalue
      |FROM
      |(
      |	SELECT  x.*
      |	       ,row_number() over (partition by PatientID,IDType ORDER BY RowUpdateDateTime desc nulls first ) AS rownumber
      |	FROM
      |	(
      |		SELECT 'pbrpatients'                                                                                      AS datasrc
      |		       ,'SSN'                                                                                              AS idtype
      |		       ,CASE WHEN replace(pbr.Socsecnumber,'-') = '000000000' THEN null ELSE nullif(replace(Socsecnumber,'-'),'') END AS idvalue
      |		       ,nullif(concat_ws('',pbr.Sourceid,pbr.Patientid),'')                                                AS patientid
      |		       ,pbr.RowUpdateDateTime
      |		FROM LSS_PBRPATIENTS pbr
      |		WHERE pbr.Socsecnumber is not null
      |	) x
      |	WHERE patientid is not null
      |)
      |WHERE rownumber = 1
      |AND idvalue is not null
    """.stripMargin
}

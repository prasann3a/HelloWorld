package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object OBSERVATION_DIAGNOSIS extends FEQueryAndMetadata[observation] {

  override def name: String = "OBSERVATION_DIAGNOSIS"

  override def dependsOn: Set[String] = Set("ASPRO_DIAGNOSIS", "HXDIAGNOSIS", "PROCRESULTS", "ZCM_OBSTYPE_CODE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, encounterid, patientid, obsdate, localcode, obstype, obsresult, localresult, statuscode, std_obs_unit, {client_ds_id} as client_ds_id
      |from
      |(select '{groupid}'                  as groupid
      |       ,zc.datasrc                 as datasrc
      |       ,d.imreenc_code             as encounterid
      |       ,d.imredemec_code           as patientid
      |       ,d.tag_systemdate           as obsdate
      |       ,d.dx_code                  as localcode
      |       ,case when zc.obstype='EXERCISE' then nullif(substr(d.dx_comment,1,255), '') else d.dx_title end  as localresult
      |       ,null                     as obsresult
      |       ,zc.obstype               as obstype
      |       ,d.dx_activity							as statuscode
      |	   ,zc.OBSTYPE_STD_UNITS as std_obs_unit
      |from ASPRO_DIAGNOSIS d
      |inner join ZCM_OBSTYPE_CODE zc on (zc.groupid ='{groupid}'  and zc.datasrc='diagnosis' and d.dx_code= zc.obscode)
      |
      |union
      |select '{groupid}'                 as groupid
      |       ,zc.datasrc                  as datasrc
      |       ,hd.imreenc_code             as encounterid
      |       ,hd.patient_id               as patientid
      |       ,hd.tag_systemdate           as obsdate
      |       ,hd.source_code               as localcode
      |       ,case when zc.obstype='EXERCISE' or hd.source_code='1621' then nullif(substr(hd.comments,1,255), '') else hd.title end       as localresult
      |       ,null                     as obsresult
      |       ,zc.obstype               as obstype
      |       ,hd.activity_code					as statuscode
      |	   ,zc.OBSTYPE_STD_UNITS as std_obs_unit
      |from HXDIAGNOSIS hd
      |inner join ZCM_OBSTYPE_CODE zc on (zc.groupid ='{groupid}' and zc.datasrc='hxdiagnosis' and hd.source_code = zc.obscode)
      |
      |union
      |select '{groupid}'                  as groupid
      |       ,zc.datasrc                as datasrc
      |       ,pr.imreenc_code           as encounterid
      |       ,pr.imredem_code           as patientid
      |       ,pr.result_observationdate as obsdate
      |       ,pr.result_name            as localcode
      |       ,pr.result_value           as localresult
      |       ,null                      as obsresult
      |       ,zc.obstype                as obstype
      |       ,null		          as statuscode
      |	   ,zc.OBSTYPE_STD_UNITS as std_obs_unit
      |from PROCRESULTS pr
      |inner join ZCM_OBSTYPE_CODE zc on (zc.groupid ='{groupid}' and zc.datasrc='procresults' and pr.result_name = zc.obscode)
      |
      |union
      |select '{groupid}'                 as groupid
      |       ,'hxdiagnosis'            as datasrc
      |       ,hd.imreenc_code             as encounterid
      |       ,hd.patient_id               as patientid
      |       ,hd.tag_systemdate           as obsdate
      |       ,hd.title               as localcode
      |       ,hd.title               as localresult
      |       ,hd.title               as obsresult
      |       ,'SMOKE'               as obstype
      |       ,hd.activity_Code      as statuscode
      |	   ,NULL as  std_obs_unit
      |from HXDIAGNOSIS hd
      |where hd.source_code='FREETEXT' and (lower(hd.title) like '%smoke%' or lower(hd.title) like '%tobacco%')
      |)
      |where localcode is not null and patientid is not null and obsdate is not null
    """.stripMargin

}

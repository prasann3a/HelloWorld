package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.cdr.fe.etl.commercial.cattails.domains.InitialDependencies
import com.optum.cdr.fe.utils.nonnumeric_labs_localresult_25.NONNUMERIC_LABRESULT
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}


object CenentQueries extends BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] =
    InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)

  override def queryRegistry = QueryRegistry.queries  ++ QueryRegistry.drug_assign_queries

}

object CenentQueriesWithDrugAssign extends BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] =
    InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)

  override def queryRegistry = QueryRegistry.drug_assign_queries

}

object InitialDependencies {

  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
  FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PREDICATE_VALUES")
    , FELoadFromParquet[map_custom_proc](name = "MAP_CUSTOM_PROC", parquetLocation = s"$mappingParquetPath", tableName = "MAP_CUSTOM_PROC")
    , FELoadFromParquet[map_unit](name = "MAP_UNIT", parquetLocation = s"$mappingParquetPath", tableName = "MAP_UNIT")
    , FELoadFromParquet[unit_remap](name = "UNIT_REMAP", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_REMAP")
    , FELoadFromParquet[metadata_lab](name = "METADATA_LAB", parquetLocation = s"$mappingParquetPath", tableName = "METADATA_LAB")
    , FELoadFromParquet[unit_conversion](name = "UNIT_CONVERSION", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_CONVERSION")
    , FELoadFromParquet[map_patient_type](name = "MAP_PATIENT_TYPE", parquetLocation = s"$mappingParquetPath", tableName="MAP_PATIENT_TYPE")
    , FELoadFromParquet[acct](name = "ACCT", parquetLocation = s"$baseParquetLocation", tableName = "ACCT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[asscid](name = "ASSCID", parquetLocation = s"$baseParquetLocation", tableName = "ASSCID", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[asscnm](name = "ASSCNM", parquetLocation = s"$baseParquetLocation", tableName = "ASSCNM", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[assoct](name = "ASSOCT", parquetLocation = s"$baseParquetLocation", tableName = "ASSOCT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[chrg](name = "CHRG", parquetLocation = s"$baseParquetLocation", tableName = "CHRG", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[disch](name = "DISCH", parquetLocation = s"$baseParquetLocation", tableName = "DISCH", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[encntr](name = "ENCNTR", parquetLocation = s"$baseParquetLocation", tableName = "ENCNTR", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[encrat](name = "ENCRAT", parquetLocation = s"$baseParquetLocation", tableName = "ENCRAT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[encrdn](name = "ENCRDN", parquetLocation = s"$baseParquetLocation", tableName = "ENCRDN", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[findng](name = "FINDNG", parquetLocation = s"$baseParquetLocation", tableName = "FINDNG", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[insure](name = "INSURE", parquetLocation = s"$baseParquetLocation", tableName = "INSURE", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[ippev](name = "IPPEV", parquetLocation = s"$baseParquetLocation", tableName = "IPPEV", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[mrcode](name = "MRCODE", parquetLocation = s"$baseParquetLocation", tableName = "MRCODE", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[orderz](name = "ORDERZ", parquetLocation = s"$baseParquetLocation", tableName = "ORDERZ", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[ordrme](name = "ORDRME", parquetLocation = s"$baseParquetLocation", tableName = "ORDRME", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[person](name = "PERSON", parquetLocation = s"$baseParquetLocation", tableName = "PERSON", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[problm](name = "PROBLM", parquetLocation = s"$baseParquetLocation", tableName = "PROBLM", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[provdr](name = "PROVDR", parquetLocation = s"$baseParquetLocation", tableName = "PROVDR", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[prsnad](name = "PRSNAD", parquetLocation = s"$baseParquetLocation", tableName = "PRSNAD", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[prsnph](name = "PRSNPH", parquetLocation = s"$baseParquetLocation", tableName = "PRSNPH", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[servce](name = "SERVCE", parquetLocation = s"$baseParquetLocation", tableName = "SERVCE", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[servme](name = "SERVME", parquetLocation = s"$baseParquetLocation", tableName = "SERVME", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[transfer](name = "TRANSFER", parquetLocation = s"$baseParquetLocation", tableName = "TRANSFER", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_dict10_plan](name = "ZH_DICT10_PLAN", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DICT10_PLAN", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_dict21_chargemaster](name = "ZH_DICT21_CHARGEMASTER", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DICT21_CHARGEMASTER", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_dict31](name = "ZH_DICT31", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DICT31", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_dict32](name = "ZH_DICT32", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DICT32", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_dict71_carrier](name = "ZH_DICT71_CARRIER", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DICT71_CARRIER", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_labnrm](name = "ZH_LABNRM", parquetLocation = s"$baseParquetLocation", tableName = "ZH_LABNRM", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_vt](name = "ZH_VT", parquetLocation = s"$baseParquetLocation", tableName = "ZH_VT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_xcncpt](name = "ZH_XCNCPT", parquetLocation = s"$baseParquetLocation", tableName = "ZH_XCNCPT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_xfaclt](name = "ZH_XFACLT", parquetLocation = s"$baseParquetLocation", tableName = "ZH_XFACLT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_xloctn](name = "ZH_XLOCTN", parquetLocation = s"$baseParquetLocation", tableName = "ZH_XLOCTN", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_xmedcn](name = "ZH_XMEDCN", parquetLocation = s"$baseParquetLocation", tableName = "ZH_XMEDCN", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_xmedrt](name = "ZH_XMEDRT", parquetLocation = s"$baseParquetLocation", tableName = "ZH_XMEDRT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_xservc](name = "ZH_XSERVC", parquetLocation = s"$baseParquetLocation", tableName = "ZH_XSERVC", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zcm_obstype_code](name = "ZCM_OBSTYPE_CODE", parquetLocation = s"$mappingParquetPath", tableName = "ZCM_OBSTYPE_CODE")

  )
}

object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    ALLERGY
    , TEMP_CLAIM_PROC_CACHE1
    , TEMP_CLAIM_PROC_CACHE2
    , TEMP_MRCODE
    , TEMP_CLAIM_PART1
    , TEMP_CLAIM_PART2
    , TEMP_PROCEDURE_PART1
    , TEMP_PROCEDURE_PART2
    , CLAIM
    , PROCEDURE
    , TEMP_DIAGNOSIS_PART1
    , TEMP_DIAGNOSIS_PART2
    , TEMP_DIAGNOSIS_PART3
    , DIAGNOSIS
    , DICTIONARY
    , INSURANCE
    , LABORDER
    , LAB_MAP_DICT
    , MBORDER
    , PROV_PAT_REL
    , LABRESULT_SERVCE_CACHE
    , GTT_LABRESULT_NONNUMERIC
    , NONNUMERIC_LABRESULT
    , LABRESULT_CACHE
    , LABRESULT
    , PATIENTADDR
    , PATIENTCONTACT
    , PROCEDUREDO_FINDING
    , OBSERVATION
    , PATIENT_CACHE
    , PATIENT_ID
    , PATIENTDETAIL
    , PATIENT
    , TREATMENT_ADMINISTERED
    , TREATMENT_ORDERED
    , CLINICALENCOUNTER
    , ENCOUNTERCAREAREA_DISCH
    , ENCOUNTERCAREAREA_TRANSFER
    , ENCOUNTERCAREAREA
    , ENCOUNTERREASON
    , ZH_SERVICE_LINE
    , RXORDER
    , RXADMIN
    , ENCOUNTERPROVIDER
    , ZH_PROVIDER
    , ZH_PROVIDER_IDENTIFIER
  )

  val drug_assign_queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    MEDICATION_MAP_SRC
    ,MEDICATION_MAP_SRC_ORDERZ
    ,MEDICATION_MAP_SRC_PROBLM
    ,MEDICATION_MAP_SRC_SERVCE

  )
}

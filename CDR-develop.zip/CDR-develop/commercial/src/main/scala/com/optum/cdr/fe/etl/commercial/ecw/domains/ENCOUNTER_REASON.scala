package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.clinicalencounter
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{encounterreason, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ENCOUNTER_REASON extends FETableInfo[encounterreason] {

  override def name: String = CDRFEParquetNames.encounterreason

  override def dependsOn: Set[String] = Set("ENC", "CLINICALENCOUNTER", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    loadedDependencies("ENC").as[enc].createOrReplaceTempView("ENC")
    loadedDependencies("CLINICALENCOUNTER").as[clinicalencounter].createOrReplaceTempView("CLINICALENCOUNTER")


    val predicate_values = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val exclViscodeId = mpvList(predicate_values, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ENCOUNTERS", "CLINICALENCOUNTER", "ENC", "VISITSTSCODEID").mkString(",")

    val encFilVal = if (runtimeVar.groupId == "H969977") " and not (deleteflag = '1' and status = 'CANC')" else " and 1=1"


      sparkSession.sql(
      """
    select groupid, datasrc, client_ds_id, localreasontext, encounterid, patientid, reasontime
 |from
 |(
 |SELECT '{groupid}' as groupid
 |,'enc' as datasrc
 |,{client_ds_id} as client_ds_id
 |,nullif(substr(e.reason,1,2000), '') AS localreasontext
 |,e.Encounterid  AS encounterid
 |,e.Patientid  AS patientid
 |,e.Enc_Date  AS reasontime
 |FROM (SELECT * FROM
 |	(SELECT m.*, ROW_NUMBER() OVER (PARTITION BY encounterid ORDER BY modifieddate
 |	       DESC nulls last) rn
 |	 FROM ENC m
 |	 WHERE visitstscodeid NOT IN ({excl_viscodeid}) {enc_fil_val})
 |      WHERE rn = 1
 |      ) e
 |      JOIN CLINICALENCOUNTER  t
 |          ON (t.encounterid = e.encounterid AND t.client_ds_id = {client_ds_id})
 |WHERE e.visitstscodeid IS NOT NULL
 |AND e.reason IS NOT NULL
 |
 |)

  """.stripMargin
          .replace("{enc_fil_val}", encFilVal)
        .replace("{excl_viscodeid}", exclViscodeId)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)


    )

  }

}












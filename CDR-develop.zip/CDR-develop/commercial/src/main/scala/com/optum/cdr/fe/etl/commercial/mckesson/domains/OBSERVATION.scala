package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object OBSERVATION extends FEQueryAndMetadata[observation] {
  override def name: String = CDRFEParquetNames.observation

  override def dependsOn: Set[String] = Set("OBSERVATION_TEMP_CCDBA_PAT_RESULTS","OBSERVATION_TEMP_ENT_PATIENT","OBSERVATION_TEMP_CCDBA_O_PAT","OBSERVATION_TEMP_CCDBA_PF_RESULTS")

  override def sparkSql: String =
    """
      |SELECT * FROM OBSERVATION_TEMP_CCDBA_PAT_RESULTS
      |UNION ALL
      |SELECT * FROM OBSERVATION_TEMP_ENT_PATIENT
      |UNION ALL
      |SELECT * FROM OBSERVATION_TEMP_CCDBA_O_PAT
      |UNION ALL
      |SELECT * FROM OBSERVATION_TEMP_CCDBA_PF_RESULTS
    """
    .stripMargin

}

package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader,CDRFEParquetNames}
import com.optum.cdr.fe.utils.Functions.mpvList
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.rx_patient_reported


object PATIENTREPORTEDMEDS extends FETableInfo[rx_patient_reported]{
  override def name: String = CDRFEParquetNames.rx_patient_reported

  override def dependsOn: Set[String] = Set("ENT_CPI_MEDICATION" , "ZH_ENT_CONFIG_LOV" ,"MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val excl_id = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "ENT_CPI_MEDICATION", "PATIENTREPORTEDMEDS", "ENT_CPI_MEDICATION", "DRUG_ID").mkString(",")

    sparkSession.sql(
      """WITH uni_meds AS
         |(SELECT * FROM
         |(SELECT m.*, ROW_NUMBER() OVER (PARTITION BY cpi_medication_seq ORDER BY modified_dt DESC NULLS LAST) rn_m
         | FROM ENT_CPI_MEDICATION m
         | WHERE Cpi_Seq IS NOT NULL
         |  )
         | WHERE rn_m = 1)
         |select 'ent_cpi_medication' as datasrc, patientid, encounterid, discontinuedate, discontinuereason, localdrugdescription, localform, localgpi, localndc, localqtyofdoseunit, localroute, localstrengthperdoseunit, localstrengthunit, reportedmedid, medreportedtime, localmedcode, localdoseunit
         |from
         |(
         |SELECT  NULL                		           AS encounterid
         |       ,uni_meds.cpi_seq                       AS patientid
         |       ,uni_meds.Discontinued_Dt	           AS discontinuedate
         |       ,rsn.Lov_Value			               AS discontinuereason
         |       ,uni_meds.Cpi_Medication_Seq	           AS reportedmedid
         |       ,CASE WHEN uni_meds.Drug_id IN ({excl_id}) OR uni_meds.Drug_id IS NULL THEN uni_meds.drug_name
         |             ELSE COALESCE(uni_meds.drug_id, uni_meds.drug_name) END   AS localmedcode
         |       ,uni_meds.drug_name                           AS localdrugdescription
         |       ,coalesce(nullif(regexp_extract(uni_meds.strength,'[\\.0-9,\\-\\\\]+', 0), ''), uni_meds.ADMIN_DOSE_QUANTITY_LO)  AS LOCALSTRENGTHPERDOSEUNIT
         |       ,coalesce(nullif(trim(nullif(regexp_replace_5param(uni_meds.strength,'[\\.0-9,\\-\\\\]+','',1,1), '')), ''), uni_meds.ADMIN_DOSE_UNIT_OVERRIDE, unit.lov_value ) AS LOCALSTRENGTHUNIT
         |       ,unit.lov_value	 		                     AS localdoseunit
         |       ,concat_ws('', {client_ds_id}, '.', coalesce(rsn.lov_value, uni_meds.route_lseq, uni_meds.route_override)) as LOCALROUTE
         |       ,coalesce(frm.lov_value, uni_meds.form_lseq, uni_meds.form_override, uni_meds.admin_dose_unit_override) as localform
         |       ,NULL	                                     AS localqtyofdoseunit
         |       ,uni_meds.ndc			                     AS localndc
         |       ,NULL	                                     AS localgpi
         |       ,uni_meds.created_dt	                         AS medreportedtime
         |       ,ROW_NUMBER() OVER (PARTITION BY uni_meds.Cpi_Medication_Seq ORDER BY uni_meds.modified_dt DESC NULLS LAST) rn
         |FROM UNI_MEDS
         |     LEFT OUTER JOIN ZH_ENT_CONFIG_LOV rsn ON (uni_meds.route_lseq = rsn.lov_seq AND rsn .lov_id = 'Medication_Route')
         |     LEFT OUTER JOIN ZH_ENT_CONFIG_LOV frm ON (uni_meds.form_lseq  = frm.lov_seq AND frm.lov_id = 'Medication_Form')
         |     LEFT OUTER JOIN ZH_ENT_CONFIG_LOV unit ON (uni_meds.admin_dose_unit_lseq = unit.lov_seq AND unit.lov_id = 'Medication_Dose_Unit')
         |
         |
         |
         |)
         |where rn = 1
       """.stripMargin.replace("{excl_id}",excl_id).replace("{client_ds_id}",clientDsId))
  }

}

package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.cdr.fe.etl.commercial.mckesson_pgn_gtt_labresult_nonnumeric
import org.apache.spark.storage.StorageLevel

object GTT_LABRESULT_NONNUMERIC extends FEQueryAndMetadata[mckesson_pgn_gtt_labresult_nonnumeric]{
  override def name: String = "GTT_LABRESULT_NONNUMERIC"

  override def dependsOn: Set[String] = Set("OBSERVATION_CACHE_TMA100_CLINICAL_DOC","OBSERVATION_CACHE_TPM300_PAT_VISIT","LABRESULT_CACHE_1","LABRESULT_CACHE_2","LABRESULT_CACHE_3","LABRESULT_CACHE_4")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, dateavailable, encounterid, localname, localtestname, localunits, LABRESULT_DATE, localresult_numeric, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25, null as datecollected, null as  laborderid, null as labordereddate, null as normalrange, null as local_loinc_code, null as RESULTTYPE, null as STATUSCODE, null as LOCALSPECIMENTYPE
      |from
      |(
      |OBSERVATION_CACHE_TMA100_CLINICAL_DOC
      |)
      |where obstype = 'LABRESULT' AND res_row = 1 AND localresult_numeric IS NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, dateavailable, encounterid, localname, localtestname, localunits, LABRESULT_DATE, localresult_numeric, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25, null as datecollected, null as  laborderid, null as labordereddate, null as normalrange, null as local_loinc_code, null as RESULTTYPE, null as STATUSCODE, null as LOCALSPECIMENTYPE
      |from
      |(
      |OBSERVATION_CACHE_TPM300_PAT_VISIT
      |)
      |where obstype = 'LABRESULT' AND res_row = 1 AND localresult_numeric IS NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, dateavailable, encounterid, localname, localtestname, localunits, LABRESULT_DATE, localresult_numeric, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25, datecollected, laborderid, LABORDEREDDATE, normalrange, local_loinc_code, null as RESULTTYPE, null as STATUSCODE, null as LOCALSPECIMENTYPE
      |from
      |(
      |LABRESULT_CACHE_1
      |)
      |where res_row = 1 AND localresult_numeric IS NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, dateavailable, encounterid, localname, LOCALTESTNAME,null as localunits, dateavailable as LABRESULT_DATE, localresult_numeric, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25,null as  DATECOLLECTED, laborderid, labordereddate, null as normalrange, null as local_loinc_code, null as RESULTTYPE, null as STATUSCODE, null as LOCALSPECIMENTYPE
      |from
      |(
      |LABRESULT_CACHE_2
      |)
      |where res_no = 1 AND localresult_numeric IS NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, DATEAVAILABLE, ENCOUNTERID, localname, LOCALTESTNAME, LOCALUNITS, DATEAVAILABLE as LABRESULT_DATE, localresult_numeric, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25, DATECOLLECTED, LABORDERID, null as labordereddate, NORMALRANGE, null as local_loinc_code, RESULTTYPE, STATUSCODE, LOCALSPECIMENTYPE
      |from
      |(
      |LABRESULT_CACHE_3
      |)
      |where re_row = 1 AND localresult_numeric IS NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, DATEAVAILABLE, ENCOUNTERID, localname, LOCALTESTNAME, LOCALUNITS, DATEAVAILABLE as LABRESULT_DATE, localresult_numeric, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25, null as  DATECOLLECTED, LABORDERID, LABORDEREDDATE, NORMALRANGE, null as local_loinc_code, RESULTTYPE, STATUSCODE, LOCALSPECIMENTYPE
      |from
      |(
      |LABRESULT_CACHE_4
      |)
      |where resw_row = 1 AND localresult_numeric IS NULL AND labresultid IS NOT NULL
    """.stripMargin

}

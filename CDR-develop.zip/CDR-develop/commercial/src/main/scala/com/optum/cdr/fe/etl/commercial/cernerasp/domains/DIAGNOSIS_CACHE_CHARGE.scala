package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{diagnosis, map_predicate_values}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object DIAGNOSIS_CACHE_CHARGE extends FETableInfo[diagnosis]{

  override def name: String = "DIAGNOSIS_CACHE_CHARGE"

  override def dependsOn: Set[String] = Set("CHARGE", "CHARGEDETAIL", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listIcd9 = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "ICD9","DIAGNOSIS","CHARGEDETAIL","HUM_TYPE").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,client_ds_id
        |       ,datasrc
        |       ,patientid
        |       ,encounterid
        |       ,localdiagnosis
        |       ,dx_timestamp
        |       ,mappeddiagnosis
        |       ,localdiagnosisproviderid
        |       ,codetype
        |       ,primarydiagnosis
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                                                                                   AS groupid
        |	       ,{client_ds_id}                                                                                                                                AS client_ds_id
        |	       ,'charge'                                                                                                                                      AS datasrc
        |	       ,c.unique_person_identifier                                                                                                                    AS patientid
        |	       ,c.unique_visit_identifier                                                                                                                     AS encounterid
        |	       ,cd.code                                                                                                                                       AS localdiagnosis
        |	       ,c.service_date_time                                                                                                                           AS dx_timestamp
        |	       ,cd.code                                                                                                                                       AS mappeddiagnosis
        |	       ,coalesce(case WHEN c.ordering_physician_identifier = '0' THEN null else c.ordering_physician_identifier end,c.verifying_physician_identifier) AS localdiagnosisproviderid
        |	       ,CASE WHEN cd.hum_type IN ({list_icd9}) AND c.service_date_time >= to_date('2015-10-01 00:00:00','yyyy-MM-dd HH:mm:ss') THEN 'ICD10'
        |              WHEN cd.hum_type IN ({list_icd9}) AND c.service_date_time < to_date('2015-10-01 00:00:00','yyyy-MM-dd HH:mm:ss') THEN 'ICD9' END       AS codetype
        |	       ,CASE WHEN cd.hum_type IN ({list_icd9}) AND cd.hum_sequence = '1' THEN '1' ELSE '0' END                                                        AS primarydiagnosis
        |	       ,row_number() over (partition by c.unique_person_identifier,cd.code,c.service_date_time ORDER BY c.update_date_time desc nulls last)           AS rownumber
        |	FROM CHARGE c
        |	INNER JOIN CHARGEDETAIL cd ON (c.unique_charge_item_identifier = cd.unique_charge_item_identifier)
        |	WHERE c.unique_person_identifier is not null
        |	AND c.service_date_time is not null
        |	AND cd.code is not null
        |	AND cd.hum_type IN ({list_icd9})
        |	AND c.active <> '0'
        |)
        |WHERE rownumber = 1
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{list_icd9}", listIcd9)
    )
  }
}

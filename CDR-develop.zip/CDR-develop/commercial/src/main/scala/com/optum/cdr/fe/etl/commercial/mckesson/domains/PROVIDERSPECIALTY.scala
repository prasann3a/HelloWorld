package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.cdr.models.prov_spec
import com.optum.oap.sparkdataloader.CDRFEParquetNames

object PROVIDERSPECIALTY extends FEQueryAndMetadata[prov_spec]{
  override def name: String = CDRFEParquetNames.prov_spec

  override def dependsOn: Set[String] = Set("ZH_ENT_CONFIG_STAFF_SPECIALTY")

  override def sparkSql: String =
    """
      |select localproviderid, localspecialtycode, localcodesource
      |from
      |(
      |SELECT  staff_seq 	AS localproviderid
      |       ,concat_ws('', {client_ds_id}, '.', specialty_seq)  AS localspecialtycode,
      |        'zh_provider'   AS localcodesource,
      |        ROW_NUMBER() OVER (PARTITION BY staff_seq ORDER BY modified_dt DESC NULLS LAST) rn
      |FROM ZH_ENT_CONFIG_STAFF_SPECIALTY
      |WHERE specialty_seq IS NOT NULL
      |
      |)
      |where rn = 1
    """.stripMargin
}

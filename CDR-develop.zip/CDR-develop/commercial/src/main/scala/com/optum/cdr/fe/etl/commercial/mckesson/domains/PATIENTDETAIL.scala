package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.patientdetail

object PATIENTDETAIL extends FEQueryAndMetadata[patientdetail]{
  override def name: String = CDRFEParquetNames.patientdetail

  override def dependsOn: Set[String] = Set("TEMP_PATIENT_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'FIRST_NAME' as patientdetailtype, firstname as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where first_row = 1 and firstname is not null
      |
      |union all
      |
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'LAST_NAME' as patientdetailtype, lastname as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where last_row = 1 and lastname is not null
      |
      |union all
      |
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'MIDDLE_NAME' as patientdetailtype, middlename as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where middle_row = 1 and middlename is not null
      |
      |union all
      |
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'GENDER' as patientdetailtype, gender as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where gender_row = 1 and gender is not null
      |
      |union all
      |
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'RACE' as patientdetailtype, race as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where race_row = 1 and race is not null
      |
      |union all
      |
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'MARITAL' as patientdetailtype, Maritalstatus as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where mstatus_row = 1 and Maritalstatus is not null
      |
      |union all
      |
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'ETHNICITY' as patientdetailtype, ethnicity as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where ethnicity_row = 1 and ethnicity is not null
      |
      |union all
      |
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'DECEASED' as patientdetailtype, death_ind as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where death_row = 1 and death_ind is not null
      |
      |union all
      |
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'LANGUAGE' as patientdetailtype, language as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where language_row = 1 and language is not null
      |
      |union all
      |
      |select groupid, datasrc, patientid, PATDETAIL_TIMESTAMP, 'RELIGION' as patientdetailtype, religion_cd as localvalue, client_ds_id
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where religion_row = 1 and religion_cd is not null
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.cdr.fe.utils.Functions.mpvList

object PROV_DOCTORFACILITY extends FETableInfo[zh_provider] {

  override def name: String = "PROV_DOCTORFACILITY"

    override def dependsOn: Set[String] = Set("CENTRICV2_ZH_DOCTORFACILITY","CENTRICV2_REGISTRATION","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }
    val whereclausempv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "INCLUSION", "PROVIDER", "PROVIDER", "PROVIDER").mkString(",")

    val constNoMpvMatches = "'NO_MPV_MATCHES'"
    val whereclausevalue = if (whereclausempv == constNoMpvMatches) "where 1=2" else "where 1=1"

    val sqlQuery =
      """ Select GROUPID, CLIENT_DS_ID, DATASRC, LOCALPROVIDERID, CREDENTIALS, EMAILADDRESS, FIRST_NAME, MIDDLE_NAME, LAST_NAME, NPI
        | from
        | (
        |select distinct
        |    '{groupid}' as groupid,
        |    '{client_ds_id}' as client_ds_id,
        |    'zh_doctorfacility' as datasrc,
        |    df.doctorfacilityid as localproviderid,
        |    df.suffix as credentials,
        |    df.emailaddress as emailaddress,
        |    df.FirstName as first_name,
        |    df.LastName as last_name,
        |    df.MiddleName as middle_name,
        |    df.NPI as npi
        | from CENTRICV2_ZH_DOCTORFACILITY df
        |join CENTRICV2_REGISTRATION reg
        |on df.doctorfacilityid=reg.pcpid
        |{where_clause}
        |)
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{where_clause}", whereclausevalue)

    sparkSession.sql(sqlQuery)
  }

}
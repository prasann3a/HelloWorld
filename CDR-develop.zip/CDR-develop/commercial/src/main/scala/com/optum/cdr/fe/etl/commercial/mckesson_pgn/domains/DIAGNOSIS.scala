package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{diagnosis, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object DIAGNOSIS extends FETableInfo[diagnosis]{

  override def name: String = CDRFEParquetNames.diagnosis

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT", "MCKESSON_PGN_V1_ZH_TSM910_ICD9_REF", "MCKESSON_PGN_V1_TPM318_VISIT_DIAGNOSIS", "MCKESSON_PGN_V1_TPP310_PBM_LST", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val cdsidPrefix = runtimeVar.clientDsId + "."
    val hostFlag = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "DX_HOSPITALFLAG","DIAGNOSIS","VISIT_DIAGNOSIS","VISIT_DIAGNOSIS").mkString(",")
    val exclPlmStatus = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "DIAGNOSIS_EXC","DIAGNOSIS","PBM_LIST","PBM_STA_CD").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH uni_visit AS (
        |SELECT  *
        |FROM
        |(
        |	SELECT  v.*
        |	       ,ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
        |	FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        |)
        |WHERE rn = 1
        |AND row_sta_cd <> 'D'
        |AND Psn_Int_Id IS NOT NULL ),
        |
        |uni_ref_1 AS (
        |SELECT  *
        |FROM
        |(
        |	SELECT  r.*
        |	       ,ROW_NUMBER() OVER (PARTITION BY icd9_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,fileid DESC nulls first) rn
        |	FROM MCKESSON_PGN_V1_ZH_TSM910_ICD9_REF r
        |)
        |WHERE rn = 1
        |AND row_sta_cd <> 'D'
        |AND icd9_code_ty = 'D'),
        |
        |uni_ref_2 AS (
        |SELECT  *
        |FROM
        |(
        |	SELECT  r.*
        |	       ,ROW_NUMBER() OVER (PARTITION BY icd9_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,fileid DESC nulls first) rn
        |	FROM MCKESSON_PGN_V1_ZH_TSM910_ICD9_REF r
        |)
        |WHERE rn = 1
        |AND row_sta_cd <> 'D'
        |AND icd9_code_ty = 'D')
        |
        |SELECT datasrc
        |       ,patientid
        |       ,encounterid
        |       ,dx_timestamp
        |       ,localdiagnosis
        |       ,primarydiagnosis
        |       ,mappeddiagnosis
        |       ,codetype
        |       ,facilityid
        |       ,hosp_dx_flag
        |       ,localdiagnosisstatus
        |       ,localactiveind
        |       ,resolutiondate
        |       ,localadmitflg
        |       ,localdiagnosisproviderid
        |       ,localpresentonadmission
        |FROM
        |(
        |	SELECT 'visit_diagnosis'                                                                                  AS datasrc
        |	       ,COALESCE(safe_to_date_length(uni_visit.arv_date_time,'yyyy-MM-dd HH:mm:ss',19),uni_visit.adm_ts) AS dx_timestamp
        |	       ,diag.Icd9_Int_Id                                                                                   AS localdiagnosis
        |	       ,uni_visit.Psn_Int_Id                                                                               AS patientid
        |	       ,NULL                                                                                               AS localactiveind
        |	       ,CASE WHEN diag.icd9_diag_ty = 'A' THEN 'Admitting' ELSE NULL END                                   AS localadmitflg
        |	       ,diag.Car_Gvr_Int_Id                                                                                AS localdiagnosisproviderid
        |	       ,diag.Present_At_Admit_Fg                                                                           AS localpresentonadmission
        |	       ,NULL                                                                                               AS localdiagnosisstatus
        |	       ,uni_visit.Vst_Int_Id                                                                               AS encounterid
        |	       ,CASE WHEN uni_ref_1.icd_ver_cd = '0' THEN 'ICD10'
        |	             WHEN uni_ref_1.icd_ver_cd = '9' THEN 'ICD9' ELSE NULL END                                       AS codetype
        |	       ,uni_ref_1.Icd9_Code                                                                                  AS mappeddiagnosis
        |	       ,NULL                                                                                               AS facilityid
        |	       ,CASE WHEN diag.icd9_diag_ty = 'P' THEN 1 ELSE 0 END                                                AS primarydiagnosis
        |	       ,CASE WHEN 'Y' IN ({host_flag}) THEN 'Y' ELSE NULL END                                              AS hosp_dx_flag
        |	       ,NULL                                                                                               AS resolutiondate
        |	       ,ROW_NUMBER() OVER (PARTITION BY uni_visit.Psn_Int_Id,COALESCE(safe_to_date_length(uni_visit.arv_date_time,'yyyy-MM-dd HH:mm:ss',19),uni_visit.adm_ts),diag.Vst_Int_Id,diag.Icd9_Int_Id ORDER BY diag.Lst_Mod_Ts DESC NULLS LAST) AS rn
        |	FROM MCKESSON_PGN_V1_TPM318_VISIT_DIAGNOSIS diag
        |	JOIN UNI_VISIT
        |	ON uni_visit.vst_int_id = diag.vst_int_id
        |	JOIN UNI_REF_1
        |	ON (uni_ref_1.icd9_int_id = diag.icd9_int_id)
        |	WHERE diag.row_sta_cd <> 'D'
        |)
        |WHERE dx_timestamp IS NOT NULL
        |AND rn = 1
        |
        |UNION ALL
        |
        |SELECT datasrc
        |       ,patientid
        |       ,encounterid
        |       ,dx_timestamp
        |       ,localdiagnosis
        |       ,primarydiagnosis
        |       ,mappeddiagnosis
        |       ,codetype
        |       ,facilityid
        |       ,hosp_dx_flag
        |       ,localdiagnosisstatus
        |       ,localactiveind
        |       ,resolutiondate
        |       ,null as localadmitflg
        |       ,null as localdiagnosisproviderid
        |       ,localpresentonadmission
        |FROM
        |(
        |	SELECT  pv.*
        |	       ,ROW_NUMBER() OVER (PARTITION BY patientid,dx_timestamp,encounterid,localdiagnosis ORDER BY modified_dt DESC NULLS LAST) AS rn
        |	FROM
        |	(
        |		SELECT  *
        |		FROM
        |		(
        |			SELECT  unpivot_base.*
        |			       ,stack(2,Ety_Ts,'entry',Lst_Mod_Ts,'modify') AS (dx_timestamp,datetype)
        |			FROM
        |			(
        |				SELECT 'pbm_lst'                                                                      AS datasrc
        |				       ,plm.Icd_Int_Id                                                                 AS localdiagnosis
        |				       ,plm.Psn_Int_Id                                                                 AS patientid
        |				       ,NVL2(plm.Pbm_Sta_Cd,concat_ws('','{cdsid_prefix}',plm.Pbm_Sta_Cd),NULL) AS localactiveind
        |				       ,NVL2(plm.Pbm_Ty,concat_ws('','{cdsid_prefix}',plm.Pbm_Ty),NULL)         AS localdiagnosisstatus
        |				       ,CASE WHEN uni_ref_2.icd_ver_cd = '0' THEN 'ICD10'
        |				             WHEN uni_ref_2.icd_ver_cd = '9' THEN 'ICD9' ELSE NULL END                   AS codetype
        |				       ,plm.Vst_Int_Id                                                                 AS encounterid
        |				       ,NULL                                                                           AS localpresentonadmission
        |				       ,NULL                                                                           AS facilityid
        |				       ,NULL                                                                           AS primarydiagnosis
        |				       ,uni_ref_2.Icd9_Code                                                              AS mappeddiagnosis
        |				       ,NULL                                                                           AS hosp_dx_flag
        |				       ,plm.End_Dt                                                                     AS resolutiondate
        |				       ,plm.Ety_Ts                                                                     AS Ety_Ts
        |				       ,plm.Lst_Mod_Ts                                                                 AS Lst_Mod_Ts
        |				       ,plm.Lst_Mod_Ts                                                                 AS modified_dt
        |				FROM MCKESSON_PGN_V1_TPP310_PBM_LST plm
        |				JOIN UNI_REF_2
        |				ON (uni_ref_2.icd9_int_id = plm.icd_int_id)
        |				WHERE plm.Psn_Int_Id IS NOT NULL
        |				AND plm.Icd_Int_Id IS NOT NULL
        |				AND plm.row_sta_cd <> 'D'
        |				AND plm.pbm_sta_cd NOT IN ({excl_plm_status})
        |			) unpivot_base
        |		)
        |		WHERE dx_timestamp is not null
        |	) pv
        |)
        |WHERE dx_timestamp IS NOT NULL
        |AND rn = 1
      """.stripMargin
        .replace("{host_flag}", hostFlag)
        .replace("{cdsid_prefix}", cdsidPrefix)
        .replace("{excl_plm_status}", exclPlmStatus)
    )
  }
}

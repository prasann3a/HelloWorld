package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.insurance
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object INSURANCE extends FEQueryAndMetadata[insurance]{

  override def name: String = CDRFEParquetNames.insurance

  override def dependsOn: Set[String] = Set("MED3000_CHARGE_TICKET_MASTER","MED3000_CHARGE_INS_PATIENT","MED3000_ZH_INS_COMPANY","MED3000_ZH_INS_COMPANY_PLAN","MED3000_ZH_LOCATION")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, ins_timestamp, patientid, encounterid, facilityid, plantype, groupnbr, insuranceorder, payorcode, payorname, plancode, planname, policynumber
      |from
      |(
      |select a.*,
      |       row_number() over (partition by patientid,encounterid,ins_timestamp,payorcode,plantype,insuranceorder order by update_date desc nulls last) as rank_ins
      |  from (
      |select
      |       '{groupid}' 			  as groupid
      |       ,'ct_master' 		    as datasrc
      |       ,{client_ds_id} 		as client_ds_id
      |       ,mast.Charge_Date  	as ins_timestamp
      |       ,mast.Blind_Key  	  as patientid
      |       ,mast.Appt_Id  		  as encounterid
      |       ,loc.Record_No  		as facilityid
      |	      ,case when '{groupid}' = 'H542284' and mast.Fc_Acct_Type is not null then concat_ws('', {client_ds_id}, '.', mast.Fc_Acct_Type) else mast.Fc_Acct_Type end 
                                  as plantype
      |       ,ins_pat.Group_Id  	as groupnbr
      |       ,ins_pat.Priority  	as insuranceorder
      |       ,ins_pat.Ins_Code  	as payorcode
      |       ,ins_comp.Ins_Name  as payorname
      |	      ,case when ins_pat.Plan_ID is null or ins_pat.Plan_ID = '0' then ins_pat.Ins_Code else ins_pat.Plan_ID end 
                                  as plancode
      |	      ,case when ins_pat.Plan_ID is null or ins_pat.Plan_ID = '0' then ins_comp.Ins_Name else ins_plan.Plan_Name end 
                                  as  planname
      |       ,ins_pat.Policy_Nbr as policynumber
      |	      ,mast.update_date
      |  from MED3000_CHARGE_TICKET_MASTER mast
      |  inner join MED3000_CHARGE_INS_PATIENT ins_pat on (mast.ICChart_CT_ID = ins_pat.ICChart_CT_ID)
      |  inner join MED3000_ZH_INS_COMPANY ins_comp       on (ins_pat.Ins_Code   = ins_comp.Ins_Code)
      |  inner join MED3000_ZH_INS_COMPANY_PLAN ins_plan  on (ins_pat.Ins_Code   = ins_plan.Ins_Code and ins_pat.Plan_ID = ins_plan.Plan_ID)
      |  left join MED3000_ZH_LOCATION loc on (mast.Location = loc.Code))a
      |
      |
      |)
      | where rank_ins = 1 and ins_timestamp is not null and patientid is not null
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.patientcontact

object PATIENTCONTACT extends FEQueryAndMetadata[patientcontact]{
  override def name: String = CDRFEParquetNames.patientcontact

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TSM040_PERSON_HDR","MCKESSON_PGN_V1_TSM060_PHONE")

  override def sparkSql: String =
    """
      |select datasrc, update_dt, patientid, work_phone, home_phone, cell_phone, personal_email
      |from
      |(
      |SELECT 'person_hdr' 	     AS datasrc
      |      ,Lst_Mod_Ts            AS update_dt
      |      ,Psn_Int_Id            AS patientid
      |      ,NULL 		     AS cell_phone
      |      ,NULL      	     AS home_phone
      |      ,NULL 		     AS work_phone
      |      ,E_Mail_Adr            AS personal_email
      |      ,ROW_NUMBER() OVER (PARTITION BY Psn_Int_Id, E_Mail_Adr ORDER BY Lst_Mod_Ts DESC NULLS LAST) rn
      |FROM MCKESSON_PGN_V1_TSM040_PERSON_HDR
      |WHERE  Row_Sta_CD <> 'D'
      |AND Psn_Int_Id IS NOT NULL
      |AND Lst_Mod_Ts IS NOT NULL
      |AND E_Mail_Adr like '%@%.%'
      |
      |)
      |where rn = 1
      |
      |union all
      |
      |select datasrc, update_dt, patientid, work_phone, home_phone, cell_phone, personal_email
      |from
      |(
      |SELECT inr.*, ROW_NUMBER() OVER (PARTITION BY patientid ORDER BY update_dt DESC NULLS LAST) rn
      |FROM (
      |SELECT 'phone' 	     	     AS datasrc
      |      ,Lst_Mod_Ts            AS update_dt
      |      ,Phn_Int_Id            AS patientid
      |      ,NULL 		     AS cell_phone
      |      ,NVL2(phn_ara_cd, nullif(concat_ws('', phn_ara_cd, phn_exc_no, phn_lcl_no), ''), NULL)  AS home_phone
      |      ,NULL 		     AS work_phone
      |      ,NULL                  AS personal_email
      |      ,phn_fmt_cd
      |FROM MCKESSON_PGN_V1_TSM060_PHONE
      |WHERE  Row_Sta_CD <> 'D'
      |AND Phn_Int_Id IS NOT NULL
      |AND Lst_Mod_Ts IS NOT NULL
      |AND NVL2(phn_ara_cd, nullif(concat_ws('', phn_ara_cd, phn_exc_no, phn_lcl_no), ''), NULL) IS NOT NULL ) inr
      |WHERE phn_fmt_cd = 'USA'
      |)
      |where rn = 1
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object CLAIM_ORDERS extends FEQueryAndMetadata[claim] {

  override def name: String = "CLAIM_ORDERS"

  override def dependsOn: Set[String] = Set("CLAIM_PROC_ORDER_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, claimid, patientid, encounterid, servicedate, localcpt, claim_cptcode as mappedcpt, localbillingproviderid as claimproviderid, localbillingproviderid
      |from
      |(
      |CLAIM_PROC_ORDER_CACHE
      |)
      |where patientid is not null and claim_cptcode is not null and  servicedate is not null and claim_rn=1
    """.stripMargin


}
package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.cdr.fe.utils.verify.MedicationMapSrcVerify
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC extends FETableInfo[medication_map_src]{

  override def name: String = CDRFEParquetNames.medication_map_src

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","CENTRICV2_PATIENTMEDICATION", "CENTRICV2_ZH_MEDINFO", "CENTRICV2_DOCUMENTS", "CENTRICV2_PRESCRIPTIONS", "CENTRICV2_PATIENTALLERGY", "CENTRICV2_IMMUNIZATION")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val doc_xid = mpvList(mapPredicateValues, groupId, clientDsId, "DOC_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")

    val doc_xid_inclusion = if (clientDsId == "9909") "" else  "AND doc.xid = coalesce(string( "+ doc_xid +"),'100000000000000000000000000000000000')"


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val medicationMapSrcDf = sparkSession.sql(
      """

         with
         dup as
             (
            select a.*,
            row_number() over
            (
              partition by pid, coalesce (vaccineName, vaccineGroupName), administeredDate
              order by db_updated_date desc nulls first
            ) as ranking
            from CENTRICV2_IMMUNIZATION a
          ),
          dedup as (select * from DUP where ranking = 1),
          main as
          (
            select
            '{groupid}' as groupid
            ,'immunization' as datasrc
            ,{client_ds_id} as client_ds_id
            ,mmn.pid as patientID
            ,case
             when (mmn.administeredDate < to_date('01-JAN-1900') or mmn.administeredDate > current_date)
               then null
             when mmn.wasGiven in ('Y', 'U') then mmn.administeredDate
             end as adminDate
            ,mmn.db_create_date as documentedDate
            ,case
             when mmn.reasonRemoved is not null then reasonRemoved
             when mmn.reasonNotGiven is not null then reasonNotGiven
             when mmn.wasGiven = 'N' then
             nullif(regexp_extract(mmn.administeredcomments,
               '(pt\\s*|patient\\s*)*\\.*(refuse|refuse|decline|contraindicate|disease|defer)(s|d)*', 0), '')
             end as localDeferredReason
            ,mmn.sdid as encounterID
            ,coalesce (mmn.vaccineName, mmn.vaccineGroupName) as localImmunizationCD
            ,coalesce (mmn.vaccineName, mmn.vaccineGroupName) as localImmunizationDesc
            ,mmn.NDC as localNDC
            ,mmn.GPI as localGPI
            ,mmn.route as localRoute
            from DEDUP mmn
            where
            nvl(mmn.reasonRemoved, 'x') not in ('Entered In Error','Migration Error') and
            nvl(mmn.filedInError, 'N') <> 'Y' and
            coalesce (mmn.vaccineName, mmn.vaccineGroupName) is not null and
            mmn.pid is not null
          )

          select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, localgeneric, localgpi, localform, localstrength, no_ndc, has_ndc, num_recs, cast(null as String) as ndc_src

          from
          (
          select groupid, datasrc, client_ds_id, localImmunizationCD localMedCode, localImmunizationDesc localDescription,
          localNDC, sum(nvl2(localndc,0,1)) as no_ndc, sum(nvl2(localndc,1,0)) as has_ndc, count(*) num_recs, null as localgeneric, null as localgpi, null as localform, null as localstrength
          from MAIN
          group by groupid, datasrc, client_ds_id, localImmunizationCD, localImmunizationDesc,
          localNDC)

          union all

         select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, localgeneric, localgpi, localform, localstrength, no_ndc, has_ndc, num_recs, cast(null as String) as ndc_src
          from
          (
          SELECT groupid
              ,datasrc
              ,client_ds_id
              ,nullif(SUBSTR(localmedcode,1,100), '')  AS localmedcode
              ,localndc
              ,localdescription
              ,localgeneric
              ,localgpi
              ,localform
              ,localstrength
              ,sum(nvl2(localndc,0,1)) as no_ndc
              ,sum(nvl2(localndc,1,0)) as has_ndc
              ,count(*) as num_recs
          FROM
          (
          SELECT
          '{groupid}'                                     as groupid
          ,'prescriptions'                             as datasrc
          ,{client_ds_id}                               as client_ds_id
          ,pm.Description                              AS localdescription
          ,mi.Doseform                                 AS localform
          ,coalesce( pm.Gpi,mi.Gpi)                    AS localgpi
          ,mi.Genericname                              AS localgeneric
          ,case when pm.DDID = 0 then pm.description else string(pm.DDID) end AS localmedcode
          ,nvl(nullif(concat_ws('', pm.Ndclabprod, pm.Ndcpackage), ''),mi.Ndcnum)  AS localndc
          ,mi.Route                                    AS localroute
          ,concat_ws('', mi.Strengthonly, ' ', mi.Unitsonly)        AS localstrength
              FROM CENTRICV2_PATIENTMEDICATION pm
                    LEFT OUTER JOIN CENTRICV2_ZH_MEDINFO mi ON (pm.ddid = mi.ddid)
                    INNER JOIN CENTRICV2_DOCUMENTS doc ON (doc.sdid = pm.sdid and doc.pid = pm.pid)
                    INNER JOIN CENTRICV2_PRESCRIPTIONS pres ON (pm.MID = pres.MID and pm.pid = pres.pid)
                     WHERE (pm.Change IS NULL or pm.Change IN ('0','1','2'))
                     {doc_xid_inclusion}
                     and nvl(stopreason,'X') <> 'E'
                     AND doc.finalsign = 1
                     AND doc.status = 'S'
          )
          GROUP BY groupid
              ,datasrc
              ,client_ds_id
              ,nullif(SUBSTR(localmedcode,1,100), '')
              ,localndc
              ,localdescription
              ,localgeneric
              ,localgpi
              ,localform
              ,localstrength
          )

          union all

          select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, localgeneric, localgpi, localform, localstrength, no_ndc, has_ndc, num_recs, cast(null as String) as ndc_src
          from
          (
          SELECT groupid
              ,datasrc
              ,client_ds_id
              ,nullif(SUBSTR(localmedcode,1,100), '')  AS localmedcode
              ,localndc
              ,drugdescription as localdescription
              ,null as localgeneric
              ,localgpi
              ,localform
              ,localstrength
              ,sum(nvl2(localndc,0,1)) as no_ndc
              ,sum(nvl2(localndc,1,0)) as has_ndc
              ,count(*) as num_recs
          FROM
          (
          select pat_rx.*
               , row_number() over
                 (partition by  nullif(concat_ws('', encounterid, reportedmedid, patientid, localmedcode, upper(date_format(discontinuedate, 'dd-MMM-yy'))), '')
                  order by medreportedtime desc nulls last) as drug_row
           from
           (SELECT '{groupid}'                                    as groupid
          ,'pat_med'                                         as datasrc
          ,{client_ds_id}                                     as client_ds_id
          ,pm.Pid                                            AS patientid
          ,nvl2(pm.Stopreason,'1','2')                       AS categorycode
          ,safe_to_date(nullif( date_format(stopdate,'yyyyMMdd'),'47001231'),'yyyyMMdd')  AS discontinuedate
          ,pm.Stopreason                                     AS discontinuereason
          ,pm.Description                                    AS drugdescription
          ,pm.Sdid                                           AS encounterid
          ,mi.Doseform                                       AS localform
          ,coalesce( pm.Gpi,mi.Gpi)                          AS localgpi
          ,case when pm.Ddid = 0 then pm.Description else string(pm.Ddid) end AS localmedcode
          ,nvl(nullif(concat_ws('', pm.Ndclabprod, pm.Ndcpackage), ''),mi.Ndcnum)       AS localndc
          ,mi.Route                                          AS localroute
          ,concat_ws('', mi.Strengthonly, ' ', mi.Unitsonly)              AS localstrength
          ,pm.Startdate                                      AS medreportedtime
          ,pm.Mid                                            AS reportedmedid
                 FROM CENTRICV2_PATIENTMEDICATION pm
                     LEFT OUTER JOIN CENTRICV2_ZH_MEDINFO mi ON (pm.ddid = mi.ddid)
                    INNER JOIN CENTRICV2_DOCUMENTS doc ON (doc.sdid = pm.sdid and doc.pid = pm.pid)
                    left outer JOIN CENTRICV2_PRESCRIPTIONS pres ON (pm.MID = pres.MID and pm.pid = pres.pid)
                     WHERE pres.MID is null
                     {doc_xid_inclusion}
                     AND (pm.Change IS NULL or pm.Change IN ('0','1','2'))
                     and nvl(stopreason,'X') <> 'E'
                     AND doc.finalsign = 1
                     AND doc.status = 'S'  )pat_rx
          )
          WHERE
           patientid is not null
           and medreportedtime is not null
           and drug_row = 1
          GROUP BY groupid
              ,datasrc
              ,client_ds_id
              ,nullif(SUBSTR(localmedcode,1,100), '')
              ,localndc
              ,drugdescription
              ,localgpi
              ,localform
              ,localstrength
          )

          union all

          select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, localgeneric, localgpi, localform, localstrength,num_recs as no_ndc, 0 as has_ndc, num_recs, cast(null as String) as ndc_src
          from
          (
          SELECT groupid,datasrc,client_ds_id
              ,nullif(SUBSTR(localallergencd,1,100), '')  AS localmedcode
              ,localallergendesc as localdescription
              ,localndc
              ,localgpi
              ,count(*) as num_recs
              ,null as localgeneric
              ,null as localform
              ,null as localstrength
          FROM
          (
          select
              '{groupid}'                            as groupid
              ,'patientallergy'                   as datasrc
              ,'{client_ds_id}'                    as client_ds_id
              ,pa.name                            as localallergencd
              ,pa.name                            as localallergendesc
              ,nullif(concat_ws('', pa.Ndclabprod, pa.Ndcpackage), '')       AS localndc
              ,pa.Gpi                             AS localgpi
            FROM CENTRICV2_PATIENTALLERGY pa
            INNER JOIN CENTRICV2_DOCUMENTS  doc ON (pa.pid = doc.pid and pa.sdid = doc.sdid)
                    WHERE (pa.Change IS NULL or pa.Change IN ('0','1','2'))
                    {doc_xid_inclusion}
                    AND (pa.stopreason is null or pa.stopreason in ('A', 'C','O','D','P'))
                    AND doc.finalsign = 1
                    AND doc.status = 'S'
          )
          group by groupid,datasrc,client_ds_id
              ,localallergencd
              ,localallergendesc
              ,localndc
              ,localgpi
          )


            """.replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId)
        .replace("{doc_xid_inclusion}", doc_xid_inclusion))

    MedicationMapSrcVerify.run(medicationMapSrcDf)

  }
}


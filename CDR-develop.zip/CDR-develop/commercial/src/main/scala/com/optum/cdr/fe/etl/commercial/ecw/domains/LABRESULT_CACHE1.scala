package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.ecw_labresult_cache
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.map_predicate_values
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE1 extends FETableInfo[ecw_labresult_cache]{

  override def name: String = "LABRESULT_CACHE1"

  override def dependsOn: Set[String] = Set("LABDATA", "ZH_LABLIST", "LABDATADETAIL", "ZH_ITEMS", "ZH_LABDATADETAILREFRANGE", "MAP_PREDICATE_VALUES", CDRFEParquetNames.clinicalencounter)

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val itemidMpvList = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LABDATADETAIL", "LAB_RESULTS",
      "ZH_ITEMS", "ITEMID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => if(!depName.equals("MAP_PREDICATE_VALUES")) df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH dedup_labdata AS (
        |        SELECT  *
        |        FROM
        |        (
        |                SELECT  d.*
        |                ,z.name lis_src
        |                ,ROW_NUMBER() OVER (PARTITION BY nullif(concat_ws('',d.ReportID,d.ItemID,d.encounterid),'') ORDER BY received DESC NULLS LAST,modifieddate DESC NULLS LAST) rn
        |                FROM LABDATA d
        |                LEFT OUTER JOIN ZH_LABLIST z ON (d.fromlabid = z.id)
        |                WHERE (d.DeleteFlag <> '1' AND d.Cancelled <> '1')
        |        )
        |        WHERE rn = 1
        |),
        |dedup_dtl AS (
        |        SELECT  *
        |        FROM
        |        (
        |                SELECT  l.*
        |                ,ROW_NUMBER() OVER (PARTITION BY nullif(concat_ws('',l.ReportID,l.PROPID,l.id),'') ORDER BY UpdatedTime DESC NULLS LAST) rn
        |                FROM LABDATADETAIL l
        |        )
        |        WHERE rn = 1
        |),
        |zhitems AS (
        |        SELECT  *
        |        FROM ZH_ITEMS
        |        WHERE XMLPATH like '/Lab%' or XMLPATH like '/Vitals%' or (ItemID IN ({itemidMpvList}))
        |),
        |zhlabdatadetailrefrange AS (
        |        SELECT  *
        |        FROM
        |        (
        |                SELECT  zh.*
        |                ,ROW_NUMBER() OVER (PARTITION BY zh.itemid ORDER BY zh.updatedtime desc nulls last) rn
        |                FROM ZH_LABDATADETAILREFRANGE zh
        |        )
        |        WHERE rn=1
        |)
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,labresultid
        |       ,localcode
        |       ,localresult
        |       ,localresult_numeric
        |       ,patientid
        |       ,datecollected
        |       ,encounterid
        |       ,laborderid
        |       ,localname
        |       ,localtestname
        |       ,labresult_date
        |       ,normalrange
        |       ,labordereddate
        |       ,dateavailable
        |       ,locallisresource
        |       ,localunits
        |       ,row1
        |from
        |(
        |   select sub.*
        |          ,row_number() over (partition by sub.labresultid,sub.patientid,sub.localcode,sub.localresult ORDER BY sub.DateCollected DESC NULLS LAST) row1
        |   FROM
        |   (
        |   	SELECT  '{groupid}'                                                   AS groupid
        |   	       ,'labdatatdetail'                                              AS datasrc
        |   	       ,{client_ds_id}                                                AS client_ds_id
        |   	       ,CASE WHEN dedup_dtl.ReportID IS NOT NULL AND dedup_dtl.PropID IS NOT NULL AND dedup_dtl.ID IS NOT NULL
        |                   THEN concat_ws('',dedup_dtl.ReportID,'_',dedup_dtl.PropID,'_',dedup_dtl.ID)
        |                  WHEN labdata.ReportID IS NOT NULL AND labdata.ItemID IS NOT NULL
        |                   THEN concat_ws('',labdata.ReportID,'_',labdata.ItemID) END AS labresultid
        |   	       ,COALESCE(dedup_dtl.Propid,labdata.itemid)                     AS localcode
        |   	       ,coalesce(dedup_dtl.Hum_Value ,Labdata.Result)                 AS localresult
        |   	       ,safe_to_number(coalesce(dedup_dtl.Hum_Value ,Labdata.Result)) AS localresult_numeric
        |   	       ,Enc.Patientid                                                 AS patientid
        |   	       ,CASE WHEN date_format(labdata.colldate,'yyyyMMdd') IN ('19010101','19000101')
        |                   THEN null
        |                  ELSE safe_to_date_length(
        |                                            concat_ws('',date_format(Labdata.colldate,'yyyy-MM-dd'),nvl(Labdata.colltime,'00:00:00'))
        |                                            ,'yyyy-MM-ddHH:mm:ss'
        |                                            ,0
        |                        )
        |                  END                                                      AS datecollected
        |   	       ,Enc.arrivaltime                                               AS labordereddate
        |   	       ,CASE WHEN Labdata.resultdate IS NOT NULL
        |                   THEN safe_to_date_length(
        |                                             concat_ws('',date_format(Labdata.resultdate,'yyyy-MM-dd'),nvl(Labdata.resultime,'00:00:00'))
        |                                             ,'yyyy-MM-ddHH:mm:ss'
        |                                             ,0
        |                        )
        |                  ELSE labdata.modifieddate
        |                  END                                                      AS dateavailable
        |   	       ,Labdata.Encounterid                                           AS encounterid
        |   	       ,coalesce(dedup_dtl.Reportid,labdata.Reportid)                 AS laborderid
        |   	       ,Labdata.lis_src                                               AS locallisresource
        |   	       ,dtl_Items.Itemname                                            AS localname
        |   	       ,data_Items.Itemname                                           AS localtestname
        |   	       ,NULL                                                          AS localunits
        |   	       ,CASE WHEN Labdata.resultdate IS NOT NULL
        |                   THEN safe_to_date_length(
        |                                           concat_ws('',date_format(Labdata.resultdate,'yyyy-MM-dd'),nvl(Labdata.resultime,'00:00:00'))
        |                                           ,'yyyy-MM-ddHH:mm:ss'
        |                                           ,0
        |                        )
        |                  ELSE labdata.modifieddate
        |                  END                                                      AS labresult_date
        |   	       ,zhlabdatadetailrefrange.range                                 AS normalrange
        |   	FROM DEDUP_LABDATA labdata
        |   	JOIN {CLINICALENCOUNTER} enc ON (labdata.encounterid = enc.encounterid)
        |   	LEFT OUTER JOIN DEDUP_DTL ON (dedup_dtl.reportid = labdata.reportid)
        |   	LEFT OUTER JOIN ZHITEMS data_items ON (labdata.itemid = data_Items.itemid)
        |   	LEFT OUTER JOIN ZHITEMS dtl_items ON (dedup_dtl.propid = dtl_Items.itemid)
        |   	LEFT OUTER JOIN ZHLABDATADETAILREFRANGE ON (zhlabdatadetailrefrange.Itemid = labdata.Itemid)
        |   	WHERE enc.client_ds_id = {client_ds_id}
        |   )sub
        |)
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{itemidMpvList}", itemidMpvList)
    )
  }


}

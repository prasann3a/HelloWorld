package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.proceduredo
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_TEMP_ENT_PATIENT extends FETableInfo[proceduredo]{
  override def name: String = "PROCEDURE_TEMP_ENT_PATIENT"

  override def dependsOn: Set[String] = Set("MCKESSON_ENT_PATIENT","CCDBA_TB_PATIENT","MAP_CUSTOM_PROC")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |WITH uni_pat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |   WHERE cpi_seq IS NOT NULL
         |     AND pat_Seq IS NOT NULL )
         |) WHERE rn = 1)
         |select datasrc, localcode, encounterid, patientid, proceduredate, localname, codetype, mappedcode, proceduredate as actualprocdate, facilityid, hosp_px_flag
         |from
         |(
         |SELECT 'Ccdba_Tb_Patient' AS datasrc
         |	,concat_ws('', '{client_ds_id}', '.', tb.Disposition) AS localcode
         |	,uni_pat.cpi_seq  AS patientid
         |	,tb.Disposition_Ddt  AS proceduredate
         |	,uni_pat.pat_seq  AS encounterid
         |	,NULL		  AS facilityid
         |	,NULL		  AS localname
         |	,Map.Mappedvalue  AS mappedcode
         |	,'CUSTOM'  	  AS codetype
         |	,NULL             AS hosp_px_flag
         |	,ROW_NUMBER() OVER (PARTITION BY uni_pat.cpi_seq, uni_pat.pat_seq, tb.Disposition_Ddt, tb.Disposition
         |	 ORDER BY tb.arrival_ddt DESC NULLS LAST) rn
         |FROM CCDBA_TB_PATIENT tb
         |   JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
         |                            map.datasrc = 'ccdba_tb_patient' AND
         |   			    map.localcode = concat_ws('', '{client_ds_id}', '.', tb.Disposition))
         |   JOIN UNI_PAT ON (uni_pat.pat_seq = tb.pat_seq)
         |
 |)
         |where rn = 1 AND proceduredate IS NOT NULL
       """.stripMargin.replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId))
  }
}

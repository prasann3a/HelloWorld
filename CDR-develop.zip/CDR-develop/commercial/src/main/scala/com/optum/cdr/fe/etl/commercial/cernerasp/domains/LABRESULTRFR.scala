package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.med3000.domains.lab_result
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object LABRESULTRFR extends FETableInfo[labresquery]{

  override def name:String="LABRFR"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select element_code, display from (
         |	            select element_code, display,
         |	            row_number() over (PARTITION BY FILE_NAME, FIELD, ELEMENT_CODE ORDER BY FILEID DESC nulls first) as rw
         |	            from REFERENCECODE
         |            )
         |            where rw=1

       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)

    )
  }

  override def dependsOn: Set[String] = Set("REFERENCECODE")


}
package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROCEDURE_CACHE_7 extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_7"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPP380_PAT_EDUCATION","MAP_CUSTOM_PROC","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val staRsnLst = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "PROC_EXC","PROCEDUREDO","PAT_EDUCATION","STA_RSN_CD").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
        |from
        |(
        |SELECT '{groupid}'         	 AS groupid
        |      ,'pat_education'           AS datasrc
        |      ,{client_ds_id}             AS client_ds_id
        |      ,ed.Pat_Edu_Doc_Nm         AS localcode
        |      ,ed.Psn_Int_Id   		 AS patientid
        |      ,ed.ety_Ts                 AS proceduredate
        |      ,ed.Vst_Int_Id 	 	 AS encounterid
        |      ,NULL                      AS orderingproviderid
        |      ,ed.Pat_Edu_Doc_Nm         AS localname
        |      ,NULL              	 AS procseq
        |      ,NULL                      AS proc_end_date
        |      ,NULL 			 AS hosp_px_flag
        |      ,'CUSTOM'  		 AS codetype
        |      ,NULL                      AS localprincipleindicator
        |      ,map.mappedvalue           AS mappedcode
        |      ,NULL        		 AS performingproviderid
        |      ,NULL                      AS actualprocdate
        |      ,ROW_NUMBER() OVER (PARTITION BY ed.Psn_Int_Id, ed.Vst_Int_Id,ed.ety_Ts,ed.Pat_Edu_Doc_Nm
        |                               ORDER BY ed.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM MCKESSON_PGN_V1_TPP380_PAT_EDUCATION ed
        |   JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
        |                               map.datasrc = 'pat_education' AND
        |   			       map.localcode = ed.Pat_Edu_Doc_Nm)
        |WHERE ed.Psn_Int_Id IS NOT NULL
        |  AND ed.ety_Ts IS NOT NULL
        |  AND ed.row_sta_cd <> 'D'
        |  AND ed.OBS_TS IS NULL
        |  AND (ed.sta_rsn_cd NOT IN ({sta_rsn_lst}) OR ed.sta_rsn_cd IS NULL)
        |)
        |where proceduredate IS NOT NULL AND patientid IS NOT NULL
      """.stripMargin
        .replace("{sta_rsn_lst}",staRsnLst)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }
}

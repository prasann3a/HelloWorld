package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.mborder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object MBORDERS extends FEQueryAndMetadata[mborder]{

  override def name: String = CDRFEParquetNames.mborder

  override def dependsOn: Set[String] = Set("LABDATA", "ENC", "ZH_ITEMS","MAP_PREDICATE_VALUES")

  override def sparkSql: String =
    """
      |WITH DEDUPED_MICRO_ORDERS AS
      |           (
      |            SELECT  ENCOUNTERID, REPORTID, ITEMID, COLLDATE, COLLTIME, RESULTDATE, RESULTIME, COLLSOURCE, COLLDESCRIPTION, RESULTSTATUS, MODIFIEDDATE
      |            FROM   (
      |                    SELECT  A.*, ROW_NUMBER() OVER (PARTITION BY REPORTID, ITEMID, ENCOUNTERID ORDER BY to_date(MODIFIEDDATE, 'yyyy-MM-dd HH:mm:ss') DESC nulls first, FILEID DESC nulls first) AS RN
      |                    FROM LABDATA A
      |                    )
      |            WHERE RN = '1'
      |                  AND (DELETEFLAG <> '1'  or DELETEFLAG is null)
      |                  AND (CANCELLED <> '1' or CANCELLED is null)
      |                  AND RECEIVED = '1'
      |            )
      |,DEDUPED_ENCOUNTER AS
      |        (
      |        SELECT  ENCOUNTERID, FACILITYID, PATIENTID
      |        FROM    (
      |                SELECT ENCOUNTERID, FACILITYID, PATIENTID, ROW_NUMBER() OVER (PARTITION BY ENCOUNTERID ORDER BY to_date(MODIFIEDDATE,'yyyy-MM-dd HH:mm:ss') DESC nulls first, FILEID DESC nulls first) AS RN
      |                FROM ENC A
      |                )
      |        WHERE RN = '1'
      |        )
      |,DEDUPED_DICT AS
      |        (
      |        SELECT  ITEMID, ITEMNAME
      |        FROM    (
      |                SELECT ITEMID, ITEMNAME, ROW_NUMBER() OVER (PARTITION BY ITEMID ORDER BY to_date(MODIFIEDDATE, 'yyyy-MM-dd HH:mm:ss') DESC nulls first, FILEID DESC nulls first) AS RN
      |                FROM ZH_ITEMS
      |                WHERE UPPER(ITEMNAME) IN (select column_value
      |                                     from MAP_PREDICATE_VALUES
      |                                     where groupid = '{groupid}'
      |                                           and client_ds_id = {client_ds_id}
      |                                           and entity = 'MBORDER'
      |                                           and data_src = 'ZH_ITEMS'
      |                                           and table_name = 'ZH_ITEMS'
      |                                           and column_name = 'ITEMNAME_CULT' )
      |                )
      |        WHERE RN = '1'
      |        )
      |
      |select groupid, datasrc, client_ds_id, localordercode, mbprocorderid, patientid, facilityid, localorderdesc, localorderstatus, localspecimenname, localspecimensource, datecollected, encounterid, mborder_date
      |from
      |(
      |SELECT A.*, DATECOLLECTED AS MBORDER_DATE
      |FROM   (
      |        SELECT
      |                '{groupid}'                                AS GROUPID,
      |                'labdata'                               AS DATASRC,
      |                {client_ds_id}                           AS CLIENT_DS_ID,
      |                DE.PATIENTID                            AS PATIENTID,
      |                DE.ENCOUNTERID                          AS ENCOUNTERID,
      |                DE.FACILITYID                           AS FACILITYID,
      |                MO.REPORTID                             AS MBPROCORDERID,
      |                MO.ITEMID                               AS LOCALORDERCODE,
      |                UPPER(ZH.ITEMNAME)                      AS LOCALORDERDESC,
      |                MO.COLLSOURCE                           AS LOCALSPECIMENSOURCE,
      |                Coalesce (UPPER(MO.COLLDESCRIPTION), UPPER(MO.COLLSOURCE) ) AS LOCALSPECIMENNAME,
      |                CASE WHEN date_format(MO.colldate, 'yyyyMMdd') in ('19010101', '19000101') THEN null
      |                             ELSE safe_to_date(nullif(concat_ws('', date_format(MO.colldate, 'yyyy-MM-dd'), MO.colltime), ''), 'yyyy-MM-ddHH:mm:ss') end AS DATECOLLECTED,
      |                MO.RESULTSTATUS                                       AS LOCALORDERSTATUS
      |        FROM DEDUPED_MICRO_ORDERS MO
      |        INNER JOIN DEDUPED_ENCOUNTER DE ON (MO.ENCOUNTERID = DE.ENCOUNTERID)
      |        INNER JOIN DEDUPED_DICT ZH ON (MO.ITEMID = ZH.ITEMID)
      |        ) A
      |WHERE DATECOLLECTED IS NOT NULL
      |AND LOCALORDERDESC IS NOT NULL
      |AND PATIENTID IS NOT NULL
      |)
    """.stripMargin
}

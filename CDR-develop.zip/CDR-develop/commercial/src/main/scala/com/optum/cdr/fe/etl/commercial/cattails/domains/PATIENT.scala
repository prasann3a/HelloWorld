package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT extends FEQueryAndMetadata[patient]{

  override def name: String = CDRFEParquetNames.patient

  override def dependsOn: Set[String] = Set("PATIENT_CACHE")

  override def sparkSql: String =

  """
    |select groupid, datasrc, client_ds_id, patientid, dateofbirth, alternativepatientid as medicalrecordnumber, dateofbirth, dateofdeath, inactiveflag as inactive_flag
    |from
    |(
    |PATIENT_CACHE
    |)
  """
  .stripMargin

}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.claim_proc_result_cache
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object CLAIM_PROC_RESULT_CACHE extends FETableInfo[claim_proc_result_cache] {

  override def name: String = "CLAIM_PROC_RESULT_CACHE"

  override def dependsOn: Set[String] = Set("CENTRICV2_OBSERVATIONS", "CENTRICV2_ZH_OBSHEAD", "CENTRICV2_DOCUMENTS", "MAP_CUSTOM_PROC", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOC_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")
    val obsXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "OBS_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")
    val serviceDateMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "PROCEDUREDATE", "PROCEDUREDO", "OBSERVATION", "HDID").mkString(",")
    val cdsidincl = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CDSID", "PROCEDURE", "PROCEDURE", "PROCEDURE").mkString(",")

    val constNoMpvMatches = "'NO_MPV_MATCHES'"
    val nullString = "''null''"
    val docXidInclusion = if (docXidInclusionMpv == constNoMpvMatches) "" else " and d.xid in ( " + docXidInclusionMpv.replace("'", "") + " ) "
    val obsXidInclusion = if (obsXidInclusionMpv == constNoMpvMatches) "" else " and o.xid in ( " + obsXidInclusionMpv.replace("'", "") + " ) "
    val serviceDateValue = if (serviceDateMpv == constNoMpvMatches || serviceDateMpv == nullString) "null" else serviceDateMpv
    val cdsidvalue = if (cdsidincl == constNoMpvMatches) "o.hdid = safe_to_number( mcp.localcode)" else "safe_to_number(concat("+clientDsId+",'.',o.hdid)) = safe_to_number(mcp.localcode)"

    sparkSession.sql(
      """
        |with customs as ( select   * from MAP_CUSTOM_PROC where groupid =  '{groupid}' and datasrc = 'results'  )
        |
        |,dedup_doc AS
        |(SELECT * FROM
        |        (SELECT b.*, ROW_NUMBER() OVER (PARTITION BY b.sdid
        |         ORDER BY b.db_updated_date  DESC NULLS LAST) rn
        |         FROM CENTRICV2_DOCUMENTS b)
        | WHERE rn = 1)
        |,dedup_obs AS
        |(
        |select  * from
        |        (select o.*, row_number() over (partition by o.pid, o.sdid, o.obsdate, o.hdid
        |         order by o.db_updated_date desc nulls last, o.fileid desc nulls last) as rnum
        |         from CENTRICV2_OBSERVATIONS o)
        | where rnum = 1)
        |Select a.*,row_number() over (partition by a.patientid, a.claimid, a.encounterid, a.servicedate, a.localcpt
        |                              order by db_updated_date desc nulls last) as claim_rn
        |         ,row_number() over (partition by a.patientid, a.encounterid, a.servicedate, a.localcode, a.stdcodetype
        |                              order by db_updated_date desc nulls last) as proc_rownumber from
        |(select distinct '{groupid}'            as groupid
        |,'results'                              as datasrc
        |,{client_ds_id}                          as client_ds_id
        |,o.Sdid                                 AS claimid
        |,o.Sdid                                 AS encounterid
        |,o.Pid                                  AS patientid
        |,case when o.hdid in ({servicedate_mp})
        | then safe_to_date(obsvalue,'MM/dd/yyyy') else obsdate end                               AS servicedate
        |,nullif(o.usrid,-3)                     AS claimproviderid
        |,case when zh.cptcode is not null
        |         then nullif(substr(zh.cptcode,1,5), '')
        |     when (zh.cptcode is null and rlike(zh.mlcode, '(?i)CPT.*(\\d|[a-z]){1}\\d{3}(\\d|[a-z]){1}'))
        |        then nullif(regexp_extract(zh.mlcode,'[a-zA-Z0-9]{5}', 0), '')
        |      else null end                       as cptcode
        |,coalesce(zh.Cptcode,zh.Mlcode)         AS localcpt
        |,o.Hdid                                as localcode
        |,o.Description                         AS localname
        |,case when mcp.mappedvalue  is not null  then  mcp.mappedvalue
        |          when rlike(coalesce(zh.Cptcode,zh.Mlcode) , '(?i)(^|CPT.*|J[^I].*|#.*)(\\d|[a-z]){1}\\d{3}(\\d|[a-z]){1}')
        |            then nullif(regexp_extract(coalesce(zh.Cptcode,zh.Mlcode), '[a-zA-Z0-9]{5}', 0), '')
        |       else null end                        AS standardcode
        |, CASE   when {cdsidin} then 'CUSTOM'
        |         WHEN rlike(nullif(regexp_extract(coalesce(zh.Cptcode,zh.Mlcode),'[a-zA-Z0-9]{5}', 0), ''),'^[0-9]{4}[0-9A-Z]$')  THEN 'CPT4'
        |         WHEN rlike(nullif(regexp_extract(coalesce(zh.Cptcode,zh.Mlcode),'[a-zA-Z0-9]{5}', 0), ''),'^[A-Z]{1,1}[0-9]{4}$')  THEN 'HCPCS'
        |         WHEN rlike(nullif(regexp_extract(coalesce(zh.Cptcode,zh.Mlcode),'[a-zA-Z0-9]{5}', 0), ''), '^[0-9]{2,2}\\.[0-9]{1,2}$') THEN 'ICD9'
        |         ELSE  NULL END                      as stdcodetype
        |,case when lower(o.obsvalue) like '%decline%' then 'Y'
        |         	   		    when lower(o.obsvalue) like '%elsewhere%' then 'Y'
        |         	   		    when lower(o.obsvalue) like '%refuse%' then 'Y'
        |        	   		    when lower(o.obsvalue) like '%immune%' then 'Y'
        |          	    		when lower(o.obsvalue) like '%defer%' then 'Y'
        |         	    		  when lower(o.obsvalue) like 'not%' then 'Y'
        |         	    		  when lower(o.obsvalue) like '%received at%' then 'Y'
        |         	    		  when lower(o.obsvalue) like '%recommend%' then 'Y'
        |         	    		  when lower(o.obsvalue) like '%not indicated%' then 'Y'
        |                     when lower(o.obsvalue) like '%discuss%' and lower(o.description) not like '%fall%' then 'Y'
        |                     when lower(o.obsvalue) like '%order%' then 'Y'
        |         	    		  when lower(o.obsvalue) like '%schedule%' then 'Y'
        |         	    		  when lower(o.obsvalue) like '%advised%' then 'Y'
        |         	    		  else 'N' end as obs_not_done
        |,o.db_updated_date
        |FROM dedup_obs o
        |INNER JOIN CENTRICV2_ZH_OBSHEAD zh ON (zh.hdid = o.hdid)
        |inner join dedup_doc d ON  (d.SDID=o.SDID and d.pid = o.pid)
        |left outer join CUSTOMS mcp   on (mcp.groupid = '{groupid}' and {cdsidin})
        | WHERE (o.state IS NULL OR  o.state NOT IN ('D','I','P','S'))
        |   AND (o.Change IS NULL OR  o.Change IN ('0','1','2'))
        |   AND d.finalsign = 1 AND d.status ='S'
        |   {dox_xid_condition}
        |   {obs_xid_condition}
        |   AND (zh.CPTcode IS NOT NULL OR rlike(zh.MLCODE, '(?i)CPT.*(\\d|[a-z]){1}\\d{3}(\\d|[a-z]){1}')
        |   		or {cdsidin})
        |     ) a
        |
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{servicedate_mp}", serviceDateValue).
        replace("{dox_xid_condition}", docXidInclusion).
        replace("{obs_xid_condition}", obsXidInclusion).
        replace("{cdsidin}", cdsidvalue)
    )

  }


}
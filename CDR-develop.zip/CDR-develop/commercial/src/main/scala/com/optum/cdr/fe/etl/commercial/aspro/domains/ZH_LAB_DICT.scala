package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_lab_dict
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ZH_LAB_DICT extends FETableInfo[zh_lab_dict]{

override def name: String = CDRFEParquetNames.zh_lab_dict

override def dependsOn: Set[String] = Set("ZH_LABCATALOG", "LABRESULTS", "PROCEDURES", "VITALS", "MAP_OBSERVATION")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val zh_lab_dict1 = sparkSession.sql(
      """
        |SELECT  groupid
        |       ,client_ds_id
        |       ,localcode
        |       ,localname
        |       ,localdesc
        |       ,local_loinc_code
        |       ,null as localunits
        |FROM
        |(
        |	SELECT  '{groupid}'                                                          AS groupid
        |	       ,{client_ds_id}                                                       AS client_ds_id
        |	       ,string(imrelabcat_code)                                         AS localcode
        |	       ,labcat_name                                                          AS localname
        |	       ,labcat_longname                                                      AS localdesc
        |	       ,CASE WHEN rlike(loinc_id,'\\d{3,7}-\\d') THEN loinc_id ELSE NULL END AS local_loinc_code
        |	FROM ZH_LABCATALOG
        |
        |      UNION
        |
        |	SELECT  '{groupid}'                                                    AS groupid
        |	       ,{client_ds_id}                                                 AS client_ds_id
        |	       ,concat_ws('','ext.',upper(external_id),':',upper(result_name)) AS localcode
        |	       ,result_name                                                    AS localname
        |	       ,result_name                                                    AS localdesc
        |	       ,NULL                                                           AS local_loinc_code
        |	FROM
        |	(
        |		SELECT  lb.*
        |		       ,row_number() over (partition by upper(external_id),upper(result_name) ORDER BY fileid desc nulls last) lb_rnk
        |		FROM LABRESULTS lb
        |		WHERE imrelabcat_code is null
        |	)
        |	WHERE lb_rnk = 1
        |
        |      UNION
        |
        |	SELECT  '{groupid}'                     AS groupid
        |	       ,{client_ds_id}                  AS client_ds_id
        |	       ,concat_ws('','proc.',proc_code) AS localcode
        |	       ,proc_title                      AS localname
        |	       ,proc_title                      AS localdesc
        |	       ,NULL                            AS local_loinc_code
        |	FROM PROCEDURES
        |
        |      UNION
        |
        |	SELECT  '{groupid}'       AS groupid
        |	       ,{client_ds_id}    AS client_ds_id
        |	       ,'Vitals_Pulse_Ox' AS localcode
        |	       ,'Vitals_Pulse_Ox' AS localname
        |	       ,'Vitals_Pulse_Ox' AS localdesc
        |	       ,NULL              AS local_loinc_code
        |	FROM VITALS
        |)
      """.stripMargin
        .replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId)
    )

    val zh_lab_dict2 = sparkSession.sql(
      """
        |SELECT  groupid
        |       ,client_ds_id
        |       ,localcode
        |       ,localname
        |       ,localdesc
        |       ,null as local_loinc_code
        |       ,localunits
        |FROM
        |(
        |	SELECT  groupid                          AS groupid
        |	       ,safe_to_number('{client_ds_id}') AS client_ds_id
        |	       ,localcode
        |	       ,local_name                       AS localname
        |	       ,local_name                       AS localdesc
        |	       ,localunit                        AS LOCALUNITS
        |	FROM MAP_OBSERVATION
        |	WHERE groupid= '{groupid}'
        |	AND obstype = 'LABRESULT'
        |	AND cui = 'CH002048'
        |)
      """.stripMargin
        .replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId)
    )

    val zh_lab_dict2_filtered = zh_lab_dict2.except(
      zh_lab_dict1.select(
        "groupid","client_ds_id","localcode","localname","localdesc","local_loinc_code","localunits"
      )
    )

    zh_lab_dict1.union(zh_lab_dict2_filtered)
  }
}

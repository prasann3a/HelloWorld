package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.sparkdataloader.CDRFEParquetNames



object PROCEDURE extends FEQueryAndMetadata[proceduredo] {
  override def name: String = CDRFEParquetNames.proceduredo

  override def dependsOn: Set[String] = Set("PROCEDURE_TEMP_CCDBA_PAT_RESULTS", "PROCEDURE_TEMP_HHS_CPI_PROCEDURE" , "PROCEDURE_TEMP_HHS_CPI_PROCEDURE2", "PROCEDURE_TEMP_CCDBA_TRIAGE_INFO", "PROCEDURE_TEMP_CCDBA_IV_ADMIN", "PROCEDURE_TEMP_CCDBA_O_ACTION", "PROCEDURE_TEMP_CCDBA_O_PAT_OCCUR", "PROCEDURE_TEMP_ENT_PATIENT")

  override def sparkSql: String =
    """
      |SELECT * FROM PROCEDURE_TEMP_CCDBA_PAT_RESULTS
      |UNION ALL
      |SELECT * FROM PROCEDURE_TEMP_HHS_CPI_PROCEDURE
      |UNION ALL
      |SELECT * FROM PROCEDURE_TEMP_HHS_CPI_PROCEDURE2
      |UNION ALL
      |SELECT * FROM PROCEDURE_TEMP_CCDBA_TRIAGE_INFO
      |UNION ALL
      |SELECT * FROM PROCEDURE_TEMP_CCDBA_IV_ADMIN
      |UNION ALL
      |SELECT * FROM PROCEDURE_TEMP_CCDBA_O_ACTION
      |UNION ALL
      |SELECT * FROM PROCEDURE_TEMP_CCDBA_O_PAT_OCCUR
      |UNION ALL
      |SELECT * FROM PROCEDURE_TEMP_ENT_PATIENT
    """
    .stripMargin
}

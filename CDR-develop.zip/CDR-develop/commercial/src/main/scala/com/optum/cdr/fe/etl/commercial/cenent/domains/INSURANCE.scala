package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.insurance
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object INSURANCE extends FEQueryAndMetadata[insurance] {

  override def name: String = CDRFEParquetNames.insurance

  override def dependsOn: Set[String] = Set("INSURE", "ENCNTR", "ZH_DICT10_PLAN", "ZH_DICT71_CARRIER")

  override def sparkSql: String =
    """
      |select groupid, datasrc, encounterid, patientid, ins_timestamp, facilityid, groupnbr, insuranceorder, policynumber, encounterid, enrollenddt, enrollstartdt, payorcode, payorcode as payorname, plantype, plancode, planname, client_ds_id
      |from
      |(
      |select distinct
      |     '{groupid}' 		      as groupid
      |    ,'insure' 			        as datasrc
      |	   ,{client_ds_id} 		    as client_ds_id
      |	   ,nsr.Entry_Date 		    as ins_timestamp
      |	   ,ncn.Pat_Person_Num 	  as patientid
      |	   ,ncn.Fac_Num 		      as facilityid
      |	   ,nsr.Group_Num 		    as groupnbr
      |	   ,nsr.Insurance_Pos 	  as insuranceorder
      |	   ,nsr.Policy_Num 		    as policynumber
      |	   ,ncn.Num 			        as encounterid
      |	   ,nsr.Insurance_Exp_Date as enrollenddt
      |    ,coalesce(nsr.Insurance_Eff_Date,nsr.Entry_Date) as enrollstartdt
      |	   ,nsr.Payor_Code 		      as payorcode
      |	   ,coalesce(d71.Fac_fc_vt0250,payor_name)   as plantype
      |	   ,nsr.dict_seq        as plancode
      |	   ,d10.plan_long_name  as planname
      |from INSURE nsr
      |inner join ENCNTR ncn on (ncn.prim_acct_num=nsr.insurance_acct)
      |left join ZH_DICT10_PLAN d10 on (d10.dict10_use=nsr.dict_use and d10.dict10_seq=nsr.dict_seq)
      |left join ZH_DICT71_CARRIER d71 on (nsr.payor_code=d71.carrier_code)
      |where nsr.Entry_Date is not null
      |      and ncn.Pat_Person_Num is not null
      |)
    """.stripMargin
}
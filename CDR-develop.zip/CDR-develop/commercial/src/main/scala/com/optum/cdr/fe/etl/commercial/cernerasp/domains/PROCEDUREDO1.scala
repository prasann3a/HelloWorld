package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDUREDO1 extends FETableInfo[proceduredo]{

  override def name:String="PROCEDURE1"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_cpt= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"CPT", "CLAIM", "CHARGEDETAIL",  "HUM_TYPE").mkString(",")

    sparkSession.sql(
      s"""
         |  with   dedup_visit as
         |  ( select * from (
         |       select
         |         visit.unique_person_identifier
         |        ,visit.unique_visit_identifier
         |        ,row_number() over (partition by unique_visit_identifier, unique_person_identifier order by update_date_time desc nulls last ) as rownumber
         |      from VISIT visit
         |      WHERE visit.unique_person_identifier is not null
         |  ) where rownumber = 1  )
         |
         |
         |  select groupid, datasrc, client_ds_id, encounterid, patientid, performingproviderid, proceduredate, localcode, codetype, mappedcode, localname, orderingproviderid, procseq, actualprocdate
         |from
         |(
         |select '{groupid}'		as groupid
         |  	,'charge'	as datasrc
         |  	,{client_ds_id}	as client_ds_id
         |  	,c.unique_visit_identifier	as encounterid
         |  	,c.unique_person_identifier	as patientid
         |  	,coalesce(nullif(c.ordering_physician_identifier, '0'), c.verifying_physician_identifier)	as performingproviderid
         |  	,c.service_date_time	as proceduredate
         |  	,cd.code	as localcode
         |  	,case when cd.hum_type in ({list_cpt}) then 'CPT4' else null end	as codetype
         |  	,cd.code	as mappedcode
         |  	,c.description	as localname
         |  	,coalesce(nullif(c.ordering_physician_identifier, '0'), c.verifying_physician_identifier)		as orderingproviderid
         |  	,cd.hum_sequence	as procseq
         |  	,cd.effective_begin_date_time	as actualprocdate
         |  	,row_number() over (partition by cd.code,c.unique_person_identifier,cd.hum_sequence order by c.update_date_time desc nulls last)	as rownumber
         |  from CHARGE c
         |  	inner join DEDUP_VISIT v on (v.unique_visit_identifier = c.unique_visit_identifier)
         |  	inner join CHARGEDETAIL cd on (c.unique_charge_item_identifier = cd.unique_charge_item_identifier)
         |  where c.unique_person_identifier is not null
         |  and c.service_date_time is not null
         |  and cd.code is not null
         |  and cd.hum_type in ({list_cpt})
         |
         |)
         |where rownumber = 1
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_cpt}",list_cpt)
    )

  }



  override def dependsOn: Set[String] = Set("CHARGE","CHARGEDETAIL","MAP_PREDICATE_VALUES","VISIT")
}

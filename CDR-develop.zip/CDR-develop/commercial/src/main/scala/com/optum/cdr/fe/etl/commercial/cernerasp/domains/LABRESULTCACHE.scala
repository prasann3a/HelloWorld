package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.med3000.domains.lab_result
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object LABRESULTCACHE extends FETableInfo[labresult]{

  override def name:String="LABRESULTCACHE"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }
    val lab_status= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"LAB_STATUS","LAB","RESULT","STATUS").mkString(",")

    sparkSession.sql(
      s"""
         |select
         |	 groupid
         |	,datasrc
         |	,client_ds_id
         |	,labresultid
         |	,localcode
         |	,localresult
         |	,patientid
         |	,datecollected
         |	,dateavailable
         |	,encounterid
         |	,laborderid
         |	,localname
         |	,localunits
         |	,normalrange
         |	,resulttype
         |	,statuscode
         |	,localresult_numeric
         | ,dateavailable as labresult_date
         | ,localresult_numeric as localresult_inferred
         |	from
         |	(
         |    select /*+ Broadcast(rfr,tbl_units) */
         |	 '{groupid}' 											as groupid
         |	,'result' 											as datasrc
         |	,{client_ds_id} 										as client_ds_id
         |	,rsl.unique_result_identifier 						as labresultid
         |	,rsl.code 											as localcode
         |	,rsl.result_value 									as localresult
         |	,safe_to_number(rsl.result_value)					as localresult_numeric
         |	,rsl.unique_person_identifier 						as patientid
         |	,rsl.end_date_time 									as datecollected
         |	,nvl(rsl.performed_date_time, rsl.end_date_time)	as dateavailable
         |	,rsl.unique_visit_identifier 						as encounterid
         |	,rsl.parent_result_identifier 						as laborderid
         |	,rfr.display 										as localname
         |	,tbl_units.description								as localunits
         |	,concat_ws('', rsl.normal_low, ' - ', rsl.normal_high) 		as normalrange
         |	,rsl.normal_code 									as resulttype
         |	,rsl.status 										as statuscode
         |	,row_number() over (partition by rsl.unique_result_identifier order by update_date_time desc nulls first) as rw
         |from RESULT rsl
         |inner join LABRFR rfr
         |on  	rfr.element_code = rsl.code
         |left outer join LABRESULTTBLUNITS tbl_units
         |on tbl_units.element_code = rsl.units
         |where 	rsl.status not in ({lab_status})
         |and 	rsl.unique_result_identifier is not null
         |and 	rsl.code is not null
         |and 	rsl.result_value is not null
         |and     (rsl.performed_date_time is not null or rsl.end_date_time is not null)
         |and 	rsl.unique_person_identifier is not null
         |
         |)
         |where rw=1
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{lab_status}",lab_status)

    )
  }

  override def dependsOn: Set[String] = Set("RESULT","LABRFR","LABRESULTTBLUNITS","REFERENCECODE","MAP_PREDICATE_VALUES")


}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.insurance
import org.apache.spark.storage.StorageLevel
import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import org.apache.spark.sql.{DataFrame, SparkSession}

object INSURANCE extends FETableInfo[insurance] {

  override def name: String = "INSURANCE"

  override def dependsOn: Set[String] =
    Set("CENTRICV2_INSURANC"
      ,"CENTRICV2_ZH_INSURECO"
      ,"CENTRICV2_ZH_BUSINESS"
      ,"CENTRICV2_PATIENTINSURANCE"
      ,"CENTRICV2_PATIENTPROFILE"
      ,"CENTRICV2_ZH_INSURANCECARRIERS"
      ,"CENTRICV2_ZH_INSURANCEGROUP"
      ,"MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val subscriberFlagMpMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"),groupId, clientDsId,"SUBSCRIBERFLAG","INSURANCE","INSURANCE","PATRELTOINSUREDMID").mkString(",")

    sparkSession.sql(
    s"""
      |select
      |       'insurance' as datasrc
      |       ,insid as sourceid
      |       ,ins.pid as patientid
      |       ,coalesce(ins.db_updated_date,ins.db_create_date) as ins_timestamp
      |       ,ico.busid as plancode
      |       ,b.name	as planname
      |       ,ins.idno as policynumber
      |       ,ico.busid as payorcode
      |       ,b.name as payorname
      |       ,null as plantype  --NOTE: JIRA HIT-7602 suggests this is not available at this time
      |       ,grpno as groupnbr
      |       ,ins.effectivedate as enrollstartdt
      |       ,ins.expireddate as enrollenddt
      |       ,case when ins.psistate ='P' then 1 when ins.psistate ='S' then 2 else 3 end as insuranceorder
      |       ,null as SUBSCRIBER_FLAG
      |       ,null as SUBSCRIBER_RELATION
      |  from (select i.*
      |               ,row_number() over (partition by pid,INSID order by coalesce(i.db_updated_date,i.db_create_date) desc nulls last) as ins_rownbr
      |        from CENTRICV2_INSURANC i) ins
      |  left outer join CENTRICV2_ZH_INSURECO ico on (ins.insplanid = ico.insplanid)
      |  left outer join CENTRICV2_ZH_BUSINESS b on (b.busid = ico.busid)
      |  where ins_rownbr = 1
      |  and coalesce(ins.db_updated_date,ins.db_create_date) is not null
      |  and ins.pid is not null
      |  and ins.psistate in ('P','S')
      |
      |UNION ALL
      |
      |  select distinct 'Patientinsurance' as datasrc
      |      ,null as sourceid
      |	     ,pf.Pid				as PATIENTID
      |      ,coalesce(pi.Eligibilityverifieddate,pi.Lastmodified) as INS_TIMESTAMP
      |      ,pi.Insurancecarriersid   as PLANCODE
      |		   ,zh.Name                  as PLANNAME
      |      ,pi.Insuredid			as POLICYNUMBER
      |      ,pi.Insurancecarriersid   as  PAYORCODE
      |		   ,zh.Name                  as PAYORNAME
      |      ,zhi.Name    as PLANTYPE
      |	    ,pi.Groupid			as GROUPNBR
      |     ,pi.Inscardeffectivedate    as ENROLLSTARTDT
      |     ,case when pi.inscardterminationdate is not null then pi.inscardterminationdate
      |           when upper(pi.inactive) = 'TRUE' then coalesce(pi.eligibilityverifieddate, pi.lastmodified)
      |           else null end       as ENROLLENDDT
      |     ,pi.Orderforclaims		as INSURANCEORDER
      |     ,case When pi.patreltoinsuredmid in ($subscriberFlagMpMpv) or pi.patreltoinsuredmid is null then 'Y' else null end as SUBSCRIBER_FLAG
      |     ,case When pi.patreltoinsuredmid is null then 'Self' else pi.patreltoinsuredmid end   as SUBSCRIBER_RELATION
      |	  from CENTRICV2_PATIENTINSURANCE pi
      |	  inner join CENTRICV2_PATIENTPROFILE pf on ( pi.patientprofileid = pf.patientprofileid)
      |	  left outer join CENTRICV2_ZH_INSURANCECARRIERS zh on (pi.insurancecarriersid = zh.insurancecarriersid)
      |	  left outer join CENTRICV2_ZH_INSURANCEGROUP zhi on (zh.insurancegroupid = zhi.insurancegroupid)
    """.stripMargin
    )

  }


}
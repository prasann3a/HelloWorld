package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROCEDURE extends FEQueryAndMetadata[proceduredo]{

  override def name: String = CDRFEParquetNames.proceduredo

  override def dependsOn: Set[String] = Set("PROCEDURE_CACHE_1","PROCEDURE_CACHE_2","PROCEDURE_CACHE_3","PROCEDURE_CACHE_4","PROCEDURE_CACHE_5","PROCEDURE_CACHE_6","PROCEDURE_CACHE_7","PROCEDURE_CACHE_8","PROCEDURE_CACHE_9")

  override def sparkSql: String =
    """
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate,null as proc_end_date,null as localprincipleindicator
      |from
      |(
      |PROCEDURE_CACHE_1
      |)
      |where proc_rn = 1 AND proceduredate IS NOT NULL AND patientid IS NOT NULL AND mappedcode IS NOT NULL
      |
      |union all
      |
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate,null as proc_end_date,null as localprincipleindicator
      |from
      |(
      |PROCEDURE_CACHE_2
      |)
      |where proc_rn = 1 AND proceduredate IS NOT NULL AND patientid IS NOT NULL
      |
      |union all
      |
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
      |from PROCEDURE_CACHE_3
      |
      |union all
      |
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
      |from PROCEDURE_CACHE_4
      |
      |union all
      |
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
      |from PROCEDURE_CACHE_5
      |
      |union all
      |
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
      |from PROCEDURE_CACHE_6
      |
      |union all
      |
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
      |from PROCEDURE_CACHE_7
      |
      |union all
      |
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
      |from PROCEDURE_CACHE_8
      |
      |union all
      |
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
      |from PROCEDURE_CACHE_9
    """
      .stripMargin
}

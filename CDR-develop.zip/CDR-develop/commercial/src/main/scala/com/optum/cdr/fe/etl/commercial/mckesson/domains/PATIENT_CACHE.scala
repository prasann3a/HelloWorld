package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.cdr.fe.etl.commercial.mckesson_patient_cache
import org.apache.spark.storage.StorageLevel

object PATIENT_CACHE extends FEQueryAndMetadata[mckesson_patient_cache]{
  override def name: String = "TEMP_PATIENT_CACHE"

  override def dependsOn: Set[String] = Set("MCKESSON_ENT_PATIENT","ENT_CPI","ZH_ENT_CONFIG_LOV")

  override def sparkSql: String =
    """
      |WITH uni_pat AS
      |(SELECT * FROM (
      |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY cpi_seq ORDER BY modified_dt DESC NULLS LAST, record_version DESC nulls first) rn
      |      FROM MCKESSON_ENT_PATIENT p
      |       )
      |) WHERE rn = 1)
      |SELECT '{groupid}' 	AS groupid
      |,'cpi_seq' 		AS datasrc
      |,{client_ds_id} 		AS client_ds_id
      |,COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq)  AS patientid
      |,uni_pat.medrec_id	AS medicalrecordnumber
      |,COALESCE(Ent_Cpi.Birth_Dt, uni_pat.Birth_Dt) AS dateofbirth
      |,COALESCE(Ent_Cpi.expired_Dt, uni_pat.expired_Dt)  AS dateofdeath
      |,NVL2(COALESCE(Ent_Cpi.Cpi_Status, uni_pat.Expired_Fl), concat_ws('', {client_ds_id}, '.', COALESCE(Ent_Cpi.Cpi_Status, uni_pat.Expired_Fl)), NULL) AS death_ind
      |,NVL2(COALESCE(Ent_Cpi.Ethnicity_Lseq,Ent_Cpi.Ethnicity_Secondary_Lseq,Ent_Cpi.Race_Lseq),
      |      concat_ws('', {client_ds_id}, 'e.', COALESCE(Ent_Cpi.Ethnicity_Lseq,Ent_Cpi.Ethnicity_Secondary_Lseq,Ent_Cpi.Race_Lseq)), NULL) AS ethnicity
      |,NVL2(COALESCE(Ent_Cpi.race_Lseq,Ent_Cpi.Ethnicity_Lseq, Ent_Cpi.Ethnicity_Secondary_Lseq),
      |      concat_ws('', {client_ds_id}, '.', COALESCE(Ent_Cpi.race_Lseq,Ent_Cpi.Ethnicity_Lseq, Ent_Cpi.Ethnicity_Secondary_Lseq)), NULL) AS race
      |,NVL2(Ent_Cpi.Marital_Status_Lseq, concat_ws('', {client_ds_id}, '.', Ent_Cpi.Marital_Status_Lseq), NULL) AS Maritalstatus
      |,COALESCE(Ent_Cpi.first_name, uni_pat.first_name)   AS firstname
      |,COALESCE(Ent_Cpi.last_name, uni_pat.last_name)     AS lastname
      |,COALESCE(Ent_Cpi.middle_name, uni_pat.middle_name)  AS middlename
      |,COALESCE(Ent_Cpi.gender, uni_pat.gender)            AS gender
      |,CASE WHEN ent_cpi.CPI_Status = 'I' THEN 'Y' ELSE NULL END  AS inactive_flag
      |,COALESCE(ent_cpi.modified_dt, ent_cpi.created_dt) AS PATDETAIL_TIMESTAMP
      |,NVL2(COALESCE(Ent_Cpi.Language_Primary_Lseq,Ent_Cpi.Language_Secondary_Lseq),
      |      concat_ws('', {client_ds_id}, '.', COALESCE(Ent_Cpi.Language_Primary_Lseq,Ent_Cpi.Language_Secondary_Lseq)), NULL) AS language
      |,CASE WHEN zh.list_seq = '59171311' THEN Zh.Lov_Value ELSE NULL END AS religion_cd
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq) ORDER BY ent_cpi.modified_dt  DESC NULLS LAST) AS rownumber
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(COALESCE(Ent_Cpi.first_name, uni_pat.first_name))
      |                    ORDER BY ent_cpi.modified_dt  DESC NULLS LAST) AS first_row
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(COALESCE(Ent_Cpi.last_name, uni_pat.last_name))
      |                    ORDER BY ent_cpi.modified_dt  DESC NULLS LAST) AS last_row
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(COALESCE(Ent_Cpi.middle_name, uni_pat.middle_name))
      |                    ORDER BY ent_cpi.modified_dt  DESC NULLS LAST) AS middle_row
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(COALESCE(Ent_Cpi.gender, uni_pat.gender))
      |                    ORDER BY ent_cpi.modified_dt  DESC NULLS LAST) AS gender_row
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(COALESCE(Ent_Cpi.Ethnicity_Lseq,Ent_Cpi.Ethnicity_Secondary_Lseq,Ent_Cpi.Race_Lseq))
      |                    ORDER BY ent_cpi.modified_dt  DESC NULLS LAST) AS ethnicity_row
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(COALESCE(Ent_Cpi.race_Lseq,Ent_Cpi.Ethnicity_Lseq, Ent_Cpi.Ethnicity_Secondary_Lseq))
      |                    ORDER BY ent_cpi.modified_dt  DESC NULLS LAST) AS race_row
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(Ent_Cpi.Marital_Status_Lseq)
      |		    ORDER BY ent_cpi.modified_dt  DESC NULLS LAST) AS mstatus_row
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(COALESCE(Ent_Cpi.Cpi_Status, uni_pat.Expired_Fl))
      |                    ORDER BY ent_cpi.modified_dt  DESC NULLS LAST) AS death_row
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(COALESCE(Ent_Cpi.Language_Primary_Lseq,Ent_Cpi.Language_Secondary_Lseq))
      |                    ORDER BY ent_cpi.modified_dt DESC NULLS LAST) AS language_row
      |,ROW_NUMBER() OVER (PARTITION BY COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq), UPPER(CASE WHEN zh.list_seq = '59171311' THEN Zh.Lov_Value ELSE NULL END)
      |                    ORDER BY ent_cpi.modified_dt DESC NULLS LAST) AS religion_row
      |FROM ENT_CPI
      |   LEFT OUTER JOIN UNI_PAT ON ent_cpi.cpi_seq = uni_pat.cpi_seq
      |   LEFT OUTER JOIN ZH_ENT_CONFIG_LOV zh ON (ent_cpi.religion_lseq = Zh.Lov_seq)
      |WHERE COALESCE(Ent_Cpi.Cpi_Seq, uni_pat.Cpi_Seq) IS NOT NULL
    """.stripMargin
}

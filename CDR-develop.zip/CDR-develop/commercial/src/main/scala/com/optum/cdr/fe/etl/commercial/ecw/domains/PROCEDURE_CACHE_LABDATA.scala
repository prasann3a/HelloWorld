package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_LABDATA extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_LABDATA"

  override def dependsOn: Set[String] = Set("LABDATA", CDRFEParquetNames.clinicalencounter, "MAP_CUSTOM_PROC", "ZH_ITEMS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    val receivedFlag = if(List("H969977","H135772","H772763").contains(runtimeVar.groupId) || List(4947).contains(runtimeVar.clientDsId)) "received <> '0'" else "1=1"

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val procedureDate = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LABDATA", "PROCEDUREDO",
      "PROCEDUREDO", "PROCEDURE_DATE").mkString(",")
    val constNoMpvMatches = "'NO_MPV_MATCHES'"
    val procedureDateCol = if (procedureDate == constNoMpvMatches) "'null'" else procedureDate

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH dedup_labdata AS (
        | SELECT  *
        | FROM
        | (
        | 	SELECT  l.*
        | 	       ,ROW_NUMBER() OVER (PARTITION BY Reportid ORDER BY received DESC NULLS LAST,modifieddate DESC nulls last) rn
        | 	FROM LABDATA l
        | )
        | WHERE deleteflag <> '1'
        | AND cancelled <> '1'
        | AND {received_flag_val}
        | AND rn = 1
        |)
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localcode
        |       ,encounterid
        |       ,patientid
        |       ,proceduredate
        |       ,localname
        |       ,orderingproviderid
        |       ,mappedcode
        |       ,codetype
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                                                                          AS groupid
        |	       ,'labdata'                                                                                                                            AS datasrc
        |	       ,{client_ds_id}                                                                                                                       AS client_ds_id
        |	       ,concat_ws('','{client_ds_id_prefix}',dedup_labdata.Itemid)                                                                           AS localcode
        |	       ,Enc.Patientid                                                                                                                        AS patientid
        |	       ,CASE WHEN {procedure_date_col} = 'null' THEN enc.arrivaltime ELSE (case
        |	             WHEN colldate is not null AND date_format(colldate,'yyyy') not IN ('1901','1900','0001') THEN colldate
        |	             WHEN resultdate is not null AND date_format(RESULTDATE,'yyyy') not IN ('1901','1900','0001') THEN RESULTDATE
        |	             WHEN revieweddate is not null AND date_format(REVIEWEDDATE,'yyyy') not IN ('1901','1900','0001') THEN REVIEWEDDATE ELSE null END ) END AS PROCEDUREDATE
        |	       ,Enc.Encounterid                                                                                                                      AS encounterid
        |	       ,Zh_Items.Itemname                                                                                                                    AS localname
        |	       ,dedup_labdata.Ordphyid                                                                                                               AS orderingproviderid
        |	       ,map_custom_proc.Mappedvalue                                                                                                          AS mappedcode
        |	       ,'CUSTOM'                                                                                                                             AS codetype
        |	FROM DEDUP_LABDATA
        |	JOIN {CLINICALENCOUNTER} enc
        |	  ON (dedup_labdata.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
        |	JOIN MAP_CUSTOM_PROC
        |	  ON (map_custom_proc.groupid = '{groupid}' AND map_custom_proc.datasrc = 'labdata' AND map_custom_proc.LocalCode = concat_ws('', '{client_ds_id_prefix}', dedup_labdata.ItemID))
        |	LEFT OUTER JOIN ZH_ITEMS
        |	  ON (dedup_labdata.ItemID = zh_items.itemid)
        |)
        |WHERE proceduredate IS NOT NULL
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{received_flag_val}", receivedFlag)
        .replace("{procedure_date_col}", procedureDateCol)
    )
  }


}

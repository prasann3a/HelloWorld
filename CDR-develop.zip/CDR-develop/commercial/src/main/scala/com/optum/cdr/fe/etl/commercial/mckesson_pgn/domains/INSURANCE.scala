package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.insurance
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object INSURANCE extends FEQueryAndMetadata[insurance]{

override def name: String = CDRFEParquetNames.insurance

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT", "MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL", "MCKESSON_PGN_V1_TPM311_VISIT_PAYOR", "MCKESSON_PGN_V1_ZH_TPM700_PAYOR_PLAN")

  override def sparkSql: String =
    """
      |WITH uni_visit AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                             FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
      |   )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'
      |   AND Psn_Int_Id IS NOT NULL
      |   AND arv_date_time IS NOT NULL),
      |uni_dtl AS
      |(SELECT * FROM
      |(SELECT d.*, ROW_NUMBER() OVER (PARTITION BY cod_dtl_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC nulls first) rn
      |   FROM MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL d
      |    )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D' )
      |select groupid, datasrc, client_ds_id, patientid, encounterid, ins_timestamp, enrollenddt, enrollstartdt, groupnbr, insuranceorder, plantype, plancode, planname, payorcode, payorname, policynumber
      |from
      |(
      |SELECT '{groupid}' AS groupid
      |	,'visit_payor' AS datasrc
      |	,{client_ds_id} AS client_ds_id
      |	,COALESCE(safe_to_date_length(uni_visit.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit.adm_ts) AS ins_timestamp
      |        ,uni_visit.Psn_Int_Id AS patientid
      |        ,uni_visit.Vst_Int_Id AS encounterid
      |	,NULL 	   AS enrollenddt
      |	,NULL      AS enrollstartdt
      |	,NVL2(pln.Src_Of_Pymt_Id, concat_ws('', '{client_ds_id}', '.', pln.Src_Of_Pymt_Id), NULL) AS plantype
      |	,NULL      AS groupnbr
      |	,CASE WHEN LOWER(uni_dtl.cod_dtl_ds) LIKE '%primary%' THEN 1
      |	   WHEN LOWER(uni_dtl.cod_dtl_ds) LIKE '%secondary%' THEN 2
      |	   WHEN LOWER(uni_dtl.cod_dtl_ds) LIKE '%tertiary%' THEN 3 ELSE 4 END AS insuranceorder
      |	,pyr.Isn_Org_Nm  AS payorcode
      |	,pyr.Isn_Org_Nm  AS payorname
      |	,pyr.Plan_Int_Id AS plancode
      |	,pln.Plan_Ds     AS planname
      |	,pyr.Policy_No   AS policynumber
      |	,ROW_NUMBER() OVER (PARTITION BY uni_visit.Psn_Int_Id,uni_visit.Vst_Int_Id,
      |	             COALESCE(safe_to_date_length(uni_visit.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit.adm_ts),
      |	             pyr.Isn_Org_Nm,pln.Src_Of_Pymt_Id
      |	       ORDER BY pyr.Lst_Mod_Ts DESC NULLS LAST, pyr.fileid DESC nulls first) rn
      |FROM MCKESSON_PGN_V1_TPM311_VISIT_PAYOR pyr
      |     JOIN UNI_VISIT ON (pyr.vst_int_id = uni_visit.vst_int_id)
      |     JOIN MCKESSON_PGN_V1_ZH_TPM700_PAYOR_PLAN pln ON (pyr.plan_int_id = pln.plan_int_id)
      |     LEFT OUTER JOIN UNI_DTL ON (pyr.pyr_seq_no = uni_dtl.cod_dtl_int_id )
      |WHERE pyr.row_sta_cd <> 'D'
      |  AND pln.row_sta_cd <> 'D'
      |)
    """.stripMargin
}

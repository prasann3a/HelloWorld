package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object DICTIONARY extends FEQueryAndMetadata[zh_facility] {

  override def name: String = CDRFEParquetNames.zh_facility

  override def dependsOn: Set[String] = Set("ZH_XFACLT")

  override def sparkSql: String =
    """
      |select groupid, client_ds_id, facilityid, facilityname, facilitypostalcd
      |from
      |(
      |SELECT
      |	'{groupid}' as groupid
      |	,{client_ds_id} as client_ds_id
      |	,Num  AS facilityid
      |	,Nm  AS facilityname
      |	,Addr_Postal_Cde  AS facilitypostalcd
      |FROM ZH_XFACLT
      |)
    """.stripMargin

}
package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.rxadmin
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXMEDADMINISTRATIONS_TEMP_CCDBA_O_PAT extends FETableInfo[rxadmin]{
  override def name: String = "RXMEDADMINISTRATIONS_TEMP_CCDBA_O_PAT"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","CCDBA_O_PAT","MCKESSON_ENT_PATIENT","ZH_CCDEV_DRUG","ZH_CCDEV_O_ITEM")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_incl_priority = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_O_PAT", "RXADMIN", "CCDBA_O_PAT", "PRIORITY").mkString(",")
    val list_incl_source = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_O_PAT", "RXADMIN", "CCDBA_O_PAT", "SOURCE_SYSTEM").mkString(",")

    sparkSession.sql(
      s"""
         |WITH uni_opat AS
         |(SELECT * FROM (
         |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY order_ddt DESC NULLS LAST) rn
         |      FROM CCDBA_O_PAT i
         |      WHERE Order_Seq IS NOT NULL
         |      )
         |WHERE rn = 1),
         |uni_epat AS
         |(SELECT * FROM (
         |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |      FROM MCKESSON_ENT_PATIENT p
         |      WHERE cpi_seq IS NOT NULL )
         |) WHERE rn = 1),
         |uni_drug AS
         |(SELECT * FROM (
         |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY drug_id ORDER BY change_dt DESC NULLS LAST) rn
         |      FROM ZH_CCDEV_DRUG i
         |       )
         |WHERE rn = 1)
         |select datasrc, localmedcode, patientid, administrationtime, encounterid, rxorderid, localgenericdesc, localdrugdescription, localqtyofdoseunit, rxadministrationid, localform, localroute, localstrengthperdoseunit, localstrengthunit
         |from
         |(
         |SELECT 'ccdba_o_pat' as datasrc
         |       ,EPE.Cpi_Seq AS patientid
         |       ,COP.Order_Seq AS rxadministrationid
         |       ,case when {client_ds_id} in (5464, 5726)  then (concat_ws('', COP.Order_Seq, '_2')) else COP.Order_Seq  end AS rxorderid
         |       ,ZCO.Preferred_Display_Name AS localdrugdescription
         |       ,ZCO.Preferred_Display_Name AS localgenericdesc
         |       ,COP.Order_Item_Seq AS localmedcode
         |       ,COP.Quantity AS localqtyofdoseunit
         |       ,COP.Start_Ddt AS administrationtime
         |       ,COP.Pat_Seq AS encounterid
         |       ,coalesce(uni_drug.dose_form,
         |nullif(trim(nullif(regexp_extract(LOWER(ZCO.ORDER_NAME),' (capsule|cream|drops?|enema|infusion|inh([alertion]+)?|inj|iv(pb| ?push)?|irrigating|neb(ulizer)?|ointment|patch|susp|soln|tab(let)?|supp(ository)?|syrup| )+', 0), '')), '')) as localform
         |       ,coalesce(uni_drug.route,
         |nullif(trim(nullif(regexp_extract(LOWER(ZCO.ORDER_NAME),' (capsule|cream|ear|enema|eye|drops?|inj|infusion|inh([alertion]+)?|iv(pb| ?push)?|neb(ulizer)?|ointment|oral|otic|po |sl|susp|supp(ository)?|rectal| )+', 0), '')), '')) as LOCALROUTE
         |       ,coalesce(uni_drug.strength,nullif(trim(nullif(regexp_extract(regexp_extract(LOWER(ZCO.ORDER_NAME),' [0-9]([0-9.]+)? ?[a-z0-9./%]+', 0),'^[0-9./ ]+', 0), '')), '')) as LOCALSTRENGTHPERDOSEUNIT
         |       ,coalesce(uni_drug.str_units,nullif(trim(nullif(regexp_replace(nullif(regexp_extract(LOWER(ZCO.ORDER_NAME),' [0-9]([0-9.]+)? ?[a-z0-9./%]+', 0), ''),'^[0-9./ ]+',''), '')), '')) as LOCALSTRENGTHUNIT
         |       ,row_number() over (partition by cop.ORDER_SEQ order by epe.RECORD_VERSION desc nulls first ) as rownumber
         |FROM UNI_EPAT EPE
         |INNER JOIN UNI_OPAT COP ON (epe.pat_seq = cop.pat_seq)
         |INNER JOIN ZH_CCDEV_O_ITEM ZCO ON (zco.order_item_seq = cop.order_item_seq)
         |LEFT OUTER JOIN UNI_DRUG ON (cop.drug_code = uni_drug.generic_id)
         |WHERE cop.source_system in ({list_incl_source}) and cop.priority in ({list_incl_priority})
         |and cop.drug_code is not null
         |AND EPE.Cpi_Seq is not null
         |AND COP.Order_Seq is not null
         |
         |)
         |where rownumber=1
       """.stripMargin.replace("{list_incl_priority}",list_incl_priority).replace("{list_incl_source}",list_incl_source).replace("{client_ds_id}",clientDsId)
    )
  }
}

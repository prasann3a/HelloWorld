package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object ZH_FACILITY_CACHE extends FETableInfo[zh_facility] {


  override def name:String="FACILITYCACHE"


  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select groupid, facilityid, facilityname, facilitypostalcd, client_ds_id
         |from
         |(
         |select '{groupid}'           as groupid
         |       ,rl.unique_location_identifier		as facilityid
         |       ,rl.name	as facilityname
         |       ,a.zipcode	as facilitypostalcd
         |       ,'{client_ds_id}'     as client_ds_id
         |       ,row_number() over (partition by rl.unique_location_identifier order by rl.update_date_time desc nulls last)	as rownumber
         |from REFERENCELOCATION rl
         |	left outer join (select zipcode,entity_identifier
         |				,row_number() over (partition by entity_identifier order by hum_type, update_date_time desc nulls last) as ad_rownum
         |			 from ADDRESS
         |			 where entity_type = 'LOCATION'
         |			) a on (rl.unique_location_identifier = a.entity_identifier and ad_rownum = 1)
         |where rl.unique_location_identifier	 is not null
         |and rl.name is not null
         |
         |)
         |where rownumber =1
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
    )
  }

  override def dependsOn: Set[String] = Set("REFERENCELOCATION","ADDRESS")
}
package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.cdr.models.zh_provider_contact
import com.optum.oap.sparkdataloader.CDRFEParquetNames

object PROVIDERCONTACT extends FEQueryAndMetadata[zh_provider_contact]{
  override def name: String = CDRFEParquetNames.zh_provider_contact

  override def dependsOn: Set[String] = Set("ZH_ENT_CONFIG_STAFF_ADDRESS")

  override def sparkSql: String =
    """
      |select 'Zh_Ent_Config_Staff_Address' as datasrc, local_provider_id, email_address, update_date, address_line1, address_line2, city, state, zipcode, work_phone
      |from
      |(
      |SELECT  staff_seq             AS local_provider_id
      |       ,NULL		      AS email_address
      |       ,modified_dt	      AS update_date
      |       ,Address_Line_1	      AS address_line1
      |       ,Address_Line_2        AS address_line2
      |       ,city                  AS city
      |       ,state                 AS state
      |       ,postal_code           AS zipcode
      |       ,NULL                  AS work_phone
      |       ,ROW_NUMBER() OVER (PARTITION BY staff_seq ORDER BY modified_dt DESC NULLS LAST) AS rn
      |FROM ZH_ENT_CONFIG_STAFF_ADDRESS
      |WHERE staff_seq IS NOT NULL
      |  AND modified_dt IS NOT NULL
      |
      |)
      |where rn = 1
    """.stripMargin
}

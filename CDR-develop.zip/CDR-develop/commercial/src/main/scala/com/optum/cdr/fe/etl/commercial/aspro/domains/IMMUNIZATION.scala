package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.immunization
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object IMMUNIZATION extends FEQueryAndMetadata[immunization] {

  override def name: String = CDRFEParquetNames.immunization

  override def dependsOn: Set[String] = Set("ASPRO_IMMUNIZATIONS", "ZH_DRUGS")

  override def sparkSql: String =
    """
      |SELECT 'immunizations' as datasrc
      |	,Immunizations.Immunization_Id  AS localimmunizationcd
      |	,Immunizations.Patient_Id  AS patientid
      |	,Immunizations.Given_Date  AS admindate
      |	,Immunizations.Entered_Date  AS documenteddate
      |	,Zh_Drugs.Drug_Gpi  AS localgpi
      |	,Immunizations.Immunization_Name  AS localimmunizationdesc
      |	,NULL  AS localndc
      |	,Immunizations.Injectionroute_Code  AS localroute
      |FROM ASPRO_IMMUNIZATIONS Immunizations
      |	LEFT OUTER JOIN ZH_DRUGS Zh_Drugs ON (IMMUNIZATIONS.DRUG_CODE = ZH_DRUGS.DRUG_CODE)
      |WHERE Immunizations.status_code = '4'
    """.stripMargin
}

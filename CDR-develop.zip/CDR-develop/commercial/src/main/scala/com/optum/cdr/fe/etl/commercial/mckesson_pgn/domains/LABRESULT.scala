package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.labresult

object LABRESULT extends FEQueryAndMetadata[labresult]{
  override def name: String = CDRFEParquetNames.labresult

  override def dependsOn: Set[String] = Set("LABRESULT_MCKESSON_PGN","NONNUMERIC_LABRESULT")

  override def sparkSql: String =
    """
      |select * from LABRESULT_MCKESSON_PGN
      |UNION ALL
      |select * from NONNUMERIC_LABRESULT
    """.stripMargin
}

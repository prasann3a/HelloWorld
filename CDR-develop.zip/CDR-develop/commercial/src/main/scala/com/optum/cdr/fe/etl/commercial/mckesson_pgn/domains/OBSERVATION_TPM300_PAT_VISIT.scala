package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.{map_predicate_values, observation}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_TPM300_PAT_VISIT extends FETableInfo[observation]{
  override def name: String = "OBSERVATION_TPM300_PAT_VISIT"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_T_PTHEIGHT","ZCM_OBSTYPE_CODE","MCKESSON_PGN_V1_T_PTWEIGHT","OBSERVATION_CACHE_TPM300_PAT_VISIT","MCKESSON_PGN_V1_TPP341_SUBSTANCE_HX","MCKESSON_PGN_V1_T_PTDATA","MCKESSON_PGN_V1_TPP380_PAT_EDUCATION","MCKESSON_PGN_V1_TSM047_ADV_DIR_HDR","MCKESSON_PGN_V1_TIF120_GEN_RESULT")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val staRsnExcl = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "OBS_EXC","OBSERVATION","SUBSTANCE_HX","STA_RSN_CD").mkString(",")
    val resFinds = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LOCALRESULTPREFIX","OBSERVATION","PTDATA","FIND_CODE").mkString(",")
    val codeFinds = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LOCALCODEPREFIX","OBSERVATION","PTDATA","FIND_CODE").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH uni_visit1 AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        | WHERE Vst_Int_Id IS NOT NULL
        |   AND Psn_Int_Id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'  )
        |
        |,uni_visit2 AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        | WHERE Vst_Int_Id IS NOT NULL
        |   AND Psn_Int_Id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'  )
        |
        |,uni_visit3 AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        | WHERE Vst_Int_Id IS NOT NULL
        |   AND Psn_Int_Id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'  )
        |
        |,uni_visit4 as
        |(select *
        | from (select v.*, row_number() over (partition by vst_int_id order by lst_mod_ts desc nulls last, fileid desc nulls last) rn
        |       from MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        |       where vst_int_id is not null
        |       and psn_int_id is not null
        |
        |       )
        | where rn = 1
        | and row_sta_cd <> 'D'
        |
        |)
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid, null as statuscode
        |from
        |(
        |SELECT '{groupid}' 		AS groupid,
        |	'ptheight' 		AS datasrc
        |	,{client_ds_id} 		AS client_ds_id
        |	,ht.Ht_Cm               AS localresult
        |	,'HEIGHT'               AS localcode
        |	,ht.Entry_For_Date      AS obsdate
        |	,uni_visit1.Psn_Int_Id  	AS patientid
        |	,ht.vst_int_id  	AS encounterid
        |	,NULL		 	AS facilityid
        |	,z.obstype
        |	,z.localunit 		AS local_obs_unit
        |    	,z.obstype_std_units 	AS std_obs_unit
        |	,NULL 	                AS obsresult
        |	,ROW_NUMBER() OVER (PARTITION BY uni_visit1.Psn_Int_Id,ht.Vst_Int_Id,ht.Entry_For_Date,z.obstype
        |			    ORDER BY ht.Lst_Mod_Ts DESC NULLS LAST) obs_rn
        |FROM MCKESSON_PGN_V1_T_PTHEIGHT ht
        |    CROSS JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
        |                                z.datasrc = 'ptheight' AND
        |                                z.obstype <> 'LABRESULT' AND
        |				z.obscode = 'HEIGHT')
        |    JOIN UNI_VISIT1 ON (ht.vst_int_id = uni_visit1.vst_int_id)
        |WHERE ht.Entry_For_Date IS NOT NULL
        |  AND ht.row_sta_cd <> 'D'
        |  AND ht.strike_out_flag = '0'
        |
        |)
        |where obsdate IS NOT NULL AND obs_rn = 1
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid, null as statuscode
        |from
        |(
        |SELECT '{groupid}' 		AS groupid,
        |	'ptweight' 		AS datasrc
        |	,{client_ds_id} 		AS client_ds_id
        |	,wt.Wt_Kg               AS localresult
        |	,'WEIGHT'               AS localcode
        |	,wt.Entry_For_Date      AS obsdate
        |	,uni_visit2.Psn_Int_Id  	AS patientid
        |	,wt.vst_int_id  	AS encounterid
        |	,NULL		 	AS facilityid
        |	,z.obstype
        |	,z.localunit 		AS local_obs_unit
        |    	,z.obstype_std_units 	AS std_obs_unit
        |	,NULL 	                AS obsresult
        |	,ROW_NUMBER() OVER (PARTITION BY uni_visit2.Psn_Int_Id,wt.Vst_Int_Id,wt.Entry_For_Date,z.obstype
        |			    ORDER BY wt.Lst_Mod_Ts DESC NULLS LAST) obs_rn
        |FROM MCKESSON_PGN_V1_T_PTWEIGHT wt
        |    CROSS JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
        |                                z.datasrc = 'ptweight' AND
        |                                z.obstype <> 'LABRESULT' AND
        |				z.obscode = 'WEIGHT')
        |    JOIN UNI_VISIT2 ON (wt.vst_int_id = uni_visit2.vst_int_id)
        |WHERE wt.Entry_For_Date IS NOT NULL
        |  AND wt.row_sta_cd <> 'D'
        |  AND wt.strike_out_flag = '0'
        |
        |)
        |where obsdate IS NOT NULL AND obs_rn = 1
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid, null as statuscode
        |from
        |(
        |OBSERVATION_CACHE_TPM300_PAT_VISIT
        |)
        |where obstype <> 'LABRESULT' AND obsdate IS NOT NULL AND obs_rn = 1
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid, null as statuscode
        |from
        |(
        |SELECT '{groupid}' 		AS groupid,
        |	'substance_hx' 		AS datasrc
        |	,{client_ds_id} 		AS client_ds_id
        |	,CASE WHEN hx.qit_dt IS NOT NULL THEN 'QUIT'
        |	      ELSE concat_ws('', hx.Use_At, '_', hx.Use_Amt_Unt_Int_Id, '_', hx.Use_Frq_Int_Id) END  AS localresult
        |	,concat_ws('', '{client_ds_id}', '.', hx.Sub_Typ_Int_Id) AS localcode
        |	,hx.Ety_Ts              AS obsdate
        |	,hx.Psn_Int_Id  	AS patientid
        |	,NULL           	AS encounterid
        |	,NULL		 	AS facilityid
        |	,z.obstype
        |	,z.Localunit            AS local_obs_unit
        |    	,z.obstype_std_units 	AS std_obs_unit
        |	,NULL 	                AS obsresult
        |	,ROW_NUMBER() OVER (PARTITION BY hx.Psn_Int_Id,hx.Sub_Typ_Int_Id,hx.Ety_Ts,z.obstype
        |			    ORDER BY hx.Lst_Mod_Ts DESC NULLS LAST) obs_rn
        |FROM MCKESSON_PGN_V1_TPP341_SUBSTANCE_HX hx
        |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
        |                                z.datasrc = 'substance_hx' AND
        |                                z.obstype <> 'LABRESULT' AND
        |				z.obscode = concat_ws('', '{client_ds_id}', '.', hx.Sub_Typ_Int_Id))
        |WHERE hx.Psn_Int_Id IS NOT NULL
        |  AND hx.Ety_Ts IS NOT NULL
        |  AND hx.row_sta_cd <> 'D'
        |  AND hx.obs_ts IS NULL
        |  AND (hx.sta_rsn_cd NOT IN ({sta_rsn_excl}) OR hx.sta_rsn_cd IS NULL)
        |
        |)
        |where obsdate IS NOT NULL AND obs_rn = 1
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid, null as statuscode
        |from
        |(
        |SELECT pre_map.*
        |	,z.obstype
        |	,z.localunit AS local_obs_unit
        |    	,z.obstype_std_units 	AS std_obs_unit
        |       ,ROW_NUMBER() OVER (PARTITION BY patientid,encounterid,localcode,obsdate,obstype
        |			    ORDER BY Lst_Mod_Ts DESC NULLS LAST) obs_rn
        |FROM (
        |SELECT '{groupid}' 		AS groupid,
        |	'ptdata' 		AS datasrc
        |	,{client_ds_id} 		AS client_ds_id
        |	,CASE WHEN dt.Find_Code IN ({res_finds}) THEN dt.value
        |	      ELSE concat_ws('', '{client_ds_id}', '.', dt.find_Code) END  AS localresult
        |	,concat_ws('', '{client_ds_id}', '.', CASE WHEN dt.Find_Code IN ({code_finds}) THEN concat_ws('', dt.Category_Code, '-', dt.Grp_Code, '-', dt.Find_Code)
        |	      ELSE concat_ws('', dt.Category_Code, '-', dt.Grp_Code) END) AS localcode
        |	,dt.Entered_For_Date    AS obsdate
        |	,uni_visit3.Psn_Int_Id  	AS patientid
        |	,dt.vst_int_id  	AS encounterid
        |	,NULL		 	AS facilityid
        |	,NULL 	                AS obsresult
        |	,dt.Lst_Mod_Ts
        |FROM MCKESSON_PGN_V1_T_PTDATA dt
        |    JOIN UNI_VISIT3 ON (dt.vst_int_id = uni_visit3.vst_int_id)
        |WHERE dt.Entered_For_Date IS NOT NULL
        |  AND dt.row_sta_cd <> 'D'
        |  AND dt.strike_out_flag = '0'
        | ) pre_map
        |JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
        |               		    z.datasrc = 'ptdata' AND
        |               		    z.obstype <> 'LABRESULT' AND
        |	                    z.obscode = pre_map.localcode)
        |
        |)
        |where obsdate IS NOT NULL AND obs_rn = 1
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid, null as statuscode
        |from
        |(
        |SELECT '{groupid}' 		AS groupid,
        |	'pat_education' 	AS datasrc
        |	,{client_ds_id} 		AS client_ds_id
        |	,ed.Pat_Edu_Doc_Nm      AS localresult
        |	,ed.Pat_Edu_Doc_Nm      AS localcode
        |	,ed.Ety_Ts              AS obsdate
        |	,ed.Psn_Int_Id  	AS patientid
        |	,ed.Vst_Int_Id         	AS encounterid
        |	,NULL		 	AS facilityid
        |	,z.obstype
        |	,z.Localunit            AS local_obs_unit
        |    	,z.obstype_std_units 	AS std_obs_unit
        |	,NULL 	                AS obsresult
        |	,ROW_NUMBER() OVER (PARTITION BY ed.Psn_Int_Id,ed.Vst_Int_Id,ed.Pat_Edu_Doc_Nm,ed.Ety_Ts,z.obstype
        |			    ORDER BY ed.Lst_Mod_Ts DESC NULLS LAST) obs_rn
        |FROM MCKESSON_PGN_V1_TPP380_PAT_EDUCATION ed
        |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
        |                                z.datasrc = 'pat_education' AND
        |                                z.obstype <> 'LABRESULT' AND
        |				z.obscode = ed.Pat_Edu_Doc_Nm)
        |WHERE ed.Psn_Int_Id IS NOT NULL
        |  AND ed.Ety_Ts IS NOT NULL
        |  AND ed.row_sta_cd <> 'D'
        |  AND ed.obs_ts IS NULL
        |  AND (ed.sta_rsn_cd NOT IN ({sta_rsn_excl}) OR ed.sta_rsn_cd IS NULL)
        |
        |)
        |where obsdate IS NOT NULL AND obs_rn = 1
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid, null as statuscode
        |from
        |(
        |SELECT '{groupid}' 		AS groupid,
        |	'adv_dir_hdr' 	        AS datasrc
        |	,{client_ds_id} 		AS client_ds_id
        |	,concat_ws('', '{client_ds_id}', '.', hdr.Adv_Dir_Int_Id)     AS localresult
        |	,'ADVANCED DIRECTIVE'   AS localcode
        |	,hdr.Adv_Dir_Eff_Ts     AS obsdate
        |	,hdr.Psn_Int_Id  	AS patientid
        |	,NULL            	AS encounterid
        |	,NULL		 	AS facilityid
        |	,z.obstype
        |	,z.Localunit            AS local_obs_unit
        |    	,z.obstype_std_units 	AS std_obs_unit
        |	,NULL 	                AS obsresult
        |	,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,hdr.Adv_Dir_Eff_Ts,z.obstype
        |			    ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST) obs_rn
        |FROM MCKESSON_PGN_V1_TSM047_ADV_DIR_HDR hdr
        |    CROSS JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
        |                                z.datasrc = 'adv_dir_hdr' AND
        |                                z.obstype <> 'LABRESULT' AND
        |				z.obscode = 'ADVANCED DIRECTIVE')
        |WHERE hdr.Psn_Int_Id IS NOT NULL
        |  AND hdr.Adv_Dir_Eff_Ts IS NOT NULL
        |  AND hdr.row_sta_cd <> 'D'
        |  AND hdr.obs_ts IS NULL
        |
        |)
        |where obsdate IS NOT NULL AND obs_rn = 1
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid, statuscode
        |from
        |(
        |select '{groupid}' 	    as groupid
        |       ,'gen_result'        as datasrc
        |       ,{client_ds_id} 	    as client_ds_id
        |       ,b.psn_int_id        as patientid
        |       ,a.vst_int_id        as encounterid
        |       ,a.gen_ts            as obsdate
        |       ,a.gen_rsu_sta_cd    as statuscode
        |       ,'LVEF'              as localcode
        |       ,nullif(trim(nullif(regexp_extract(lower(gen_tx),'(ef.teich.{4,7})', 0), '')), '') as localresult
        |       ,null		    as facilityid
        |       ,z.obstype
        |       ,z.localunit         as local_obs_unit
        |       ,z.obstype_std_units as std_obs_unit
        |       ,null 	            as obsresult
        |       ,row_number() over (partition by b.psn_int_id, a.vst_int_id, a.gen_ts, z.obstype
        |                           order by a.lst_mod_ts desc nulls last, a.fileid desc nulls last) obs_rn
        |from MCKESSON_PGN_V1_TIF120_GEN_RESULT a
        |join UNI_VISIT4 b on (a.vst_int_id = b.vst_int_id)
        |cross join ZCM_OBSTYPE_CODE z
        |   on z.groupid = '{groupid}'
        |   and z.datasrc = 'gen_result'
        |   and z.obstype <> 'LABRESULT'
        |   and z.obscode = 'LVEF'
        |where lower(gen_tx) like '%teich%'
        |
        |)
        |where obsdate IS NOT NULL AND obs_rn = 1
      """
        .stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{sta_rsn_excl}", staRsnExcl)
        .replace("{res_finds}", resFinds)
        .replace("{code_finds}", codeFinds)
    )
  }


}

package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.insurance
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}

object INSURANCE extends FEQueryAndMetadata[insurance] {
  override def name: String = CDRFEParquetNames.insurance

  override def dependsOn: Set[String] = Set("MCKESSON_ENT_CPI_INSURANCE", "MCKESSON_ENT_PATIENT_INSURANCE")

  override def sparkSql: String =
    """
      WITH uni_cpi AS
      (
        SELECT * FROM
        (
          SELECT c.*, ROW_NUMBER() OVER (PARTITION BY cpi_insurance_seq ORDER BY modified_dt DESC NULLS LAST) rn
          FROM MCKESSON_ENT_CPI_INSURANCE c
        )
        WHERE rn = 1),
      uni_pat AS
      (
        SELECT * FROM
        (
          SELECT p.*, ROW_NUMBER() OVER (PARTITION BY cpi_insurance_seq, pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
          FROM MCKESSON_ENT_PATIENT_INSURANCE p
        )
        WHERE rn = 1
      )
       SELECT distinct 'ent_cpi_insurance'     AS datasrc
        ,uni_cpi.created_dt           AS ins_timestamp  -- not null field
        ,uni_cpi.Cpi_Seq              AS patientid
        ,uni_pat.pat_seq              AS encounterid
        ,uni_cpi.Effective_Thru_Dt    AS enrollenddt
        ,uni_cpi.effective_dt         AS enrollstartdt
        ,CASE WHEN uni_Cpi.insurance_company_name = 'UNINSURED' THEN 'UNINSURED'
              ELSE NVL2(uni_cpi.payor_type, CONCAT_WS('', {client_ds_id},'.',uni_cpi.payor_type), NULL) END AS plantype
        ,uni_cpi.Group_Nbr   AS groupnbr
        ,NULLIF(uni_cpi.Insurance_Order, '99')  AS insuranceorder
        ,uni_cpi.Insurance_Company_Name         AS payorcode
        ,uni_cpi.Insurance_Company_Name         AS payorname
        ,uni_cpi.plan_name            AS plancode
        ,uni_cpi.plan_name            AS planname
        ,uni_cpi.policy_number        AS policynumber
       FROM uni_Cpi
            LEFT OUTER JOIN uni_pat ON (uni_cpi.cpi_insurance_seq = uni_pat.cpi_insurance_seq)
       WHERE uni_cpi.Cpi_Seq IS NOT NULL
          AND uni_cpi.Created_Dt IS NOT NULL
    """.stripMargin

}

package com.optum.cdr.fe.etl.commercial.cernerasp.domains
import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ZH_FACILITY extends FETableInfo[zh_facility]{

  override def name:String =CDRFEParquetNames.zh_facility

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select groupid, facilityid, facilityname, facilitypostalcd, client_ds_id
         |from
         |FACILITYCACHE
         |union all
         |
         |select groupid, facilityid, facilityname, facilitypostalcd, client_ds_id
         |from
         |(
         |select '{groupid}'           as groupid
         |       ,rc.element_code		as facilityid
         |       ,rc.description	as facilityname
         |       ,a.zipcode	as facilitypostalcd
         |       ,'{client_ds_id}'     as client_ds_id
         |       ,row_number() over (partition by rc.element_code order by a.zipcode desc nulls last)	as rownumber
         |from REFERENCECODE rc
         |	left outer join ADDRESS a on (rc.element_code = a.entity_identifier and a.entity_type = 'LOCATION')
         |	left outer join FACILITYCACHE  f on (f.groupid = '{groupid}' and f.client_ds_id = '{client_ds_id}' and f.facilityid = rc.element_code)
         |where rc.element_code is not null
         |and rc.description is not null
         |and rc.file_name = 'VISIT'
         |and rc.field = 'LOCATION_CODE'
         |and f.facilityid is null
         |
 |)
         |where rownumber =1
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
    )

  }

  override def dependsOn: Set[String] = Set("REFERENCECODE","ADDRESS","FACILITYCACHE")
}
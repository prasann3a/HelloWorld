package com.optum.cdr.fe.etl.commercial.med3000.domains


import com.optum.oap.cdr.models.patientaddr
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTADDRESS extends FEQueryAndMetadata[patientaddr]{

  override def name: String = CDRFEParquetNames.patientaddr

  override def dependsOn: Set[String] = Set("MED3000_MPI")

  override def sparkSql: String =
    """
      |select '{groupid}' as groupid, {client_ds_id} as client_ds_id, 'MPI' as datasrc, patientid, address_date, address_line1, address_line2, city, state, zipcode
      |from
      |(
      |select  Mpi.Blind_Key 		as patientid
      |  	   ,Mpi.Address2  		as address_line1
      |       ,Mpi.Address1  		as address_line2
      |       ,Mpi.City 			as city
      |       ,upper(nullif(regexp_replace(Mpi.Hum_State,'[^a-zA-Z]', ''), '')) as state
      |       ,case when length(nullif(regexp_replace(Mpi.Zip,'[^a-zA-Z]', ''), '')) is null and length(Mpi.Zip) in (5,9,10) then
      |              Mpi.Zip else null end as zipcode
      |       ,max(Mpi.Update_Date) as address_date
      |  from MED3000_MPI MPI
      | where Mpi.Blind_Key is not null
      |   and coalesce(Mpi.Address1,Mpi.Address2,Mpi.City,Mpi.Hum_State,Mpi.Zip) is not null
      |   and (length(nullif(regexp_replace(Mpi.Hum_State,'[^a-zA-Z]', ''), '')) = 2 or Mpi.Hum_State is null)
      |
      |group by Mpi.Blind_Key,Mpi.Address1,Mpi.Address2,Mpi.City,Mpi.Hum_State,Mpi.Zip
      |)
    """.stripMargin
}

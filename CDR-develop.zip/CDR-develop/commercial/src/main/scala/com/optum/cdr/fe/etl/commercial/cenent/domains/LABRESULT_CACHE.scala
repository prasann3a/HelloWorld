package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object LABRESULT_CACHE extends FEQueryAndMetadata[labresult] {

  override def name: String = "LABRESULT_CACHE"

  override def dependsOn: Set[String] = Set("LABRESULT_SERVCE_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, datecollected, LABORDEREDDATE, dateavailable, encounterid, laborderid, localname, normalrange, resulttype, statuscode, localtestname, localunits, LABRESULT_DATE, localresult_numeric, localresult_numeric as localresult_inferred, local_loinc_code
      |from
      |(
      |LABRESULT_SERVCE_CACHE
      |)
      |where res_row = 1 AND localresult_numeric IS NOT NULL AND labresultid IS NOT NULL
    """.stripMargin
}
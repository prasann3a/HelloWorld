package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_EDI_INV_CPT extends FEQueryAndMetadata[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_EDI_INV_CPT"

  override def dependsOn: Set[String] = Set("EDI_INVOICE", "EDI_INV_CPT", CDRFEParquetNames.clinicalencounter, "ZH_ITEMS", "ZH_ITEMDETAIL")

  override def sparkSql: String =
    """
      |WITH dedup_inv AS (
      |	SELECT  *
      |	FROM
      |	(
      |		SELECT  i.*
      |					,ROW_NUMBER() OVER (PARTITION BY id ORDER BY modifydate DESC nulls last) rn
      |		FROM EDI_INVOICE i
      |		WHERE deleteflag <> '1'
      |	)
      |	WHERE rn = 1
      |),
      |
      |dedup_cpt AS (
      |	SELECT  *
      |	FROM
      |	(
      |		SELECT  c.*
      |					,concat_ws('',c.invoiceid,'.',c.id)                                                                          AS sourceid
      |					,COALESCE(nullif(regexp_extract(revcodeid,'([0-9])+',0),''),nullif(regexp_extract(revcode,'([0-9])+',0),'')) AS rev_code
      |					,ROW_NUMBER() OVER (PARTITION BY nullif(concat_ws('',id,invoiceid),'') ORDER BY c.modifieddate DESC nulls last) rn
      |		FROM EDI_INV_CPT c
      |	)
      |	WHERE rn = 1
      |	AND deleteflag <> '1'
      |),
      |
      |sum_units AS (
      |    SELECT  a.patientid
      |        ,b.sdos
      |        ,b.code
      |    FROM DEDUP_INV a
      |    JOIN DEDUP_CPT b
      |    ON a.id = b.invoiceid
      |    GROUP BY  a.patientid
      |            ,b.sdos
      |            ,b.code
      |    HAVING SUM(b.units) > 0
      |)
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,localcode
      |       ,encounterid
      |       ,patientid
      |       ,proceduredate
      |       ,hosp_px_flag
      |       ,localname
      |       ,localbillingproviderid
      |       ,orderingproviderid
      |       ,performingproviderid
      |       ,procseq
      |       ,mappedcode
      |       ,codetype
      |       ,sourceid
      |FROM
      |(
      |	SELECT  '{groupid}'                                                                            AS groupid
      |	       ,'edi_inv_cpt'                                                                          AS datasrc
      |	       ,{client_ds_id}                                                                         AS client_ds_id
      |	       ,dedup_cpt.Code                                                                         AS localcode
      |	       ,dedup_inv.Patientid                                                                    AS patientid
      |	       ,dedup_cpt.Sdos                                                                         AS proceduredate
      |	       ,dedup_inv.Encounterid                                                                  AS encounterid
      |	       ,CASE WHEN LENGTH(rev_code) = 3 THEN 'Y'
      |	             WHEN LENGTH(rev_code) = 4 THEN 'Y' ELSE 'N' END                                   AS hosp_px_flag
      |	       ,CASE WHEN dedup_inv.Paytoproviderid = '0' THEN null ELSE dedup_inv.Paytoproviderid END AS localbillingproviderid
      |	       ,Zh_Items.Itemname                                                                      AS localname
      |	       ,dedup_cpt.Ordpruserid                                                                  AS orderingproviderid
      |	       ,CASE WHEN dedup_inv.Renproviderid = '0' THEN null ELSE dedup_inv.Renproviderid END     AS performingproviderid
      |	       ,dedup_cpt.Displayindex                                                                 AS procseq
      |	       ,Zh_Itemdetail.Value                                                                    AS mappedcode
      |	       ,CASE WHEN rlike(Zh_Itemdetail.Value,'^[0-9]{4}[0-9A-Z]$') THEN 'CPT4'
      |	             WHEN rlike(Zh_Itemdetail.Value,'^[A-Z]{1,1}[0-9]{4}$') THEN 'HCPCS' ELSE NULL END AS codetype
      |	       ,enc.flag
      |	       ,concat_ws('',dedup_inv.Patientid,'.',dedup_cpt.sourceid)                               AS sourceid
      |	FROM DEDUP_INV
      |	LEFT OUTER JOIN
      |	(
      |		SELECT  enc1.*
      |		       ,'1' AS flag
      |		FROM {CLINICALENCOUNTER} enc1
      |	) enc
      |		ON (dedup_inv.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
      |	JOIN DEDUP_CPT
      |		ON (dedup_inv.id = dedup_cpt.invoiceid)
      |	LEFT OUTER JOIN ZH_ITEMS
      |		ON (dedup_cpt.ItemID = ZH_Items.ItemID)
      |	LEFT OUTER JOIN ZH_ITEMDETAIL
      |		ON (dedup_cpt.ItemID = Zh_Itemdetail.ItemID AND Zh_ItemDetail.PropID = '13')
      |	JOIN SUM_UNITS
      |		ON sum_units.patientid = dedup_inv.patientid AND sum_units.sdos = dedup_cpt.sdos AND sum_units.code = dedup_cpt.code
      |)
      |WHERE proceduredate IS NOT NULL
      |AND (('{groupid}' = 'H458934' AND flag =1) or ('{groupid}' <> 'H458934'))
    """.stripMargin
      .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)


}

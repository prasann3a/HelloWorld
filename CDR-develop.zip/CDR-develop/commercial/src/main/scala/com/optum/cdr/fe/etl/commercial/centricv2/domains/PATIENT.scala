package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object PATIENT extends FEQueryAndMetadata[patient] {

  override def name: String = "PATIENT"

  override def dependsOn: Set[String] = Set("PATIENT_PART1_CACHE", "PATIENT_PART2_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, patientid, medicalrecordnumber, dateofbirth, dateofdeath, inactive as inactive_flag
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where rownumber = 1 and patientid is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, medicalrecordnumber, dateofbirth, dateofdeath, inactive as inactive_flag
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where rownumber = 1 and patientid is not null
      |
    """.stripMargin
}
package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, rx_patient_reported}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RX_PAT_REP_CACHE_MEDICATIONS extends FETableInfo[rx_patient_reported]{

  override def name: String = "RX_PAT_REP_CACHE_MEDICATIONS"

  override def dependsOn: Set[String] = Set("MEDICATIONS", "REFERENCEMEDICATION", "MEDICATIONDETAILS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listDOSEUNIT = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "DOSE_UNIT","RX","RX","DETAIL_QUESTION").mkString(",")
    val listQTYDOSEUNIT = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "QTY_DOSE_UNIT","RX","RX","DETAIL_QUESTION").mkString(",")
    val listROUTE = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "ROUTE","RX","RX","DETAIL_QUESTION").mkString(",")
    val listSTRGDOSE = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "STRG_DOSE","RX","RX","DETAIL_QUESTION").mkString(",")
    val listSTRGDOSEUNIT = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "STRG_DOSE_UNIT","RX","RX","DETAIL_QUESTION").mkString(",")
    val listMEDSTATUS = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "MED_STATUS","RX","MEDICATION","STATUS").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,patientid
        |       ,discontinuedate
        |       ,discontinuereason
        |       ,localdoseunit
        |       ,localdrugdescription
        |       ,encounterid
        |       ,localform
        |       ,localmedcode
        |       ,localndc
        |       ,localqtyofdoseunit
        |       ,localroute
        |       ,localstrengthperdoseunit
        |       ,localstrengthunit
        |       ,medreportedtime
        |       ,reportedmedid
        |       ,rxnorm_code
        |       ,localtotaldose
        |FROM
        |(
        |	SELECT  groupid
        |	       ,datasrc
        |	       ,client_ds_id
        |	       ,patientid
        |	       ,discontinuedate
        |	       ,discontinuereason
        |	       ,localdoseunit
        |	       ,localdrugdescription
        |	       ,encounterid
        |	       ,localform
        |	       ,localmedcode
        |	       ,localndc
        |	       ,localqtyofdoseunit
        |	       ,localroute
        |	       ,localstrengthperdoseunit
        |	       ,localstrengthunit
        |	       ,medreportedtime
        |	       ,reportedmedid
        |	       ,rxnorm_code
        |	       ,nvl(safe_to_number(localstrengthperdoseunit),0) * nvl(safe_to_number(localqtyofdoseunit),0) AS localtotaldose
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                                                                                AS groupid
        |		       ,'medications'                                                                                                                              AS datasrc
        |		       ,{client_ds_id}                                                                                                                             AS client_ds_id
        |		       ,md.unique_person_identifier                                                                                                                AS patientid
        |		       ,MAX(md.discontinue_date_time) over (partition by md.unique_medication_identifier ORDER BY md.discontinue_date_time desc nulls last)        AS discontinuedate
        |		       ,MAX(case WHEN md.discontinue_type = '0' THEN null else md.discontinue_type end) over (partition by md.unique_medication_identifier)        AS discontinuereason
        |		       ,MAX(case WHEN mdc.detail_question IN ({list_DOSE_UNIT}) THEN mdc.text_answer else null end) over (partition by md.unique_medication_identifier) AS localdoseunit
        |		       ,MAX(md.ordered_as) over (partition by md.unique_medication_identifier)                                                                     AS localdrugdescription
        |		       ,md.unique_visit_identifier                                                                                                                 AS encounterid
        |		       ,MAX(case WHEN mdc.detail_question IN ({list_DOSE_UNIT}) THEN CASE WHEN lower(mdc.text_answer) = 'ml' THEN 'liquid' else mdc.text_answer end else null end) over (partition by md.unique_medication_identifier) AS localform
        |		       ,CASE WHEN ct.desc_ct is null THEN md.unique_synonym_identifier ELSE nullif(substr(md.ordered_as,1,100),'') END                             AS localmedcode
        |		       ,MAX(nullif(replace(rfr.ndc,'-',''),'')) over (partition by md.unique_medication_identifier)                                                AS localndc
        |		       ,MAX(case WHEN mdc.detail_question IN ({list_QTY_DOSE_UNIT}) THEN mdc.text_answer end) over (partition by md.unique_medication_identifier)  AS localqtyofdoseunit
        |		       ,MAX(case WHEN mdc.detail_question IN ({list_ROUTE}) THEN concat_ws('','{client_ds_id}','.',mdc.coded_answer) end) over (partition by md.unique_medication_identifier) AS localroute
        |		       ,MAX(case WHEN mdc.detail_question IN ({list_STRG_DOSE}) THEN mdc.text_answer end) over (partition by md.unique_medication_identifier)      AS localstrengthperdoseunit
        |		       ,MAX(case WHEN mdc.detail_question IN ({list_STRG_DOSE_UNIT}) THEN mdc.text_answer end) over (partition by md.unique_medication_identifier) AS localstrengthunit
        |		       ,md.update_date_time                                                                                                                        AS medreportedtime
        |		       ,nullif(concat_ws('',md.unique_medication_identifier,date_format(md.update_date_time,'yyyyMMddHHmmss')),'')                               AS reportedmedid
        |		       ,MAX(rfr.rxnorm) over (partition by md.unique_synonym_identifier)                                                                           AS rxnorm_code
        |		       ,md.unique_synonym_identifier                                                                                                               AS unique_synonym_identifier
        |		       ,row_number() over (partition by md.unique_medication_identifier ORDER BY md.update_date_time desc nulls first)                             AS rw
        |		FROM MEDICATIONS md
        |
        |   INNER JOIN
        |		(
        |			SELECT  unique_synonym_identifier
        |			       ,rxnorm
        |			       ,ndc
        |			FROM
        |			(
        |				SELECT  r.unique_synonym_identifier      AS unique_synonym_identifier
        |				       ,r.rxnorm                         AS rxnorm
        |				       ,nullif(replace(r.ndc,'-',''),'') AS ndc
        |				       ,row_number() over (partition by unique_synonym_identifier,ndc,rxnorm ORDER BY fileid desc nulls first) rn
        |				FROM REFERENCEMEDICATION r
        |			)
        |			WHERE rn =1
        |		) rfr ON md.unique_synonym_identifier = rfr.unique_synonym_identifier
        |
        |   INNER JOIN MEDICATIONDETAILS mdc ON md.unique_medication_identifier = mdc.unique_medication_identifier
        |
        |   LEFT OUTER JOIN
        |		(
        |			SELECT  unique_synonym_identifier
        |			       ,COUNT(distinct ordered_as) AS desc_ct
        |			FROM MEDICATIONS
        |			GROUP BY  unique_synonym_identifier
        |			HAVING COUNT(distinct ordered_as)>20
        |		) ct ON ( md.unique_synonym_identifier = ct.unique_synonym_identifier )
        |
        |   WHERE md.placed_order_as = '2'
        |		AND md.status not IN ( {list_MED_STATUS})
        |		AND md.unique_person_identifier is not null
        |	)
        |	WHERE rw =1
        |)
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{list_DOSE_UNIT}", listDOSEUNIT)
        .replace("{list_QTY_DOSE_UNIT}", listQTYDOSEUNIT)
        .replace("{list_ROUTE}", listROUTE)
        .replace("{list_STRG_DOSE}", listSTRGDOSE)
        .replace("{list_STRG_DOSE_UNIT}", listSTRGDOSEUNIT)
        .replace("{list_MED_STATUS}", listMEDSTATUS)
    )
  }


}
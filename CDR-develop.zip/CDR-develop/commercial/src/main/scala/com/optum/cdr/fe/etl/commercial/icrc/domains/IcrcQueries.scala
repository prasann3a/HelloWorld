package com.optum.cdr.fe.etl.commercial.icrc.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.cdr.fe.etl.icrc.domains._
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}


object IcrcQueries extends BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)

  override def queryRegistry = QueryRegistry.queries

}

object InitialDependencies {

  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      FELoadFromParquet[pharmacy](name = "PHARMACY", parquetLocation = s"$baseParquetLocation", tableName = "PHARMACY")
    , FELoadFromParquet[pharmacy](name = "PHARMV2", parquetLocation = s"$baseParquetLocation", tableName = "PHARMACY")
    , FELoadFromParquet[eligibility](name = "ELIGIBILITY", parquetLocation = s"$baseParquetLocation", tableName = "ELIGIBILITY", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[member_detail](name = "MEMBER_DETAIL", parquetLocation = s"$baseParquetLocation", tableName = "MEMBER_DETAIL")
    , FELoadFromParquet[medical_H834852](name = "MEDICAL", parquetLocation = s"$baseParquetLocation", tableName = "MEDICAL", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[missing_members](name = "MISSING_MEMBERS", parquetLocation = s"$baseParquetLocation", tableName = "MISSING_MEMBERS")
    , FELoadFromParquet[zo_bpo_map_employer](name = "ZO_BPO_MAP_EMPLOYER", parquetLocation = s"$mappingParquetPath", tableName = "ZO_BPO_MAP_EMPLOYER")
    , FELoadFromParquet[int_claim_member](name = "INT_CLAIM_MEMBER", parquetLocation = s"$mappingParquetPath", tableName = "INT_CLAIM_MEMBER")
    , FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PREDICATE_VALUES")

  )
}

object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    INT_CLAIM_PHARM
    , INT_CLAIM_MEDICAL
    , INT_CLAIM_MEMBER
    , PAT_RISK_ATTRIB
  )
}

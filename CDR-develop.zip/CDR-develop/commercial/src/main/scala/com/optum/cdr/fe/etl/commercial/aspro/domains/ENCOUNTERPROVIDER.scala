package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.encounterprovider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ENCOUNTERPROVIDER extends FEQueryAndMetadata[encounterprovider] {

  override def name: String = CDRFEParquetNames.encounterprovider

  override def dependsOn: Set[String] = Set("ENCOUNTERPROVIDER1", "ENCOUNTERPROVIDER2")

  override def sparkSql: String =
    """
      |select * from ENCOUNTERPROVIDER1
      |
      |UNION ALL
      |
      |select * from ENCOUNTERPROVIDER2
    """.stripMargin
}

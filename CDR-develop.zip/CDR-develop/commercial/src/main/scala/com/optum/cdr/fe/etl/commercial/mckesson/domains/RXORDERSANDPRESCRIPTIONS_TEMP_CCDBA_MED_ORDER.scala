package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_MED_ORDER extends FETableInfo[rxorder] {
  override def name: String = "RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_MED_ORDER"

  override def dependsOn: Set[String] = Set("CCDBA_MED_ORDER", "ZH_CCDEV_DRUG" , "ZH_DRUG1_FDB_PACKAGEDDRUG" , "MCKESSON_ENT_PATIENT" , "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val excl_id = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_MED_ORDER", "MEDS", "CCDBA_MED_ORDER", "DRUG_ID").mkString(",")
    val med_pat_type = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_MED_ORDER", "MEDS", "ENT_PATIENT", "PAT_TYPE_GROUP_LSEQ").mkString(",")



    sparkSession.sql(s"""
                        |WITH uni_order AS
                        |(SELECT * FROM (
                        |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY chart_ddt DESC NULLS LAST) rn
                        |      FROM CCDBA_MED_ORDER i
                        |      WHERE Order_Seq IS NOT NULL
                        |        AND NVL(route, 'null') NOT IN ('MISC', 'NA')
                        |      )
                        |WHERE rn = 1),
                        |uni_drug AS
                        |(SELECT * FROM (
                        |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY drug_id ORDER BY change_dt DESC NULLS LAST) rn
                        |      FROM ZH_CCDEV_DRUG i
                        |       )
                        |WHERE rn = 1),
                        |uni_pat AS
                        |(SELECT * FROM (
                        |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
                        |      FROM MCKESSON_ENT_PATIENT p
                        |      WHERE cpi_seq IS NOT NULL )
                        |) WHERE rn = 1)
                        |select datasrc, issuedate, patientid, encounterid, rxid, discontinuedate, localinfusionrate, localdosefreq, localdoseunit, localform, localgenericdesc, localndc, localproviderid, ordertype, venue, localdescription, ordervsprescription, localmedcode, localroute, localstrengthperdoseunit, localstrengthunit, localtotaldose
                        |from
                        |(
                        |SELECT 'ccdba_med_order' AS datasrc
                        |    ,uni_order.Sched_Ddt  AS issuedate
                        |    ,CASE WHEN uni_pat.Pat_Type_Group_Lseq IN ({med_pat_type}) THEN 'O' ELSE 'P' END AS ordervsprescription
                        |    ,uni_pat.cpi_seq      AS patientid
                        |    ,case when {client_ds_id} in (5464, 5726)  then (concat_ws('', uni_order.Order_Seq, '_1')) else (uni_order.Order_Seq) end  AS rxid
                        |    ,uni_order.Pat_Seq    AS encounterid
                        |    ,CASE WHEN date_format(uni_order.end_ddt, 'yyyy') = '2200' OR uni_order.end_ddt < uni_order.sched_ddt THEN NULL
                        |          ELSE uni_order.end_ddt END AS discontinuedate
                        |    ,uni_order.Infus_Rate AS localinfusionrate
                        |    ,NVL2(uni_order.Frequency_Id, concat_ws('', {client_ds_id}, '.', uni_order.Frequency_Id), NULL) AS localdosefreq
                        |    ,uni_drug.Dose_Form   AS localdoseunit
                        |    ,CASE WHEN uni_order.Drug_id IN ({excl_id}) THEN LOWER(uni_order.drug_name) ELSE LOWER(COALESCE(uni_drug.sec_name, uni_order.drug_name)) END  AS localdescription
                        |    ,uni_drug.Vol_Units   AS localform
                        |    ,CASE WHEN uni_order.Drug_id IN ({excl_id}) THEN NULL ELSE LOWER(uni_drug.primary_name) END AS localgenericdesc
                        |    ,CASE WHEN uni_order.Drug_id IN ({excl_id}) THEN LOWER(uni_order.drug_name) ELSE uni_order.drug_id END  AS localmedcode
                        |    ,CASE WHEN uni_order.Drug_id IN ({excl_id}) THEN NULL ELSE zh.Pmid END     AS localndc
                        |    ,NVL2(uni_order.Route,concat_ws('', {client_ds_id}, '.', uni_order.route),NULL)  AS localroute
                        |    ,COALESCE(uni_drug.strength, zh.strength) AS localstrengthperdoseunit
                        |    ,COALESCE(uni_drug.str_units, zh.strengthunits) AS localstrengthunit
                        |    ,uni_order.staff_id  AS localproviderid
                        |    ,CASE WHEN uni_pat.Pat_Type_Group_Lseq IN ({med_pat_type}) THEN 'CH002045' ELSE 'CH002047' END AS ordertype
                        |    ,NULL                AS localtotaldose
                        |    ,CASE WHEN uni_pat.Pat_Type_Group_Lseq IN ({med_pat_type}) THEN '0' ELSE '1' END  AS venue
                        |    ,ROW_NUMBER() OVER (PARTITION BY uni_order.Order_Seq ORDER BY uni_order.chart_ddt DESC NULLS LAST) rn
                        |FROM UNI_ORDER
                        |   JOIN UNI_PAT ON (uni_order.pat_seq = uni_pat.pat_seq)
                        |   LEFT OUTER JOIN UNI_DRUG ON (uni_order.drug_id = uni_drug.drug_id)
                        |   LEFT OUTER JOIN ZH_DRUG1_FDB_PACKAGEDDRUG zh ON (uni_order.drug_id = zh.pmid)
                        |
                        |
                        |)
                        |where rn = 1
    """.stripMargin.replace("{excl_id}",excl_id).replace("{med_pat_type}",med_pat_type).replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId))
  }
}

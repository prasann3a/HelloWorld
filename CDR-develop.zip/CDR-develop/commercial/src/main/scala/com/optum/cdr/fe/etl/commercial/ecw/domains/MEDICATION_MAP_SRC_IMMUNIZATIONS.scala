package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object MEDICATION_MAP_SRC_IMMUNIZATIONS extends FEQueryAndMetadata[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_IMMUNIZATIONS"

  override def dependsOn: Set[String] = Set("IMMUNIZATIONS", "ZH_ITEMS")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localmedcode, localdescription, localndc, num_recs as no_ndc, 0 as has_ndc, num_recs
      |from
      |(
      |SELECT groupid,datasrc
      |    ,client_ds_id
      |    ,localimmunizationcd  AS localmedcode
      |    ,localimmunizationdesc as localdescription
      |    ,localndc
      |    ,sum(nvl2(localndc,0,1)) as no_ndc
      |    ,sum(nvl2(localndc,1,0)) as has_ndc
      |    ,count(*) as num_recs
      |FROM
      |(
      |    SELECT '{groupid}' as groupid
      |    ,'immunizations' as datasrc
      |    ,{client_ds_id} as client_ds_id
      |    ,immunizations.Itemid  AS localimmunizationcd
      |    ,zh_items.itemname AS localimmunizationdesc
      |    , NULL as localndc
      |    FROM (SELECT * FROM (
      |          SELECT i.*, ROW_NUMBER() OVER (PARTITION BY immunizationid ORDER BY modifieddate DESC NULLS LAST) rn
      |          FROM IMMUNIZATIONS i
      |          WHERE DELETEFLAG <> '1' )
      |          WHERE rn = 1) immunizations
      |    LEFT OUTER JOIN ZH_ITEMS
      |       ON (immunizations.ItemID = zh_items.itemid)
      |)
      |group by groupid,datasrc
      |    ,client_ds_id
      |    ,localimmunizationcd,
      |    localimmunizationdesc
      |    ,localndc
      |)
    """.stripMargin

}

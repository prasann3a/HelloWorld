package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.mborder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object MBORDER extends FEQueryAndMetadata[mborder] {

  override def name: String = CDRFEParquetNames.mborder

  override def dependsOn: Set[String] = Set("ORDERZ", "ZH_XSERVC")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localordercode, patientid, dateordered, facilityid, encounterid, localorderdesc, localspecimenname, localspecimensource, localorderstatus, mbprocorderid, mborder_date
      |from
      |(
      |SELECT '{groupid}' as groupid
      |	,'orderz' as datasrc
      |	,{client_ds_id} as client_ds_id
      |	,Orderz.Serv_Descr_Num  AS localordercode
      |	,Orderz.Pat_Person_Num  AS patientid
      |	,Orderz.Begin_Dttm  AS dateordered
      |	,Orderz.Encntr_Num  AS encounterid
      |	,Orderz.Fac_Num  AS facilityid
      |	,Zh_Xservc.Nm  AS localorderdesc
      |	,Zh_Xservc.Nm  AS localspecimenname
      |	,Orderz.Serv_Descr_Num  AS localspecimensource
      |        ,nullif(concat_ws('', Orderz.order_status_cde, Orderz.order_substatus_cde), '')  AS localorderstatus
      |	,nullif(concat_ws('', ORDERZ.PAT_PERSON_NUM, date_format(ORDERZ.DATA_CREATE_TS,'yyyyMMddHHmmss'), ORDERZ.SERV_DESCR_NUM), '') AS mbprocorderid
      |	,orderz.begin_dttm AS mborder_date
      |	,ROW_NUMBER() OVER (PARTITION BY nullif(concat_ws('', ORDERZ.PAT_PERSON_NUM, date_format(ORDERZ.DATA_CREATE_TS,'yyyyMMddHHmmss'), ORDERZ.SERV_DESCR_NUM), '')
      |	                    ORDER BY 1) rn
      |FROM ORDERZ
      |     INNER JOIN ZH_XSERVC ON (zh_xservc.num = orderz.serv_descr_num)
      |WHERE zh_xservc.serv_subtype_cde = 'MICRO'
      |  AND nullif(concat_ws('', orderz.order_status_cde, orderz.order_substatus_cde), '') in('A','AU','IE','IX', 'AF')
      |
      |)
      |where rn = 1 AND patientid IS NOT NULL AND mborder_date IS NOT NULL
    """.stripMargin
}
package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE4 extends FEQueryAndMetadata[proceduredo]{

override def name: String = "PROCEDURE4"

override def dependsOn: Set[String] = Set("SCAN_DOCUMENT", "MAP_CUSTOM_PROC")

override def sparkSql: String =
  """
    |SELECT  groupid
    |       ,datasrc
    |       ,facilityid
    |       ,encounterid
    |       ,patientid
    |       ,proceduredate
    |       ,localcode
    |       ,localname
    |       ,codetype
    |       ,mappedcode
    |       ,client_ds_id
    |FROM
    |(
    |	SELECT  distinct '{groupid}' AS groupid
    |	       ,'scan_document'      AS datasrc
    |	       ,sd.location_id       AS facilityid
    |	       ,null                 AS encounterid
    |	       ,sd.imredem_code      AS patientid
    |	       ,sd.document_dt       AS proceduredate
    |	       ,sd.description       AS localcode
    |	       ,sd.description       AS localname
    |	       ,mcp.codetype         AS codetype
    |	       ,mcp.mappedvalue      AS mappedcode
    |	       ,{client_ds_id}       AS client_ds_id
    |	FROM SCAN_DOCUMENT sd
    |	INNER JOIN MAP_CUSTOM_PROC mcp
    |	ON (sd.description = mcp.localcode AND '{groupid}'=mcp.groupid AND 'scan_document'=mcp.datasrc)
    |	WHERE sd.scanstatus_code = 4
    |)
  """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_ALLERGY extends FETableInfo[medication_map_src] {

  override def name: String = "MEDICATION_MAP_SRC_ALLERGY"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES", "REFERENCETERMINOLOGY")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val list_terminology = mpvList(mapPredicateValues, groupId, clientDsId, "ALLERGY_TERMINOLOGY", "RX", "REFERENCETERMINOLOGY", "TERMINOLOGY").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql("""select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, localgeneric, localbrand, localgpi, localform, localstrength, no_ndc, has_ndc, num_recs, ndc_src
                       |        from
                       |        (
                       |        select
                       |                                 '{groupid}' as groupid
                       |                                ,'allergy' as datasrc
                       |                                ,{client_ds_id} as client_ds_id
                       |                                ,localmedcode
                       |                                ,localdescription
                       |                                ,localgeneric
                       |                                ,null as localndc
                       |                                ,null as localbrand
                       |                                ,null as localgpi
                       |                                ,null as localform
                       |                                ,null as localstrength
                       |                                ,count(*) as no_ndc
                       |                                ,0        as has_ndc
                       |                                ,count(*) as num_recs
                       |                                ,count(*) as ndc_src
                       |                from (
                       |                                select
                       |                                 rt.unique_terminology_identifier               as localmedcode
                       |                                ,nullif(substr(rt.text,1,200), '')                              as localdescription
                       |                                ,nullif(substr(rt.text,1,200), '')                              as localgeneric
                       |                                ,row_number() over (partition by rt.unique_terminology_identifier order by update_date_time desc nulls first) as rw
                       |                from REFERENCETERMINOLOGY rt
                       |                where   rt.terminology in ({list_terminology})
                       |                and     rt.unique_terminology_identifier is not null
                       |                and     rt.text is not null
                       |                ) where rw = 1
                       |                group by localmedcode, localdescription, localgeneric
                       |        )
                       """.stripMargin
      .replace("{groupid}", groupId)
      .replace("{client_ds_id}", clientDsId)
      .replace("{list_terminology}", list_terminology)
    )
  }
}

package com.optum.cdr.fe.etl.commercial.med3000.domains


import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object LABRESULT extends FEQueryAndMetadata[labresult] {

  override def name: String = CDRFEParquetNames.labresult

  override def dependsOn: Set[String] = Set("TEMP_LABRESULT_CACHE","NONNUMERIC_LABRESULT")

  override def sparkSql: String =
    """
      |select groupid, datasrc, labresultid, laborderid, patientid, datecollected, dateavailable, localresult, localcode, localname, normalrange, localunits, statuscode, labresult_date, localresult_numeric,  localresult_inferred, resulttype, client_ds_id, localtestname, local_loinc_code,relativeindicator,mappedunits, datecollected,statuscode ,localunits_inferred,localspecimentype, locallisresource,normalizedvalue from
      |TEMP_LABRESULT_CACHE
      |where localresult_numeric is not null
      |
      |union all
      |
      |select groupid, datasrc, labresultid, laborderid, patientid, datecollected, dateavailable, localresult, localcode, localname, normalrange, localunits, statuscode, labresult_date, localresult_numeric,  localresult_inferred, resulttype, client_ds_id, localtestname, local_loinc_code,relativeindicator,mappedunits, datecollected,statuscode ,localunits_inferred,localspecimentype, locallisresource,normalizedvalue from
      |NONNUMERIC_LABRESULT
    """.stripMargin
}

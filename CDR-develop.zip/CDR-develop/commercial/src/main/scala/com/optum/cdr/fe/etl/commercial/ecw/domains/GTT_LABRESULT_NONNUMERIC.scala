package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.etl.commercial.ecw_gtt_labresult_nonnumeric
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object GTT_LABRESULT_NONNUMERIC extends FEQueryAndMetadata[ecw_gtt_labresult_nonnumeric]{

  override def name: String = "GTT_LABRESULT_NONNUMERIC"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE1", "LABRESULT_CACHE2", "LABRESULT_CACHE3")

  override def sparkSql: String =
    """
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,labresultid
      |       ,localcode
      |       ,localresult
      |       ,patientid
      |       ,datecollected
      |       ,LABORDEREDDATE
      |       ,dateavailable
      |       ,encounterid
      |       ,laborderid
      |       ,locallisresource
      |       ,localname
      |       ,localtestname
      |       ,localunits
      |       ,labresult_date
      |       ,null as resulttype
      |       ,localresult_numeric
      |       ,nullif(substr(localresult,1,case WHEN instr_3params(localresult,' ',25) = 0 THEN length(localresult) else instr_3params(localresult,' ',25) end),'') AS localresult_25
      |       ,normalrange
      |FROM LABRESULT_CACHE1
      |WHERE localresult_numeric IS NULL
      |AND labresultid IS NOT NULL
      |AND LABRESULT_DATE is not null
      |AND row1 = 1
      |
      |
      |UNION ALL
      |
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,labresultid
      |       ,localcode
      |       ,localresult
      |       ,patientid
      |       ,datecollected
      |       ,null as LABORDEREDDATE
      |       ,null as dateavailable
      |       ,encounterid
      |       ,laborderid
      |       ,null as locallisresource
      |       ,localname
      |       ,localtestname
      |       ,null as localunits
      |       ,labresult_date
      |       ,null as resulttype
      |       ,localresult_numeric
      |       ,nullif(substr(localresult,1,case WHEN instr_3params(localresult,' ',25) = 0 THEN length(localresult) else instr_3params(localresult,' ',25) end),'') AS localresult_25
      |       ,null as normalrange
      |FROM LABRESULT_CACHE2
      |WHERE localresult_numeric is NULL
      |AND dedup_row = 1
      |
      |
      |UNION ALL
      |
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,labresultid
      |       ,localcode
      |       ,localresult
      |       ,patientid
      |       ,datecollected
      |       ,null as LABORDEREDDATE
      |       ,dateavailable
      |       ,encounterid
      |       ,null as laborderid
      |       ,null as locallisresource
      |       ,localname
      |       ,localtestname
      |       ,localunits
      |       ,datecollected AS labresult_date
      |       ,resulttype
      |       ,localresult_numeric
      |       ,nullif(substr(localresult,1,CASE WHEN instr_3params(localresult,' ',25) = 0 THEN length(localresult) else instr_3params(localresult,' ',25) end),'') AS localresult_25
      |       ,normalrange
      |FROM LABRESULT_CACHE3
      |WHERE localresult_numeric is null
      |AND rownumber = 1
    """.stripMargin


}

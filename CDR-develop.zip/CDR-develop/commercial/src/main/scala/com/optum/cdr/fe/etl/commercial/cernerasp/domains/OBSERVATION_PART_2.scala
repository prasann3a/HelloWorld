package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object OBSERVATION_PART_2 extends FETableInfo[observation]{

  override def name:String="OBSERVATION2"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_OBS_STATUS = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STATUS", "OBSERVATION", "OBSERVATION", "STATUS").mkString(",")

    sparkSession.sql(
      s"""
         | select groupid, datasrc, client_ds_id, localresult, localcode, obsdate, patientid, obstype, statuscode
         |from
         |(
         |select
         |	 mn.groupid
         |	,mn.datasrc
         |	,mn.client_ds_id
         |	,mn.localresult
         |	,mn.localcode
         |	,mn.obsdate
         |	,mn.patientid
         |	,z.obstype  as obstype
         |	,mn.statuscode
         |from (
         |	select 	'{groupid}' 																													as groupid
         |			,'socialhistory' 																											as datasrc
         |			,{client_ds_id} 																												as client_ds_id
         |			,nullif(substr(case when scl.hum_type = 'ASSESSMENT' then scl.assessment when scl.hum_type = 'DETAIL' then scl.text end, 1, 255), '') 	as localresult
         |			,case when scl.category is null then null else concat_ws('', '{client_ds_id}', '.shx.', scl.category) end								as localcode
         |			,scl.perform_date_time 																										as obsdate
         |			,scl.unique_person_identifier 																								as patientid
         |			,scl.status 																												as statuscode
         |	from SOCIALHISTORY scl
         |	where 	scl.status not 	in ({list_OBS_STATUS})
         |	and 	scl.hum_type 	in ('DETAIL','ASSESSMENT')
         |	and 	scl.category 	is not null
         |	and 	scl.perform_date_time 	is not null
         |	and 	scl.unique_person_identifier is not null
         |
         |) mn
         |inner join ZCM_OBSTYPE_CODE z on (z.groupid = '{groupid}' and z.datasrc =  'socialhistory' and lower(z.obscode) = lower(mn.localcode))
         |where localresult is not null
         |
 |)
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_OBS_STATUS}",list_OBS_STATUS))
  }
  override def dependsOn: Set[String] = Set("SOCIALHISTORY","MAP_PREDICATE_VALUES","ZCM_OBSTYPE_CODE")
}
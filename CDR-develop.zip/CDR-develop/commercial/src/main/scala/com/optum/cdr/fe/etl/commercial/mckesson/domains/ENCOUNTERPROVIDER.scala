package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.cdr.models.encounterprovider
import com.optum.oap.sparkdataloader.CDRFEParquetNames

object ENCOUNTERPROVIDER extends FEQueryAndMetadata[encounterprovider]{
  override def name: String = CDRFEParquetNames.encounterprovider

  override def dependsOn: Set[String] = Set("ENT_STAFF_ASSIGN","MAP_PROVIDER_ROLE","MCKESSON_ENT_PATIENT")

  override def sparkSql: String =
    """
      |select datasrc, encounterid, patientid, encountertime, providerid, providerrole, facilityid
      |from
      |(
      |SELECT 'ent_staff_assign' AS datasrc
      |,a.start_dt	    AS encountertime
      |,a.staff_seq	    AS providerid
      |,p.cpi_seq	    AS patientid
      |,a.pat_seq	    AS encounterid
      |,p.facility_id      AS facilityid
      |,NVL2(a.Care_Reln_Code,concat_ws('', {client_ds_id}, '.', a.Care_Reln_Code),NULL)   AS providerrole
      |,ROW_NUMBER() OVER (PARTITION BY a.pat_seq, a.staff_seq, a.Care_Reln_Seq
      |                    ORDER BY a.modified_dt DESC NULLS LAST) rn
      |FROM ENT_STAFF_ASSIGN a
      |     JOIN MAP_PROVIDER_ROLE mp ON (mp.groupid = '{groupid}' AND
      |                                   mp.localcode = concat_ws('', {client_ds_id}, '.', a.Care_Reln_Code))
      |     LEFT OUTER JOIN MCKESSON_ENT_PATIENT p ON (p.pat_seq = a.pat_seq)
      |WHERE p.cpi_seq IS NOT NULL
      |  AND a.start_utc IS NOT NULL
      |  AND (a.end_dt IS NULL OR a.end_dt > a.start_dt)
      |
      |)
      |where rn = 1
    """.stripMargin

}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_PART_CACHE extends FEQueryAndMetadata[labresult] {

  override def name: String = "LABRESULT_PART_CACHE"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, labresultid, localresultcode as localcode, localresult, patientid,
      |dateavailable as LABRESULT_DATE, datecollected, dateavailable, localresult_numeric, encounterid,
      | localresultname as localname, localspecimensource as LOCALSPECIMENTYPE, localunits, normalrange, resulttype, local_loinc_code
      |from
      |(
      |LABRESULT_CACHE
      |)
      |where lab_row = 1 and datasrc ='results' and localresult_numeric is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localresultcode as localcode, localresult, patientid,
      |dateavailable as LABRESULT_DATE, datecollected, dateavailable, localresult_numeric, encounterid,
      |localresultname as localname, localspecimensource as LOCALSPECIMENTYPE, localunits, normalrange, resulttype, local_loinc_code
      |from
      |(
      |LABRESULT_CACHE
      |)
      |where datasrc ='clinicaldocuments'
      |
    """.stripMargin

}


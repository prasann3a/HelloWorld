package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.{map_predicate_values, patientaddr}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENTADDRESS extends FETableInfo[patientaddr]{
  override def name: String = CDRFEParquetNames.patientaddr

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TSM020_ADDRESS","MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL","MCKESSON_PGN_V1_TSM021_ENT_ADR")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val addr_cd = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ENT_ADR","PATIENTADDR","ENT_ADR","ADR_USE_CD").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH uni_addr AS
        |(SELECT * FROM
        |(SELECT a.*, ROW_NUMBER() OVER (PARTITION BY adr_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
        |FROM MCKESSON_PGN_V1_TSM020_ADDRESS a)
        |WHERE row_sta_cd <> 'D'
        |AND rn = 1 ),
        |uni_zh AS
        |(SELECT * FROM
        |(SELECT z.*, ROW_NUMBER() OVER (PARTITION BY cod_dtl_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
        |FROM MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL z)
        |WHERE row_sta_cd <> 'D'
        |AND rn = 1 )
        |select datasrc, address_date, patientid, state, zipcode, address_line1, address_line2, city, address_type
        |from
        |(
        |SELECT 'ent_adr'         AS datasrc
        |	,ea.adr_eff_ts     as address_date
        |        ,ea.psn_int_id     as patientid
        |        ,nullif(regexp_replace(zh_state.cod_dtl_ext_id,'[^a-zA-Z]', ''), '') as state
        |        ,standardizepostalcode(uni_addr.zip_cd)                    as zipcode
        |        ,COALESCE(uni_addr.adr_str_1,concat_ws('', 'PO BOX ', uni_addr.box_no))   as address_line1
        |        ,uni_addr.adr_str_2                                        as address_line2
        |        ,uni_addr.cty_nm                                           as city
        |        ,zh_type.cod_dtl_ext_id                                    as address_type
        |from MCKESSON_PGN_V1_TSM021_ENT_ADR ea
        |inner join UNI_ADDR on (ea.adr_int_id = uni_addr.adr_int_id)
        |left outer join UNI_ZH zh_state on (uni_addr.ste_cd = zh_state.cod_dtl_int_id)
        |left outer join UNI_ZH zh_type on (ea.adr_use_cd = zh_type.cod_dtl_int_id)
        |where ea.psn_int_id is not null
        |and   ea.adr_eff_ts is not null
        |and   ea.adr_use_cd IN ({addr_cd})
        |and   (length(nullif(regexp_replace(zh_state.cod_dtl_ext_id,'[^a-zA-Z]', ''), '')) = 2 or zh_state.cod_dtl_ext_id is null)
        |and   coalesce(coalesce(uni_addr.adr_str_1,concat_ws('', 'PO BOX ', uni_addr.box_no)), uni_addr.adr_str_2, uni_addr.cty_nm, zh_state.cod_dtl_ext_id, uni_addr.zip_cd) is not null
        |
        |)
      """.stripMargin.replace("{addr_cd}",addr_cd))
  }

}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object RXORDER extends FETableInfo[rxorder] {

  override def name: String = CDRFEParquetNames.rxorder

  override def dependsOn: Set[String] = Set("CENTRICV2_PATIENTMEDICATION", "CENTRICV2_PRESCRIPTIONS",
    "CENTRICV2_ZH_MEDINFO", "CENTRICV2_DOCUMENTS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOC_XID",
      "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")

    val docXidInclusion = if (docXidInclusionMpv == "'NO_MPV_MATCHES'") "" else
      "  and doc.xid in ( " + docXidInclusionMpv.replace("'", "") + " ) "

    val erxdenial_incl = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "EXCLUSION",
      "RXORDER", "PRESCRIPTIONS", "ERXDENIALREASONCODE").mkString(",")

    sparkSession.sql(
      """
        |select distinct groupid, datasrc, client_ds_id, issuedate, ordervsprescription, patientid, rxid, altmedcode,
        |discontinuedate, discontinuereason, encounterid, localdaw, localdescription
        |  , localform, localgpi, localgenericdesc, localmedcode, localndc, localproviderid, localroute,
        |  localstrengthperdoseunit, localstrengthunit
        |, fillnum, quantityperfill, signature, venue, LOCALDOSEFREQ,
        |LOCALQTYOFDOSEUNIT, LOCALDOSEUNIT, ordertype
        |from
        |(
        |SELECT
        |'{groupid}'                                     as groupid
        |,'prescriptions'                             as datasrc
        |,{client_ds_id}                               as client_ds_id
        |,coalesce(pres.Clinicaldate ,pm.Startdate )  AS issuedate
        |,'P'                                         AS ordervsprescription
        |,pm.Pid                                      AS patientid
        |,pres.Ptid                                   AS rxid
        |, null			                     AS altmedcode
        |,case
        | when DATE_FORMAT(pm.stopdate, 'yyyy-MM-dd') = '4700-12-31' then NULL
        | when DATE_FORMAT(pm.stopdate, 'MM/dd/yyyy') = '12/31/4700' then NULL
        | else pm.stopdate
        | end                                         AS discontinuedate
        |,pm.Stopreason                               AS discontinuereason
        |,pm.Sdid                                     AS encounterid
        |,pres.Daw                                    AS localdaw
        |,pm.Description                              AS localdescription
        |,coalesce(nullif(regexp_replace(pm.dose_unit,'[{}]',''), ''),mi.doseform) AS localform
        |,coalesce( pm.Gpi,mi.Gpi)                    AS localgpi
        |,mi.Genericname                              AS localgenericdesc
        |,case when pm.Ddid = 0 then pm.Description else CAST(pm.Ddid AS STRING) end AS localmedcode
        |,nvl(nullif(concat_ws('', pm.Ndclabprod, pm.Ndcpackage), ''),mi.Ndcnum)  AS localndc
        |,pres.Pvid                                   AS localproviderid
        |,coalesce(pm.route,mi.ROUTE,
        |nullif(trim(nullif(regexp_extract(lower(mi.KEYWORD),'[^a-z](cr[eam]+|enema|inha[lation]+|inj([ection]+)?|intram[uscular]+|im|intravenous|
        |gel|film|lancets?|lot[ion]+|nasal|neb[ulizer]+|oint([tmeno]+)?|opht[halmic]+|ora[ly]+|otic|pads?|paste|patc[hes]+|shampo+|sub[lingual]+|suppo[sitory]+|spray|vaginal)+($|\\s)', 0), '')), '')) AS localroute
        |,coalesce(mi.STRENGTHONLY,nullif(regexp_extract(regexp_extract(lower(pm.DESCRIPTION),'([0-9%]+(\\/|-|,|\\.)[0-9%]+|[0-9%]+) ?([a-z]+(\\/|-)[a-z]+|[a-z%]+)', 0),
        |'([0-9%]+(\\/|-|,|\\.)[0-9%]+|[0-9%]+)', 0), '')) as localstrengthperdoseunit
        |,coalesce(mi.UNITSONLY,nullif(regexp_extract(regexp_extract(lower(pm.DESCRIPTION),'([0-9%]+(\\/|-|,|\\.)[0-9%]+|[0-9%]+) ?([a-z]+(\\/|-)[a-z]+|[a-z%]+)', 0),
        |'([a-z]+(\\/|-)[a-z]+|[a-z%]+)', 0), '')) as localstrengthunit
        |,
        |  CASE WHEN CAST(pres.Refills AS STRING) RLIKE '(?!.{5,})^(0|-*[0-9]*)$|(?!.{6,})^-([0-9]*)$'
        | THEN CAST(pres.Refills AS INT) ELSE NULL END AS fillnum
        |
        |,pres.Quantity                               AS quantityperfill
        |,pm.Instructions                             AS signature
        |,'1'                                         AS venue
        |,
        |Case
        |When pm.period <> '.00000' then (concat_ws('', pm.period, ' ', pm.period_unit))
        |else null END AS LOCALDOSEFREQ
        |,
        |Case
        |When pm.dose <> '.00000' then pm.dose
        |else null END AS LOCALQTYOFDOSEUNIT
        |,coalesce(nullif(regexp_replace(pm.dose_unit,'[{}]',''), ''),mi.doseform) AS LOCALDOSEUNIT
        |,CAST('CH002047' AS STRING)        as ordertype
        |   FROM CENTRICV2_PATIENTMEDICATION pm
        |          LEFT OUTER JOIN CENTRICV2_ZH_MEDINFO mi ON (pm.ddid = mi.ddid)
        |          INNER JOIN CENTRICV2_DOCUMENTS doc ON (doc.sdid = pm.sdid and doc.pid = pm.pid)
        |          INNER JOIN CENTRICV2_PRESCRIPTIONS pres ON (pm.MID = pres.MID and pm.pid = pres.pid)
        |           WHERE  (pm.Change IS NULL or pm.Change IN ('0','1','2'))
        |           and (pm.stopreason <> 'E' or pm.stopreason is null)
        |           AND doc.finalsign = 1
        |           AND doc.status = 'S' {dox_xid_condition}
        |           AND (pres.erxdenialreasoncode not in ({erxdenial_inclusion}) OR pres.erxdenialreasoncode is null)
        |)
    """.stripMargin
        .replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{dox_xid_condition}", docXidInclusion).
        replace("{erxdenial_inclusion}", erxdenial_incl)
    )

  }
}

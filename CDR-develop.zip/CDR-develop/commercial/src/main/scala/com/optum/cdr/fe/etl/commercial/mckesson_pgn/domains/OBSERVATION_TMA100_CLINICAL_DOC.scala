package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object OBSERVATION_TMA100_CLINICAL_DOC extends FEQueryAndMetadata[observation]{
  override def name: String = "OBSERVATION_TMA100_CLINICAL_DOC"

  override def dependsOn: Set[String] = Set("OBSERVATION_CACHE_TMA100_CLINICAL_DOC")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid
      |from
      |(
      |OBSERVATION_CACHE_TMA100_CLINICAL_DOC
      |)
      |where obstype <> 'LABRESULT' AND obsdate IS NOT NULL AND obs_rn = 1
    """.stripMargin


}

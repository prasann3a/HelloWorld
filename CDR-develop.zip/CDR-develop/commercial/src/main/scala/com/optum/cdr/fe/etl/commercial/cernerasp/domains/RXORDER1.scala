package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXORDER1 extends FETableInfo[rxorder]{
  override def name:String ="RXORDER1"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_DAW= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DAW", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DISCON_REAON= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DISCON_REAON", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_QUANTITY_FILL= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "QUANTITY_FILL", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_REFILL= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "REFILL", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_SIGNATURE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "SIGNATURE", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_STRG_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STRG_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DOSE_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DOSE_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DURATION= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DURATION", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DURATION_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DURATION_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_FREQUENCY= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "FREQUENCY", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_QTY_DOSE_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "QTY_DOSE_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_ROUTE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "ROUTE", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_STRG_DOSE_UNIT=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STRG_DOSE_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_STRG_DOSE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STRG_DOSE", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_MED_STATUS= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "MED_STATUS", "RX", "MEDICATION", "STATUS").mkString(",")
    val list_HUM_TYPE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "RX_HUM_TYPE", "RX", "ORDERS", "HUM_TYPE").mkString(",")
    val list_HUM_ACTION= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "HUM_ACTION", "RX", "MEDICATIONRECONCILIATIONDETAIL", "HUM_ACTION").mkString(",")
    val list_RX_HUM_TYPE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "RX_HUM_TYPE", "RX", "ORDERS", "HUM_TYPE").mkString(",")
    val list_ORD_STATUS= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "ORD_STATUS", "RX", "ORDERS", "STATUS").mkString(",")

    sparkSession.sql(
      """
         |with rc_cte as (select distinct description,element_code from REFERENCECODE),
         |rm_cte as (select r.unique_synonym_identifier as unique_synonym_identifier
         |,max(r.rxnorm) as rxnorm,max(nullif(replace(r.ndc, '-', ''), '') )as ndc
         |from REFERENCEMEDICATION r
         |group by r.unique_synonym_identifier)
         |select groupid, datasrc, client_ds_id, issuedate, ordervsprescription, patientid, rxid, altmedcode, encounterid, localdaw, localdosefreq, localdoseunit, localdescription, localduration, localform, localgenericdesc, localmedcode, localndc, localproviderid, localqtyofdoseunit, localroute, localstrengthperdoseunit, localstrengthunit, orderstatus, rxnorm_code, signature, venue, ordertype
         |,QUANTITYPERFILL,nvl(safe_to_number(localstrengthperdoseunit),0) * nvl(safe_to_number(localqtyofdoseunit),0) as localtotaldose
         |,CASE WHEN rlike(LOCALDOSEFREQ,'(?i)week') AND rlike(QUANTITYPERFILL,'(?i)one') THEN 7
         |WHEN rlike(LOCALDOSEFREQ,'(?i)week') THEN safe_to_number(QUANTITYPERFILL)*7
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?12|bid|twice)') AND rlike(QUANTITYPERFILL,'(?i)one') THEN 1/2
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?12|bid|twice)') THEN safe_to_number(QUANTITYPERFILL)/2
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?8|tid|three)') AND rlike(QUANTITYPERFILL,'(?i)one') THEN 1/3
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?8|tid|three)') THEN safe_to_number(QUANTITYPERFILL)/3
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?6|qid|four)') AND rlike(QUANTITYPERFILL,'(?i)one') THEN 1/4
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?6|qid|four)') THEN safe_to_number(QUANTITYPERFILL)/4
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?4|six)') THEN safe_to_number(QUANTITYPERFILL)/6
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?24|qd|daily|day|hs|bed|q[ap]m|)') AND rlike(QUANTITYPERFILL,'(?i)two') THEN 2
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?24|qd|daily|day|hs|bed|q[ap]m|)') AND rlike(QUANTITYPERFILL,'(?i)one') THEN 1
         |WHEN rlike(LOCALDOSEFREQ, '(?i)(q ?24|qd|daily|day|hs|bed|q[ap]m|)') THEN safe_to_number(QUANTITYPERFILL) ELSE NULL END as localDAYSUPPLIED
         |from
         |(
         |select
         |groupid,datasrc,client_ds_id,issuedate,ordervsprescription,patientid,rxid,altmedcode,encounterid
         |,localdaw,orderstatus,rxnorm_code,signature,venue,ordertype,localdescription,localroute,localgenericdesc,localmedcode,localndc,localproviderid
         |,max(case when lower(description) in ('frequency') then text_answer
         | when SIGNATURE is not null then trim(regexp_extract(lower(SIGNATURE),'(qd|bid|tid|qid|q[-0-9 ]+(hr?|min)|q[ap]m|q?hs|q(week|month)|bedtime|daily|(once|twice|three|four|every)((times|per|a|day|daily| )+)?)'))
         | else null end) over (partition by rxid) as localdosefreq
         |,max(case when lower(description) in ('duration unit','dispense quantity unit') then text_answer
         | when SIGNATURE is not null then regexp_replace(regexp_extract(lower(SIGNATURE),'([0-9]|one|two|three|.?half)+([^a-z0-9]+)?(cap|tab|powd|syr|aero|liq|susp|spray|drop|app|unit|puff|ea).?([a-z]+)?',0),'([0-9]|one|two|three|.?half|[^a-z0-9]+)+','')
         | else null end) over (partition by rxid) as localdoseunit
         |,case when duration is null or duration_unit is null then null else concat_ws('', duration, ' ', duration_unit) end as localduration
         |,max(case when lower(description) like '%dispense quantity unit%' then text_answer when LOCALDESCRIPTION is not null then
         | trim(regexp_extract(lower(LOCALDESCRIPTION ),' (tablet|capsule|syrup|inh[a-z]+|nasal ?|oral|extended|delayed|release|inj[ection]+|aerosol|spray|cream|solution|rectal|strips?|lancets?|kit|[ ,])+'))
         | else null end) over (partition by rxid) as localform
         |,max(case when lower(description) in ('duration','dispense quantity') then text_answer
         | when SIGNATURE is not null then regexp_extract(regexp_extract(lower(SIGNATURE),'([0-9]|one(.and.)?|two|three|.?half)+([^a-z0-9]+)?(cap|tab|powd|syr|aero|liq|susp|spray|drop|app|unit|puff|ea).?([a-z]+)?'),'([0-9]|one(.and.)?|two|three|.?half)+')
         | else null end) over (partition by rxid) as localqtyofdoseunit
         |,max(case when lower(description) in ('strength dose','volume dose') then text_answer
         | when LOCALDESCRIPTION is not null then regexp_replace(regexp_extract(lower(localdescription),'[0-9,./]+ ?(mc?g|ml|meq|(intl )?unit.?s?.?|g|each|dose|%)+([-0-9/ ]+(ml|mc?g))?',0),'[a-z% ]+','')
         | else null end) over (partition by rxid) as localstrengthperdoseunit
         |,max(case when lower(description) in ('strength dose unit','volume dose unit') then text_answer
         | when LOCALDESCRIPTION is not null then regexp_replace(regexp_extract(lower(localdescription),'[0-9,./]+ ?(mc?g|ml|meq|(intl )?unit.?s?.?|g|each|dose|%)+([-0-9/ ]+(ml|mc?g))?'),'[0-9,. ]+','')
         | else null end) over (partition by rxid) as localstrengthunit
         |,coalesce(regexp_extract(regexp_extract(lower(SIGNATURE),'([0-9]|one(.and.)?|two|three|.?half)+([^a-z0-9]+)?(cap|tab|powd|syr|aero|liq|susp|spray|drop|app|unit|puff|ea).?([a-z)]+)?',0),'([0-9]|one(.and.)?|two|three|.?half)+',0)
         |,regexp_extract(regexp_extract(lower(SIGNATURE),'([0-9]|one(.and.)?|two|three|.?half)+([^a-z0-9]+)?(cap|tab|powd|syr|aero|liq|susp|spray|drop|app|unit|puff|ea).?([a-z)]+)?',0),'([0-9]|one(.and.)?|two|three|.?half)+',0) )as QUANTITYPERFILL
         |from (
         |select
         |	'{groupid}' 							as groupid
         |	,'medicationreconciliation' 					as datasrc
         |	,{client_ds_id} 							as client_ds_id
         |	,mr.performed_date_time 					as issuedate
         |	,max(case when m.placed_order_as in ('1','5') then 'P' when m.placed_order_as = '0' then 'O' end) over (partition by mrd.record_identifier) 			as ordervsprescription
         |	,mr.unique_person_identifier 					as patientid
         |	,mrd.record_identifier 						as rxid
         |	,max(rm.ndc) over (partition by m.unique_synonym_identifier)	as altmedcode
         |	,mr.unique_visit_identifier 					as encounterid
         |	,max(case when md.detail_question in ({list_DAW}) then concat_ws('', '{client_ds_id}', '.', md.coded_answer) end) over (partition by mrd.record_identifier)		as localdaw
         |	,max(case when mr.hum_type = 3 then 'Discharge' else null end) over (partition by mrd.record_identifier) 						as localdischargemedflag
         |	,max(mrd.mnemonic) over (partition by mrd.record_identifier) 												as localdescription
         |    ,max(case when md.detail_question in ({list_DURATION}) then md.text_answer end) over (partition by mrd.record_identifier)     				as duration
         |    ,max(case when md.detail_question in ({list_DURATION_UNIT}) then md.text_answer end) over (partition by mrd.record_identifier) 				as duration_unit
         |	,max(mrd.mnemonic) over (partition by mrd.record_identifier) 												as localgenericdesc
         |	,max(case when lower(mrd.mnemonic) like '%misc%' or m.unique_synonym_identifier = '0' then
         |		nullif(substr(mrd.mnemonic,1,100), '') else coalesce(m.unique_synonym_identifier, nullif(substr(mrd.mnemonic,1,100), '')) end) over (partition by mrd.record_identifier)	as localmedcode
         |	,max(rm.ndc) over (partition by m.unique_synonym_identifier)												as localndc
         |	,mr.performed_by 																	as localproviderid
         |	,max(case when lower(rc.description) like '%route of administration%' then md.text_answer
         |   when mrd.mnemonic is not null then regexp_extract(lower(mrd.mnemonic),'(oral|topical|otic|rectal|nasal|vaginal|(inhalat|intra|subcut|transd|ophth)[a-z]+)')
         |   else null end) over (partition by mrd.record_identifier) as localroute
         |	,case when mr.status is not null then concat_ws('', '{client_ds_id}', '.', mr.status) end										as orderstatus
         |	,max(rm.rxnorm) over (partition by m.unique_synonym_identifier)  									                as rxnorm_code
         |	,max(coalesce(mrd.simplified_display,case when lower(rc.description) in ('signature','special instructions') then md.text_answer
         |   else null end)) over (partition by mrd.record_identifier) as signature
         |  ,max(case when md.detail_question in ({list_QUANTITY_FILL}) then md.text_answer end) over (partition by mrd.record_identifier) as quantityperfill
         |	,'1' 																			as venue
         |	,'CH002047' 																		as ordertype
         |  ,rc.description as description
         |  ,md.text_answer as text_answer
         |	,row_number() over (partition by mrd.record_identifier order by mrd.update_date_time desc nulls first, mrd.fileid desc nulls last)					as medreconrw
         |from MEDICATIONRECONCILIATION mr
         |left outer join MEDICATIONRECONCILIATIONDETAIL mrd
         |on 	 mr.unique_med_reconciliation_id = mrd.unique_med_reconciliation_id
         |left outer join MEDICATIONDETAILS md
         |on 	 mrd.unique_medication_identifier = md.unique_medication_identifier
         |left outer join MEDICATIONS m
         |on 	 mrd.unique_medication_identifier = m.unique_medication_identifier
         |left outer join rc_cte rc
         |on md.detail_question = rc.element_code
         |left outer join rm_cte rm
         |on m.unique_synonym_identifier = rm.unique_synonym_identifier
         |where hum_action not in ({list_HUM_ACTION})
         |and nvl(m.placed_order_as, '2') <>'2'
         |and mr.performed_date_time 			is not null
         |and m.placed_order_as	 			is not null
         |and mr.unique_person_identifier 	is not null
         |and mrd.record_identifier 			is not null
         |)
         |where medreconrw=1
         |)
         |

       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_DAW}",list_DAW)
        .replace("{list_DISCON_REAON}",list_DISCON_REAON)
        .replace("{list_QUANTITY_FILL}",list_QUANTITY_FILL)
        .replace("{list_REFILL}",list_REFILL)
        .replace("{list_SIGNATURE}",list_SIGNATURE)
        .replace("{list_STRG_UNIT}",list_STRG_UNIT)
        .replace("{list_DOSE_UNIT}",list_DOSE_UNIT)
        .replace("{list_DURATION}",list_DURATION)
        .replace("{list_DURATION_UNIT}",list_DURATION_UNIT)
        .replace("{list_FREQUENCY}",list_FREQUENCY)
        .replace("{list_QTY_DOSE_UNIT}",list_QTY_DOSE_UNIT)
        .replace("{list_ROUTE}",list_ROUTE)
        .replace("{list_STRG_DOSE}",list_STRG_DOSE)
        .replace("{list_STRG_DOSE_UNIT}",list_STRG_DOSE_UNIT)
        .replace("{list_MED_STATUS}",list_MED_STATUS)
        .replace("{list_HUM_TYPE}",list_HUM_TYPE)
        .replace("{list_HUM_ACTION}",list_HUM_ACTION)
        .replace("{list_RX_HUM_TYPE}",list_RX_HUM_TYPE)
        .replace("{list_ORD_STATUS}",list_ORD_STATUS)



    )
  }




  override def dependsOn: Set[String] = Set("MEDICATIONRECONCILIATION","MEDICATIONRECONCILIATIONDETAIL","REFERENCEMEDICATION","MEDICATIONDETAILS","MEDICATIONS","MAP_PREDICATE_VALUES","REFERENCECODE")
}

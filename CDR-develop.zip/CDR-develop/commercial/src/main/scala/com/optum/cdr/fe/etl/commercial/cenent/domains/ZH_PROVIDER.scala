package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, RuntimeVariables}


object ZH_PROVIDER extends FEQueryAndMetadata[zh_provider] {

  override def name: String = CDRFEParquetNames.zh_provider

  override def dependsOn: Set[String] = Set("ASSOCT", "ASSCNM", "ASSCID", "PROVDR")

  override def sparkSql: String =
    """
      |select groupid, client_ds_id, datasrc, localproviderid, credentials, dob, first_name, last_name, middle_name, providername, gender, npi
      |from
      |(
      |SELECT '{groupid}' as groupid,
      |'assoct' as datasrc
      |,{client_ds_id} as client_ds_id
      |,Assoct.Num  AS localproviderid
      |,Provdr.Prov_Type_Cde  AS credentials
      |,Asscnm.Birth_Dt  AS dob
      |,Asscnm.First_Nm  AS first_name
      |,Assoct.Display_Nm  AS providername
      |,Asscnm.Gender_Cde  AS gender
      |,Asscnm.Last_Nm  AS last_name
      |,Asscnm.Mid_Nm  AS middle_name
      |,CASE WHEN '{prov_exception}' = '{groupid}' and asscid.id_type_cde = 'PROVD' THEN Asscid.Id
      |      WHEN '{prov_exception}' = 'EXCEPTION' and asscid.id_type_cde = 'PROVK' then Asscid.Id else null end AS npi
      |,Asscnm.Suffix_Nm  AS suffix
      |,ROW_NUMBER() OVER (PARTITION BY Assoct.Num ORDER BY Assoct.Display_Nm) rn
      |FROM ASSOCT
      |  LEFT OUTER JOIN ASSCNM ON (assoct.num = asscnm.assoc_num)
      |  LEFT OUTER JOIN (select * from ASSCID where id_type_cde='PROVD' ) asscid ON (assoct.num = asscid.assoct_num)
      |  LEFT OUTER JOIN PROVDR ON (assoct.num = provdr.assoc_num)
      |WHERE assoct.type_cde ='P'
      |
      |)
      |where rn = 1 AND localproviderid IS NOT NULL
    """.stripMargin

  override protected def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val provException = if (loaderVars.groupId == "H984216" ) {"EXCEPTION"} else {"UNDEFINED"}

    sparkSql.replace("{groupid}", loaderVars.groupId)
      .replace("{client_ds_id}", loaderVars.clientDsId.toString)
      .replace("{prov_exception}", provException)
  }
}
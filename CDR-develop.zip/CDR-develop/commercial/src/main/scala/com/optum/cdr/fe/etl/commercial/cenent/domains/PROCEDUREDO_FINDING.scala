package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, RuntimeVariables}

//   this code is not validated after the change request made. Rally#US786987. Needs to re-validate code before  deploying the code into Prod.
object PROCEDUREDO_FINDING extends FEQueryAndMetadata[proceduredo] {

  override def name: String = "PROCEDUREDO_FINDING"

  override def dependsOn: Set[String] = Set("FINDNG", "SERVCE", "MAP_CUSTOM_PROC")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localcode, encounterid, patientid, proceduredate, localname, codetype, mappedcode, facilityid, hosp_px_flag
      |from
      |(
      |SELECT distinct '{groupid}' as groupid
      |,'findng' as datasrc
      |,{client_ds_id} as client_ds_id
      |,Findng.Concept_Descr_Num  AS localcode
      |,Findng.Pat_Person_Num  AS patientid
      |,Findng.Data_Ts  AS proceduredate
      |,Servce.Encntr_Num  AS encounterid
      |,Findng.Findng_Fac_Num  AS facilityid
      |,'Y'  AS hosp_px_flag
      |,NULL AS localname
      |,m.Mappedvalue  AS mappedcode
      |,'CUSTOM'  AS codetype
      |FROM FINDNG
      |     JOIN SERVCE ON (servce.pat_person_num = findng.pat_person_num AND
      |                                   servce.data_create_ts = findng.serv_data_create_ts)
      |
      |     JOIN MAP_CUSTOM_PROC m ON (m.groupid = '{groupid}' AND
      |			        m.datasrc = 'findng' AND
      |     				m.localcode = findng.concept_descr_num)
      |WHERE findng.finding_type_cde ='FINDNG'
      |{incl_proc_exception}
      |
      |)
      |where proceduredate IS NOT NULL AND patientid IS NOT NULL
    """.stripMargin


  override protected def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val inclProcVal = if (loaderVars.groupId == "H984216" ) {"EXCEPTION"} else {"UNDEFINED"}
    val inclProcExcp =  if (inclProcVal == "EXCEPTION")
    { " and ((txt not in ('Refused', 'Not Indctd') and concept_descr_num <>'6103790') or (concept_descr_num ='6103790' and txt like 'Foley DC%'))" }
    else { " --- "}
    sparkSql.replace("{incl_proc_exception}", inclProcExcp)
      .replace("{groupid}", loaderVars.groupId)
      .replace("{client_ds_id}", loaderVars.clientDsId.toString)
  }

}

package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object LABRESULT extends FEQueryAndMetadata[labresult] {

  override def name: String = CDRFEParquetNames.labresult

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE", "NONNUMERIC_LABRESULT")

  override def sparkSql: String =
    """
      |SELECT * FROM LABRESULT_CACHE
      |
      |UNION ALL
      |
      |SELECT * FROM NONNUMERIC_LABRESULT
    """.stripMargin
}
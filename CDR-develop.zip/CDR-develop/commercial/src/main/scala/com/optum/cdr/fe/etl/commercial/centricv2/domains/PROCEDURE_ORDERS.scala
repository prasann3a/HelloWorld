package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE_ORDERS extends FEQueryAndMetadata[proceduredo] {

  override def name: String = "PROCEDURE_ORDERS"

  override def dependsOn: Set[String] = Set("CLAIM_PROC_ORDER_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, patientid, encounterid, servicedate as proceduredate, localcode, localname, stdcodetype as codetype, standardcode as mappedcode, orderingproviderid, servicedate as actualprocdate
      |from
      |(
      |CLAIM_PROC_ORDER_CACHE
      |)
      |where patientid is not null and localcode is not null and  servicedate is not null and proc_rownumber=1
    """.stripMargin


}
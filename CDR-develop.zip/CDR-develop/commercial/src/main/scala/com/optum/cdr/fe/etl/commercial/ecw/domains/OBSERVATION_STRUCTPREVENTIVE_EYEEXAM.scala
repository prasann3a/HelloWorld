package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, observation}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_STRUCTPREVENTIVE_EYEEXAM extends FETableInfo[observation]{

  override def name: String = "OBSERVATION_STRUCTPREVENTIVE_EYEEXAM"

  override def dependsOn: Set[String] = Set("STRUCTPREVENTIVE", "ENC", "ZCM_OBSTYPE_CODE", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val listDetailId1 = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTPREVENTIVE", "OBSERVATION",
      "STRUCTPREVENTIVE_1", "DETAILID").mkString(",")

    val listDetailId2 = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTPREVENTIVE", "OBSERVATION",
      "STRUCTPREVENTIVE_2", "DETAILID").mkString(",")

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |with structprev_1 AS (
        |SELECT  *
        |FROM
        |(
        |	SELECT  s1.*
        |	       ,hum_value                                                                                                  AS hum_value_1
        |	       ,row_number() over (partition by s1.encounterid,s1.itemid,s1.detailid ORDER BY s1.hum_date desc nulls last) AS rn_1
        |	FROM STRUCTPREVENTIVE s1
        |	WHERE detailid is null or detailid IN ({list_detail_id_1})
        |)
        |WHERE rn_1 = 1 ),
        |
        |structprev_2 AS (
        |SELECT  *
        |FROM
        |(
        |	SELECT  s2.*
        |	       ,hum_value                                                                                                  AS hum_value_2
        |	       ,row_number() over (partition by s2.encounterid,s2.itemid,s2.detailid ORDER BY s2.hum_date desc nulls last) AS rn_2
        |	FROM STRUCTPREVENTIVE s2
        |	WHERE detailid is null or detailid IN ({list_detail_id_2})
        |)
        |WHERE rn_2 = 1 )
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,obsdate
        |       ,localcode
        |       ,localresult
        |       ,obstype
        |       ,null AS obsresult
        |FROM
        |(
        |	SELECT  t.*
        |	       ,zcm.obstype                                                                                                                      AS obstype
        |	       ,row_number() over (partition by t.patientid,t.encounterid,t.obsdate,t.localcode,zcm.obstype ORDER BY t.hum_date desc nulls last) AS rownumber
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                    AS groupid
        |		       ,'structpreventive_eyeexam'                     AS datasrc
        |		       ,'{client_ds_id}'                               AS client_ds_id
        |		       ,s.encounterid                                  AS encounterid
        |		       ,e.patientid                                    AS patientid
        |		       ,safe_to_date(hum_value_1,'MM/dd/yyyy')         AS obsdate
        |		       ,concat_ws('','{client_ds_id_prefix}',s.itemid) AS localcode
        |		       ,s.hum_value_2                                  AS localresult
        |		       ,s.hum_date
        |		FROM
        |		(
        |			SELECT  s1.encounterid
        |			       ,s1.itemid
        |			       ,s1.hum_value_1
        |			       ,s2.hum_value_2
        |			       ,s1.hum_date
        |			FROM STRUCTPREV_1 s1
        |			INNER JOIN STRUCTPREV_2 s2
        |			  ON (s1.itemid = s2.itemid AND s1.encounterid = s2.encounterid)
        |			WHERE s1.encounterid is not null
        |			AND s1.itemid is not null
        |		)s
        |		INNER JOIN ENC e
        |		  ON (s.encounterid = e.encounterid)
        |		WHERE e.patientid is not null
        |	) t
        |	INNER JOIN ZCM_OBSTYPE_CODE zcm
        |	  ON (zcm.groupid = '{groupid}' AND zcm.obscode = t.localcode AND zcm.datasrc = 'structpreventive_eyeexam')
        |	WHERE obsdate is not null
        |)
        |WHERE rownumber = 1
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{list_detail_id_1}", listDetailId1)
        .replace("{list_detail_id_2}", listDetailId2)
    )
  }


}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE_RESULTS extends FEQueryAndMetadata[proceduredo] {

  override def name: String = "PROCEDURE_RESULTS"

  override def dependsOn: Set[String] = Set("CLAIM_PROC_RESULT_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, encounterid, patientid, servicedate as proceduredate,
      |localcode, localname, stdcodetype as codetype, claimproviderid as Performingproviderid,
      |claimproviderid as localbillingproviderid, standardcode as mappedcode, servicedate as actualprocdate
      |from
      |(
      |CLAIM_PROC_RESULT_CACHE
      |)
      |where localcpt is not null and servicedate is not null and patientid is not null and obs_not_done = 'N' and proc_rownumber=1
    """.stripMargin


}
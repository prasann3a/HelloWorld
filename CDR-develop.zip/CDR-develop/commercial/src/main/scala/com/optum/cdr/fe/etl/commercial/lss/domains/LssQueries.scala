package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object LssQueries extends BaseQueryConfig{
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]]
      = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries
}

object InitialDependencies {
  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables) : Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    FELoadFromParquet[lss_pbraccounts](name = "LSS_PBRACCOUNTS", parquetLocation = s"$baseParquetLocation", tableName = "PBRACCOUNTS")
    , FELoadFromParquet[lss_dpbrprocedure](name = "LSS_DPBRPROCEDURE", parquetLocation = s"$baseParquetLocation", tableName = "DPBRPROCEDURE")
    , FELoadFromParquet[lss_pbraccounttransactions](name = "LSS_PBRACCOUNTTRANSACTIONS", parquetLocation = s"$baseParquetLocation", tableName = "PBRACCOUNTTRANSACTIONS")
    , FELoadFromParquet[lss_dpbrprovider](name = "LSS_DPBRPROVIDER", parquetLocation = s"$baseParquetLocation", tableName = "DPBRPROVIDER")
    , FELoadFromParquet[lss_dpbrlocation](name = "LSS_DPBRLOCATION", parquetLocation = s"$baseParquetLocation", tableName = "DPBRLOCATION")
    , FELoadFromParquet[lss_pbraccountepisodes](name = "LSS_PBRACCOUNTEPISODES", parquetLocation = s"$baseParquetLocation", tableName = "PBRACCOUNTEPISODES")
    , FELoadFromParquet[lss_pbraccounttransactiondiagnoses](name = "LSS_PBRACCOUNTTRANSACTIONDIAGNOSES", parquetLocation = s"$baseParquetLocation", tableName = "PBRACCOUNTTRANSACTIONDIAGNOSES")
    , FELoadFromParquet[lss_dpbrinsurance](name = "LSS_DPBRINSURANCE", parquetLocation = s"$baseParquetLocation", tableName = "DPBRINSURANCE")
    , FELoadFromParquet[lss_pbraccountepiinsurance](name = "LSS_PBRACCOUNTEPIINSURANCE", parquetLocation = s"$baseParquetLocation", tableName = "PBRACCOUNTEPIINSURANCE")
    , FELoadFromParquet[lss_pbraccountepiinsuranceorder](name = "LSS_PBRACCOUNTEPIINSURANCEORDER", parquetLocation = s"$baseParquetLocation", tableName = "PBRACCOUNTEPIINSURANCEORDER")
    , FELoadFromParquet[lss_pbrpatients](name = "LSS_PBRPATIENTS", parquetLocation = s"$baseParquetLocation", tableName = "PBRPATIENTS")
    , FELoadFromParquet[lss_pbraccountdemographics](name = "LSS_PBRACCOUNTDEMOGRAPHICS", parquetLocation = s"$baseParquetLocation", tableName = "PBRACCOUNTDEMOGRAPHICS")
  )
}

object QueryRegistry{
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    CLAIM
    , CLINICALENCOUNTER
    , DIAGNOSIS
    , ENCOUNTERPROVIDER
    , ZH_FACILITY
    , INSURANCE
    , TEMP_PATIENT_CACHE
    , PATIENT
    , PATIENTADDR
    , PATIENTCONTACT
    , PATIENTDETAIL
    , PATIENT_ID
    , PROCEDURE
    , ZH_PROVIDER
    , ZH_PROVIDER_CONTACT
    , ZH_PROVIDER_IDENTIFIER
    , PROV_SPEC
  )
}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object LABRESULT extends FEQueryAndMetadata[labresult] {

  override def name: String = "LABRESULT"

  override def dependsOn: Set[String] = Set("LABRESULT_PART_CACHE", "NONNUMERIC_LABRESULT")

  override def sparkSql: String =
    """
      |select *
      |from
      |(
      |LABRESULT_PART_CACHE
      |)
      |
      |UNION ALL
      |
      |select *
      |from
      |(
      |NONNUMERIC_LABRESULT
      |)
    """.stripMargin

}


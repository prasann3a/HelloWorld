package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.zh_appt_location
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_APPT_LOCATION extends FEQueryAndMetadata[zh_appt_location]{

  override def name: String = CDRFEParquetNames.zh_appt_location

  override def dependsOn: Set[String] = Set("ZH_EDI_FACILITIES")

  override def sparkSql: String =
    """
      select '{groupid}' as groupid, '{client_ds_id}' as client_ds_id, locationname, locationid
 |from
 |(
 |SELECT
 |	 zh.hum_name as locationname
 |	,zh.id as locationid
 |FROM ZH_EDI_FACILITIES zh
 |
 |)
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object MEDICATION_MAP_SRC_BILLINGDATA extends FEQueryAndMetadata[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_BILLINGDATA"

  override def dependsOn: Set[String] = Set("BILLINGDATA", "ZH_ITEMS", "ZH_ITEMDETAIL")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localmedcode, localdescription, localndc, num_recs as no_ndc, 0 as has_ndc, num_recs
      |from
      |(
      |select '{groupid}'			as groupid
      |		,'billingdata'	as datasrc
      |		,{client_ds_id}	as client_ds_id
      |		,zh.itemid		as localmedcode
      |		,zh.itemname	as localdescription
      |		,null			as localndc
      |		,count(*)		as num_recs
      |from (select * from (
      |	 select bd.*
      |			,row_number() over (partition by bd.id order by bd.modifieddate desc nulls last) as rownumber
      |	 from BILLINGDATA bd
      |	 where bd.id is not null )
      |	 where rownumber = 1) b
      |		left outer join ZH_ITEMS zh on (b.itemid = zh.itemid)
      |		left outer join ZH_ITEMDETAIL zh_id on (zh.itemid = zh_id.itemid)
      |where zh_id.propid = '13'
      |and	  zh_id.value is null
      |
      |group by zh.itemid, zh.itemname
      |)
    """.stripMargin

}

package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.patientcontact
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object PATIENTCONTACT extends FEQueryAndMetadata[patientcontact]{

  override def name: String = CDRFEParquetNames.patientcontact

  override def dependsOn: Set[String] = Set("LSS_PBRACCOUNTDEMOGRAPHICS", "LSS_PBRACCOUNTS")

  override def sparkSql: String =
    """
      |SELECT datasrc,patientid,home_phone,work_phone,update_dt
      |FROM (
      |       SELECT   x.*
      |         ,row_number() over (partition by PatientID, RowUpdateDateTime order by accountID desc nulls first ) as rownumber
      |       FROM (
      |           SELECT  'pbraccountdemographics' as datasrc
      |                   ,pbr.Rowupdatedatetime AS update_dt
      |                   ,CONCAT_WS('', pbr.Sourceid, act.Patientid) AS patientid
      |                   ,pbr.Homephone AS home_phone
      |                   ,pbr.Workphone AS work_phone
      |                   ,pbr.RowUpdateDateTime
      |                   ,pbr.accountid
      |           FROM LSS_PBRACCOUNTDEMOGRAPHICS pbr
      |           INNER JOIN LSS_PBRACCOUNTS act ON (pbr.sourceid=act.sourceid and pbr.accountid=act.accountid)
      |           WHERE NULLIF(CONCAT_WS('', Homephone, Workphone), '') is not null
      |                 AND pbr.Rowupdatedatetime is not null
      |           ) x
      |) where rownumber=1
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.encounterprovider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ENCOUNTERPROVIDER extends FEQueryAndMetadata[encounterprovider]{

  override def name: String = CDRFEParquetNames.encounterprovider

  override def dependsOn: Set[String] = Set("PROVIDER_HISTORIES_TB", "PATIENT_FAC_GRP_SEG_TB", "EVENTS_VW")

  override def sparkSql: String =

  """
    |with hist_qry as
    |(
    |    SELECT  * FROM (
    |    SELECT  z.PROVIDER_ID, z.PROV_TYPE_ID,
    |           row_number() over ( Partition by Provider_ID order by Last_Modified_Date desc nulls first, Active_Date desc nulls first, Thru_Date desc nulls first ) as hist_rownumber
    |    FROM PROVIDER_HISTORIES_TB z
    |
    |    ) WHERE hist_rownumber = 1
    |),
    |
    |pfg as (
    |    select distinct PATIENT_ID from PATIENT_FAC_GRP_SEG_TB
    |)
    |
    |select groupid, encounterid, datasrc, patientid, localproviderid as providerid, localproviderrolecode as providerrole, encountertime, client_ds_id
    |from
    |(
    |SELECT   * FROM (
    |SELECT    z.*
    |         ,row_number() over (partition by PatientID, EncounterID, LocalProviderID, LocalProviderRoleCode order by Last_Modified_Date desc nulls first, FileID desc nulls first) as rownumber
    |FROM (
    | SELECT   '{groupid}' as groupid,'events_vw' as datasrc
    |  ,{client_ds_id} as client_ds_id
    |  ,EVE.Reception_Check_In_Date_Time AS encountertime
    |  ,EVE.Provider_Id AS localproviderid
    |  ,EVE.Patient_Id AS patientid
    |  ,EVE.Event_Id AS encounterid
    |  ,concat_ws('', '{client_ds_id}', '.', '1') AS localproviderrolecode
    |  ,EVE.Last_Modified_Date, EVE.FileID
    |FROM EVENTS_VW EVE
    |INNER JOIN HIST_QRY PHT ON (EVE.PROVIDER_ID = PHT.PROVIDER_ID)
    |INNER JOIN PFG ON (EVE.PATIENT_ID = PFG.PATIENT_ID)
    |WHERE   EVE.APPT_STATUS_ID = 0
    |AND   EVE.EVENT_TYPE_ID = 1
    |AND   EVE.EVENT_STATUS_CODE = 'A'
    |AND   EVE.RECEPTION_CHECK_IN_OPERHX_ID <> 0
    |AND   EVE.Reception_Check_In_Date_Time is not null
    |AND   EVE.Provider_Id is not null
    |AND   EVE.Patient_Id is not null
    |
    |) z
    |) where rownumber=1
    |)
    |where rownumber = 1
  """
  .stripMargin

}

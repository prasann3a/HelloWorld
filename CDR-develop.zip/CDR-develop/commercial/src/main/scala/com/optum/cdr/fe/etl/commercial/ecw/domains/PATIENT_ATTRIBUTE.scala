package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.patient_attribute
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT_ATTRIBUTE extends FEQueryAndMetadata[patient_attribute]{

  override def name: String = CDRFEParquetNames.patient_attribute

  override def dependsOn: Set[String] = Set("ZH_INSURANCEDETAIL")

  override def sparkSql: String =
    """
      |SELECT  groupid
      |       ,client_ds_id
      |       ,datasrc
      |       ,patientid
      |       ,attribute_type_cui
      |       ,attribute_value
      |FROM
      |(
      |	SELECT  '{groupid}'       AS groupid
      |	       ,'Insurancedetail' AS datasrc
      |	       ,{client_ds_id}    AS client_ds_id
      |	       ,'CH002785'        AS attribute_type_cui
      |	       ,ins.Pid           AS patientid
      |	       ,ins.Subscriberno  AS attribute_value
      |	FROM
      |	(
      |		SELECT  *
      |		FROM ZH_INSURANCEDETAIL
      |		WHERE (CASE WHEN '{groupid}' = 'H772763' THEN 1 ELSE 0 END) = 1
      |	) ins
      |	WHERE DELETEFLAG='0'
      |)
    """.stripMargin
}

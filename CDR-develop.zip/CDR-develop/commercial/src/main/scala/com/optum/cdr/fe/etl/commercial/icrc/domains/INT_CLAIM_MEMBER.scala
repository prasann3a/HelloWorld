package com.optum.cdr.fe.etl.commercial.icrc.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.int_claim_member
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.sql.Timestamp
import org.apache.spark.sql.functions._

object INT_CLAIM_MEMBER extends FETableInfo[int_claim_member] {

  override def name: String = CDRFEParquetNames.int_claim_member

  override def dependsOn: Set[String] = Set("ELIGIBILITY", "MISSING_MEMBERS", "MAP_PREDICATE_VALUES","ZO_BPO_MAP_EMPLOYER")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    var eligibilityDf = loadedDependencies("ELIGIBILITY")
    // Add this column with null value if this column is not present
    // This is because the stage parquets may/may not have this column, but the query needs this
    Seq("UHC_MEMBER").foreach(col => {
      eligibilityDf = if(!eligibilityDf.columns.contains(col)) eligibilityDf.withColumn(col, lit(null)) else eligibilityDf
    })
    eligibilityDf.createOrReplaceTempView("ELIGIBILITY")

    loadedDependencies("MISSING_MEMBERS").createOrReplaceTempView("MISSING_MEMBERS")
    loadedDependencies("ZO_BPO_MAP_EMPLOYER").createOrReplaceTempView("ZO_BPO_MAP_EMPLOYER")

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val intClaimMemberMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "INT_CLAIM_MEMBER", "INT_CLAIM_MEMBER", "INT_CLAIM_MEMBER", "MEMBER").mkString(",")

    val  df = Seq(Timestamp.valueOf("1900-01-01 00:00:00")).toDF("minDate")
    val dateDf =df.withColumn("maxDate", lit(current_timestamp()))
      .withColumn("monthsDiff", months_between($"maxDate", $"minDate") - 2)
      .withColumn("repeat", expr("split(repeat(',', monthsDiff), ',')"))

    dateDf.selectExpr("*", "posexplode(repeat) as (membereffdate, val)")
      .withColumn("membereffdate", expr("add_months(minDate, membereffdate)"))
      .select($"membereffdate").withColumn("memberenddate", last_day($"membereffdate")).createOrReplaceTempView("A")

    val intClaimMemberQuery = if (intClaimMemberMpv.contains(loaderVars.groupId))
        """
          |WITH
          |Member_Months as (
          |select A.membereffdate, A.memberenddate, B.member
          |from ELIGIBILITY B
          |inner join A on date_format(A.membereffdate,'yyyyMMdd') between date_format(B.EFF_DT,'yyyyMMdd') and date_format(B.END_DT,'yyyyMMdd')),
          |
          |Missing_Member_Months as (
          |select A.membereffdate, A.memberenddate, B.Sub_Mcare_Nbr
          |from MISSING_MEMBERS B
          |inner join A on date_format(A.membereffdate,'yyyyMMdd') between date_format(B.Enr_Eff,'yyyyMMdd') and date_format(B.Enr_Exp_Date,'yyyyMMdd'))
          |
          |
          |select groupid, datasrc, client_ds_id, member_eff_date, FINANCIAL_CLASS, MEMBER_GENDER_CODE, MEDICAL_BENEFIT_FLAG, MEMBER_DOB, MEMBER_FNAME, MEMBER_ID, MEMBER_LNAME, PAYER_CODE, PAYER_NAME, PHARMACY_BENEFIT_FLAG, PLAN_CODE, PLAN_NAME, BENEFIT_PLAN_CODE, CONTRACT_TYPE_CODE, COVERAGE_CLASS_CODE, COVERAGE_STATUS_CODE, MEMBER_DEATH_IND, EMP_ACCT_ID, MEMBER_END_DATE, MEMBER_ADDR_1, MEMBER_ADDR_2, MEMBER_CITY, MEMBER_DOD, MEMBER_EMAIL, MEMBER_MNAME, MEMBER_PHONE, MEMBER_SSN, MEMBER_STATE_CODE, MEMBER_ZIP_CODE, PCP_ID, PCP_NPI, PRODUCT_CODE, PRODUCT_NAME, SUBSCRIBER_FLAG, SUBSCRIBER_ID, CONTRACT_ID, null as HICN, null as SUBSCRIBER_SSN
          |from
          |(
          |select
          |		distinct '{groupid}' 	     AS groupid
          |	,'Eligibility' 		     AS datasrc
          |	,{client_ds_id}		     AS client_ds_id
          |	,m.membereffdate	   	     AS member_eff_date
          |	,Lob_Sev_Cat      	     AS FINANCIAL_CLASS
          |	,Case
          |	When sex='0' then 'M'
          |	When sex='1' then 'F'
          |	else Null         end        AS MEMBER_GENDER_CODE
          |	,Case
          |	When med='1' then 'Y'
          |	When med='0' then 'N'
          |	else Null end 		     AS MEDICAL_BENEFIT_FLAG
          |	,Dob 			     AS MEMBER_DOB
          |	,First_Name		     AS MEMBER_FNAME
          |	,E.Member	    	     AS MEMBER_ID
          |		,Last_Name		     AS MEMBER_LNAME
          |	,b.EMPLOYERACCOUNTID	     AS PAYER_CODE
          |	,b.EMPLOYERACCOUNTID	     AS PAYER_NAME
          |	,Case
          |	When rx='1' then 'Y'
          |	When rx='0' then 'N'
          |	else Null 	end 	     AS PHARMACY_BENEFIT_FLAG
          |	,b.EMPLOYERACCOUNTID	     AS PLAN_CODE
          |	,b.EMPLOYERACCOUNTID	     AS PLAN_NAME
          |	,Benefit_Plan		     AS BENEFIT_PLAN_CODE
          |	,Contract_Type 		     AS CONTRACT_TYPE_CODE
          |	,Covclass 		     AS COVERAGE_CLASS_CODE
          |	,Coverage_Status	     AS COVERAGE_STATUS_CODE
          |	,Deceased_Ind		     AS MEMBER_DEATH_IND
          |	,Emp_Account 		     AS EMP_ACCT_ID
          |	,m.memberenddate           AS MEMBER_END_DATE
          |	,Address1 		     AS MEMBER_ADDR_1
          |	,Address2 		     AS MEMBER_ADDR_2
          |	,City 			     AS MEMBER_CITY
          |	,Dod 			     AS MEMBER_DOD
          |	,Email 			     AS MEMBER_EMAIL
          |	,Middle_Init		     AS MEMBER_MNAME
          |	,Phone	 		     AS MEMBER_PHONE
          |	,Member_Ssn		     AS MEMBER_SSN
          |	,State_N 		     AS MEMBER_STATE_CODE
          |	,Zip_N 			     AS MEMBER_ZIP_CODE
          |	,Pcp_Id 		     AS PCP_ID
          |	,Pcp_Id 		     AS PCP_NPI
          |	,Product		     AS PRODUCT_CODE
          |	,Product 	 	     AS PRODUCT_NAME
          |	,Subscriber_Flag 	     AS SUBSCRIBER_FLAG
          |	,Subscriber_Id		     AS SUBSCRIBER_ID
          |	,b.EMPLOYERACCOUNTID     As CONTRACT_ID
          |	,row_number() over(partition by E.member, membereffdate, memberenddate, pcp_id order by transact_date desc nulls last) as rnk
          |	from ELIGIBILITY E
          |	inner join MEMBER_MONTHS m on e.member=m.member
          |	cross Join ZO_BPO_MAP_EMPLOYER b ON (b.client_ds_id = {client_ds_id})
          |)
          |where rnk = 1
          |
          |union all
          |
          |select groupid, datasrc, client_ds_id, member_eff_date, null as FINANCIAL_CLASS, MEMBER_GENDER_CODE, MEDICAL_BENEFIT_FLAG, MEMBER_DOB, MEMBER_FNAME, MEMBER_ID, MEMBER_LNAME, PAYER_CODE, PAYER_NAME, null as PHARMACY_BENEFIT_FLAG, PLAN_CODE, PLAN_NAME, null as BENEFIT_PLAN_CODE, null as CONTRACT_TYPE_CODE, null as COVERAGE_CLASS_CODE, null as COVERAGE_STATUS_CODE, null as MEMBER_DEATH_IND, null as EMP_ACCT_ID, MEMBER_END_DATE, MEMBER_ADDR_1, MEMBER_ADDR_2, MEMBER_CITY, null as MEMBER_DOD, null as MEMBER_EMAIL, MEMBER_MNAME, MEMBER_PHONE, MEMBER_SSN, MEMBER_STATE_CODE, MEMBER_ZIP_CODE, PCP_ID, PCP_NPI, null as PRODUCT_CODE, null as PRODUCT_NAME, null as SUBSCRIBER_FLAG, SUBSCRIBER_ID, CONTRACT_ID, HICN, SUBSCRIBER_SSN
          |from
          |(
          |select
          |		distinct '{groupid}' 	     AS groupid
          |	,'Missing_Members' 		     AS datasrc
          |	,{client_ds_id}		     AS client_ds_id
          |	,m.membereffdate	   	     AS member_eff_date
          |	,Gender       AS MEMBER_GENDER_CODE
          |	,'Y'	     AS MEDICAL_BENEFIT_FLAG
          |	,Dob 			     AS MEMBER_DOB
          |	,F_Name		     AS MEMBER_FNAME
          |	,E.Sub_Mcare_Nbr	    	     AS MEMBER_ID
          |		,L_Name		     AS MEMBER_LNAME
          |	,b.EMPLOYERACCOUNTID	     AS PAYER_CODE
          |	,b.EMPLOYERACCOUNTID	     AS PAYER_NAME
          |	,b.EMPLOYERACCOUNTID	     AS PLAN_CODE
          |	,b.EMPLOYERACCOUNTID	     AS PLAN_NAME
          |	,m.memberenddate           AS MEMBER_END_DATE
          |	,HICN                      As HICN
          |	,Addr1 		     AS MEMBER_ADDR_1
          |	,Addr2 		     AS MEMBER_ADDR_2
          |	,City 			     AS MEMBER_CITY
          |	,M_Init		     AS MEMBER_MNAME
          |	,nullif(concat_ws('', Sub_Hm_Area_Cde, Sub_Hm_Phone_Nbr), '')	 		     AS MEMBER_PHONE
          |	,Sub_Ces_Alt_Id		     AS MEMBER_SSN
          |	,State 		     AS MEMBER_STATE_CODE
          |	,Zip			     AS MEMBER_ZIP_CODE
          |	,Npi_Nbr 		     AS PCP_ID
          |	,Npi_Nbr 		     AS PCP_NPI
          |	,E.Sub_Mcare_Nbr		     AS SUBSCRIBER_ID
          |	,E.Sub_Ces_Alt_Id            As SUBSCRIBER_SSN
          |	,b.EMPLOYERACCOUNTID     As CONTRACT_ID
          |	,row_number() over(partition by E.Sub_Mcare_Nbr, membereffdate, memberenddate, Npi_Nbr order by transact_date desc nulls last) as rnk
          |	from MISSING_MEMBERS E
          |	inner join MISSING_MEMBER_MONTHS m on e.Sub_Mcare_Nbr=m.Sub_Mcare_Nbr
          |	cross Join ZO_BPO_MAP_EMPLOYER b ON (b.client_ds_id = {client_ds_id})
          |)
          |where rnk = 1
        """.stripMargin
    else
        """
          |select groupid, datasrc, client_ds_id, member_eff_date, FINANCIAL_CLASS, MEMBER_GENDER_CODE, MEDICAL_BENEFIT_FLAG, MEMBER_DOB, MEMBER_FNAME, MEMBER_ID, MEMBER_LNAME, PAYER_CODE, PAYER_NAME, PHARMACY_BENEFIT_FLAG, PLAN_CODE, PLAN_NAME, BENEFIT_PLAN_CODE, CONTRACT_TYPE_CODE, COVERAGE_CLASS_CODE, COVERAGE_STATUS_CODE, MEMBER_DEATH_IND, EMP_ACCT_ID, MEMBER_END_DATE, MEMBER_ADDR_1, MEMBER_ADDR_2, MEMBER_CITY, MEMBER_DOD, MEMBER_EMAIL, MEMBER_MNAME, MEMBER_PHONE, MEMBER_SSN, MEMBER_STATE_CODE, MEMBER_ZIP_CODE, PCP_ID, PCP_NPI, PRODUCT_CODE, PRODUCT_NAME, SUBSCRIBER_FLAG, SUBSCRIBER_ID
          |from
          |(
          |select
          |     	distinct '{groupid}' 	     AS groupid
          |       ,'Eligibility' 		     AS datasrc
          |       ,{client_ds_id}		     AS client_ds_id
          |       ,Eff_Dt 		   	     AS member_eff_date
          |	,Lob_Sev_Cat      	     AS FINANCIAL_CLASS
          |	,Case
          | 	When sex='0' then 'M'
          |	When sex='1' then 'F'
          |	else Null         end        AS MEMBER_GENDER_CODE
          |       ,Case
          |	 When med='1' then 'Y'
          |	 When med='0' then 'N'
          |	 else Null end 		     AS MEDICAL_BENEFIT_FLAG
          |	,Dob 			     AS MEMBER_DOB
          |	,First_Name		     AS MEMBER_FNAME
          |	,Uhc_Member	    	     AS MEMBER_ID
          |        ,Last_Name		     AS MEMBER_LNAME
          |	,b.EMPLOYERACCOUNTID	     AS PAYER_CODE
          |	,b.EMPLOYERACCOUNTID	     AS PAYER_NAME
          |	,Case
          |	 When rx='1' then 'Y'
          |	 When rx='0' then 'N'
          |	 else Null 	end 	     AS PHARMACY_BENEFIT_FLAG
          |	,b.EMPLOYERACCOUNTID	     AS PLAN_CODE
          |	,b.EMPLOYERACCOUNTID	     AS PLAN_NAME
          |	,Benefit_Plan		     AS BENEFIT_PLAN_CODE
          |	,Contract_Type 		     AS CONTRACT_TYPE_CODE
          |	,Covclass 		     AS COVERAGE_CLASS_CODE
          |	,Coverage_Status	     AS COVERAGE_STATUS_CODE
          |	,Deceased_Ind		     AS MEMBER_DEATH_IND
          |	,Emp_Account 		     AS EMP_ACCT_ID
          |	,Case
          |	 When YEAR(TO_DATE(END_dt,'DD-MMM-YY')) = '9999'
          |	 then last_day(transact_date)
          |	 else End_Dt 		end  AS MEMBER_END_DATE
          |	,Address1 		     AS MEMBER_ADDR_1
          |	,Address2 		     AS MEMBER_ADDR_2
          |	,City 			     AS MEMBER_CITY
          |	,Dod 			     AS MEMBER_DOD
          |	,Email 			     AS MEMBER_EMAIL
          |	,Middle_Init		     AS MEMBER_MNAME
          |	,Phone	 		     AS MEMBER_PHONE
          |	,Member_Ssn		     AS MEMBER_SSN
          |	,State_N 		     AS MEMBER_STATE_CODE
          |	,Zip_N 			     AS MEMBER_ZIP_CODE
          |	,Pcp_Id 		     AS PCP_ID
          |	,Pcp_Id 		     AS PCP_NPI
          |	,Product		     AS PRODUCT_CODE
          |	,Product 	 	     AS PRODUCT_NAME
          |	,Subscriber_Flag 	     AS SUBSCRIBER_FLAG
          |	,Subscriber_Id		     AS SUBSCRIBER_ID
          |	,row_number() over(partition by uhc_member, eff_dt, end_dt, pcp_id order by transact_date desc nulls last) as rnk
          |	from ELIGIBILITY E
          |	cross Join ZO_BPO_MAP_EMPLOYER b ON (b.client_ds_id = {client_ds_id})
          |)
          |where rnk = 1
        """.stripMargin

    sparkSession.sql("""{intClaimMemberQuery}"""
      .replace("{intClaimMemberQuery}", intClaimMemberQuery)
      .replace("{groupid}", loaderVars.groupId)
      .replace("{client_ds_id}", clientDsId)
    )
  }
}
package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.treatment_ordered
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.sparkdataloader.CDRFEParquetNames

object TREATMENT_ORDERED extends FEQueryAndMetadata[treatment_ordered] {
  override def name: String = CDRFEParquetNames.treatment_ordered

  override def dependsOn: Set[String] = Set("MCKESSON_ENT_PATIENT","CCDBA_O_PAT","ZCM_TREATMENT_TYPE_CODE")

  override def sparkSql: String =
    """
      |WITH uni_epat AS
      | (SELECT * FROM (
      | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
      |    FROM MCKESSON_ENT_PATIENT p
      |   WHERE pat_seq IS NOT NULL )
      |) WHERE rn = 1),
      |uni_opat AS
      |(SELECT * FROM (
      |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY order_ddt DESC NULLS LAST) rn
      |      FROM CCDBA_O_PAT i
      |      WHERE pat_seq IS NOT NULL
      |        AND Order_Item_Seq IS NOT NULL
      |       )
      |WHERE rn = 1)
      |select datasrc, encounterid, patientid, order_id, order_date, localcode, cui, ordered_quantity, local_unit, std_unit_cui, NULL as normalized_quantity, order_prov_id, NULL as master_hgprovid, NULL as hgpid, NULL as grp_mpi
      |from
      |(
      |SELECT 'ccdba_o_pat' as datasrc
      |	,concat_ws('', '{client_ds_id}', '.', uni_opat.Order_Item_Seq) AS localcode
      |	,uni_opat.Order_Ddt	      AS order_date
      |	,uni_epat.cpi_seq 	      AS patientid
      |	,uni_opat.Pat_seq 	      AS encounterid
      |	,NULL 		      	      AS local_unit
      |	,uni_opat.order_seq           AS order_id
      |	,uni_opat.Ordering_Id	      AS order_prov_id
      |	,uni_opat.quantity	      AS ordered_quantity
      |	,z.treatment_type_cui         AS cui
      |	,z.treatment_type_std_units   AS std_unit_cui
      |	,ROW_NUMBER() OVER (PARTITION BY uni_epat.cpi_seq, uni_opat.Pat_seq, uni_opat.Order_Item_Seq, uni_opat.Order_Ddt
      |	                    ORDER BY uni_opat.order_ddt DESC NULLS LAST) rn
      |FROM UNI_OPAT
      |    JOIN ZCM_TREATMENT_TYPE_CODE z ON (z.groupid = '{groupid}' AND z.local_code = concat_ws('', '{client_ds_id}', '.', uni_opat.Order_Item_Seq))
      |    JOIN UNI_EPAT ON (uni_epat.pat_seq = uni_opat.pat_seq)
      |
      |)
      |where rn = 1
    """
      .stripMargin

}

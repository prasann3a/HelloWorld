package com.optum.cdr.fe.etl.commercial.cigna_cm.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_pharm
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_PHARM extends FETableInfo[int_claim_pharm]
{
  override def name: String = CDRFEParquetNames.int_claim_pharm

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString

    sparkSession.sql(
      s"""
         |select groupid, datasrc, client_ds_id, claim_id, contract_id, days_supply, member_id, metric_quantity, ndc_name, ndc, quantity_per_fill, rx_id, service_date, allowed_amount, encounterid, generic_status, localdaw, pay_process_date, pharmacy_id, pharmacy_name, presc_prov_id, presc_prov_npi, refill_num
         |from
         |(
         |SELECT  distinct
         |     '{groupid}' as groupid
         |    ,'Pharmacy' as datasrc
         |    ,{client_ds_id} as client_ds_id
         |    ,nullif(concat_ws('', indiv_entpr_id, nullif(drug_cd, '*'), upper(date_format(svc_beg_dt, 'dd-MMM-yy')), cast(float(safe_to_number(refll_num_id)) as integer), upper(date_format(pd_dt, 'dd-MMM-yy'))), '') as claim_id
         |    ,bme.employeraccountid as contract_id
         |    ,safe_to_number(phr.days_suply_qty) as days_supply
         |    ,phr.indiv_entpr_id as member_id
         |    ,safe_to_number(phr.metrc_qty) as metric_quantity
         |    ,case when coalesce(brnd_nm, label_nm) =  '*' then  null  else  coalesce(brnd_nm, label_nm) end as ndc_name
         |    ,case when drug_cd =  '*' then  null  else  drug_cd end as ndc
         |    ,safe_to_number(phr.metrc_qty) as quantity_per_fill
         |    ,nullif(concat_ws('', indiv_entpr_id, nullif(drug_cd, '*'), upper(date_format(svc_beg_dt, 'dd-MMM-yy')), cast(float(safe_to_number(refll_num_id)) as integer), upper(date_format(pd_dt, 'dd-MMM-yy'))), '') as rx_id
         |    ,coalesce(rx_wrtn_dt,svc_beg_dt) as service_date
         |    ,safe_to_number(phr.Uc_Amt) AS allowed_amount
         |    ,nullif(concat_ws('', indiv_entpr_id, nullif(drug_cd, '*'), upper(date_format(svc_beg_dt, 'dd-MMM-yy')), cast(float(safe_to_number(refll_num_id)) as integer), upper(date_format(pd_dt, 'dd-MMM-yy'))), '') as encounterid
         |    ,case when Clm_Ndc_Prodt_Cd =  '1' then  'Y'  else  'N' end AS generic_status
         |    ,phr.Dispns_As_Wrtn_Cd AS localdaw
         |    ,phr.Pd_Dt AS pay_process_date
         |    ,case when Bill_Prov_Id =  '*' then  null  else  Bill_Prov_Id end  AS pharmacy_id
         |    ,case when Bill_Prov_Nm =  '*' then  null  else  Bill_Prov_Nm end  AS pharmacy_name
         |    ,case when coalesce(ordr_prov_npi, ordr_prov_dea_num) = '*' then null
         |        else coalesce(nullif(ordr_prov_npi,'COPAY ADJ'), ordr_prov_dea_num) end as presc_prov_id
         |    ,CASE When length(Ordr_Prov_Npi)  = 10 then Ordr_Prov_Npi else null end AS presc_prov_npi
         |    ,safe_to_number(refll_num_id) AS refill_num
         |FROM CIGNA_CM_PHARMACY phr
         |CROSS JOIN ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
         |
         |)
       """.stripMargin
        .replace("{client_ds_id}",clientDsId).replace("{groupid}",groupId)

    )
  }

  override def dependsOn: Set[String] = Set("CIGNA_CM_PHARMACY","ZO_BPO_MAP_EMPLOYER")

}

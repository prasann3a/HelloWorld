package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROVIDER extends FEQueryAndMetadata[zh_provider]{

  override def name: String = CDRFEParquetNames.zh_provider

  override def dependsOn: Set[String] = Set("PROVIDER_HISTORIES_TB")

  override def sparkSql: String =

  """
    |select groupid, localproviderid, npi, fullprovidername as providername, client_ds_id, firstname as first_name, lastname as last_name, middlename as middle_name, credentials, datasrc
    |from
    |(
    |SELECT * FROM (
    |SELECT   z.*
    |         ,row_number() over (partition by localproviderid order by Last_Modified_Date desc nulls first, Active_Date desc nulls first, Thru_Date desc nulls last ) as rownumber
    |FROM (
    |SELECT '{groupid}' as groupid,'provider_histories_tb' as datasrc
    |  ,{client_ds_id} as client_ds_id
    |  ,PHT.Provider_Id AS localproviderid
    |  ,PHT.Suffix_Name AS credentials
    |  ,PHT.First_Name AS firstname
    |  ,CASE WHEN PHT.Cms_National_Prov_Id IS NULL THEN PHT.Full_Name ELSE NULL END AS fullprovidername
    |  ,PHT.Last_Name AS lastname
    |  ,PHT.Middle_Name AS middlename
    |  ,CASE WHEN PHT.Cms_National_Prov_Id=0 THEN NULL ELSE PHT.Cms_National_Prov_Id END AS npi
    |  ,PHT.Last_Modified_date, PHT.Active_Date, PHT.Thru_Date
    |FROM PROVIDER_HISTORIES_TB PHT
    |WHERE PHT.Provider_Id is not null
    |
    |) z
    |) where rownumber = 1
    |)
  """
  .stripMargin

}

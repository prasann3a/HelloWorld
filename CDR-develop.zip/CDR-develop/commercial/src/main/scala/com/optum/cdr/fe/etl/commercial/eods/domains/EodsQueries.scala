package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object EodsQueries extends  BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)

  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries
}
object InitialDependencies {
  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
     FELoadFromParquet[eods_temp_ref_term_dict_loinc](name = "REF_TERM_DICT_LOINC", parquetLocation = s"$mappingParquetPath", tableName = "REF_TERM_DICT_LOINC")
    , FELoadFromParquet[eods_medclaim](name = "MEDCLAIM", parquetLocation = s"$baseParquetLocation", tableName = "MEDCLAIM")
    , FELoadFromParquet[eods_labresults](name = "LABRESULTS", parquetLocation = s"$baseParquetLocation", tableName = "LABRESULTS")
    , FELoadFromParquet[eods_member](name = "MEMBER", parquetLocation = s"$baseParquetLocation", tableName = "MEMBER")
    , FELoadFromParquet[eods_provider](name = "PROVIDER", parquetLocation = s"$baseParquetLocation", tableName = "PROVIDER")
    , FELoadFromParquet[eods_rxclaim](name = "RXCLAIM", parquetLocation = s"$baseParquetLocation", tableName = "RXCLAIM")


  )
}

object QueryRegistry {

  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(

    INT_CLAIM_LABRESULT,
    INT_CLAIM_MEDICAL,
    INT_CLAIM_MEMBER,
    INT_CLAIM_PHARM,
    INT_CLAIM_PROV1,
    INT_CLAIM_PROV2,
    PROV_CLIENT_REL,
    ZH_FACILITY,
    ZH_PROV_ATTRIBUTE,
    ZH_PROVIDER_IDENTIFIER,
    PATIENT_ATTRIBUTE

  )
}
package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_O_PAT extends FETableInfo[rxorder]{
  override def name: String = "RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_O_PAT"

  override def dependsOn: Set[String] = Set("CCDBA_MED_ORDER" , "MCKESSON_ENT_PATIENT" , "ZH_CCDEV_DRUG" , "CCDBA_O_PAT" , "ZH_CCDEV_O_ITEM" , "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val ogrp_id = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_O_PAT", "MEDS", "CCDBA_O_PAT", "OGROUP_ID").mkString(",")
    val opat_type = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_O_PAT", "MEDS", "ENT_PATIENT", "PAT_TYPE_GROUP_LSEQ").mkString(",")


    sparkSession.sql(s"""
                        |WITH uni_opat AS
                        |(SELECT  * FROM (
                        |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY order_ddt DESC NULLS LAST) rn
                        |      FROM CCDBA_O_PAT i
                        |      WHERE Order_Seq IS NOT NULL
                        |      )
                        |WHERE rn = 1),
                        |uni_epat AS
                        |(SELECT  * FROM (
                        |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
                        |      FROM MCKESSON_ENT_PATIENT p
                        |      WHERE cpi_seq IS NOT NULL )
                        |) WHERE rn = 1),
                        |uni_drug AS
                        |(SELECT  generic_id, max(route) as route, max(dose_form) as dose_form,
                        |      max(strength) as strength, max(str_units) as str_units
                        |      FROM ZH_CCDEV_DRUG i
                        |
                        |      group by generic_id
                        |)
                        |select datasrc, issuedate, patientid, encounterid, rxid, discontinuedate, localinfusionrate, localdosefreq, localdoseunit, localform, localgenericdesc, localndc, localproviderid, ordertype, venue, localdescription, ordervsprescription, localmedcode, localroute, localstrengthperdoseunit, localstrengthunit, localtotaldose, facilityid, orderstatus, signature
                        |from
                        |(
                        |SELECT 'ccdba_o_pat'  AS datasrc
                        |    ,uni_opat.order_Ddt  AS issuedate
                        |    ,CASE WHEN uni_epat.Pat_Type_Group_Lseq IN ({opat_type}) THEN 'O' ELSE 'P' END AS ordervsprescription
                        |    ,uni_epat.cpi_seq     AS patientid
                        |    ,case when {client_ds_id} in (5464, 5726)  then (concat_ws('', uni_opat.Order_Seq, '_2')) else uni_opat.Order_Seq end   AS rxid
                        |    ,uni_opat.Pat_Seq     AS encounterid
                        |    ,uni_opat.facility_id AS facilityid
                        |    ,uni_opat.dc_ddt      AS discontinuedate
                        |    ,NULL                 AS localinfusionrate
                        |    ,NVL2(uni_opat.Frequency_Id, concat_ws('', {client_ds_id}, '.', uni_opat.Frequency_Id), NULL) AS localdosefreq
                        |    ,NULL     AS localdoseunit
                        |    ,zh.Order_Name        AS localdescription
                        |    ,uni_drug.dose_form   AS localform
                        |    ,LOWER(zh.order_name) AS localgenericdesc
                        |    ,uni_opat.Order_Item_Seq  AS localmedcode
                        |    ,NULL           AS localndc
                        |    ,NVL2(uni_drug.route,concat_ws('', {client_ds_id}, '.', uni_drug.route),NULL)     AS localroute
                        |    ,uni_drug.strength    AS localstrengthperdoseunit
                        |    ,uni_drug.str_units   AS localstrengthunit
                        |    ,NULL                 AS localproviderid
                        |    ,CASE WHEN uni_epat.Pat_Type_Group_Lseq IN ({opat_type}) THEN 'CH002045' ELSE 'CH002047' END AS ordertype
                        |    ,NULL                AS localtotaldose
                        |    ,CASE WHEN uni_epat.Pat_Type_Group_Lseq IN ({opat_type}) THEN '0' ELSE '1' END  AS venue
                        |    ,NVL2(uni_opat.Status_Desc, concat_ws('', {client_ds_id}, '.', uni_opat.Status_Desc), NULL) AS orderstatus
                        |    ,uni_opat.Order_Cmt  AS signature
                        |    ,ROW_NUMBER() OVER (PARTITION BY uni_opat.Order_Seq ORDER BY uni_opat.order_ddt DESC NULLS LAST) rn
                        |FROM UNI_OPAT
                        |   JOIN ZH_CCDEV_O_ITEM zh ON uni_opat.order_item_seq = zh.order_item_seq
                        |   JOIN UNI_EPAT ON (uni_opat.pat_seq = uni_epat.pat_seq)
                        |   LEFT OUTER JOIN UNI_DRUG ON (uni_opat.drug_code = uni_drug.generic_id)
                        |WHERE ogroup_id IN ({ogrp_id})
                        |
                        |)
                        |where rn = 1
    """.stripMargin.replace("{ogrp_id}",ogrp_id).replace("{opat_type}",opat_type).replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId))
  }
}

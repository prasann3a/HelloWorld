package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_REFERRAL extends FEQueryAndMetadata[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_REFERRAL"

  override def dependsOn: Set[String] = Set("REFERRAL", "MAP_CUSTOM_PROC")

  override def sparkSql: String =
    """
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,localcode
      |       ,patientid
      |       ,proceduredate
      |       ,localname
      |       ,referproviderid
      |       ,actualprocdate
      |       ,hosp_px_flag
      |       ,performingproviderid
      |       ,codetype
      |       ,mappedcode
      |FROM
      |(
      |	SELECT  '{groupid}'                                                                           AS groupid
      |	       ,'referral'                                                                            AS datasrc
      |	       ,{client_ds_id}                                                                        AS client_ds_id
      |	       ,r.reason                                                                              AS localcode
      |	       ,r.patientid                                                                           AS patientid
      |	       ,r.refstdate                                                                           AS proceduredate
      |	       ,r.reason                                                                              AS localname
      |	       ,nullif(r.reffrom,'0')                                                                 AS referproviderid
      |	       ,r.hum_date                                                                            AS actualprocdate
      |	       ,'N'                                                                                   AS hosp_px_flag
      |	       ,nullif(r.refto,'0')                                                                   AS performingproviderid
      |	       ,'CUSTOM'                                                                              AS codetype
      |	       ,mcp.mappedvalue                                                                       AS mappedcode
      |	       ,row_number() over (partition by r.referralid ORDER BY r.modifieddate desc nulls last) AS rownumber
      |	FROM REFERRAL r
      |	INNER JOIN MAP_CUSTOM_PROC mcp
      |	  ON (mcp.groupid = '{groupid}' AND mcp.datasrc = 'referral' AND mcp.localcode = r.reason)
      |	WHERE r.patientid is not null
      |	AND r.reason is not null
      |	AND r.refstdate is not null
      |	AND r.deleteflag <> '1'
      |)
      |WHERE rownumber = 1
    """.stripMargin


}

package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.rxadmin
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXMEDADMINISTRATIONS_TEMP_CCDBA_MED_ORDER extends FETableInfo[rxadmin]{
  override def name: String = "RXMEDADMINISTRATIONS_TEMP_CCDBA_MED_ORDER"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","CCDBA_MED_ORDER","ZH_CCDEV_DRUG","MCKESSON_ENT_PATIENT","CCDBA_MED_ADMIN","ZH_DRUG1_FDB_PACKAGEDDRUG")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val excl_id = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_MED_ORDER", "MEDS", "CCDBA_MED_ORDER", "DRUG_ID").mkString(",")


    sparkSession.sql(
      s"""
         |WITH uni_order AS
         |(SELECT * FROM (
         |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY chart_ddt DESC NULLS LAST) rn
         |      FROM CCDBA_MED_ORDER i
         |       )
         |WHERE rn = 1),
         |uni_drug AS
         |(SELECT * FROM (
         |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY drug_id ORDER BY change_dt DESC NULLS LAST) rn
         |      FROM ZH_CCDEV_DRUG i
         |       )
         |WHERE rn = 1),
         |uni_pat AS
         |(SELECT * FROM (
         |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |      FROM MCKESSON_ENT_PATIENT p
         |      WHERE cpi_seq IS NOT NULL )
         |) WHERE rn = 1)
         |select datasrc, localmedcode, patientid, administrationtime, encounterid, localroute, rxorderid, localdrugdescription, localstrengthunit, localtotaldose, localproviderid, localinfusionrate, localinfusionvolume, localdoseunit, localform, localgenericdesc, localndc, localqtyofdoseunit, localstrengthperdoseunit, qtydispensed, rxadministrationid
         |from
         |(
         |SELECT 'ccdba_med_admin' AS datasrc
         |	,CASE WHEN admin.Drug_id IN ({excl_id}) THEN LOWER(uni_order.drug_name) ELSE admin.drug_id END  AS localmedcode
         |	,uni_pat.Cpi_Seq   AS patientid
         |	,admin.pat_seq     AS encounterid
         |	,NVL2(admin.Route,concat_ws('', {client_ds_id}, '.', admin.route),NULL) AS localroute
         |	,case when {client_ds_id} in (5464, 5726)  then (concat_ws('', admin.Order_Seq, '_1')) else admin.Order_Seq   end    AS rxorderid
         |	,uni_order.Infus_Rate AS localinfusionrate
         |	,admin.Total_Volume AS localinfusionvolume
         |	,admin.Qty_Units    AS localdoseunit
         |	,CASE WHEN admin.Drug_id IN ({excl_id}) THEN LOWER(uni_order.drug_name) ELSE LOWER(COALESCE(uni_drug.sec_name, uni_order.drug_name)) END AS localdrugdescription
         |	,admin.Qty_Units  AS localform
         |	,CASE WHEN admin.Drug_id IN ({excl_id}) THEN NULL ELSE LOWER(uni_drug.primary_name) END AS localgenericdesc
         |	,CASE WHEN admin.Drug_id IN ({excl_id}) THEN NULL ELSE zh.Pmid END  AS localndc
         |	,admin.Admin_Qty  AS localqtyofdoseunit
         |	,coalesce(admin.dose_qty,nullif(regexp_extract(admin.dose,'^[-0-9.]+', 0), '')) 	  AS localstrengthperdoseunit
         |	,admin.Dose_Units AS localstrengthunit
         |	,admin.Dose_Qty   AS localtotaldose
         |	,admin.Admin_Qty  AS qtydispensed
         |	,admin.Admin_Seq  AS rxadministrationid
         |	,NULL             AS localproviderid
         |	,CASE WHEN date_format(admin.perform_ddt,'yyyy') = '1800' THEN NULL ELSE admin.perform_ddt END AS administrationtime
         |        ,ROW_NUMBER() OVER (PARTITION BY admin.Admin_Seq ORDER BY admin.verify_ddt DESC NULLS LAST) rn
         |FROM CCDBA_MED_ADMIN admin
         |   JOIN UNI_PAT ON (admin.pat_seq = uni_pat.pat_seq)
         |   LEFT OUTER JOIN UNI_DRUG ON (admin.drug_id = uni_drug.drug_id)
         |   LEFT OUTER JOIN UNI_ORDER ON (admin.order_seq = uni_order.order_seq AND admin.drug_id = uni_order.drug_id)
         |   LEFT OUTER JOIN ZH_DRUG1_FDB_PACKAGEDDRUG zh ON (uni_order.drug_id = zh.pmid)
         |WHERE (admin.dose_units <> 'INFO' OR admin.dose_units IS NULL)
         |
         |)
         |where rn = 1
       """.stripMargin.replace("{excl_id}",excl_id).replace("{client_ds_id}",clientDsId).replace("{client_ds_id}",clientDsId)
    )
  }
}

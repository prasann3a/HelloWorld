package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.rx_patient_reported
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object RX_PAT_REP extends FEQueryAndMetadata[rx_patient_reported]{

  override def name: String = CDRFEParquetNames.rx_patient_reported

  override def dependsOn: Set[String] = Set("RX_PAT_REP_CACHE_MEDICATIONS", "RX_PAT_REP_CACHE_MEDICATIONRECONCILIATION")

  override def sparkSql: String =
    """
      |select * from RX_PAT_REP_CACHE_MEDICATIONS
      |union
      |select * from RX_PAT_REP_CACHE_MEDICATIONRECONCILIATION
    """.stripMargin
}
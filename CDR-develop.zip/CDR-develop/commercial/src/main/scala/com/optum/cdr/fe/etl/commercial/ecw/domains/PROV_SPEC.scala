package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.prov_spec
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROV_SPEC extends FEQueryAndMetadata[prov_spec]{

  override def name: String = CDRFEParquetNames.prov_spec

  override def dependsOn: Set[String] = Set("DOCTORS")

  override def sparkSql: String =
    """
      |SELECT  '{groupid}'    AS groupid
      |       ,{client_ds_id} AS client_ds_id
      |       ,doctorid       AS localproviderid
      |       ,speciality     AS localspecialtycode
      |       ,localcodesource
      |FROM
      |(
      |	SELECT  doctorid
      |	       ,speciality
      |	       ,'Doctors' AS localcodesource
      |	       ,ROW_NUMBER() OVER (PARTITION BY doctorid ORDER BY modifieddate DESC NULLS LAST) rn
      |	FROM DOCTORS
      |)
      |WHERE rn = 1
      |AND speciality is not null
    """.stripMargin
}

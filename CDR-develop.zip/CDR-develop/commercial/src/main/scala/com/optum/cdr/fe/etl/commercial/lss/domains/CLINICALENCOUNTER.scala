package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.clinicalencounter
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object CLINICALENCOUNTER extends FEQueryAndMetadata[clinicalencounter] {

  override def name: String = CDRFEParquetNames.clinicalencounter

  override def dependsOn: Set[String] = Set("LSS_PBRACCOUNTEPISODES", "LSS_PBRACCOUNTS", "LSS_PBRACCOUNTTRANSACTIONS", "LSS_DPBRLOCATION")

  override def sparkSql: String =
    """
      |WITH act_qry as (
      |     SELECT * FROM (
      |       SELECT z.*
      |        ,ROW_NUMBER () OVER ( PARTITION BY sourceid, accountid ORDER BY rowupdatedatetime DESC, patientid DESC nulls last) AS act_rownumber
      |       FROM LSS_PBRACCOUNTS z
      |      )WHERE act_rownumber = 1
      |)
      |
      |SELECT datasrc,encounterid,facilityid,patientid,arrivaltime
      |FROM (
      | SELECT  x.*
      |        ,ROW_NUMBER() OVER (PARTITION BY encounterid ORDER BY rowupdatedatetime DESC nulls last) AS rownumber
      | FROM (
      |   SELECT
      |     'pbraccountepisodes' AS datasrc
      |     ,SAFE_TO_DATE(e.begindatetime, 'yyyy-MM-dd') AS arrivaltime
      |     ,NULLIF(CONCAT_WS('', pbr.sourceid, pbr.accountid, e.episeqid), '') AS encounterid
      |     ,NULLIF(CONCAT_WS('', pbr.sourceid, pbr.patientid), '') AS patientid
      |     ,NULLIF(CONCAT_WS('', pbr.sourceid, t.locationid), '') AS facilityid
      |     ,e.rowupdatedatetime
      |   FROM LSS_PBRACCOUNTEPISODES e
      |   INNER JOIN LSS_PBRACCOUNTS pbr ON ( e.sourceid=pbr.sourceid AND e.accountid=pbr.accountid )
      |   INNER JOIN (
      |         SELECT DISTINCT x.sourceid
      |           , x.accountid
      |           , x.episeqid
      |           , x.locationid
      |           , y.stdplaceofservice
      |         FROM LSS_PBRACCOUNTTRANSACTIONS x
      |         JOIN LSS_DPBRLOCATION y ON x.locationid = y.locationid
      |         WHERE episeqid IS NOT NULL
      |    ) t
      |    ON ( t.sourceid=e.sourceid AND t.accountid=e.accountid AND t.episeqid =e.episeqid )
      |    WHERE NULLIF(CONCAT_WS('', pbr.sourceid, pbr.accountid, e.episeqid), '') IS NOT NULL
      |    AND NULLIF(CONCAT_WS('', pbr.sourceid, pbr.patientid), '')	 IS NOT NULL
      |    AND e.begindatetime IS NOT NULL
      | ) x
      |) WHERE rownumber = 1
      |
      |UNION ALL
      |
      |SELECT datasrc,encounterid,facilityid,patientid,arrivaltime
      |FROM (
      |   SELECT   x.*
      |    ,ROW_NUMBER() OVER (PARTITION BY encounterid ORDER BY rowupdatedatetime DESC nulls last) AS rownumber
      |   FROM (
      |     SELECT
      |       'pbraccounttransactions' AS datasrc
      |       ,pbr.servicedatetime as arrivaltime
      |       ,NULLIF(CONCAT_WS('', pbr.sourceid, act.accountid, pbr.locationid, upper(date_format(pbr.servicedatetime, 'dd-MMM-yy'))), '') AS encounterid
      |       ,NULLIF(CONCAT_WS('', pbr.sourceid, act.patientid), '') AS patientid
      |       ,NULLIF(CONCAT_WS('', dpb.sourceid, pbr.locationid), '') AS facilityid
      |       ,pbr.rowupdatedatetime
      |     FROM LSS_PBRACCOUNTTRANSACTIONS pbr
      |     INNER JOIN act_qry act ON ( pbr.sourceid = act.sourceid AND pbr.accountid = act.accountid)
      |     INNER JOIN LSS_DPBRLOCATION dpb ON ( dpb.sourceid = pbr.sourceid AND dpb.locationid = pbr.locationid)
      |     WHERE pbr.type = 'C'
      |       AND pbr.servicedatetime is not null
      |       AND NULLIF(CONCAT_WS('', pbr.sourceid, act.accountid, pbr.locationid, pbr.servicedatetime), '') IS NOT NULl
      |       AND NULLIF(CONCAT_WS('', pbr.sourceid, act.patientid), '') IS NOT NULL
      |   ) x
      |) WHERE rownumber = 1 AND patientid IS NOT NULL
    """.stripMargin
}

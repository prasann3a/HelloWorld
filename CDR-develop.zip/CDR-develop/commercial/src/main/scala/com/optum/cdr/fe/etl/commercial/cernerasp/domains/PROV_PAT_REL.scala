package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.prov_pat_rel
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.cdr.fe.utils.Functions.mpvList


object PROV_PAT_REL extends FETableInfo[prov_pat_rel]{

  override def name:String=CDRFEParquetNames.prov_pat_rel

  override def dependsOn: Set[String] = Set("RELATION","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    //dummy
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_pcp = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"PCP","PROV_PAT_REL","RELATION",	"ENTITY_RELATIONSHIP_TO_SUBJECT").mkString(",")


    sparkSession.sql(
      """select groupid, client_ds_id, datasrc, localrelshipcode, providerid, patientid, startdate,enddate
        |from
        |(
        |select '{groupid}'	as groupid
        |	,'{cdsid}'	as client_ds_id
        |	,'relation'	as datasrc
        |	,'PCP'	as localrelshipcode
        |	,r.unique_related_entity_id	as providerid
        |	,r.unique_subject_identifier	as patientid
        |	,r.effective_begin_date_time	as startdate
        |	,case when r.effective_end_date_time = to_date('2100-12-31 00:00:00','yyyy-MM-dd HH_mm_ss') then null
        |		else r.effective_end_date_time end as enddate
        |	,row_number() over (partition by r.unique_subject_identifier,r.unique_related_entity_id,r.effective_begin_date_time order by r.update_date_time desc nulls last)	as rownumber
        |from RELATION r
        |where r.unique_subject_identifier is not null
        |and r.unique_related_entity_id is not null
        |and r.effective_begin_date_time is not null
        |and r.active <> '0'
        |and r.entity_relationship_to_subject in ({list_pcp})
        |
        |)
      """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{cdsid}",clientDsId)
        .replace("{list_pcp}",list_pcp)
    )

  }

}
package com.optum.cdr.fe.etl.commercial.cigna_cm.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}


object CignaCmQueries extends BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)

  override def queryRegistry = QueryRegistry.queries

}

object InitialDependencies {

  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      FELoadFromParquet[cigna_cm_medical](name = "CIGNA_CM_MEDICAL", parquetLocation = s"$baseParquetLocation", tableName = "MEDICAL", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[cigna_cm_demo_supplemental](name = "CIGNA_CM_DEMO_SUPPLEMENTAL", parquetLocation = s"$baseParquetLocation", tableName = "DEMO_SUPPLEMENTAL")
    , FELoadFromParquet[cigna_cm_eligibility](name = "CIGNA_CM_ELIGIBILITY", parquetLocation = s"$baseParquetLocation", tableName = "ELIGIBILITY")
    , FELoadFromParquet[cigna_cm_pharmacy](name = "CIGNA_CM_PHARMACY", parquetLocation = s"$baseParquetLocation", tableName = "PHARMACY")
    , FELoadFromParquet[zo_bpo_map_employer](name = "ZO_BPO_MAP_EMPLOYER", parquetLocation = s"$mappingParquetPath", tableName = "ZO_BPO_MAP_EMPLOYER")
  )
}

object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    INT_CLAIM_PHARM
    , INT_CLAIM_MEDICAL
    , INT_CLAIM_MEMBER
  )
}

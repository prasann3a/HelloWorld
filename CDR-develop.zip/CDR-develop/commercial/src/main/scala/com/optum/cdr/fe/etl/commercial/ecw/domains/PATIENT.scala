package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT extends FEQueryAndMetadata[patient]{

  override def name: String = CDRFEParquetNames.patient

  override def dependsOn: Set[String] = Set("ECW_USERS_CACHE", "ECW_PATS_CACHE")

  override def sparkSql: String =
    """
      |SELECT  groupid
      |       ,client_ds_id
      |       ,datasrc
      |       ,patientid
      |       ,dob AS dateofbirth
      |       ,dateofdeath
      |       ,mrn AS medicalrecordnumber
      |       ,inactive_flag
      |FROM
      |(
      |	SELECT  u.*
      |	       ,dateofdeath
      |	FROM
      |	(
      |		SELECT  '{groupid}'                                                                                       AS groupid
      |		       ,{client_ds_id}                                                                                    AS client_ds_id
      |		       ,'patient'                                                                                         AS datasrc
      |		       ,p.hum_uid                                                                                         AS patientid
      |		       ,null                                                                                              AS mrn
      |		       ,first_value(p.dob) over (partition by p.hum_uid ORDER BY nvl2(p.dob,0,1),p.mdate desc nulls last) AS dob
      |		       ,row_number() over (partition by p.hum_uid ORDER BY p.mdate desc nulls last)                       AS rownbr
      |		       ,CASE WHEN last_status = '1' THEN 'Y'
      |		             WHEN last_status = '0' THEN 'N' ELSE NULL END                                                AS inactive_flag
      |		FROM ECW_USERS_CACHE p
      |	) u
      |	INNER JOIN
      |	(
      |		SELECT  pid
      |		       ,coalesce(safe_to_date_length(tp.Deceaseddate,'MM/dd/yy',0),safe_to_date_length(tp.Deceaseddate,'MM/dd/yyyy',0)
      |                   ,safe_to_date_length(tp.Deceaseddate,'yyyy/MM/dd',0),safe_to_date_length(tp.Deceaseddate,'MMddyyyy',0)) as dateofdeath
      |		       ,row_number() over (partition by pid ORDER BY modifieddate desc nulls last) AS patsrow
      |		FROM ECW_PATS_CACHE tp
      |	) pat
      |	ON (pat.pid = u.patientid AND pat.patsrow = 1)
      |	WHERE rownbr = 1
      |)
    """.stripMargin
}

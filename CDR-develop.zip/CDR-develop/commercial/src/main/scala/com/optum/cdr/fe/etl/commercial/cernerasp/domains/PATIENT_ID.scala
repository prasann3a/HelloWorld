package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.{patient_id, patientdetail}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENT_ID extends FETableInfo[patient_id]{

  override def name:String=CDRFEParquetNames.patient_id

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }
    sparkSession.sql(
      s"""
         |select groupid, client_ds_id, datasrc, patientid, 'SSN' as idtype, ssn as idvalue, id_subtype
         |from
         |(
         |TEMP_PATIENT_ID_CACHE
         |)
         |where ssn_row = 1 and  validate_ssn(ssn) = 'Y' and active_id_flag = '1'
         |
         |union all
         |
         |select groupid, client_ds_id, datasrc, patientid, 'MRN' as idtype, mrn as idvalue, id_subtype
         |from
         |(
         |TEMP_PATIENT_ID_CACHE
         |)
         |where cmrn_row=1 and  mrn is not null and active_id_flag = '1'
       """.stripMargin)

  }

  override def dependsOn: Set[String] = Set("TEMP_PATIENT_ID_CACHE")
}
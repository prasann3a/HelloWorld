package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.cdr.fe.etl.commercial.med3000_patientcache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PATIENT_CACHE extends FEQueryAndMetadata[med3000_patientcache]{

  override def name: String = "TEMP_PATIENT_CACHE"

  override def dependsOn: Set[String] = Set("MED3000_MPI","MED3000_MPI_XREF")

  override def sparkSql: String =
    """
      with MPIXREF as
 |(
 |Select  distinct Blind_Key from MED3000_MPI_XREF
 |)
 |
 |select a.*
 |       ,row_number() over (partition by patientid order by lastupdateddate desc nulls last,medicalrecordnumber desc nulls last ) as rank_pat
 |	   ,first_value(dateofbirth) over (partition by patientid      order by nvl2(dateofbirth,1,0) desc nulls first, lastupdateddate desc nulls last) as dob
 |       ,row_number() over (partition by patientid, upper(firstname) order by lastupdateddate desc nulls last)  as firstname_row
 |	   ,row_number() over (partition by patientid, upper(lastname)  order by lastupdateddate desc nulls last)  as lastname_row
 |	   ,row_number() over (partition by patientid, upper(middlename)order by lastupdateddate desc nulls last)  as middle_row
 |       ,row_number() over (partition by patientid, upper(gender)    order by lastupdateddate desc nulls last)  as gender_row
 |	   ,row_number() over (partition by patientid, upper(maritalstatus)   order by lastupdateddate desc nulls last) as marital_row
 |	   ,row_number() OVER (partition by patientid, upper(race)      order by lastupdateddate desc nulls last ) as race_row
 |	   ,row_number() OVER (partition by patientid, upper(ethnicity) order by lastupdateddate desc nulls last ) as ethnic_row
 |       ,row_number() OVER (partition by patientid, upper(language)  order by lastupdateddate desc nulls last ) as language_row
 |	   ,row_number() over (partition by patientid, upper(city)      order by lastupdateddate desc nulls last)  as city_row
 |       ,row_number() over (partition by patientid, upper(state)     order by lastupdateddate desc nulls last)  as state_row
 |       ,row_number() over (partition by patientid, zipcode          order by lastupdateddate desc nulls last)  as zipcode_row
 |	     ,row_number() over (partition by patientid,deathindicator    order by lastupdateddate desc  nulls last)  as deathindicator_row
 |      ,row_number() over (partition by patientid,cell_phone,home_phone,work_phone,personal_email order by lastupdateddate desc nulls last ) as rank_con
 |from (
 |select
 |       'MPI' 	        	as datasrc
 |       ,Mpi.Blind_Key  		as patientid
 |       ,to_timestamp(Mpi.Dob,'yyyy-MM-dd') 	as dateofbirth
 |       ,null                as medicalrecordnumber
 |       ,Mpi.Death_Date  	as dateofdeath
 |       ,Mpi.Death_Ind     as deathindicator
 |       ,Mpi.Ethnicity_Id  	as ethnicity
 |       ,Mpi.Fname  			as firstname
 |       ,Mpi.Sex  			as gender
 |       ,Mpi.Language_Id 	as language
 |       ,Mpi.Lname  			as lastname
 |       ,Mpi.Marital_Status  as maritalstatus
 |       ,Mpi.Mname  			as middlename
 |       ,Mpi.Race_Id  		as race
 |	   ,Mpi.Cell_Phone      as cell_phone
 |       ,Mpi.Phone1          as home_phone
 |       ,Mpi.Email           as personal_email
 |       ,Mpi.Phone2          as work_phone
 |	   ,Mpi.City 			as city
 |       ,upper(nullif(regexp_replace(Mpi.Hum_State,'[^a-zA-Z]', ''), '')) as state
 |       ,case when length(nullif(regexp_replace(Mpi.Zip,'[^a-zA-Z]', ''), '')) is null and length(Mpi.Zip) in (5,9,10) then
 |              Mpi.Zip else null end as zipcode
 |	   ,Mpi.Update_Date    as lastupdateddate
 |  from MED3000_MPI MPI
 | inner join MPIXREF mxm on (mpi.Blind_Key = mxm.Blind_Key))a
    """.stripMargin



}

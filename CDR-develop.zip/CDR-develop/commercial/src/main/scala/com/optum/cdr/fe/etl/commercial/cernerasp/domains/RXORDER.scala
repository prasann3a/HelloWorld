package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object RXORDER extends FETableInfo[rxorder]{

  override def name:String = CDRFEParquetNames.rxorder

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select * from RXORDER1
         |
         |union all
         |
         |select * from RXORDER2
         |
         |union all
         |
         |select * from RXORDER3
       """.stripMargin)
  }

  override def dependsOn: Set[String] = Set("RXORDER1","RXORDER2","RXORDER3")
}

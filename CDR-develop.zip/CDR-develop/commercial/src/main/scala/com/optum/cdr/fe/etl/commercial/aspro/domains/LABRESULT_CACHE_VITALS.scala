package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.aspro_labresult_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE_VITALS extends FEQueryAndMetadata[aspro_labresult_cache]{

  override def name: String = "LABRESULT_CACHE_VITALS"

  override def dependsOn: Set[String] = Set("VITALS")

  override def sparkSql: String =
    """
      |select 	distinct
      |        '{groupid}' 										as groupid,
      |				'vitals' 										as datasrc
      |       	,v.imreenc_code 						as encounterid
      |       	,v.imredem_code 						as patientid
      |       	,v.vital_datetime 					as datecollected
      |        ,v.vital_datetime 					  as dateavailable
      |        ,v.vital_pulse_ox           as vital_pulse_ox
      |        ,safe_to_number(v.vital_pulse_ox) as pulse_ox_numeric
      |        ,concat_ws('', v.vitals_code, 'v')							as labresultid
      |from VITALS v
      |where v.imredem_code is not null
      |      and v.vital_datetime >= to_date('20050101','yyyyMMdd')
    """.stripMargin
}

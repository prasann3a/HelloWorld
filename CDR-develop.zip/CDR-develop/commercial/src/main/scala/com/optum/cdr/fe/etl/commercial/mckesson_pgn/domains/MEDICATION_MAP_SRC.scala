package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.cdr.fe.utils.verify.MedicationMapSrcVerify
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC extends FETableInfo[medication_map_src]{

  override def name: String = CDRFEParquetNames.medication_map_src

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TSM255_PERSON_ALLERGY", "MCKESSON_PGN_V1_TPP350_IMMUNIZATION_HX", "MCKESSON_PGN_V1_TSM261_PSN_HOME_MEDS", "MCKESSON_PGN_V1_TRX101_THERAPY_ITEM", "MCKESSON_PGN_V1_TCP540_RX_ADS_INFO", "MCKESSON_PGN_V1_TCP500_RX_ADS","MCKESSON_PGN_V1_ZH_TRX800_ITEM_INVENTORY","MCKESSON_PGN_V1_ZH_TRX870_NDC")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val list_sta_tsn_cd = mpvList(mapPredicateValues, groupId, clientDsId, "IMMUNIZATION_EXC", "IMMUNIZATION", "IMMUNIZATION_HX", "STA_RSN_CD").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val medicationMapSrcDf = sparkSession.sql(
      """               select groupid, datasrc, client_ds_id, localmedcode, localdescription, no_ndc, has_ndc, num_recs, localndc, localgeneric, rxnorm_code, cast(null as String) as ndc_src
            from
            (
            SELECT '{groupid}' AS groupid
              ,'person_allergy'	AS datasrc
              ,{client_ds_id}	AS client_ds_id
              ,pa.alg_desc     	AS localmedcode
              ,upper(pa.alg_desc)	AS localdescription
              ,count(*)	AS no_ndc
              ,0	AS has_ndc
              ,count(*)	AS num_recs
              ,null as localndc
              ,null as localgeneric
              ,null as rxnorm_code
            FROM MCKESSON_PGN_V1_TSM255_PERSON_ALLERGY pa
            GROUP BY pa.allergy_int_id,pa.alg_desc
            )

            union all

            select groupid, datasrc, client_ds_id, localmedcode, localdescription, no_ndc, has_ndc, num_recs, localndc, localgeneric, rxnorm_code, cast(null as String) as ndc_src
            from
            (
            SELECT '{groupid}' AS groupid
              ,'immunization_hx'	AS datasrc
              ,{client_ds_id}	AS client_ds_id
              ,upper(i.imm_nm)	AS localmedcode
              ,upper(i.imm_nm)	AS localdescription
              ,count(*)	AS no_ndc
              ,0	AS has_ndc
              ,count(*)	AS num_recs
              ,null as localndc
              ,null as localgeneric
              ,null as rxnorm_code
            FROM MCKESSON_PGN_V1_TPP350_IMMUNIZATION_HX i
            WHERE i.row_sta_cd <> 'D'
            AND (i.sta_rsn_cd not in ({list_sta_tsn_cd}) or sta_rsn_cd is null)
            AND (i.cvx_con_set_int_id is not null or i.imm_ads_dt is not null or i.imm_ads_fmt_nm is not null)
            GROUP BY i.imm_nm
            )

            union all

            select groupid, datasrc, client_ds_id, localmedcode, localdescription, no_ndc, has_ndc, num_recs, localndc, localgeneric, rxnorm_code, cast(null as String) as ndc_src
            from
            (
            SELECT '{groupid}' AS groupid
              ,'psn_home_meds'	AS datasrc
              ,{client_ds_id}	AS client_ds_id
              ,upper(ph.med_freeform)	AS localmedcode
              ,upper(ph.med_freeform)	AS localdescription
              ,count(*)	AS no_ndc
              ,0	AS has_ndc
              ,count(*)	AS num_recs
              ,null as localndc
              ,null as localgeneric
              ,null as rxnorm_code
            FROM MCKESSON_PGN_V1_TSM261_PSN_HOME_MEDS ph
            GROUP BY ph.med_freeform
            )

            union all

            select groupid, datasrc, client_ds_id, localmedcode, localdescription, no_ndc, has_ndc, num_recs, localndc, localgeneric, rxnorm_code, cast(null as String) as ndc_src
            from
            (
            SELECT groupid,datasrc,client_ds_id,localmedcode,localdescription,localgeneric
                ,ndc	AS localndc
                ,sum(case when ndc is null then 1 else 0 end) as no_ndc
                ,sum(case when ndc is null then 0 else 1 end) as has_ndc
                ,count(*) as num_recs
              ,null as rxnorm_code

            from
            (
            select * from
            (
            select t.*,
            stack(2,pri_ndc_id,'PRI_NDC_ID',ndc_id,'NDC_ID') as (ndc, ndc_data)
            from
            (
            SELECT '{groupid}' AS groupid
              ,'therapy_order'	AS datasrc
              ,{client_ds_id}	AS client_ds_id
              ,case when t.bnd_nm is not null then trim(t.bnd_nm||': '||t.dug_ds) else t.dug_ds end	AS localmedcode
              ,t.pri_ndc_id
              ,zh.ndc_id
              ,case when t.bnd_nm is not null then trim(t.bnd_nm||': '||t.dug_ds) else t.dug_ds end	AS localdescription
              ,t.dug_ds	AS localgeneric
            FROM MCKESSON_PGN_V1_TRX101_THERAPY_ITEM t
              left outer join MCKESSON_PGN_V1_ZH_TRX870_NDC zh on (t.itm_id = zh.itm_id)
              ) t
            )
            )
            GROUP BY groupid,datasrc,client_ds_id,localmedcode,ndc,localdescription,localgeneric
            )

            union all

         select groupid, datasrc, client_ds_id, localmedcode, localdescription, no_ndc, has_ndc, num_recs, localndc, localgeneric, rxnorm_code, cast(null as String) as ndc_src
            from
            (
                SELECT '{groupid}' AS groupid
                  ,'rx_ads'	AS datasrc
                  ,{client_ds_id}	AS client_ds_id
                  ,coalesce(ri.brd_ds,ri.med_ds)	AS localmedcode
                  ,rx.localndc	as localndc
                  ,coalesce(ri.brd_ds,ri.med_ds)	AS localdescription
                  ,ri.med_ds	AS localgeneric
                  ,rx.rxnorm_code	as rxnorm_code
                  ,sum(case when localndc is null then 1 else 0 end) as no_ndc
                  ,sum(case when localndc is null then 0 else 1 end) as has_ndc
                  ,count(*) as num_recs
                FROM MCKESSON_PGN_V1_TCP540_RX_ADS_INFO ri
                  left outer join
                    (select ads_inf_int_id
                             ,ndc	as localndc
                             ,rxnormcd	as rxnorm_code
                         from
                      (
                        select *
                        ,stack(3,ndc_cd,'NDC_CD',ndc_cd_adm,'NDC_CD_ADM',ndc_cd_ord,'NDC_CD_ORD') as (ndc, ndc_data)
                        from(
                            select *
                            ,stack(2,rx_nor_cd_adm,'RX_NOR_CD_ADM',rx_nor_cd_ord,'RX_NOR_CD_ORD') as (rxnormcd, rxnorm_data)
                            from(
                                select ads_inf_int_id
                                  ,ndc_cd
                                  ,ndc_cd_adm
                                  ,ndc_cd_ord
                                  ,rx_nor_cd_adm
                                  ,rx_nor_cd_ord
                                  from
                                  MCKESSON_PGN_V1_TCP500_RX_ADS
                                )
                             )
                      )
                     where rxnormcd is not null
                  ) rx on (ri.ads_inf_int_id = rx.ads_inf_int_id)
                GROUP BY coalesce(ri.brd_ds,ri.med_ds),rx.localndc,ri.med_ds,rx.rxnorm_code
            )

            union all

            select groupid, datasrc, client_ds_id, localmedcode, localdescription, no_ndc, has_ndc, num_recs, localndc, localgeneric, rxnorm_code, cast(null as String) as ndc_src
            from
            (
            SELECT distinct '{groupid}'	as groupid
              ,'ord_dtl'	as datasrc
              ,{client_ds_id}	as client_ds_id
              ,i.itm_id	as localmedcode
              ,n.ndc_id	as localndc
              ,i.gic_nm	as localdescription
              ,i.gic_nm	as localgeneric
                    ,sum(case when n.ndc_id is null then 1 else 0 end) as no_ndc
              ,sum(case when n.ndc_id is null then 0 else 1 end) as has_ndc
                  ,count(*) as num_recs
              ,null as rxnorm_code
            FROM MCKESSON_PGN_V1_ZH_TRX800_ITEM_INVENTORY i
            left outer join MCKESSON_PGN_V1_ZH_TRX870_NDC n on (i.itm_id = n.itm_id)
            where i.itm_id is not null
            and n.row_sta_cd not in ('D','O')
            group by i.itm_id, n.ndc_id, i.gic_nm
            )
            """.replace("{groupid}", groupId)
      .replace("{client_ds_id}", clientDsId)
      .replace("{list_sta_tsn_cd}", list_sta_tsn_cd))

    MedicationMapSrcVerify.run(medicationMapSrcDf)

  }
}



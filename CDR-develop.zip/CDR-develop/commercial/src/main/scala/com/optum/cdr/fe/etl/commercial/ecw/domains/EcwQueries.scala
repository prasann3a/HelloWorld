package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.oap.cdr.models.{map_predicate_values, zcm_obstype_code}
import com.optum.cdr.fe.utils.nonnumeric_labs_localresult_25.NONNUMERIC_LABRESULT
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object EcwQueries extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries
}

object EcwQueriesWithDrugAssign extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries ++ QueryRegistry.drug_assign_queries
}

object InitialDependencies {
  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    // stage tables
    FELoadFromParquet[users](name = "USERS", parquetLocation = s"$baseParquetLocation", tableName = "USERS")
    , FELoadFromParquet[patients](name = "PATIENTS", parquetLocation = s"$baseParquetLocation", tableName = "PATIENTS")
    , FELoadFromParquet[zh_insurancedetail](name = "ZH_INSURANCEDETAIL", parquetLocation = s"$baseParquetLocation", tableName = "ZH_INSURANCEDETAIL")
    , FELoadFromParquet[zh_insurance](name = "ZH_INSURANCE", parquetLocation = s"$baseParquetLocation", tableName = "ZH_INSURANCE")
    , FELoadFromParquet[enc](name = "ENC", parquetLocation = s"$baseParquetLocation", tableName = "ENC")
    , FELoadFromParquet[edi_invoice](name = "EDI_INVOICE", parquetLocation = s"$baseParquetLocation", tableName = "EDI_INVOICE")
    , FELoadFromParquet[flowsheetdata](name = "FLOWSHEETDATA", parquetLocation = s"$baseParquetLocation", tableName = "FLOWSHEETDATA")
    , FELoadFromParquet[social](name = "SOCIAL", parquetLocation = s"$baseParquetLocation", tableName = "SOCIAL")
    , FELoadFromParquet[hpi](name = "HPI", parquetLocation = s"$baseParquetLocation", tableName = "HPI")
    , FELoadFromParquet[structhpi](name = "STRUCTHPI", parquetLocation = s"$baseParquetLocation", tableName = "STRUCTHPI")
    , FELoadFromParquet[structpreventive](name = "STRUCTPREVENTIVE", parquetLocation = s"$baseParquetLocation", tableName = "STRUCTPREVENTIVE")
    , FELoadFromParquet[structsocialhistory](name = "STRUCTSOCIALHISTORY", parquetLocation = s"$baseParquetLocation", tableName = "STRUCTSOCIALHISTORY")
    , FELoadFromParquet[structexam](name = "STRUCTEXAM", parquetLocation = s"$baseParquetLocation", tableName = "STRUCTEXAM")
    , FELoadFromParquet[zh_properties](name = "ZH_PROPERTIES", parquetLocation = s"$baseParquetLocation", tableName = "ZH_PROPERTIES")
    , FELoadFromParquet[vitals](name = "VITALS", parquetLocation = s"$baseParquetLocation", tableName = "VITALS")
    , FELoadFromParquet[doctors](name = "DOCTORS", parquetLocation = s"$baseParquetLocation", tableName = "DOCTORS")
    , FELoadFromParquet[immunizations](name = "IMMUNIZATIONS", parquetLocation = s"$baseParquetLocation", tableName = "IMMUNIZATIONS")
    , FELoadFromParquet[zh_items](name = "ZH_ITEMS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_ITEMS")
    , FELoadFromParquet[input_allergies](name = "INPUT_ALLERGIES", parquetLocation = s"$baseParquetLocation", tableName = "ALLERGIES")
    , FELoadFromParquet[zh_edi_facilities](name = "ZH_EDI_FACILITIES", parquetLocation = s"$baseParquetLocation", tableName = "ZH_EDI_FACILITIES")
    , FELoadFromParquet[zh_pcphistory](name = "ZH_PCPHISTORY", parquetLocation = s"$baseParquetLocation", tableName = "ZH_PCPHISTORY")
    , FELoadFromParquet[zh_flowsheetitems](name = "ZH_FLOWSHEETITEMS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_FLOWSHEETITEMS")
    , FELoadFromParquet[physicalexam](name = "PHYSICALEXAM", parquetLocation = s"$baseParquetLocation", tableName = "PHYSICALEXAM")
    , FELoadFromParquet[referral](name = "REFERRAL", parquetLocation = s"$baseParquetLocation", tableName = "REFERRAL")
    , FELoadFromParquet[zh_visitcodes](name = "ZH_VISITCODES", parquetLocation = s"$baseParquetLocation", tableName = "ZH_VISITCODES")
    , FELoadFromParquet[labdata](name = "LABDATA", parquetLocation = s"$baseParquetLocation", tableName = "LABDATA")
    , FELoadFromParquet[billingdata](name = "BILLINGDATA", parquetLocation = s"$baseParquetLocation", tableName = "BILLINGDATA")
    , FELoadFromParquet[zh_itemdetail](name = "ZH_ITEMDETAIL", parquetLocation = s"$baseParquetLocation", tableName = "ZH_ITEMDETAIL")
    , FELoadFromParquet[edi_inv_cpt](name = "EDI_INV_CPT", parquetLocation = s"$baseParquetLocation", tableName = "EDI_INV_CPT")
    , FELoadFromParquet[zh_facilityidtype](name = "ZH_FACILITYIDTYPE", parquetLocation = s"$baseParquetLocation", tableName = "ZH_FACILITYIDTYPE")
    , FELoadFromParquet[zh_labdatadetailrefrange](name = "ZH_LABDATADETAILREFRANGE", parquetLocation = s"$baseParquetLocation", tableName = "ZH_LABDATADETAILREFRANGE")
    , FELoadFromParquet[zh_vitaltypes](name = "ZH_VITALTYPES", parquetLocation = s"$baseParquetLocation", tableName = "ZH_VITALTYPES")
    , FELoadFromParquet[hl7labdatadetail](name = "HL7LABDATADETAIL", parquetLocation = s"$baseParquetLocation", tableName = "HL7LABDATADETAIL")
    , FELoadFromParquet[zh_lablist](name = "ZH_LABLIST", parquetLocation = s"$baseParquetLocation", tableName = "ZH_LABLIST")
    , FELoadFromParquet[labdatadetail](name = "LABDATADETAIL", parquetLocation = s"$baseParquetLocation", tableName = "LABDATADETAIL")
    , FELoadFromParquet[electroniclabresults](name = "ELECTRONICLABRESULTS", parquetLocation = s"$baseParquetLocation", tableName = "ELECTRONICLABRESULTS")
    , FELoadFromParquet[oldrxmain](name = "OLDRXMAIN", parquetLocation = s"$baseParquetLocation", tableName = "OLDRXMAIN")
    , FELoadFromParquet[oldrxdetail](name = "OLDRXDETAIL", parquetLocation = s"$baseParquetLocation", tableName = "OLDRXDETAIL")
    , FELoadFromParquet[zh_drugref](name = "ZH_DRUGREF", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DRUGREF")
    , FELoadFromParquet[input_diagnosis](name = "INPUT_DIAGNOSIS", parquetLocation = s"$baseParquetLocation", tableName = "DIAGNOSIS")
    , FELoadFromParquet[edi_inv_diagnosis](name = "EDI_INV_DIAGNOSIS", parquetLocation = s"$baseParquetLocation", tableName = "EDI_INV_DIAGNOSIS")
    , FELoadFromParquet[problemlist](name = "PROBLEMLIST", parquetLocation = s"$baseParquetLocation", tableName = "PROBLEMLIST")

    // CDR tables
    , FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PREDICATE_VALUES")
    , FELoadFromParquet[zcm_obstype_code](name = "ZCM_OBSTYPE_CODE", parquetLocation = s"$mappingParquetPath", tableName = "ZCM_OBSTYPE_CODE")
    , FELoadFromParquet[map_custom_proc](name = "MAP_CUSTOM_PROC", parquetLocation = s"$mappingParquetPath", tableName = "MAP_CUSTOM_PROC")
    , FELoadFromParquet[map_unit](name = "MAP_UNIT", parquetLocation = s"$mappingParquetPath", tableName = "MAP_UNIT")
    , FELoadFromParquet[unit_remap](name = "UNIT_REMAP", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_REMAP")
    , FELoadFromParquet[metadata_lab](name = "METADATA_LAB", parquetLocation = s"$mappingParquetPath", tableName = "METADATA_LAB")
    , FELoadFromParquet[unit_conversion](name = "UNIT_CONVERSION", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_CONVERSION")
  )
}

object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    ECW_USERS_CACHE
    , ECW_PATS_CACHE
    , PATIENT
    , PATIENT_ID
    , PATIENTDETAIL
    , CLINICALENCOUNTER
    , INSURANCE
    , PATIENT_ATTRIBUTE
    , PATIENTADDR
    , PATIENTCONTACT
    , OBSERVATION_FLOWSHEETDATA
    , OBSERVATION_SOCIAL
    , OBSERVATION_HPI
    , OBSERVATION_STRUCTHPI
    , OBSERVATION_STRUCTPREVENTIVE
    , OBSERVATION_STRUCTSOCIALHISTORY
    , OBSERVATION_STRUCTPREVENTIVE_EYEEXAM
    , OBSERVATION_STRUCTEXAM
    , OBSERVATION_VITALS
    , OBSERVATION
    , PROVIDER_CONTACT
    , RXADMIN
    , PROV_SPEC
    , ZH_PROVIDER
    , ZH_PROVIDER_IDENTIFIER
    , IMMUNIZATION
    , ALLERGY
    , ENCOUNTER_REASON
    , APPOINTMENT
    , ZH_APPT_LOCATION
    , GTT_PROV_PAT_REL_ZH_PCP
    , GTT_PROV_PAT_REL_PATIENTS
    , PROV_PAT_REL_ZH_PCP
    , PROV_PAT_REL_PATIENTS
    , PROV_PAT_REL
    , PROCEDURE_CACHE_BILLINGDATA
    , PROCEDURE_CACHE_EDI_INV_CPT
    , PROCEDURE_CACHE_FLOWSHEETDATA
    , PROCEDURE_CACHE_LABDATA
    , PROCEDURE_CACHE_HPI
    , PROCEDURE_CACHE_STRUCTHPI
    , PROCEDURE_CACHE_BILLINGDATA_CUSTOM
    , PROCEDURE_CACHE_PHYSICALEXAM
    , PROCEDURE_CACHE_STRUCTEXAM
    , PROCEDURE_CACHE_STRUCTPREVENTIVE
    , PROCEDURE_CACHE_REFERRAL
    , PROCEDURE_CACHE_ENC
    , PROCEDURE
    , LABORDER
    , CLAIM
    , ZH_FACILITY
    , ZH_LAB_DICT
    , LABRESULT_CACHE1
    , LABRESULT_CACHE2
    , LABRESULT_CACHE3
    , GTT_LABRESULT_NONNUMERIC
    , LABRESULT_WITHOUT_NONNUMERIC
    , NONNUMERIC_LABRESULT
    , LABRESULT_FINAL
    , RXORDER_CACHE
    , PATIENTREPORTEDMEDS
    , RXORDERSANDPRESCRIPTIONS
    , DIAGNOSIS
    , ENCOUNTERPROVIDER
    , MBORDERS
    , MBRESULTS
  )

  val drug_assign_queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      MEDICATION_MAP_SRC
    , MEDICATION_MAP_SRC_ALLERGIES
    , MEDICATION_MAP_SRC_BILLINGDATA
    , MEDICATION_MAP_SRC_IMMUNIZATIONS
    , MEDICATION_MAP_SRC_OLDRXMAIN
  )

}

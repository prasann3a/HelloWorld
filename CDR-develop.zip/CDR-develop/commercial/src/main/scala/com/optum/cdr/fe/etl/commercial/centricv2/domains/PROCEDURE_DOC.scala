package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.sql.SaveMode


object PROCEDURE_DOC extends FEQueryAndMetadata[proceduredo] {

  override def name: String = "PROCEDURE"

  override def tableOrder: Int = 2

  override def saveMode: SaveMode = SaveMode.Append

  override def dependsOn: Set[String] = Set("CLAIM_PROC_DOC_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, encounterid, patientid, servicedate as proceduredate,
      |localcode, localname, stdcodetype as codetype, claimproviderid as Performingproviderid,
      |claimproviderid as localbillingproviderid, standardcode as mappedcode, servicedate as actualprocdate
      |from
      |(
      |CLAIM_PROC_DOC_CACHE
      |)
      |where localcpt is not null and servicedate is not null and patientid is not null and obs_not_done = 'N' and proc_rownumber=1
    """.stripMargin


}
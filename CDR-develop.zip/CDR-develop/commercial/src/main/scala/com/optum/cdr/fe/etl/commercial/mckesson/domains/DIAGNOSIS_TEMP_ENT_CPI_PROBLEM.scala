package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.diagnosis
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object DIAGNOSIS_TEMP_ENT_CPI_PROBLEM extends FETableInfo[diagnosis]{
  override def name: String = "DIAGNOSIS_TEMP_ENT_CPI_PROBLEM"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","REF_SNOMED_ICD9","REF_SNOMED_ICD10","ENT_CPI_PROBLEM","MCKESSON_ZH_ENT_CONFIG_CODE_SET")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val excl_status = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DIAGNOSIS_EXC", "DIAGNOSIS", "ENT_CPI_PROBLEM", "PROBLEM_STATUS_LSEQ").mkString(",")
    val incl_type = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DIAGNOSIS_INC", "DIAGNOSIS", "ENT_CPI_PROBLEM", "PROBLEM_TYPE_LSEQ").mkString(",")
    val excl_desc = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DIAGNOSIS_EXC", "DIAGNOSIS", "ENT_CPI_PROBLEM", "PROBLEM_DESCRIPTION").mkString(",")

    sparkSession.sql(
      s"""
         |WITH uni_problem AS
         |(SELECT * FROM (
         |   (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY cpi_problem_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |      FROM ENT_CPI_PROBLEM p
         |     WHERE cpi_seq IS NOT NULL
         |       AND Created_Dt IS NOT NULL
         |       AND clinical_problem_fl = 'Y'
         |       AND (problem_status_lseq IS NULL OR problem_status_lseq NOT IN ({excl_status}))
         |       AND (problem_type_lseq IS NULL OR problem_type_lseq IN ({incl_type}))
         |       AND (problem_description IS NULL OR problem_description NOT IN ({excl_desc}))
         | 	))
         | WHERE rn = 1)
         |select datasrc, patientid, encounterid, dx_timestamp, localdiagnosis, primarydiagnosis, mappeddiagnosis, codetype, facilityid, hosp_dx_flag, localdiagnosisstatus, localdiagnosisstatus as localactiveind, resolutiondate
         |from
         |(
         |SELECT pp.* from
         |(
         |select * from
         |(
         |select unpivot_base.*,
         |stack(3,Zh_Code_Value,'SNOMED',icd9_code,'ICD9',icd10_code,'ICD10') as (mappeddiagnosis, codetype)
         |from
         |(
         |SELECT  'ent_cpi_problem' AS datasrc
         |	,uni_problem.Created_Dt AS dx_timestamp
         |	,COALESCE(uni_problem.internal_code, uni_problem.problem_description)  AS localdiagnosis
         |	,uni_problem.cpi_seq  	AS patientid
         |	,NVL2(uni_problem.Problem_Status_Lseq, concat_ws('', {client_ds_id}, '.', uni_problem.Problem_Status_Lseq), NULL) AS localdiagnosisstatus
         |	,uni_problem.pat_seq  	AS encounterid
         |	,NULL  		AS facilityid
         |	,NULL  		AS primarydiagnosis
         |	,NULL		AS hosp_dx_flag
         |	,uni_problem.Inactive_Dt    AS resolutiondate
         |	,Zh.Code_Value  AS Zh_Code_Value
         |	,icd9.icd9cm_code AS icd9_code
         |	,icd10.icd10_code AS icd10_code
         |        ,ROW_NUMBER() OVER (PARTITION BY uni_problem.cpi_seq, uni_problem.Created_Dt, uni_problem.pat_seq, COALESCE(uni_problem.internal_code, uni_problem.problem_description)
         |                            ORDER BY uni_problem.modified_dt DESC NULLS LAST) AS rn
         |FROM UNI_PROBLEM
         |   LEFT OUTER JOIN MCKESSON_ZH_ENT_CONFIG_CODE_SET zh ON uni_Problem.internal_code = Zh.internal_code
         |   LEFT OUTER JOIN REF_SNOMED_ICD9 icd9 ON (zh.code_value = icd9.snomed_id AND uni_problem.created_dt < TO_DATE('10/01/2015', 'MM/dd/yyyy'))
         |   LEFT OUTER JOIN REF_SNOMED_ICD10 icd10 ON (zh.code_value = icd10.snomed_id AND uni_problem.created_dt >= TO_DATE('10/01/2015', 'MM/dd/yyyy'))
         | ) unpivot_base
         |)
         |where mappeddiagnosis is not null
         |) pp
         |)
         |where rn = 1
       """.stripMargin.replace("{excl_status}",excl_status).replace("{incl_type}",incl_type).replace("{excl_desc}",excl_desc).replace("{client_ds_id}",clientDsId))

  }
}

package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object TEMP_CLINICALENCOUNTER_CACHE extends FETableInfo[cliniccache]{


  override def name:String="CLINICALCACHE"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    val list_alt_enc_id = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"ALT_ENC_ID","CLINICALENCOUNTER","IDENTIFIERS","IDENTIFIER_TYPE").mkString(",")


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }


    sparkSession.sql(
      s"""
         |select '{groupid}'	as groupid
         |	,{client_ds_id}	as client_ds_id
         |	,'visit'	as datasrc
         |	,v.location_code	as facilityid
         |	,v.unique_person_identifier	as patientid
         |	,v.unique_visit_identifier	as encounterid
         |	,v.registration_date_time	as arrivaltime
         |	,v.registration_date_time	as admittime
         |	,v.discharge_date_time	as dischargetime
         |	,nvl2(v.hum_type,concat_ws('', {client_ds_id}, '.', v.hum_type),null)	as localpatienttype
         |	,i.identifier		as alt_encounterid
         |	,r.unique_related_entity_id	as providerid
         |	,r.relationship_type	as providerrole
         |	,v.registration_date_time	as encountertime
         |	,v.hum_type
         |	,row_number() over (partition by v.unique_visit_identifier order by v.update_date_time desc nulls last)	as ce_rownumber
         |	,row_number() over (partition by r.unique_related_entity_id,v.unique_person_identifier,v.unique_visit_identifier,r.relationship_type order by r.update_date_time desc nulls last)	as ep_rownumber
         |from VISIT v
         |	left outer join IDENTIFIERS i on (v.unique_visit_identifier=i.entity_identifier
         |		and i.entity_type = 'VISIT'
         |		and i.identifier_type in ({list_alt_enc_id}))
         |	left outer join RELATION r on (v.unique_visit_identifier = r.unique_subject_identifier
         |		and r.subject_type = 'VISIT'
         |		and r.related_entity_type = 'PERSONNEL')
         |where v.unique_person_identifier is not null
         |and v.registration_date_time is not null
         |and v.active <> '0'
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_alt_enc_id}",list_alt_enc_id)

    )

  }

  override def dependsOn: Set[String] = Set("VISIT","IDENTIFIERS","RELATION","MAP_PREDICATE_VALUES")

}
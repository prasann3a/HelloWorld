package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.encounterprovider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}
import org.apache.spark.storage.StorageLevel

object ENCOUNTERPROVIDER1 extends FEQueryAndMetadata[encounterprovider] {

  override def name: String = "ENCOUNTERPROVIDER1"

  override def dependsOn: Set[String] = Set("ENCOUNTERS", "ZH_PROVIDERS")

  override def sparkSql: String =
    """
      |SELECT
      |  datasrc
      | ,encounterid
      | ,patientid
      | ,encountertime
      | ,facilityid
      |	,providerid
      |	,providerrole
      | FROM (
      |SELECT DISTINCT 'encounters'    AS datasrc
      | ,Enc_Chartpulltime  AS encountertime
      |	,Imredemec_Code  AS patientid
      |	,Imreenc_Code  AS encounterid
      |	,Location_Id   AS facilityid
      | ,STACK(2, 'visit provider',Imreprov_Code, 'billing provider', Enc_Billingprov_Code) AS (providerrole, providerid)
      |FROM ENCOUNTERS
      |) enc
      |INNER JOIN ZH_PROVIDERS zh
      |ON (zh.imreprov_code = enc.providerid)
      |WHERE patientid IS NOT NULL AND encountertime IS NOT NULL
    """.stripMargin
}

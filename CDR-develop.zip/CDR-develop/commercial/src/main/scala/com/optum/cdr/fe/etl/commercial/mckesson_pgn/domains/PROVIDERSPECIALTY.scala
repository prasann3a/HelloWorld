package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.prov_spec

object PROVIDERSPECIALTY extends FEQueryAndMetadata[prov_spec]{
  override def name: String = CDRFEParquetNames.prov_spec

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM100_CARE_GIVER")

  override def sparkSql: String =
    """
      |select '{groupid}' as groupid, {client_ds_id} as client_ds_id, localproviderid, localspecialtycode, localcodesource
      |from
      |(
      |SELECT  Car_Gvr_Int_Id	AS localproviderid
      |       ,NVL2(car_gvr_role_cd,concat_ws('', '{client_ds_id}', '.', car_gvr_role_cd, '-', car_gvr_srv_cd),NULL) AS localspecialtycode,
      |        'zh_provider'   AS localcodesource,
      |        ROW_NUMBER() OVER (PARTITION BY Car_Gvr_Int_Id ORDER BY Car_Gvr_Int_Id DESC NULLS LAST, fileid DESC nulls first) rn
      |FROM MCKESSON_PGN_V1_TPM100_CARE_GIVER
      |WHERE Car_Gvr_Int_Id IS NOT NULL
      |
      |)
      |where localspecialtycode IS NOT NULL AND rn = 1
    """.stripMargin
}

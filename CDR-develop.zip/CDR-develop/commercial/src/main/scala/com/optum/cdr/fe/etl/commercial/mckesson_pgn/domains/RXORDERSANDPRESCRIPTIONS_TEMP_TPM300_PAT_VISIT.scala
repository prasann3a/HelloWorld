package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.cdr.models.rxorder
import org.apache.spark.storage.StorageLevel

object RXORDERSANDPRESCRIPTIONS_TEMP_TPM300_PAT_VISIT extends FEQueryAndMetadata[rxorder]{
  override def name: String = "RXORDERSANDPRESCRIPTIONS_TEMP_TPM300_PAT_VISIT"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_TRX101_THERAPY_ITEM","MCKESSON_PGN_V1_TRX100_THERAPY_ORDER")

  override def sparkSql: String =
    """
      |WITH uni_visit AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC nulls first) rn
      |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
      |  WHERE Psn_Int_Id IS NOT NULL
      |    AND Vst_Int_Id IS NOT NULL )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'),
      |uni_item AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY prx_itm_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC nulls first) rn
      |   FROM MCKESSON_PGN_V1_TRX101_THERAPY_ITEM v
      |  WHERE Prx_Itm_Int_Id IS NOT NULL
      |    AND prx_int_id IS NOT NULL )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D')
      |select datasrc, issuedate, patientid, encounterid, rxid, discontinuedate, localinfusionrate, localdosefreq, localdoseunit, localform, localgenericdesc, localndc, localproviderid, ordertype, venue, localdescription, ordervsprescription, localmedcode, localroute, localstrengthperdoseunit, localstrengthunit, localtotaldose, facilityid, orderstatus, localdaw, expiredate, quantityperfill
      |from
      |(
      |SELECT 'therapy_order' AS datasrc
      |    ,todr.Cre_Ts     AS issuedate
      |    ,'O'             AS ordervsprescription
      |    ,uni_visit.Psn_Int_Id AS patientid
      |    ,concat_ws('', uni_item.Prx_Int_Id, '_', uni_item.Prx_Itm_Int_Id)  AS rxid
      |    ,uni_visit.Vst_Int_Id AS encounterid
      |    ,NULL                 AS facilityid
      |    ,todr.Stp_Dtm_Ts      AS discontinuedate
      |    ,NULL                 AS localinfusionrate
      |    ,uni_Item.Cpt_Frq_Rat_Ds AS localdosefreq
      |    ,uni_item.Cpt_Fom_Ds  AS localdoseunit
      |    ,case when uni_item.bnd_nm is not null then trim(uni_item.bnd_nm||': '||uni_item.dug_ds) else uni_item.dug_ds end  AS localdescription
      |    ,uni_item.Cpt_Fom_Ds  AS localform
      |    ,uni_item.Dug_Ds      AS localgenericdesc
      |    ,case when uni_item.bnd_nm is not null then trim(uni_item.bnd_nm||': '||uni_item.dug_ds) else uni_item.dug_ds end  AS localmedcode
      |    ,uni_item.Pri_Ndc_Id  AS localndc
      |,coalesce(nullif(trim(nullif(regexp_extract(lower(uni_item.Dug_Ds),'(aero(sol)?|cream|ear|enema|eye|gel|hfa|inh|inj([ection]+)?|[^a-z]iv[^a-z]|nasal|oph?th|op?tic|oint|oral|pa?tch|sub(q|cut|ling)|suppository|topical)+', 0), '')), '')
      |,nullif(trim(nullif(regexp_extract(lower(uni_item.cpt_fom_ds),'(aero(sol)?|by mouth|cream|enema|gel|hfa|inh|inj([ection]+)?|irrigation|nebulizer|oint|oral|parenteral|pa?tch|sub(q|cut|ling)|suppository|topical)+', 0), '')), '') ) AS localroute
      |    ,nullif(TRIM(nullif(regexp_replace_5param(regexp_replace_5param(uni_item.Cpt_Sth_Ds, '[A-Za-z%(),]+','',1,0),'/$','',1,0), '')), '')   AS localstrengthperdoseunit
      |    ,COALESCE(Dos_Lbl_Ds, Dos_Exp_Ds, nullif(TRIM(nullif(regexp_replace_5param(uni_item.Cpt_Sth_Ds, '[0-9.,]+', '',1,0), '')), '')) AS localstrengthunit
      |    ,nullif(TRIM(nullif(regexp_replace_5param(regexp_replace_5param(CASE WHEN rlike(uni_item.Dos_Sth_Ds,'[%]+') THEN
      |            uni_item.Cpt_Sth_Ds ELSE uni_item.Dos_Sth_Ds END, '[A-Za-z%(),]+','',1,0),'/$','',1,0), '')), '')  AS localtotaldose
      |    ,todr.Car_Gvr_Int_Id  AS localproviderid
      |    ,todr.Act_Fg         AS orderstatus
      |    ,todr.Dpn_Wrt_Fg     AS localdaw
      |    ,'CH002045'          AS ordertype
      |    ,'0'                 AS venue
      |    ,todr.Ord_Dnt_Ts     AS expiredate
      |    ,uni_Item.Dpn_Siz_Qy AS quantityperfill
      |    ,ROW_NUMBER() OVER (PARTITION BY uni_item.Prx_Itm_Int_Id ORDER BY todr.Lst_Mod_Ts DESC NULLS LAST) rn
      |FROM MCKESSON_PGN_V1_TRX100_THERAPY_ORDER todr
      |   JOIN UNI_VISIT ON (todr.vst_int_id = uni_visit.vst_int_id)
      |   JOIN UNI_ITEM  ON (todr.prx_int_id = uni_item.prx_int_id)
      |WHERE todr.row_sta_cd <> 'D'
      |  AND todr.Prx_Int_Id IS NOT NULL
      |
      |)
      |where rxid IS NOT NULL AND rn = 1
    """.stripMargin
}

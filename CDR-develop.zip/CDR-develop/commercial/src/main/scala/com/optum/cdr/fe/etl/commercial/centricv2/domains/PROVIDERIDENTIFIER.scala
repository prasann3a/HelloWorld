package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_provider_identifier
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROVIDERIDENTIFIER extends FETableInfo[zh_provider_identifier] {

  override def name: String = "PROVIDERIDENTIFIER"

  override def dependsOn: Set[String] = Set("CENTRICV2_ZH_STAFFREG")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val sqlQuery =
      """
        |select GROUPID, CLIENT_DS_ID, PROVIDER_ID, ID_TYPE, ID_VALUE
        |from
        |(
        |select distinct
        |       '{groupid}' AS GROUPID
        |       ,'{client_ds_id}' AS CLIENT_DS_ID
        |       ,pvid AS PROVIDER_ID
        |       ,'License' AS ID_TYPE
        |       ,licnumber AS ID_VALUE
        |              from CENTRICV2_ZH_STAFFREG p where licnumber is not null
        |   union
        |       select distinct
        |       '{groupid}' AS GROUPID
        |       ,'{client_ds_id}' AS CLIENT_DS_ID
        |       ,pvid AS PROVIDER_ID
        |       ,'DEA' AS ID_TYPE
        |       ,deanumber AS ID_VALUE
        |              from CENTRICV2_ZH_STAFFREG p where deanumber is not null
        |   union
        |     select distinct
        |       '{groupid}' AS GROUPID
        |       ,'{client_ds_id}' AS CLIENT_DS_ID
        |       ,pvid AS PROVIDER_ID
        |       ,'UPIN' AS ID_TYPE
        |       ,upin AS ID_VALUE
        |   from CENTRICV2_ZH_STAFFREG p
        |   where upin is not null
        |
        |)
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId)

    sparkSession.sql(sqlQuery)
  }

}
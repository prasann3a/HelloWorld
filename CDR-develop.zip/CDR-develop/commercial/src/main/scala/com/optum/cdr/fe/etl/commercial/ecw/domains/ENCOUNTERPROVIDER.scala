package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{encounterprovider, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ENCOUNTERPROVIDER extends FETableInfo[encounterprovider]{

  override def name: String = CDRFEParquetNames.encounterprovider

  override def dependsOn: Set[String] = Set("IMMUNIZATIONS", "ZH_ITEMS", "ENC", CDRFEParquetNames.clinicalencounter, "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val visitstscodeidMpvList = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ENCOUNTERS", "CLINICALENCOUNTER",
      "ENC", "VISITSTSCODEID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val immuFilVal = if (runtimeVar.groupId.equals("H969977")) "and zh_items.parentid = '485'" else "and 1=1"
    val encFilVal = if (runtimeVar.groupId.equals("H969977")) "and not (deleteflag = '1' and status = 'CANC')" else "and 1=1"

    sparkSession.sql(
      """
        |WITH dedup_immu AS (
        |      SELECT  *
        |      FROM
        |      (
        |            SELECT  i.*
        |                  ,ROW_NUMBER() OVER (PARTITION BY immunizationid ORDER BY modifieddate DESC NULLS LAST) rn
        |            FROM IMMUNIZATIONS i
        |            WHERE DELETEFLAG <> '1'
        |      )
        |      WHERE rn = 1
        |),
        |enct_v AS (
        |      SELECT  *
        |      FROM
        |      (
        |            SELECT  m.*
        |                  ,ROW_NUMBER() OVER (PARTITION BY encounterid ORDER BY modifieddate DESC nulls last) rn
        |            FROM ENC m
        |            WHERE m.visitstscodeid NOT IN ({visitstscodeidMpvList})
        |            {encFilVal}
        |      )
        |      WHERE rn = 1
        |),
        |aco_enct AS (
        |      SELECT  v.*
        |      FROM ENCT_V v
        |      JOIN {CLINICALENCOUNTER} enc
        |      ON (v.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
        |)
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,encountertime
        |       ,providerid
        |       ,providerrole
        |       ,null as facilityid
        |FROM
        |(
        |	SELECT  distinct '{groupid}'                                                         AS groupid
        |	       ,'immunization'                                                               AS datasrc
        |	       ,{client_ds_id}                                                               AS client_ds_id
        |	       ,CASE WHEN dedup_immu.Datevisgiven IS NOT NULL THEN
        |             safe_to_date_length(
        |                 nullif(concat_ws('',
        |                     dedup_immu.Datevisgiven,
        |                     nvl(dedup_immu.Giventime,'00:00:00')
        |                  ),'')
        |             ,'yyyy-MM-ddHH:mm:ss',0)
        |           ELSE dedup_immu.modifieddate END AS encountertime
        |	       ,CASE WHEN dedup_immu.Givenbyid = '0' THEN NULL ELSE dedup_immu.Givenbyid END AS providerid
        |	       ,dedup_immu.Patientid                                                         AS patientid
        |	       ,dedup_immu.Encounterid                                                       AS encounterid
        |	       ,'Immunization Performing Provider'                                           AS providerrole
        |	FROM DEDUP_IMMU
        |	JOIN {CLINICALENCOUNTER} enc ON (dedup_immu.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
        |	LEFT OUTER JOIN ZH_ITEMS zh_items ON (zh_items.itemid = dedup_immu.itemid) {immuFilVal}
        |)
        |WHERE providerid IS NOT NULL
        |
        |UNION ALL
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,encountertime
        |       ,providerid
        |       ,providerrole
        |       ,facilityid
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                 AS groupid
        |	       ,'enc'                                                                       AS datasrc
        |	       ,{client_ds_id}                                                              AS client_ds_id
        |	       ,safe_to_date_length(
        |             nullif(concat_ws('',
        |                 date_format(enct.Enc_Date,'yyyy-MM-dd'),
        |                 nvl(CASE WHEN enct.Arrivedtime <> '00:00:00' THEN enct.arrivedtime WHEN enct.Timein <> '00:00:00' THEN enct.timein ELSE enct.Starttime END, '00:00:00')
        |             ),'')
        |           ,'yyyy-MM-ddHH:mm:ss',0) AS encountertime
        |	       ,Enct.Patientid                                                              AS patientid
        |	       ,Enct.Encounterid                                                            AS encounterid
        |	       ,CASE WHEN Enct.Facilityid = '0' THEN NULL ELSE Enct.Facilityid END          AS facilityid
        |	       ,enct.provid                                                                 AS providerid
        |	       ,CASE WHEN enct.provid_type = 'refprid' THEN 'Referring Provider'
        |	             WHEN enct.provid_type = 'doctorid' THEN 'Visit Provider' ELSE NULL END AS providerrole
        |	FROM
        |	(
        |		SELECT  *
        |		FROM
        |		(
        |			SELECT  *
        |			FROM
        |			(
        |				SELECT  unpivot_base.*
        |				       ,stack(2,refprid,'refprid',doctorid,'doctorid') AS (provid,provid_type)
        |				FROM ACO_ENCT unpivot_base
        |			)
        |			WHERE provid is not null
        |		)
        |	) enct
        |)
        |WHERE providerid <> '0'
        |AND providerid is not null and encountertime is not null
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{immuFilVal}", immuFilVal)
        .replace("{encFilVal}", encFilVal)
        .replace("{visitstscodeidMpvList}", visitstscodeidMpvList)
    )
  }
}

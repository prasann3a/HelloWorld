package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROCEDURE_CACHE_5 extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_5"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_ZH_T_GRPMST","MCKESSON_PGN_V1_ZH_T_FNDMST","MCKESSON_PGN_V1_ZH_T_CATMST", "MCKESSON_PGN_V1_T_PTDATA", "MAP_CUSTOM_PROC","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val findCdLst = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LOCALCODEPREFIX","PROCEDUREDO","PTDATA","FIND_CODE").mkString(",")
    val clientDsIdPrefix = runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |with uni_visit3 AS
        |(SELECT * FROM
        |(SELECT  v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        |   WHERE Psn_Int_Id IS NOT NULL
        |     AND vst_int_id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D' ),
        |uni_Grpmst AS
        |(SELECT * FROM
        |   (SELECT r.*, ROW_NUMBER() OVER (PARTITION BY grpmst_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
        |      FROM MCKESSON_PGN_V1_ZH_T_GRPMST r
        |      )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D' ),
        |uni_Fndmst AS
        |(SELECT * FROM
        |    (SELECT c.*, ROW_NUMBER() OVER (PARTITION BY t_fndmst_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
        |       FROM MCKESSON_PGN_V1_ZH_T_FNDMST c
        |       )
        |  WHERE rn = 1
        |    AND row_sta_cd <> 'D' ),
        |uni_Catmst AS
        |(SELECT * FROM
        |    (SELECT d.*, ROW_NUMBER() OVER (PARTITION BY cat_code ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
        |       FROM MCKESSON_PGN_V1_ZH_T_CATMST d
        |       )
        |  WHERE rn = 1
        |    AND row_sta_cd <> 'D' )
        |
        |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
        |from
        |(
        |SELECT pre_map.*, map.mappedvalue AS mappedcode,
        |       ROW_NUMBER() OVER (PARTITION BY pre_map.patientid, pre_map.encounterid,pre_map.proceduredate,pre_map.localcode
        |                          ORDER BY pre_map.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM (
        |SELECT '{groupid}'         	 AS groupid
        |      ,'ptdata'                  AS datasrc
        |      ,{client_ds_id}             AS client_ds_id
        |      ,CASE WHEN t_ptdata.Find_Code IN ({find_cd_lst}) THEN
        |               concat_ws('', '{client_ds_id_prefix}', t_ptdata.Category_Code, '-', t_ptdata.Grp_Code, '-', t_ptdata.Find_Code)
        |            ELSE concat_ws('', '{client_ds_id_prefix}', t_ptdata.Category_Code, '-', t_ptdata.Grp_Code) END AS localcode
        |      ,uni_visit3.Psn_Int_Id      AS patientid
        |      ,t_ptdata.Entered_For_Date AS proceduredate
        |      ,NULL     	         AS encounterid
        |      ,NULL                      AS orderingproviderid
        |      ,CASE WHEN t_ptdata.Find_Code IN ({find_cd_lst}) THEN
        |               concat_ws('', uni_catmst.Cat_Description, '-', uni_grpmst.Grp_Description, '-', uni_Fndmst.Find_Description)
        |            ELSE concat_ws('', uni_catmst.Cat_Description, '-', uni_grpmst.Grp_Description) END  AS localname
        |      ,NULL             	 AS procseq
        |      ,NULL                      AS proc_end_date
        |      ,NULL 			 AS hosp_px_flag
        |      ,'CUSTOM'  		 AS codetype
        |      ,NULL                      AS localprincipleindicator
        |      ,NULL        		 AS performingproviderid
        |      ,t_ptdata.Entered_For_Date AS actualprocdate
        |      ,t_ptdata.Lst_Mod_Ts
        |FROM MCKESSON_PGN_V1_T_PTDATA t_ptdata
        |   JOIN UNI_VISIT3 ON (uni_visit3.vst_int_id = t_ptdata.vst_int_id)
        |   LEFT OUTER JOIN UNI_GRPMST ON (t_ptdata.grp_code = uni_Grpmst.grp_code)
        |   LEFT OUTER JOIN UNI_FNDMST ON (uni_Fndmst.find_code = t_ptdata.find_code)
        |   LEFT OUTER JOIN UNI_CATMST ON (uni_Catmst.cat_code = t_ptdata.category_code)
        |WHERE t_ptdata.row_sta_cd <> 'D'
        |  AND t_ptdata.strike_out_flag = '0'
        |  AND t_ptdata.Entered_For_Date IS NOT NULL
        |) pre_map
        |   JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
        |                               map.datasrc = 'ptdata' AND
        |   			    map.localcode = pre_map.localcode)
        |)
        |where rn = 1 AND proceduredate IS NOT NULL AND patientid IS NOT NULL
      """.stripMargin
        .replace("{find_cd_lst}",findCdLst)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}",clientDsIdPrefix)
    )
  }
}

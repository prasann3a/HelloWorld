package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object OBSERVATION extends FEQueryAndMetadata[observation]{

  override def name: String = CDRFEParquetNames.observation

  override def dependsOn: Set[String] = Set("OBSERVATION_FLOWSHEETDATA","OBSERVATION_HPI","OBSERVATION_SOCIAL","OBSERVATION_STRUCTEXAM","OBSERVATION_STRUCTHPI","OBSERVATION_STRUCTPREVENTIVE","OBSERVATION_STRUCTPREVENTIVE_EYEEXAM","OBSERVATION_STRUCTSOCIALHISTORY","OBSERVATION_VITALS")

  override def sparkSql: String =
    """
      |select * from OBSERVATION_FLOWSHEETDATA
      |union all
      |select * from OBSERVATION_HPI
      |union all
      |select * from OBSERVATION_SOCIAL
      |union all
      |select * from OBSERVATION_STRUCTEXAM
      |union all
      |select * from OBSERVATION_STRUCTHPI
      |union all
      |select * from OBSERVATION_STRUCTPREVENTIVE
      |union all
      |select * from OBSERVATION_STRUCTPREVENTIVE_EYEEXAM
      |union all
      |select * from OBSERVATION_STRUCTSOCIALHISTORY
      |union all
      |select * from OBSERVATION_VITALS
    """.stripMargin
}

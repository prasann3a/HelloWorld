package com.optum.cdr.fe.etl.commercial.cust_pay_aetna.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.int_claim_member
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_MEMBER extends FETableInfo[int_claim_member] {

  override def name: String = CDRFEParquetNames.int_claim_member
  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","INT_CLAIM_MEMBER_CACHE1",
    "INT_CLAIM_MEMBER_H770_CACHE1","INT_CLAIM_MEMBER_MASKED_CACHE1")
  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")

    val maskedIdInclusion = mpvList(mapPredicateValues, groupId, clientDsId,"MASKED_CLAIMS","INTERMEDIATE_CLAIMS","INTERMEDIATE_CLAIMS","CLIENT_DS_ID").mkString
    val memberScript = mpvList(mapPredicateValues, groupId, clientDsId,"INT_CLAIM_MEMBER_H770","INT_CLAIM_MEMBER_H770","INT_CLAIM_MEMBER_H770","MEMBER_H770").mkString

    val memberScriptToRun = getMemberScriptList(groupId, memberScript)

    val maskedIdInclusionScript = if (maskedIdInclusion.equals("'Y'")) "UNION ALL SELECT * FROM INT_CLAIM_MEMBER_MASKED_CACHE1" else ""

    sparkSession.sql(
      s"""
         |SELECT *
         |FROM {int_claim_member}
         |{masked_id_inclusion}
      """.stripMargin.replace("{int_claim_member}",memberScriptToRun).replace("{masked_id_inclusion}",maskedIdInclusionScript)
    )
  }

  def getMemberScriptList(groupId: String, memberScript: String): String = {
     if (memberScript.equals(groupId)) {"INT_CLAIM_MEMBER_H770_CACHE1" }else {"INT_CLAIM_MEMBER_CACHE1"}
  }
}

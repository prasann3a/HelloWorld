package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.insurance
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INSURANCE extends FETableInfo[com.optum.oap.cdr.models.insurance]{

  override def name:String=CDRFEParquetNames.insurance

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId



    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }


    sparkSession.sql("""select groupid, datasrc, client_ds_id, ins_timestamp, patientid, encounterid, enrollenddt, enrollstartdt, plantype, groupnbr, insuranceorder, payorcode, payorname, plancode, planname, policynumber
                       |from
                       |(
                       |select
                       |		groupid
                       |		,datasrc
                       |		,client_ds_id
                       |		,ins_timestamp
                       |		,patientid
                       |		,encounterid
                       |		,enrollenddt
                       |		,enrollstartdt
                       |		,plantype
                       |		,groupnbr
                       |		,insuranceorder
                       |		,payorcode
                       |		,payorname
                       |		,plancode
                       |		,planname
                       |		,policynumber
                       |from (
                       |select
                       |		'{groupid}' 											as groupid
                       |		,'insurance' 											as datasrc
                       |		,{client_ds_id} 											as client_ds_id
                       |		,ins.active_status_date_time 									as ins_timestamp
                       |		,v.unique_person_identifier 									as patientid
                       |		,ins.unique_entity_identifier 									as encounterid
                       |		,ins.effective_end_date_time 									as enrollenddt
                       |		,ins.effective_begin_date_time 									as enrollstartdt
                       |		,rfr.financial_class 										as plantype
                       |		,coalesce(rfr.group_number, ins.group_number) 							as groupnbr
                       |		,ins.hum_sequence 										as insuranceorder
                       |		,ins.unique_health_plan_identifier 								as payorcode
                       |		,rfr.plan_name 											as payorname
                       |		,ins.unique_health_plan_identifier 								as plancode
                       |		,rfr.plan_name 											as planname
                       |		,coalesce(rfr.policy_number, ins.policy_number) 						as policynumber
                       |		,row_number() over (partition by ins.record_identifier order by ins.update_date_time desc nulls first) 	as rn
                       |from CERNERASP_INSURANCE  ins
                       |inner join VISIT v
                       |on 		ins.unique_subscriber_identifier = v.unique_person_identifier
                       |and 		ins.unique_entity_identifier = v.unique_visit_identifier
                       |left join REFERENCEHEALTHPLAN rfr
                       |on 		ins.unique_health_plan_identifier = rfr.unique_health_plan_identifier
                       |where 	ins.entity_type = 'VISIT'
                       |and 	ins.active_status_date_time 	is not null
                       |and 	v.unique_person_identifier 	is not null
                       |
                       |)
                       |where rn=1
                       |
                       |)""".stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
    )

  }
  override def dependsOn: Set[String] = Set("VISIT","CERNERASP_INSURANCE","REFERENCEHEALTHPLAN")
}

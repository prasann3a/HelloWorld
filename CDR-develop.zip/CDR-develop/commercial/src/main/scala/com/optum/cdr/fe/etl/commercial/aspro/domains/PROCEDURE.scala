package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROCEDURE extends FEQueryAndMetadata[proceduredo]{

override def name: String = CDRFEParquetNames.proceduredo

override def dependsOn: Set[String] = Set("PROCEDURE1", "PROCEDURE2", "PROCEDURE3", "PROCEDURE4")

override def sparkSql: String =
  """
    |select * from PROCEDURE1
    |
    |UNION ALL
    |
    |select * from PROCEDURE2
    |
    |UNION ALL
    |
    |select * from PROCEDURE3
    |
    |UNION ALL
    |
    |select * from PROCEDURE4
  """.stripMargin
}

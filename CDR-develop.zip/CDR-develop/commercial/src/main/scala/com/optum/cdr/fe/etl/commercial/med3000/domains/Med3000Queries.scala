package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.cdr.fe.etl.commercial.unit_remap
import com.optum.cdr.fe.utils.nonnumeric_labs_localresult_25.NONNUMERIC_LABRESULT
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object Med3000Queries extends BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)

  override def queryRegistry = QueryRegistry.queries

}

object InitialDependencies {

  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(

    FELoadFromParquet[charge_procedures](name = "MED3000_CHARGE_PROCEDURES", parquetLocation = s"$baseParquetLocation", tableName = "CHARGE_PROCEDURES")
    , FELoadFromParquet[charge_ticket_master](name = "MED3000_CHARGE_TICKET_MASTER", parquetLocation = s"$baseParquetLocation", tableName = "CHARGE_TICKET_MASTER")
    , FELoadFromParquet[patient_procedures](name = "MED3000_PATIENT_PROCEDURES", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT_PROCEDURES")
    , FELoadFromParquet[patient_hm](name = "MED3000_PATIENT_HM", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT_HM")
    , FELoadFromParquet[zh_hm_master](name = "MED3000_ZH_HM_MASTER", parquetLocation = s"$baseParquetLocation", tableName = "ZH_HM_MASTER")
    , FELoadFromParquet[map_custom_proc](name = "MED3000_MAP_CUSTOM_PROC", parquetLocation = s"$mappingParquetPath", tableName = "MAP_CUSTOM_PROC")
    , FELoadFromParquet[charge_diagnoses](name = "MED3000_CHARGE_DIAGNOSES", parquetLocation = s"$baseParquetLocation", tableName = "CHARGE_DIAGNOSES")
    , FELoadFromParquet[patient_diagnoses](name = "MED3000_PATIENT_DIAGNOSES", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT_DIAGNOSES")
    , FELoadFromParquet[zh_proc_master](name = "MED3000_ZH_PROC_MASTER", parquetLocation = s"$baseParquetLocation", tableName = "ZH_PROC_MASTER")
    , FELoadFromParquet[charge_ins_patient](name = "MED3000_CHARGE_INS_PATIENT", parquetLocation = s"$baseParquetLocation", tableName = "CHARGE_INS_PATIENT")
    , FELoadFromParquet[zh_ins_company](name = "MED3000_ZH_INS_COMPANY", parquetLocation = s"$baseParquetLocation", tableName = "ZH_INS_COMPANY")
    , FELoadFromParquet[zh_ins_company_plan](name = "MED3000_ZH_INS_COMPANY_PLAN", parquetLocation = s"$baseParquetLocation", tableName = "ZH_INS_COMPANY_PLAN")
    , FELoadFromParquet[zh_location](name = "MED3000_ZH_LOCATION", parquetLocation = s"$baseParquetLocation", tableName = "ZH_LOCATION")
    , FELoadFromParquet[patient_allergies](name = "MED3000_PATIENT_ALLERGIES", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT_ALLERGIES")
    , FELoadFromParquet[zh_medication_master](name = "MED3000_ZH_MEDICATION_MASTER", parquetLocation = s"$baseParquetLocation", tableName = "ZH_MEDICATION_MASTER")
    , FELoadFromParquet[patient_medications](name = "MED3000_PATIENT_MEDICATIONS", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT_MEDICATIONS")
    , FELoadFromParquet[zh_med_routes](name = "MED3000_ZH_MED_ROUTES", parquetLocation = s"$baseParquetLocation", tableName = "ZH_MED_ROUTES")
    , FELoadFromParquet[zh_med_forms](name = "MED3000_ZH_MED_FORMS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_MED_FORMS")
    , FELoadFromParquet[zh_doctors](name = "MED3000_ZH_DOCTORS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DOCTORS")
    , FELoadFromParquet[prescriptions](name = "MED3000_PRESCRIPTIONS", parquetLocation = s"$baseParquetLocation", tableName = "PRESCRIPTIONS")
    , FELoadFromParquet[prescription_master](name = "MED3000_PRESCRIPTION_MASTER", parquetLocation = s"$baseParquetLocation", tableName = "PRESCRIPTION_MASTER")
    , FELoadFromParquet[lab_result](name = "MED3000_LAB_RESULT", parquetLocation = s"$baseParquetLocation", tableName = "LAB_RESULT")
    , FELoadFromParquet[ordered_test](name = "MED3000_ORDERED_TEST", parquetLocation = s"$baseParquetLocation", tableName = "ORDERED_TEST")
    , FELoadFromParquet[patient_vitals](name = "MED3000_PATIENT_VITALS", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT_VITALS")
    , FELoadFromParquet[zcm_obstype_code](name = "ZCM_OBSTYPE_CODE", parquetLocation = s"$mappingParquetPath", tableName = "ZCM_OBSTYPE_CODE")
    , FELoadFromParquet[zh_vitals_master](name = "MED3000_ZH_VITALS_MASTER", parquetLocation = s"$baseParquetLocation", tableName = "ZH_VITALS_MASTER")
    , FELoadFromParquet[patient_vital_signs](name = "MED3000_PATIENT_VITAL_SIGNS", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT_VITAL_SIGNS")
    , FELoadFromParquet[map_unit](name = "MAP_UNIT", parquetLocation = s"$mappingParquetPath", tableName = "MAP_UNIT")
    , FELoadFromParquet[unit_remap](name = "UNIT_REMAP", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_REMAP")
    , FELoadFromParquet[metadata_lab](name = "METADATA_LAB", parquetLocation = s"$mappingParquetPath", tableName = "METADATA_LAB")
    , FELoadFromParquet[unit_conversion](name = "UNIT_CONVERSION", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_CONVERSION")
    , FELoadFromParquet[mpi](name = "MED3000_MPI", parquetLocation = s"$baseParquetLocation", tableName = "MPI")
    , FELoadFromParquet[visit_entry_answers_h](name = "MED3000_VISIT_ENTRY_ANSWERS_H", parquetLocation = s"$baseParquetLocation", tableName = "VISIT_ENTRY_ANSWERS_H")
    , FELoadFromParquet[mpi_xref](name = "MED3000_MPI_XREF", parquetLocation = s"$baseParquetLocation", tableName = "MPI_XREF")

  )
}

object QueryRegistry {

  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(

    ALLERGY
    , CLAIM
    , DIAGNOSIS
    , DIAGNOSIS_TEMP_PAT
    , DIAGNOSIS_TEMP_CHARGE
    , FACILITY
    , GTT_LABRESULT_NONNUMERIC
    , INSURANCE
    , LABMAPPERDICT
    , LABRESULT
    , LABRESULT_CACHE
    , LABRESULT_HM_VITALS_TEMP
    , NONNUMERIC_LABRESULT
    , OBSERVATION
    , PATIENT
    , PATIENT_CACHE
    , PATIENT_CONTACT
    , PATIENT_DETAIL
    , PATIENT_ID
    , PATIENTADDRESS
    , PATIENT_REPORTED_MEDS
    , PROCEDURE
    , PROCEDURE_CHARGE_PROCS
    , PROCEDURE_PAT_PROCS
    , PROCEDURE_PAT_HM
    , PROVIDER
    , PROVIDER_IDENTIFIER
    , RXORDER

  )
}
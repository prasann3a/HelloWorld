package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.patientaddr
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object PATIENTADDRESS extends FEQueryAndMetadata[patientaddr] {

  override def name: String = "PATIENTADDRESS"

  override def dependsOn: Set[String] = Set("PATIENT_PART1_CACHE", "PATIENT_PART2_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as address_date, addressline1 as address_line1, addressline2 as address_line2, city, state, zipcode, address_type
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where adder_row = 1  and addressline1 is not null and patientid is not null and lastupdateddate is not null
      |
      |union all
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as address_date, addressline1 as address_line1, addressline2 as address_line2, city, state, zipcode, address_type
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where adder_row = 1  and addressline1 is not null and patientid is not null and lastupdateddate is not null
    """.stripMargin
}
package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object TEMP_PROCEDURE_PART2 extends FEQueryAndMetadata[proceduredo] {

  override def name: String = "TEMP_PROCEDURE_PART2"

  override def dependsOn: Set[String] = Set("TEMP_MRCODE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localcode, patientid, servicedate as proceduredate, facilityid, procseq, referproviderid, actualprocdate, encounterid, hosp_px_flag, performingproviderid, localcode as mappedcode
      |from
      |(
      |TEMP_MRCODE
      |)
      |where servicedate is not null and patientid is not null
    """.stripMargin

}

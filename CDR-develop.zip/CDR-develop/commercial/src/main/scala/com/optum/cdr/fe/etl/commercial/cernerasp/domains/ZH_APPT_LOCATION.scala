package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_appt_location
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ZH_APPT_LOCATION extends FETableInfo[zh_appt_location]{

  override  def name:String=CDRFEParquetNames.zh_appt_location

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select groupid, client_ds_id, locationid, locationname
         |from
         |(
         |select '{groupid}'	as groupid
         |	,{client_ds_id}	as client_ds_id
         |	,s.location	as locationid
         |	,max(rc.description)	as locationname
         |from SCHEDULES s
         |	inner join REFERENCECODE rc on (rc.element_code = s.location and rc.file_name = 'SCHEDULES')
         |where s.location is not null
         |and rc.description is not null
         |
          |group by s.location
         |)
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
    )
  }

  override def dependsOn: Set[String] = Set("REFERENCECODE","SCHEDULES")
}
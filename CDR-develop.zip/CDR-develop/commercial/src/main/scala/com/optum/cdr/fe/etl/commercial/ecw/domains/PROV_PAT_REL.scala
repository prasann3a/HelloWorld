package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.prov_pat_rel
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, RuntimeVariables}

object PROV_PAT_REL extends FEQueryAndMetadata[prov_pat_rel] {

  override def name: String = CDRFEParquetNames.prov_pat_rel

  override def dependsOn: Set[String] = Set("PROV_PAT_REL_ZH_PCP", "PROV_PAT_REL_PATIENTS")

  override def sparkSql: String =

    """
      select * from
      |PROV_PAT_REL_ZH_PCP
      |
      |union all
      |
      |select * from
      |PROV_PAT_REL_PATIENTS
    """.stripMargin

}
package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.laborder
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object LABORDER extends FETableInfo[laborder]{

  override def name: String = "LABORDER"

  override def dependsOn: Set[String] =
    Set("CENTRICV2_ORDERS"
      ,"CENTRICV2_ZH_ORDERCODES"
      ,"CENTRICV2_DOCUMENTS"
      ,"MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val xidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"),groupId, clientDsId,"XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")

    val xidInclusionCondition = if(xidInclusionMpv == "'X'") "--" else ""

    sparkSession.sql(
      s"""
         |SELECT
         |   datasrc
         |  ,laborderid
         |  ,encounterid
         |  ,patientid
         |  ,dateordered
         |  ,localtestname
         |  ,localtestdescription
         |  ,statuscode
         |  ,dateordered as laborder_date
         |  ,orderingproviderid
         |FROM
         |(
         |SELECT
         | 'Orders'                               as datasrc
         |,od.Code                             AS localtestcode
         |,od.Description                      AS localtestname
         |,od.Pid                              AS patientid
         |,od.Orderdate                        AS dateordered
         |,od.Sdid                             AS encounterid
         |,od.Orderid                          AS laborderid
         |,zh_od.Description                   AS localtestdescription
         |,od.Status                           AS statuscode
         |,od.Usrid                            AS orderingproviderid
         |           FROM CENTRICV2_ORDERS od
         |                INNER JOIN CENTRICV2_ZH_ORDERCODES zh_od ON (od.ORDCODEID = zh_od.ORDCODEID)
         |                INNER JOIN CENTRICV2_DOCUMENTS doc ON (doc.sdid = od.sdid and doc.pid = od.pid)
         |                 where od.ordertype = 'T' ---(lab tests and procedures)
         |                 and  od.status <> 'X' ---(cancelled)
         |                 $xidInclusionCondition and od.XID =  '100000000000000000000000000000000000'
         |                 and doc.XID = '100000000000000000000000000000000000'
         |                 and od.orderdate is not null
         |)
       """
    .stripMargin
    )

  }

}

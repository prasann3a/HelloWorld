package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.etl.commercial.cenent_claim_proc_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object TEMP_CLAIM_PROC_CACHE1 extends FEQueryAndMetadata[cenent_claim_proc_cache] {

  override def name: String = "TEMP_CLAIM_PROC_CACHE1"

  override def dependsOn: Set[String] = Set("DISCH", "ENCNTR")

  override def sparkSql: String =
    """
      |SELECT distinct
      |    '{groupid}' as groupid,
      |    'disch' as datasrc
      |    ,{client_ds_id} as client_ds_id
      |    ,Acct_Num  AS claimid
      |    ,Pat_Person_Num  AS patientid
      |    ,encounterid
      |    ,Fac  AS facilityid
      |    ,servicedate
      |    ,claimproviderid
      |    ,localcpt
      |    ,seq
      |FROM (
      |    SELECT unpivot_base.*,
      |    stack(10, Proc_Date_1, Proc_Md_1, Stay_Proc_1, '1', Proc_Date_2, Proc_Md_2, Stay_Proc_2, '2',
      |        Proc_Date_3, Proc_Md_3, Stay_Proc_3, '3', Proc_Date_4, Proc_Md_4, Stay_Proc_4, '4',
      |         Proc_Date_5, Proc_Md_5, Stay_Proc_5, '5', Proc_Date_6, Proc_Md_6, Stay_Proc_6, '6',
      |          Proc_Date_7, Proc_Md_7, Stay_Proc_7, '7', Proc_Date_8, Proc_Md_8, Stay_Proc_8, '8',
      |          Proc_Date_9, Proc_Md_9, Stay_Proc_9, '9', Proc_Date_10, Proc_Md_10, Stay_Proc_10, '10') as (servicedate, claimproviderid, localcpt, seq)
      |
      |    FROM (
      |    SELECT * FROM DISCH JOIN (
      |    SELECT prim_acct_num, Pat_Person_Num, num AS encounterid FROM ENCNTR
      |          WHERE encntr_type_cde IN ('I','A','V') AND encntr_cat_cde = 'ACTV'
      |      ) encntr ON (encntr.prim_acct_num=disch.acct_num)) unpivot_base )
      |
    """.stripMargin

}

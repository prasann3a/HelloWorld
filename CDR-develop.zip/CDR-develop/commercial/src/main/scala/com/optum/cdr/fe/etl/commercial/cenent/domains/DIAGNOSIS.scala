package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object DIAGNOSIS extends FEQueryAndMetadata[diagnosis] {

  override def name: String = CDRFEParquetNames.diagnosis

  override def dependsOn: Set[String] = Set("TEMP_DIAGNOSIS_PART1", "TEMP_DIAGNOSIS_PART2", "TEMP_DIAGNOSIS_PART3")

  override def sparkSql: String =
    """

    SELECT * FROM TEMP_DIAGNOSIS_PART1

    UNION ALL

    SELECT * FROM TEMP_DIAGNOSIS_PART2


    UNION ALL

    SELECT * FROM TEMP_DIAGNOSIS_PART3
    
    """.stripMargin

}
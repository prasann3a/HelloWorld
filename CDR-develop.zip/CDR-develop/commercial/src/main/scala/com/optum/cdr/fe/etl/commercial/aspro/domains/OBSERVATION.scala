package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object OBSERVATION extends FEQueryAndMetadata[observation] {

  override def name: String = CDRFEParquetNames.observation

  override def dependsOn: Set[String] = Set("OBSERVATION_VITALS", "OBSERVATION_DIAGNOSIS", "OBSERVATION_FLOWSHEET")

  override def sparkSql: String =
    """
      |select * from OBSERVATION_VITALS
      |
      |union all
      |
      |select * from OBSERVATION_DIAGNOSIS
      |
      |union all
      |
      |select * from OBSERVATION_FLOWSHEET
    """.stripMargin

}


package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}
import com.optum.oap.cdr.models.rxadmin

object RXMEDADMINISTRATIONS extends FEQueryAndMetadata[rxadmin]{
  override def name: String = CDRFEParquetNames.rxadmin

  override def dependsOn: Set[String] = Set("RXMEDADMINISTRATIONS_TEMP_CCDBA_MED_ORDER","RXMEDADMINISTRATIONS_TEMP_CCDBA_O_PAT")

  override def sparkSql: String =
    """
      |SELECT * FROM RXMEDADMINISTRATIONS_TEMP_CCDBA_MED_ORDER
      |UNION ALL
      |SELECT * FROM RXMEDADMINISTRATIONS_TEMP_CCDBA_O_PAT
    """.stripMargin

}

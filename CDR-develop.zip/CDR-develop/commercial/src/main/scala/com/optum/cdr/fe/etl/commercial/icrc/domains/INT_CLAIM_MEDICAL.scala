package com.optum.cdr.fe.etl.commercial.icrc.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.int_claim_medical
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.lit

object INT_CLAIM_MEDICAL extends FETableInfo[int_claim_medical] {

  override def name: String = CDRFEParquetNames.int_claim_medical

  override def dependsOn: Set[String] = Set("MEDICAL", "ZO_BPO_MAP_EMPLOYER", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    var medicalDf = loadedDependencies("MEDICAL")
    // Add these 5 columns with null value if these columns are not present
    // This is because the stage parquets may/may not have these 5 columns, but the query needs them
    Seq("UHC_MEMBER","BILL_PRV","ORDER_PRV","REF_PRV","AMT_COB").foreach(col => {
      medicalDf = if(!medicalDf.columns.contains(col)) medicalDf.withColumn(col, lit(null)) else medicalDf
    })
    medicalDf.createOrReplaceTempView("MEDICAL")

    loadedDependencies("ZO_BPO_MAP_EMPLOYER").createOrReplaceTempView("ZO_BPO_MAP_EMPLOYER")

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val intClaimMedicalMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "INT_CLAIM_MEDICAL", "INT_CLAIM_MEDICAL", "INT_CLAIM_MEDICAL", "MEDICAL").mkString(",")
    val intClaimMedicalQuery = if (intClaimMedicalMpv.contains(loaderVars.groupId))
      """
        |Select groupid, datasrc, client_ds_id, CLAIM_HEADER_ID, CLAIM_LINE_ID, MEMBER_ID, PAYER_CODE, PAYER_NAME, PLACE_OF_SERVICE, QUANTITY_OF_SERVICE, SERVICE_DATE, SERVICING_PROV_ID, ADMIT_DATE, ADMIT_SOURCE_CODE, ALLOWED_AMT, ATTND_PROV_NPI, ATTND_PROV_SPCLTY_CD, BILLING_PROV_ID, BILLING_PROV_NPI, COORD_BENIFITS_AMT, CAPITATED_SERVICE_FLAG, CAPITATION_AMT, CLAIM_TYPE, COINSURANCE_AMT, COPAY_AMT, DIAG_REL_GRP_CODE, DIAG_REL_GRP_GROUPER, DIAG_REL_GRP_OUTLIER, DIAG_REL_GRP_SEVERITY, DEDUCTABLE_AMT, DENIED_FLAG, DENIED_REASON, DISCHARGE_DATE, DISCHARGE_STATUS_CODE, ICD_DIAG_CD1_POA_INDICATOR, ICD_DIAG_CD2_POA_INDICATOR, ICD_DIAG_CD3_POA_INDICATOR, ICD_DIAG_CD4_POA_INDICATOR, ICD_DIAG_CD5_POA_INDICATOR, ICD_DIAG_CD6_POA_INDICATOR, ICD_DIAG_CD7_POA_INDICATOR, ICD_DIAG_CD8_POA_INDICATOR, ICD_DIAG_CD9_POA_INDICATOR, ICD_DIAG_CD10_POA_INDICATOR, ICD_DIAG_CD11_POA_INDICATOR, ICD_DIAG_CD12_POA_INDICATOR, ICD_DIAG_CD13_POA_INDICATOR, ICD_DIAG_CD14_POA_INDICATOR, ICD_DIAG_CD15_POA_INDICATOR, ICD_DIAG_CD16_POA_INDICATOR, ICD_DIAG_CD17_POA_INDICATOR, ICD_DIAG_CD18_POA_INDICATOR, ICD_DIAG_CD19_POA_INDICATOR, ICD_DIAG_CD20_POA_INDICATOR, ICD_DIAG_CD21_POA_INDICATOR, ICD_DIAG_CD22_POA_INDICATOR, ICD_DIAG_CD23_POA_INDICATOR, ICD_DIAG_CD1, ICD_DIAG_CD2, ICD_DIAG_CD3, ICD_DIAG_CD4, ICD_DIAG_CD5, ICD_DIAG_CD6, ICD_DIAG_CD7, ICD_DIAG_CD8, ICD_DIAG_CD9, ICD_DIAG_CD10, ICD_DIAG_CD11, ICD_DIAG_CD12, ICD_DIAG_CD13, ICD_DIAG_CD14, ICD_DIAG_CD15, ICD_DIAG_CD16, ICD_DIAG_CD17, ICD_DIAG_CD18, ICD_DIAG_CD19, ICD_DIAG_CD20, ICD_DIAG_CD21, ICD_DIAG_CD22, ICD_DIAG_CD23, ICD_DIAG_CD1_TYPE, ICD_DIAG_CD2_TYPE, ICD_DIAG_CD3_TYPE, ICD_DIAG_CD4_TYPE, ICD_DIAG_CD5_TYPE, ICD_DIAG_CD6_TYPE, ICD_DIAG_CD7_TYPE, ICD_DIAG_CD8_TYPE, ICD_DIAG_CD9_TYPE, ICD_DIAG_CD10_TYPE, ICD_DIAG_CD11_TYPE, ICD_DIAG_CD12_TYPE, ICD_DIAG_CD13_TYPE, ICD_DIAG_CD14_TYPE, ICD_DIAG_CD15_TYPE, ICD_DIAG_CD16_TYPE, ICD_DIAG_CD17_TYPE, ICD_DIAG_CD18_TYPE, ICD_DIAG_CD19_TYPE, ICD_DIAG_CD20_TYPE, ICD_DIAG_CD21_TYPE, ICD_DIAG_CD22_TYPE, ICD_DIAG_CD23_TYPE, ICD_PROC_CD_1, ICD_PROC_CD_2, ICD_PROC_CD_3, ICD_PROC_CD_4, ICD_PROC_CD_5, ICD_PROC_CD_6, ICD_PROC_CD_7, ICD_PROC_CD_8, ICD_PROC_CD_9, ICD_PROC_CD_10, ICD_PROC_CD_11, ICD_PROC_CD_12, ICD_PROC_CD_13, ICD_PROC_CD_14, ICD_PROC_CD_15, ICD_PROC_CD_1_TYPE, ICD_PROC_CD_2_TYPE, ICD_PROC_CD_3_TYPE, ICD_PROC_CD_4_TYPE, ICD_PROC_CD_5_TYPE, ICD_PROC_CD_6_TYPE, ICD_PROC_CD_7_TYPE, ICD_PROC_CD_8_TYPE, ICD_PROC_CD_9_TYPE, ICD_PROC_CD_10_TYPE, ICD_PROC_CD_11_TYPE, ICD_PROC_CD_12_TYPE, ICD_PROC_CD_13_TYPE, ICD_PROC_CD_14_TYPE, ICD_PROC_CD_15_TYPE, NETWORK_PAID_STATUS, ORDERING_PROV_ID, Par_Flag, PAYMENT_AMT, PAY_PROCESS_DATE, PRINCIPLE_PROC_CD, PRINCIPLE_PROC_ICD_TYPE, PROC_CD_MODIFIER_1, PROC_CD_MODIFIER_2, PROC_CD_MODIFIER_3, PROC_CODE, REFERRING_PROV_ID, REQUESTED_AMT, REVENUE_CODE, SERVICE_FROM_DATE, SERVICE_TO_DATE, SERVICING_PROV_NPI, TYPE_OF_BILL_CODE, SERVICING_PROV_SPCLTY_CD, CONTRACT_ID, ENCOUNTERID
        |from (
        |select
        |     	 distinct '{groupid}' 	     AS groupid
        |        ,'Medical' 		     AS datasrc
        |        ,{client_ds_id}		     AS client_ds_id
        |        ,nullif(concat_ws('', MEMBER, PROVIDER, upper(date_format(DOS, 'dd-MMM-yy')), upper(date_format(FROM_DT, 'dd-MMM-yy')), upper(date_format(TO_DT, 'dd-MMM-yy')), POS, TOS_N, REVENUE, PROCCODE, MOD_N, PLAN_SOURCE), '')	AS CLAIM_HEADER_ID
        |	,Line_Nat						 AS CLAIM_LINE_ID
        |	,Member						 AS MEMBER_ID
        |	,b.EMPLOYERACCOUNTID 		     AS PAYER_CODE
        |	,b.EMPLOYERACCOUNTID 		     AS PAYER_NAME
        |	,Pos		     AS PLACE_OF_SERVICE
        |	,Qty			     AS QUANTITY_OF_SERVICE
        |	,Dos 		      	     AS SERVICE_DATE
        |	,Provider		     AS SERVICING_PROV_ID
        |	,CASE
        |	WHEN TOS_N = 'FACIP' and date_format(From_Dt, 'yyyy') <> '9999'
        |	then From_Dt
        |	WHEN TOS_N = 'FACIP' and date_format(From_Dt, 'yyyy') = '9999'
        |	then DOS else NULL End 	     AS ADMIT_DATE
        |	,Admit_Source		     AS ADMIT_SOURCE_CODE
        |	,Amt_Eqv		     AS ALLOWED_AMT
        |	,Provider 		     AS ATTND_PROV_NPI
        |	,Prv_Sp_N	             AS ATTND_PROV_SPCLTY_CD
        |	,Bill_Prov		     AS BILLING_PROV_ID
        |	,Bill_Prov 		     AS BILLING_PROV_NPI
        |	,Cob_amt	             AS COORD_BENIFITS_AMT
        |	,Cap_Flag	             AS CAPITATED_SERVICE_FLAG
        |	,Amt_Cap_Pay	             AS CAPITATION_AMT
        |	,CASE
        |	WHEN TOS_N in ('FACIP', 'FACOP') then 'I'
        |	WHEN   TOS_N = 'PROF' then 'P'
        |	else null END 		     AS CLAIM_TYPE
        |	,Amt_Coin	             AS COINSURANCE_AMT
        |	,Amt_Cop	             AS COPAY_AMT
        |	,Drg_N	                     AS DIAG_REL_GRP_CODE
        |	,CASE
        |	When Drg_Version = 'MS' then 'MSDRG'
        |	else Null END	    	     AS DIAG_REL_GRP_GROUPER
        |	,Drg_Outlier 		     AS DIAG_REL_GRP_OUTLIER
        |	,Drg_Level	             AS DIAG_REL_GRP_SEVERITY
        |	,Amt_Ded 		     AS DEDUCTABLE_AMT
        |	,Denied_Flag	             AS DENIED_FLAG
        |	,Denied_Ind	             AS DENIED_REASON
        |	,CASE WHEN TOS_N = 'FACIP' then To_Dt
        |	 else NULL END 	 	     AS DISCHARGE_DATE
        |	,Dis_Stat 		     AS DISCHARGE_STATUS_CODE
        |	,Poa_N	    	 	     AS ICD_DIAG_CD1_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD2_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD3_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD4_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD5_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD6_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD7_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD8_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD9_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD10_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD11_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD12_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD13_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD14_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD15_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD16_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD17_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD18_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD19_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD20_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD21_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD22_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD23_POA_INDICATOR
        |	,Diag1                       AS ICD_DIAG_CD1
        |	,Diag2		             AS ICD_DIAG_CD2
        |	,Diag3 		             AS ICD_DIAG_CD3
        |	,Diag4			     AS ICD_DIAG_CD4
        |	,Diag5 			     AS ICD_DIAG_CD5
        |	,Diag6 			     AS ICD_DIAG_CD6
        |	,Diag7			     AS ICD_DIAG_CD7
        |	,Diag8 			     AS ICD_DIAG_CD8
        |	,Diag9			     AS ICD_DIAG_CD9
        |	,Diag10 		     AS ICD_DIAG_CD10
        |	,Diag11 		     AS ICD_DIAG_CD11
        |	,Diag12 		     AS ICD_DIAG_CD12
        |	,Diag13 		     AS ICD_DIAG_CD13
        |	,Diag14 		     AS ICD_DIAG_CD14
        |	,Diag15 		     AS ICD_DIAG_CD15
        |	,Diag16 		     AS ICD_DIAG_CD16
        |	,Diag17			     AS ICD_DIAG_CD17
        |	,Diag18	    		     AS ICD_DIAG_CD18
        |	,Diag19	                     AS ICD_DIAG_CD19
        |	,Diag20			     AS ICD_DIAG_CD20
        |	,Diag21 		     AS ICD_DIAG_CD21
        |	,Diag22 		     AS ICD_DIAG_CD22
        |	,Diag23 		     AS ICD_DIAG_CD23
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD1_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD2_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD3_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD4_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD5_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD6_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD7_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD8_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD9_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD10_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD11_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD12_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD13_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD14_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD15_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD16_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD17_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD18_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD19_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD20_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD21_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD22_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD23_TYPE
        |	,Case
        |	 when Iproc1 like '%00000%' Then Null
        |		else Iproc1 END	 AS ICD_PROC_CD_1
        |	,Case
        |	 when Iproc2 like '%00000%' Then Null
        |		else Iproc2 END  AS ICD_PROC_CD_2
        |	,Case
        |	 when Iproc3 like '%00000%' Then Null
        |		else Iproc3 END  AS ICD_PROC_CD_3
        |	,Case
        |	 when Iproc4 like '%00000%' Then Null
        |		else Iproc4 END AS ICD_PROC_CD_4
        |	,Case
        |	 when Iproc5 like '%00000%' Then Null
        |		else Iproc5 END AS ICD_PROC_CD_5
        |	,Case
        |	 when Iproc6 like '%00000%' Then Null
        |		else Iproc6 END  AS ICD_PROC_CD_6
        |	,Case
        |	 when Iproc7 like '%00000%' Then Null
        |		else Iproc7 END  AS ICD_PROC_CD_7
        |	,Case
        |	 when Iproc8 like '%00000%' Then Null
        |		else Iproc8 END  AS ICD_PROC_CD_8
        |	,Case
        |	 when Iproc9 like '%00000%' Then Null
        |		else Iproc9 END  AS ICD_PROC_CD_9
        |	,Case
        |	 when Iproc10 like '%00000%' Then Null
        |		else Iproc10 END  AS ICD_PROC_CD_10
        |	,Case
        |	 when Iproc11 like '%00000%' Then Null
        |		else Iproc11 END  AS ICD_PROC_CD_11
        |	,Case
        |	 when Iproc12 like '%00000%' Then Null
        |		else Iproc12 END  AS ICD_PROC_CD_12
        |	,Case
        |	 when Iproc13 like '%00000%' Then Null
        |		else Iproc13 END  AS ICD_PROC_CD_13
        |	,Case
        |	 when Iproc14 like '%00000%' Then Null
        |		else Iproc14 END  AS ICD_PROC_CD_14
        |	,Case
        |	 when Iproc15 like '%00000%' Then Null
        |		else Iproc15 END  AS ICD_PROC_CD_15
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |	 else null END 			AS ICD_PROC_CD_1_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_2_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_3_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_4_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_5_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_6_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_7_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_8_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_9_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_10_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_11_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_12_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_13_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_14_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_15_TYPE
        |	,Network_Paid_Status 	     AS NETWORK_PAID_STATUS
        |	,Order_Prov 		     AS ORDERING_PROV_ID
        |	,CASE
        |	WHEN network_status = '1' THEN 'Y'
        |	WHEN network_status ='0' THEN 'N'
        |	else NULL END 		     AS Par_Flag
        |	,Amt_Pay		     AS PAYMENT_AMT
        |	,Pay_Dt			     AS PAY_PROCESS_DATE
        |	,Iproc1			     AS PRINCIPLE_PROC_CD
        |	,CASE
        |	 WHEN icd_version ='9' THEN 'ICD9'
        |	 WHEN icd_version='0' THEN 'ICD10'
        |	 else null END 		     AS PRINCIPLE_PROC_ICD_TYPE
        |	,Mod_N			     AS PROC_CD_MODIFIER_1
        |	,Mod_N_2		     AS PROC_CD_MODIFIER_2
        |	,Mod_N_3		     AS PROC_CD_MODIFIER_3
        |	,Proccode		     AS PROC_CODE
        |	,Ref_Prov		     AS REFERRING_PROV_ID
        |	,Amt_Req		     AS REQUESTED_AMT
        |	,case when Revenue='0000' then null else revenue END	     AS REVENUE_CODE
        |	,CASE
        | 	When YEAR(TO_DATE(from_dt,'yyyy-MM-dd HH:mm:ss' )) <> '9999'  then From_Dt
        |	else null             END   AS SERVICE_FROM_DATE
        |	,To_Dt			     AS SERVICE_TO_DATE
        |	,Provider 		     AS SERVICING_PROV_NPI
        |	,Bill_Type		     AS TYPE_OF_BILL_CODE
        |	,prv_sp_N            As SERVICING_PROV_SPCLTY_CD
        |	,b.EMPLOYERACCOUNTID As CONTRACT_ID
        |        ,nullif(concat_ws('', MEMBER, PROVIDER, upper(date_format(DOS, 'dd-MMM-yy')), upper(date_format(FROM_DT, 'dd-MMM-yy')), upper(date_format(TO_DT, 'dd-MMM-yy')), POS, TOS_N, REVENUE, PROCCODE, MOD_N, PLAN_SOURCE), '')      AS ENCOUNTERID
        |	,row_number() over(partition by MEMBER, PROVIDER, DOS, FROM_DT, TO_DT, POS, TOS_N, REVENUE, PROCCODE, MOD_N, MOD_N_2, MOD_N_3, MOD_N_4, PLAN_SOURCE order by transact_date desc nulls last) as rnk
        |	from MEDICAL M
        |	cross Join ZO_BPO_MAP_EMPLOYER b ON (b.client_ds_id = {client_ds_id})
        |	)
        |	Where rnk = 1
      """.stripMargin
    else
      """
        |Select groupid, datasrc, client_ds_id, CLAIM_HEADER_ID, CLAIM_LINE_ID, MEMBER_ID, PAYER_CODE, PAYER_NAME, PLACE_OF_SERVICE, QUANTITY_OF_SERVICE, SERVICE_DATE, SERVICING_PROV_ID, ADMIT_DATE, ADMIT_SOURCE_CODE, ALLOWED_AMT, ATTND_PROV_NPI, ATTND_PROV_SPCLTY_CD, BILLING_PROV_ID, BILLING_PROV_NPI, COORD_BENIFITS_AMT, CAPITATED_SERVICE_FLAG, CAPITATION_AMT, CLAIM_TYPE, COINSURANCE_AMT, COPAY_AMT, DIAG_REL_GRP_CODE, DIAG_REL_GRP_GROUPER, DIAG_REL_GRP_OUTLIER, DIAG_REL_GRP_SEVERITY, DEDUCTABLE_AMT, DENIED_FLAG, DENIED_REASON, DISCHARGE_DATE, DISCHARGE_STATUS_CODE, ICD_DIAG_CD1_POA_INDICATOR, ICD_DIAG_CD2_POA_INDICATOR, ICD_DIAG_CD3_POA_INDICATOR, ICD_DIAG_CD4_POA_INDICATOR, ICD_DIAG_CD5_POA_INDICATOR, ICD_DIAG_CD6_POA_INDICATOR, ICD_DIAG_CD7_POA_INDICATOR, ICD_DIAG_CD8_POA_INDICATOR, ICD_DIAG_CD9_POA_INDICATOR, ICD_DIAG_CD10_POA_INDICATOR, ICD_DIAG_CD11_POA_INDICATOR, ICD_DIAG_CD12_POA_INDICATOR, ICD_DIAG_CD13_POA_INDICATOR, ICD_DIAG_CD14_POA_INDICATOR, ICD_DIAG_CD15_POA_INDICATOR, ICD_DIAG_CD16_POA_INDICATOR, ICD_DIAG_CD17_POA_INDICATOR, ICD_DIAG_CD18_POA_INDICATOR, ICD_DIAG_CD19_POA_INDICATOR, ICD_DIAG_CD20_POA_INDICATOR, ICD_DIAG_CD21_POA_INDICATOR, ICD_DIAG_CD22_POA_INDICATOR, ICD_DIAG_CD23_POA_INDICATOR, ICD_DIAG_CD1, ICD_DIAG_CD2, ICD_DIAG_CD3, ICD_DIAG_CD4, ICD_DIAG_CD5, ICD_DIAG_CD6, ICD_DIAG_CD7, ICD_DIAG_CD8, ICD_DIAG_CD9, ICD_DIAG_CD10, ICD_DIAG_CD11, ICD_DIAG_CD12, ICD_DIAG_CD13, ICD_DIAG_CD14, ICD_DIAG_CD15, ICD_DIAG_CD16, ICD_DIAG_CD17, ICD_DIAG_CD18, ICD_DIAG_CD19, ICD_DIAG_CD20, ICD_DIAG_CD21, ICD_DIAG_CD22, ICD_DIAG_CD23, ICD_DIAG_CD1_TYPE, ICD_DIAG_CD2_TYPE, ICD_DIAG_CD3_TYPE, ICD_DIAG_CD4_TYPE, ICD_DIAG_CD5_TYPE, ICD_DIAG_CD6_TYPE, ICD_DIAG_CD7_TYPE, ICD_DIAG_CD8_TYPE, ICD_DIAG_CD9_TYPE, ICD_DIAG_CD10_TYPE, ICD_DIAG_CD11_TYPE, ICD_DIAG_CD12_TYPE, ICD_DIAG_CD13_TYPE, ICD_DIAG_CD14_TYPE, ICD_DIAG_CD15_TYPE, ICD_DIAG_CD16_TYPE, ICD_DIAG_CD17_TYPE, ICD_DIAG_CD18_TYPE, ICD_DIAG_CD19_TYPE, ICD_DIAG_CD20_TYPE, ICD_DIAG_CD21_TYPE, ICD_DIAG_CD22_TYPE, ICD_DIAG_CD23_TYPE, ICD_PROC_CD_1, ICD_PROC_CD_2, ICD_PROC_CD_3, ICD_PROC_CD_4, ICD_PROC_CD_5, ICD_PROC_CD_6, ICD_PROC_CD_7, ICD_PROC_CD_8, ICD_PROC_CD_9, ICD_PROC_CD_10, ICD_PROC_CD_11, ICD_PROC_CD_12, ICD_PROC_CD_13, ICD_PROC_CD_14, ICD_PROC_CD_15, ICD_PROC_CD_1_TYPE, ICD_PROC_CD_2_TYPE, ICD_PROC_CD_3_TYPE, ICD_PROC_CD_4_TYPE, ICD_PROC_CD_5_TYPE, ICD_PROC_CD_6_TYPE, ICD_PROC_CD_7_TYPE, ICD_PROC_CD_8_TYPE, ICD_PROC_CD_9_TYPE, ICD_PROC_CD_10_TYPE, ICD_PROC_CD_11_TYPE, ICD_PROC_CD_12_TYPE, ICD_PROC_CD_13_TYPE, ICD_PROC_CD_14_TYPE, ICD_PROC_CD_15_TYPE, NETWORK_PAID_STATUS, ORDERING_PROV_ID, Par_Flag, PAYMENT_AMT, PAY_PROCESS_DATE, PRINCIPLE_PROC_CD, PRINCIPLE_PROC_ICD_TYPE, PROC_CD_MODIFIER_1, PROC_CD_MODIFIER_2, PROC_CD_MODIFIER_3, PROC_CODE, REFERRING_PROV_ID, REQUESTED_AMT, REVENUE_CODE, SERVICE_FROM_DATE, SERVICE_TO_DATE, SERVICING_PROV_NPI, TYPE_OF_BILL_CODE
        |from (
        |
        |select
        |     	 distinct '{groupid}' 	     AS groupid
        |        ,'Medical' 		             AS datasrc
        |        ,{client_ds_id}		         AS client_ds_id
        |        ,nullif(concat_ws('', UHC_MEMBER, PROVIDER, upper(date_format(DOS, 'dd-MMM-yy')), upper(date_format(FROM_DT, 'dd-MMM-yy')), upper(date_format(TO_DT, 'dd-MMM-yy')), POS, TOS_N, REVENUE, PROCCODE, MOD_N, MOD_N_2, MOD_N_3, MOD_N_4, PLAN_SOURCE), '') AS CLAIM_HEADER_ID
        |	,Line_Nat						               AS CLAIM_LINE_ID
        |	,Uhc_Member						 AS MEMBER_ID
        |	,b.EMPLOYERACCOUNTID 		     AS PAYER_CODE
        |	,b.EMPLOYERACCOUNTID 		     AS PAYER_NAME
        |	,Pos		     AS PLACE_OF_SERVICE
        |	,Qty			     AS QUANTITY_OF_SERVICE
        |	,Dos 		      	     AS SERVICE_DATE
        |	,Provider		     AS SERVICING_PROV_ID
        |	,CASE
        |	WHEN TOS_N = 'FACIP' and date_format(From_Dt, 'yyyy') <> '9999'
        |	then From_Dt
        |	WHEN TOS_N = 'FACIP' and date_format(From_Dt, 'yyyy') = '9999'
        |	then DOS else NULL End 	     AS ADMIT_DATE
        |	,Admit_Source		     AS ADMIT_SOURCE_CODE
        |	,Amt_Eqv		     AS ALLOWED_AMT
        |	,Provider 		     AS ATTND_PROV_NPI
        |	,Prv_Sp_N	             AS ATTND_PROV_SPCLTY_CD
        |	,bill_prv		     AS BILLING_PROV_ID
        |	,bill_prv 		     AS BILLING_PROV_NPI
        |	,Amt_Cob	             AS COORD_BENIFITS_AMT
        |	,Cap_Flag	             AS CAPITATED_SERVICE_FLAG
        |	,Amt_Cap_Pay	             AS CAPITATION_AMT
        |	,CASE
        |	WHEN TOS_N in ('FACIP', 'FACOP') then 'I'
        |	WHEN   TOS_N = 'PROF' then 'P'
        |	else null END 		     AS CLAIM_TYPE
        |	,Amt_Coin	             AS COINSURANCE_AMT
        |	,Amt_Cop	             AS COPAY_AMT
        |	,Drg_N	                     AS DIAG_REL_GRP_CODE
        |	,CASE
        |	When Drg_Version = 'MS' then 'MSDRG'
        |	else Null END	    	     AS DIAG_REL_GRP_GROUPER
        |	,Drg_Outlier 		     AS DIAG_REL_GRP_OUTLIER
        |	,Drg_Level	             AS DIAG_REL_GRP_SEVERITY
        |	,Amt_Ded 		     AS DEDUCTABLE_AMT
        |	,Denied_Flag	             AS DENIED_FLAG
        |	,Denied_Ind	             AS DENIED_REASON
        |	,CASE WHEN TOS_N = 'FACIP' then To_Dt
        |	 else NULL END 	 	     AS DISCHARGE_DATE
        |	,Dis_Stat 		     AS DISCHARGE_STATUS_CODE
        |	,Poa_N	    	 	     AS ICD_DIAG_CD1_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD2_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD3_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD4_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD5_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD6_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD7_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD8_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD9_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD10_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD11_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD12_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD13_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD14_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD15_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD16_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD17_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD18_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD19_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD20_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD21_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD22_POA_INDICATOR
        |	,Poa_N	    	 	     AS ICD_DIAG_CD23_POA_INDICATOR
        |	,Diag1                       AS ICD_DIAG_CD1
        |	,Diag2		             AS ICD_DIAG_CD2
        |	,Diag3 		             AS ICD_DIAG_CD3
        |	,Diag4			     AS ICD_DIAG_CD4
        |	,Diag5 			     AS ICD_DIAG_CD5
        |	,Diag6 			     AS ICD_DIAG_CD6
        |	,Diag7			     AS ICD_DIAG_CD7
        |	,Diag8 			     AS ICD_DIAG_CD8
        |	,Diag9			     AS ICD_DIAG_CD9
        |	,Diag10 		     AS ICD_DIAG_CD10
        |	,Diag11 		     AS ICD_DIAG_CD11
        |	,Diag12 		     AS ICD_DIAG_CD12
        |	,Diag13 		     AS ICD_DIAG_CD13
        |	,Diag14 		     AS ICD_DIAG_CD14
        |	,Diag15 		     AS ICD_DIAG_CD15
        |	,Diag16 		     AS ICD_DIAG_CD16
        |	,Diag17			     AS ICD_DIAG_CD17
        |	,Diag18	    		     AS ICD_DIAG_CD18
        |	,Diag19	                     AS ICD_DIAG_CD19
        |	,Diag20			     AS ICD_DIAG_CD20
        |	,Diag21 		     AS ICD_DIAG_CD21
        |	,Diag22 		     AS ICD_DIAG_CD22
        |	,Diag23 		     AS ICD_DIAG_CD23
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD1_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD2_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD3_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD4_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD5_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD6_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD7_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD8_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD9_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD10_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD11_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD12_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD13_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD14_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD15_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD16_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD17_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD18_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD19_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD20_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD21_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD22_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_DIAG_CD23_TYPE
        |	,Case
        |	 when Iproc1 like '%00000%' Then Null
        |		else Iproc1 END	 AS ICD_PROC_CD_1
        |	,Case
        |	 when Iproc2 like '%00000%' Then Null
        |		else Iproc2 END  AS ICD_PROC_CD_2
        |	,Case
        |	 when Iproc3 like '%00000%' Then Null
        |		else Iproc3 END  AS ICD_PROC_CD_3
        |	,Case
        |	 when Iproc4 like '%00000%' Then Null
        |		else Iproc4 END AS ICD_PROC_CD_4
        |	,Case
        |	 when Iproc5 like '%00000%' Then Null
        |		else Iproc5 END AS ICD_PROC_CD_5
        |	,Case
        |	 when Iproc6 like '%00000%' Then Null
        |		else Iproc6 END  AS ICD_PROC_CD_6
        |	,Case
        |	 when Iproc7 like '%00000%' Then Null
        |		else Iproc7 END  AS ICD_PROC_CD_7
        |	,Case
        |	 when Iproc8 like '%00000%' Then Null
        |		else Iproc8 END  AS ICD_PROC_CD_8
        |	,Case
        |	 when Iproc9 like '%00000%' Then Null
        |		else Iproc9 END  AS ICD_PROC_CD_9
        |	,Case
        |	 when Iproc10 like '%00000%' Then Null
        |		else Iproc10 END  AS ICD_PROC_CD_10
        |	,Case
        |	 when Iproc11 like '%00000%' Then Null
        |		else Iproc11 END  AS ICD_PROC_CD_11
        |	,Case
        |	 when Iproc12 like '%00000%' Then Null
        |		else Iproc12 END  AS ICD_PROC_CD_12
        |	,Case
        |	 when Iproc13 like '%00000%' Then Null
        |		else Iproc13 END  AS ICD_PROC_CD_13
        |	,Case
        |	 when Iproc14 like '%00000%' Then Null
        |		else Iproc14 END  AS ICD_PROC_CD_14
        |	,Case
        |	 when Iproc15 like '%00000%' Then Null
        |		else Iproc15 END  AS ICD_PROC_CD_15
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |	 else null END 			AS ICD_PROC_CD_1_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_2_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_3_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_4_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_5_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_6_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_7_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_8_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_9_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_10_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_11_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_12_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_13_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_14_TYPE
        |	,CASE WHEN icd_version ='9' THEN 'ICD9'
        |	WHEN icd_version='0' THEN 'ICD10'
        |        else null END 		     AS ICD_PROC_CD_15_TYPE
        |	,Network_Paid_Status 	     AS NETWORK_PAID_STATUS
        |	,order_prv 		     AS ORDERING_PROV_ID
        |	,CASE
        |	WHEN network_status = '1' THEN 'Y'
        |	WHEN network_status ='0' THEN 'N'
        |	else NULL END 		     AS Par_Flag
        |	,Amt_Pay		     AS PAYMENT_AMT
        |	,Pay_Dt			     AS PAY_PROCESS_DATE
        |	,Iproc1			     AS PRINCIPLE_PROC_CD
        |	,CASE
        |	 WHEN icd_version ='9' THEN 'ICD9'
        |	 WHEN icd_version='0' THEN 'ICD10'
        |	 else null END 		     AS PRINCIPLE_PROC_ICD_TYPE
        |	,Mod_N			     AS PROC_CD_MODIFIER_1
        |	,Mod_N_2		     AS PROC_CD_MODIFIER_2
        |	,Mod_N_3		     AS PROC_CD_MODIFIER_3
        |	,Proccode		     AS PROC_CODE
        |	,ref_prv		     AS REFERRING_PROV_ID
        |	,Amt_Req		     AS REQUESTED_AMT
        |	,Revenue		     AS REVENUE_CODE
        |	,CASE
        | When YEAR(TO_DATE(from_dt,'yyyy-MM-dd HH:mm:ss' )) <> '9999'  then From_Dt
        |	else null             END   AS SERVICE_FROM_DATE
        |	,To_Dt			     AS SERVICE_TO_DATE
        |	,Provider 		     AS SERVICING_PROV_NPI
        |	,Bill_Type		     AS TYPE_OF_BILL_CODE
        |	,row_number() over(partition by UHC_MEMBER, PROVIDER, DOS, FROM_DT, TO_DT, POS, TOS_N, REVENUE, PROCCODE, MOD_N, MOD_N_2, MOD_N_3, MOD_N_4, PLAN_SOURCE order by transact_date desc nulls last) as rnk
        |	from MEDICAL M
        |	cross Join ZO_BPO_MAP_EMPLOYER b ON (b.client_ds_id = {client_ds_id})
        |	)
        |	Where rnk = 1
      """.stripMargin

    sparkSession.sql("""{intClaimMedicalQuery}"""
      .replace("{intClaimMedicalQuery}", intClaimMedicalQuery)
      .replace("{groupid}", loaderVars.groupId)
      .replace("{client_ds_id}", clientDsId)
    )
  }

  override def ignoreExtraColumnsInDataFrame: Boolean = true
}
package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.etl.commercial.gtt_prov_pat_rel
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}
import org.apache.spark.storage.StorageLevel

object GTT_PROV_PAT_REL_PATIENTS extends FEQueryAndMetadata[gtt_prov_pat_rel]{

  override def name: String = "GTT_PROV_PAT_REL_PATIENTS"

  override def dependsOn: Set[String] = Set("PATIENTS", "PATIENT")

  override def sparkSql: String =
    """
      |WITH uni_pat AS
      |(SELECT * FROM (
      |   SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pid, doctorid, modifieddate ORDER BY modifieddate) rn
      |   FROM PATIENTS p
      |   WHERE doctorid IS NOT NULL
      |   AND   doctorid <> '0'
      |   AND   pid IS NOT NULL
      |   AND   modifieddate IS NOT NULL)
      | WHERE rn = 1
      |  ),
      |aco_pat AS
      |(SELECT *
      | FROM UNI_PAT u
      |      JOIN PATIENT  c ON (u.pid = c.patientid AND
      |                                                c.client_ds_id = {client_ds_id}))
      |select groupid, datasrc, client_ds_id, providerid, patientid, localrelshipcode, startdate, enddate
      |from
      |(
      |SELECT '{groupid}' as groupid
      |	,'patients' as datasrc
      |	,{client_ds_id} as client_ds_id
      |	,'PCP'  AS localrelshipcode
      |	,p.patientid
      |	,p.providerid
      |	,p.startdate
      |	,current_date as enddate
      |
      |
      |FROM (
      |	SELECT  pid  AS patientid
      |		,doctorid  AS providerid
      |		,modifieddate  AS startdate
      |
      |	FROM ACO_PAT
      |	) p
      |
      |)
    """.stripMargin
}

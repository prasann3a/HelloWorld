package com.optum.cdr.fe.etl.commercial.icrc.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.pat_risk_attrib
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

object PAT_RISK_ATTRIB extends FETableInfo[pat_risk_attrib] {

  override def name: String = CDRFEParquetNames.pat_risk_attrib

  val intClaimMember = CDRFEParquetNames.int_claim_member

  override def dependsOn: Set[String] = Set("MEMBER_DETAIL", "ELIGIBILITY", "ZO_BPO_MAP_EMPLOYER", "MAP_PREDICATE_VALUES", intClaimMember)

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    var eligibilityDf = loadedDependencies("ELIGIBILITY")
    // Add this column with null value if this column is not present
    // This is because the stage parquets may/may not have this column, but the query needs this
    Seq("UHC_MEMBER").foreach(col => {
      eligibilityDf = if(!eligibilityDf.columns.contains(col)) eligibilityDf.withColumn(col, lit(null)) else eligibilityDf
    })
    eligibilityDf.createOrReplaceTempView("ELIGIBILITY")

    loadedDependencies("MEMBER_DETAIL").createOrReplaceTempView("MEMBER_DETAIL")
    loadedDependencies(intClaimMember).createOrReplaceTempView("INT_CLAIM_MEMBER")
    loadedDependencies("ZO_BPO_MAP_EMPLOYER").createOrReplaceTempView("ZO_BPO_MAP_EMPLOYER")

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val patRiskAttrMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "PAT_RISK_ATTR", "PAT_RISK_ATTR", "PAT_RISK_ATTR", "PATRISK").mkString(",")
    val patRiskAttrQuery = if (patRiskAttrMpv.contains(loaderVars.groupId))
        """
          |with DEDUPE_MEMDETAIL as
          |     ( select *
          |       from (select md.*
          |              ,row_number() over (partition by nullif(concat_ws('', SUB_MCARE_NBR, FILEID), '') order by ORIG_EFF desc nulls last ) as rn
          |             from MEMBER_DETAIL md
          |                )
          |       where rn=1
          |      )
          |
          |select groupid, datasrc, client_ds_id, END_DATE, PATIENTID, AT_RISK_STATUS, PROVIDERID, null as CONTRACT, START_DATE, contract_ID
          |from
          |(
          |select distinct '{groupid}' 					as groupid
          |       ,'Memeber_Detail' 				as datasrc
          |       ,{client_ds_id}			as client_ds_id
          |       ,icm.member_eff_date 			as start_date
          |       ,icm.member_end_date      	as end_date
          |       ,dmd.SUB_MCARE_NBR 				as patientid
          |       ,icm.Pcp_Id 					as providerid
          |       ,bme.employeraccountid 		as contract_ID
          |       ,case when transact_date is not null then 'Y' else 'N' end as AT_RISK_STATUS
          |       ,row_number() over (partition by SUB_MCARE_NBR, member_eff_date  order by transact_date  desc nulls last) as rowno
          | from DEDUPE_MEMDETAIL dmd
          | inner join INT_CLAIM_MEMBER icm on (dmd.SUB_MCARE_NBR=icm.MEMBER_ID)
          | cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
          |)
          |where rowno = 1
        """.stripMargin
    else
        """
          |select groupid, datasrc, client_ds_id, END_DATE, PATIENTID, AT_RISK_STATUS, PROVIDERID, CONTRACT, START_DATE, null as contract_ID
          |from
          |(
          |Select * from (
          |   select
          |     distinct '{groupid}' 	         AS groupid
          |        ,'Eligibility' 		 AS datasrc
          |        ,{client_ds_id}	 AS client_ds_id
          |	    ,End_Dt 		 AS END_DATE
          |	    ,Uhc_Member		 AS PATIENTID
          |	    ,At_Risk_Status		 AS AT_RISK_STATUS
          |	    ,Pcp_Id			 AS PROVIDERID
          |	    ,Z.EMPLOYERACCOUNTID     AS CONTRACT
          |	    ,Eff_Dt			 AS START_DATE
          |	    ,row_number() over(partition by uhc_member, eff_dt, end_dt, pcp_id order by transact_date desc nulls last) as rnk
          |  from ELIGIBILITY E
          |  cross join ZO_BPO_MAP_EMPLOYER Z on (Z.client_ds_id = {client_ds_id})
          |	)
          |	Where rnk = 1
          |)
        """.stripMargin

    sparkSession.sql("""{patRiskAttrQuery}"""
      .replace("{patRiskAttrQuery}",patRiskAttrQuery)
      .replace("{groupid}",loaderVars.groupId)
      .replace("{client_ds_id}",clientDsId)
    )
  }
}
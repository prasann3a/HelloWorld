package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE3 extends FEQueryAndMetadata[proceduredo]{

override def name: String = "PROCEDURE3"

override def dependsOn: Set[String] = Set("ENCOUNTERS")

override def sparkSql: String =
  """
    |SELECT  groupid
    |       ,datasrc
    |       ,{client_ds_id} AS client_ds_id
    |       ,patientid
    |       ,proceduredate
    |       ,localcode
    |       ,codetype
    |       ,encounterid
    |       ,localbillingproviderid
    |       ,orderingproviderid
    |       ,mappedcode
    |FROM
    |(
    |	SELECT  distinct '{groupid}'                                                                                          AS groupid
    |	       ,'encounters'                                                                                                  AS datasrc
    |	       ,e.imredemec_code                                                                                              AS patientid
    |	       ,e.enc_chartpulltime                                                                                           AS proceduredate
    |	       ,e.enc_billlevel                                                                                               AS localcode
    |	       ,CASE WHEN nullif(substr(e.enc_billlevel,2,1),'') IN ('D') THEN 'CPT4'
    |	             WHEN rlike(nullif(substr(e.enc_billlevel,1,5),''),'^[0-9]{4}[0-9A-Z]$') THEN 'CPT4'
    |	             WHEN rlike(nullif(substr(e.enc_billlevel,1,5),''),'^[A-Z]{1,1}[0-9]{4}$') THEN 'HCPCS'
    |	             WHEN rlike(nullif(substr(e.enc_billlevel,1,5),''),'^[0-9]{2,2}\\.[0-9]{1,2}$') THEN 'ICD9' ELSE NULL END AS codetype
    |	       ,e.imreenc_code                                                                                                AS encounterid
    |	       ,e.location_id                                                                                                 AS facilityid
    |	       ,e.enc_billingprov_code                                                                                        AS localbillingproviderid
    |	       ,e.imreprov_code                                                                                               AS orderingproviderid
    |	       ,CASE WHEN nullif(substr(e.enc_billlevel,2,1),'')='D' THEN '99213'
    |	             WHEN nullif(substr(e.enc_billlevel,2,1),'')='Z' THEN null ELSE e.enc_billlevel END                       AS mappedcode
    |	FROM ENCOUNTERS e
    |)
    |WHERE patientid is not null
    |AND localcode is not null
  """.stripMargin
}

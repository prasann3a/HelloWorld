package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, observation}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_STRUCTHPI extends FETableInfo[observation]{

  override def name: String = "OBSERVATION_STRUCTHPI"

  override def dependsOn: Set[String] = Set("STRUCTHPI", CDRFEParquetNames.clinicalencounter, "ZCM_OBSTYPE_CODE", "MAP_PREDICATE_VALUES", "ENC")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val obsdateColStructhpi = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTHPI", "OBSERVATION",
      "OBSERVATION", "OBSDATE_COL_NM").mkString(",")

    val obsdateColStructhpiCorrected = if (obsdateColStructhpi == "'NO_MPV_MATCHES'") "Structhpi.Hum_Date"
                                       else obsdateColStructhpi.replaceAll("\'","").replaceAll("Enc.ArrivalTime", "cEnc.ArrivalTime")

    val encDateJoinStructhpi = if (obsdateColStructhpiCorrected.toLowerCase == "enc.enc_date") "JOIN ENC enc on (structhpi.encounterid = enc.encounterid)" else "--"

    val obsdateFilterStructhpiS = if (obsdateColStructhpiCorrected.toLowerCase == "cenc.arrivaltime") "--" else s"AND $obsdateColStructhpiCorrected IS NOT NULL"

    val obsdateFilterStructhpiC = if (obsdateColStructhpiCorrected.toLowerCase == "cenc.arrivaltime") s"AND $obsdateColStructhpiCorrected IS NOT NULL" else "--"

    val listDetailid = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTHPI", "OBSERVATION",
      "OBSERVATION", "DETAILID").mkString(",")

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,obsdate
        |       ,localcode
        |       ,localresult
        |       ,obstype
        |       ,null              AS obsresult
        |       ,local_obs_unit
        |       ,obstype_std_units AS std_obs_unit
        |FROM
        |(
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                     AS groupid
        |		       ,'structhpi'                                     AS datasrc
        |		       ,{client_ds_id}                                  AS client_ds_id
        |		       ,nullif(SUBSTR(sc.hum_value,1,255),'')           AS localresult
        |		       ,concat_ws('','{client_ds_id_prefix}',sc.Itemid) AS localcode
        |		       ,obsdate
        |		       ,sc.Patientid                                    AS patientid
        |		       ,sc.Encounterid                                  AS encounterid
        |		       ,z.obstype
        |		       ,z.obsregex
        |		       ,z.obsconvfactor
        |		       ,z.datatype
        |		       ,z.begin_range
        |		       ,z.end_range
        |		       ,z.ROUND_PREC
        |		       ,z.localunit                                     AS local_obs_unit
        |		       ,z.obstype_std_units
        |		       ,z.localunit_cui
        |		       ,z.conv_Fact
        |		       ,z.function_applied
        |		       ,ROW_NUMBER() OVER (PARTITION BY sc.PatientID,sc.EncounterID,Sc.Itemid,z.obstype ORDER BY sc.obsdate DESC NULLS LAST) rn
        |		FROM
        |		(
        |			SELECT  *
        |			FROM
        |			(
        |				SELECT  Structhpi.*
        |				       ,{obsdate_col_structhpi} AS obsdate
        |				       ,cEnc.Patientid          AS patientid
        |				       ,ROW_NUMBER() OVER (PARTITION BY Structhpi.EncounterID,Structhpi.Itemid ORDER BY {obsdate_col_structhpi} DESC NULLS LAST) rn
        |				FROM STRUCTHPI Structhpi
        |				{encDateJoinStructhpi}
        |				JOIN
        |				(
        |					SELECT  *
        |					FROM
        |					(
        |						SELECT  Encounterid
        |						       ,Patientid
        |						       ,Client_ds_id
        |						       ,ArrivalTime
        |						       ,ROW_NUMBER() OVER (PARTITION BY EncounterID,Client_ds_id ORDER BY ArrivalTime DESC NULLS LAST) rn
        |						FROM {CLINICALENCOUNTER} cEnc
        |						WHERE Client_ds_id = {client_ds_id}
        |						{obsdateFilterStructhpi_C}
        |					) cEnc
        |					WHERE rn=1
        |				) cEnc
        |				ON (structhpi.encounterid = cEnc.encounterid AND cEnc.client_ds_id = {client_ds_id})
        |				WHERE Structhpi.hum_value IS NOT NULL
        |				{obsdateFilterStructhpi_S}
        |				AND Structhpi.Detailid IN ({list_detailid})
        |			)
        |			WHERE rn=1
        |		) sc
        |		JOIN ZCM_OBSTYPE_CODE z
        |		ON (z.obscode = concat_ws('', '{client_ds_id_prefix}', sc.itemid) AND z.groupid = '{groupid}' AND z.datasrc = 'structhpi')
        |	)
        |	WHERE rn = 1
        |)
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{obsdate_col_structhpi}", obsdateColStructhpiCorrected)
        .replace("{encDateJoinStructhpi}", encDateJoinStructhpi)
        .replace("{obsdateFilterStructhpi_S}", obsdateFilterStructhpiS)
        .replace("{obsdateFilterStructhpi_C}", obsdateFilterStructhpiC)
        .replace("{list_detailid}", listDetailid)
    )
  }


}

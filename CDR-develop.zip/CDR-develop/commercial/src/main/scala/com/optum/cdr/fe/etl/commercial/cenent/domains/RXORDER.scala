package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object RXORDER extends FEQueryAndMetadata[rxorder] {

  override def name: String = CDRFEParquetNames.rxorder

  override def dependsOn: Set[String] = Set("ZH_XMEDCN", "ORDERZ", "ZH_XSERVC", "ASSOCT")

  override def sparkSql: String =
    """
      |WITH uni_zxm AS
      |       ( SELECT * FROM (
      |         SELECT x.*, ROW_NUMBER() OVER (PARTITION BY SERV_DESCR_NUM ORDER BY DATA_TS DESC NULLS LAST) rn
      |         FROM ZH_XMEDCN x)
      |         WHERE rn = 1 ),
      |order AS
      |      ( SELECT        '{groupid}'                                                                              AS groupid
      |                     ,'orderz'                                                                                 AS datasrc
      |                     ,{client_ds_id}                                                                           AS client_ds_id
      |                     ,o.data_create_ts                                                                         AS issuedate
      |                     ,'O'                                    						                                      AS ordervsprescription
      |                     ,o.pat_person_num                                                                         AS patientid
      |                     ,nullif(concat_ws('', o.pat_person_num, date_format(o.data_create_ts,'yyyyMMddHHmmss'), o.serv_descr_num), '')         AS rxid
      |                     ,uni_zxm.cde                                                                              AS altmedcode
      |                     ,o.encntr_num                                                                             AS encounterid
      |                     ,o.fac_num                                                                                AS facilityid
      |                     ,NULL                                                       			                        AS localinfusionrate
      |                     ,NULL                                              				                                AS localinfusionvolume
      |                     ,o.freq_id                                                                                AS localdosefreq
      |                     ,NULL                                                                 		                AS localdoseunit
      |                     ,COALESCE(uni_zxm.Nm,Zh_Xservc.Nm)                                                        AS localdescription
      |                     ,o.serv_descr_num                                                                         AS localmedcode
      |                     ,uni_zxm.cde                                                                              AS localndc
      |                     ,nvl2(a.num, o.assoc_num, NULL)                                                           AS localproviderid
      |                     ,Coalesce(uni_ZXm.Med_Class_Id,nullif(trim(nullif(regexp_extract(Zh_Xservc.Nm,' (BOLUS|CAPS?|CRM|DRP|INH|INJ|IRR|IV|FLUSH|LOZENG|MDI|PATCH|PASTE|PUFFS?|NEB |SLT|SY[PRING]+|SUB[LQ]|SUSP?|(CHEW)?TABS?)', 0), '')), '')) AS localroute
      |                     ,Coalesce(uni_zxm.Med_Subclass_Id, nullif(trim(nullif(regexp_extract(Zh_Xservc.Nm,' (EARS?|EPIDURAL|EYE|IN[HJ]|I[MV]|FLUSH|GTUBE|MDI|NEB|OI?NT|OPH|PAT(CH)?|PO|RECTAL|SY[PRING]+|SUB[LQ]|SUP|TOP(IC)?(ALLY)?|TRANSD?ERMAL(LY)?|VAG(INALLY)?)($| )', 0), '')), '')) AS localform
      |                     ,nullif(regexp_extract(nullif(trim(regexp_extract(Zh_Xservc.Nm,' [0-9.,/%]+ ?[-A-Z0-9./%]+($| )', 0)), ''),'^[-0-9.,/%]+', 0), '') as LOCALSTRENGTHPERDOSEUNIT
      |                     ,nullif(regexp_extract(nullif(trim(regexp_extract(Zh_Xservc.Nm,' [0-9.,/%]+ ?[-A-Z0-9./%]+($| )', 0)), ''),'[A-Z%]+([-A-Z0-9./%]+)?', 0), '')  AS localstrengthunit
      |                     ,NULL                                                                           	       AS localtotaldose
      |                     ,NULL                                                                             	     AS fillnum
      |                     ,nullif(concat_ws('', o.order_status_cde, o.order_substatus_cde), '')                    AS orderstatus
      |                     ,NULL                                                                           	       AS quantityperfill
      |                     ,'0' 										                                                                 AS venue
      |            ,ROW_NUMBER() OVER (PARTITION BY nullif(concat_ws('', o.pat_person_num, date_format(o.data_create_ts,'yyyyMMddHHmmss'), o.serv_descr_num), '')
      |                               ORDER BY o.data_ts desc nulls first) rnum
      |       FROM ORDERZ o
      |       LEFT JOIN uni_zxm
      |            ON (o.serv_descr_num = uni_zxm.serv_descr_num )
      |       LEFT JOIN ZH_XSERVC ON (o.serv_descr_num = zh_xservc.num)
      |       left outer join
      |       (
      |         select distinct num
      |         from ASSOCT
      |         where assoct.type_cde = 'P'
      |       ) a on o.assoc_num = a.num
      |       WHERE o.serv_type_cde = 'MED' )
      |
      |SELECT groupid, datasrc, client_ds_id, issuedate, ordervsprescription, patientid, rxid, altmedcode, encounterid, facilityid, localinfusionrate, localinfusionvolume, localdosefreq, localdoseunit, localdescription, localform, localmedcode, localndc, localproviderid, localroute, localstrengthunit, localtotaldose, fillnum, orderstatus, quantityperfill, venue, LOCALSTRENGTHPERDOSEUNIT
      |FROM order
      |WHERE rnum = 1
    """.stripMargin
}
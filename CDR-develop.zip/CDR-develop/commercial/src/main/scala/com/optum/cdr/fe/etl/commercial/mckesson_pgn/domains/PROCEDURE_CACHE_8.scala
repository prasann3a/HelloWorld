package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object PROCEDURE_CACHE_8 extends FEQueryAndMetadata[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_8"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TMC100_MED_RCN_HDR","MAP_CUSTOM_PROC")

  override def sparkSql: String =
    """
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
      |from
      |(
      |SELECT '{groupid}'         	 AS groupid
      |      ,'med_rcn_hdr'             AS datasrc
      |      ,{client_ds_id}             AS client_ds_id
      |      ,'MEDREC'                  AS localcode
      |      ,rcn.Psn_Int_Id   	 AS patientid
      |      ,rcn.ety_dt                AS proceduredate
      |      ,rcn.Vst_Int_Id 	 	 AS encounterid
      |      ,NULL                      AS orderingproviderid
      |      ,'MEDREC'                  AS localname
      |      ,NULL              	 AS procseq
      |      ,NULL                      AS proc_end_date
      |      ,NULL 			 AS hosp_px_flag
      |      ,'CUSTOM'  		 AS codetype
      |      ,NULL                      AS localprincipleindicator
      |      ,map.mappedvalue           AS mappedcode
      |      ,NULL        		 AS performingproviderid
      |      ,rcn.ety_dt                AS actualprocdate
      |      ,ROW_NUMBER() OVER (PARTITION BY rcn.Psn_Int_Id, rcn.Vst_Int_Id,rcn.ety_dt
      |                               ORDER BY rcn.Lst_Mod_Ts DESC NULLS LAST) rn
      |FROM MCKESSON_PGN_V1_TMC100_MED_RCN_HDR rcn
      |   CROSS JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
      |                               map.datasrc = 'med_rcn_hdr' AND
      |   			       map.localcode = 'MEDREC')
      |WHERE rcn.Psn_Int_Id IS NOT NULL
      |  AND rcn.ety_dt IS NOT NULL
      |  AND rcn.row_sta_cd <> 'D'
      |  AND rcn.OBS_dt IS NULL
      |)
      |where proceduredate IS NOT NULL AND patientid IS NOT NULL
    """.stripMargin
}

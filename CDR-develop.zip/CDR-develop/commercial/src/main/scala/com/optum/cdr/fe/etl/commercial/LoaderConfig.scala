package com.optum.cdr.fe.etl.commercial

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.cdr.fe.etl.commercial.aspro.domains.{AsproQueries, AsproQueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.cattails.domains.{CattailsQueries, CattailsQueriesDrugAssign}
import com.optum.cdr.fe.etl.commercial.cenent.domains.CenentQueriesWithDrugAssign
import com.optum.cdr.fe.etl.commercial.centricv2.domains.{Centricv2Queries, Centricv2QueriesH770494, Centricv2QueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.cernerasp.domains.CerneraspQueries
import com.optum.cdr.fe.etl.commercial.cernerasp.domains.CerneraspQueriesDrugAssign
import com.optum.cdr.fe.etl.commercial.cigna_cm.domains.CignaCmQueries
import com.optum.cdr.fe.etl.commercial.cust_pay_aetna.domains.custPayAetnaQueries
import com.optum.cdr.fe.etl.commercial.ecw.domains.{EcwQueries, EcwQueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.eods.domains.EodsQueries
import com.optum.cdr.fe.etl.commercial.huamana.domains.{HumanaMDSPQueries, HumanaQueries}
import com.optum.cdr.fe.etl.commercial.icrc.domains.IcrcQueries
import com.optum.cdr.fe.etl.commercial.lss.domains.LssQueries
import com.optum.cdr.fe.etl.commercial.mckesson.domains.{McKessonQueries, McKessonQueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains.MckessonPgnQueriesWithDrugAssign
import com.optum.cdr.fe.etl.commercial.med3000.domains.Med3000Queries
import com.optum.cdr.fe.etl.commercial.meditechdr.domains.{MeditechdrDrugAssign, MeditechdrQueries}
import com.optum.cdr.fe.etl.commercial.meditechv6.domains.Meditechv6Queries
import com.optum.cdr.fe.etl.commercial.misys.domains.MisysQueries
import com.optum.cdr.fe.etl.commercial.mssp.domains.{MsspH053731Queries, MsspH178829Queries, MsspH223937Queries, MsspQueries, MsspQueriesH218}
import com.optum.cdr.fe.etl.commercial.nextgen.domains.H642453_cust_nextgen.{H642453CustNextgenQueries, H642453CustNextgenQueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.nextgen.domains.H770635_cust_nextgen.{H770635CustNextgenQueries, H770635CustNextgenQueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.nextgen.domains.H984442.{NextgenH984442Queries, NextgenH984442QueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.nextgen.domains.dict_nexgen.{dictNexgenQueries, dictNexgenQueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.oa_standard_claims.domains.H770494.H770494OaStandardCaimsQueries
import com.optum.cdr.fe.etl.commercial.oa_standard_claims.domains.OaStandardCaimsQueries
import com.optum.cdr.fe.etl.commercial.odxflatfile.domains.OdxflatfileQueries
import com.optum.cdr.fe.etl.commercial.odxjson.domains.OdxjsonQueries
import com.optum.cdr.fe.etl.commercial.population_segmentation.domains.PopulationSegmentationQueries
import com.optum.cdr.fe.etl.commercial.practicefusion.domains.PracticeFusionQueriesDrugAssign
import com.optum.cdr.fe.etl.commercial.premera.domains.PremeraQueries
import com.optum.cdr.fe.etl.commercial.ric.domains.{RicQueries, RicQueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.sage.domains.{SageQueries, SageQueriesWithDrugAssign}
import com.optum.cdr.fe.etl.commercial.ricv2.domains.{Ricv2_ClinicalQueries, Ricv2_ClinicalQueriesWithDrugAssign, Ricv2_IdxQueries}
import com.optum.cdr.fe.etl.commercial.salesforcecc.domains.{OCCPQueries, SalesForceccQueries}
import com.optum.cdr.fe.etl.commercial.scm.domains.ScmQueriesWithDrugAssign
import com.optum.cdr.fe.etl.commercial.soarian.domains.SoarianQueries
import com.optum.cdr.fe.etl.commercial.std_payer_maps.domains.StdPayerMapsQueries
import com.optum.cdr.fe.etl.commercial.std_prov.stage1.domains.{StdProvH984216Queries, StdProvQueries}
import com.optum.cdr.fe.etl.commercial.uhc.domains.{H200272UHCQueries, H636663UHCQueries, H770494UHCQueries}
import com.optum.cdr.fe.etl.commercial.wellmark.domains.{WellmarkH328218Queries, WellmarkH827927Queries}

object LoaderConfig {
  val CLIENT_QUERIES_MAP: Map[String, BaseQueryConfig] = Map(
    // Maintain alphabetical order while adding new BaseQueryConfig
    //First by the commercial client name then by source_dsid

    "H717614_2801" -> AsproQueries
    , "H770635_45" -> AsproQueriesWithDrugAssign

    , "H984787_6244"  -> CattailsQueries
    // H984787 is migrated to H984216
    , "H984216_6244"  -> CattailsQueriesDrugAssign

    , "H064317_883"   -> Centricv2Queries
    , "H303173_6365"  -> Centricv2Queries
    // H984787 clients were moved to H984216, so adding 6504 as part of H984216
    , "H984216_6504"  -> Centricv2QueriesWithDrugAssign
    // H770494 Centricv2 alone have an additional query migrated from post_hadoop
    , "H770494_11014" -> Centricv2QueriesH770494
    , "H770494_9909"  -> Centricv2QueriesH770494

    , "H200272_10308" -> Centricv2QueriesWithDrugAssign
    , "H302436_1841"  -> Centricv2QueriesWithDrugAssign
    , "H984787_6504"  -> Centricv2QueriesWithDrugAssign


    , "H984216_6544" -> CenentQueriesWithDrugAssign

    , "H328218_5104" -> CerneraspQueriesDrugAssign

    , "H591965_1782" -> EcwQueries
    , "H772763_6744" -> EcwQueriesWithDrugAssign
    , "H827927_5944" -> EcwQueries
    // H984's clients were moved to H984216
    , "H984216_2062" -> EcwQueriesWithDrugAssign
    , "H984216_2063" -> EcwQueriesWithDrugAssign
    , "H984216_2064" -> EcwQueriesWithDrugAssign
    , "H984216_4346" -> EcwQueriesWithDrugAssign
    , "H984216_4946" -> EcwQueriesWithDrugAssign
    , "H984216_4947" -> EcwQueriesWithDrugAssign

    , "H827927_9520" -> IcrcQueries
    , "H834852_10810" -> IcrcQueries

    , "H984787_6704" -> LssQueries
    , "H984787_6705" -> LssQueries
    , "H984787_6706" -> LssQueries
    // H984787 clients were moved to H984216
    , "H984216_6704"  -> LssQueries
    , "H984216_6705"  -> LssQueries
    , "H984216_6706"  -> LssQueries

    , "H984216_5464" -> McKessonQueriesWithDrugAssign

    , "H984216_5726" -> McKessonQueriesWithDrugAssign
    , "H984216_5727" -> McKessonQueriesWithDrugAssign

    , "H200272_10088"  -> MckessonPgnQueriesWithDrugAssign

    , "H542284_3062"   -> Med3000Queries

    /*
      MeditechdrextraQueries will have one additional query called MEDICATION_MAP_SRC that's not present in MeditechdrQueries.
      This is because only clients H984833_5223 and H984112_4827 use this  extra query.
     */
    , "H984216_3081"  -> MeditechdrDrugAssign
    , "H984216_5223"  -> MeditechdrDrugAssign
    , "H984216_4827"  -> MeditechdrDrugAssign
    , "H984787_6211"  -> MeditechdrQueries
    , "H984787_6284"  -> MeditechdrQueries
    , "H984787_6287"  -> MeditechdrQueries
    , "H984787_6266"  -> MeditechdrQueries
    , "H984951_4826"  -> MeditechdrQueries
    , "H251512_3072"  -> MeditechdrQueries
    , "H340651_121"   -> MeditechdrQueries

    , "H984216_6211"  -> MeditechdrDrugAssign
    , "H984216_6284"  -> MeditechdrDrugAssign
    , "H984216_4826"  -> MeditechdrDrugAssign
    , "H984216_6266"  -> MeditechdrDrugAssign
    , "H984216_6287"  -> MeditechdrDrugAssign

    , "H984216_8738"  -> Meditechv6Queries

    , "H984216_2941"  -> MisysQueries
    , "H984216_4370"  -> MisysQueries
    , "H984216_4689"  -> MisysQueries
    , "H984216_5008"  -> MisysQueries
    , "H984216_5624"  -> MisysQueries
    , "H984926_2941"  -> MisysQueries
    , "H984926_4370"  -> MisysQueries
    , "H984926_4689"  -> MisysQueries
    , "H984926_5008"  -> MisysQueries
    , "H984926_5624"  -> MisysQueries

    // client_ds_ids loading nextgen commercial
    , "H302436_11314" -> dictNexgenQueries
    , "H558781_10352" -> dictNexgenQueriesWithDrugAssign
    , "H834852_2041" -> dictNexgenQueriesWithDrugAssign
    , "H969581_10515" -> dictNexgenQueriesWithDrugAssign
    , "H969719_3161" -> dictNexgenQueries
    , "H984945_5463" -> dictNexgenQueries

    // client_ds_ids loading nextgen commercial + some client specific queries
    , "H642453_8388" -> H642453CustNextgenQueriesWithDrugAssign
    , "H770635_3063" -> H770635CustNextgenQueriesWithDrugAssign
    , "H984442_422" -> NextgenH984442Queries
    , "H984442_423" -> NextgenH984442Queries
    , "H984216_422" -> NextgenH984442QueriesWithDrugAssign
    , "H984216_423" -> NextgenH984442QueriesWithDrugAssign

    , "H704847_9382" -> OdxflatfileQueries
    , "H969644_10851" -> OdxflatfileQueries

    , "H969644_11310"  -> OdxjsonQueries
    , "H000444_11291"  -> OdxjsonQueries
    , "H969979_11568"  -> OdxjsonQueries

    , "H328218_5730" -> PopulationSegmentationQueries
    , "H328218_5764" -> PopulationSegmentationQueries
    //, "H328218_7788" -> PopulationSegmentationQueries [Retired - CDRSCALE-4048]
    , "H782252_11449" -> PracticeFusionQueriesDrugAssign

    , "H770494_10946" -> PremeraQueries
    , "H770494_10993" -> PremeraQueries
    , "H770494_10953" -> PremeraQueries
    , "H770494_10969" -> PremeraQueries

    , "H135535_7556" -> SalesForceccQueries
    , "H135535_9409" -> SalesForceccQueries
    , "H135772_7555" -> SalesForceccQueries
    , "H135772_9590" -> SalesForceccQueries
    , "H171267_8528" -> SalesForceccQueries
    , "H303173_7389" -> SalesForceccQueries
    , "H303173_9383" -> SalesForceccQueries
    , "H328218_7648" -> SalesForceccQueries
    , "H416989_6645" -> SalesForceccQueries
    , "H451171_7390" -> SalesForceccQueries
    , "H451171_9309" -> SalesForceccQueries
    , "H542284_6644" -> SalesForceccQueries
    , "H542284_9448" -> SalesForceccQueries
    , "H591965_4623" -> SalesForceccQueries
    , "H908583_4624" -> SalesForceccQueries
    , "H984216_8148" -> SalesForceccQueries

    , "H171267_9768" -> OCCPQueries
    , "H223937_11688" -> OCCPQueries
    , "H236119_9648" -> OCCPQueries
    , "H642453_9658" -> OCCPQueries
    , "H743123_9583" -> OCCPQueries
    , "H984216_9528" -> OCCPQueries

    , "H053731_1901" -> SoarianQueries

    , "H984216_3082" -> ScmQueriesWithDrugAssign
    , "H984216_3083" -> ScmQueriesWithDrugAssign
    , "H984216_2781" -> ScmQueriesWithDrugAssign
    , "H984216_4663" -> ScmQueriesWithDrugAssign

    , "H147747_11008" -> StdPayerMapsQueries
    , "H178829_10606" -> StdPayerMapsQueries
    , "H200272_9930" -> StdPayerMapsQueries
    , "H218562_10189" -> StdPayerMapsQueries
    , "H223937_11290" -> StdPayerMapsQueries
    , "H319046_10675" -> StdPayerMapsQueries
    , "H558781_10674" -> StdPayerMapsQueries
    , "H623622_9688" -> StdPayerMapsQueries
    , "H636663_10569" -> StdPayerMapsQueries
    , "H641171_11208" -> StdPayerMapsQueries
    , "H770494_10953" -> StdPayerMapsQueries
    , "H770635_10516" -> StdPayerMapsQueries
    , "H831111_11288" -> StdPayerMapsQueries
    , "H834852_11150" -> StdPayerMapsQueries
    , "H942522_10588" -> StdPayerMapsQueries
    , "H973241_10828" -> StdPayerMapsQueries
    , "H984216_9471" -> StdPayerMapsQueries
    , "H993781_10351" -> StdPayerMapsQueries


    , "H053731_10192" -> StdProvQueries
    , "H147747_10942" -> StdProvQueries
    , "H178829_10850" -> StdProvQueries
    , "H218562_10150" -> StdProvQueries
    , "H223937_11281" -> StdProvQueries
    , "H319046_10729" -> StdProvQueries
    , "H558781_10468" -> StdProvQueries
    , "H636663_10568" -> StdProvQueries
    , "H770494_10969" -> StdProvQueries
    , "H770635_10149" -> StdProvQueries
    , "H831111_11028" -> StdProvQueries
    , "H834852_11090" -> StdProvQueries
    , "H942522_10549" -> StdProvQueries
    , "H973241_10914" -> StdProvQueries
    , "H984216_9455" -> StdProvH984216Queries
    , "H993781_10354" -> StdProvQueries

    , "H942522_7553" -> SageQueriesWithDrugAssign

    , "H328218_4890" -> WellmarkH328218Queries
    , "H328218_5109" -> WellmarkH328218Queries
    , "H328218_6987" -> WellmarkH328218Queries
    , "H827927_4945" -> WellmarkH827927Queries

    ,"H200272_9549" -> H200272UHCQueries
    ,"H770494_10908" -> H770494UHCQueries
    ,"H636663_10748" -> CignaCmQueries
    ,"H636663_10758" -> CignaCmQueries
    ,"H636663_10771" -> H636663UHCQueries
    ,"H770494_10916" -> CignaCmQueries

    , "H053731_5023" -> MsspH053731Queries
    , "H178829_9288" -> MsspH178829Queries
    , "H223937_11429" -> MsspH223937Queries
    , "H218562_7089" -> MsspQueries
    , "H236119_9412" -> MsspQueries
    , "H236119_9249" -> MsspQueries
    , "H319046_10548" -> MsspQueries
    , "H557454_4324" -> MsspQueries
    , "H558781_10514" -> MsspQueries
    , "H623622_9519" -> MsspQueries
    , "H770635_9931" -> MsspQueries
    , "H827927_5543" -> MsspQueries
    , "H827927_9469" -> MsspQueries
    , "H827927_8733" -> MsspQueries
    , "H827927_7327" -> MsspQueries
    , "H925467_7568" -> MsspQueries
    , "H984186_4305" -> MsspQueries
    , "H984216_4305" -> MsspQueries
    , "H984216_7429" -> MsspQueries
    , "H984216_7430" -> MsspQueries
    , "H984216_7431" -> MsspQueries
    , "H984216_7427" -> MsspQueries
    , "H984216_7432" -> MsspQueries
    , "H984216_7428" -> MsspQueries
    , "H993781_10209" -> MsspQueries
    , "H993781_10208" -> MsspQueries
    , "H147747_10911" -> MsspQueries
    , "H147747_11269" -> MsspQueries
    , "H147747_11249" -> MsspQueries
    , "H147747_11270" -> MsspQueries
    , "H636663_10788" -> MsspQueries
    , "H636663_10930" -> MsspQueries
    , "H770494_10912" -> MsspQueries
    , "H973241_10770" -> MsspQueries
    , "H984216_11489" -> MsspQueries

    , "H636663_10934" -> custPayAetnaQueries
    , "H770494_10910" -> custPayAetnaQueries
    , "H770494_10951" -> custPayAetnaQueries

    , "H770494_11112" -> OaStandardCaimsQueries
    , "H770494_10938" -> OaStandardCaimsQueries
    , "H770494_10915" -> OaStandardCaimsQueries
    , "H770494_11111" -> OaStandardCaimsQueries
    , "H770494_10996" -> OaStandardCaimsQueries
    , "H770494_10995" -> OaStandardCaimsQueries
    , "H770494_10998" -> OaStandardCaimsQueries
    , "H770494_10997" -> OaStandardCaimsQueries
    , "H770494_11189" -> H770494OaStandardCaimsQueries
    , "H770494_11190" -> H770494OaStandardCaimsQueries
    , "H770494_11188" -> H770494OaStandardCaimsQueries
    , "H770494_11191" -> H770494OaStandardCaimsQueries
    , "H770494_10935" -> OaStandardCaimsQueries
    , "H770494_11070" -> OaStandardCaimsQueries
    , "H969222_3901" ->  EodsQueries
    , "H973241_10769" -> HumanaQueries
    , "H636663_10952" -> HumanaQueries
    , "H636663_10760" -> HumanaQueries
    , "H636663_10808" -> HumanaQueries
    , "H636663_11168" -> HumanaQueries
    , "H770494_10948"-> HumanaMDSPQueries

    , "H956115_11283" -> RicQueriesWithDrugAssign
    , "H883627_11413" -> RicQueriesWithDrugAssign
    , "H122141_11414" -> RicQueriesWithDrugAssign
    , "H291527_11431" -> RicQueriesWithDrugAssign
    , "H362535_11452" -> RicQueriesWithDrugAssign
    , "H648522_11430" -> RicQueriesWithDrugAssign
  )

}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.patient_attribute
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTCUSTOMATTRIBUTE extends FEQueryAndMetadata[patient_attribute] {

  override def name: String = CDRFEParquetNames.patient_attribute

  override def dependsOn: Set[String] = Set(CDRFEParquetNames.patient)

  override def sparkSql: String =
    """
      |select distinct
      |    datasrc                  as datasrc
      |    ,patientid                as patientid
      |    ,{client_ds_id}           as attribute_value
      |    ,case when {client_ds_id} = 9909     then 'CH002785' --WWMG Centricity
      |          when {client_ds_id} = 11014    then 'CH002787' --SFM Centricity
      |     end                      as attribute_type_cui
      |from patient
      |where patientid is not null
    """.stripMargin
}

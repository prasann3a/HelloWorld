package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, observation}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_STRUCTSOCIALHISTORY extends FETableInfo[observation]{

  override def name: String = "OBSERVATION_STRUCTSOCIALHISTORY"

  override def dependsOn: Set[String] = Set("STRUCTSOCIALHISTORY", CDRFEParquetNames.clinicalencounter, "ZCM_OBSTYPE_CODE", "MAP_PREDICATE_VALUES", "ENC")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val listItemidSocialhist = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTSOCIALHISTORY", "OBSERVATION",
      "STRUCTSOCIALHISTORY", "ITEMID").mkString(",")

    val obsdateColHist = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTSOCIALHISTORY", "OBSERVATION",
      "OBSERVATION", "OBSDATE_COL_NM").mkString(",")
    val obsdateColHistCorrected = if (obsdateColHist == "'NO_MPV_MATCHES'") "hist.Hum_Date"
                                  else s"replace($obsdateColHist,'\'',NULL)"

    val encDateJoinHist = if (obsdateColHistCorrected.toLowerCase == "enc.enc_date") "JOIN ENC enc on (hist.encounterid = enc.encounterid)" else "--"

    val listDetailid = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "STRUCTSOCIALHISTORY", "OBSERVATION",
      "OBSERVATION", "DETAILID").mkString(",")

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,obsdate
        |       ,localcode
        |       ,localresult
        |       ,obstype
        |       ,null              AS obsresult
        |       ,local_obs_unit
        |       ,obstype_std_units AS std_obs_unit
        |FROM
        |(
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                                                           AS groupid
        |		       ,'structsocialhistory'                                                                                                 AS datasrc
        |		       ,{client_ds_id}                                                                                                        AS client_ds_id
        |		       ,CASE WHEN hist.itemid IN ({list_itemid_socialhist}) THEN 'Completed' ELSE nullif(SUBSTR(hist.Hum_Value,1,255),'') END AS localresult
        |		       ,concat_ws('','{client_ds_id_prefix}',hist.Itemid)                                                                     AS localcode
        |		       ,obsdate
        |		       ,cEnc.Patientid                                                                                                        AS patientid
        |		       ,hist.Encounterid                                                                                                      AS encounterid
        |		       ,z.obstype
        |		       ,z.obsregex
        |		       ,z.obsconvfactor
        |		       ,z.datatype
        |		       ,z.begin_range
        |		       ,z.end_range
        |		       ,z.ROUND_PREC
        |		       ,z.localunit                                                                                                           AS local_obs_unit
        |		       ,z.obstype_std_units
        |		       ,z.localunit_cui
        |		       ,z.conv_Fact
        |		       ,z.function_applied
        |		       ,ROW_NUMBER() OVER (PARTITION BY cEnc.PatientID,cEnc.EncounterID,hist.Itemid,z.obstype ORDER BY obsdate DESC NULLS LAST) rn
        |		FROM
        |		(
        |			SELECT  *
        |			FROM
        |			(
        |				SELECT  hist.*
        |				       ,{obsdate_col_hist} AS obsdate
        |				       ,ROW_NUMBER() OVER (PARTITION BY hist.EncounterID,hist.Itemid ORDER BY {obsdate_col_hist} DESC NULLS LAST) rn
        |				FROM STRUCTSOCIALHISTORY hist
        |       {encDateJoinHist}
        |				WHERE hist.hum_value IS NOT NULL
        |				AND {obsdate_col_hist} IS NOT NULL
        |				AND hist.detailid IN ({list_detailid})
        |			)
        |			WHERE rn=1
        |		) hist
        |		JOIN {CLINICALENCOUNTER} cEnc
        |		  ON (hist.encounterid = cEnc.encounterid AND cEnc.client_ds_id = {client_ds_id} )
        |		JOIN ZCM_OBSTYPE_CODE z
        |		  ON (z.obscode = concat_ws('', '{client_ds_id_prefix}', hist.itemid) AND z.groupid = '{groupid}' AND z.datasrc = 'structsocialhistory')
        |	)
        |	WHERE rn = 1
        |)
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{list_itemid_socialhist}", listItemidSocialhist)
        .replace("{obsdate_col_hist}", obsdateColHistCorrected)
        .replace("{encDateJoinHist}", encDateJoinHist)
        .replace("{list_detailid}", listDetailid)
    )
  }
}

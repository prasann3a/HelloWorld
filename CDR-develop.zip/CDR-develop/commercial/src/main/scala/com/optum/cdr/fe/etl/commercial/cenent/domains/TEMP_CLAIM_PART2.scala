package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object TEMP_CLAIM_PART2 extends FEQueryAndMetadata[claim] {

  override def name: String = "TEMP_CLAIM_PART2"

  override def dependsOn: Set[String] = Set("TEMP_CLAIM_PROC_CACHE2")

  override def sparkSql: String =
    """
      |select distinct groupid, datasrc, client_ds_id, claimid, patientid, servicedate,
      |facilityid, localrev, localcode as localcpt, CAST(quantity AS INT), procseq as seq, charge,
      | performingproviderid as claimproviderid, localcode as mappedcpt, encounterid, localrev as mappedrev
      |from
      |(
      |TEMP_CLAIM_PROC_CACHE2
      |)
      |where servicedate is not null and claimid is not null and patientid is not null
    """.stripMargin

}

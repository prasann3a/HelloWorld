package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CHARGE_PROCS extends FEQueryAndMetadata[proceduredo]{

  override def name: String = "PROCEDURE_CHARGE_PROCS"

  override def dependsOn: Set[String] = Set("MED3000_CHARGE_PROCEDURES","MED3000_ZH_PROC_MASTER","MED3000_CHARGE_TICKET_MASTER")

  override def sparkSql: String =
    """
     select groupid, datasrc, client_ds_id, localcode, patientid, proceduredate, encounterid, localname, procseq, mappedcode, codetype, performingproviderid
 |from
 |(
 |select '{groupid}'         as groupid
 |       ,'charge_procs'      as datasrc
 |       ,{client_ds_id}       as client_ds_id
 |       ,proc.Procedure_Code   as localcode
 |       ,tict_mast.Blind_Key   as patientid
 |       ,tict_mast.Charge_Date   as proceduredate
 |       ,tict_mast.Appt_Id     as encounterid
 |       ,proc_mast.Description   as localname
 |       ,tict_mast.Clinician   as performingproviderid
 |       ,proc.Ct_Proc_Seq      as procseq
 |       ,lpad(proc.Procedure_Code,5,'0')   as mappedcode
 |       ,case when rlike(nullif(substr(proc.Procedure_Code,1,5), ''),'^[0-9]{4}[0-9A-Z]$')        then 'CPT4'
 |             when rlike(nullif(substr(proc.Procedure_Code,1,5), ''),'^[A-Z]{1,1}[0-9]{4}$')      then 'HCPCS'
 |             when rlike(nullif(substr(proc.Procedure_Code,1,5), ''), '^[0-9]{2,2}\\.[0-9]{1,2}$') then 'ICD9'
 |        end as codetype
 |     ,row_number() over (partition by tict_mast.Appt_Id,proc.Procedure_Code,proc.Ct_Proc_Seq order by proc.Update_Date desc nulls last) as rank_proc
 |  from MED3000_CHARGE_PROCEDURES proc
 | inner join MED3000_ZH_PROC_MASTER proc_mast          on (proc.Procedure_Code = proc_mast.Procedure_Code)
 | inner join MED3000_CHARGE_TICKET_MASTER tict_mast on (proc.ICChart_CT_ID = tict_mast.ICChart_CT_ID)
 |
 |
 |)
 |where  proceduredate is not null and patientid is not null
 |
    """.stripMargin


}

package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object MEDICATION_MAP_SRC_ALLERGIES extends FEQueryAndMetadata[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_ALLERGIES"

  override def dependsOn: Set[String] = Set("MCKESSON_ENT_CPI_ALLERGY")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs
      |from
      |(
      |SELECT '{groupid}' AS groupid
      |        ,'ent_cpi_allergy' AS datasrc
      |	,{client_ds_id} AS client_ds_id
      |        ,nullif(LTRIM(nullif(RTRIM(nullif(regexp_extract(LOWER(allergen_description), '[0-9a-z /s]+', 0), '')), '')), '') AS localmedcode
      |        ,NULL AS localndc
      |        ,nullif(LTRIM(nullif(RTRIM(nullif(regexp_extract(LOWER(allergen_description), '[0-9a-z /s]+', 0), '')), '')), '') AS localdescription
      |        ,COUNT(*) AS no_ndc
      |        ,0        AS has_ndc
      |        ,COUNT(*) AS num_recs
      |FROM MCKESSON_ENT_CPI_ALLERGY
      |GROUP BY COALESCE(allergen_code, nullif(LTRIM(nullif(RTRIM(nullif(regexp_extract(LOWER(allergen_description), '[0-9a-z /s]+', 0), '')), '')), '')),
      |         nullif(LTRIM(nullif(RTRIM(nullif(regexp_extract(LOWER(allergen_description), '[0-9a-z /s]+', 0), '')), '')), '')
      |)
    """.stripMargin

}

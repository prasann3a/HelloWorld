package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.prov_spec
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROVIDERSPECIALTY extends FETableInfo[prov_spec] {

  override def name: String = "PROVIDERSPECIALTY"

  override def dependsOn: Set[String] = Set("CENTRICV2_ZH_STAFFREG")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val sqlQuery =
      """
        |select GROUPID, LOCALPROVIDERID, LOCALSPECIALTYCODE, LOCALCODESOURCE, CLIENT_DS_ID, LOCAL_CODE_ORDER
        |from
        |(
        |select distinct
        |       '{groupid}' AS GROUPID
        |       ,pvid AS LOCALPROVIDERID
        |       ,concat_ws('', 'cen.', specialty) AS LOCALSPECIALTYCODE
        |       ,'zh_provider' AS LOCALCODESOURCE
        |       ,'{client_ds_id}' AS CLIENT_DS_ID
        |       ,1 AS LOCAL_CODE_ORDER
        |       from CENTRICV2_ZH_STAFFREG p
        |       where specialty <> '0'
        |
        |)
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId)

    sparkSession.sql(sqlQuery)
  }

}
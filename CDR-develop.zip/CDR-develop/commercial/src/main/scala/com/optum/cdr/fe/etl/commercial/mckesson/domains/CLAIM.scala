package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader,CDRFEParquetNames}
import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import org.apache.spark.sql.{DataFrame, SparkSession}

object CLAIM extends FETableInfo[claim] {
  override def name: String = CDRFEParquetNames.claim

  override def dependsOn: Set[String] = Set("MCKESSON_HHS_CPI_PROCEDURE", "MCKESSON_ZH_ENT_CONFIG_CODE_SET" , "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val inclClaimMpMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "HHS_CPI_PROCEDURE", "CLAIM", "HHS_CPI_PROCEDURE", "PROCEDURE_REPORTED_BY_LSEQ").mkString(",")

    sparkSession.sql(s"""
    WITH uni_clm AS
    (
      SELECT *
      FROM
        ( SELECT p.*, ROW_NUMBER() OVER (PARTITION BY cpi_procedure_seq ORDER BY modified_dt DESC NULLS LAST) rn
          FROM MCKESSON_HHS_CPI_PROCEDURE p
          WHERE coding_system IS NOT NULL
            AND (reportable_fl = 'Y' OR reportable_fl IS NULL)
            AND procedure_reported_by_lseq IN ( $inclClaimMpMpv )
        )
      WHERE rn = 1
    ),
    claim_unfiltered AS
    (
      SELECT
        'hhs_cpi_procedure'   AS datasrc
        ,uni_clm.code	        AS localcpt
        ,zh.code_value	      AS mappedcpt
        ,uni_clm.cpi_seq      AS patientid
        ,uni_clm.Performed_Dt AS servicedate
        ,uni_clm.pat_seq  	  AS claimid
        ,uni_clm.pat_seq  	  AS encounterid
        ,ROW_NUMBER() OVER (PARTITION BY uni_clm.pat_seq, uni_clm.code ORDER BY uni_clm.modified_dt DESC NULLS LAST) rn
      FROM uni_clm
         LEFT OUTER JOIN MCKESSON_ZH_ENT_CONFIG_CODE_SET zh ON uni_clm.internal_code = zh.internal_code
    )
    SELECT distinct
        datasrc,
        claimid,
        patientid,
        servicedate,
        encounterid,
        localcpt,
        mappedcpt
    FROM claim_unfiltered
    WHERE servicedate IS NOT NULL
        AND claimid IS NOT NULL
        AND patientid IS NOT NULL
        and rn = 1
    """.stripMargin)
  }

}

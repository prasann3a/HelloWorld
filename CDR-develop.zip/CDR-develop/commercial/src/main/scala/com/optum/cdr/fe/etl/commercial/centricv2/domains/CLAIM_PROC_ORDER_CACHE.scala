package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.claim_proc_order_cache
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object CLAIM_PROC_ORDER_CACHE extends FETableInfo[claim_proc_order_cache] {

  override def name: String = "CLAIM_PROC_ORDER_CACHE"

  override def dependsOn: Set[String] = Set("CENTRICV2_ORDERS", "CENTRICV2_DOCUMENTS", "MAP_CUSTOM_PROC", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOC_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")
    val ordXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "ORDER_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")

    val constNoMpvMatches = "'NO_MPV_MATCHES'"
    val docXidInclusion = if (docXidInclusionMpv == constNoMpvMatches) ""  else " and d.xid in ( " + docXidInclusionMpv.replace("'", "") + " ) "
    val ordXidInclusion = if (ordXidInclusionMpv == constNoMpvMatches) "" else " and o.xid in ( " + ordXidInclusionMpv.replace("'", "") + " ) "


    sparkSession.sql(
      """
        |select A.*
        |  ,mcp.codetype
        |  ,mcp.mappedvalue
        | ,case when rlike(localcpt, '(?i)(^|CPT.*|J[^I].*|#.*)(\\d|[a-z]){1}\\d{3}(\\d|[a-z]){1}')
        |            then cptcode
        |       else null end  AS claim_cptcode
        | ,case when mcp.mappedvalue is not null
        |            then mcp.mappedvalue
        |       when rlike(localcpt, '(?i)(^|CPT.*|J[^I].*|#.*)(\\d|[a-z]){1}\\d{3}(\\d|[a-z]){1}')
        |            then nullif(regexp_extract(localcpt, '[a-zA-Z0-9]{5}', 0), '')
        |       else null end                        AS standardcode
        |, CASE
        |         WHEN mcp.mappedvalue is not null then 'CUSTOM'
        |         WHEN rlike(nullif(substr(cptcode,1,5), ''),'^[0-9]{4}[0-9A-Z]$')  THEN 'CPT4'
        |         WHEN rlike(nullif(substr(cptcode,1,5), ''),'^[A-Z]{1,1}[0-9]{4}$')  THEN 'HCPCS'
        |         WHEN rlike(nullif(substr(cptcode,1,5), ''), '^[0-9]{2,2}\\.[0-9]{1,2}$') THEN 'ICD9'
        |         ELSE  NULL END                      as stdcodetype
        |      ,row_number() over (partition by a.patientid, a.encounterid, a.servicedate, a.localcode
        |                              order by db_updated_date desc nulls last) as proc_rownumber
        |      ,row_number() over (partition by a.patientid, a.claimid, a.encounterid, a.servicedate, a.localcpt
        |                              order by db_updated_date desc nulls last) as claim_rn
        |FROM  (SELECT
        |'{groupid}'                                     as groupid
        |,'orders'                                    as datasrc
        |,{client_ds_id}                               as client_ds_id
        |,o.Sdid                                    AS claimid
        |,o.Pid                                     AS patientid
        |,o.Orderdate                               AS servicedate
        |,o.Usrid                                   AS orderingproviderid
        |,nullif(regexp_extract(o.code, '[a-zA-Z0-9]{5}', 0), '')   as cptcode
        |,o.Code                                    AS localcpt
        |,case when rlike(o.code, '(?i)(^|CPT.*)0{4,5}')
        |      then o.description
        |             else o.code end               as localcode
        |,o.description                             as localname
        |,d.Sdid                                    AS encounterid
        |,coalesce(o.Usrid ,o.Servprovid )          AS localbillingproviderid
        |,o.db_updated_date                         AS db_updated_date
        |FROM CENTRICV2_ORDERS o
        |     INNER JOIN CENTRICV2_DOCUMENTS d ON (d.sdid = o.sdid and d.pid = o.pid)
        |            where not rlike(o.description, '\\d{3}\\-\\d{4}')
        |            and o.status in ('C')
        |            {dox_xid_condition}
        |	    {ord_xid_condition}
        |            and (o.change is null OR o.change in (0,1,2))
        |            and d.finalsign = 1
        |            and d.status = 'S'
        |
        |             )a
        |        left outer join MAP_CUSTOM_PROC mcp on (mcp.groupid = '{groupid}'  and a.localcode = mcp.localcode and mcp.datasrc = 'orders')
        |WHERE (rlike(a.localcpt, '(?i)(^|CPT.*|J[^I].*|#.*)(\\d|[a-z]){1}\\d{3}(\\d|[a-z]){1}') OR mcp.mappedvalue is not null)
        |
    """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{dox_xid_condition}", docXidInclusion).
        replace("{ord_xid_condition}", ordXidInclusion)
    )

  }



}

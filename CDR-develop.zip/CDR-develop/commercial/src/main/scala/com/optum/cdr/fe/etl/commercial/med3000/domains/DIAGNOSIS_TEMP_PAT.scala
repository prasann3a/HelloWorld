package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object DIAGNOSIS_TEMP_PAT extends FEQueryAndMetadata[diagnosis]{

  override def name: String = "DIAGNOSIS_TEMP_PAT"

  override def dependsOn: Set[String] = Set("MED3000_PATIENT_DIAGNOSES")

  override def sparkSql: String =
    """select groupid, datasrc, client_ds_id, dx_timestamp, localdiagnosis, patientid, codetype, localactiveind, mappeddiagnosis, localdiagnosisproviderid
      |from
      |(
      |select a.*,
      |       row_number() over (partition by localdiagnosis,mappeddiagnosis,dx_timestamp,patientid order by Update_Date desc nulls last) as rank_diag
      |  from (
      |select distinct
      |       '{groupid}' 		as groupid
      |	   ,'pat_diags' 	as datasrc
      |       ,{client_ds_id} 			as client_ds_id
      |       ,Diag.Diagnosis_Date  	as dx_timestamp
      |       ,Diag.Diagnosis_Code  	as localdiagnosis
      |       ,Diag.Blind_Key  		as patientid
      |       ,NULL    				as codetype
      |       ,Diag.Hum_Status  		as localactiveind
      |       ,Diag.Diagnosis_Pcp  	as localdiagnosisproviderid
      |       ,Diag.Diagnosis_Code     as mappeddiagnosis
      |	   ,Update_Date
      |  from MED3000_PATIENT_DIAGNOSES Diag
      | where nvl(Hum_Status,'X') <> 'E') a
      |
      |
      |)
      |where dx_timestamp is not null and patientid is not null and rank_diag =1
    """.stripMargin




}

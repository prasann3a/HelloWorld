package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.mborder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object MBORDER extends FEQueryAndMetadata[mborder] {
  override def name: String = CDRFEParquetNames.mborder

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT", "MCKESSON_PGN_V1_TOM107_CHILD_ORDER", "MCKESSON_PGN_V1_TMB875_SPECIMEN_SOURCE_MASTER", "MCKESSON_PGN_V1_ZH_TOM200_ORDER_CODE")

  override def sparkSql: String =
    """
      |with dedup_pat_visit AS (
      |      SELECT  *
      |      FROM
      |      (
      |            SELECT  x.*
      |                  ,row_number () over (partition by vst_int_id ORDER BY lst_mod_ts desc nulls first,fileid desc nulls last) AS rownumber
      |            FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT x
      |      )
      |      WHERE rownumber = 1
      |      AND nvl(row_sta_cd,'X') <> 'D'
      |),
      |
      |dedup_child_order AS (
      |      SELECT  *
      |      FROM
      |      (
      |            SELECT  x.*
      |                  ,row_number () over (partition by chi_ord_int_id ORDER BY lst_mod_ts desc nulls first,fileid desc nulls last) AS rownumber
      |            FROM MCKESSON_PGN_V1_TOM107_CHILD_ORDER x
      |      )
      |      WHERE rownumber = 1
      |      AND nvl(row_sta_cd,'X') <> 'D'
      |),
      |
      |dedup_specimen AS (
      |      SELECT  *
      |      FROM
      |      (
      |            SELECT  x.*
      |                  ,row_number () over (partition by smn_src_int_id ORDER BY lst_mod_ts desc nulls first,fileid desc nulls last) AS rownumber
      |            FROM MCKESSON_PGN_V1_TMB875_SPECIMEN_SOURCE_MASTER x
      |      )
      |      WHERE rownumber = 1
      |      AND nvl(row_sta_cd,'X') <> 'D'
      |),
      |
      |dedup_order_code AS (
      |      SELECT  *
      |      FROM
      |      (
      |            SELECT  x.*
      |                  ,row_number () over (partition by order_code_int_id ORDER BY lst_mod_ts desc nulls first,fileid desc nulls last) AS rownumber
      |            FROM MCKESSON_PGN_V1_ZH_TOM200_ORDER_CODE x
      |      )
      |      WHERE rownumber = 1
      |      AND nvl(row_sta_cd,'X') <> 'D'
      |)
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,encounterid
      |       ,patientid
      |       ,mbprocorderid
      |       ,datecollected
      |       ,datereceived
      |       ,dateordered
      |       ,mborder_date
      |       ,localspecimensource
      |       ,localspecimenname
      |       ,localordercode
      |       ,client_ds_id
      |       ,localorderdesc
      |FROM
      |(
      |	SELECT  *
      |	FROM
      |	(
      |		SELECT  '{groupid}'                                                                                                                                AS groupid
      |		       ,{client_ds_id}                                                                                                                             AS client_ds_id
      |		       ,'child_order'                                                                                                                              AS datasrc
      |		       ,pv.psn_int_id                                                                                                                              AS patientid
      |		       ,pv.vst_int_id                                                                                                                              AS encounterid
      |		       ,co.chi_ord_int_id                                                                                                                          AS mbprocorderid
      |		       ,coalesce(co.chi_evt_dtm,co.col_dt,co.smn_rcv_ts)                                                                                           AS mborder_date
      |		       ,co.chi_evt_dtm                                                                                                                             AS dateordered
      |		       ,co.col_dt                                                                                                                                  AS datecollected
      |		       ,co.smn_rcv_ts                                                                                                                              AS datereceived
      |		       ,co.order_code_int_id                                                                                                                       AS localordercode
      |		       ,zh.order_code_desc1                                                                                                                        AS localorderdesc
      |		       ,co.smn_src_int_id                                                                                                                          AS localspecimensource
      |		       ,sp.smn_src_ds                                                                                                                              AS localspecimenname
      |		       ,row_number() over (partition by pv.psn_int_id,pv.vst_int_id,co.chi_ord_int_id,co.order_code_int_id ORDER BY co.lst_mod_ts desc nulls last) AS rownumber
      |		FROM DEDUP_CHILD_ORDER co
      |		INNER JOIN DEDUP_PAT_VISIT pv ON co.vst_int_id = pv.vst_int_id
      |		INNER JOIN DEDUP_ORDER_CODE zh ON co.order_code_int_id = zh.order_code_int_id
      |		LEFT JOIN DEDUP_SPECIMEN sp ON co.smn_src_int_id = sp.smn_src_int_id
      |		WHERE zh.microbiology_cd = 'Y'
      |	)
      |)
      |WHERE rownumber = 1
    """.stripMargin
}
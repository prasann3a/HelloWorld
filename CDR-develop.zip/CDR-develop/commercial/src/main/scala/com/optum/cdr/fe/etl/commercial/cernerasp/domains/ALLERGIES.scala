package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{allergy, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ALLERGIES extends FETableInfo[allergy]{

  override def name: String = CDRFEParquetNames.allergy

  override def dependsOn: Set[String] = Set("ALLERGY", "REFERENCETERMINOLOGY", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listAllergyTerminology = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "TERMINOLOGY","ALLERGY","ALLERGY","TERMINOLOGY").mkString(",")
    val listReactionStatus = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "STATUS","RX","ALLERGY","REACTION_STATUS").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localallergentype
        |       ,localallergencd
        |       ,onsetdate
        |       ,patientid
        |       ,encounterid
        |       ,localallergendesc
        |       ,localstatus
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                                                   AS groupid
        |	       ,'allergy'                                                                                                     AS datasrc
        |	       ,{client_ds_id}                                                                                                AS client_ds_id
        |	       ,concat_ws('','{client_ds_id}','.',llr.allergy_type)                                                           AS localallergentype
        |	       ,llr.allergy_terminology_identifier                                                                            AS localallergencd
        |	       ,coalesce(llr.onset_date_time,llr.reaction_status_date_time)                                                   AS onsetdate
        |	       ,llr.unique_person_identifier                                                                                  AS patientid
        |	       ,llr.unique_visit_identifier                                                                                   AS encounterid
        |	       ,rfr.text                                                                                                      AS localallergendesc
        |	       ,concat_ws('','{client_ds_id}','.',llr.reaction_status)                                                        AS localstatus
        |	       ,row_number() over (partition by llr.unique_allergy_identifier ORDER BY llr.update_date_time desc nulls first) AS rw
        |	FROM ALLERGY llr
        |	INNER JOIN
        |	(
        |		SELECT  unique_terminology_identifier
        |		       ,text
        |		FROM
        |		(
        |			SELECT  rt.unique_terminology_identifier AS unique_terminology_identifier
        |			       ,nullif(substr(rt.text,1,200),'') AS text
        |			       ,terminology
        |			       ,ROW_NUMBER() OVER (PARTITION BY rt.UNIQUE_TERMINOLOGY_IDENTIFIER ORDER BY rt.UPDATE_DATE_TIME DESC nulls first,rt.FILEID DESC nulls first) RN
        |			FROM REFERENCETERMINOLOGY rt
        |		)
        |		WHERE rn = 1
        |		AND text <> 'No known allergies'
        |		AND terminology IN ({LIST_ALLERGY_TERMINOLOGY})
        |	) rfr
        |	ON llr.allergy_terminology_identifier = rfr.unique_terminology_identifier
        |	WHERE llr.reaction_status in({LIST_REACTION_STATUS})
        |	AND llr.allergy_type is not null
        |	AND llr.allergy_terminology_identifier is not null
        |	AND llr.unique_person_identifier is not null
        |)
        |WHERE rw=1
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{LIST_ALLERGY_TERMINOLOGY}", listAllergyTerminology)
        .replace("{LIST_REACTION_STATUS}", listReactionStatus)
    )
  }
}

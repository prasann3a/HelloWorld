package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_ORDERS extends FETableInfo[medication_map_src] {

  override def name: String = "MEDICATION_MAP_SRC_ORDERS"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES", "ORDERS", "REFERENCECODE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val list_rx_hum_type = mpvList(mapPredicateValues, groupId, clientDsId, "RX_HUM_TYPE", "RX", "ORDERS", "HUM_TYPE").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql("""select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, localgeneric, localbrand, localgpi, localform, localstrength, no_ndc, has_ndc, num_recs, ndc_src
                       |        from
                       |        (
                       |        SELECT   distinct
                       |                '{groupid}'     as groupid
                       |                ,'orders'       as datasrc
                       |                ,{client_ds_id}         as client_ds_id
                       |                ,rdr.code       as localmedcode
                       |                ,rdr.ordered_as as localdescription
                       |                ,rfr.display    as localgeneric
                       |                ,null           as localndc
                       |                ,null           as localbrand
                       |                ,null           as localgpi
                       |                ,null           as localform
                       |                ,null           as localstrength
                       |                ,count(*)       as no_ndc
                       |                ,0              as has_ndc
                       |                ,count(*)       as num_recs
                       |                ,count(*)       as ndc_src
                       |        from ORDERS rdr
                       |        inner join REFERENCECODE rfr
                       |        on    rdr.code = rfr.element_code and rfr.field = 'CODE' and rfr.file_name = 'ORDERS'
                       |        where rdr.hum_type      in ({list_rx_hum_type})
                       |        and   rdr.code          is not null
                       |        and   rdr.ordered_as    is not null
                       |        group by rdr.code, rdr.ordered_as, rfr.display
                       |        )"""
                      .stripMargin
                      .replace("{groupid}", groupId)
                      .replace("{client_ds_id}", clientDsId)
                      .replace("{list_rx_hum_type}", list_rx_hum_type))
  }

}

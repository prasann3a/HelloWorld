package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDUREDO4 extends FETableInfo[proceduredo]{

  override def name:String="PROCEDURE4"
  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_result_status= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"RESULT_STATUS","PROCEDURE","RESULT","STATUS").mkString(",")

    sparkSession.sql(
      s"""
         |
          |select groupid, datasrc, client_ds_id, encounterid, patientid, performingproviderid, proceduredate, localcode, codetype, mappedcode, localname, actualprocdate
         |from
         |(
         |select '{groupid}'	as groupid
         |  	,'result'	as datasrc
         |  	,{client_ds_id}	as client_ds_id
         |  	,r.unique_visit_identifier	as encounterid
         |  	,r.unique_person_identifier	as patientid
         |  	,nullif(r.performed_by,'0')	as performingproviderid
         |  	,coalesce(r.performed_date_time,r.end_date_time)	as proceduredate
         |  	,concat_ws('', {client_ds_id}, '.', r.code)		as localcode
         |  	,'CUSTOM'	as codetype
         |  	,mcp.mappedvalue	as mappedcode
         |  	,rc.description	as localname
         |  	,coalesce(r.performed_date_time,r.end_date_time)	as actualprocdate
         |  	,row_number() over (partition by r.unique_result_identifier	order by r.update_date_time desc nulls last)	as rownumber
         |  from RESULT r
         |  	inner join MAP_CUSTOM_PROC mcp on (mcp.groupid = '{groupid}' and datasrc = 'result' and mcp.localcode = concat_ws('', {client_ds_id}, '.', r.code))
         |  	left outer join REFERENCECODE rc on (rc.element_code = r.code and rc.file_name = 'RESULT' and rc.field = 'CODE')
         |  where r.unique_person_identifier is not null
         |  and r.code is not null
         |  and coalesce(r.performed_date_time,r.end_date_time) is not null
         |  and r.result_value is not null
         |  and r.status not in ({list_result_status})
         |
         |)
         |where rownumber = 1
         |
         |
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_result_status}",list_result_status)
    )
  }



  override def dependsOn: Set[String] = Set("MAP_CUSTOM_PROC","RESULT","REFERENCECODE","MAP_PREDICATE_VALUES")
}

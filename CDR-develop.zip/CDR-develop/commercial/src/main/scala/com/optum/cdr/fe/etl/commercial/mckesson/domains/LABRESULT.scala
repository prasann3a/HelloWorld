package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader,CDRFEParquetNames}
import org.apache.spark.sql.{DataFrame, SparkSession}

object LABRESULT extends FETableInfo[labresult] {
  override def name: String = CDRFEParquetNames.labresult

  override def dependsOn: Set[String] = Set("LABRESULT_MCKESSON","NONNUMERIC_LABRESULT")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |SELECT * FROM LABRESULT_MCKESSON
         |UNION ALL
         |SELECT * FROM NONNUMERIC_LABRESULT
       """.stripMargin)


  }

}

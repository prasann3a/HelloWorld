
package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.patientaddr
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.cdr.fe.utils.Functions.mpvList


object PATIENTADDR extends FETableInfo[patientaddr]{

  override def name:String=CDRFEParquetNames.patientaddr

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    val list_home = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"HOME","PATIENT_ADDRESS","ADDRESS","HUM_TYPE").mkString(",")

    val list_mailing=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"MAILING","PATIENT_ADDRESS","ADDRESS","HUM_TYPE").mkString(",")


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }
    sparkSession.sql(
      s"""
         |select groupid, client_ds_id, datasrc, patientid, address_date, address_type, address_line1, address_line2, city, state, zipcode
         |from
         |(
         |select distinct '{groupid}'	as groupid
         |	,{client_ds_id}	as client_ds_id
         |	,'address'	as datasrc
         |	,a.entity_identifier	as patientid
         |	,a.update_date_time	as address_date
         |	,case when a.hum_type in ({list_home}) then 'HOME'
         |		when a.hum_type in ({list_mailing}) then 'MAILING'
         |		else null end	as address_type
         |	,a.address_line_1	as address_line1
         |	,a.address_line_2	as address_line2
         |	,a.city_text		as city
         |	,case when length(coalesce(a.state_text,rc.display)) > 2 then null
         |		else coalesce(a.state_text,rc.display) end 		as state
         |	,a.zipcode_key	as zipcode
         |from ADDRESS a
         |	left outer join REFERENCECODE rc on (a.state_code=rc.element_code and rc.field = 'STATE_CODE')
         |where a.entity_identifier is not null
         |and a.update_date_time is not null
         |and a.entity_type = 'PERSON'
         |and a.hum_type in ({list_home},{list_mailing})
         |and ( coalesce(a.address_line_1, a.address_line_2, a.city_text, a.zipcode_key) is not null
         |      or length(coalesce(a.state_text,rc.display)) between 1 and 2
         |    )
         |
 |)
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_home}",list_home)
        .replace("{list_mailing}",list_mailing)

    )


  }

  override def dependsOn: Set[String] = Set("ADDRESS","REFERENCECODE","MAP_PREDICATE_VALUES")

}
package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.prov_pat_rel
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, RuntimeVariables}

object PROV_PAT_REL_ZH_PCP extends FEQueryAndMetadata[prov_pat_rel] {

  override def name: String = "PROV_PAT_REL_ZH_PCP"

  override def dependsOn: Set[String] = Set("GTT_PROV_PAT_REL_ZH_PCP")

  override def sparkSql: String =

    """
      |select groupid, datasrc, client_ds_id, localrelshipcode, patientid, providerid, startdate, enddate, hgpid, grp_mpi, mstrprovid
      |from
      |(
      |select groupid,datasrc,client_ds_id,localrelshipcode,patientid,providerid,startdate,enddate,hgpid,grp_mpi,mstrprovid
      |  from (
      |       select l.groupid,l.datasrc,l.client_ds_id,l.localrelshipcode,l.patientid,l.providerid,l.startdate,hgpid,grp_mpi,mstrprovid
      |              ,case when '{prov_neg_one}' = 'Y' and l.providerid='-1' then to_date('{no_op_enddate}','yyyyMMdd')
      |                    when '{prov_neg_one}' = 'Y' and leadNwProv = '-1' and l.leadPat=l.patientid
      |                         then case when date_trunc('DAY', leadSt) = date_trunc('DAY', l.startdate) then l.startdate else (date_sub(leadSt, 1)) end
      |                    when l.leadLast='LAST' and l.newProv != 'x' and l.leadNwProv  = 'x' then NULL
      |                    when l.lastThisPat='x'    and l.newProv != 'x' and l.leadNwProv != 'x'
      |                         then case when date_trunc('DAY', leadSt) = date_trunc('DAY', l.startdate) then l.startdate else (date_sub(leadSt, 1)) end
      |                    when l.lastThisPat='LAST' and l.newProv != 'x' then NULL
      |                    else to_date('{no_op_enddate}','yyyyMMdd') end enddate
      |        from (select k.groupid,datasrc,client_ds_id,localrelshipcode,patientid,providerid,startdate,lastThisPat,newProv,k.leadPat,hgpid,grp_mpi,mstrprovid
      |                    ,Lead(startdate) OVER (ORDER BY rownum asc) as leadSt
      |                    ,Lead(lastThisPat) OVER (ORDER BY rownum asc) as leadLast
      |                    ,Lead(newProv) OVER (ORDER BY rownum asc) as leadNwProv
      |                    from
      |                    (
      |                        select *, monotonically_increasing_id() as rownum from
      |                        (
      |                            from (select j.groupid, j.datasrc, j.client_ds_id, j.localrelshipcode
      |                                    ,j.patientid,j.providerid,j.startdate,j.leadPat,j.hgpid,j.grp_mpi,j.mstrprovid
      |
      |                                    ,CASE WHEN leadPat != patientid
      |                                            THEN 'LAST'      ELSE 'x'   END LastThisPat
      |
      |                                    ,CASE WHEN (lagProv != providerid  OR lagPat != patientid)
      |                                            THEN providerid  ELSE 'x'   END newProv
      |                                from (
      |                                        select i.groupid, i.datasrc, i.client_ds_id, i.localrelshipcode
      |                                            ,i.patientid,i.providerid,i.startdate,i.hgpid,i.grp_mpi,i.mstrprovid
      |                                            ,Lag(patientid) OVER (ORDER BY rownum asc) as lagPat
      |                                            ,Lead(patientid) OVER (ORDER BY rownum asc) as leadPat
      |                                            ,LAG(providerid) OVER (ORDER BY rownum asc) as lagProv
      |                                            from
      |                                            (
      |                                                select *, monotonically_increasing_id() as rownum from
      |                                                (
      |                                                from (
      |                                                        select NULL as groupid, NULL as datasrc ,000 as client_ds_id,'PCP' as localrelshipcode
      |                                                            ,'.' as patientid, '..' as providerid, date_trunc('DAY', current_date) as startdate, null as hgpid, null as grp_mpi, null as mstrprovid
      |                                                        union select h.groupid, h.datasrc, h.client_ds_id, h.localrelshipcode
      |                                                                    ,h.patientid,h.providerid,date_trunc('DAY', h.startdate),hgpid,grp_mpi,mstrprovid
      |                                                                from GTT_PROV_PAT_REL_ZH_PCP h
      |
      |                                                        union select NULL as groupid,NULL as datasrc ,000 as client_ds_id,'PCP' as localrelshipcode
      |                                                            ,'~' as patientid,'000000' as providerid, date_trunc('DAY', current_date) as startdate, null as hgpid, null as grp_mpi, null as mstrprovid
      |                                                        order by 5,7  )
      |                                                order by patientid, startdate asc nulls last
      |                                                )
      |                                            ) i
      |                                    ) j
      |                            order by patientid, startdate asc nulls last
      |                            )
      |                        )
      |                    ) k
      |
      |              where (newProv != 'x' OR LastThisPat != 'x' )
      |              order by patientid, startdate ) l
      |      order by patientid, startdate
      |     ) m
      |where ( enddate is null or date_format(enddate, 'yyyyMMdd') <> '{no_op_enddate}')
      |and patientid != '.'
      |
      |order by patientid, startdate
      |)
    """.stripMargin

  override protected def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    sparkSql.replace("{prov_neg_one}", loaderVars.groupId).replace("{no_op_enddate}", "99991231")
  }

}
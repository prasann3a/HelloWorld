package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}

object ZH_FACILITY extends FEQueryAndMetadata[zh_facility] {
  override def name: String = CDRFEParquetNames.zh_facility

  override def sparkSql: String =
    """
      SELECT
        id      AS facilityid
        ,name   AS facilityname
      FROM MCKESSON_ZH_ENT_CONFIG_ORGANIZATION
      WHERE organization_type = 'Facility'
    """.stripMargin

  override def dependsOn: Set[String] = Set("MCKESSON_ZH_ENT_CONFIG_ORGANIZATION")


}

package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.oap.cdr.models.map_predicate_values
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object CattailsQueries extends BaseQueryConfig{

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)

  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries

}

object CattailsQueriesDrugAssign extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath,runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries ++ QueryRegistry.drug_assign_queries
}

object InitialDependencies {
  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables) : Seq[TableInfo[_ <: Product with Serializable]] = Seq(

      FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PREDICATE_VALUES")
    , FELoadFromParquet[item_detail_medications_tb](name = "ITEM_DETAIL_MEDICATIONS_TB", parquetLocation = s"$baseParquetLocation", tableName = "ITEM_DETAIL_MEDICATIONS_TB")
    , FELoadFromParquet[zh_dates_tb](name = "ZH_DATES_TB", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DATES_TB")
    , FELoadFromParquet[zh_times_tb](name = "ZH_TIMES_TB", parquetLocation = s"$baseParquetLocation", tableName = "ZH_TIMES_TB")
    , FELoadFromParquet[mecca_term_details_tb](name = "MECCA_TERM_DETAILS_TB", parquetLocation = s"$baseParquetLocation", tableName = "MECCA_TERM_DETAILS_TB")
    , FELoadFromParquet[events_vw](name = "EVENTS_VW", parquetLocation = s"$baseParquetLocation", tableName = "EVENTS_VW")
    , FELoadFromParquet[item_details_vw](name = "ITEM_DETAILS_VW", parquetLocation = s"$baseParquetLocation", tableName = "ITEM_DETAILS_VW")
    , FELoadFromParquet[med_disp_drug_dtls_tb](name = "MED_DISP_DRUG_DTLS_TB", parquetLocation = s"$baseParquetLocation", tableName = "MED_DISP_DRUG_DTLS_TB")
    , FELoadFromParquet[med_pat_script_disp_dtls_tb](name = "MED_PAT_SCRIPT_DISP_DTLS_TB", parquetLocation = s"$baseParquetLocation", tableName = "MED_PAT_SCRIPT_DISP_DTLS_TB")
    , FELoadFromParquet[med_drugs_tb](name = "MED_DRUGS_TB", parquetLocation = s"$baseParquetLocation", tableName = "MED_DRUGS_TB")
    , FELoadFromParquet[med_attributes_tb](name = "MED_ATTRIBUTES_TB", parquetLocation = s"$baseParquetLocation", tableName = "MED_ATTRIBUTES_TB")
    , FELoadFromParquet[med_patient_scripts_tb](name = "MED_PATIENT_SCRIPTS_TB", parquetLocation = s"$baseParquetLocation", tableName = "MED_PATIENT_SCRIPTS_TB")
    , FELoadFromParquet[med_event_items_tb](name = "MED_EVENT_ITEMS_TB", parquetLocation = s"$baseParquetLocation", tableName = "MED_EVENT_ITEMS_TB")
    , FELoadFromParquet[patient_fac_grp_seg_tb](name = "PATIENT_FAC_GRP_SEG_TB", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT_FAC_GRP_SEG_TB")
    , FELoadFromParquet[med_pat_script_dtls_tb](name = "MED_PAT_SCRIPT_DTLS_TB", parquetLocation = s"$baseParquetLocation", tableName = "MED_PAT_SCRIPT_DTLS_TB")
    , FELoadFromParquet[med_events_tb](name = "MED_EVENTS_TB", parquetLocation = s"$baseParquetLocation", tableName = "MED_EVENTS_TB")
    , FELoadFromParquet[patient_histories_tb](name = "PATIENT_HISTORIES_TB", parquetLocation = s"$baseParquetLocation", tableName = "PATIENT_HISTORIES_TB")
    , FELoadFromParquet[patients_tb](name = "PATIENTS_TB", parquetLocation = s"$baseParquetLocation", tableName = "PATIENTS_TB")
    , FELoadFromParquet[zh_national_codes_tb](name = "ZH_NATIONAL_CODES_TB", parquetLocation = s"$baseParquetLocation", tableName = "ZH_NATIONAL_CODES_TB")
    , FELoadFromParquet[provider_histories_tb](name = "PROVIDER_HISTORIES_TB", parquetLocation = s"$baseParquetLocation", tableName = "PROVIDER_HISTORIES_TB")
    , FELoadFromParquet[zh_facility_attributes_tb](name = "ZH_FACILITY_ATTRIBUTES_TB", parquetLocation = s"$baseParquetLocation", tableName = "ZH_FACILITY_ATTRIBUTES_TB")

  )
}

object QueryRegistry{
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(

      RXORDER
    , RXORDER_ITEM_DETAIL_MEDICATIONS_TB
    , RXORDER_MED_EVENTS_TB
    , RX_PATIENT_REPORTED
    , CLINICALENCOUNTER
    , PATIENT_CACHE
    , PATIENT
    , PATIENTDETAIL
    , PATIENTADDR
    , CLAIM
    , PROCEDURE
    , ENCOUNTERPROVIDER
    , PATIENT_ID
    , PATIENTCONTACT
    , FACILITY
    , PROV_SPEC
    , PROVIDER
    , PROVIDERIDENTIFIER

  )

  val drug_assign_queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    MEDICATION_MAP_SRC
  )
}

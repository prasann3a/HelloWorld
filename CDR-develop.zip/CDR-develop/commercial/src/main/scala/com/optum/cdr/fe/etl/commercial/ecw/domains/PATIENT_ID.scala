package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.{ecw_pats_cache, ecw_users_cache}
import com.optum.oap.cdr.models.patient_id
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{count, expr, lit}

object PATIENT_ID extends FETableInfo[patient_id]{

  override def name: String = CDRFEParquetNames.patient_id

  override def dependsOn: Set[String] = Set("ECW_USERS_CACHE", "ECW_PATS_CACHE", "ZH_INSURANCEDETAIL")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val ECW_USERS_CACHE = loadedDependencies("ECW_USERS_CACHE").as[ecw_users_cache]
    val ECW_PATS_CACHE = loadedDependencies("ECW_PATS_CACHE").as[ecw_pats_cache]
    loadedDependencies("ZH_INSURANCEDETAIL").as[zh_insurancedetail].createOrReplaceTempView("ZH_INSURANCEDETAIL")

    val ECW_PATS = ECW_PATS_CACHE.select($"pid",$"Controlno").distinct
      .select($"pid",$"Controlno"
        ,expr("case when count(pid) over (partition by Controlno) = 1 then Controlno end").as("member_mrn") //Distinct window functions are not supported in Spark. Controlno having count(distinct pid) > 1 should be NULL as per Spec System.
      )

    val joinCacheDf = ECW_USERS_CACHE.join(ECW_PATS, ECW_USERS_CACHE("hum_uid") === ECW_PATS("pid"), "inner")
      .select(
        lit(runtimeVar.groupId).as("groupid")
        ,lit(runtimeVar.clientDsId).as("client_ds_id")
        ,lit("patient").as("datasrc")
        ,$"hum_uid".as("patientid")
        ,$"ssn"
        ,expr("CASE WHEN validate_ssn(ssn) = 'Y' THEN ssn END").as("member_ssn")
        ,$"Controlno"
        ,$"member_mrn"
      )
    joinCacheDf.createOrReplaceTempView("withMemberMrn")

    val patientDatasrcDf = sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,patientid
        |       ,idtype
        |       ,idvalue
        |       ,client_ds_id
        |FROM
        |(
        |	SELECT  distinct groupid
        |	       ,datasrc
        |	       ,patientid
        |	       ,client_ds_id
        |        ,stack(2,'SSN',member_ssn,'MRN',member_mrn) as (idtype,idvalue)
        |	FROM withMemberMrn
        |)
        |where idvalue is not null
      """.stripMargin)

    val hInsurancedetailDatasrcDf = sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,patientid
        |       ,idtype
        |       ,idvalue
        |       ,client_ds_id
        |FROM
        |(
        |	SELECT  distinct '{groupid}'                                                                                AS groupid
        |	       ,'zh_insurancedetail'                                                                                AS datasrc
        |	       ,{client_ds_id}                                                                                      AS client_ds_id
        |	       ,zh.pid                                                                                              AS patientid
        |	       ,'HICN'                                                                                              AS idtype
        |	       ,nullif(regexp_extract(Subscriberno,'^([A-Z]{1,3}[0-9]{6}([0-9]{3})?|[0-9]{9}[A-Z][A-Z0-9]?)',0),'') AS idvalue
        |	FROM
        |	(
        |		SELECT  *
        |		FROM ZH_INSURANCEDETAIL
        |		WHERE (CASE WHEN '{groupid}' = 'H772763' THEN 1 ELSE 0 END) = 1
        |	) zh
        |	WHERE zh.pid is not null
        |	AND zh.subscriberno is not null
        |	AND zh.seqno = '1'
        |	AND rlike(subscriberno,'^([A-Z]{1,3}[0-9]{6}([0-9]{3})?|[0-9]{9}[A-Z][A-Z0-9]?)($|_)')
        |)
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )

    patientDatasrcDf union hInsurancedetailDatasrcDf
  }
}

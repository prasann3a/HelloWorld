package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_RXORDER_CCDBA_MED_ORDER extends FETableInfo[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_RXORDER_CCDBA_MED_ORDER"

  override def dependsOn: Set[String] = Set("CCDBA_MED_ORDER","ZH_CCDEV_DRUG","MCKESSON_ENT_PATIENT","ZH_DRUG1_FDB_PACKAGEDDRUG","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val excl_id = mpvList(mapPredicateValues, groupId, clientDsId, "CCDBA_MED_ORDER", "MEDS", "CCDBA_MED_ORDER", "DRUG_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
     WITH uni_order AS
      (SELECT * FROM (
            SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY chart_ddt DESC NULLS LAST) rn
            FROM CCDBA_MED_ORDER i
            WHERE Order_Seq IS NOT NULL
              AND NVL(route, 'null') NOT IN ('MISC', 'NA'))
      WHERE rn = 1),
      uni_drug AS
      (SELECT * FROM (
            SELECT i.*, ROW_NUMBER() OVER (PARTITION BY drug_id ORDER BY change_dt DESC NULLS LAST) rn
            FROM ZH_CCDEV_DRUG i)
      WHERE rn = 1),
      uni_pat AS
      (SELECT * FROM (
      (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
            FROM MCKESSON_ENT_PATIENT p
            WHERE cpi_seq IS NOT NULL )
      ) WHERE rn = 1)
      select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs
      from
      (
      SELECT '{groupid}' AS groupid
              ,'ccdba_med_order' AS datasrc
        ,{client_ds_id} AS client_ds_id
              ,SUM(CASE WHEN localndc IS NULL THEN 1 ELSE 0 END) AS no_ndc
              ,SUM(CASE WHEN localndc IS NULL THEN 0 ELSE 1 END) AS has_ndc
              ,COUNT(*) AS num_recs
              ,localmedcode, localndc, localdescription
      FROM ( SELECT CASE WHEN uni_order.Drug_id IN ({excl_id}) THEN LOWER(uni_order.drug_name) ELSE uni_order.drug_id END AS localmedcode
                    ,normalize_NDC(CASE WHEN uni_order.Drug_id IN ({excl_id}) THEN NULL ELSE zh.Pmid END) AS localndc
                   ,CASE WHEN uni_order.Drug_id IN ({excl_id}) THEN LOWER(uni_order.drug_name) ELSE LOWER(COALESCE(uni_drug.sec_name, uni_order.drug_name)) END AS localdescription
        FROM UNI_ORDER
           JOIN UNI_PAT ON (uni_order.pat_seq = uni_pat.pat_seq)
           LEFT OUTER JOIN UNI_DRUG ON (uni_order.drug_id = uni_drug.drug_id)
           LEFT OUTER JOIN ZH_DRUG1_FDB_PACKAGEDDRUG zh ON (uni_order.drug_id = zh.pmid))
      GROUP BY  localmedcode, localndc, localdescription
      )
        """.replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId)
        .replace("{excl_id}", excl_id))
  }
}
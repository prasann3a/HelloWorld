package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.oap.cdr.models.{map_custom_proc, map_patient_type, map_predicate_values, map_unit, metadata_lab, unit_conversion, unit_remap, zcm_obstype_code}
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}
import com.optum.cdr.fe.utils.nonnumeric_labs_localresult_25.NONNUMERIC_LABRESULT
import com.optum.cdr.fe.utils.load_prov_pat_rel.PROV_PAT_REL


object Centricv2Queries extends BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)

  override def queryRegistry = QueryRegistry.queries

}

object Centricv2QueriesH770494 extends BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  // PATIENTCUSTOMATTRIBUTE should run only for H770494 clients
  override def queryRegistry = QueryRegistry.queries  ++ QueryRegistry.drug_assign_queries  ++ QueryRegistry.H770494_post_hadoop_queries

}

object Centricv2QueriesWithDrugAssign extends BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry = QueryRegistry.queries ++ QueryRegistry.drug_assign_queries
}


object InitialDependencies {

  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    FELoadFromParquet[patientallergy](name = "CENTRICV2_PATIENTALLERGY", parquetLocation = s"$baseParquetLocation", tableName = "PATIENTALLERGY", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[documents](name = "CENTRICV2_DOCUMENTS", parquetLocation = s"$baseParquetLocation", tableName = "DOCUMENTS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PREDICATE_VALUES")
    , FELoadFromParquet[centricv2_immunization](name = "CENTRICV2_IMMUNIZATION", parquetLocation = s"$baseParquetLocation", tableName = "IMMUNIZATION", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_locationreg](name = "CENTRICV2_ZH_LOCATIONREG", parquetLocation = s"$baseParquetLocation", tableName = "ZH_LOCATIONREG", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[insuranc](name = "CENTRICV2_INSURANC", parquetLocation = s"$baseParquetLocation", tableName = "INSURANC", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_insureco](name = "CENTRICV2_ZH_INSURECO", parquetLocation = s"$baseParquetLocation", tableName = "ZH_INSURECO", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_business](name = "CENTRICV2_ZH_BUSINESS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_BUSINESS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[patientinsurance](name = "CENTRICV2_PATIENTINSURANCE", parquetLocation = s"$baseParquetLocation", tableName = "PATIENTINSURANCE", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[patientprofile](name = "CENTRICV2_PATIENTPROFILE", parquetLocation = s"$baseParquetLocation", tableName = "PATIENTPROFILE", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_insurancecarriers](name = "CENTRICV2_ZH_INSURANCECARRIERS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_INSURANCECARRIERS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_insurancegroup](name = "CENTRICV2_ZH_INSURANCEGROUP", parquetLocation = s"$baseParquetLocation", tableName = "ZH_INSURANCEGROUP", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[scheduling](name = "CENTRICV2_SCHEDULING", parquetLocation = s"$baseParquetLocation", tableName = "SCHEDULING", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[appointments](name = "CENTRICV2_APPOINTMENTS", parquetLocation = s"$baseParquetLocation", tableName = "APPOINTMENTS", ignoreExtraColumnsInDataFrame = true)
    //, FELoadFromParquet[load_log](name = "CENTRICV2_LOAD_LOG", parquetLocation = s"$baseParquetLocation", tableName = "LOAD_LOG", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_doctorfacility](name = "CENTRICV2_ZH_DOCTORFACILITY", parquetLocation = s"$baseParquetLocation", tableName = "ZH_DOCTORFACILITY", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[orders](name = "CENTRICV2_ORDERS", parquetLocation = s"$baseParquetLocation", tableName = "ORDERS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_ordercodes](name = "CENTRICV2_ZH_ORDERCODES", parquetLocation = s"$baseParquetLocation", tableName = "ZH_ORDERCODES", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_obshead](name = "CENTRICV2_ZH_OBSHEAD", parquetLocation = s"$baseParquetLocation", tableName = "ZH_OBSHEAD", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[observations](name = "CENTRICV2_OBSERVATIONS", parquetLocation = s"$baseParquetLocation", tableName = "OBSERVATIONS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[map_custom_proc](name = "MAP_CUSTOM_PROC", parquetLocation = s"$mappingParquetPath", tableName = "MAP_CUSTOM_PROC")
    , FELoadFromParquet[zh_medinfo](name = "CENTRICV2_ZH_MEDINFO", parquetLocation = s"$baseParquetLocation", tableName = "ZH_MEDINFO", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[patientmedication](name = "CENTRICV2_PATIENTMEDICATION", parquetLocation = s"$baseParquetLocation", tableName = "PATIENTMEDICATION", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[prescriptions](name = "CENTRICV2_PRESCRIPTIONS", parquetLocation = s"$baseParquetLocation", tableName = "PRESCRIPTIONS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_staffreg](name = "CENTRICV2_ZH_STAFFREG", parquetLocation = s"$baseParquetLocation", tableName = "ZH_STAFFREG", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_hiergrps](name = "CENTRICV2_ZH_HIERGRPS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_HIERGRPS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[map_unit](name = "MAP_UNIT", parquetLocation = s"$mappingParquetPath", tableName = "MAP_UNIT")
    , FELoadFromParquet[unit_remap](name = "UNIT_REMAP", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_REMAP")
    , FELoadFromParquet[metadata_lab](name = "METADATA_LAB", parquetLocation = s"$mappingParquetPath", tableName = "METADATA_LAB")
    , FELoadFromParquet[unit_conversion](name = "UNIT_CONVERSION", parquetLocation = s"$mappingParquetPath", tableName = "UNIT_CONVERSION")
    , FELoadFromParquet[registration](name = "CENTRICV2_REGISTRATION", parquetLocation = s"$baseParquetLocation", tableName = "REGISTRATION", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[patientrace](name = "CENTRICV2_PATIENTRACE", parquetLocation = s"$baseParquetLocation", tableName = "PATIENTRACE", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[patientethnicity](name = "CENTRICV2_PATIENTETHNICITY", parquetLocation = s"$baseParquetLocation", tableName = "PATIENTETHNICITY", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[map_patient_type](name = "MAP_PATIENT_TYPE", parquetLocation = s"$mappingParquetPath", tableName="MAP_PATIENT_TYPE")
    , FELoadFromParquet[patientproblem](name = "CENTRICV2_PATIENTPROBLEM", parquetLocation = s"$baseParquetLocation", tableName = "PATIENTPROBLEM", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[problemassessment](name = "CENTRICV2_PROBLEMASSESSMENT", parquetLocation = s"$baseParquetLocation", tableName = "PROBLEMASSESSMENT", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[problemmasterdiagnosis](name = "CENTRICV2_PROBLEMMASTERDIAGNOSIS", parquetLocation = s"$baseParquetLocation", tableName = "PROBLEMMASTERDIAGNOSIS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zh_masterdiagnosis](name = "CENTRICV2_ZH_MASTERDIAGNOSIS", parquetLocation = s"$baseParquetLocation", tableName = "ZH_MASTERDIAGNOSIS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[clinicaldocuments](name = "CENTRICV2_CLINICALDOCUMENTS", parquetLocation = s"$baseParquetLocation", tableName = "CLINICALDOCUMENTS", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[zcm_obstype_code](name = "ZCM_OBSTYPE_CODE", parquetLocation = s"$mappingParquetPath", tableName = "ZCM_OBSTYPE_CODE")
  )
}

object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    ALLERGY
    , IMMUNIZATION
    , ZH_FACILITY
    , INSURANCE
    , APPOINTMENT
    , ZH_APPT_LOCATION
    , LABORDER
    , CLAIM_PROC_ORDER_CACHE
    , CLAIM_PROC_RESULT_CACHE
    , CLAIM_ORDERS
    , CLAIM_RESULTS
    , PROCEDURE_ORDERS
    , PROCEDURE_RESULTS
    , CLAIM
    , PROCEDURE
    , CLAIM_PROC_DOC_CACHE
    , PROCEDURE_DOC
    , PATIENTREPORTEDMEDS
    , LABMAPPERDICT
    , PROV_DOCTORFACILITY
    , PROV_STAFFREG
    , PROVIDER
    , PROV_CONTACT_DOCTORFACILITY
    , PROV_CONTACT_STAFFREG
    , PROVIDERCONTACT
    , PROVIDERIDENTIFIER
    , PROVIDERSPECIALTY
    , RXORDER
    , LABRESULT_CACHE
    , GTT_LABRESULT_NONNUMERIC
    , NONNUMERIC_LABRESULT
    , LABRESULT_PART_CACHE
    , LABRESULT
    , PATIENT_PART1_CACHE
    , PATIENT_PART2_CACHE
    , PATIENT
    , PATIENTCONTACT
    , PATIENTDETAIL
    , PATIENTADDRESS
    , ENCOUNTERPROVIDER
    , CLINICALENCOUNTER
    , GTT_PROV_PAT_REL
    , PROV_PAT_REL
    , DIAGNOSIS
    , OBSERVATION
  )

  val H770494_post_hadoop_queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    PATIENTCUSTOMATTRIBUTE
  )

  val drug_assign_queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    MEDICATION_MAP_SRC
  )

}

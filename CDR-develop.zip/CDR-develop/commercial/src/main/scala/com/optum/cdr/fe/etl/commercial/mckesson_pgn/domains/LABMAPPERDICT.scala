package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.{map_predicate_values, zh_lab_dict}
import org.apache.spark.sql.{DataFrame, SparkSession}

object LABMAPPERDICT extends FETableInfo[zh_lab_dict]{
  override def name: String = CDRFEParquetNames.zh_lab_dict

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_T_LABORATORY_RESULTS","MCKESSON_PGN_V1_TMA100_CLINICAL_DOC","ZCM_OBSTYPE_CODE","MCKESSON_PGN_V1_TED101_TRIAGE","MCKESSON_PGN_V1_ZH_TLB800_TEST_CODE_MST","MCKESSON_PGN_V1_ZH_TAS915_MEASUREMENT")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val listMapper = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LOCALNAME","LABRESULT","TLB800_TEST_CODE_MST","TST_COD_DS").mkString(",")
    val vtlsgnint = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "INCLUSION","LABRESULT","PTVITAILS","VTL_SGN_INT_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |with  dedup_Code_Mst as ( select *
        |          from (select cm.*
        |                      ,row_number () over (partition by TST_COD_INT_ID order by Lst_Mod_Ts DESC nulls first, FileID DESC NULLS LAST) as rownumber
        |                from MCKESSON_PGN_V1_ZH_TLB800_TEST_CODE_MST cm
        |                )
        |        WHERE rownumber = 1
        |   AND nvl(row_sta_cd,'X') <> 'D' ),
        |
        |dedup_Tas_Mst as ( select *
        |          from (select ztm.*
        |                      ,row_number () over (partition by vtl_sgn_int_id order by Lst_Mod_Ts DESC nulls first, FileID DESC NULLS LAST) as rnum
        |                from MCKESSON_PGN_V1_ZH_TAS915_MEASUREMENT ztm
        |                )
        |        WHERE rnum = 1 )
        |
        |select groupid, client_ds_id, localcode, localdesc, localname, localunits, localdatatype, local_loinc_code, localrefrange
        |from
        |(
        |SELECT t.*, ROW_NUMBER() OVER (PARTITION BY localcode ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |FROM (
        |SELECT '{groupid}'   AS groupid
        |	,{client_ds_id} AS client_ds_id
        |	,CASE WHEN format_code <> 'RL**' THEN format_code ELSE alt_idn END AS localcode
        |	,CASE WHEN data_mixed IS NOT NULL THEN 'text'
        |	      WHEN data_numeric IS NOT NULL THEN 'numeric'
        |	      ELSE NULL END AS localdatatype
        |	,alt_idn       AS local_loinc_code
        |	,NULL          AS localrefrange
        |	,COALESCE(result_description, alt_dsc)  AS localname
        |	,COALESCE(result_description, alt_dsc)  AS localdesc
        |	,NULL  AS localunits
        |        ,Lst_Mod_Ts
        |        ,FileID
        |FROM (SELECT * FROM MCKESSON_PGN_V1_T_LABORATORY_RESULTS
        |      WHERE format_code <> 'RL**' OR alt_idn IS NOT NULL)
        |WHERE format_code IS NOT NULL
        |  AND (NVL(data_mixed,'null') <> 'CANCELED' OR data_numeric IS NOT NULL)
        |) t
        |)
        |where localcode IS NOT NULL AND rn =1
        |
        |union all
        |
        |select groupid, client_ds_id, localcode, localdesc, localname, localunits, null as localdatatype, null as local_loinc_code, null as localrefrange
        |from
        |(
        |SELECT '{groupid}' 		AS groupid
        |	,{client_ds_id} 		AS client_ds_id
        |	,concat_ws('', '{client_ds_id}', '.cd.', unpvt_doc.localcode)    AS localcode
        |    	,unpvt_doc.localcode    AS localname
        |    	,unpvt_doc.localcode    AS localdesc
        |	,z.localunit            AS localunits
        |	,ROW_NUMBER() OVER (PARTITION BY unpvt_doc.localcode ORDER BY unpvt_doc.Lst_Mod_Ts DESC NULLS LAST) map_rn
        |FROM (SELECT * from
        |(
        |select * from
        |(
        |select unpivot_base.*,
        |stack(3,Spo2_Ds,'SPO2_DS',Blo_Glu_Ds,'BLO_GLU_DS',Inr_Ds,'INR_DS') as (localresult, localcode)
        |from
        |MCKESSON_PGN_V1_TMA100_CLINICAL_DOC unpivot_base
        |)
        |where localresult is not null
        |)) unpvt_doc
        |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
        |                                z.datasrc = 'clinical_doc' AND
        |                                z.obstype = 'LABRESULT' AND
        |				z.obscode = concat_ws('', '{client_ds_id}', '.cd.', unpvt_doc.localcode))
        |
        |)
        |where localcode IS NOT NULL AND map_rn =1
        |
        |union all
        |
        |select groupid, client_ds_id, localcode, localdesc, localname, localunits, null as localdatatype, null as local_loinc_code, null as localrefrange
        |from
        |(
        |SELECT '{groupid}' 		AS groupid
        |	,{client_ds_id} 		AS client_ds_id
        |	,concat_ws('', '{client_ds_id}', '.tr.', unpvt_triage.localcode)    AS localcode
        |    	,unpvt_triage.localcode    AS localname
        |    	,unpvt_triage.localcode    AS localdesc
        |	,z.localunit            AS localunits
        |	,ROW_NUMBER() OVER (PARTITION BY unpvt_triage.localcode ORDER BY unpvt_triage.Lst_Mod_Ts DESC NULLS LAST) map_rn
        |FROM (SELECT * from
        |(
        |select * from
        |(
        |select unpivot_base.*,
        |stack(2,vit_pox_no,'VIT_POX_NO',vit_bld_sug_no,'VIT_BLD_SUG_NO') as (localresult, localcode)
        |from
        |MCKESSON_PGN_V1_TED101_TRIAGE unpivot_base
        |)
        |where localresult is not null
        |)) unpvt_triage
        |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
        |                                z.datasrc = 'triage' AND
        |                                z.obstype = 'LABRESULT' AND
        |				z.obscode = concat_ws('', '{client_ds_id}', '.tr.', unpvt_triage.localcode))
        |
        |)
        |where localcode IS NOT NULL AND map_rn =1
        |
        |union all
        |
        |select groupid, client_ds_id, localcode, localdesc, localname, localunits, null as localdatatype, null as local_loinc_code, null as localrefrange
        |from
        |(
        |SELECT
        |        '{groupid}'   AS groupid
        |	,{client_ds_id} AS client_ds_id
        |	,TST_COD_INT_ID AS localcode
        |	,Tst_Cod_Abr_Cd  AS localdesc
        |	,case when tst_cod_ds in ({list_mapper}) then tst_cod_abr_cd else tst_cod_ds End AS localname
        |	,Unt_Msr_Cd  AS localunits
        |  	FROM DEDUP_CODE_MST dcm
        |)
        |
        |union all
        |
        |select groupid, client_ds_id, localcode, localdesc, localname, null as localunits, null as localdatatype, null as local_loinc_code, null as localrefrange
        |from
        |(
        |SELECT
        |        distinct '{groupid}'    AS groupid
        |	,{client_ds_id}       AS client_ds_id
        |	,concat_ws('', '{client_ds_id}', '.', Vtl_Sgn_Int_Id)      AS localcode
        |    	,Msr_Ds              AS localname
        |    	,Msr_Ds              AS localdesc
        |FROM DEDUP_TAS_MST
        |WHERE VTL_SGN_INT_ID in ({vtlsgnint})
        |)
        |where localcode IS NOT NULL
      """
        .stripMargin
        .replace("{list_mapper}",listMapper)
        .replace("{vtlsgnint}",vtlsgnint)
        .replace("{groupid}",runtimeVar.groupId)
        .replace("{client_ds_id}",runtimeVar.clientDsId.toString)
    )
  }

}

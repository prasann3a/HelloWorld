package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.appointment
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object APPOINTMENT extends FEQueryAndMetadata[appointment]{

  override def name: String = "APPOINTMENT"

  override def dependsOn: Set[String] = Set(
      "CENTRICV2_SCHEDULING"
    , "CENTRICV2_APPOINTMENTS"
    , "CENTRICV2_ZH_DOCTORFACILITY"
  )

  override def sparkSql: String =
    """
      |select
      |  datasrc
      | ,patientid
      | ,appointmentid
      | ,appointmentdate
      | ,locationid
      | ,null as providerid
      | ,local_appt_type
      | ,appointment_reason
      |from
      |(
      |select
      |	'Scheduling' 	as datasrc
      |	,date_format(sch.apptdate, 'yyyy-MM-dd 00:00:00') 	as appointmentdate
      |	,sch.apptid 	as appointmentid
      |	,sch.locid 	as locationid
      |	,sch.pid 	as patientid
      |	,sch.appttype	as local_appt_type
      |	,sch.reason 	as appointment_reason
      | ,row_number() over (partition by sch.pid,sch.apptid order by appt_updated_date desc nulls last) as rownumber
      |from CENTRICV2_SCHEDULING sch
      |where 1=1
      |and sch.apptdate is not null
      |and sch.apptid 	 is not null
      |and sch.locid 	 is not null
      |and sch.pid 	 is not null
      |and apptstatus 	 <> '1'
      |)
      |where rownumber=1 and appointmentdate is not null
      |
      |UNION ALL
      |
      |select
      |  datasrc
      | ,patientid
      | ,appointmentid
      | ,appointmentdate
      | ,locationid
      | ,providerid
      | ,local_appt_type
      | ,appointment_reason
      |from
      |(
      |SELECT 'appointments' as datasrc
      |	,date_format(ppn.Apptstart, 'yyyy-MM-dd HH:mm:ss') AS appointmentdate -- Extract Date from APPTSTART
      |	,ppn.Appointmentsid AS appointmentid
      |	,ppn.Facilityid AS locationid
      |	,ppn.Pid AS patientid
      |	,ppn.Appttypeid AS local_appt_type
      |	,zlz.Pvid  AS providerid
      | ,substr(ppn.Notes,1,249)  as appointment_reason
      |  -- deduplicate: FILEID
      | ,row_number() over (partition by ppn.Appointmentsid,ppn.Facilityid,ppn.Pid,ppn.Apptstart,ppn.STATUS,ppn.APPTTYPEID,ppn.DOCTORID order by COALESCE(ppn.TRANSACT_DATE, ppn.TRACK_TIME) desc nulls first) as rownumber
      |FROM  CENTRICV2_APPOINTMENTS ppn
      |left join CENTRICV2_ZH_DOCTORFACILITY zlz on  ppn.doctorid = zlz.doctorfacilityid
      |WHERE 1=1
      |AND   lower(status)not in ('no show') or lower(status) not like '%cancel%'
      |AND  ppn.Apptstart is not null
      |)
      |where rownumber =1 and appointmentdate is not null
    """
    .stripMargin

}

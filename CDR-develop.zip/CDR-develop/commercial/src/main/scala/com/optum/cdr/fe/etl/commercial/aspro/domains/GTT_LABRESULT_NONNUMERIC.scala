package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.aspro_labresult_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object GTT_LABRESULT_NONNUMERIC extends FEQueryAndMetadata[aspro_labresult_cache]{

  override def name: String = "GTT_LABRESULT_NONNUMERIC"

  override def dependsOn: Set[String] = Set("GTT_LABRESULT_NONNUMERIC_LABRESULTS", "GTT_LABRESULT_NONNUMERIC_PROCRESULTS", "GTT_LABRESULT_NONNUMERIC_VITALS")

  override def sparkSql: String =
    """
       select * from GTT_LABRESULT_NONNUMERIC_LABRESULTS

       union all

       select * from GTT_LABRESULT_NONNUMERIC_PROCRESULTS

       union all

       select * from GTT_LABRESULT_NONNUMERIC_VITALS

    """.stripMargin

}

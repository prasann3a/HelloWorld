package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{appointment, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object APPOINTMENT extends FETableInfo[appointment]{

  override def name: String = CDRFEParquetNames.appointment

  override def dependsOn: Set[String] = Set("ENC", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    loadedDependencies("ENC").as[enc].createOrReplaceTempView("ENC")

    val predicate_values = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val app_sts_cdDf = mpvList(predicate_values,runtimeVar.groupId, runtimeVar.clientDsId.toString, "ECW", "APPOINTMENT", "ENC", "VISITSTSCODEID").mkString(",")

    sparkSession.sql(
    """
      select '{groupid}' as groupid, 'enc' as datasrc, '{client_ds_id}' as client_ds_id, appointmentdate, appointmentid, locationid, patientid, local_appt_type, providerid, appointment_reason
 |from
 |(
 |SELECT
 |         enc.enc_date as appointmentdate
 |        ,enc.encounterid as appointmentid
 |	,enc.facilityid as locationid
 |	,enc.patientid as patientid
 |	,enc.visittypeid as local_appt_type
 |	,enc.doctorid as providerid
 |	,nullif(substr(enc.reason, 1, 249), '') as appointment_reason
 |	,row_number() over (partition by enc.encounterid order by modifieddate desc nulls first) as rownumber
 |FROM ENC enc
 |WHERE enc.visitstscodeid NOT IN ({app_sts_cdDf}) and date_format(enc_date,'yyyyMMdd')>=date_format(current_date,'yyyyMMdd')
 |
 |)
 |where rownumber = 1
    """.stripMargin
      .replace("{app_sts_cdDf}", app_sts_cdDf)
      .replace("{groupid}", runtimeVar.groupId)
      .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )

  }

}


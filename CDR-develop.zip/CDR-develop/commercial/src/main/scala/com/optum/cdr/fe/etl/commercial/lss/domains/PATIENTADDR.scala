package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.patientaddr
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object PATIENTADDR extends FEQueryAndMetadata[patientaddr]{

  override def name: String = CDRFEParquetNames.patientaddr

  override def dependsOn: Set[String] = Set("LSS_PBRACCOUNTDEMOGRAPHICS", "LSS_PBRACCOUNTS")

  override def sparkSql: String =
    """
      |SELECT datasrc,patientid,address_date,address_line1,address_line2,city,state,zipcode
      |FROM (
      |   SELECT x.*
      |         ,row_number() over (partition by x.Patientid, x.Rowupdatedatetime order by x.AccountID desc nulls first) as rownumber
      |   FROM (
      |       SELECT 'pbraccountdemographics' as datasrc
      |         ,pbr.Rowupdatedatetime AS address_date
      |         ,CONCAT_WS('', pbr.Sourceid, act.Patientid) AS patientid
      |         ,pbr.State AS state
      |         ,pbr.Postalcodeid AS zipcode
      |         ,pbr.Addr1 AS address_line1
      |         ,pbr.Addr2 AS address_line2
      |         ,pbr.City AS city
      |         ,pbr.AccountID
      |         ,pbr.Rowupdatedatetime
      |       FROM LSS_PBRACCOUNTDEMOGRAPHICS pbr
      |       INNER JOIN LSS_PBRACCOUNTS act ON (act.sourceid=pbr.sourceid and act.accountid=pbr.accountid)
      |       WHERE NULLIF(CONCAT_WS('', Addr1, Addr2, City, State, PostalcodeID), '') is not null
      |         AND pbr.Rowupdatedatetime is not null
      |    ) x
      |) where rownumber = 1
    """.stripMargin
}

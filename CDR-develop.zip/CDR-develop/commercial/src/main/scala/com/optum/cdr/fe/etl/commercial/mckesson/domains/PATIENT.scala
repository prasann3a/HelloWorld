package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.patient

object PATIENT extends FEQueryAndMetadata[patient]{
  override def name: String = CDRFEParquetNames.patient

  override def dependsOn: Set[String] = Set("TEMP_PATIENT_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, patientid, dateofbirth, dateofdeath, medicalrecordnumber, inactive_flag
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where rownumber = 1
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.bcn.domains

import com.optum.oap.cdr.models.int_claim_medical
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object INT_CLAIM_MEDICAL extends FEQueryAndMetadata[int_claim_medical]{
  override def name: String = CDRFEParquetNames.int_claim_medical

  override def dependsOn: Set[String] = Set("CLCPV", "CLDEV", "ZO_BPO_MAP_EMPLOYER")

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def sparkSql: String =
    """
      |select datasrc, admit_date, admit_source_code, admit_type_code, allowed_amt, coord_benifits_amt, capitated_service_flag, claim_header_id, claim_line_id, claim_type, coinsurance_amt, copay_amt, diag_rel_grp_code, diag_rel_grp_grouper, deductable_amt, financial_class, pcp_id, pcp_npi, denied_flag, discharge_date, discharge_status_code, facility_code, facility_name, icd_diag_cd1, icd_diag_cd1_poa_indicator, member_dob, member_fname, member_gender_code, member_id, member_lname, pat_liability_amt, payment_amt, pay_process_date, place_of_service, principle_proc_cd, principle_proc_icd_type, proc_cd_modifier_1, proc_cd_modifier_2, proc_cd_modifier_3, proc_code, quantity_of_service, requested_amt, revenue_code, service_date, service_from_date, service_to_date, servicing_prov_name, servicing_prov_id, servicing_prov_npi, source_code, type_of_bill_code, type_of_service, denied_reason, network_status_flag, Ordering_Prov_Id, payer_code, payer_name, product_code, product_name, servicing_prov_spclty_cd, servicing_prov_spclty_desc, par_flag, plan_code, plan_name, withhold_amt, encounterid
      |from
      |(
      |select
      |       distinct
      |       'clcpv'                                      AS datasrc,
      |       c.encounter_id                               AS claim_header_id,
      |       c.encounter_id                               AS encounterid,
      |       concat_ws('', c.subscriber_number, '-', c.member_number)    AS member_id,
      |       c.from_date                                  AS service_date,
      |       NULL                                         AS admit_date,
      |       NULL                                         AS admit_source_code,
      |       NULL                                         AS admit_type_code,
      |       c.allow_amount_sum_2                         AS allowed_amt,
      |       NULL                                         AS coord_benifits_amt,
      |       NULL                                         AS capitated_service_flag,
      |       NULL                                         AS claim_line_id,
      |       NULL                                         AS claim_type,
      |       NULL                                         AS coinsurance_amt,
      |       NULL                                         AS copay_amt,
      |       'Commercial'                                 AS financial_class,
      |       c.drg_code                                   AS diag_rel_grp_code,
      |       'MSDRG'                                      AS diag_rel_grp_grouper,
      |       NULL                                         AS deductable_amt,
      |       NULL                                         AS denied_flag,
      |       case when c.discharge_date = '17530101' then  NULL
      |          else safe_to_date(c.discharge_date,'yyyyMMdd') end AS discharge_date,
      |       NULL                                         AS discharge_status_code,
      |       NULL                                         AS facility_code,
      |       NULL                                         AS facility_name,
      |       c.Medical_Diag_Code                          AS icd_diag_cd1,
      |       c.Diagnosis_Code                             AS icd_diag_cd2,
      |       NULL                                         AS icd_diag_cd1_poa_indicator,
      |       c.Member_Dob                                 AS member_dob,
      |       c.Member_First_Name                          AS member_fname ,
      |       c.Member_Gender                              AS member_gender_code,
      |       c.Member_last_Name                           AS member_lname,
      |       NULL                                         AS pcp_id,
      |       NULL                                         AS pcp_npi,
      |       NULL                                         AS pat_liability_amt,
      |       c.paid_amount_sum_2                          AS payment_amt,
      |       c.paid_date_sum_2                            AS pay_process_date,
      |       c.pos                                        AS place_of_service,
      |       NULL                                         AS principle_proc_cd,
      |       NULL                                         AS principle_proc_icd_type ,
      |       nullif(substr(c.proc_code,6,7), '')                      AS proc_cd_modifier_1,
      |       NULL                                         AS proc_cd_modifier_2,
      |       NULL                                         AS proc_cd_modifier_3,
      |       nullif(substr(c.proc_code,1,5), '')                      AS proc_code,
      |       c.Units_sum_2                                AS quantity_of_service,
      |       c.Charge_amount_sum_2                        AS requested_amt,
      |       c.Revenue_Code                               AS revenue_code,
      |       c.from_Date                                  AS service_from_date,
      |       c.thru_Date                                  AS service_to_date,
      |       c.Servicing_Prov_Name                        AS servicing_prov_name,
      |       c.Servicing_Prov_Npi                         AS servicing_prov_id,
      |       c.Servicing_Prov_Npi                         AS servicing_prov_npi,
      |       concat_ws('', '{client_ds_id}.', c.Servicing_Prov_Specialty)    AS servicing_prov_spclty_cd,
      |       c.Servicing_Prov_Specialty                   AS servicing_prov_spclty_desc,
      |       zo.employeraccountid                         AS source_code,
      |       NULL                                         AS type_of_bill_code,
      |       NULL                                         AS type_of_service,
      |       NULL                                         AS denied_reason,
      |       NULL                                         AS network_status_flag,
      |       case when c.network_indicator = 'I' then 'Y' when c.network_indicator = 'O' then 'N'  else null end  AS par_flag,
      |       NULL                                         AS Ordering_Prov_Id,
      |       zo.employeraccountid                         AS payer_code,
      |       zo.employeraccountid                         AS payer_name,
      |       zo.employeraccountid                         AS plan_code,
      |       zo.employeraccountid                         AS plan_name,
      |       NULL                                         AS product_code,
      |       NULL                                         AS product_name,
      |       NULL                                         AS withhold_amt
      |from (
      |        select
      |         sum(b.Units_sum_1) over (partition by b.rollup_id) as Units_sum_2
      |        ,sum(b.Charge_amount_sum_1) over (partition by b.rollup_id) as Charge_amount_sum_2
      |        ,sum(b.paid_amount_sum_1) over (partition by b.rollup_id) as paid_amount_sum_2
      |        ,sum(b.allow_amount_sum_1) over (partition by b.rollup_id) as allow_amount_sum_2
      |        ,max(b.paid_date_sum_1) over (partition by b.rollup_id) as paid_date_sum_2
      |        ,row_number() over (partition by b.rollup_id order by b.paid_date_sum_1 desc nulls last, claim_header_line_id desc nulls first) as rn_3
      |        ,b.*
      |        from (
      |                select
      |                 sum(a.units) over (partition by a.claim_header_line_id) as Units_sum_1
      |                ,sum(a.Charge_amount) over (partition by a.claim_header_line_id) as Charge_amount_sum_1
      |                ,sum(a.paid_amount) over (partition by a.claim_header_line_id) as paid_amount_sum_1
      |                ,sum(a.allow_amount) over (partition by a.claim_header_line_id) as allow_amount_sum_1
      |                ,max(a.paid_date) over (partition by a.claim_header_line_id) as paid_date_sum_1
      |                ,row_number() over (partition by a.claim_header_line_id order by a.paid_date desc nulls last) as rn_2
      |                ,a.*
      |                from(
      |                        select
      |                        concat_ws('', CLAIM_NUMBER, '_', SERVICE_KEY) as claim_header_line_id
      |                        ,concat_ws('', subscriber_number, '-', member_number, '-', servicing_prov_npi, '-', upper(date_format(from_date, 'dd-MMM-yy')), '-', upper(date_format(THRU_DATE, 'dd-MMM-yy')), '-', proc_code, '-', pos, '-', REVENUE_CODE) as rollup_id
      |                        ,concat_ws('', subscriber_number, '-', member_number, '-', servicing_prov_npi, '-', upper(date_format(from_date, 'dd-MMM-yy')), '-', upper(date_format(THRU_DATE, 'dd-MMM-yy')), '_', pos) as encounter_id
      |                        ,d.*
      |                        ,row_number() over (partition by CLAIM_NUMBER, SERVICE_KEY, count_line order by paid_date desc nulls first) as rn_1
      |                        from CLCPV d
      |
      |
      |                ) a where rn_1=1
      |        ) b where rn_2=1
      |) c
      |cross join ZO_BPO_MAP_EMPLOYER zo on 1=1 and zo.client_ds_id = {client_ds_id}
      |where rn_3=1
      |)
      |
      |union all
      |
      |select datasrc, admit_date, admit_source_code, admit_type_code, allowed_amt, coord_benifits_amt, capitated_service_flag, claim_header_id, claim_line_id, claim_type, coinsurance_amt, copay_amt, diag_rel_grp_code, diag_rel_grp_grouper, deductable_amt, financial_class, pcp_id, pcp_npi, denied_flag, discharge_date, discharge_status_code, facility_code, facility_name, icd_diag_cd1, icd_diag_cd1_poa_indicator, member_dob, member_fname, member_gender_code, member_id, member_lname, pat_liability_amt, payment_amt, pay_process_date, place_of_service, principle_proc_cd, principle_proc_icd_type, proc_cd_modifier_1, proc_cd_modifier_2, proc_cd_modifier_3, proc_code, quantity_of_service, requested_amt, revenue_code, service_date, service_from_date, service_to_date, servicing_prov_name, servicing_prov_id, servicing_prov_npi, source_code, type_of_bill_code, type_of_service, denied_reason, network_status_flag, Ordering_Prov_Id, payer_code, payer_name, product_code, product_name, servicing_prov_spclty_cd, servicing_prov_spclty_desc, par_flag, plan_code, plan_name, withhold_amt, encounterid
      |from
      |(
      |select
      |       distinct
      |       'cldev'                                      AS datasrc,
      |       c.encounter_id                               AS claim_header_id,
      |       c.encounter_id                               AS encounterid,
      |       concat_ws('', c.subscriber_number, '-', c.member_number)    AS member_id,
      |       c.from_date                                  AS service_date,
      |       NULL                                         AS admit_date,
      |       NULL                                         AS admit_source_code,
      |       NULL                                         AS admit_type_code,
      |       c.allow_amount_sum_2                         AS allowed_amt,
      |       NULL                                         AS coord_benifits_amt,
      |       NULL                                         AS capitated_service_flag,
      |       NULL                                         AS claim_line_id,
      |       NULL                                         AS claim_type,
      |       NULL                                         AS coinsurance_amt,
      |       NULL                                         AS copay_amt,
      |       'Commercial'                                 AS financial_class,
      |       c.drg_code                                   AS diag_rel_grp_code,
      |       'MSDRG'                                      AS diag_rel_grp_grouper,
      |       NULL                                         AS deductable_amt,
      |       NULL                                         AS denied_flag,
      |       case when c.discharge_date = '17530101' then  NULL
      |          else safe_to_date(c.discharge_date,'yyyyMMdd') end AS discharge_date,
      |       NULL                                         AS discharge_status_code,
      |       NULL                                         AS facility_code,
      |       NULL                                         AS facility_name,
      |       c.Medical_Diag_Code                          AS icd_diag_cd1,
      |       c.Diagnosis_Code                             AS icd_diag_cd2,
      |       NULL                                         AS icd_diag_cd1_poa_indicator,
      |       c.Member_Dob                                 AS member_dob,
      |       c.Member_First_Name                          AS member_fname ,
      |       c.Member_Gender                              AS member_gender_code,
      |       c.Member_last_Name                           AS member_lname,
      |       NULL                                         AS pcp_id,
      |       NULL                                         AS pcp_npi,
      |       NULL                                         AS pat_liability_amt,
      |       c.paid_amount_sum_2                          AS payment_amt,
      |       c.paid_date_sum_2                            AS pay_process_date,
      |       c.pos                                        AS place_of_service,
      |       NULL                                         AS principle_proc_cd,
      |       NULL                                         AS principle_proc_icd_type ,
      |       nullif(substr(c.proc_code,6,7), '')                      AS proc_cd_modifier_1,
      |       NULL                                         AS proc_cd_modifier_2,
      |       NULL                                         AS proc_cd_modifier_3,
      |       nullif(substr(c.proc_code,1,5), '')                      AS proc_code,
      |       c.Units_sum_2                                AS quantity_of_service,
      |       c.Charge_amount_sum_2                        AS requested_amt,
      |       c.Revenue_Code                               AS revenue_code,
      |       c.from_Date                                  AS service_from_date,
      |       c.thru_Date                                  AS service_to_date,
      |       c.Servicing_Prov_Name                        AS servicing_prov_name,
      |       c.Servicing_Prov_Npi                         AS servicing_prov_id,
      |       c.Servicing_Prov_Npi                         AS servicing_prov_npi,
      |       concat_ws('', '{client_ds_id}.', c.Servicing_Prov_Specialty)    AS servicing_prov_spclty_cd,
      |       c.Servicing_Prov_Specialty                   AS servicing_prov_spclty_desc,
      |       zo.employeraccountid                         AS source_code,
      |       NULL                                         AS type_of_bill_code,
      |       NULL                                         AS type_of_service,
      |       NULL                                         AS denied_reason,
      |       NULL                                         AS network_status_flag,
      |       case when c.network_indicator = 'I' then 'Y' when c.network_indicator = 'O' then 'N'  else null end  AS par_flag,
      |       NULL                                         AS Ordering_Prov_Id,
      |       zo.employeraccountid                         AS payer_code,
      |       zo.employeraccountid                         AS payer_name,
      |       zo.employeraccountid                         AS plan_code,
      |       zo.employeraccountid                         AS plan_name,
      |       NULL                                         AS product_code,
      |       NULL                                         AS product_name,
      |       NULL                                         AS withhold_amt
      |from (
      |        select
      |         sum(b.Units_sum_1) over (partition by b.rollup_id) as Units_sum_2
      |        ,sum(b.Charge_amount_sum_1) over (partition by b.rollup_id) as Charge_amount_sum_2
      |        ,sum(b.paid_amount_sum_1) over (partition by b.rollup_id) as paid_amount_sum_2
      |        ,sum(b.allow_amount_sum_1) over (partition by b.rollup_id) as allow_amount_sum_2
      |        ,max(b.paid_date_sum_1) over (partition by b.rollup_id) as paid_date_sum_2
      |        ,row_number() over (partition by b.rollup_id order by b.paid_date_sum_1 desc nulls last, claim_header_line_id desc nulls first) as rn_3
      |        ,b.*
      |        from (
      |                select
      |                 sum(a.units) over (partition by a.claim_header_line_id) as Units_sum_1
      |                ,sum(a.Charge_amount) over (partition by a.claim_header_line_id) as Charge_amount_sum_1
      |                ,sum(a.paid_amount) over (partition by a.claim_header_line_id) as paid_amount_sum_1
      |                ,sum(a.allow_amount) over (partition by a.claim_header_line_id) as allow_amount_sum_1
      |                ,max(a.paid_date) over (partition by a.claim_header_line_id) as paid_date_sum_1
      |                ,row_number() over (partition by a.claim_header_line_id order by a.paid_date desc nulls last) as rn_2
      |                ,a.*
      |                from(
      |                        select
      |                        concat_ws('', CLAIM_NUMBER, '_', SERVICE_KEY) as claim_header_line_id
      |                        ,concat_ws('', subscriber_number, '-', member_number, '-', servicing_prov_npi, '-', upper(date_format(from_date, 'dd-MMM-yy')), '-', upper(date_format(THRU_DATE, 'dd-MMM-yy')), '-', proc_code, '-', pos, '-', REVENUE_CODE) as rollup_id
      |                        ,concat_ws('', subscriber_number, '-', member_number, '-', servicing_prov_npi, '-', upper(date_format(from_date, 'dd-MMM-yy')), '-', upper(date_format(THRU_DATE, 'dd-MMM-yy')), '_', pos) as encounter_id
      |                        ,d.*
      |                        ,row_number() over (partition by CLAIM_NUMBER, SERVICE_KEY, count_line order by paid_date desc nulls first) as rn_1
      |                        from CLDEV d
      |
      |
      |                ) a where rn_1=1
      |        ) b where rn_2=1
      |) c
      |cross join ZO_BPO_MAP_EMPLOYER zo on 1=1 and zo.client_ds_id = {client_ds_id}
      |where rn_3=1
      |)
    """.stripMargin
}

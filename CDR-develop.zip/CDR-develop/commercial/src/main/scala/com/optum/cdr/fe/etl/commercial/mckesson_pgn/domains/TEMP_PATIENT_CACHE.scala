package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.mckesson_pgn_patient_cache
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object TEMP_PATIENT_CACHE extends FETableInfo[mckesson_pgn_patient_cache]{

  override def name: String = "TEMP_PATIENT_CACHE"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT", "MCKESSON_PGN_V1_TSM040_PERSON_HDR", "MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val cdsid_prefix = runtimeVar.clientDsId + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH uni_visit AS (
        |SELECT  *
        |FROM
        |(
        |	SELECT  v.*
        |	       ,ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
        |	FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        |	WHERE Psn_Int_Id IS NOT NULL
        |	AND Med_Rec_No IS NOT NULL
        |)
        |WHERE rn = 1
        |AND row_sta_cd <> 'D' )
        |SELECT  '{groupid}'                                                                                                         AS groupid
        |       ,'person_hdr'                                                                                                        AS datasrc
        |       ,{client_ds_id}                                                                                                      AS client_ds_id
        |       ,hdr.Psn_Int_Id                                                                                                      AS patientid
        |       ,uni_visit.Med_Rec_No                                                                                                AS medicalrecordnumber
        |       ,hdr.Bth_Ts                                                                                                          AS dateofbirth
        |       ,hdr.dth_Ts                                                                                                          AS dateofdeath
        |       ,NVL2(COALESCE(hdr.eeoc_cd,hdr.eeoc_2_cd,hdr.eth_003_cd,hdr.eth_004_cd,hdr.eth_005_cd,hdr.eeoc_oth_ds),concat_ws('','{cdsid_prefix}',COALESCE(hdr.eeoc_cd,hdr.eeoc_2_cd,hdr.eth_003_cd,hdr.eth_004_cd,hdr.eth_005_cd,hdr.eeoc_oth_ds)),NULL) AS ethnicity
        |       ,NVL2(COALESCE(Hdr.Rac_Cd,Hdr.Rac_2_Cd,Hdr.Rac_003_Cd,Hdr.Rac_004_Cd,Hdr.Rac_005_Cd,Hdr.Rac_Oth_Ds),concat_ws('','{cdsid_prefix}',COALESCE(Hdr.Rac_Cd,Hdr.Rac_2_Cd,Hdr.Rac_003_Cd,Hdr.Rac_004_Cd,Hdr.Rac_005_Cd,Hdr.Rac_Oth_Ds)),NULL) AS race
        |       ,NVL2(hdr.Mry_Sta_Cd,concat_ws('','{cdsid_prefix}',hdr.Mry_Sta_Cd),NULL)                                      AS Maritalstatus
        |       ,hdr.Fst_Nm                                                                                                          AS firstname
        |       ,hdr.Lst_Nm                                                                                                          AS lastname
        |       ,hdr.mid_nm                                                                                                          AS middlename
        |       ,NVL2(hdr.Sex_Cd,concat_ws('','{cdsid_prefix}',hdr.Sex_Cd),NULL)                                              AS gender
        |       ,CASE WHEN hdr.row_sta_cd = 'I' THEN 'Y' ELSE NULL END                                                               AS inactive_flag
        |       ,COALESCE(hdr.Lst_Mod_Ts,hdr.enr_ts)                                                                                 AS PATDETAIL_TIMESTAMP
        |       ,NVL2(hdr.Pri_Lng_Cd,concat_ws('','{cdsid_prefix}',hdr.Pri_Lng_Cd),NULL)                                      AS language
        |       ,zh.Cod_Dtl_Ds                                                                                                       AS religion_cd
        |       ,CASE WHEN hdr.soc_scu_no <> '0' THEN hdr.soc_scu_no END                                                             AS ssn
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST,hdr.FileID DESC nulls first) AS rownumber
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(hdr.Fst_Nm) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST)           AS first_row
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(hdr.lst_Nm) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST)           AS last_row
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(hdr.mid_Nm) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST)           AS middle_row
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(hdr.Sex_Cd) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST)           AS gender_row
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(COALESCE(hdr.eeoc_cd,hdr.eeoc_2_cd,hdr.eth_003_cd,hdr.eth_004_cd,hdr.eth_005_cd,hdr.eeoc_oth_ds)) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST) AS ethnicity_row
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(COALESCE(Hdr.Rac_Cd,Hdr.Rac_2_Cd,Hdr.Rac_003_Cd,Hdr.Rac_004_Cd,Hdr.Rac_005_Cd,Hdr.Rac_Oth_Ds)) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST) AS race_row
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(hdr.Mry_Sta_Cd) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST)       AS mstatus_row
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(hdr.Pri_Lng_Cd) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST)       AS language_row
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(zh.Cod_Dtl_Ds) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST)        AS religion_row
        |       ,ROW_NUMBER() OVER (PARTITION BY hdr.Psn_Int_Id,UPPER(hdr.Soc_Scu_No) ORDER BY hdr.Lst_Mod_Ts DESC NULLS LAST)       AS ssn_row
        |FROM MCKESSON_PGN_V1_TSM040_PERSON_HDR hdr
        |LEFT OUTER JOIN MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL zh
        |ON (hdr.rgn_cd = zh.cod_dtl_int_id)
        |LEFT OUTER JOIN UNI_VISIT
        |ON (hdr.psn_int_id = uni_visit.psn_int_id)
        |WHERE hdr.Row_Sta_CD <> 'D'
        |AND hdr.Psn_Int_Id IS NOT NULL
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{cdsid_prefix}", cdsid_prefix)
    )
  }


}

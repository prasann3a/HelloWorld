package com.optum.cdr.fe.etl.commercial.med3000.domains


import com.optum.oap.cdr.models.rx_patient_reported
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT_REPORTED_MEDS extends FEQueryAndMetadata[rx_patient_reported] {

  override def name: String = CDRFEParquetNames.rx_patient_reported

  override def dependsOn: Set[String] = Set("MED3000_PATIENT_MEDICATIONS", "MED3000_ZH_MEDICATION_MASTER", "MED3000_ZH_MED_ROUTES","MED3000_ZH_MED_FORMS")

  override def sparkSql: String =
    """|select groupid, datasrc, client_ds_id, patientid, categorycode as localcategorycode, discontinuedate, nullif(replace(discontinuereason,'-',''), '') as discontinuereason, localdoseunit, localdrugdescription, localform, localmedcode, localndc, localroute, rxnormcode as rxnorm_code, localqtyofdoseunit, localstrengthperdoseunit, localstrengthunit, localtotaldose, medreportedtime, reportedmedid
       |from
       |(
       |select groupid,datasrc,client_ds_id,patientid,categorycode,discontinuedate,discontinuereason,localdoseunit,localdrugdescription,
       |       localform,localmedcode,localndc,localqtyofdoseunit,localroute,medreportedtime,reportedmedid,rxnormcode,Med_Strength,
       |       safe_to_number(dose_final) * safe_to_number(Quantity_final) as localtotaldose, localstrengthunit,
       |       dose_final  as localstrengthperdoseunit,
       |       row_number() over (partition by reportedmedid,medreportedtime order by update_date desc nulls last) as rank_rxpat
       | from (
       |select groupid,datasrc,client_ds_id,patientid,categorycode,  discontinuedate,discontinuereason,localdoseunit,localdrugdescription,
       |       localform,localmedcode,localndc,localqtyofdoseunit,localroute,medreportedtime,reportedmedid,rxnormcode,update_date,Med_Strength,localstrengthunit,
       |       case when dose2 is not null and safe_to_number(dose2) < safe_to_number(dose1) then dose2 else dose1 end as dose_final,
       |       nullif(regexp_extract(Qty_transformed, '[0-9\\,\\.]+', 0), '') as Quantity_final
       |  from  (
       |select
       |       '{groupid}' 			as groupid
       |       ,'pat_medications' 	as datasrc
       |	   ,{client_ds_id}		as client_ds_id
       |       ,med.Blind_Key  		as patientid
       |       ,case when med.Exp_Date is null then '1' else '2' end as categorycode
       |       ,med.Exp_Date  						as discontinuedate
       |       ,med.Inactivated_Reason  			as discontinuereason
       |       ,coalesce(nullif(replace(med.Quantity_Units,'-',''), ''), nullif(replace(med.Med_Form ,'-',''), '')) as localdoseunit
       |       ,med.Med_Name  						as localdrugdescription
       |       ,coalesce(nullif(replace(med.Med_Form,'-',''), ''), nullif(replace(mfrm.form_desc,'-',''), ''))  		as localform
       |       ,med.Med_Record_No  	as localmedcode
       |       ,mast.Ndc_Number  	as localndc
       |       ,med.Quantity  		as localqtyofdoseunit
       |       ,coalesce(nullif(replace(med.Med_Route,'-',''), ''),nullif(replace(mrt.route_desc,'-',''), ''))  		as localroute
       |       ,coalesce(med.Prescribing_Date,med.Create_Date)  as medreportedtime
       |       ,med.Record_No  		as reportedmedid
       |       ,mast.Rxcui  		as rxnormcode
       |       ,med.update_date
       |       ,med.Med_Strength
       |	   ,nullif(regexp_extract( Med_Strength, '[0-9\\,\\.]+', 0), '')         as dose1
       |       ,nullif(regexp_substr(Med_Strength, '[0-9,\\.]+', 1, 2), '')     as dose2
       |       ,nullif(regexp_replace(nullif(regexp_extract(lower(med.med_strength), '[-0-9\\,\\.]+.*', 0), ''),'^[0-9 \\,\\.]+',''), '') as localstrengthunit
       |       ,case when Quantity like '1/2%' then '0.5'
       |             when Quantity like '1/4%' then '0.25'
       |             when Quantity like '3/4%' then '0.75'
       |             when Quantity like '1/3%' then '0.33'
       |             when Quantity like '2/3%' then '0.66'
       |             when Quantity like '1/8%' then '0.125'
       |			 when Quantity like '2 1/2%' then '2.5'
       |			 when Quantity like '1 2/3%' then '1.66'
       |			 when Quantity like '1 1/2%' then '1.50'
       |			 when Quantity like '2 1/4%' then '2.25'
       |			 when Quantity like '1 3/4%' then '1.75'
       |			 when Quantity like '1 1/3%' then '1.33'
       |			 when Quantity like '1 1/4%' then '1.25'
       |        else Quantity end Qty_transformed
       |  from MED3000_PATIENT_MEDICATIONS med
       | inner join MED3000_ZH_MEDICATION_MASTER mast ON (med.Med_Record_No = mast.Med_Master_Recno)
       | left outer join MED3000_ZH_MED_ROUTES mrt ON (mast.med_route_recno = mrt.route_recno)
       | left outer join MED3000_ZH_MED_FORMS mfrm ON (mast.med_form_recno = mfrm.form_recno)
       | where med.Prescription_Number is null
       |  ))
       |
       |
       |)
       |where patientid is not null and rank_rxpat = 1""".stripMargin
}

package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_provider_contact
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROV_CONTACT_STAFFREG extends FETableInfo[zh_provider_contact] {

  override def name: String = "PROV_CONTACT_STAFFREG"

  override def dependsOn: Set[String] = Set("CENTRICV2_ZH_STAFFREG")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val sqlQuery =
      """
        |select groupid, client_ds_id, datasrc, local_provider_id, email_address, update_date, address_line1, address_line2, city, state, zipcode, work_phone, local_contact_type, mapped_contact_type
        |from
        |(
        |SELECT  '{groupid}'              AS groupid
        |       ,'{client_ds_id}'       AS client_ds_id
        |       ,'zh_staffreg'         AS datasrc
        |       ,pvId                  AS local_provider_id
        |       ,NULL                  AS email_address
        |       ,Db_Updated_Date	      AS update_date
        |       ,NULL	              AS address_line1
        |       ,NULL                  AS address_line2
        |       ,NULL                  AS city
        |       ,NULL                  AS state
        |       ,NULL                  AS zipcode
        |       ,nullif(regexp_replace(phone,'([a-zA-Z&/])+',''), '') AS work_phone
        |       ,'PROVIDER'            AS local_contact_type
        |       ,NULL                  AS mapped_contact_type
        |       ,ROW_NUMBER() OVER (PARTITION BY pvId ORDER BY Db_Updated_Date DESC nulls first) AS rn
        |FROM CENTRICV2_ZH_STAFFREG
        |WHERE pvid IS NOT NULL
        |  AND Db_Updated_Date IS NOT NULL
        |
        |)
        |where rn = 1 AND LENGTH(work_phone) >= 10
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId)

    sparkSession.sql(sqlQuery)
  }

}
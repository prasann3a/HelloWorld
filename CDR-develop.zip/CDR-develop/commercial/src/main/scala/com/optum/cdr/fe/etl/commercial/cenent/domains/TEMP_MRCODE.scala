package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.etl.commercial.cenent_claim_proc_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata


object TEMP_MRCODE extends FEQueryAndMetadata[cenent_claim_proc_cache] {

  override def name: String = "TEMP_MRCODE"

  override def dependsOn: Set[String] = Set("CHRG", "ENCNTR", "MRCODE")

  override def sparkSql: String =
    """
      |with claim_enc
      |as
      |(select distinct num,pat_person_num,begin_dttm,end_dttm,fac_num,dept_num,loc_num,prim_acct_num,alt_acct_num,encntr_type_cde,
      |        encntr_cat_cde,encntr_dispo_cde,encntr_dispo_reason_cde,medical_serv_cde,prim_prov_assoc_num,refer_from_assoc_num,
      |		refer_to_assoc_num,sched_dttm,sched_prov_assoc_num,arrival_mode_cde,acuity_cde,los_days,los_mnts,accident_dttm,
      |		enscribe_auth_ptr,enscribe_trnscrpt_ptr,data_src_id,data_src_encntr_id,data_sec_cde,data_status_cde,data_create_ts,
      |		data_create_user_assoc_num,data_ts,data_user_assoc_num,reason_txt
      |   from ENCNTR where encntr_cat_cde ='ACTV'  ),
      |claim_max
      |as
      |(select  distinct event_ptr, acct_num, chrg_cpt4_seq, chrg_service_provider, service_date, chrg_cpt4_modifier,
      |        max(date_modified) over ( partition by event_ptr,acct_num, chrg_cpt4_seq, chrg_service_provider, service_date, chrg_cpt4_modifier) as dmod
      |   from CHRG  c where claim_date is not null and chrg_cpt4_seq is not null ),
      |claim_sum
      |as
      |(select  distinct c.acct_num x, c.event_ptr, c.chrg_cpt4_seq, c.service_date,c.location,
      |        sum(c.quantity) over (partition by c.acct_num, c.event_ptr, c.chrg_cpt4_seq, c.service_date, c.location) as quan,
      |        sum(c.price) over (partition by c.acct_num, c.event_ptr, c.chrg_cpt4_seq, c.service_date, c.location) as pr
      |   from CHRG c
      |  inner join CLAIM_MAX f
      |on (c.date_modified=f.dmod and
      |         c.acct_num=f.acct_num and
      |         c.chrg_cpt4_seq=f.chrg_cpt4_seq and
      |         c.chrg_service_provider=f.chrg_service_provider and
      |         c.service_date=f.service_date and
      |         coalesce(c.chrg_cpt4_modifier,'0')= coalesce(f.chrg_cpt4_modifier,'0') and
      |         c.event_ptr=f.event_ptr)  ),
      |claim_mr_type
      |as
      |(select * from(
      | select distinct mr.acct_num, mr.mrcode_seq, mr.mrcode_proc_date, mr.mrcode_text, mr.mrcode_ub82_category,
      |                 mr.mrcode_add_date, mr.mrcode_add_time, mr.mrcode_proc_md,mr.mrcode_event_ptr
      |   from MRCODE mr where mrcode_type = 'C'  )),
      |claim_type_sum
      |as
      |(select * from CLAIM_MR_TYPE a
      |   left join CLAIM_SUM nc on (a.acct_num=nc.x and a.mrcode_event_ptr=nc.event_ptr))
      |select
      |       distinct '{groupid}' 		as groupid
      |	   ,'mrcode' 				as datasrc
      |	   ,{client_ds_id} 			as client_ds_id
      |	   ,m.Mrcode_Text 			as localcode
      |	   ,e.Pat_Person_Num 		as patientid
      |	   ,m.Mrcode_Proc_Date 		as servicedate
      |	   ,e.Fac_Num 				as facilityid
      |	   ,m.Mrcode_Seq 			as procseq
      |	   ,e.Refer_From_assoc_Num 	as referproviderid
      |	   ,m.Mrcode_Proc_Date 		as actualprocdate
      |	   ,e.Num 					as encounterid
      |	   ,case when Encntr_Type_Cde in('C','N','S') then 'N' else 'Y' end as hosp_px_flag
      |	   ,mrcode_proc_md		    as performingproviderid
      |
      |
      |  from CLAIM_ENC e
      | inner join CLAIM_TYPE_SUM m
      |    on (m.acct_num=e.prim_acct_num and
      |     (nullif(concat_ws('', date_format(m.mrcode_add_date, 'yyyyMMdd'), lpad(m.mrcode_add_time,4,0)), '')= date_format(e.data_ts,'yyyyMMddHHmm')
      |         or date_format(m.mrcode_proc_date,'yyyyMMdd') between date_format(e.begin_DTTM,'yyyyMMdd')  and date_format(e.end_dttm,'yyyyMMdd'))
      |            )
    """.stripMargin

}

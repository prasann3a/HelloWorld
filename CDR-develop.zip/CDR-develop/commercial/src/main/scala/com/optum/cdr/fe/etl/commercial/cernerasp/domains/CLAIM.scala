package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{claim, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object CLAIM extends FETableInfo[claim]{

  override def name: String = CDRFEParquetNames.claim

  override def dependsOn: Set[String] = Set("CHARGE", "CHARGEDETAIL", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listCpt = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "CPT","CLAIM","CHARGEDETAIL","HUM_TYPE").mkString(",")
    val listCptMod = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "CPT_MOD","CLAIM","CHARGEDETAIL","HUM_TYPE").mkString(",")
    val listHcpcs = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "HCPCS","CLAIM","CHARGEDETAIL","HUM_TYPE").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,client_ds_id
        |       ,datasrc
        |       ,claimid
        |       ,localcpt
        |       ,patientid
        |       ,servicedate
        |       ,encounterid
        |       ,localcptmod1
        |       ,localcptmod2
        |       ,localcptmod3
        |       ,localcptmod4
        |       ,seq
        |       ,mappedcpt
        |       ,localcptmod1 AS mappedcptmod1
        |       ,localcptmod2 AS mappedcptmod2
        |       ,localcptmod3 AS mappedcptmod3
        |       ,localcptmod4 AS mappedcptmod4
        |       ,claimproviderid
        |       ,localbillingproviderid
        |       ,post_dt
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                                                                            AS groupid
        |	       ,{client_ds_id}                                                                                                                         AS client_ds_id
        |	       ,'charge'                                                                                                                               AS datasrc
        |	       ,c.unique_charge_item_identifier                                                                                                        AS claimid
        |	       ,MAX(case WHEN cd.hum_type IN ({LIST_CPT},{LIST_HCPCS}) THEN cd.code else null end) over (partition by c.unique_charge_item_identifier) AS localcpt
        |	       ,c.unique_person_identifier                                                                                                             AS patientid
        |	       ,c.service_date_time                                                                                                                    AS servicedate
        |	       ,c.unique_visit_identifier                                                                                                              AS encounterid
        |	       ,MAX(case WHEN cd.hum_type IN ({LIST_CPT_MOD}) AND cd.hum_sequence = '1' THEN cd.code else null end) over (partition by c.unique_charge_item_identifier) AS localcptmod1
        |	       ,MAX(case WHEN cd.hum_type IN ({LIST_CPT_MOD}) AND cd.hum_sequence = '2' THEN cd.code else null end) over (partition by c.unique_charge_item_identifier) AS localcptmod2
        |	       ,MAX(case WHEN cd.hum_type IN ({LIST_CPT_MOD}) AND cd.hum_sequence = '3' THEN cd.code else null end) over (partition by c.unique_charge_item_identifier) AS localcptmod3
        |	       ,MAX(case WHEN cd.hum_type IN ({LIST_CPT_MOD}) AND cd.hum_sequence = '4' THEN cd.code else null end) over (partition by c.unique_charge_item_identifier) AS localcptmod4
        |	       ,CASE WHEN cd.hum_type IN ({LIST_CPT},{LIST_HCPCS}) THEN cd.hum_sequence ELSE null END                                                  AS seq
        |	       ,MAX(case WHEN cd.hum_type IN ({LIST_CPT},{LIST_HCPCS}) THEN cd.code else null end) over (partition by c.unique_charge_item_identifier) AS mappedcpt
        |	       ,CASE WHEN c.performing_physician_id = '0' THEN null ELSE c.performing_physician_id END                                                 AS claimproviderid
        |	       ,coalesce(nullif(c.ordering_physician_identifier,'0'),c.verifying_physician_identifier)                                                 AS localbillingproviderid
        |	       ,c.posted_date_time                                                                                                                     AS post_dt
        |	       ,row_number() over (partition by c.unique_charge_item_identifier ORDER BY c.update_date_time desc nulls last)                           AS rownumber
        |	FROM CHARGE c
        |	INNER JOIN CHARGEDETAIL cd
        |	ON (c.unique_charge_item_identifier = cd.unique_charge_item_identifier)
        |	WHERE c.unique_charge_item_identifier is not null
        |	AND c.unique_person_identifier is not null
        |	AND c.service_date_time is not null
        |	AND cd.hum_type IN ({LIST_CPT},{LIST_CPT_MOD},{LIST_HCPCS})
        |	AND c.active <> '0'
        |)
        |WHERE rownumber=1
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{LIST_CPT}", listCpt)
        .replace("{LIST_CPT_MOD}", listCptMod)
        .replace("{LIST_HCPCS}", listHcpcs)
    )
  }
}

package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXORDER2 extends FETableInfo[rxorder]{
  override def name:String ="RXORDER2"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_DAW= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DAW", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DISCON_REASON= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DISCON_REAON", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_QUANTITY_FILL= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "QUANTITY_FILL", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_REFILL= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "REFILL", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_SIGNATURE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "SIGNATURE", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_STRG_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STRG_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DOSE_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DOSE_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DURATION= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DURATION", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_DURATION_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DURATION_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_FREQUENCY= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "FREQUENCY", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_QTY_DOSE_UNIT= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "QTY_DOSE_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_ROUTE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "ROUTE", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_STRG_DOSE_UNIT=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STRG_DOSE_UNIT", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_STRG_DOSE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "STRG_DOSE", "RX", "RX", "DETAIL_QUESTION").mkString(",")
    val list_MED_STATUS= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "MED_STATUS", "RX", "MEDICATION", "STATUS").mkString(",")
    val list_HUM_TYPE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "RX_HUM_TYPE", "RX", "ORDERS", "HUM_TYPE").mkString(",")
    val list_HUM_ACTION= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "HUM_ACTION", "RX", "MEDICATIONRECONCILIATIONDETAIL", "HUM_ACTION").mkString(",")
    val list_RX_HUM_TYPE= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "RX_HUM_TYPE", "RX", "ORDERS", "HUM_TYPE").mkString(",")
    val list_ORD_STATUS= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "ORD_STATUS", "RX", "ORDERS", "STATUS").mkString(",")

    sparkSession.sql(
      s"""
         |select groupid, datasrc, client_ds_id, issuedate, ordervsprescription, patientid, rxid, altmedcode, encounterid, localdaw, localdosefreq, localdoseunit, localdescription,  localform, localgenericdesc, localmedcode, localndc, localqtyofdoseunit, localroute, localstrengthperdoseunit, localstrengthunit, orderstatus, rxnorm_code, signature, venue, ordertype, discontinuedate, discontinuereason, fillnum, quantityperfill
         |,nvl(safe_to_number(localstrengthperdoseunit),0) * nvl(safe_to_number(localqtyofdoseunit),0) as localtotaldose
         |,case when rlike(localdosefreq,'(?i)(8 times)') then safe_to_number(QUANTITYPERFILL)/8
         |when rlike(localdosefreq,'(?i)(6 times)') then safe_to_number(QUANTITYPERFILL)/6
         |when rlike(localdosefreq,'(?i)(5 times)') then safe_to_number(QUANTITYPERFILL)/5
         |when rlike(localdosefreq,'(?i)(4 times|qid|four)') then safe_to_number(QUANTITYPERFILL)/4
         |when rlike(localdosefreq,'(?i)(3 times|tid|three)') and rlike(QUANTITYPERFILL,'(?i)one') then 1/3
         |when rlike(localdosefreq,'(?i)(3 times|tid|three)') then safe_to_number(QUANTITYPERFILL)/3
         |when rlike(localdosefreq,'(?i)(2 times|bid|twice)') and rlike(QUANTITYPERFILL,'(?i)one') then 1/2
         |when rlike(localdosefreq,'(?i)(2 times|bid|twice)') and rlike(QUANTITYPERFILL,'(?i)two') then 2/2
         |when rlike(localdosefreq,'(?i)(2 times|bid|twice)') then safe_to_number(QUANTITYPERFILL)/2
         |when rlike(localdosefreq,'(?i)(every.*other.*day)') then safe_to_number(QUANTITYPERFILL)*2
         |when rlike(localdosefreq,'(?i)(once|qd|q[ap]m|daily|day)') and rlike(QUANTITYPERFILL,'(?i)one') then 1
         |when rlike(localdosefreq,'(?i)(once|qd|q[ap]m|daily|day)') and rlike(QUANTITYPERFILL,'(?i)two') then 2
         |when rlike(localdosefreq,'(?i)(once|qd|q[ap]m|daily|day)') then safe_to_number(QUANTITYPERFILL)
         |else null end as localDAYSUPPLIED
         |,case when rlike(localdosefreq,'(?i)(8 times)') then safe_to_number(QUANTITYPERFILL)/8
         |when rlike(localdosefreq,'(?i)(6 times)') then safe_to_number(QUANTITYPERFILL)/6
         |when rlike(localdosefreq,'(?i)(5 times)') then safe_to_number(QUANTITYPERFILL)/5
         |when rlike(localdosefreq,'(?i)(4 times|qid|four)') then safe_to_number(QUANTITYPERFILL)/4
         |when rlike(localdosefreq,'(?i)(3 times|tid|three)') and rlike(QUANTITYPERFILL,'(?i)one') then 1/3
         |when rlike(localdosefreq,'(?i)(3 times|tid|three)') then safe_to_number(QUANTITYPERFILL)/3
         |when rlike(localdosefreq,'(?i)(2 times|bid|twice)') and rlike(QUANTITYPERFILL,'(?i)one') then 1/2
         |when rlike(localdosefreq,'(?i)(2 times|bid|twice)') and rlike(QUANTITYPERFILL,'(?i)two') then 2/2
         |when rlike(localdosefreq,'(?i)(2 times|bid|twice)') then safe_to_number(QUANTITYPERFILL)/2
         |when rlike(localdosefreq,'(?i)(every.*other.*day)') then safe_to_number(QUANTITYPERFILL)*2
         |when rlike(localdosefreq,'(?i)(once|qd|q[ap]m|daily|day)') and rlike(QUANTITYPERFILL,'(?i)one') then 1
         |when rlike(localdosefreq,'(?i)(once|qd|q[ap]m|daily|day)') and rlike(QUANTITYPERFILL,'(?i)two') then 2
         |when rlike(localdosefreq,'(?i)(once|qd|q[ap]m|daily|day)') then safe_to_number(QUANTITYPERFILL)
         |else null end as localduration
         |from
         |(
         |select
         |groupid,datasrc,client_ds_id,issuedate,ordervsprescription,patientid,rxid,altmedcode,encounterid,localdaw,localdescription
         |,orderstatus,rxnorm_code,signature,venue,ordertype,discontinuedate,discontinuereason,fillnum,localgenericdesc,localmedcode,localndc
         |,max(case when lower(description) like '%dispense quantity unit%' then text_answer
         | when LOCALDESCRIPTION is not null then trim(regexp_extract(lower(LOCALDESCRIPTION),' ((caps|tab|powd|syr|aero|liq|susp|inhala)[a-z]+|solution|lotion|spray|topical|transdermal|rectal|cream|oint|film|suppository|extended|delayed|release|[, ])+'))
         | else null end) over (partition by rxid) as localform
         |,max(case when lower(description) like '%route of administration%' then text_answer
         | when LOCALDESCRIPTION is not null then regexp_extract(lower(LOCALDESCRIPTION),'(oral|topical|otic|rectal|nasal|vaginal|(inhalat|intra|subcut|transd|ophth)[a-z]+)')
         | else null end) over (partition by rxid) as  localroute
         |,max(case when lower(description) like '%strength dose unit%' then text_answer
         | when LOCALDESCRIPTION is not null then regexp_replace(regexp_extract(lower(LOCALDESCRIPTION), '[0-9,./]+ ?(mc?g|ml|meq|units?|g|each|dose|%)([/0-9](ml|mc?g))?'), '[0-9,. ]', '')
         | else null end) over (partition by rxid) as  localstrengthunit
         |,max(case when lower(description) in ('duration','dispense quantity') then text_answer
         | when SIGNATURE is not null then
         | regexp_extract(regexp_extract(lower(SIGNATURE),'([0-9]|one|two|three| (&|and) |.?half)+ ?(cap|tab|powd|syr|aero|liq|susp|spray|drop|app|unit|puff|ea|tsp).?([a-z)]+)?',0),'([0-9]|one|two|three| (&|and) |.?half)+',0)
         | else null end) over (partition by rxid) as localqtyofdoseunit
         |,max(case when lower(description) in ('duration unit','dispense quantity unit') then text_answer
         | when SIGNATURE is not null then
         | regexp_replace(regexp_extract(lower(SIGNATURE),'([0-9]|one|two|three| (&|and) |.?half)+ ?(cap|tab|powd|syr|aero|liq|susp|spray|drop|app|unit|puff|ea|tsp).?([a-z)]+)?',0),'([0-9]|one|two|three|&|and|.?half| )+','')
         | else null end) over (partition by rxid) as localdoseunit
         |,max(case when lower(description) = 'frequency' then text_answer
         | when SIGNATURE is not null then
         | trim(regexp_extract(lower(SIGNATURE),'(q[pa]m|q[^a-z]+h(ou)?r|qd|bid|tid|qid|((onc?e|twice|two|three|four|five|[1-8])?([1-9] ?x|times?| )+)?(daily|weekly|(every( other)?|per|at?) (day|night|week|month|evening|morning|bedtime|([1-9]|to| )+ ?h(ou)?rs)))',0))
         | else null end) over (partition by rxid) as localdosefreq
         |,regexp_extract(regexp_extract(lower(SIGNATURE),'([0-9]+|one|two|three) ?(cap|tab|powd|syr|aero|liq|susp|spray|drop|app|unit|puff|ea).?([a-z)]+)?'),'([0-9]+|one|two|three)') as quantityperfill
         |,max(case when detail_question in ({list_STRG_DOSE}) then text_answer
         | when LOCALDESCRIPTION is not null then regexp_extract(regexp_extract(lower(LOCALDESCRIPTION), '[0-9,./]+ ?(mc?g|ml|meq|units?|g|each|dose|%)([/0-9](ml|mc?g))?',0),'^[0-9,./]+',0)
         | else null end) over (partition by rxid) as localstrengthperdoseunit
         |from (
         |select
         |	'{groupid}' 									as groupid
         |	,'medications' 									as datasrc
         |	,{client_ds_id} 									as client_ds_id
         |	,m.original_ordered_date_time 							as issuedate
         |	,max(case when m.placed_order_as in ('1','5') then 'P' when m.placed_order_as = '0' then 'O' end) over (partition by m.unique_medication_identifier ) 			as ordervsprescription
         |	,m.unique_person_identifier 							as patientid
         |	,m.unique_medication_identifier 						as rxid
         |	,max(rm.ndc) over (partition by m.unique_medication_identifier)			as altmedcode
         |	,m.unique_visit_identifier 							as encounterid
         |	,max(case when md.detail_question in ({list_DAW}) then concat_ws('', '{client_ds_id}', '.', md.coded_answer) end) over (partition by m.unique_medication_identifier)		as localdaw
         |	,max(m.ordered_as) over (partition by m.unique_medication_identifier)  												as localdescription
         |    ,max(case when md.detail_question in ({list_DURATION}) then md.text_answer end) over (partition by m.unique_medication_identifier)     				as duration
         |    ,max(case when md.detail_question in ({list_DURATION_UNIT}) then md.text_answer end) over (partition by m.unique_medication_identifier) 				as duration_unit
         |	,max(rfr.display) over (partition by m.unique_medication_identifier)  												as localgenericdesc
         |	,case when ct.desc_ct is null then m.unique_synonym_identifier else nullif(substr(m.ordered_as,1,100), '') end  as localmedcode
         |	,max(rm.ndc) over (partition by m.unique_synonym_identifier)													as localndc
         |	,case when m.status is not null then concat_ws('', '{client_ds_id}', '.', m.status) end											as orderstatus
         |	,max(rm.rxnorm) over (partition by m.unique_synonym_identifier)  												as rxnorm_code
         |	,max(case when lower(rfr.description) in ('signature','special instructions') then md.text_answer
         |   else null end) over (partition by m.unique_medication_identifier)	as signature
         |	,'1' 																				as venue
         |	,'CH002047' 																			as ordertype
         |	,max(m.discontinue_date_time) over (partition by m.unique_medication_identifier)  										as discontinuedate
         |	,max(m.discontinue_type) over (partition by m.unique_medication_identifier) 											as discontinuereason
         |	,max(case when md.detail_question in ({list_REFILL}) then md.text_answer end) over (partition by m.unique_medication_identifier)   				as fillnum
         |  ,rfr.description as description
         |  ,md.text_answer as text_answer
         |  ,md.detail_question as detail_question
         |	,row_number() over (partition by m.unique_medication_identifier order by m.update_date_time desc nulls first)								as medrw
         |from MEDICATIONS m
         |left outer join MEDICATIONDETAILS md
         |on m.unique_medication_identifier = md.unique_medication_identifier
         |left outer join (select element_code, display,description from (
         |              select element_code, display,description
         |              ,row_number() over (partition by file_name, field, element_code order by fileid desc nulls first) as rw
         |              from REFERENCECODE
         |
         |             )
         |              where rw=1
         |              ) rfr
         |on 	 md.detail_question = rfr.element_code
         |left outer join ( select
         |		r.unique_synonym_identifier as unique_synonym_identifier
         |		,max(r.rxnorm) as rxnorm
         |		,max(nullif(replace(r.ndc, '-', ''), '') )as ndc
         |	    from REFERENCEMEDICATION r
         |	    group by r.unique_synonym_identifier) rm
         |on m.unique_synonym_identifier = rm.unique_synonym_identifier
         |left outer join
         |        (
         |        select unique_synonym_identifier, COUNT(distinct ordered_as) as desc_ct
         |        from MEDICATIONS group by unique_synonym_identifier
         |        having COUNT(distinct ordered_as)>20
         |        ) ct
         |on      ( m.unique_synonym_identifier = ct.unique_synonym_identifier )
         |where m.status not in ({list_MED_STATUS})
         |and nvl(m.placed_order_as, '2') <>'2'
         |and m.original_ordered_date_time 	is not null
         |and m.placed_order_as	 		is not null
         |and m.unique_person_identifier 		is not null
         |
         |)
         |where medrw=1
         |)
         |

       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_DAW}",list_DAW)
        .replace("{list_DISCON_REAON}",list_DISCON_REASON)
        .replace("{list_QUANTITY_FILL}",list_QUANTITY_FILL)
        .replace("{list_REFILL}",list_REFILL)
        .replace("{list_SIGNATURE}",list_SIGNATURE)
        .replace("{list_STRG_UNIT}",list_STRG_UNIT)
        .replace("{list_DOSE_UNIT}",list_DOSE_UNIT)
        .replace("{list_DURATION}",list_DURATION)
        .replace("{list_DURATION_UNIT}",list_DURATION_UNIT)
        .replace("{list_FREQUENCY}",list_FREQUENCY)
        .replace("{list_QTY_DOSE_UNIT}",list_QTY_DOSE_UNIT)
        .replace("{list_ROUTE}",list_ROUTE)
        .replace("{list_STRG_DOSE}",list_STRG_DOSE)
        .replace("{list_STRG_DOSE_UNIT}",list_STRG_DOSE_UNIT)
        .replace("{list_MED_STATUS}",list_MED_STATUS)
        .replace("{list_HUM_TYPE}",list_HUM_TYPE)
        .replace("{list_HUM_ACTION}",list_HUM_ACTION)
        .replace("{list_RX_HUM_TYPE}",list_RX_HUM_TYPE)
        .replace("{list_ORD_STATUS}",list_ORD_STATUS)



    )
  }




  override def dependsOn: Set[String] = Set("REFERENCECODE","REFERENCEMEDICATION","MEDICATIONDETAILS","MEDICATIONS","MAP_PREDICATE_VALUES")
}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_BILLINGDATA_CUSTOM extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_BILLINGDATA_CUSTOM"

  override def dependsOn: Set[String] = Set("BILLINGDATA", "MAP_CUSTOM_PROC", CDRFEParquetNames.clinicalencounter, "ZH_ITEMS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |With Dedup_Billing AS (
        |	SELECT  B.*
        |		,Row_Number() Over (Partition By B.Id ORDER BY B.Modifieddate Desc nulls first) AS Dedup_bill_Row
        |	FROM BILLINGDATA B
        |	WHERE B.Deleteflag <> '1'
        |)
        |
        |SELECT  Groupid
        |       ,Datasrc
        |       ,Client_Ds_Id
        |       ,Localcode
        |       ,Encounterid
        |       ,Patientid
        |       ,Proceduredate
        |       ,Proceduredate AS actualprocdate
        |       ,Hosp_Px_Flag
        |       ,Localname
        |       ,Procseq
        |       ,Mappedcode
        |       ,Codetype
        |FROM
        |(
        |	SELECT  '{groupid}'                                                AS groupid
        |	       ,{client_ds_id}                                             AS client_ds_id
        |	       ,'billingdata_custom'                                       AS datasrc
        |	       ,concat_ws('','{client_ds_id_prefix}',dedup_billing.itemid) AS localcode
        |	       ,Enc.Patientid                                              AS Patientid
        |	       ,enc.arrivaltime                                            AS proceduredate
        |	       ,dedup_billing.encounterid                                  AS encounterid
        |	       ,'N'                                                        AS hosp_px_flag
        |	       ,zh_items.itemname                                          AS localname
        |	       ,dedup_billing.displayindex                                 AS procseq
        |	       ,map.mappedvalue                                            AS mappedcode
        |	       ,'CUSTOM'                                                   AS codetype
        |	FROM DEDUP_BILLING
        |	INNER JOIN MAP_CUSTOM_PROC map
        |		ON (map.localcode = concat_ws('', '{client_ds_id_prefix}', dedup_billing.itemid) AND map.datasrc='billingdata_custom' AND map.groupid = '{groupid}')
        |	INNER JOIN {CLINICALENCOUNTER} enc
        |		ON (dedup_billing.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
        |	LEFT OUTER JOIN ZH_ITEMS
        |		ON (Dedup_Billing.Itemid = Zh_Items.Itemid)
        |	WHERE dedup_billing.Dedup_bill_Row=1
        |)
        |WHERE proceduredate IS NOT NULL
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }
}

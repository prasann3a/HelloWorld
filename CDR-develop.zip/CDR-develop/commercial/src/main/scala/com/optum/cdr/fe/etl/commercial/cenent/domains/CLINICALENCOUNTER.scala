package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.clinicalencounter
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object CLINICALENCOUNTER extends FEQueryAndMetadata[clinicalencounter] {

  override def name: String = CDRFEParquetNames.clinicalencounter

  override def dependsOn: Set[String] = Set("ENCNTR", "DISCH")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, arrivaltime, encounterid, patientid, facilityid, localpatienttype, admittime, alt_encounterid, dischargetime, localadmitsource, localdischargedisposition, inpatientlocation, localencountertype
      |from
      |(
      |SELECT '{groupid}' as groupid
      |	,'encntr' as datasrc
      |	,{client_ds_id} as client_ds_id
      |	,encntr.Begin_Dttm AS arrivaltime
      |	,encntr.num  AS encounterid
      |	,encntr.Pat_Person_Num  AS patientid
      |	,Encntr.Begin_Dttm  AS admittime
      |	,Encntr.Prim_Acct_Num  AS alt_encounterid
      |	,Encntr.End_Dttm  AS dischargetime
      |	,Encntr.Fac_Num  AS facilityid
      |	,Disch.Adm_Source  AS localadmitsource
      |	,coalesce( disch.disposition ,encntr.Encntr_Dispo_Reason_Cde)  AS localdischargedisposition
      |	,Encntr.Encntr_Type_Cde  AS localpatienttype
      |	,disch.adm_ns AS inpatientlocation
      |	,encntr.encntr_type_cde AS localencountertype
      |	,ROW_NUMBER() OVER (PARTITION BY encntr.num ORDER BY encntr.data_ts DESC NULLS LAST) rn
      |FROM ENCNTR
      |     LEFT OUTER JOIN DISCH ON (encntr.prim_acct_num = disch.acct_num AND encntr.encntr_type_cde = 'I')
      |WHERE encntr.encntr_cat_cde ='ACTV'
      |
      |)
      |where rn = 1 AND arrivaltime IS NOT NULL
    """.stripMargin
}
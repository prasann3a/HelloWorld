package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENT extends FETableInfo [patient]{

  override def name:String=CDRFEParquetNames.patient

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select groupid, datasrc, patientid, dob as dateofbirth, dod as dateofdeath, medicalrecordnumber, inactive_flag, client_ds_id
         |from
         |(
         | TEMP_PATIENT_CACHE
         |)
         |where rownumber=1
       """.stripMargin)


  }

  override def dependsOn: Set[String] = Set("TEMP_PATIENT_CACHE")
}
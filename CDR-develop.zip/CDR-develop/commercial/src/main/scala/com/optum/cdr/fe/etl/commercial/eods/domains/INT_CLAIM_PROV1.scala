package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_prov
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_PROV1 extends FETableInfo[int_claim_prov] {

  override def name: String = CDRFEParquetNames.int_claim_prov

  override def dependsOn: Set[String] = Set("PROVIDER")

  override def tableOrder: Int = 1

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId

    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val (prov_h969333_npi_incl1, prov_npi1) = groupId match {
      case "H969333" => ("""left join ref_cmsnpi Cms on (Cms.NPI =a.Prov_NPI and  Cms.entity_type_code = '1')""","""Cms.NPI""")
      case _ => ("""---""", """a.Prov_NPI""")
    }

    sparkSession.sql(
      """
        |
        |select groupid, client_ds_id, datasrc, dea_number, prov_addr_1, prov_addr_2, prov_city, prov_credentials, prov_email, prov_fname, prov_id, prov_lname, prov_mi,
        | case when upper(prov_npi) in('9999999999', 'PENDING','0000000000', 'NA') then null else prov_npi end as prov_npi
        | , prov_name, prov_phone, provider_region, prov_sec_spclty_cd, prov_spclty_cd, prov_state_code, pcp_flag, prov_zip_code, source_code, update_dt
        |from
        |(
        |select
        |       distinct '{groupid}' 		as 	groupid,
        |       {client_ds_id} 		as 	client_ds_id,
        |	   'provider' 				as 	datasrc,
        |	   Dea_Nbr                  as  dea_number,
        |	   Pcp_Flg					as 	pcp_flag,
        |	   case when  upper(prov_adr_1) in('OUT OF COUNTRY','NA')  then null else prov_adr_1 end 	as 	prov_addr_1,
        |	   case when  upper(prov_adr_2) in('OUT OF COUNTRY','NA')  then null else prov_adr_2 end 	as 	prov_addr_2,
        |	   case when upper(Prov_Cty)='NA' then null else prov_cty end 		as 	prov_city,
        |       case when upper(prov_prfx) in ('PROF.','DR.') then prov_prfx end as 	prov_credentials,
        |	   Prov_Email_Adr 			as 	prov_email,
        |	   nullif(trim(nullif(replace(Prov_Fst_Nm,'*',''), '')), '')	as 	prov_fname,
        |	   prov_id,
        |	   Prov_Lst_Nm 				as 	prov_lname,
        |	   Prov_Midl_Nm 			as 	prov_mi,
        |	   {prov_npi1}                 as prov_npi,
        |	   Prov_Nm 					as 	prov_name,
        |	   replace(replace(Prov_Tel,' '),'-') 		as 	prov_phone,
        |	   Prov_Rgn 								as 	provider_region,
        |           case when '{groupid}' in ( 'H969719' ,'H969222') then NVL2(Std_Prov_Spcl_2,concat_ws('', 'eods', '.', Std_Prov_Spcl_2),null) else Std_Prov_Spcl_2 end as prov_sec_spclty_cd,
        |           case when '{groupid}' in ( 'H969719' ,'H969222') then NVL2( Std_Prov_Spcl_1 ,concat_ws('', 'eods', '.', Std_Prov_Spcl_1), null) else Std_Prov_Spcl_1 end as prov_spclty_cd,
        |           case when prov_st='NA' then null else prov_st end	as 	prov_state_code,
        |	   case when prov_zip_cd='99999' then null else prov_zip_cd end as prov_zip_code,
        |	   Enty_Nm 					as 	source_code,
        |	   Prov_Eff_Strt_Dt 		as 	update_dt
        |  from
        |(
        |select * from
        |(
        |select unpivot_base.*,
        |stack(2,Src_Prov_Id,'SRC_PROV_ID',Uniq_Prov_Id,'UNIQ_PROV_ID') as (Prov_Id, source)
        |from
        |PROVIDER unpivot_base
        |)
        |where Prov_Id is not null
        |) a
        | {prov_h969333_npi_incl1}
        |
        |
        |)
        |
        |
    """.stripMargin
        .replace("{groupid}", groupId.toString)
        .replace("{client_ds_id}", clientDsId.toString)
        .replace("{prov_h969333_npi_incl1}", prov_h969333_npi_incl1)
        .replace("{prov_npi1}", prov_npi1)
    )
  }
}

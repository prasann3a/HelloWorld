package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.encounterreason
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object ENCOUNTERREASON extends FEQueryAndMetadata[encounterreason] {

  override def name: String = CDRFEParquetNames.encounterreason

  override def dependsOn: Set[String] = Set("ENCNTR")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localreasontext, encounterid, patientid, reasontime
      |from
      |(
      |SELECT distinct '{groupid}' as groupid,
      |   'assoct' as datasrc
      |   ,{client_ds_id} as client_ds_id
      |   ,reason_txt AS localreasontext
      |   ,Num  AS encounterid
      |   ,Pat_Person_Num  AS patientid
      |   ,Begin_Dttm  AS reasontime
      |FROM ENCNTR
      |
      |)
      |where encounterid IS NOT NULL AND patientid IS NOT NULL AND localreasontext IS NOT NULL
    """.stripMargin
}
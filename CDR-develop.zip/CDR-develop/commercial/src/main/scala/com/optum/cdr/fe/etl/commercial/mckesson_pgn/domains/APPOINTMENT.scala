package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.{appointment, map_predicate_values}
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object APPOINTMENT extends FETableInfo[appointment]{

override def name: String = CDRFEParquetNames.appointment

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TRS601_EVENT_SCHEDULES", "MCKESSON_PGN_V1_ZH_TRS200_RESOURCE", "MCKESSON_PGN_V1_TRS603_EVENT_RESOURCE_SCHED", "MCKESSON_PGN_V1_TRS600_MASTER_SCHEDULES", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val excl_sta_id = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "APPOINTMENT_EXC","APPOINTMENT","EVENT_SCHEDULES","SCH_STA_INT_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
       |WITH uni_esch AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  v.*
       |	       ,ROW_NUMBER() OVER (PARTITION BY evt_sch_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_TRS601_EVENT_SCHEDULES v
       |	WHERE Sch_Srt_Ts IS NOT NULL
       |	AND mst_sch_int_id IS NOT NULL
       |	AND Evt_Sch_Int_Id IS NOT NULL
       |	AND sch_sta_int_id NOT IN ({excl_sta_id})
       |)
       |WHERE rn = 1
       |AND row_sta_cd <> 'D' ),
       |
       |uni_resc AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  r.*
       |	       ,ROW_NUMBER() OVER (PARTITION BY rsc_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_ZH_TRS200_RESOURCE r
       |	WHERE rsc_Int_Id IS NOT NULL
       |)
       |WHERE rn = 1
       |AND row_sta_cd <> 'D' ),
       |
       |uni_eres_sch AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  s.*
       |	       ,ROW_NUMBER() OVER (PARTITION BY evt_rsc_sch_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_TRS603_EVENT_RESOURCE_SCHED s
       |	WHERE Evt_Sch_Int_Id IS NOT NULL
       |)
       |WHERE rn = 1
       |AND row_sta_cd <> 'D' )
       |
       |SELECT  '{groupid}'        AS groupid
       |       ,'master_schedules' AS datasrc
       |       ,'{client_ds_id}'   AS client_ds_id
       |       ,appointmentdate
       |       ,appointmentid
       |       ,locationid
       |       ,patientid
       |       ,local_appt_type
       |       ,providerid
       |       ,appointment_reason
       |FROM
       |(
       |	SELECT  uni_esch.Sch_Srt_Ts                                                                               AS appointmentdate
       |	       ,uni_esch.Evt_Sch_Int_Id                                                                           AS appointmentid
       |         ,FIRST_VALUE(uni_eres_sch.rsc_int_id) OVER (PARTITION BY uni_esch.Evt_Sch_Int_ID ORDER BY CASE WHEN uni_resc.Psn_Int_ID IS NULL THEN 0 ELSE 1 END,uni_eres_sch.Lst_Mod_Ts DESC nulls first,uni_eres_sch.Rsc_Evt_Srt_TS,uni_eres_sch.Rsc_Int_ID nulls last) AS locationid
       |	       ,FIRST_VALUE(uni_resc.psn_int_id) OVER (PARTITION BY uni_eres_sch.Evt_Sch_Int_ID ORDER BY CASE WHEN uni_resc.Psn_Int_ID IS NOT NULL THEN 0 ELSE 1 END,uni_eres_sch.Lst_Mod_Ts DESC nulls first,uni_eres_sch.Rsc_Evt_Srt_TS,uni_eres_sch.Rsc_Int_ID nulls last) AS providerid
       |	       ,msch.Psn_Int_Id                                                                                   AS patientid
       |	       ,NULL                                                                                              AS local_appt_type
       |	       ,msch.Rsn_For_Exam                                                                                 AS appointment_reason
       |	       ,ROW_NUMBER() OVER (PARTITION BY uni_esch.Evt_Sch_Int_Id ORDER BY msch.Lst_Mod_Ts DESC NULLS LAST) AS rn
       |	FROM MCKESSON_PGN_V1_TRS600_MASTER_SCHEDULES msch
       |	JOIN UNI_ESCH
       |	ON (msch.mst_sch_int_id = uni_esch.mst_sch_int_id)
       |	JOIN UNI_ERES_SCH
       |	ON (uni_esch.evt_sch_int_id = uni_eres_sch.evt_sch_int_id)
       |	JOIN UNI_RESC
       |	ON (uni_eres_sch.rsc_int_id = uni_resc.rsc_int_id)
       |	WHERE msch.Psn_Int_Id IS NOT NULL
       |)
       |WHERE locationid IS NOT NULL
       |AND rn = 1
       """
        .stripMargin
        .replace("{excl_sta_id}", excl_sta_id)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }
}

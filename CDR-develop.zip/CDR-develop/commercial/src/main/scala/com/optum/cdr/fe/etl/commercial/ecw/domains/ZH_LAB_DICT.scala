package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{zh_lab_dict, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ZH_LAB_DICT extends FETableInfo[zh_lab_dict] {

  override def name: String = CDRFEParquetNames.zh_lab_dict

  override def dependsOn: Set[String] = Set("ZH_ITEMS", "ZH_LABDATADETAILREFRANGE", "ZH_VITALTYPES", "HL7LABDATADETAIL", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    loadedDependencies("ZH_ITEMS").as[zh_items].createOrReplaceTempView("ZH_ITEMS")
    loadedDependencies("ZH_LABDATADETAILREFRANGE").as[zh_labdatadetailrefrange].createOrReplaceTempView("ZH_LABDATADETAILREFRANGE")
    loadedDependencies("ZH_VITALTYPES").as[zh_vitaltypes].createOrReplaceTempView("ZH_VITALTYPES")
    loadedDependencies("HL7LABDATADETAIL").as[hl7labdatadetail].createOrReplaceTempView("HL7LABDATADETAIL")

    val predicate_values = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val lab_valueDf = mpvList(predicate_values, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LABDATADETAIL", "LAB_RESULTS", "ZH_ITEMS"
      , "ITEMID").mkString(",")

    sparkSession.sql(
      """
      select groupid, client_ds_id, localcode, localdesc, localname, localrefrange
 |from
 |(
 |SELECT  '{groupid}' as groupid
 |,{client_ds_id} as client_ds_id
 |,zh_items.Itemid  AS localcode
 |,zh_items.Itemdesc  AS localdesc
 |,zh_items.Itemname  AS localname
 |,zh1.range AS localrefrange
 |FROM ZH_ITEMS zh_items
 |LEFT OUTER JOIN
 |(SELECT * from
 |	(SELECT zh.*, row_number() over (partition by zh.itemid order by updatedtime desc nulls first) as rownumber from ZH_LABDATADETAILREFRANGE zh
 |          )
 |WHERE rownumber =1
 |) zh1
 |ON (zh1.itemid = zh_items.Itemid)
 |WHERE (zh_items.XMLPATH like '/Lab%' OR zh_items.XMLPATH like '/Vitals%'
 |   OR (zh_items.ItemID in ({lab_valueDf}))
 |  )
 |)
 |
 |union all
 |
 |select groupid, client_ds_id, localcode, localname as localdesc, localname, null as localrefrange
 |from
 |(
 |SELECT '{groupid}' as groupid
 |,{client_ds_id} as client_ds_id
 |,zh_vitaltypes.itemid as localcode
 |,CASE WHEN ({client_ds_id} = 2063 and zh_vitaltypes.itemid = '194603') THEN 'SpO2'
 |      ELSE COALESCE(zh_vitaltypes.hum_type,Zh_Items.Itemname) END as localname
 |FROM ZH_VITALTYPES
 |      LEFT OUTER JOIN ZH_ITEMS ON Zh_Vitaltypes.Itemid = Zh_Items.Itemid
 |
 |)
 |
 |union all
 |
 |select groupid, client_ds_id, localcode, localrefrange, localname, localunits
 |from
 |(
 |select
 |       distinct '{groupid}' 	as groupid
 |       ,'hl7labdatadetail' 	as datasrc
 |       ,{client_ds_id} 		as client_ds_id
 |	   ,concat_ws('', '{client_ds_id}', '.HL7.', hl7.Hl7id)	as localcode
 |	   ,null		 		as localrefrange
 |	   ,null	 			as localname
 |	   ,null	 			as localunits
 |  from HL7LABDATADETAIL hl7
 | where hl7.Hl7id is not null
 |
 |)
    """.stripMargin
        .replace("{lab_valueDf}", lab_valueDf)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }
}

package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.zh_lab_dict
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ZH_LAB_DICT extends FETableInfo[zh_lab_dict]{

  override def name:String=CDRFEParquetNames.zh_lab_dict

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select groupid, localcode, localname, localname as localdesc, localrefrange, localunits, localbodysite, client_ds_id
         |from LABCACHE
       """.stripMargin)
  }

  override def dependsOn: Set[String] = Set("LABCACHE")
}

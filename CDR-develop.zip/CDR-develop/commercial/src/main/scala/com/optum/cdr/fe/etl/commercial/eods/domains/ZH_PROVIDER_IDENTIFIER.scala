package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.oap.cdr.models.zh_provider_identifier
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_PROVIDER_IDENTIFIER extends FEQueryAndMetadata[zh_provider_identifier] {

  override def name: String = CDRFEParquetNames.zh_provider_identifier

  override def dependsOn: Set[String] = Set("PROVIDER")

  override def sparkSql: String =
    """
      |
      |select groupid, client_ds_id, id_type, id_value, provider_id
      |from
      |(
      |select distinct
      |       '{groupid}'			as groupid
      |       ,{client_ds_id}   as client_ds_id
      |       ,'NPI'           as id_type
      |	   ,p.Uniq_Prov_Id  as provider_id
      |       ,p.Prov_Npi      as id_value
      |  from PROVIDER p
      | where p.Uniq_Prov_Id is not null and p.Prov_Npi is not null
      |
      |)
      |
    """.stripMargin

}

package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object CLAIM extends FEQueryAndMetadata[claim]{

  override def name: String = CDRFEParquetNames.claim

  override def dependsOn: Set[String] = Set("EVENTS_VW", "PATIENT_FAC_GRP_SEG_TB", "ITEM_DETAILS_VW", "ZH_NATIONAL_CODES_TB")

  override def sparkSql: String =

  """
    |With Event as
    |(
    |select
    |             patient_id, Reception_Check_In_Date_Time, Provider_Id, event_id, last_modified_date
    |from (select patient_id, Reception_Check_In_Date_Time, Provider_Id, event_id, last_modified_date
    |      ,row_number() over (partition by event_id, patient_id order by last_modified_date desc nulls first) as rnbr
    |      from EVENTS_VW ev
    |      where event_id is not null and patient_id is not null and Reception_Check_In_Date_Time is not null
    |        )
    |Where rnbr=1
    |)
    |,
    |Patient_Fac as
    |(
    |Select  distinct PATIENT_ID from PATIENT_FAC_GRP_SEG_TB
    |)
    |
    |select groupid, datasrc, client_ds_id, claimid, patientid, servicedate, localbillingproviderid, localcpt, claimProviderId, mappedcpt, encounterid
    |from
    |(
    |select  '{groupid}' as groupid, 'item_details_vw' as datasrc
    |      ,{client_ds_id} as client_ds_id
    |      ,idv.itmdtl_Id as claimid
    |      ,ev.patient_id as patientid
    |      ,ev.Reception_Check_In_Date_Time as servicedate
    |      ,ev.Provider_Id as localbillingproviderid
    |      ,idv.Natcode_Id as localcpt
    |      ,ev.Provider_Id as claimProviderId
    |      ,nc.National_Code as mappedcpt
    |      ,ev.event_id as encounterid
    |      ,row_number() over (partition by idv.Event_ID,idv.itmdtl_Id order by idv.Last_Modified_Date desc nulls first, idv.FileID desc nulls first) as rnbr
    |from ITEM_DETAILS_VW idv
    |inner join EVENT ev on (ev.event_id = idv.event_id)
    |inner join PATIENT_FAC pfg on (pfg.patient_id = ev.patient_id)
    |inner join ZH_NATIONAL_CODES_TB nc
    |        on (idv.natcode_id = nc.natcode_id and (nc.national_code_type = 'CPT 4'))
    |where idv.itmdtl_Id is not null
    |
    |)
    |where rnbr = 1
  """
  .stripMargin

}

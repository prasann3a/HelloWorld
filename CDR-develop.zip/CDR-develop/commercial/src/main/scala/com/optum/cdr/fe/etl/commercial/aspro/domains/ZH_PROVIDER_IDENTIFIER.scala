package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.zh_provider_identifier
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_PROVIDER_IDENTIFIER extends FEQueryAndMetadata[zh_provider_identifier]{

override def name: String = CDRFEParquetNames.zh_provider_identifier

override def dependsOn: Set[String] = Set("ZH_PROVIDERS")

override def sparkSql: String =
  """
    |SELECT GROUPID
    |      ,CLIENT_DS_ID
    |      ,PROVIDER_ID
    |      ,ID_TYPE
    |      ,ID_VALUE
    |FROM
    |(
    |	SELECT distinct '{groupid}' as GROUPID
    |	       ,'{client_ds_id}'    as CLIENT_DS_ID
    |	       , Imreprov_code      as PROVIDER_ID
    |	       ,'DEA'               as ID_TYPE
    |	       , prov_deaid         as ID_VALUE
    |	FROM ZH_PROVIDERS p
    |	WHERE prov_deaid is not null
    |
    | union
    |
    |	SELECT distinct '{groupid}' as GROUPID
    |	       ,'{client_ds_id}'    as CLIENT_DS_ID
    |	       , Imreprov_code      as PROVIDER_ID
    |	       ,'UPIN'              as ID_TYPE
    |	       , prov_upin as ID_VALUE
    |	FROM ZH_PROVIDERS p
    |	WHERE prov_upin is not null
    |)
  """.stripMargin
}

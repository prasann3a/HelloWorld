package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.CDRFEParquetNames

object PROVIDER extends FEQueryAndMetadata[zh_provider]{
  override def name: String = CDRFEParquetNames.zh_provider

  override def dependsOn: Set[String] = Set("ZH_ENT_CONFIG_STAFF")

  override def sparkSql: String =
    """
      |select datasrc, localproviderid, credentials, dob, first_name, last_name, middle_name, providername, gender, npi
      |from
      |(
      |SELECT 'zh_ent_config_staff' 	AS datasrc
      |,staff_seq		AS localproviderid
      |,CASE WHEN staff_type = 'UNK' THEN NULL ELSE staff_type END AS credentials
      |,NULL			AS dob
      |,staff_first_name	AS first_name
      |,NULL         		AS providername
      |,NULL			AS gender
      |,staff_last_name	AS last_name
      |,staff_middle_name	AS middle_name
      |,NULL			AS npi
      |,NULL			AS suffix
      |,ROW_NUMBER() OVER (PARTITION BY staff_seq ORDER BY modified_dt DESC NULLS LAST) rn
      |FROM ZH_ENT_CONFIG_STAFF
      |WHERE staff_seq IS NOT NULL
      |
      |)
      |where rn = 1
    """.stripMargin
}

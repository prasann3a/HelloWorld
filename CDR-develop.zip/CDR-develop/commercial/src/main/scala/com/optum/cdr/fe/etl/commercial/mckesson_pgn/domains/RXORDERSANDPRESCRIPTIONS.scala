package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.rxorder

object RXORDERSANDPRESCRIPTIONS extends FEQueryAndMetadata[rxorder]{
  override def name: String = CDRFEParquetNames.rxorder

  override def dependsOn: Set[String] = Set("RXORDERSANDPRESCRIPTIONS_TEMP_TPM300_PAT_VISIT","RXORDERSANDPRESCRIPTIONS_TEMP_TPW102_ORD_DTL")

  override def sparkSql: String =
    """
      |SELECT * FROM RXORDERSANDPRESCRIPTIONS_TEMP_TPM300_PAT_VISIT
      |UNION ALL
      |SELECT * FROM RXORDERSANDPRESCRIPTIONS_TEMP_TPW102_ORD_DTL
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.huamana.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.int_claim_medical
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_MEDICAL extends FETableInfo[int_claim_medical]{

  override def name:String=CDRFEParquetNames.int_claim_medical

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def dependsOn: Set[String] = Set("RECLMEXP","RECLMDSP","RECLM627","REPRX","ZO_BPO_MAP_EMPLOYER","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    val groupIdConstant="{groupid}"
    val clientDsIdConstant="{client_ds_id}"

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }
   val ismdsp = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "OLD_TABLE", "INT_CLAIM_MEDICAL", "INT_CLAIM_MEDICAL", "INT_CLAIM_MEDICAL").mkString(",")
  //  val ismdsp="'Y'"
    if (ismdsp.equals("'Y'")) { //INTCLAIMMEDICAL_MDSP_QUERY
      val df1mdsp = sparkSession.sql(
        """
          |with ll as
          |(
          | select fileid,max(transact_date) as transact_date
          | from RECLMDSP
          | group by fileid
          | ),
          |dtl as
          |(select
          |        p.*,
          |         case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then
          |            concat_ws('', mbr_pid, '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(serv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end, '_', case when srv_cd_typ = 'R' then lpad(Type,4,'0') else null end)
          |         else
          |            concat_ws('', mbr_pid, '00', '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(serv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end, '_', case when srv_cd_typ = 'R' then lpad(Type,4,'0') else null end)
          |        end as dtl_key,
          |        case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then mbr_pid else concat_ws('', mbr_pid, '00') end as memb_id
          | from RECLMDSP  p
          | inner join ll on  p.fileid=ll.fileid
          | where claim_type in ('H','P')
          | and not (claim_ind in ('%') and safe_to_number(fund_exp) = 0)
          |
          | )
          | select groupid,client_ds_id,datasrc, claim_header_id, contract_id, member_id, payer_code, payer_name, place_of_service, quantity_of_service, service_date, servicing_prov_id, source_code, admit_date, payment_amt, requested_amt, capitated_service_flag, claim_type, diag_rel_grp_code, diag_rel_grp_grouper, discharge_date, discharge_status_code, encounterid, icd_diag_cd1, icd_diag_cd2, icd_diag_cd3, icd_diag_cd4, icd_diag_cd5, icd_diag_cd6, icd_diag_cd7, icd_diag_cd8, icd_diag_cd9, icd_diag_cd10, icd_diag_cd11, icd_diag_cd12, icd_diag_cd13, icd_diag_cd14, icd_diag_cd15, icd_diag_cd16, icd_diag_cd17, icd_diag_cd18, icd_diag_cd19, icd_diag_cd20, icd_diag_cd21, icd_diag_cd22, icd_diag_cd23, ICD_DIAG_CD1_TYPE, ICD_DIAG_CD2_TYPE, ICD_DIAG_CD3_TYPE, ICD_DIAG_CD4_TYPE, ICD_DIAG_CD5_TYPE, ICD_DIAG_CD6_TYPE,
          |  member_gender_code, par_flag, pcp_id, pcp_name, pcp_npi, pay_process_date,
          |  case when regexp_instr(proc_cd_modifier_1,'[^a-zA-Z0-9 ]') > 0 then null else proc_cd_modifier_1 end as proc_cd_modifier_1,proc_cd_modifier_2,proc_code,PRINCIPLE_PROC_ICD_TYPE,referring_prov_id,revenue_code,service_from_date,service_to_date,servicing_prov_name,servicing_prov_npi,type_of_bill_code,claim_line_id,admit_source_code,admit_type_code,admit_prov_id,admit_prov_npi,allowed_amt,pat_liability_amt,attnd_prov_id,attnd_prov_npi,billing_prov_id,billing_prov_npi,denied_reason,ein,financial_class,icd_proc_cd_1,icd_proc_cd_2, icd_proc_cd_3, icd_proc_cd_4, icd_proc_cd_5,icd_proc_cd_6,
          |ICD_PROC_CD_1_TYPE,ICD_PROC_CD_2_TYPE,ICD_PROC_CD_3_TYPE,ICD_PROC_CD_4_TYPE,ICD_PROC_CD_5_TYPE,ICD_PROC_CD_6_TYPE,ICD_PROC_CD_7_TYPE,ICD_PROC_CD_8_TYPE,ICD_PROC_CD_9_TYPE,principle_proc_cd,coinsurance_amt,servicing_prov_spclty_cd
          |from
          |(
          |select
          |        '{groupid}'                                as groupid
          |	,{client_ds_id}                          as client_ds_id
          |	,'reclmdsp'                             as datasrc
          |	,bme.employeraccountid                  as contract_id
          |	,bme.employeraccountid                  as payer_code
          |	,bme.employeraccountid                  as payer_name
          |	,memb_id                                as member_id
          |	,dtl_key                                as claim_header_id
          |	,dtl_key                                as encounterid
          |        ,case when Claim_Type = 'H' then 'I' when Claim_Type = 'P' then 'P' else null end AS claim_type
          |	,bill_type                              as type_of_bill_code
          |        ,case when Cms_Pot in ('XX') then null else Cms_Pot end as place_of_service
          |	,coalesce(srv_frm_dt,srvc_in_dt)        as service_date
          |	,srv_frm_dt                             as service_from_date
          |	,serv_to_dt                             as service_to_date
          |	,proc_date                              as pay_process_date
          | ,coalesce(dtl.npi,dtl.serv_prov)        as servicing_prov_id
          |	,npi                                    as servicing_prov_npi
          |	,sprov_name                             as servicing_prov_name
          |	,sprov_spec                             as servicing_prov_spclty_cd
          |	,case when refer_prov in ('000000000','999999999','0') then null else refer_prov end as referring_prov_id
          |	,safe_to_date(Adm_Date,'yyyyMMdd')      as admit_date
          |        ,nvl2(adm_srce, concat_ws('', 'CMS.', adm_srce), null) as admit_source_code
          |	,safe_to_date(Dischrg_Dt,'yyyyMMdd')    as discharge_date
          |	,dischrg_st                             as discharge_status_code
          |	,case when Srv_Cd_Typ = 'R' then lpad(Type,4,'0') else null end as revenue_code
          |	,case when Srv_Cd_Typ in ('C','H') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end as proc_code
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as PRINCIPLE_PROC_ICD_TYPE
          |	,case when Srv_Cd_Typ in ('C','H') then Type_Mod when (Srv_Cd_Typ not in ('C','H') and Proc_Code1 is not null) then Cpt4_Mod else null end AS proc_cd_modifier_1
          |	,case when Drg_Nbr='000' then null else Drg_Nbr end AS diag_rel_grp_code
          |,case when safe_to_number(dtl.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(dtl.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(dtl.Serv_Units,'(\\+|\\-)',''), '')))
          |              when safe_to_number(dtl.fund_exp) =  0 and dtl.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('',dtl.claim_ind,nullif(regexp_replace(dtl.Serv_Units,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(dtl.Serv_Units)
          |              end as quantity_of_service
          |,case when safe_to_number(dtl.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(dtl.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(dtl.Coins_Amt,'(\\+|\\-)',''), '')))
          |              when safe_to_number(dtl.fund_exp) =  0 and dtl.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('', dtl.claim_ind,nullif(regexp_replace(dtl.Coins_Amt,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(dtl.Coins_Amt)
          |              end                               as coinsurance_amt
          |	,case when safe_to_number(dtl.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(dtl.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(dtl.chrg_amt,'(\\+|\\-)',''), '')))
          |              when safe_to_number(dtl.fund_exp) =  0 and dtl.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('',dtl.claim_ind,nullif(regexp_replace(dtl.chrg_amt,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(dtl.chrg_amt)
          |              end                               as requested_amt
          |,case when safe_to_number(dtl.fund_exp) <> 0 then safe_to_number(dtl.fund_exp)+safe_to_number(concat_ws('',nullif(regexp_extract(dtl.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(dtl.sub_rspamt,'(\\+|\\-)',''), '')))
          |              when safe_to_number(dtl.fund_exp) =  0 and dtl.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('', dtl.claim_ind,nullif(regexp_replace(dtl.sub_rspamt,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(dtl.sub_rspamt)
          |              end                               as allowed_amt
          |	,safe_to_number(dtl.fund_exp)          as payment_amt
          |	,proc_code1                            as principle_proc_cd
          |    	,proc_code1                            as icd_proc_cd_1
          |    	,proc_code2                            as icd_proc_cd_2
          |    	,proc_code3                            as icd_proc_cd_3
          |    	,proc_code4                            as icd_proc_cd_4
          |    	,proc_code5                            as icd_proc_cd_5
          |        ,proc_code6                            as icd_proc_cd_6
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_1_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_2_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_3_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_4_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_5_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_6_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_7_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_8_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_9_TYPE
          |        ,diag_code1                            as icd_diag_cd1
          |  	,diag_code2                            as icd_diag_cd2
          |  	,diag_code3                            as icd_diag_cd3
          |  	,diag_code4                            as icd_diag_cd4
          |  	,diag_code5                            as icd_diag_cd5
          |  	,diag_code6                            as icd_diag_cd6
          |  	,diag_code7                            as icd_diag_cd7
          |  	,diag_code8                            as icd_diag_cd8
          |  	,diag_code9                            as icd_diag_cd9
          |  	,null                                  as icd_diag_cd10
          |  	,null                                  as icd_diag_cd11
          |  	,null                                  as icd_diag_cd12
          |  	,null                                  as icd_diag_cd13
          |  	,null                                  as icd_diag_cd14
          |  	,null                                  as icd_diag_cd15
          |  	,null                                  as icd_diag_cd16
          |  	,null                                  as icd_diag_cd17
          |  	,null                                  as icd_diag_cd18
          |  	,null                                  as icd_diag_cd19
          |  	,null                                  as icd_diag_cd20
          |  	,null                                  as icd_diag_cd21
          |  	,null                                  as icd_diag_cd22
          |  	,null                                  as icd_diag_cd23
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD1_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD2_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD3_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD4_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD5_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD6_TYPE
          |        ,null                                  as claim_line_id
          |	,null                                  as source_code
          |	,null                                  as admit_type_code
          |	,null                                  as admit_prov_id
          |	,null                                  as admit_prov_npi
          |	,null                                  as pat_liability_amt
          |	,null                                  as attnd_prov_id
          |	,null                                  as attnd_prov_npi
          |	,null                                  as billing_prov_id
          |	,null                                  as billing_prov_npi
          |	,null                                  as capitated_service_flag
          |	,null                                  as diag_rel_grp_grouper
          |	,null                                  as denied_reason
          |	,null                                  as ein
          |	,null                                  as financial_class
          |  	,null                                  as member_gender_code
          |	,null                                  as par_flag
          |	,null                                  as pcp_id
          |	,null                                  as pcp_name
          |	,null                                  as pcp_npi
          |	,null                                  as proc_cd_modifier_2
          |from DTL
          |cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
          |
          |
          |)
        """.stripMargin
          .replace(groupIdConstant, loaderVars.groupId)
          .replace(clientDsIdConstant, clientDsId)
      )

      val df2mdsp = sparkSession.sql(
        """
          |with ll as
          |(
          | select fileid,max(transact_date) as transact_date
          | from RECLMDSP
          | group by fileid
          | ),
          |hdr as
          |(select
          |        h.*,
          |      concat_ws('', mbr_pid, '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(srv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(srv_code,'[A-Z0-9]{5}', 0), '') else null  end, '_', case when srv_cd_typ = 'R' then lpad(Srv_Code,4,'0') else null end) as biz_key
          | from RECLM627 h
          | where lr_ind is null
          | and not (claim_ind in ('%') and safe_to_number(fund_exp) = 0)
          |
          | ),
          |dtl as
          |(select
          |        p.*,
          |        case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then
          |            concat_ws('', mbr_pid,'_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(serv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end, '_', case when srv_cd_typ = 'R' then lpad(Type,4,'0') else null end)
          |         else
          |              concat_ws('', mbr_pid, '00', '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(serv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end, '_', case when srv_cd_typ = 'R' then lpad(Type,4,'0') else null end)
          |          end as dtl_key
          |         from RECLMDSP  p
          |         inner join ll on p.fileid=ll.fileid
          | where claim_type in ('H','P')
          | and not (claim_ind in ('%') and safe_to_number(fund_exp) = 0)
          |
          | ),
          |hdr_filter as
          |(
          |select  *
          | from HDR
          | anti join DTL on biz_key=dtl_key
          | )
          |select groupid, client_ds_id, datasrc, claim_header_id, contract_id, member_id, payer_code, payer_name, place_of_service, quantity_of_service, service_date, servicing_prov_id, source_code, admit_date, payment_amt, requested_amt, capitated_service_flag, claim_type, diag_rel_grp_code, diag_rel_grp_grouper, discharge_date, discharge_status_code, encounterid, icd_diag_cd1, icd_diag_cd2, icd_diag_cd3, icd_diag_cd4, icd_diag_cd5, icd_diag_cd6, icd_diag_cd7, icd_diag_cd8, icd_diag_cd9, icd_diag_cd10, icd_diag_cd11, icd_diag_cd12, icd_diag_cd13, icd_diag_cd14, icd_diag_cd15, icd_diag_cd16, icd_diag_cd17, icd_diag_cd18, icd_diag_cd19, icd_diag_cd20, icd_diag_cd21, icd_diag_cd22, icd_diag_cd23, ICD_DIAG_CD1_TYPE, member_gender_code, par_flag, pcp_id, pcp_name, pcp_npi, pay_process_date,
          | case when regexp_instr(proc_cd_modifier_1,'[^a-zA-Z0-9 ]') > 0 then null else proc_cd_modifier_1 end as proc_cd_modifier_1, proc_cd_modifier_2,proc_code,referring_prov_id,revenue_code,service_from_date,
          | service_to_date,servicing_prov_name,servicing_prov_npi,type_of_bill_code,
          | claim_line_id,admit_source_code,admit_type_code,admit_prov_id,admit_prov_npi,allowed_amt,pat_liability_amt,attnd_prov_id,attnd_prov_npi,
          | billing_prov_id,billing_prov_npi,denied_reason,ein,financial_class,icd_proc_cd_1,icd_proc_cd_2, icd_proc_cd_3, icd_proc_cd_4, icd_proc_cd_5,icd_proc_cd_6,
          | principle_proc_cd,coinsurance_amt,servicing_prov_spclty_cd,null as ICD_DIAG_CD2_TYPE,null as ICD_DIAG_CD3_TYPE,null as ICD_DIAG_CD4_TYPE,null as ICD_DIAG_CD5_TYPE,null as ICD_DIAG_CD6_TYPE,
          | null as PRINCIPLE_PROC_ICD_TYPE,
          |null as ICD_PROC_CD_1_TYPE,
          |null as ICD_PROC_CD_2_TYPE,
          |null as ICD_PROC_CD_3_TYPE,
          |null as ICD_PROC_CD_4_TYPE,
          |null as ICD_PROC_CD_5_TYPE,
          |null as ICD_PROC_CD_6_TYPE,
          |null as ICD_PROC_CD_7_TYPE,
          |null as ICD_PROC_CD_8_TYPE,
          |null as ICD_PROC_CD_9_TYPE
          |
          |from
          |(
          |select
          |        '{groupid}'                                as groupid
          |	,{client_ds_id}                          as client_ds_id
          |	,'reclm627'                             as datasrc
          |	,bme.employeraccountid                  as contract_id
          |	,bme.employeraccountid                  as payer_code
          |	,bme.employeraccountid                  as payer_name
          |	,hdr.mbr_pid                             as member_id
          |	,hdr.biz_key                            as claim_header_id
          |	,hdr.biz_key                            as encounterid
          |        ,null                                   as claim_type
          |	,null                                   as type_of_bill_code
          |	,case when hdr.pot = '1' then '21' when hdr.pot = '2' then '22' when hdr.pot = '3' then '11'
          |              when hdr.pot = '4' then '12' when hdr.pot = '5' then '52' when hdr.pot = '7' then '32' when hdr.pot = '8' then '31'
          |              when hdr.pot = '9' then '41' when hdr.pot = 'A' then '81' when hdr.pot = 'B' then '33' when hdr.pot = 'D' then '71'
          |              when hdr.pot = 'F' then '51' when hdr.pot = 'G' then '22' when hdr.pot = 'H' then '21' when hdr.pot = 'I' then '24'
          |              when hdr.pot = 'R' then '23' when hdr.pot = 'T' then '99'
          |              when hdr.pot = 'W' then '22'
          |              end                               as place_of_service
          |	,hdr.srv_frm_dt                         as service_date
          |	,hdr.srv_frm_dt                         as service_from_date
          |	,hdr.srv_to_dt                          as service_to_date
          |	,null                                   as pay_process_date
          |        ,hdr.serv_prov                          as servicing_prov_id
          |	,null                                   as servicing_prov_npi
          |	,hdr.sprov_name                         as servicing_prov_name
          |	,null                                   as servicing_prov_spclty_cd
          |	,null                                   as referring_prov_id
          |	,null                                   as admit_date
          |        ,null                                   as admit_source_code
          |	,null                                   as discharge_date
          |	,null                                   as discharge_status_code
          |	,case when hdr.srv_cd_typ = 'R' then lpad(hdr.Srv_Code,4,'0') else null end as revenue_code
          |	,case when hdr.srv_cd_typ in ('H','C') then hdr.srv_code end as proc_code
          |	,case when hdr.srv_cd_typ in ('C','H') then hdr.srv_cd_mod else null end as proc_cd_modifier_1
          |	,null                                   as diag_rel_grp_code
          |  ,case when safe_to_number(hdr.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(hdr.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(hdr.Serv_Units,'(\\+|\\-)',''), '')))
          |              when safe_to_number(hdr.fund_exp) =  0 and hdr.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('', hdr.claim_ind,nullif(regexp_replace(hdr.Serv_Units,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(hdr.Serv_Units)
          |              end as quantity_of_service
          |  ,case when safe_to_number(hdr.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(hdr.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(hdr.Coins_Amt,'(\\+|\\-)',''), '')))
          |              when safe_to_number(hdr.fund_exp) =  0 and hdr.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('', hdr.claim_ind,nullif(regexp_replace(hdr.Coins_Amt,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(hdr.Coins_Amt)
          |              end                               as coinsurance_amt
          |        ,null                                   as requested_amt
          |        ,null					as allowed_amt
          |        ,safe_to_number(hdr.fund_exp)  					as payment_amt
          |	,null                                   as principle_proc_cd
          |    	,null                                   as icd_proc_cd_1
          |    	,null                                   as icd_proc_cd_2
          |    	,null                                   as icd_proc_cd_3
          |    	,null                                   as icd_proc_cd_4
          |    	,null                                   as icd_proc_cd_5
          |        ,null                                   as icd_proc_cd_6
          |  	,coalesce(hdr.Icd10_Diag, hdr.Icd9_Diag) as ICD_DIAG_CD1
          |  	,null                                   as icd_diag_cd2
          |  	,null                                   as icd_diag_cd3
          |  	,null                                   as icd_diag_cd4
          |  	,null                                   as icd_diag_cd5
          |  	,null                                   as icd_diag_cd6
          |  	,null                                   as icd_diag_cd7
          |  	,null                                   as icd_diag_cd8
          |  	,null                                   as icd_diag_cd9
          |  	,null                                   as icd_diag_cd10
          |  	,null                                   as icd_diag_cd11
          |  	,null                                   as icd_diag_cd12
          |  	,null                                   as icd_diag_cd13
          |  	,null                                   as icd_diag_cd14
          |  	,null                                   as icd_diag_cd15
          |  	,null                                   as icd_diag_cd16
          |  	,null                                   as icd_diag_cd17
          |  	,null                                   as icd_diag_cd18
          |  	,null                                   as icd_diag_cd19
          |  	,null                                   as icd_diag_cd20
          |  	,null                                   as icd_diag_cd21
          |  	,null                                   as icd_diag_cd22
          |  	,null                                   as icd_diag_cd23
          |        ,case when hdr.ICD_IND = '9' then 'ICD9' when hdr.ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD1_TYPE
          |	,null                                   as claim_line_id
          |	,null                                   as source_code
          |	,null                                   as admit_type_code
          |	,null                                   as admit_prov_id
          |	,null                                   as admit_prov_npi
          |	,null                                   as pat_liability_amt
          |	,null                                   as attnd_prov_id
          |	,null                                   as attnd_prov_npi
          |	,null                                   as billing_prov_id
          |	,null                                   as billing_prov_npi
          |	,null                                   as capitated_service_flag
          |	,null                                   as diag_rel_grp_grouper
          |	,null                                   as denied_reason
          |	,null                                   as ein
          |	,null                                   as financial_class
          |  ,null                                   as member_gender_code
          |	,null                                   as par_flag
          |	,null                                   as pcp_id
          |	,null                                   as pcp_name
          |	,null                                   as pcp_npi
          |	,null                                   as proc_cd_modifier_2
          |from HDR_FILTER hdr
          |cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
          |
          |
          |)
        """.stripMargin
          .replace(groupIdConstant, loaderVars.groupId)
          .replace(clientDsIdConstant, clientDsId)
      )

      df1mdsp.unionByName(df2mdsp)
    }
    else {
      val df1 = sparkSession.sql(
        """
          |with ll as
          |(
          | select
          |    fileid, max(transact_date) as transact_date
          |    from RECLMEXP
          |    group by fileid
          |
          |),
          |dtl as
          |(select
          |        p.*,
          |        case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then
          |           concat_ws('', mbr_pid,'_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(serv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end, '_', case when srv_cd_typ = 'R' then lpad(Type,4,'0') else null end)
          |        else
          |         concat_ws('', mbr_pid, '00', '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(serv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end, '_', case when srv_cd_typ = 'R' then lpad(Type,4,'0') else null end)
          |        end as dtl_key,
          |        case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then mbr_pid else concat_ws('', mbr_pid, '00') end as memb_id
          | from RECLMEXP  p
          | inner join ll on p.fileid=ll.fileid
          | where claim_type in ('H','P')
          | and not (claim_ind in ('%') and safe_to_number(fund_exp) = 0)
          |
          | )
          | select groupid,client_ds_id,datasrc, claim_header_id, contract_id, member_id, payer_code, payer_name, place_of_service, quantity_of_service, service_date, servicing_prov_id, source_code, admit_date, payment_amt, requested_amt, capitated_service_flag, claim_type, diag_rel_grp_code, diag_rel_grp_grouper, discharge_date, discharge_status_code, encounterid, icd_diag_cd1, icd_diag_cd2, icd_diag_cd3, icd_diag_cd4, icd_diag_cd5, icd_diag_cd6, icd_diag_cd7, icd_diag_cd8, icd_diag_cd9, icd_diag_cd10, icd_diag_cd11, icd_diag_cd12, icd_diag_cd13, icd_diag_cd14, icd_diag_cd15, icd_diag_cd16, icd_diag_cd17, icd_diag_cd18, icd_diag_cd19, icd_diag_cd20, icd_diag_cd21, icd_diag_cd22, icd_diag_cd23, ICD_DIAG_CD1_TYPE, ICD_DIAG_CD2_TYPE, ICD_DIAG_CD3_TYPE, ICD_DIAG_CD4_TYPE, ICD_DIAG_CD5_TYPE, ICD_DIAG_CD6_TYPE,
          |  member_gender_code, par_flag, pcp_id, pcp_name, pcp_npi, pay_process_date,
          |  case when regexp_instr(proc_cd_modifier_1,'[^a-zA-Z0-9 ]') > 0 then null else proc_cd_modifier_1 end as proc_cd_modifier_1,proc_cd_modifier_2,proc_code,PRINCIPLE_PROC_ICD_TYPE,referring_prov_id,revenue_code,service_from_date,service_to_date,servicing_prov_name,servicing_prov_npi,type_of_bill_code,claim_line_id,admit_source_code,admit_type_code,admit_prov_id,admit_prov_npi,allowed_amt,pat_liability_amt,attnd_prov_id,attnd_prov_npi,billing_prov_id,billing_prov_npi,denied_reason,ein,financial_class,icd_proc_cd_1,icd_proc_cd_2, icd_proc_cd_3, icd_proc_cd_4, icd_proc_cd_5,icd_proc_cd_6,
          |ICD_PROC_CD_1_TYPE,ICD_PROC_CD_2_TYPE,ICD_PROC_CD_3_TYPE,ICD_PROC_CD_4_TYPE,ICD_PROC_CD_5_TYPE,ICD_PROC_CD_6_TYPE,ICD_PROC_CD_7_TYPE,ICD_PROC_CD_8_TYPE,ICD_PROC_CD_9_TYPE,principle_proc_cd,coinsurance_amt,servicing_prov_spclty_cd
          |from
          |(
          |select
          |        '{groupid}'                                as groupid
          |	,{client_ds_id}                          as client_ds_id
          |	,'reclmexp'                             as datasrc
          |	,bme.employeraccountid                  as contract_id
          |	,bme.employeraccountid                  as payer_code
          |	,bme.employeraccountid                  as payer_name
          |	,memb_id                                as member_id
          |	,dtl_key                                as claim_header_id
          |	,dtl_key                                as encounterid
          |        ,case when Claim_Type = 'H' then 'I' when Claim_Type = 'P' then 'P' else null end AS claim_type
          |	,bill_type                              as type_of_bill_code
          |        ,case when Cms_Pot in ('XX') then null else Cms_Pot end as place_of_service
          |	,coalesce(srv_frm_dt,srvc_in_dt)        as service_date
          |	,srv_frm_dt                             as service_from_date
          |	,serv_to_dt                             as service_to_date
          |	,proc_date                              as pay_process_date
          | ,case when {client_ds_id} =10808 then coalesce(dtl.serv_prov,dtl.npi) else coalesce(dtl.npi,dtl.serv_prov) end as servicing_prov_id
          |	,npi                                    as servicing_prov_npi
          |	,sprov_name                             as servicing_prov_name
          |	,sprov_spec                             as servicing_prov_spclty_cd
          |	,case when refer_prov in ('000000000','999999999','0') then null else refer_prov end as referring_prov_id
          |	,safe_to_date(Adm_Date,'yyyyMMdd')      as admit_date
          | ,nvl2(adm_srce, concat_ws('', 'CMS.', adm_srce), null) as admit_source_code
          |	,safe_to_date(Dischrg_Dt,'yyyyMMdd')    as discharge_date
          |	,dischrg_st                             as discharge_status_code
          |	,case when Srv_Cd_Typ = 'R' then lpad(Type,4,'0') else null end as revenue_code
          |	,case when Srv_Cd_Typ in ('C','H') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end as proc_code
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as PRINCIPLE_PROC_ICD_TYPE
          |	,case when Srv_Cd_Typ in ('C','H') then Type_Mod when (Srv_Cd_Typ not in ('C','H') and Proc_Code1 is not null) then Cpt4_Mod else null end AS proc_cd_modifier_1
          |	,case when Drg_Nbr='000' then null else Drg_Nbr end AS diag_rel_grp_code
          |,case when safe_to_number(dtl.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(dtl.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(dtl.Serv_Units,'(\\+|\\-)',''), '')))
          |              when safe_to_number(dtl.fund_exp) =  0 and dtl.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('',dtl.claim_ind,nullif(regexp_replace(dtl.Serv_Units,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(dtl.Serv_Units)
          |              end as quantity_of_service
          |,case when safe_to_number(dtl.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(dtl.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(dtl.Coins_Amt,'(\\+|\\-)',''), '')))
          |              when safe_to_number(dtl.fund_exp) =  0 and dtl.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('', dtl.claim_ind,nullif(regexp_replace(dtl.Coins_Amt,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(dtl.Coins_Amt)
          |              end                               as coinsurance_amt
          |	,case when safe_to_number(dtl.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(dtl.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(dtl.chrg_amt,'(\\+|\\-)',''), '')))
          |              when safe_to_number(dtl.fund_exp) =  0 and dtl.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('',dtl.claim_ind,nullif(regexp_replace(dtl.chrg_amt,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(dtl.chrg_amt)
          |              end                               as requested_amt
          |,case when safe_to_number(dtl.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(dtl.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(dtl.bsched_amt,'(\\+|\\-)',''), '')))
          |              when safe_to_number(dtl.fund_exp) =  0 and dtl.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('', dtl.claim_ind,nullif(regexp_replace(dtl.bsched_amt,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(dtl.bsched_amt)
          |              end                               as allowed_amt
          |	,case when safe_to_number(dtl.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(dtl.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(dtl.act_pd_amt,'(\\+|\\-)',''), '')))
          |              when safe_to_number(dtl.fund_exp) =  0 and dtl.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('',dtl.claim_ind,nullif(regexp_replace(dtl.act_pd_amt,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(dtl.act_pd_amt)
          |              end                              as payment_amt
          |	,proc_code1                            as principle_proc_cd
          |    	,proc_code1                            as icd_proc_cd_1
          |    	,proc_code2                            as icd_proc_cd_2
          |    	,proc_code3                            as icd_proc_cd_3
          |    	,proc_code4                            as icd_proc_cd_4
          |    	,proc_code5                            as icd_proc_cd_5
          |        ,proc_code6                            as icd_proc_cd_6
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_1_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_2_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_3_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_4_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_5_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_6_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_7_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_8_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_PROC_CD_9_TYPE
          |        ,diag_code1                            as icd_diag_cd1
          |  	,diag_code2                            as icd_diag_cd2
          |  	,diag_code3                            as icd_diag_cd3
          |  	,diag_code4                            as icd_diag_cd4
          |  	,diag_code5                            as icd_diag_cd5
          |  	,diag_code6                            as icd_diag_cd6
          |  	,diag_code7                            as icd_diag_cd7
          |  	,diag_code8                            as icd_diag_cd8
          |  	,diag_code9                            as icd_diag_cd9
          |  	,null                                  as icd_diag_cd10
          |  	,null                                  as icd_diag_cd11
          |  	,null                                  as icd_diag_cd12
          |  	,null                                  as icd_diag_cd13
          |  	,null                                  as icd_diag_cd14
          |  	,null                                  as icd_diag_cd15
          |  	,null                                  as icd_diag_cd16
          |  	,null                                  as icd_diag_cd17
          |  	,null                                  as icd_diag_cd18
          |  	,null                                  as icd_diag_cd19
          |  	,null                                  as icd_diag_cd20
          |  	,null                                  as icd_diag_cd21
          |  	,null                                  as icd_diag_cd22
          |  	,null                                  as icd_diag_cd23
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD1_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD2_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD3_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD4_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD5_TYPE
          |        ,case when ICD_IND = '9' then 'ICD9' when ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD6_TYPE
          |        ,null                                  as claim_line_id
          |	,null                                  as source_code
          |	,null                                  as admit_type_code
          |	,null                                  as admit_prov_id
          |	,null                                  as admit_prov_npi
          |	,null                                  as pat_liability_amt
          |	,null                                  as attnd_prov_id
          |	,null                                  as attnd_prov_npi
          |	,null                                  as billing_prov_id
          |	,null                                  as billing_prov_npi
          |	,null                                  as capitated_service_flag
          |	,null                                  as diag_rel_grp_grouper
          |	,null                                  as denied_reason
          |	,null                                  as ein
          |	,null                                  as financial_class
          |  	,null                                  as member_gender_code
          |	,null                                  as par_flag
          |	,null                                  as pcp_id
          |	,null                                  as pcp_name
          |	,null                                  as pcp_npi
          |	,null                                  as proc_cd_modifier_2
          |from DTL
          |cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
          |)
        """.stripMargin
          .replace(groupIdConstant, loaderVars.groupId)
          .replace(clientDsIdConstant, clientDsId)
      )



      val df2 = sparkSession.sql(
        """
          |with ll as
          |(
          |   select fileid,max(transact_date) as transact_date
          |   from RECLMEXP
          |   group by fileid
          |),
          |hdr as
          |(select
          |        h.*,
          |      concat_ws('', mbr_pid, '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(srv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(srv_code,'[A-Z0-9]{5}', 0), '') else null  end, '_', case when srv_cd_typ = 'R' then lpad(Srv_Code,4,'0') else null end) as biz_key
          | from RECLM627 h
          | where lr_ind is null
          | and not (claim_ind in ('%') and safe_to_number(fund_exp) = 0)
          | ),
          |dtl as
          |(select
          |        p.*,
          |        case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then
          |          concat_ws('', mbr_pid, '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(serv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end, '_', case when srv_cd_typ = 'R' then lpad(Type,4,'0') else null end)
          |        else
          |        concat_ws('', mbr_pid, '00', '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', upper(date_format(serv_to_dt, 'dd-MMM-yy')), '_', nullif(regexp_replace(serv_prov,' ',''), ''), '_', lpad(pot,2,0), '_', case when srv_cd_typ in ('H','C') then nullif(regexp_extract(type,'[A-Z0-9]{5}', 0), '') else null end, '_', case when srv_cd_typ = 'R' then lpad(Type,4,'0') else null end)
          |        end as dtl_key
          |
          | from RECLMEXP  p
          | inner join ll on p.fileid=ll.fileid
          | where claim_type in ('H','P')
          | and not (claim_ind in ('%') and safe_to_number(fund_exp) = 0)
          |
          | ),
          |hdr_filter as
          |(
          |select  *
          | from HDR
          | anti join DTL on biz_key=dtl_key
          | )
          |select groupid, client_ds_id, datasrc, claim_header_id, contract_id, member_id, payer_code, payer_name, place_of_service, quantity_of_service, service_date, servicing_prov_id, source_code, admit_date, payment_amt, requested_amt, capitated_service_flag, claim_type, diag_rel_grp_code, diag_rel_grp_grouper, discharge_date, discharge_status_code, encounterid, icd_diag_cd1, icd_diag_cd2, icd_diag_cd3, icd_diag_cd4, icd_diag_cd5, icd_diag_cd6, icd_diag_cd7, icd_diag_cd8, icd_diag_cd9, icd_diag_cd10, icd_diag_cd11, icd_diag_cd12, icd_diag_cd13, icd_diag_cd14, icd_diag_cd15, icd_diag_cd16, icd_diag_cd17, icd_diag_cd18, icd_diag_cd19, icd_diag_cd20, icd_diag_cd21, icd_diag_cd22, icd_diag_cd23, ICD_DIAG_CD1_TYPE, member_gender_code, par_flag, pcp_id, pcp_name, pcp_npi, pay_process_date,
          | case when regexp_instr(proc_cd_modifier_1,'[^a-zA-Z0-9 ]') > 0 then null else proc_cd_modifier_1 end as proc_cd_modifier_1, proc_cd_modifier_2,proc_code,referring_prov_id,revenue_code,service_from_date,
          | service_to_date,servicing_prov_name,servicing_prov_npi,type_of_bill_code,
          | claim_line_id,admit_source_code,admit_type_code,admit_prov_id,admit_prov_npi,allowed_amt,pat_liability_amt,attnd_prov_id,attnd_prov_npi,
          | billing_prov_id,billing_prov_npi,denied_reason,ein,financial_class,icd_proc_cd_1,icd_proc_cd_2, icd_proc_cd_3, icd_proc_cd_4, icd_proc_cd_5,icd_proc_cd_6,
          | principle_proc_cd,coinsurance_amt,servicing_prov_spclty_cd,null as ICD_DIAG_CD2_TYPE,null as ICD_DIAG_CD3_TYPE,null as ICD_DIAG_CD4_TYPE,null as ICD_DIAG_CD5_TYPE,null as ICD_DIAG_CD6_TYPE,
          |null as PRINCIPLE_PROC_ICD_TYPE,
          |null as ICD_PROC_CD_1_TYPE,
          |null as ICD_PROC_CD_2_TYPE,
          |null as ICD_PROC_CD_3_TYPE,
          |null as ICD_PROC_CD_4_TYPE,
          |null as ICD_PROC_CD_5_TYPE,
          |null as ICD_PROC_CD_6_TYPE,
          |null as ICD_PROC_CD_7_TYPE,
          |null as ICD_PROC_CD_8_TYPE,
          |null as ICD_PROC_CD_9_TYPE
          |from
          |(
          |select
          |        '{groupid}'                                as groupid
          |	,{client_ds_id}                          as client_ds_id
          |	,'reclm627'                             as datasrc
          |	,bme.employeraccountid                  as contract_id
          |	,bme.employeraccountid                  as payer_code
          |	,bme.employeraccountid                  as payer_name
          |	,hdr.mbr_pid                             as member_id
          |	,hdr.biz_key                            as claim_header_id
          |	,hdr.biz_key                            as encounterid
          |        ,null                                   as claim_type
          |	,null                                   as type_of_bill_code
          |	,case when hdr.pot = '1' then '21' when hdr.pot = '2' then '22' when hdr.pot = '3' then '11'
          |              when hdr.pot = '4' then '12' when hdr.pot = '5' then '52' when hdr.pot = '7' then '32' when hdr.pot = '8' then '31'
          |              when hdr.pot = '9' then '41' when hdr.pot = 'A' then '81' when hdr.pot = 'B' then '33' when hdr.pot = 'D' then '71'
          |              when hdr.pot = 'F' then '51' when hdr.pot = 'G' then '22' when hdr.pot = 'H' then '21' when hdr.pot = 'I' then '24'
          |              when hdr.pot = 'R' then '23' when hdr.pot = 'T' then '99'
          |              when hdr.pot = 'W' then '22'
          |              end                               as place_of_service
          |	,hdr.srv_frm_dt                         as service_date
          |	,hdr.srv_frm_dt                         as service_from_date
          |	,hdr.srv_to_dt                          as service_to_date
          |	,null                                   as pay_process_date
          | ,hdr.serv_prov                          as servicing_prov_id
          |	,null                                   as servicing_prov_npi
          |	,hdr.sprov_name                         as servicing_prov_name
          |	,null                                   as servicing_prov_spclty_cd
          |	,null                                   as referring_prov_id
          |	,null                                   as admit_date
          | ,null                                   as admit_source_code
          |	,null                                   as discharge_date
          |	,null                                   as discharge_status_code
          |	,case when hdr.srv_cd_typ = 'R' then lpad(hdr.Srv_Code,4,'0') else null end as revenue_code
          |	,case when hdr.srv_cd_typ in ('H','C') then hdr.srv_code end as proc_code
          |	,case when hdr.srv_cd_typ in ('C','H') then hdr.srv_cd_mod else null end as proc_cd_modifier_1
          |	,null                                   as diag_rel_grp_code
          |  ,case when safe_to_number(hdr.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(hdr.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(hdr.Serv_Units,'(\\+|\\-)',''), '')))
          |              when safe_to_number(hdr.fund_exp) =  0 and hdr.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('', hdr.claim_ind,nullif(regexp_replace(hdr.Serv_Units,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(hdr.Serv_Units)
          |              end as quantity_of_service
          |  ,case when safe_to_number(hdr.fund_exp) <> 0 then safe_to_number(concat_ws('',nullif(regexp_extract(hdr.fund_exp,'(\\+|\\-)', 0), ''),nullif(regexp_replace(hdr.Coins_Amt,'(\\+|\\-)',''), '')))
          |              when safe_to_number(hdr.fund_exp) =  0 and hdr.claim_ind in ('+','-') then safe_to_number(nullif(concat_ws('', hdr.claim_ind,nullif(regexp_replace(hdr.Coins_Amt,'(\\+|\\-)',''), '')),''))
          |              else safe_to_number(hdr.Coins_Amt)
          |              end                               as coinsurance_amt
          |        ,null                                   as requested_amt
          |        ,null					as allowed_amt
          |        ,null					as payment_amt
          |	,null                                   as principle_proc_cd
          |    	,null                                   as icd_proc_cd_1
          |    	,null                                   as icd_proc_cd_2
          |    	,null                                   as icd_proc_cd_3
          |    	,null                                   as icd_proc_cd_4
          |    	,null                                   as icd_proc_cd_5
          |     ,null                                   as icd_proc_cd_6
          |  	,coalesce(hdr.Icd10_Diag, hdr.Icd9_Diag) as ICD_DIAG_CD1
          |  	,null                                   as icd_diag_cd2
          |  	,null                                   as icd_diag_cd3
          |  	,null                                   as icd_diag_cd4
          |  	,null                                   as icd_diag_cd5
          |  	,null                                   as icd_diag_cd6
          |  	,null                                   as icd_diag_cd7
          |  	,null                                   as icd_diag_cd8
          |  	,null                                   as icd_diag_cd9
          |  	,null                                   as icd_diag_cd10
          |  	,null                                   as icd_diag_cd11
          |  	,null                                   as icd_diag_cd12
          |  	,null                                   as icd_diag_cd13
          |  	,null                                   as icd_diag_cd14
          |  	,null                                   as icd_diag_cd15
          |  	,null                                   as icd_diag_cd16
          |  	,null                                   as icd_diag_cd17
          |  	,null                                   as icd_diag_cd18
          |  	,null                                   as icd_diag_cd19
          |  	,null                                   as icd_diag_cd20
          |  	,null                                   as icd_diag_cd21
          |  	,null                                   as icd_diag_cd22
          |  	,null                                   as icd_diag_cd23
          |   ,case when hdr.ICD_IND = '9' then 'ICD9' when hdr.ICD_IND = 'A' then 'ICD10' else null end as ICD_DIAG_CD1_TYPE
          |	,null                                   as claim_line_id
          |	,null                                   as source_code
          |	,null                                   as admit_type_code
          |	,null                                   as admit_prov_id
          |	,null                                   as admit_prov_npi
          |	,null                                   as pat_liability_amt
          |	,null                                   as attnd_prov_id
          |	,null                                   as attnd_prov_npi
          |	,null                                   as billing_prov_id
          |	,null                                   as billing_prov_npi
          |	,null                                   as capitated_service_flag
          |	,null                                   as diag_rel_grp_grouper
          |	,null                                   as denied_reason
          |	,null                                   as ein
          |	,null                                   as financial_class
          |  ,null                                   as member_gender_code
          |	,null                                   as par_flag
          |	,null                                   as pcp_id
          |	,null                                   as pcp_name
          |	,null                                   as pcp_npi
          |	,null                                   as proc_cd_modifier_2
          |from HDR_FILTER hdr
          |cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
          |)
        """.stripMargin
          .replace(groupIdConstant, loaderVars.groupId)
          .replace(clientDsIdConstant, clientDsId)
      )
      df1.unionByName(df2)
    }
  }


}

package com.optum.cdr.fe.etl.commercial.cust_pay_aetna.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object custPayAetnaQueries extends BaseQueryConfig {

  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)

  override def queryRegistry = QueryRegistry.queries

}

object InitialDependencies {

  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      FELoadFromParquet[cust_pay_aetna_aetaclaim](name = "AETACLAIM", parquetLocation = s"$baseParquetLocation", tableName = "AETACLAIM", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[cust_pay_aetna_aetacoe6](name = "AETACOE6", parquetLocation = s"$baseParquetLocation", tableName = "AETACOE6")
 //   , FELoadFromParquet[cust_pay_aetna_eligibility](name = "ELIGIBILITY", parquetLocation = s"$baseParquetLocation", tableName = "ELIGIBILITY")
    , FELoadFromParquet[cust_pay_aetna_aetndrug](name = "AETNDRUG", parquetLocation = s"$baseParquetLocation", tableName = "AETNDRUG")
    , FELoadFromParquet[cust_pay_aetna_aetnlabd](name = "AETNLABD", parquetLocation = s"$baseParquetLocation", tableName = "AETNLABD")
    , FELoadFromParquet[zo_bpo_map_employer](name = "ZO_BPO_MAP_EMPLOYER", parquetLocation = s"$mappingParquetPath", tableName = "ZO_BPO_MAP_EMPLOYER")
    , FELoadFromParquet[ref_billtype_pos_xref](name = "REF_BILLTYPE_POS_XREF", parquetLocation = s"$mappingParquetPath", tableName = "REF_BILLTYPE_POS_XREF")
    , FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName = "MAP_PREDICATE_VALUES")
  )
}

object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    INT_CLAIM_PHARM
    , INT_CLAIM_PHARM_CACHE1
    , INT_CLAIM_PHARM_H367_CACHE1
    , INT_CLAIM_MEDICAL
    , INT_CLAIM_MEMBER
    , INT_CLAIM_MEMBER_CACHE1
    , INT_CLAIM_MEMBER_H770_CACHE1
    , INT_CLAIM_MEMBER_MASKED_CACHE1
    , INT_CLAIM_LABRESULT
  )
}

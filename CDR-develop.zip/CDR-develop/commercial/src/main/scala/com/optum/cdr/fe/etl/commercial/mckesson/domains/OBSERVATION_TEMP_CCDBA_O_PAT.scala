package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_TEMP_CCDBA_O_PAT extends FETableInfo[observation] {
  override def name: String = "OBSERVATION_TEMP_CCDBA_O_PAT"

  override def dependsOn: Set[String] = Set("CCDBA_O_PAT","MCKESSON_ENT_PATIENT")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |WITH uni_opat AS
         | (SELECT * FROM (
         | (SELECT o.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY order_ddt DESC NULLS LAST) rn
         |    FROM CCDBA_O_PAT o
         |   WHERE order_ddt IS NOT NULL )
         |) WHERE rn = 1),
         |uni_epat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |   WHERE cpi_seq IS NOT NULL )
         |) WHERE rn = 1)
         |select datasrc, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid, statuscode
         |from
         |(
         |SELECT 'ccdba_o_pat' 		AS datasrc
         |	,NULL			AS localresult
         |	,concat_ws('', {client_ds_id}, '.', uni_opat.Order_Item_Seq) AS localcode
         |	,uni_opat.order_ddt	AS obsdate
         |	,uni_epat.cpi_seq  	AS patientid
         |	,uni_opat.pat_seq  	AS encounterid
         |	,uni_opat.facility_id 	AS facilityid
         |	,uni_opat.status        AS statuscode
         |	,NULL 			AS obsresult
         |	,NULL                   AS obstype
         |	,NULL 			AS local_obs_unit
         |    	,NULL    		AS std_obs_unit
         |	,ROW_NUMBER() OVER (PARTITION BY uni_epat.cpi_seq,uni_opat.pat_seq,uni_opat.Order_Item_Seq,uni_opat.order_ddt
         |			    ORDER BY uni_opat.order_ddt DESC NULLS LAST) obs_rn
         |FROM UNI_OPAT
         |    LEFT OUTER JOIN UNI_EPAT ON  uni_opat.pat_seq = uni_epat.pat_seq
         |
         |)
         |where patientid IS NOT NULL AND obs_rn = 1
       """.stripMargin.replace("{client_ds_id}",clientDsId))
  }
}

package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.proceduredo
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel



object PROCEDURE_TEMP_CCDBA_PAT_RESULTS extends FETableInfo[proceduredo] {
  override def name: String = "PROCEDURE_TEMP_CCDBA_PAT_RESULTS"

  override def dependsOn: Set[String] = Set("MCKESSON_CCDBA_PAT_RESULTS", "MCKESSON_ENT_PATIENT", "MAP_CUSTOM_PROC", "MCKESSON_ZH_CCDEV_PCQ_LABEL")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |WITH uni_res AS
         |(SELECT * FROM
         |(SELECT p.*, CASE WHEN {client_ds_id} = 5726 THEN
         |	     CASE WHEN label_seq = '251422' AND LOWER(result_value) LIKE '%disc%' THEN concat_ws('', '{client_ds_id}', '.CATHREMVL')
         |	          WHEN label_seq = '251422' AND LOWER(result_value) NOT LIKE '%disc%' THEN concat_ws('', '{client_ds_id}', '.CATHACTIVITY')
         |	          ELSE concat_ws('', '{client_ds_id}', '.', Label_Seq) END
         |	 ELSE concat_ws('', '{client_ds_id}', '.', Label_Seq) END AS localcode_str
         |	,ROW_NUMBER() OVER (PARTITION BY result_seq ORDER BY chart_ddt DESC NULLS LAST) rn
         | FROM MCKESSON_CCDBA_PAT_RESULTS p
         | WHERE label_Seq IS NOT NULL
         |   AND Perform_Ddt IS NOT NULL )
         | WHERE rn = 1),
         | uni_pat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |   WHERE cpi_seq IS NOT NULL )
         |) WHERE rn = 1)
         |select datasrc, localcode, encounterid, patientid, proceduredate, localname, codetype, mappedcode, proceduredate as actualprocdate, facilityid, hosp_px_flag
         |from
         |(
         |SELECT 'ccdba_pat_results' AS datasrc
         |	,uni_res.localcode_str AS localcode
         |	,uni_pat.cpi_seq  AS patientid
         |	,uni_res.Perform_Ddt  AS proceduredate
         |	,uni_res.pat_seq  AS encounterid
         |	,uni_res.facility_id  AS facilityid
         |	,Zh.Label_Name    AS localname
         |	,Map.Mappedvalue  AS mappedcode
         |	,'CUSTOM'  	  AS codetype
         |	,'Y'              AS hosp_px_flag
         |	,ROW_NUMBER() OVER (PARTITION BY uni_pat.cpi_seq, uni_res.pat_seq, uni_res.Perform_Ddt, uni_res.localcode_str
         |	 ORDER BY uni_res.chart_ddt DESC NULLS LAST) rn
         |FROM UNI_RES
         |   JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
         |                            map.datasrc = 'ccdba_pat_results' AND
         |   			    map.localcode = uni_res.localcode_str)
         |   JOIN UNI_PAT ON (uni_pat.pat_seq = uni_res.pat_seq)
         |   LEFT OUTER JOIN MCKESSON_ZH_CCDEV_PCQ_LABEL zh ON (uni_res.label_seq = zh.label_seq)
         |
         |)
         |where rn = 1 AND proceduredate IS NOT NULL
       """.stripMargin.replace("{groupid}", groupId).replace("{client_ds_id}", clientDsId))
  }
}
package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.centricityv2_patient_cache
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object PATIENT_PART2_CACHE extends FETableInfo[centricityv2_patient_cache] {

  override def name: String = "PATIENT_PART2_CACHE"

  override def dependsOn: Set[String] = Set("CENTRICV2_PATIENTPROFILE", "CENTRICV2_PATIENTETHNICITY", "CENTRICV2_PATIENTRACE", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val mapExclusionmpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "EXCLUSION", "PATIENT", "PATIENT", "LASTNAME").mkString(",")
    val mapExclusion = if (mapExclusionmpv == "'NO_MPV_MATCHES'") "''" else mapExclusionmpv
    val MRNPatientprofile = if (groupId == "H770494") "P.PATIENTID" else "P.Medicalrecordnumber"

    sparkSession.sql(
      """
        |select *,
        | row_number() over (partition by patientid order by lastupdateddate desc nulls first ) as rownumber
        | ,row_number() over (partition by patientid,lower(firstname) order by lastupdateddate desc nulls first ) as first_row
        | ,row_number() over (partition by patientid,lower(mi) order by lastupdateddate desc nulls first ) as mi_row
        | ,row_number() over (partition by patientid,lower(lastname) order by lastupdateddate desc nulls first ) as last_row
        | ,row_number() over (partition by patientid,lower(city) order by lastupdateddate desc nulls last ) as city_row
        | ,row_number() over (partition by patientid,lower(state) order by lastupdateddate desc nulls first ) as state_row
        | ,row_number() over (partition by patientid,zipcode order by lastupdateddate desc nulls first ) as zip_row
        | ,row_number() over (partition by patientid,lower(gender) order by lastupdateddate desc nulls first ) as gender_row
        | ,row_number() over (partition by patientid,lower(nullif(concat_ws('', addressline1, addressline2, city, state, zipcode), '')) order by lastupdateddate desc nulls first ) as adder_row
        | ,row_number() over (partition by patientid,homephone,workphone  order by lastupdateddate desc nulls first ) as contact_row
        | ,row_number() over (partition by patientid,maritalstatus order by lastupdateddate desc nulls first ) as marital_row
        | ,row_number() over (partition by patientid,language order by lastupdateddate desc nulls first ) as language_row
        | ,row_number() over (partition by patientid,deathindicator order by lastupdateddate desc nulls first ) as deathindicator_row
        | ,row_number() over (partition by patientid order by ethn_last_modified desc nulls last, lastupdateddate desc nulls last ) as ethnicity_row
        | ,row_number() over (partition by patientid order by race_last_modified desc nulls last, lastupdateddate desc nulls last ) as race_row
        |from ( select
        |'{groupid}'                           as groupid
        |,'Patientprofile'                                  as datasrc
        |,{client_ds_id}                                 as client_ds_id
        |,P.Pid                                       AS patientid
        |,{MRN_Patientprofile}                                  AS medicalrecordnumber
        |,P.Birthdate                               AS dateofbirth
        |,P.Deathdate                               AS dateofdeath
        |,P.Pstatus                                   AS deathindicator
        |,case when P.ethnicitymid <> '0' then cast(P.ethnicitymid as string) when PE.patientethnicitymid <> '0' then cast(PE.patientethnicitymid as string) else null end as ethnicity
        |,P.Firstname                                 AS firstname
        |,P.Sex                                   AS gender
        |,coalesce(P.Languageid,P.Preflanguagemid)                                  AS language
        |,P.Lastname							   AS lastname
        |,case When P.patientstatusmid in ('-901','-900') then 'Y'
        | when P.pstatus = 'I' then 'Y' else null end as inactive
        |,P.Maritalstatusmid                             AS maritalstatus
        |,P.Middlename                                AS mi
        |,case when P.racemid <> '0' then cast(P.racemid as string) when PR.patientracemid <> '0' then cast(PR.patientracemid as string) else null end as Race
        |,P.Lastmodified                           AS lastupdateddate
        |,case when length(P.STATE) = 2 then P.state else null end AS state
        |,P.Zip				                    AS zipcode
        |,P.Address1                                  AS addressline1
        |,P.Address2                                  AS addressline2
        |,P.Addresstype					        AS address_type
        |,P.City                                      AS city
        |,case when lower(P.phone1type) like '%cell%' then P.phone1
        | when lower(P.phone2type) like '%cell%' then P.phone2
        | when lower(P.phone3type) like '%cell%' then P.phone3
        | else null   END 						AS cell_phone
        |,case when lower(P.phone1type) like '%work%' then P.phone1
        | when lower(P.phone2type) like '%work%' then P.phone2
        | when lower(P.phone3type) like '%work%' then P.phone3
        | else null   END                              AS workphone
        |,case when lower(P.phone1type) like '%home%' then P.phone1
        | when lower(P.phone2type) like '%home%' then P.phone2
        | when lower(P.phone3type) like '%home%' then P.phone3
        | else null   End                         AS homephone
        |,P.Emailaddress                                     AS email
        |,PR.lastmodified as race_last_modified
        |,PE.lastmodified as ethn_last_modified
        |  FROM CENTRICV2_PATIENTPROFILE P
        |  left join CENTRICV2_PATIENTRACE PR on P.pid = PR.pid
        |  left join CENTRICV2_PATIENTETHNICITY PE on P.pid = PE.pid
        |          where ispatient='Y'
        |          and   lower(lastname) not in ({map_exclusion})
        |)
    """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{map_exclusion}", mapExclusion).
        replace("{MRN_Patientprofile}", MRNPatientprofile)
    )

  }

}
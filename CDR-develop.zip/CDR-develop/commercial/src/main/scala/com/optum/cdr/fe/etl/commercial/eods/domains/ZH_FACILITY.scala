package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_FACILITY  extends FEQueryAndMetadata[zh_facility] {

  override def name: String = CDRFEParquetNames.zh_facility

  override def dependsOn: Set[String] = Set("PROVIDER")

  override def sparkSql: String =
    """
      |
      |select groupid, facilityid, facilityname, client_ds_id
      |from
      |(
      |select distinct '{groupid}' 	as groupid,
      |       'provider' 			as datasrc
      |	   ,{client_ds_id} 		as client_ds_id
      |	   ,prv.Prov_Org_Nm 	as facilityid
      |	   ,prv.Prov_Org_Nm 	as facilityname
      |  from PROVIDER prv
      | where prv.Prov_Org_Nm is not null
      |
      |)
    """.stripMargin

}

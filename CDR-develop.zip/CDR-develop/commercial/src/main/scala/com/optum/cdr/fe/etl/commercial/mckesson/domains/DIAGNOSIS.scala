package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.sparkdataloader.CDRFEParquetNames
import com.optum.oap.cdr.models.diagnosis

object DIAGNOSIS extends FEQueryAndMetadata[diagnosis]{
  override def name: String = CDRFEParquetNames.diagnosis

  override def dependsOn: Set[String] = Set("DIAGNOSIS_TEMP_ENT_CPI_PROBLEM","DIAGNOSIS_TEMP_ENT_PATIENT_DIAGNOSIS")

  override def sparkSql: String =
    """
      |SELECT * FROM DIAGNOSIS_TEMP_ENT_CPI_PROBLEM
      |UNION ALL
      |SELECT * FROM DIAGNOSIS_TEMP_ENT_PATIENT_DIAGNOSIS
    """.stripMargin
}

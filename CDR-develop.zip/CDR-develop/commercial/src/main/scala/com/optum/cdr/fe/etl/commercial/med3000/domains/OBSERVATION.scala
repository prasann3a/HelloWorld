package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object OBSERVATION extends FEQueryAndMetadata[observation] {

  override def name: String = CDRFEParquetNames.observation

  override def dependsOn: Set[String] = Set("MED3000_PATIENT_VITAL_SIGNS", "ZCM_OBSTYPE_CODE", "MED3000_PATIENT_VITALS",
    "MED3000_PATIENT_VITALS", "MED3000_PATIENT_HM", "MED3000_VISIT_ENTRY_ANSWERS_H")

  override def sparkSql: String =
    """
      select groupid, datasrc, patientid, obsdate, localcode, obstype, local_obs_unit, std_obs_unit, obsresult, localresult, client_ds_id
     |from
     |(
     |select p.*
     |       , null as obsresult
     |  from (
     |select a.*
     |      ,z.Localunit  		as local_obs_unit
     |	   ,z.obstype_std_units as std_obs_unit
     |	   ,z.obstype
     |	   ,z.OBSCONVFACTOR
     |	   ,z.obsregex
     |	   ,z.datatype
     |	   ,z.begin_range
     |	   ,z.end_Range
     |	   ,z.round_prec
     |	   ,z.localunit_cui
     |	   ,z.conv_fact
     |	   ,z.function_applied
     |     ,row_number() over (partition by patientid,localcode,obsdate,obstype,localresult order by Update_Date desc nulls last) as rank_obs
     | from
     |(
     |select * from
     |(
     |select unpivot_base.*,
     |stack(14,ht_in,'HT_IN',ht_cm,'HT_CM',wt_gm,'WT_GM',wt_oz,'WT_OZ',temp_f,'TEMP_F',temp_c,'TEMP_C',pulse,'PULSE',resp,'RESP',dbp,'DBP',sbp,'SBP',dbp2,'DBP2',sbp2,'SBP2',dbp3,'DBP3',sbp3,'SBP3') as (localresult, localcode)
     |from
     |(
     |select  distinct
     |       '{groupid}' 			as groupid
     |       ,'pat_vital_signs' 	as datasrc
     |       ,{client_ds_id} 		as client_ds_id
     |       ,vit.Visit_Date  	as obsdate
     |       ,vit.Blind_Key   	as patientid
     |       ,case when height_unit = 'ft'    then string(decimal((height *  12) + height2)) end as ht_in
     |       ,case when height_unit = 'm'     then string(decimal((height * 100) + height2)) end as ht_cm
     |       ,case when weight_unit = 'kg'    then string(decimal((weight *1000) + weight2)) end as wt_gm
     |       ,case when weight_unit = 'lb'    then string(decimal((weight *  16) + weight2)) end as wt_oz
     |	   ,case When temp_unit   = 'Deg F' then temperature end as temp_f
     |       ,case when Temp_Unit   = 'Deg C' then temperature end as temp_c
     |       ,coalesce(pulse, bp1_pulse) 		as pulse
     |       ,resp_rate 	as resp
     |       ,bp1_dias 	as dbp
     |       ,bp1_sys 	as sbp
     |       ,bp2_dias 	as dbp2
     |       ,bp2_sys 	as sbp2
     |       ,bp3_dias 	as dbp3
     |       ,bp3_sys 	as sbp3
     |       ,Update_Date
     |  from MED3000_PATIENT_VITAL_SIGNS vit ) unpivot_base
     |)
     |where localresult is not null
     |) a
     |  inner join ZCM_OBSTYPE_CODE z
     |   on (z.groupid='{groupid}' and z.datasrc='pat_vital_signs' and z.obscode = localcode and z.ObsType <> 'LABRESULT')
     |   ) p
     |where rank_obs = 1
     |
     |)
     |where patientid is not null and obsdate is not null
     |
     |union all
     |
     |select groupid, datasrc, patientid, obsdate, localcode, obstype, local_obs_unit, std_obs_unit, obsresult, localresult, client_ds_id
     |from
     |(
     |select p.*
     |       , null as obsresult
     |  from (
     |select a.*
     |      ,row_number() over (partition by patientid,localcode,obsdate,obstype order by Update_Date desc nulls last) as rank_obs
     | from (
     |select  distinct
     |      '{groupid}' 		    		as groupid
     |      ,'pat_vitals' 			as datasrc
     |      ,{client_ds_id}			as client_ds_id
     |      ,lower(Vit.Short_Text)  	as localresult
     |      ,Vit.Vitals_Master_Key  	as localcode
     |      ,Vit.Create_Date  		as obsdate
     |      ,Vit.Blind_Key  			as patientid
     |      ,z.Localunit  			as localobsunit
     |      ,z.Localunit  			as local_obs_unit
     |	  ,z.obstype_std_units 		as std_obs_unit
     |	  ,z.obstype
     |	  ,z.OBSCONVFACTOR
     |	  ,z.obsregex
     |	  ,z.datatype
     |	  ,z.begin_range
     |	  ,z.end_Range
     |	  ,z.round_prec
     |	  ,z.localunit_cui
     |	  ,z.conv_fact
     |	  ,z.function_applied
     |      ,Update_Date
     | from MED3000_PATIENT_VITALS Vit
     | inner join ZCM_OBSTYPE_CODE z
     |   on (z.groupid='{groupid}' and z.datasrc='pat_vitals' and z.obscode = Vit.Vitals_Master_Key  and z.ObsType <> 'LABRESULT')) a
     |   ) p
     |where rank_obs = 1
     |
     |)
     |where patientid is not null and obsdate is not null
     |
     |union all
     |
     |select groupid, datasrc, patientid, obsdate, localcode, obstype, local_obs_unit, std_obs_unit, obsresult, localresult, client_ds_id
     |from
     |(
     |select p.*
     |       , null as obsresult
     |  from (
     |select a.*
     |      ,row_number() over (partition by patientid,localcode,obsdate,obstype order by Update_Date desc nulls last) as rank_obs
     | from (
     |select  distinct
     |       '{groupid}'           as groupid
     |       ,'pat_hm_def'      as datasrc
     |       ,{client_ds_id}     as client_ds_id
     |       ,lower(Hm.Hum_Comment)   as localresult
     |       ,Hm.Hm_Master_Key  		as localcode
     |       ,Hm.Label_Date           as obsdate
     |       ,Hm.Blind_Key            as patientid
     |       ,z.Localunit  			as localobsunit
     |       ,z.Localunit  			as local_obs_unit
     |	   ,z.obstype_std_units 	as std_obs_unit
     |	   ,z.obstype
     |	   ,z.OBSCONVFACTOR
     |	   ,z.obsregex
     |	   ,z.datatype
     |	   ,z.begin_range
     |	   ,z.end_Range
     |	   ,z.round_prec
     |	   ,z.localunit_cui
     |	   ,z.conv_fact
     |	   ,z.function_applied
     |       ,Update_Date
     |  from MED3000_PATIENT_HM Hm
     | inner join ZCM_OBSTYPE_CODE z
     |   on (z.groupid='{groupid}' and z.datasrc='pat_hm_def' and z.obscode = Hm.Hm_Master_Key  and z.ObsType <> 'LABRESULT')
     | where (rlike(hum_comment, '(?i)decline')
     |    or rlike(hum_comment, '(?i)elsewhere')
     |    or rlike(hum_comment, '(?i)immune')
     |    or rlike(hum_comment, '(?i)refuse')
     |    or rlike(hum_comment, '(?i)defer')
     |    or rlike(hum_comment, '(?i)^not ')
     |    or rlike(hum_comment, '(?i)received at')
     |    or rlike(hum_comment, '(?i)recommend')
     |    or rlike(hum_comment, '(?i)not indicated'))) a
     |   ) p
     |where rank_obs = 1
     |
     |)
     |where patientid is not null and obsdate is not null
     |
     |union all
     |
     |select groupid, datasrc, patientid, obsdate, localcode, obstype, local_obs_unit, std_obs_unit, obsresult, localresult, client_ds_id
     |from
     |(
     |select p.*
     |       , null as obsresult
     |  from (
     |select a.*
     |      ,row_number() over (partition by patientid,localcode,obsdate,obstype order by Update_Date desc nulls last) as rank_obs
     | from (
     |select  distinct
     |       '{groupid}' 		as groupid
     |       ,'pat_hm' 		as datasrc
     |       ,{client_ds_id} 	as client_ds_id
     |       ,coalesce(lower(Hm.Hum_Comment), Hm.Yes_No_Display) 	as localresult
     |       ,Hm.Hm_Master_Key  		as localcode
     |	   ,coalesce(Hm.Label_Date, Hm.create_date) 		    as obsdate
     |       ,Hm.Blind_Key  			as patientid
     |       ,z.Localunit  			as localobsunit
     |       ,z.Localunit  			as local_obs_unit
     |	   ,z.obstype_std_units 	as std_obs_unit
     |	   ,z.obstype
     |	   ,z.OBSCONVFACTOR
     |	   ,z.obsregex
     |	   ,z.datatype
     |	   ,z.begin_range
     |	   ,z.end_Range
     |	   ,z.round_prec
     |	   ,z.localunit_cui
     |	   ,z.conv_fact
     |	   ,z.function_applied
     |       ,Update_Date
     |from MED3000_PATIENT_HM Hm
     |inner join ZCM_OBSTYPE_CODE z
     |   on (z.groupid='{groupid}' and z.datasrc='pat_hm' and z.obscode = Hm.Hm_Master_Key  and z.ObsType <> 'LABRESULT')) a
     |   ) p
     |where rank_obs = 1
     |
     |)
     |where patientid is not null and obsdate is not null
     |
     |union all
     |
     |select groupid, datasrc, patientid, obsdate, localcode, obstype, local_obs_unit, std_obs_unit, obsresult, localresult, client_ds_id
     |from
     |(
     |select p.*
     |       , null as obsresult
     |  from (
     |select a.*
     |      ,row_number() over (partition by patientid,localcode,obsdate,obstype order by Update_Date desc nulls last) as rank_obs
     | from (
     |select  distinct
     |       '{groupid}' 				as groupid
     |       ,'visit_entry_answers' 	as datasrc
     |       ,{client_ds_id} 			as client_ds_id
     |       ,Vst.Question_Result 	as localresult
     |       ,Vst.Visit_Question_Id  	as localcode
     |	   ,Vst.create_date 		as obsdate
     |       ,Vst.Blind_Key  			as patientid
     |       ,z.Localunit  			as localobsunit
     |       ,z.Localunit  			as local_obs_unit
     |	   ,z.obstype_std_units 	as std_obs_unit
     |	   ,z.obstype
     |	   ,z.OBSCONVFACTOR
     |	   ,z.obsregex
     |	   ,z.datatype
     |	   ,z.begin_range
     |	   ,z.end_Range
     |	   ,z.round_prec
     |	   ,z.localunit_cui
     |	   ,z.conv_fact
     |	   ,z.function_applied
     |       ,Update_Date
     |from MED3000_VISIT_ENTRY_ANSWERS_H Vst
     |inner join ZCM_OBSTYPE_CODE z
     |   on (z.groupid='{groupid}' and z.datasrc='visit_entry_answers' and z.obscode = Vst.Visit_Question_Id  and z.ObsType <> 'LABRESULT')) a
     |   ) p
     |where rank_obs = 1
     |
     |)
     |where patientid is not null and obsdate is not null
    """.stripMargin
}

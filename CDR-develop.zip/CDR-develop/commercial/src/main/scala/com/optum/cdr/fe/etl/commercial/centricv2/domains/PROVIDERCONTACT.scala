package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.zh_provider_contact
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object PROVIDERCONTACT extends FEQueryAndMetadata[zh_provider_contact] {

  override def name: String = "PROVIDERCONTACT"

  override def dependsOn: Set[String] = Set("PROV_CONTACT_DOCTORFACILITY","PROV_CONTACT_STAFFREG")


    override def sparkSql: String =
      """
        select * from PROV_CONTACT_DOCTORFACILITY
        |
        |UNION ALL
        |
        |select * from PROV_CONTACT_STAFFREG
      """.stripMargin

}
package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{immunization, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object IMMUNIZATION extends FETableInfo[immunization]{

  override def name: String = CDRFEParquetNames.immunization

  override def dependsOn: Set[String] = Set("INPUT_IMMUNIZATION", "REFERENCECODE", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listImmunStatus = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "IMMUN_STATUS","IMMUNIZATION","IMMUNIZATION","STATUS").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localimmunizationcd
        |       ,patientid
        |       ,admindate
        |       ,documenteddate
        |       ,encounterid
        |       ,localdeferredreason
        |       ,localimmunizationdesc
        |       ,localroute
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                                                              AS groupid
        |	       ,'immunization'                                                                                                           AS datasrc
        |	       ,{client_ds_id}                                                                                                           AS client_ds_id
        |	       ,mmn.code                                                                                                                 AS localimmunizationcd
        |	       ,mmn.unique_person_identifier                                                                                             AS patientid
        |	       ,mmn.end_date_time                                                                                                        AS admindate
        |	       ,mmn.end_date_time                                                                                                        AS documenteddate
        |	       ,mmn.unique_visit_identifier                                                                                              AS encounterid
        |	       ,CASE WHEN mmn.modifier_reason = '0' THEN NULL ELSE concat_ws('','{client_ds_id}','.',mmn.modifier_reason) END            AS localdeferredreason
        |	       ,coalesce(mmn.product_name,rfr.display)                                                                                   AS localimmunizationdesc
        |	       ,MAX(rout.description) over (partition by mmn.unique_result_identifier ORDER BY length(rout.description) desc nulls last) AS localroute
        |	FROM
        |	(
        |		SELECT  *
        |		FROM
        |		(
        |			SELECT  code
        |			       ,unique_person_identifier
        |			       ,end_date_time
        |			       ,unique_visit_identifier
        |			       ,unique_result_identifier
        |			       ,modifier_reason
        |			       ,product_name
        |			       ,route
        |			       ,row_number() over (partition by m.unique_result_identifier ORDER BY m.update_date_time desc nulls last) AS rw
        |			FROM INPUT_IMMUNIZATION m
        |			WHERE m.status not IN ({LIST_IMMUN_STATUS})
        |			AND m.code is not null
        |			AND m.unique_person_identifier is not null
        |		) mm
        |		WHERE mm.rw = 1
        |	) mmn
        |	INNER JOIN
        |	(
        |		SELECT  distinct element_code
        |		       ,display
        |		FROM REFERENCECODE
        |		WHERE field = 'CODE'
        |		AND file_name = 'IMMUNIZATION'
        |	) rfr
        |	ON (mmn.code = rfr.element_code)
        |	LEFT OUTER JOIN
        |	(
        |		SELECT  distinct element_code
        |		       ,description
        |		FROM REFERENCECODE
        |		WHERE field = 'ROUTE'
        |		AND file_name = 'IMMUNIZATION'
        |	) rout
        |	ON (mmn.route = rout.element_code )
        |)
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{LIST_IMMUN_STATUS}", listImmunStatus)
    )
  }
}

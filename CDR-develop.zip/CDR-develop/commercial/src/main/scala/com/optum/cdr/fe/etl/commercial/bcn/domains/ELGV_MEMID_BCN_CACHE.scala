package com.optum.cdr.fe.etl.commercial.bcn.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object ELGV_MEMID_BCN_CACHE extends FEQueryAndMetadata[elgv]{
  override def name: String = "ELGV_MEMID_BCN_CACHE"

  override def dependsOn: Set[String] = Set("ELGV")

  override def sparkSql: String =
    """
      |with excl_memid_bcn_elgv as(
      |    SELECT  distinct concat_ws('',a.subscriber_id,'-',ltrim('0',a.member_suffix)) mem_id
      |    FROM elgv a
      |    JOIN elgv b
      |    ON (concat_ws('',a.subscriber_id,'-',ltrim('0',a.member_suffix)) = concat_ws('',b.subscriber_id,'-',ltrim('0',b.member_suffix)))
      |    WHERE a.first_name <> b.first_name
      |    AND a.birth_date <> b.birth_date
      |)
      |
      |SELECT  *
      |FROM elgv m
      |WHERE subscriber_id is not null
      |AND member_suffix is not null
      |AND not exists (
      |    SELECT  1
      |    FROM excl_memid_bcn_elgv
      |    WHERE mem_id = concat_ws('',m.subscriber_id,'-',ltrim('0',m.member_suffix))
      |)
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.rx_patient_reported
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object RX_PATIENT_REPORTED extends FEQueryAndMetadata[rx_patient_reported]{

  override def name: String = CDRFEParquetNames.rx_patient_reported

  override def dependsOn: Set[String] = Set("ITEM_DETAIL_MEDICATIONS_TB", "ZH_DATES_TB", "ZH_TIMES_TB", "EVENTS_VW", "PATIENT_FAC_GRP_SEG_TB", "MECCA_TERM_DETAILS_TB")

  override def sparkSql: String =

  """
    |with dedup_query as
    |  (
    |  select * from (
    |  select
    |     IDM.MECTRMDTL_ID, IDM.ACTION_VALUE_ID, IDM.Dose_Value_Desc, item_id
    |    , case when idm.dose_load_value_desc <> '*Not Available' then idm.dose_units_value_desc else idm.dispunit_value_desc end as localform
    |    ,IDM.Item_Id AS reportedmedid
    |    ,IDM.Action_Value_Id AS localcategorycode
    |    ,case when (IDM.Qty_Units_Value_Id = '0' or IDM.Qty_Units_Value_Desc = '*Not Available')
    |       then null
    |       else IDM.Qty_Units_Value_Desc
    |     end AS localdoseunit
    |    ,IDM.Event_Id AS encounterid
    |
    |    ,case when IDM.Route_Value_Id = '0' then null else IDM.Route_Value_desc end as localroute
    |    ,case when idm.dose_load_value_desc <> '*Not Available' then nullif(regexp_extract(idm.DOSE_LOAD_VALUE_DESC,'^[-.,/0-9]+', 0), '') else nullif(regexp_extract(idm.disp_drug_value_desc,'^[-.,/0-9]+', 0), '') end as localstrengthperdoseunit
    |    ,case when idm.dose_load_value_desc <> '*Not Available' then nullif(regexp_extract(idm.DOSE_LOAD_VALUE_DESC,'[a-zA-Z%]+([-/][ .0-9a-zA-Z%]+)?', 0), '')  else nullif(regexp_extract(idm.disp_drug_value_desc,'[a-zA-Z%]+([-/][ .0-9a-zA-Z%]+)?', 0), '')  end as localstrengthunit
    |    ,case when DAILY_LOAD_VALUE_ID = '0' then null else nullif(regexp_extract(DAILY_LOAD_VALUE_DESC, '(\\S*)', 0), '') end as localtotaldose
    |    ,SAFE_TO_DATE(concat_ws('', date_format(ZDT.DATE_ORACLE,'yyyy-MM-dd'), ' ', ZTT.FORMATTED_MILITARY_TIME), 'yyyy-MM-dd HH:mm') AS medreportedtime
    |    ,case when ACTION_VALUE_ID ='12' then SAFE_TO_DATE(concat_ws('', date_format(ZDT.DATE_ORACLE,'yyyy-MM-dd'), ' ', ZTT.FORMATTED_MILITARY_TIME), 'yyyy-MM-dd HH:mm') else null end
    |as discontinueDate
    |    ,case when IDM.Dose_Value_Id = '0' then null else IDM.Dose_Value_Desc end AS localqtyofdoseunit
    |    ,row_number() over (partition by IDM.Mectrmdtl_Id order by concat_ws('', date_format(ZDT.DATE_ORACLE,'yyyy-MM-dd'), ' ', ZTT.FORMATTED_MILITARY_TIME) desc nulls last ) as rownumber
    |  from ITEM_DETAIL_MEDICATIONS_TB IDM
    |  INNER JOIN ZH_DATES_TB ZDT ON ( ZDT.DATES_ID = IDM.CREATION_DATES_ID)
    |  INNER JOIN ZH_TIMES_TB ZTT ON ( ZTT.TIME_ID = IDM.CREATION_TIME_ID  )
    |
    |  ) where rownumber = 1  )
    |select groupid, datasrc, client_ds_id, localform, reportedmedid, localcategorycode, localdoseunit, encounterid, localroute, localstrengthperdoseunit, localstrengthunit, localtotaldose, discontinueDate, MedreportedTime, localqtyofdoseunit, patientid, facilityid, localproviderid, localdrugdescription, localmedcode
    |from
    |(
    |SELECT
    |   distinct '{groupid}' as groupid,'item_detail_medications_tb' as datasrc
    |  ,{client_ds_id} as client_ds_id
    |  ,IDM.MECTRMDTL_ID
    |  ,IDM.localform
    |  ,IDM.reportedmedid
    |  ,IDM.localcategorycode
    |  ,IDM.localdoseunit
    |  ,IDM.encounterid
    |  ,IDM.localroute
    |  ,IDM.localstrengthperdoseunit
    |  ,IDM.localstrengthunit
    |  ,IDM.localtotaldose
    |  ,IDM.discontinueDate
    |  ,IDM.MedreportedTime
    |  ,localqtyofdoseunit
    |  ,EVE.Patient_Id AS patientid
    |  ,EVE.Facility_Num AS facilityid
    |  ,EVE.Provider_Id AS localproviderid
    |  ,MTD.Term_Desc AS localdrugdescription
    |  ,MTD.Mectrm_Id AS localmedcode
    |FROM DEDUP_QUERY IDM
    |INNER JOIN EVENTS_VW EVE ON (EVE.EVENT_ID = IDM.ENCOUNTERID)
    |INNER JOIN PATIENT_FAC_GRP_SEG_TB PFG ON (EVE.PATIENT_ID = PFG.PATIENT_ID)
    |INNER JOIN MECCA_TERM_DETAILS_TB MTD ON (MTD.MECTRMDTL_ID = IDM.MECTRMDTL_ID)
    |WHERE ACTION_VALUE_ID NOT IN('18','52')
    |AND ACTION_VALUE_ID IN('10','12')
    |AND IDM.Item_Id is not null
    |
    |)
  """
  .stripMargin

}

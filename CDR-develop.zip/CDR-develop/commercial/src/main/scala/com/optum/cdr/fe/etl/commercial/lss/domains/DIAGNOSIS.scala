package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object DIAGNOSIS extends FEQueryAndMetadata[diagnosis]{

  override def name: String = CDRFEParquetNames.diagnosis

  override def dependsOn: Set[String] = Set("LSS_PBRACCOUNTTRANSACTIONDIAGNOSES", "LSS_PBRACCOUNTS", "LSS_PBRACCOUNTTRANSACTIONS")

  override def sparkSql: String =
    """
      |with diag as (
      |   select *
      |     , stack(12, Primarydiagcode, '1', Seconddiagcode, '0', Thirddiagcode, '0', Fourthdiagcode, '0', Fifthdiagcode, '0'
      |       , Sixthdiagcode, '0', Seventhdiagcode, '0', Eigthdiagcode, '0', Ninthdiagcode, '0', Tenthdiagcode, '0'
      |       , Eleventhdiagcode, '0', Twelfthdiagcode, '0') as (diagnosis, PrimaryDiag)
      |   from LSS_PBRACCOUNTTRANSACTIONDIAGNOSES
      |),
      |diag_pivot as
      |(
      |   select sourceid, accountid, transactionid, diagnosis
      |     , PrimaryDiag as PrimaryDiagCode, RowUpdateDateTime
      |   from diag
      |   where diagnosis is not null
      |),
      |act as (
      |   select z.*
      |      ,row_number () over ( Partition by SourceID, AccountID order by RowUpdateDateTime desc nulls first, PatientID desc nulls first) as act_rownumber
      |   from   LSS_PBRACCOUNTS z
      |),
      |act_qry as (
      |     select *
      |     from act
      |     where act_rownumber = 1
      |),
      |act_trans as (
      |     select z.*
      |        ,row_number () over ( Partition by SourceID, AccountID, transactionId order by RowUpdateDateTime desc nulls first, FIleID desc nulls first) as act_trans_rownumber
      |     from   LSS_PBRACCOUNTTRANSACTIONS z
      |),
      |act_trans_qry as (
      |     select *
      |     from act_trans
      |     where act_trans_rownumber = 1
      |)
      |select datasrc,encounterid,patientid,localdiagnosis,mappeddiagnosis,primarydiagnosis,localdiagnosisproviderid,dx_timestamp,facilityid
      |from (
      |     select x.*
      |         ,row_number() over (partition by PatientID, EncounterID, dx_timestamp, LocalDiagnosis order by RowUpdateDateTime desc nulls first) as rownumber
      |     from (
      |         SELECT 'pbraccounttransactiondiagnoses' as datasrc
      |             ,tr.Servicedatetime AS dx_timestamp
      |             ,pbr.diagnosis AS localdiagnosis
      |             ,CONCAT_WS('', pbr.sourceid, act.patientid) AS patientid
      |             ,CONCAT_WS('', pbr.Sourceid, tr.Providerid) AS localdiagnosisproviderid
      |             ,CONCAT_WS('', pbr.sourceid, pbr.accountid, tr.locationid, UPPER(DATE_FORMAT(tr.ServiceDateTime, 'dd-MMM-yy'))) AS encounterid
      |             ,pbr.PrimaryDiagCode AS primarydiagnosis
      |             ,pbr.diagnosis AS mappeddiagnosis
      |             ,pbr.RowUpdateDateTime
      |             ,tr.locationid as facilityid
      |         FROM diag_pivot pbr
      |         INNER JOIN act_qry act ON (pbr.sourceid=act.sourceid and pbr.accountid=act.accountid)
      |         INNER JOIN act_trans_qry tr ON (pbr.sourceid=tr.sourceid and pbr.accountid=tr.accountid and pbr.transactionid=tr.transactionid)
      |         WHERE tr.Servicedatetime is not null
      |               AND PatientId is not null
      |     ) x
      |) where rownumber=1
      |
    """.stripMargin
}

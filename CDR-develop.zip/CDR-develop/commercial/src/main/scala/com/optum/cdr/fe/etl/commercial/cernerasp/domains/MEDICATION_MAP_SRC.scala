package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC extends FETableInfo[medication_map_src]{

  override def name: String = CDRFEParquetNames.medication_map_src

  override def dependsOn: Set[String] = Set("MEDICATION_MAP_SRC_ALLERGY", "MEDICATION_MAP_SRC_MEDICATIONS", "MEDICATION_MAP_SRC_ORDERS", "MEDICATION_MAP_SRC_MEDICATIONRECONCILIATION", "MEDICATION_MAP_SRC_IMMUNIZATION")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |select * from MEDICATION_MAP_SRC_ALLERGY
        |union all
        |select * from MEDICATION_MAP_SRC_MEDICATIONS
        |union all
        |select * from MEDICATION_MAP_SRC_ORDERS
        |union all
        |select * from MEDICATION_MAP_SRC_MEDICATIONRECONCILIATION
        |union all
        |select * from MEDICATION_MAP_SRC_IMMUNIZATION
        |""".stripMargin
    )
  }
}

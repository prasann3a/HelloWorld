package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object RXORDER extends FEQueryAndMetadata[rxorder]{

  override def name: String = CDRFEParquetNames.rxorder

  override def dependsOn: Set[String] = Set("RXORDER_ITEM_DETAIL_MEDICATIONS_TB", "RXORDER_MED_EVENTS_TB")

  override def sparkSql: String =

  """
    |select * from RXORDER_ITEM_DETAIL_MEDICATIONS_TB
    |
    |union all
    |
    |select * from RXORDER_MED_EVENTS_TB
  """
  .stripMargin

}

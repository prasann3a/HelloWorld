package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.etl.commercial.mckesson_labresult_cache
import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE_1 extends FETableInfo[mckesson_labresult_cache]{
  override def name: String = "LABRESULT_CACHE_1"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_CCDBA_PAT_RESULTS","MCKESSON_CCDBA_ANC_RESULTS","MCKESSON_ENT_PATIENT","MCKESSON_CCDBA_ANC_ORDER","MCKESSON_ZH_CCDEV_ANC_RES_CODE_SEQS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val srcSysList = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_PAT_RESULTS", "LABRESULTS", "CCDBA_PAT_RESULTS", "SOURCE_SYSTEM").mkString(",")
    val codeSysList = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "ZH_CCDEV_ANC_RES_CODE_SEQS", "LABMAPPERDICT", "ZH_CCDEV_ANC_RES_CODE_SEQS", "CODING_SYSTEM").mkString(",")


    sparkSession.sql(
      s"""
         |WITH uni_pat AS
         |(SELECT * FROM
         |(SELECT  p.*, ROW_NUMBER() OVER (PARTITION BY result_seq ORDER BY perform_ddt DESC NULLS LAST) rn
         | FROM MCKESSON_CCDBA_PAT_RESULTS p
         | WHERE source_system IN ({src_sys_list})
         |   AND Result_Seq IS NOT NULL
         |   AND Perform_Ddt IS NOT NULL )
         | WHERE rn = 1),
         |uni_anc AS
         |(SELECT * FROM (
         | SELECT a.*, ROW_NUMBER() OVER (PARTITION BY result_seq ORDER BY pat_results_perform_ddt DESC NULLS LAST) rn
         | FROM MCKESSON_CCDBA_ANC_RESULTS a
         |  )
         | WHERE rn = 1),
         |uni_ent_pat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST, record_version DESC nulls first) rn
         |       FROM MCKESSON_ENT_PATIENT p
         |       WHERE Cpi_Seq IS NOT NULL )
         |) WHERE rn = 1),
         |ORDERS as
         |(Select * from
         |(Select O_Occur_Seq, Order_Ddt, Specimen_Src, Row_Number() Over (Partition By O_Occur_Seq Order By Order_Ddt Desc Nulls Last) As Rn
         |From MCKESSON_CCDBA_ANC_ORDER
         | )
         |Where Rn = 1
         |And date_format(Order_Ddt, 'yyyy') <> '1800' ),
         |zh AS
         | (SELECT  * FROM MCKESSON_ZH_CCDEV_ANC_RES_CODE_SEQS
         |   WHERE coding_system IN ({code_sys_list}) )
         |SELECT t.*, safe_to_number(localresult) AS localresult_numeric
         |FROM
         |(
         |SELECT
         |'{groupid}' AS groupid
         |,'ccdba_pat_results' AS datasrc
         |,{client_ds_id} AS client_ds_id
         |,uni_pat.Result_Seq AS labresultid
         |,uni_pat.Label_Seq  AS localcode
         |,CASE WHEN uni_pat.data_type = 'TWO_NUMBERS' THEN uni_pat.result_value
         |      ELSE COALESCE(uni_pat.result_number_1, uni_pat.result_value) END AS localresult
         |,uni_ent_pat.Cpi_Seq AS patientid
         |,uni_pat.Perform_Ddt AS datecollected
         |,Orders.Order_Ddt    AS labordereddate
         |,Orders.Specimen_Src   As Localspecimentype
         |,uni_pat.Perform_Ddt AS dateavailable
         |,uni_pat.pat_seq     AS encounterid
         |,NULL 		     AS facilityid
         |,UNI_ANC.O_OCCUR_SEQ   AS laborderid
         |,zh.result_lname     AS localname
         |,zh.test_name        AS localtestname
         |,COALESCE(zh.result_units,uni_pat.units) AS localunits
         |,uni_anc.normal_range AS normalrange
         |,CASE WHEN uni_anc.abnormal_ind IS NOT NULL THEN 'Abnormal' ELSE NULL END AS resulttype
         |,uni_anc.Status_Desc  AS statuscode
         |,uni_pat.Perform_Ddt  AS labresult_date
         |,ROW_NUMBER() OVER (PARTITION BY uni_pat.Result_Seq
         |                    ORDER BY uni_pat.perform_ddt DESC NULLS LAST) res_row
         |FROM UNI_PAT
         |    JOIN UNI_ENT_PAT ON (uni_pat.pat_seq = uni_ent_pat.pat_seq)
         |    JOIN ZH ON (uni_pat.label_seq = zh.result_label_seq)
         |    LEFT OUTER JOIN UNI_ANC ON (uni_pat.result_seq = uni_anc.result_seq)
         |    Left Join ORDERS On (Uni_Anc.O_Occur_Seq = Orders.O_Occur_Seq)
         |  ) t
         |
       """.stripMargin
    .replace("{groupid}",groupId)
    .replace("{client_ds_id}",clientDsId)
    .replace("{src_sys_list}",srcSysList)
    .replace("{code_sys_list}",codeSysList))

  }


}

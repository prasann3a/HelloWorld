package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.cdr.models.prov_pat_rel
import com.optum.oap.sparkdataloader.CDRFEParquetNames

object PROVIDERPATIENTRELATION extends FEQueryAndMetadata[prov_pat_rel]{
  override def name: String = CDRFEParquetNames.prov_pat_rel

  override def dependsOn: Set[String] = Set("ENT_STAFF_ASSIGN","MCKESSON_ENT_PATIENT")

  override def sparkSql: String =
    """
      |select distinct datasrc, providerid, patientid, localrelshipcode, startdate, enddate
      |from
      |(
      |SELECT 'ent_staff_assign' AS datasrc
      |,a.staff_seq  	    AS providerid
      |,p.cpi_seq  	    AS patientid
      |,'PCP'		    AS localrelshipcode
      |,a.start_dt         AS startdate
      |,NULL               AS enddate
      |,ROW_NUMBER() OVER (PARTITION BY a.staff_seq, p.pat_seq, a.start_dt
      |                    ORDER BY a.modified_dt DESC NULLS LAST) rn
      |FROM ENT_STAFF_ASSIGN a
      |     LEFT OUTER JOIN MCKESSON_ENT_PATIENT p ON (p.pat_seq = a.pat_seq)
      |WHERE p.cpi_seq IS NOT NULL
      |  AND a.staff_seq IS NOT NULL
      |  AND a.start_dt IS NOT NULL
      |  AND a.care_reln_code = 'PCMD'
      |
      |)
      |where rn = 1
    """.stripMargin
}

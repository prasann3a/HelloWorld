package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{claim, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object CLAIM extends FETableInfo[claim]{

  override def name: String = CDRFEParquetNames.claim

  override def dependsOn: Set[String] = Set("EDI_INVOICE", "EDI_INV_CPT", CDRFEParquetNames.clinicalencounter, "ZH_ITEMDETAIL", "BILLINGDATA", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val listResultConcat = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "EDI_INV_CPT", "CLAIM",
      "EDI_INV_CPT", "POS").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH dedup_inv AS (
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  i.*
        |					,ROW_NUMBER() OVER (PARTITION BY id ORDER BY modifydate DESC nulls last) rn
        |		FROM EDI_INVOICE i
        |		WHERE deleteflag <> '1'
        |	)
        |	WHERE rn = 1
        |),
        |dedup_cpt AS (
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  c.*
        |					,concat_ws('',c.invoiceid,'.',c.id)                                                                          AS sourceid
        |					,COALESCE(nullif(regexp_extract(revcodeid,'([0-9])+',0),''),nullif(regexp_extract(revcode,'([0-9])+',0),'')) AS rev_code
        |					,ROW_NUMBER() OVER (PARTITION BY id,invoiceid ORDER BY modifieddate DESC nulls last) rn
        |		FROM EDI_INV_CPT c
        |	)
        |	WHERE rn = 1
        |	AND deleteflag <> '1'
        |),
        |uni_billing AS (
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  b.*
        |					,ROW_NUMBER() OVER (PARTITION BY id ORDER BY modifieddate DESC NULLS LAST) rn
        |		FROM BILLINGDATA b
        |		WHERE Id IS NOT NULL
        |		AND deleteflag <> '1'
        |	)
        |	WHERE rn = 1
        |)
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,claimid
        |       ,patientid
        |       ,encounterid
        |       ,servicedate
        |       ,quantity
        |       ,localcpt
        |       ,mappedcpt
        |       ,sourceid
        |       ,seq
        |       ,localcptmod1
        |       ,localcptmod2
        |       ,localcptmod3
        |       ,localcptmod4
        |       ,mappedcptmod1
        |       ,mappedcptmod2
        |       ,mappedcptmod3
        |       ,mappedcptmod4
        |       ,localrev
        |       ,mappedrev
        |       ,charge
        |       ,pos
        |       ,claimproviderid
        |FROM
        |(
        |	SELECT  '{groupid}'                                                         AS groupid
        |	       ,'edi_inv_cpt'                                                       AS datasrc
        |	       ,{client_ds_id}                                                      AS client_ds_id
        |	       ,dedup_cpt.Id                                                        AS claimid
        |	       ,dedup_inv.Patientid                                                 AS patientid
        |	       ,dedup_cpt.Sdos                                                      AS servicedate
        |	       ,dedup_cpt.Mod1                                                      AS mappedcptmod1
        |	       ,dedup_cpt.Mod2                                                      AS mappedcptmod2
        |	       ,dedup_cpt.Mod3                                                      AS mappedcptmod3
        |	       ,dedup_cpt.Mod4                                                      AS mappedcptmod4
        |	       ,dedup_cpt.Billedfee                                                 AS charge
        |	       ,dedup_cpt.Rendpruserid                                              AS claimproviderid
        |	       ,Zh_Itemdetail.Value                                                 AS mappedcpt
        |	       ,dedup_inv.Encounterid                                               AS encounterid
        |	       ,CASE WHEN dedup_cpt.rev_code = '0' THEN NULL
        |	             WHEN LENGTH(dedup_cpt.rev_code) = 3 THEN coalesce(dedup_cpt.revcodeid,dedup_cpt.revcode)
        |	             WHEN LENGTH(dedup_cpt.rev_code) = 4 THEN coalesce(dedup_cpt.revcodeid,dedup_cpt.revcode)
        |	             WHEN LENGTH(dedup_cpt.rev_code) > 4 THEN null ELSE NULL END    AS localrev
        |	       ,CASE WHEN dedup_cpt.rev_code = '0' THEN NULL
        |	             WHEN LENGTH(dedup_cpt.rev_code) = 3 THEN LPAD(dedup_cpt.rev_code,4,'0')
        |	             WHEN LENGTH(dedup_cpt.rev_code) = 4 THEN rev_code
        |	             WHEN LENGTH(dedup_cpt.rev_code) > 4 THEN NULL ELSE NULL END    AS mappedrev
        |	       ,coalesce(dedup_cpt.code,Zh_Itemdetail.value)                        AS localcpt
        |	       ,dedup_cpt.Mod1                                                      AS localcptmod1
        |	       ,dedup_cpt.Mod2                                                      AS localcptmod2
        |	       ,dedup_cpt.Mod3                                                      AS localcptmod3
        |	       ,dedup_cpt.Mod4                                                      AS localcptmod4
        |	       ,CASE WHEN {list_result_concat}='Y' THEN dedup_cpt.pos ELSE null END AS pos
        |	       ,dedup_cpt.Units                                                     AS quantity
        |	       ,dedup_cpt.Displayindex                                              AS seq
        |	       ,concat_ws('',dedup_inv.Patientid,'.',dedup_cpt.sourceid)            AS sourceid
        |	FROM DEDUP_INV
        |	JOIN {CLINICALENCOUNTER} enc
        |		ON (dedup_inv.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
        |	JOIN DEDUP_CPT
        |		ON (dedup_inv.id = dedup_cpt.invoiceid)
        |	LEFT OUTER JOIN ZH_ITEMDETAIL
        |		ON (dedup_cpt.ItemID = Zh_Itemdetail.ItemID AND Zh_ItemDetail.PropID = '13')
        |	WHERE coalesce(dedup_cpt.code, Zh_Itemdetail.value) is not null
        |	AND 1=1
        |)
        |WHERE servicedate IS NOT NULL
        |
        |UNION ALL
        |
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,claimid
        |       ,patientid
        |       ,encounterid
        |       ,servicedate
        |       ,quantity
        |       ,localcpt
        |       ,mappedcpt
        |       ,Sourceid
        |       ,seq
        |       ,localcptmod1
        |       ,localcptmod2
        |       ,localcptmod3
        |       ,localcptmod4
        |       ,null as mappedcptmod1
        |       ,null as mappedcptmod2
        |       ,null as mappedcptmod3
        |       ,null as mappedcptmod4
        |       ,null as localrev
        |       ,null as mappedrev
        |       ,null as charge
        |       ,null as pos
        |       ,null as claimproviderid
        |FROM
        |(
        |	SELECT  '{groupid}'      AS groupid
        |	       ,'billingdata'    AS datasrc
        |	       ,{client_ds_id}   AS client_ds_id
        |	       ,bll.Id           AS claimid
        |	       ,enc.Patientid    AS patientid
        |	       ,enc.Arrivaltime  AS servicedate
        |	       ,ziz.Value        AS mappedcpt
        |	       ,bll.Encounterid  AS encounterid
        |	       ,ziz.Value        AS localcpt
        |	       ,bll.Units        AS quantity
        |	       ,bll.Displayindex AS seq
        |	       ,bll.Encounterid  AS Sourceid
        |	       ,bll.Mod1         AS localcptmod1
        |	       ,bll.Mod2         AS localcptmod2
        |	       ,bll.Mod3         AS localcptmod3
        |	       ,bll.Mod4         AS localcptmod4
        |	FROM UNI_BILLING bll
        |	JOIN {CLINICALENCOUNTER} enc
        |	    ON (bll.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
        |	LEFT OUTER JOIN ZH_ITEMDETAIL ziz
        |	    ON (bll.itemid = ziz.itemid AND ziz.propid = '13')
        |	WHERE ziz.Value is not null
        |	AND 1=1
        |)
        |WHERE servicedate IS NOT NULL
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{list_result_concat}", listResultConcat)
    )
  }
}

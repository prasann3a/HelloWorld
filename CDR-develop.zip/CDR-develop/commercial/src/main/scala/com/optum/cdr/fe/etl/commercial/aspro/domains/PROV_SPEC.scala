package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.prov_spec
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROV_SPEC extends FEQueryAndMetadata[prov_spec]{

override def name: String = CDRFEParquetNames.prov_spec

override def dependsOn: Set[String] = Set("ZH_PROVIDERS")

override def sparkSql: String =
  """
    |SELECT  GROUPID
    |       ,LOCALPROVIDERID
    |       ,LOCALSPECIALTYCODE
    |       ,LOCALCODESOURCE
    |       ,CLIENT_DS_ID
    |       ,LOCAL_CODE_ORDER
    |FROM
    |(
    |	SELECT  distinct '{groupid}' as GROUPID
    |	       ,p.Imreprov_code as LOCALPROVIDERID
    |	       ,p.prov_specialty as LOCALSPECIALTYCODE
    |	       ,'zh_provider' as LOCALCODESOURCE
    |	       ,'{client_ds_id}' as CLIENT_DS_ID
    |	       ,1 as LOCAL_CODE_ORDER
    |	FROM ZH_PROVIDERS p
    |	WHERE p.prov_specialty is not null
    |)
  """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.huamana.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.int_claim_pharm
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_PHARM extends FETableInfo[int_claim_pharm] {

  override def name: String = CDRFEParquetNames.int_claim_pharm

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def dependsOn: Set[String] = Set("RECLMEXP","RECLMDSP","RECLM627","REPRX","ZO_BPO_MAP_EMPLOYER","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    val groupIdConstant="{groupid}"
    val clientDsIdConstant="{client_ds_id}"

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val ismdsp = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "OLD_TABLE", "INT_CLAIM_PHARM", "INT_CLAIM_PHARM", "INT_CLAIM_PHARM").mkString(",")

    if (ismdsp.equals("'Y'")) {

      val df1mdsp = sparkSession.sql(
        s"""
           |with ll_627 as
           |(
           |  select fileid, max(transact_date) as transact_date ,max(staged_dt_tm) as load_date
           |  from RECLM627 group by fileid
           | )
           | ,ll_dsp as
           | (
           |  select fileid, max(transact_date) as transact_date, max(staged_dt_tm) as load_dat
           |  from RECLMDSP group by fileid
           |  )
           | ,ll_prx as
           | (
           | select fileid, max(transact_date) as transact_date ,max(staged_dt_tm) as load_date
           |  from REPRX group by fileid
           | ),
           | dedup_reclm627 as (
           |select   *
           |from (
           |        select row_number() over (partition by concat_ws('', mbr_pid, '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', ndc_nbr, '_', safe_to_number(pres_qty))
           |               order by coalesce(ll.transact_date,ll.load_date) desc nulls last, ll.fileid desc nulls first) as rank
           |               ,concat_ws('', p.mbr_pid, '_', upper(date_format(p.srv_frm_dt, 'dd-MMM-yy')), '_', p.ndc_nbr, '_', safe_to_number(p.pres_qty)) as Reclm627_joinid
           |               ,concat_ws('', p.mem_umid, '_', upper(date_format(p.srv_frm_dt, 'dd-MMM-yy')), '_', p.ndc_nbr, '_', round(safe_to_number(p.pres_qty))) as Reclm627_Reprx_joinid
           |               ,p.*
           |        from RECLM627 p
           |        inner join ll_627 ll on p.fileid=ll.fileid
           |        where lr_ind in ('B','L') and (claim_ind is null or claim_ind in ('+','@'))
           |    )
           |   where rank=1
           |
           |)
           |,dedup_reprx as (
           |select  *
           |from (
           |        select row_number() over (partition by concat_ws('', mem_umid, lpad(mbr_suffix,2,'0'), '_', upper(date_format(service_dt, 'dd-MMM-yy')), '_', prod_id, '_', safe_to_number(met_dec_qt))
           |               order by coalesce(ll.transact_date,ll.load_date) desc nulls last, ll.fileid desc nulls first) as rank
           |               ,concat_ws('', r.mem_umid, lpad(r.mbr_suffix,2,'0'), '_', upper(date_format(r.service_dt, 'dd-MMM-yy')), '_', r.prod_id, '_', round(safe_to_number(r.met_dec_qt))) as Reprx_joinid
           |               ,r.*
           |        from REPRX r
           |        inner join ll_prx ll on r.fileid=ll.fileid
           |     )
           |     where rank=1
           |)
           |,T_Reclmdsp as (
           |select
           | case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then
           |      concat_ws('', e.mbr_pid,'_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.ndc_nbr, '_', safe_to_number(e.rx_qty))
           |    else
           |        concat_ws('', e.mbr_pid, '00', '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.ndc_nbr, '_', safe_to_number(e.rx_qty))
           |     end as reclmdsp_joinid
           |       ,e.* from RECLMDSP e
           |       inner join ll_dsp ll on e.fileid=ll.fileid
           |
           |)
           |,R1_reprx as (
           |select
           |        concat_ws('', r1.mem_umid, lpad(r1.mbr_suffix,2,'0'), '_', upper(date_format(r1.service_dt, 'dd-MMM-yy')), '_', r1.prod_id, '_', round(safe_to_number(r1.met_dec_qt))) as Reprx_joinid_R1
           |       ,r1.* from DEDUP_RECLM627 dr
           |       left outer join REPRX r1 on (dr.Reclm627_Reprx_joinid = concat_ws('', r1.mem_umid, lpad(r1.mbr_suffix,2,'0'), '_', upper(date_format(r1.service_dt, 'dd-MMM-yy')), '_', r1.prod_id, '_', round(safe_to_number(r1.met_dec_qt))))
           |       where NOT EXISTS (select 1 from T_Reclmdsp t where t.reclmdsp_joinid = dr.reclm627_joinid)
           |)
           |
             |
             |
             |select groupid, datasrc, client_ds_id, CLAIM_ID, CONTRACT_ID, DAYS_SUPPLY, MEMBER_ID, METRIC_QUANTITY, NDC_NAME, NDC, QUANTITY_PER_FILL, RX_ID, SERVICE_DATE, ALLOWED_AMOUNT, PAYMENT_AMOUNT, REQUESTED_AMOUNT, ENCOUNTERID, GENERIC_STATUS, LOCALDAW, PAY_PROCESS_DATE, PRESC_PROV_FNAME, PRESC_PROV_ID, PRESC_PROV_LNAME, PRESC_PROV_NPI
           |from
           |(
           |Select
           | '{groupid}'		              as groupid
           |,'RECLM627' 			      as datasrc
           |,{client_ds_id}         	              as client_ds_id
           |,concat_ws('', p.Mbr_Pid, '_', upper(date_format(p.Srv_Frm_Dt, 'dd-MMM-yy')), '_', p.Ndc_Nbr, '_', round(safe_to_number(p.Pres_Qty))) as CLAIM_ID
           |,bme.employeraccountid 		      as CONTRACT_ID
           |,case
           |when coalesce(safe_to_number(e.Act_Pd_Amt),safe_to_number(r1.Tot_Paid_A)) < 0 then safe_to_number(r.Plan_Ds) * -1
           |else safe_to_number(r.Plan_Ds) end as DAYS_SUPPLY
           |,p.mbr_pid as MEMBER_ID
           |,case
           |when coalesce(safe_to_number(e.act_pd_amt),safe_to_number(r1.tot_paid_a)) < 0
           |     then coalesce(safe_to_number(r.met_dec_qt),safe_to_number(p.pres_qty)) * -1
           |     else coalesce(safe_to_number(r.met_dec_qt),safe_to_number(p.pres_qty)) end as METRIC_QUANTITY
           |,r.drug_name               as NDC_NAME
           |,lpad(p.ndc_nbr,11,'0')    as NDC
           |,case
           |when coalesce(safe_to_number(e.act_pd_amt),safe_to_number(r1.tot_paid_a)) < 0
           |     then coalesce(safe_to_number (r.met_dec_qt),safe_to_number(p.pres_qty)) * -1
           |     else coalesce(safe_to_number (r.met_dec_qt),safe_to_number(p.pres_qty)) end as QUANTITY_PER_FILL
           |,p.Pres_Nbr                as RX_ID
           |,p.Srv_Frm_Dt              as SERVICE_DATE
           |,nvl2(e.Bsched_Amt,safe_to_number(e.Bsched_Amt),0)   as ALLOWED_AMOUNT
           |,NVL2 ( coalesce(safe_to_number(e.Act_Pd_Amt),safe_to_number(r1.Tot_Paid_A)),
           |        coalesce(safe_to_number(e.Act_Pd_Amt),safe_to_number(r1.Tot_Paid_A)), 0 )  as PAYMENT_AMOUNT
           |,nvl2(e.Chrg_Amt,safe_to_number(e.Chrg_Amt),0)         as REQUESTED_AMOUNT
           |,concat_ws('', p.Mbr_pid, '_', upper(date_format(p.Srv_Frm_Dt, 'dd-MMM-yy')), '_', p.Ndc_Nbr, '_', round(safe_to_number(p.Pres_Qty))) as ENCOUNTERID
           |,Case when p.Gen_Ind = 'G' then 'Y' else p.Gen_Ind end as GENERIC_STATUS
           |,r.Daw_Cd                              as LOCALDAW
           |,coalesce(e.Proc_Date,r1.Sf_Proc_Dt)   as PAY_PROCESS_DATE
           |,r.Pres_Fstnm                          as PRESC_PROV_FNAME
           |,coalesce(p.Pres_Id, r.Pres_Npi_N)     as PRESC_PROV_ID
           |,r.Pres_Lstnm                          as PRESC_PROV_LNAME
           |,coalesce(p.pres_id, r.pres_npi_n)     as PRESC_PROV_NPI
           |from DEDUP_RECLM627 p
           |cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
           |left outer join T_Reclmdsp e on (e.reclmdsp_joinid = p.Reclm627_joinid) and (e.claim_type = 'R' and e.claim_ind in ('+','@'))
           |left outer join DEDUP_REPRX r on (r.Reprx_joinid = p.Reclm627_Reprx_joinid)
           |left outer join R1_REPRX r1 on (r1.Reprx_joinid_R1 = p.Reclm627_Reprx_joinid)
           |
             |
             |)
       """.stripMargin
          .replace(groupIdConstant, loaderVars.groupId)
          .replace(clientDsIdConstant, clientDsId)


      )

      val df2mdsp =  sparkSession.sql(
        """
          |with ll_dsp as
          |(
          |select
          |   fileid, max(transact_date) as transact_date, max(staged_dt_tm) as load_date
          |from RECLMDSP group by fileid
          |),
          |ll_prx as
          |(
          | select
          |  fileid, max(transact_date) as transact_date, max(staged_dt_tm) as load_date
          |from REPRX group by fileid
          |),
          | T_Reclm627 as (
          |select
          |concat_ws('', Mbr_pid, '_', upper(date_format(Srv_Frm_Dt, 'dd-MMM-yy')), '_', Ndc_Nbr, '_', safe_to_number(Pres_Qty)) AS Reclm627_T from RECLM627
          |
          |)
          |
          |,T_Reclmdsp as (
          |Select
          | case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then
          |   concat_ws('', e.Mbr_Pid,'_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', safe_to_number(e.Rx_Qty))
          | else
          |   concat_ws('', e.Mbr_Pid, '00', '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', safe_to_number(e.Rx_Qty))
          | end as Reclmdsp_joinid
          |,concat_ws('', e.Mem_Umid, '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', round(safe_to_number(e.Rx_Qty))) as Reclmdsp_Reprx_joinid
          |, case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then
          |   e.Mbr_Pid
          |   else concat_ws('', e.Mbr_Pid, '00') end as memb_id
          |,e.*
          |from RECLMDSP e
          |inner join ll_dsp ll on e.fileid=ll.fileid
          |where e.Claim_Type in ('R') and (e.Claim_Ind is null or e.Claim_Ind in ('+','@'))
          |)
          |
          |,dedup_reprx as (
          |select  *
          |from (
          |      select row_number() over (partition by concat_ws('', mem_umid, lpad(mbr_suffix,2,'0'), '_', upper(date_format(service_dt, 'dd-MMM-yy')), '_', prod_id, '_', safe_to_number(met_dec_qt))
          |      order by coalesce(ll.transact_date,ll.load_date) desc nulls last, ll.fileid desc nulls first) as rank
          |		  ,concat_ws('', r.mem_umid, lpad(r.mbr_suffix,2,'0'), '_', upper(date_format(r.service_dt, 'dd-MMM-yy')), '_', r.prod_id, '_', round(safe_to_number(r.met_dec_qt))) as reprx_joinid
          |		  ,r.*
          |      from REPRX r
          |      inner join ll_prx ll on r.fileid=ll.fileid
          |
          |     )
          |     where rank=1
          |)
          |
          |select groupid, datasrc, client_ds_id, CLAIM_ID, CONTRACT_ID, DAYS_SUPPLY, MEMBER_ID, METRIC_QUANTITY, NDC_NAME, NDC, QUANTITY_PER_FILL, RX_ID, SERVICE_DATE, ALLOWED_AMOUNT, PAYMENT_AMOUNT, REQUESTED_AMOUNT, ENCOUNTERID, GENERIC_STATUS, LOCALDAW, PAY_PROCESS_DATE, PRESC_PROV_FNAME, PRESC_PROV_ID, PRESC_PROV_LNAME, PRESC_PROV_NPI
          |from
          |(
          |select
          | '{groupid}'		           as groupid
          |,'reclmdsp' 			   as datasrc
          |,{client_ds_id}         	           as client_ds_id
          |,concat_ws('', e.memb_id, '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', round(safe_to_number(e.Rx_Qty)))  as CLAIM_ID
          |,bme.employeraccountid 		   as CONTRACT_ID
          |,case when safe_to_number(e.Act_Pd_Amt) < 0
          | then safe_to_number(r.Plan_Ds) * -1
          | else safe_to_number(r.Plan_Ds) end as DAYS_SUPPLY
          |,memb_id                    as MEMBER_ID
          |,safe_to_number(e.Rx_Qty)          as METRIC_QUANTITY
          |,r.Drug_Name                       as NDC_NAME
          |,lpad(e.Ndc_Nbr,11,'0')            as NDC
          |,safe_to_number(e.Rx_Qty)          as QUANTITY_PER_FILL
          |,e.Pres_Nbr                        as RX_ID
          |,e.Srv_Frm_Dt                      as SERVICE_DATE
          |,safe_to_number(e.Bsched_Amt)      as ALLOWED_AMOUNT
          |,safe_to_number(e.Act_Pd_Amt)      as PAYMENT_AMOUNT
          |,safe_to_number(e.Chrg_Amt)        as REQUESTED_AMOUNT
          |,concat_ws('', e.memb_id, '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', round(safe_to_number(e.Rx_Qty)))  as ENCOUNTERID
          |,case when e.Gen_Ind = 'G' then 'Y' else e.Gen_Ind end as GENERIC_STATUS
          |,r.Daw_Cd                          as LOCALDAW
          |,e.Proc_Date                       as PAY_PROCESS_DATE
          |,r.Pres_Fstnm                      as PRESC_PROV_FNAME
          |,r.Pres_Npi_N                      as PRESC_PROV_ID
          |,r.Pres_Lstnm                      as PRESC_PROV_LNAME
          |,r.Pres_Npi_N                      as PRESC_PROV_NPI
          |from T_Reclmdsp e
          |anti join  T_RECLM627 trec on e.Reclmdsp_joinid=trec. Reclm627_T
          |cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
          |left outer join DEDUP_REPRX r on (e.Reclmdsp_Reprx_joinid = r.reprx_joinid)
          |
          |)
        """.stripMargin
          .replace(groupIdConstant, loaderVars.groupId)
          .replace(clientDsIdConstant, clientDsId)
      )

      df1mdsp.union(df2mdsp)

    }
    else {
      val df1 = sparkSession.sql(
        s"""
           |with ll_627 as
           |(
           |  select fileid,max(transact_date) as transact_date ,max(staged_dt_tm) as load_date
           |  from RECLM627 group by fileid
           | )
           | ,ll_prx as
           | (
           | select fileid,max(transact_date) as transact_date ,max(staged_dt_tm) as load_date
           |  from REPRX group by fileid
           |  )
           | ,ll_exp as
           | (
           | select fileid,max(transact_date) as transact_date,max(staged_dt_tm) as load_date
           |  from RECLMEXP group by fileid
           |  )
           |,dedup_reclm627 as (
           |select   *
           |from (
           |        select row_number() over (partition by concat_ws('', mbr_pid, '_', upper(date_format(srv_frm_dt, 'dd-MMM-yy')), '_', ndc_nbr, '_', safe_to_number(pres_qty))
           |               order by coalesce(ll.transact_date,ll.load_date) desc nulls last, ll.fileid desc nulls first) as rank
           |               ,concat_ws('', p.mbr_pid, '_', upper(date_format(p.srv_frm_dt, 'dd-MMM-yy')), '_', p.ndc_nbr, '_', safe_to_number(p.pres_qty)) as Reclm627_joinid
           |               ,concat_ws('', p.mem_umid, '_', upper(date_format(p.srv_frm_dt, 'dd-MMM-yy')), '_', p.ndc_nbr, '_', round(safe_to_number(p.pres_qty))) as Reclm627_Reprx_joinid
           |               ,p.*
           |        from RECLM627 p
           |        inner join ll_627 ll on p.fileid=ll.fileid
           |        where lr_ind in ('B','L') and (claim_ind is null or claim_ind in ('+','@'))
           |    )
           |    where rank=1
           |)
           |
           |,dedup_reprx as (
           |select  *
           |from (
           |        select row_number() over (partition by concat_ws('', mem_umid, lpad(mbr_suffix,2,'0'), '_', upper(date_format(service_dt, 'dd-MMM-yy')), '_', prod_id, '_', safe_to_number(met_dec_qt))
           |               order by coalesce(ll.transact_date,ll.load_date) desc nulls last, ll.fileid desc nulls first) as rank
           |               ,concat_ws('', r.mem_umid, lpad(r.mbr_suffix,2,'0'), '_', upper(date_format(r.service_dt, 'dd-MMM-yy')), '_', r.prod_id, '_', round(safe_to_number(r.met_dec_qt))) as Reprx_joinid
           |               ,r.*
           |        from REPRX r
           |        inner join ll_prx ll on r.fileid=ll.fileid
           |     )
           |     where rank=1
           |)
           |
           |
           |,T_RECLMEXP as (
           |select
           | case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then
           |         concat_ws('', e.mbr_pid, '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.ndc_nbr, '_', safe_to_number(e.rx_qty))
           |     else
           |        concat_ws('', e.mbr_pid, '00', '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.ndc_nbr, '_', safe_to_number(e.rx_qty))
           |   end as Reclmexp_joinid,e.*
           |   from RECLMEXP e
           |   inner join ll_exp ll on e.fileid=ll.fileid
           |)
           |
           |
           |
           |,R1_reprx as (
           |select
           |        concat_ws('', r1.mem_umid, lpad(r1.mbr_suffix,2,'0'), '_', upper(date_format(r1.service_dt, 'dd-MMM-yy')), '_', r1.prod_id, '_', round(safe_to_number(r1.met_dec_qt))) as Reprx_joinid_R1
           |       ,r1.* from DEDUP_RECLM627 dr
           |       left outer join REPRX r1 on (dr.Reclm627_Reprx_joinid = concat_ws('', r1.mem_umid, lpad(r1.mbr_suffix,2,'0'), '_', upper(date_format(r1.service_dt, 'dd-MMM-yy')), '_', r1.prod_id, '_', round(safe_to_number(r1.met_dec_qt))))
           |       where NOT EXISTS (select 1 from T_RECLMEXP t where t.reclmexp_joinid = dr.reclm627_joinid)
           |)
           |
           |
           |
           |select groupid, datasrc, client_ds_id, CLAIM_ID, CONTRACT_ID, DAYS_SUPPLY, MEMBER_ID, METRIC_QUANTITY, NDC_NAME, NDC, QUANTITY_PER_FILL, RX_ID, SERVICE_DATE, ALLOWED_AMOUNT, PAYMENT_AMOUNT, REQUESTED_AMOUNT, ENCOUNTERID, GENERIC_STATUS, LOCALDAW, PAY_PROCESS_DATE, PRESC_PROV_FNAME, PRESC_PROV_ID, PRESC_PROV_LNAME, PRESC_PROV_NPI
           |from
           |(
           |Select
           | '{groupid}'		              as groupid
           |,'RECLM627' 			      as datasrc
           |,{client_ds_id}         	              as client_ds_id
           |,concat_ws('', p.Mbr_Pid, '_', upper(date_format(p.Srv_Frm_Dt, 'dd-MMM-yy')), '_', p.Ndc_Nbr, '_', round(safe_to_number(p.Pres_Qty))) as CLAIM_ID
           |,bme.employeraccountid 		      as CONTRACT_ID
           |,case
           |when coalesce(safe_to_number(e.Act_Pd_Amt),safe_to_number(r1.Tot_Paid_A)) < 0 then safe_to_number(r.Plan_Ds) * -1
           |else safe_to_number(r.Plan_Ds) end as DAYS_SUPPLY
           |,p.mbr_pid as MEMBER_ID
           |,case
           |when coalesce(safe_to_number(e.act_pd_amt),safe_to_number(r1.tot_paid_a)) < 0
           |     then coalesce(safe_to_number(r.met_dec_qt),safe_to_number(p.pres_qty)) * -1
           |     else coalesce(safe_to_number(r.met_dec_qt),safe_to_number(p.pres_qty)) end as METRIC_QUANTITY
           |,r.drug_name               as NDC_NAME
           |,lpad(p.ndc_nbr,11,'0')    as NDC
           |,case
           |when coalesce(safe_to_number(e.act_pd_amt),safe_to_number(r1.tot_paid_a)) < 0
           |     then coalesce(safe_to_number (r.met_dec_qt),safe_to_number(p.pres_qty)) * -1
           |     else coalesce(safe_to_number (r.met_dec_qt),safe_to_number(p.pres_qty)) end as QUANTITY_PER_FILL
           |,p.Pres_Nbr                as RX_ID
           |,p.Srv_Frm_Dt              as SERVICE_DATE
           |,nvl2(e.Bsched_Amt,safe_to_number(e.Bsched_Amt),0)   as ALLOWED_AMOUNT
           |,NVL2 ( coalesce(safe_to_number(e.Act_Pd_Amt),safe_to_number(r1.Tot_Paid_A)),
           |        coalesce(safe_to_number(e.Act_Pd_Amt),safe_to_number(r1.Tot_Paid_A)), 0 )  as PAYMENT_AMOUNT
           |,nvl2(e.Chrg_Amt,safe_to_number(e.Chrg_Amt),0)         as REQUESTED_AMOUNT
           |,concat_ws('', p.Mbr_pid, '_', upper(date_format(p.Srv_Frm_Dt, 'dd-MMM-yy')), '_', p.Ndc_Nbr, '_', round(safe_to_number(p.Pres_Qty))) as ENCOUNTERID
           |,Case when p.Gen_Ind = 'G' then 'Y' else p.Gen_Ind end as GENERIC_STATUS
           |,r.Daw_Cd                              as LOCALDAW
           |,coalesce(e.Proc_Date,r1.Sf_Proc_Dt)   as PAY_PROCESS_DATE
           |,r.Pres_Fstnm                          as PRESC_PROV_FNAME
           |,coalesce(p.Pres_Id, r.Pres_Npi_N)     as PRESC_PROV_ID
           |,r.Pres_Lstnm                          as PRESC_PROV_LNAME
           |,coalesce(p.pres_id, r.pres_npi_n)     as PRESC_PROV_NPI
           |from DEDUP_RECLM627 p
           |cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
           |left outer join T_RECLMEXP e on (e.Reclmexp_joinid = p.Reclm627_joinid) and (e.claim_type = 'R' and e.claim_ind in ('+','@'))
           |left outer join DEDUP_REPRX r on (r.Reprx_joinid = p.Reclm627_Reprx_joinid)
           |left outer join R1_REPRX r1 on (r1.Reprx_joinid_R1 = p.Reclm627_Reprx_joinid)
           |
         |
         |)
       """.stripMargin
          .replace(groupIdConstant, loaderVars.groupId)
          .replace(clientDsIdConstant, clientDsId)


      )


      val df2 = sparkSession.sql(
        s"""
           |with ll_exp as
           |(
           |  select fileid,max(transact_date) as transact_date ,max(staged_dt_tm) as load_date
           |  from RECLMEXP group by fileid
           | )
           | ,ll_prx as
           | (
           |
           | select fileid,max(transact_date) as transact_date ,max(staged_dt_tm) as load_date
           |  from REPRX group by fileid
           |  )
           |, T_Reclm627 as (
           |select
           |concat_ws('', Mbr_Pid, '_', upper(date_format(Srv_Frm_Dt, 'dd-MMM-yy')), '_', Ndc_Nbr, '_', safe_to_number(Pres_Qty)) AS Reclm627_T from RECLM627
           |
           |)
           |,T_Reclmexp as (
           |Select
           | case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then
           |  concat_ws('', e.Mbr_Pid, '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', safe_to_number(e.Rx_Qty))
           | else
           |   concat_ws('', e.Mbr_Pid, '00', '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', safe_to_number(e.Rx_Qty))
           | end as Reclmexp_joinid
           |,concat_ws('', e.Mem_Umid, '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', round(safe_to_number(e.Rx_Qty))) as Reclmexp_Reprx_joinid
           |,case when date_format(ll.transact_date,'yyyyMMdd')>='20210527' then e.Mbr_Pid else concat_ws('', e.Mbr_Pid, '00') end as memb_id
           |,e.*
           |from RECLMEXP e
           |inner join ll_exp ll on e.fileid=ll.fileid
           |where e.Claim_Type in ('R') and (e.Claim_Ind is null or e.Claim_Ind in ('+','@'))
           |)
           |,dedup_reprx as (
           |select  *
           |from (
           |      select row_number() over (partition by concat_ws('', mem_umid, lpad(mbr_suffix,2,'0'), '_', upper(date_format(service_dt, 'dd-MMM-yy')), '_', prod_id, '_', safe_to_number(met_dec_qt))
           |      order by coalesce(ll.transact_date,ll.load_date) desc nulls last, ll.fileid desc nulls first) as rank
           |		  ,concat_ws('', r.mem_umid, lpad(r.mbr_suffix,2,'0'), '_', upper(date_format(r.service_dt, 'dd-MMM-yy')), '_', r.prod_id, '_', round(safe_to_number(r.met_dec_qt))) as reprx_joinid
           |		  ,r.*
           |      from REPRX r
           |      inner join ll_prx ll on r.fileid=ll.fileid
           |     )
           |     where rank=1
           |)
           |
           |select groupid, datasrc, client_ds_id, CLAIM_ID, CONTRACT_ID, DAYS_SUPPLY, MEMBER_ID, METRIC_QUANTITY, NDC_NAME, NDC, QUANTITY_PER_FILL, RX_ID, SERVICE_DATE, ALLOWED_AMOUNT, PAYMENT_AMOUNT, REQUESTED_AMOUNT, ENCOUNTERID, GENERIC_STATUS, LOCALDAW, PAY_PROCESS_DATE, PRESC_PROV_FNAME, PRESC_PROV_ID, PRESC_PROV_LNAME, PRESC_PROV_NPI
           |from
           |(
           |select
           | '{groupid}'		           as groupid
           |,'RECLMEXP' 			   as datasrc
           |,{client_ds_id}         	           as client_ds_id
           |,concat_ws('', e.memb_id,'_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', round(safe_to_number(e.Rx_Qty)))  as CLAIM_ID
           |,bme.employeraccountid 		   as CONTRACT_ID
           |,case
           |when safe_to_number(e.Act_Pd_Amt) < 0 then safe_to_number(r.Plan_Ds) * -1
           |else safe_to_number(r.Plan_Ds) end as DAYS_SUPPLY
           |,memb_id                        as MEMBER_ID
           |,safe_to_number(e.Rx_Qty)          as METRIC_QUANTITY
           |,r.Drug_Name                       as NDC_NAME
           |,lpad(e.Ndc_Nbr,11,'0')            as NDC
           |,safe_to_number(e.Rx_Qty)          as QUANTITY_PER_FILL
           |,e.Pres_Nbr                        as RX_ID
           |,e.Srv_Frm_Dt                      as SERVICE_DATE
           |,safe_to_number(e.Bsched_Amt)      as ALLOWED_AMOUNT
           |,safe_to_number(e.Act_Pd_Amt)      as PAYMENT_AMOUNT
           |,safe_to_number(e.Chrg_Amt)        as REQUESTED_AMOUNT
           |,concat_ws('', e.memb_id, '_', upper(date_format(e.Srv_Frm_Dt, 'dd-MMM-yy')), '_', e.Ndc_Nbr, '_', round(safe_to_number(e.Rx_Qty)))  as ENCOUNTERID
           |,case
           |when e.Gen_Ind = 'G' then 'Y' else e.Gen_Ind end as GENERIC_STATUS
           |,r.Daw_Cd                          as LOCALDAW
           |,e.Proc_Date                       as PAY_PROCESS_DATE
           |,r.Pres_Fstnm                      as PRESC_PROV_FNAME
           |,r.Pres_Npi_N                      as PRESC_PROV_ID
           |,r.Pres_Lstnm                      as PRESC_PROV_LNAME
           |,r.Pres_Npi_N                      as PRESC_PROV_NPI
           |from T_RECLMEXP e
           |anti join  T_RECLM627 trec on e.Reclmexp_joinid=trec. Reclm627_T
           |cross join ZO_BPO_MAP_EMPLOYER bme on (bme.client_ds_id = {client_ds_id})
           |left outer join DEDUP_REPRX r on (e.Reclmexp_Reprx_joinid = r.reprx_joinid)
           |)
       """.stripMargin
          .replace(groupIdConstant, loaderVars.groupId)
          .replace(clientDsIdConstant, clientDsId)
      )
      df1.union(df2)
    }
  }

}

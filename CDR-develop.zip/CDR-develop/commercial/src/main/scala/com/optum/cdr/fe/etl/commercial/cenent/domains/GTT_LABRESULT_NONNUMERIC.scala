package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.etl.commercial.cenent_gtt_labresult_nonnumeric
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object GTT_LABRESULT_NONNUMERIC extends FEQueryAndMetadata[cenent_gtt_labresult_nonnumeric] {

  override def name: String = "GTT_LABRESULT_NONNUMERIC"

  override def dependsOn: Set[String] = Set("LABRESULT_SERVCE_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, datecollected, LABORDEREDDATE, dateavailable, encounterid, laborderid, localname, normalrange, localtestname, localunits, LABRESULT_DATE, localresult_numeric, nullif(substr(localresult,1,case when instr_3params(localresult,' ',25) = 0 then
      |       length(localresult) else instr_3params(localresult,' ',25) end), '') as localresult_25, local_loinc_code
      |from
      |(
      |LABRESULT_SERVCE_CACHE
      |)
      |where res_row = 1 AND localresult_numeric IS NULL AND labresultid IS NOT NULL
    """.stripMargin
}
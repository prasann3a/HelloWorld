package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROCEDURE_CACHE_3 extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_3"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT", "MCKESSON_PGN_V1_ZH_TSM910_ICD9_REF", "MCKESSON_PGN_V1_TPM317_VISIT_PROCEDURE", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val hostProcFlg = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "PROC_HOSPITALFLAG","PROCEDUREDO","VISIT_PROCEDURE","VISIT_PROCEDURE").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |with uni_visit1 AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        |   WHERE vst_int_id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'
        |   AND Psn_Int_Id IS NOT NULL ),
        |uni_ref AS
        |(SELECT * FROM
        |   (SELECT r.*, ROW_NUMBER() OVER (PARTITION BY icd9_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
        |      FROM MCKESSON_PGN_V1_ZH_TSM910_ICD9_REF r
        |     WHERE icd9_int_id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'
        |   AND icd9_code_ty = 'P')
        |
        |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
        |from
        |(
        |SELECT '{groupid}'         	 AS groupid
        |      ,'visit_procedure'         AS datasrc
        |      ,{client_ds_id}             AS client_ds_id
        |      ,vp.Icd9_Int_Id	 	 AS localcode
        |      ,uni_visit1.Psn_Int_Id      AS patientid
        |      ,COALESCE(safe_to_date_length(uni_visit1.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit1.adm_ts)
        |      ,CASE WHEN vp.Icd9_Proc_Srt_Ts NOT BETWEEN COALESCE(safe_to_date_length(uni_visit1.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit1.adm_ts)
        |                AND COALESCE(uni_visit1.dschrg_ts, current_date) THEN COALESCE(safe_to_date_length(uni_visit1.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit1.adm_ts)
        |            ELSE vp.Icd9_Proc_Srt_Ts END AS proceduredate
        |      ,vp.Vst_Int_Id 	         AS encounterid
        |      ,NULL		         AS orderingproviderid
        |      ,uni_ref.Icd9_Abrv_Ds      AS localname
        |      ,vp.Icd9_Seq_No		 AS procseq
        |      ,vp.Icd9_Proc_End_Ts       AS proc_end_date
        |      ,CASE WHEN 'Y' IN ({host_proc_flg}) THEN 'Y' ELSE NULL END AS hosp_px_flag
        |      ,CASE WHEN uni_ref.icd_ver_cd = '0' THEN 'ICD10'
        |	    WHEN uni_ref.icd_ver_cd = '9' THEN 'ICD9' ELSE NULL END   AS codetype
        |      ,CASE WHEN vp.icd9_rank_no = '1' THEN 'Y' ELSE 'N' END  AS localprincipleindicator
        |      ,uni_ref.icd9_code         AS mappedcode
        |      ,vp.Car_Gvr_Int_Id         AS performingproviderid
        |      ,CASE WHEN vp.Icd9_Proc_Srt_Ts NOT BETWEEN COALESCE(safe_to_date_length(arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), adm_ts)
        |                AND COALESCE(uni_visit1.dschrg_ts, current_date) THEN COALESCE(safe_to_date_length(uni_visit1.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit1.adm_ts)
        |            ELSE vp.Icd9_Proc_Srt_Ts END  AS actualprocdate
        |      ,ROW_NUMBER() OVER (PARTITION BY uni_visit1.Psn_Int_Id, vp.Vst_Int_Id,
        |                              CASE WHEN vp.Icd9_Proc_Srt_Ts NOT BETWEEN COALESCE(safe_to_date_length(uni_visit1.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit1.adm_ts)
        |                                                   AND COALESCE(uni_visit1.dschrg_ts, current_date) THEN
        |                                       COALESCE(safe_to_date_length(uni_visit1.arv_date_time,'yyyy-MM-dd HH:mm:ss', 19), uni_visit1.adm_ts)
        |                                   ELSE vp.Icd9_Proc_Srt_Ts END,
        |                              vp.Icd9_Int_Id
        |                               ORDER BY vp.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM MCKESSON_PGN_V1_TPM317_VISIT_PROCEDURE vp
        |   JOIN UNI_VISIT1 ON (uni_visit1.vst_int_id = vp.vst_int_id)
        |   JOIN UNI_REF ON (uni_ref.icd9_int_id = vp.icd9_int_id)
        |WHERE vp.row_sta_cd <> 'D'
        |  AND vp.Icd9_Int_Id IS NOT NULL
        |)
        |where proceduredate IS NOT NULL AND patientid IS NOT NULL
      """.stripMargin
        .replace("{host_proc_flg}", hostProcFlg)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }
}

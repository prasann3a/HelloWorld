
package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.patientdetail
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENT_ID_CACHE  extends FETableInfo[cernerpatientidcache]
{

  override def name:String="TEMP_PATIENT_ID_CACHE"
  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_cmrn= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,
      "CMRN",	"PATIENT_IDENTIFIER","IDENTIFIERS","IDENTIFIER_TYPE").mkString(",")

    val list_ssn= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"SSN",	"PATIENT_IDENTIFIER","IDENTIFIERS","IDENTIFIER_TYPE").mkString(",")

    sparkSession.sql(
      s"""
         |select t.*
         |	,'{groupid}'	as groupid
         |	,{client_ds_id}	as client_ds_id
         |	,'identifiers'	as datasrc
         |	,row_number() over (partition by t.patientid, t.ssn order by t.update_date desc nulls last) as ssn_row
         |    ,row_number() over (partition by t.patientid, t.mrn order by t.update_date desc nulls last) as cmrn_row
         |from (
         |select i.entity_identifier	as patientid
         |	,case when i.identifier_type in ({list_ssn}) then i.identifier end as ssn
         |	,case when i.identifier_type in ({list_cmrn}) then i.identifier end as mrn
         |	,rc.display	as id_subtype
         |	,case when i.active = '1' then '1' end as active_id_flag
         |	,i.update_date_time	as update_date
         |from IDENTIFIERS i
         |	left outer join REFERENCECODE rc on (i.identifier_type = rc.element_code and rc.field in ('IDENTIFIER_TYPE'))
         |where i.entity_identifier is not null
         |and i.entity_type = 'PERSON'
         |and i.identifier_type in ({list_ssn},{list_cmrn})
         |) t
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_ssn}",list_ssn)
        .replace("{list_cmrn}",list_cmrn)

    )
  }

  override def dependsOn: Set[String] = Set("IDENTIFIERS","REFERENCECODE","MAP_PREDICATE_VALUES")
}
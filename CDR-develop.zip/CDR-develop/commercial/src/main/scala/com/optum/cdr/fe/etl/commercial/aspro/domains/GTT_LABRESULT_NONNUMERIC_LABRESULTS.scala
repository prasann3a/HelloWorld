package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.aspro_labresult_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object GTT_LABRESULT_NONNUMERIC_LABRESULTS extends FEQueryAndMetadata[aspro_labresult_cache]{

  override def name: String = "GTT_LABRESULT_NONNUMERIC_LABRESULTS"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE_LABRESULTS")

  override def sparkSql: String =
    """
      |select groupid, datasrc, encounterid, patientid, laborderid, labresultid, localresult, localcode, localname
      |, normalrange, localunits, datecollected, dateavailable, labresult_date
      |, (substr(localresult,1,case when instr_3params(localresult,' ',25) = 0
      |                                  then length(localresult)
      |                                  else instr_3params(localresult,' ',25) end)) as localresult_25, client_ds_id, labordereddate
      |from
      |(
      |LABRESULT_CACHE_LABRESULTS
      |)
      |where localresult_numeric is null
    """.stripMargin
}

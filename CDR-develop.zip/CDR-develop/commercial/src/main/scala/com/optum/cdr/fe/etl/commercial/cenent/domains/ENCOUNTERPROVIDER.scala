package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.encounterprovider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object ENCOUNTERPROVIDER extends FEQueryAndMetadata[encounterprovider] {

  override def name: String = CDRFEParquetNames.encounterprovider

  override def dependsOn: Set[String] = Set("ENCNTR", "ENCRAT")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, encounterid, patientid, encountertime, providerid, providerrole, facilityid
      |from
      |(
      |SELECT * FROM (
      |SELECT '{groupid}' as groupid
      |,'encntr' as datasrc
      |,{client_ds_id} as client_ds_id
      |,Encrat.Begin_Dttm  AS encountertime
      |,Encrat.Assoct_Num  AS providerid
      |,Encntr.Pat_Person_Num  AS patientid
      |,Encntr.Num  AS encounterid
      |,Encntr.Fac_Num  AS facilityid
      |,Encrat.Role_Cde  AS providerrole
      |,ROW_NUMBER() OVER (PARTITION BY Encntr.Num, Encrat.Assoct_Num, Encrat.Role_Cde
      |                    ORDER BY Encrat.Begin_Dttm DESC NULLS LAST) rn
      |FROM ENCNTR
      |     JOIN ENCRAT ON (encrat.encntr_num = encntr.num))
      |WHERE rn=1
      |)
      |where encountertime IS NOT NULL
    """.stripMargin

}
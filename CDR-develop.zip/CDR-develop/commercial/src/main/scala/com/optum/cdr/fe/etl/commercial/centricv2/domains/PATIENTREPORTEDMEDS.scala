package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.rx_patient_reported
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENTREPORTEDMEDS extends FETableInfo[rx_patient_reported] {

  override def name: String = "PATIENTREPORTEDMEDS"

  override def dependsOn: Set[String] = Set("CENTRICV2_PATIENTMEDICATION", "CENTRICV2_PRESCRIPTIONS", "CENTRICV2_ZH_MEDINFO", "CENTRICV2_DOCUMENTS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOC_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")

    val constNoMpvMatches = "'NO_MPV_MATCHES'"
    val docXidInclusion = if (docXidInclusionMpv == constNoMpvMatches) "" else " and doc.xid in ( " + docXidInclusionMpv.replace("'", "") + " ) "

    sparkSession.sql(
      """
        |select groupid, datasrc, client_ds_id, patientid, encounterid, drugdescription as localdrugdescription, categorycode as localcategorycode, localform, localgpi, localndc, localroute, localstrengthperdoseunit, localstrengthunit, reportedmedid, medreportedtime, discontinuedate, discontinuereason, localmedcode, LOCALQTYOFDOSEUNIT, LOCALDOSEUNIT
        |from
        |(
        |select pat_rx.*
        | ,  row_number() over (partition by  concat_ws('', encounterid, reportedmedid, patientid, localmedcode, discontinuedate) order by medreportedtime desc nulls last) as drug_row
        | from
        | (SELECT '{groupid}'                                    as groupid
        |,'pat_med'                                         as datasrc
        |,{client_ds_id}                                     as client_ds_id
        |,pm.Pid                                            AS patientid
        |,nvl2(pm.Stopreason,'1','2')                       AS categorycode
        |,SAFE_TO_DATE(nullif( date_format(stopdate,'yyyyMMdd'),'47001231'),'yyyyMMdd')  AS discontinuedate
        |,pm.Stopreason                                     AS discontinuereason
        |,pm.Description                                    AS drugdescription
        |,pm.Sdid                                           AS encounterid
        |,coalesce(nullif(regexp_replace(pm.dose_unit,'[{}]',''), ''),mi.doseform) AS localform
        |,coalesce( pm.Gpi,mi.Gpi)                          AS localgpi
        |,case when pm.Ddid = 0 then pm.Description else CAST(pm.Ddid as INT) end AS localmedcode
        |,nvl(nullif(concat_ws('', pm.Ndclabprod, pm.Ndcpackage), ''),mi.Ndcnum)       AS localndc
        |,coalesce(mi.ROUTE,nullif(trim(nullif(regexp_extract(lower(pm.INSTRUCTIONS),' (ear|eye|as directed|by|cream|inj|inh(altions|ed)?|mouth|nostril|oral|patch|puff|po|sub(cut|q|l)|supp|topical| )+', 0), '')), ''),nullif(regexp_extract(pm.Description,'(CAPS?|CREAM?|FOAM|GEL|HFA AER[SO]|INJ|LQCR|LOZG|NEBU|PTTW|PT24|POWD|OINT|SUBL|SPRAY|SOLN|SUS[PR]|SYRP|TABS?)', 0), '')) AS localroute
        |,mi.Strengthonly                                   AS localstrengthperdoseunit
        |,mi.Unitsonly                                      AS localstrengthunit
        |,pm.Startdate                                      AS medreportedtime
        |,pm.Mid                                            AS reportedmedid
        |,
        |Case
        |When pm.dose <> '.00000' then pm.dose
        |else null END AS LOCALQTYOFDOSEUNIT
        |,coalesce(nullif(regexp_replace(pm.dose_unit,'[{}]',''), ''),mi.doseform) AS LOCALDOSEUNIT
        |       FROM CENTRICV2_PATIENTMEDICATION pm
        |          LEFT OUTER JOIN CENTRICV2_ZH_MEDINFO mi ON (pm.ddid = mi.ddid)
        |          INNER JOIN CENTRICV2_DOCUMENTS doc ON (doc.sdid = pm.sdid and doc.pid = pm.pid)
        |          left outer JOIN CENTRICV2_PRESCRIPTIONS pres ON (pm.MID = pres.MID and pm.pid = pres.pid)
        |           WHERE pres.MID is null
        |           {dox_xid_condition}
        |           AND (pm.Change IS NULL or pm.Change IN ('0','1','2'))
        |           and (stopreason <> 'E' or stopreason is null)
        |           AND doc.finalsign = 1
        |           AND doc.status = 'S'
        |            )pat_rx
        |)
        |where patientid is not null and medreportedtime is not null and  drug_row =1
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{dox_xid_condition}", docXidInclusion)
    )

  }

}
package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.patientcontact
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object PATIENTCONTACT extends FEQueryAndMetadata[patientcontact] {

  override def name: String = "PATIENTCONTACT"

  override def dependsOn: Set[String] = Set("PATIENT_PART1_CACHE", "PATIENT_PART2_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as update_dt, homephone as home_phone, workphone as work_phone, nullif(SUBSTR(email, 1, 100), '') as personal_email, cell_phone
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where contact_row = 1  and nullif(concat_ws('', homephone, workphone, email), '') is not null and patientid is not null and lastupdateddate is not null
      |
      |union all
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as update_dt, homephone as home_phone, workphone as work_phone, nullif(SUBSTR(email, 1, 100), '') as personal_email, cell_phone
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where contact_row = 1  and nullif(concat_ws('', homephone, workphone, email, cell_phone), '') is not null and patientid is not null and lastupdateddate is not null
    """.stripMargin
}
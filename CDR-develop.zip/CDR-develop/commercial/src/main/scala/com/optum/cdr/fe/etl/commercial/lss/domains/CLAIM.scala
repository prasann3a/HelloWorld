package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object CLAIM extends FEQueryAndMetadata[claim]{

  override def name: String = CDRFEParquetNames.claim

  override def dependsOn: Set[String] = Set("LSS_PBRACCOUNTS", "LSS_DPBRPROCEDURE", "LSS_PBRACCOUNTTRANSACTIONS", "LSS_DPBRPROVIDER", "LSS_DPBRLOCATION")

  override def sparkSql: String =
    """
      |with act_qry as
      |(
      |select * from (
      |select a.*,
      |       row_number() over (partition by sourceid, accountid order by RowUpdateDateTime desc, FileID desc nulls last) as act_rownumber
      |from   LSS_PBRACCOUNTS a
      |) where act_rownumber = 1
      |),
      |proc_qry as
      |(
      |select * from (
      |select p.*,
      |       row_number() over (partition by sourceid, procedureid order by RowUpdateDateTime desc, FileID desc nulls last) as proc_rownumber
      |from   LSS_DPBRPROCEDURE p
      |) where proc_rownumber = 1
      |)
      |select datasrc,claimid,encounterid,patientid,charge,quantity,localcpt,mappedcpt,localcptmod1,mappedcptmod1,servicedate,seq,claimproviderid,pos
      |from (
      |select x.*
      |       ,row_number() over (partition by ClaimID, Seq order by RowUpdateDateTime desc, FileID desc nulls last) as rownumber
      |from (
      |SELECT
      |  'pbraccounttransactions' as datasrc
      |  ,NULLIF(CONCAT_WS('', pbr.Sourceid, pbr.Accountid, pbr.Locationid, upper(date_format(pbr.Servicedatetime, 'dd-MMM-yy'))), '') AS claimid
      |  ,NULLIF(CONCAT_WS('', act.Sourceid, act.Patientid), '') AS patientid
      |  ,pbr.Servicedatetime AS servicedate
      |  ,COALESCE(NULLIF(substr(proc.Inscode,1,5), ''),NULLIF(substr(pbr.Procedureid,1,5), '') ) AS localcpt
      |  ,COALESCE(NULLIF(substr(regexp_replace(proc.inscode, '[^a-zA-Z0-9]+', ''), 6), ''), NULLIF(substr(regexp_replace(pbr.procedureid, '[^a-zA-Z0-9]+', ''), 6), '')) AS localcptmod1
      |  ,case when length(loc.Stdplaceofservice) < 2 then null else loc.Stdplaceofservice end AS pos
      |  ,pbr.Quantity AS quantity
      |  ,pbr.Transactionid AS seq
      |  ,COALESCE(NULLIF(substr(regexp_replace(proc.inscode, '[^a-zA-Z0-9]+', ''), 6), ''), NULLIF(substr(regexp_replace(pbr.procedureid, '[^a-zA-Z0-9]+', ''), 6), '')) AS mappedcptmod1
      |  ,pbr.Amount AS charge
      |  ,NULLIF(CONCAT_WS('', pbr.Providerid, pbr.Sourceid), '') AS claimproviderid
      |  ,COALESCE(NULLIF(substr(proc.Inscode,1,5), ''), NULLIF(substr(pbr.Procedureid,1,5), '') ) AS mappedcpt
      |  ,NULLIF(CONCAT_WS('', pbr.Sourceid, pbr.Accountid, pbr.Locationid, upper(date_format(pbr.Servicedatetime, 'dd-MMM-yy'))), '') AS encounterid
      |  ,pbr.RowUpdatedateTime
      |  ,pbr.FileID
      |FROM LSS_PBRACCOUNTTRANSACTIONS pbr
      |INNER JOIN LSS_DPBRPROVIDER dpb ON (dpb.sourceid=pbr.sourceid and dpb.providerid=pbr.providerid)
      |INNER JOIN act_qry act ON (pbr.sourceid=act.sourceid and pbr.accountid=act.accountid)
      |INNER JOIN LSS_DPBRLOCATION loc ON (pbr.sourceid=loc.sourceid and pbr.locationid=loc.locationid)
      |LEFT JOIN proc_qry proc ON (dpb.sourceid = proc.sourceid and Pbr.procedureid = proc.procedureid)
      |WHERE  pbr.Type = 'C' and pbr.reversingtransactionid is null
      | AND ( NULLIF(CONCAT_WS('', pbr.Sourceid, pbr.Accountid, pbr.Locationid, pbr.Servicedatetime), '') ) is not null
      | AND ( NULLIF(CONCAT_WS('', act.Sourceid, act.Patientid), '') ) is not null
      | AND pbr.Servicedatetime is not null
      |) x
      |)
      |where rownumber = 1
    """.stripMargin
}

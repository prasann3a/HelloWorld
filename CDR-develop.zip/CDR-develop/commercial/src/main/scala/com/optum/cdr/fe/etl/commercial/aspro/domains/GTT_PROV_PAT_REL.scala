package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.gtt_prov_pat_rel
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object GTT_PROV_PAT_REL extends FEQueryAndMetadata[gtt_prov_pat_rel]{

  override def name: String = "GTT_PROV_PAT_REL"

  override def dependsOn: Set[String] = Set("PCP")

  override def sparkSql: String =

      """
        |select groupid, datasrc, {client_ds_id} as client_ds_id, providerid, patientid, localrelshipcode, startdate, enddate
        |from
        |(
        |SELECT '{groupid}'               as groupid
        |       ,'pcp'                 as datasrc
        |       ,dem_preferredprovider as providerid
        |       ,imredem_code          as patientid
        |       ,'PCP'                 as localrelshipcode
        |       ,date_trunc('DAY', tag_systemdate) as startdate
        |       ,current_date               as enddate
        |FROM
        |       (select distinct imredem_code, dem_preferredprovider, date_trunc('DAY', tag_systemdate) tag_systemdate
        |        from PCP where dem_preferredprovider is not null)
        |)
      """.stripMargin

}

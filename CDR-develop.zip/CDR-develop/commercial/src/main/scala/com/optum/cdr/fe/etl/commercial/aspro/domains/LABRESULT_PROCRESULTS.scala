package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_PROCRESULTS extends FEQueryAndMetadata[labresult]{

  override def name: String = "LABRESULT_PROCRESULTS"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE_PROCRESULTS")

  override def sparkSql: String =
    """
      |select groupid, datasrc, labresultid, laborderid, facilityid, encounterid, patientid, datecollected, dateavailable
      |, resultstatus, localresult, localresult_numeric, localresult_numeric as localresult_inferred, localcode, localname
      |, normalrange, localunits, statuscode, labresult_date, client_ds_id
      |from
      |(
      |LABRESULT_CACHE_PROCRESULTS
      |)
      |where localresult_numeric is not null
    """.stripMargin
}

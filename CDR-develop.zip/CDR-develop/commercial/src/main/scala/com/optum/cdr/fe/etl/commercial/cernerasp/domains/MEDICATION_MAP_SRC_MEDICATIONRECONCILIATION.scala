package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_MEDICATIONRECONCILIATION extends FETableInfo[medication_map_src] {

  override def name: String = "MEDICATION_MAP_SRC_MEDICATIONRECONCILIATION"

  override def dependsOn: Set[String] = Set("MEDICATIONS", "MEDICATIONDETAILS", "MEDICATIONRECONCILIATION", "MEDICATIONRECONCILIATIONDETAIL", "REFERENCEMEDICATION")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql("""select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, localgeneric, localbrand, localgpi, localform, localstrength, no_ndc, has_ndc, num_recs, ndc_src
                       |        from
                       |        (
                       |        select
                       |                 '{groupid}'                    as groupid
                       |                ,'medicationreconciliation'     as datasrc
                       |                ,{client_ds_id}                         as client_ds_id
                       |                ,localmedcode
                       |                ,localdescription
                       |                ,localndc
                       |                ,null as localgeneric
                       |                ,null as localbrand
                       |                ,null as localgpi
                       |                ,null as localform
                       |                ,null as localstrength
                       |                ,sum ( case when localndc is null then 1 else 0 end ) as no_ndc
                       |                ,sum ( case when localndc is null then 0 else 1 end ) as has_ndc
                       |                ,count(*) as num_recs
                       |                ,count(*) as ndc_src
                       |        from (
                       |                select
                       |                         max(mdc.mnemonic) over (partition by mdc.record_identifier) as localdescription
                       |                        ,max(case when lower(mdc.mnemonic) like '%misc%' or m.unique_synonym_identifier = '0'
                       |                             then nullif(substr(mdc.mnemonic,1,100), '')
                       |                             else coalesce(m.unique_synonym_identifier, nullif(substr(mdc.mnemonic,1,100), ''))
                       |                             end) over (partition by mdc.record_identifier)
                       |                                as localmedcode
                       |                        ,max(nullif(replace(rm.ndc, '-', ''), '')) over (partition by mdc.record_identifier) as localndc
                       |                        ,row_number() over (partition by mdc.record_identifier order by mdc.update_date_time desc nulls first ) as rw
                       |                from MEDICATIONRECONCILIATION mr
                       |                inner join MEDICATIONRECONCILIATIONDETAIL mdc
                       |                on                      mr.unique_med_reconciliation_id = mdc.unique_med_reconciliation_id
                       |                inner join MEDICATIONS m
                       |                on                      mdc.unique_medication_identifier = m.unique_medication_identifier
                       |                inner join MEDICATIONDETAILS md
                       |                on                      mdc.unique_medication_identifier = md.unique_medication_identifier
                       |                left outer join      (select unique_synonym_identifier, rxnorm, ndc from (
                       |                                                select
                       |                                                r.unique_synonym_identifier as unique_synonym_identifier
                       |                                                ,r.rxnorm as rxnorm
                       |                                                ,nullif(replace(r.ndc, '-', ''), '') as ndc
                       |                                                ,row_number() over (partition by unique_synonym_identifier, ndc, rxnorm order by fileid desc nulls first) rn
                       |                                                from REFERENCEMEDICATION r  ) where rn =1) rm
                       |                on                      m.unique_synonym_identifier = rm.unique_synonym_identifier
                       |        )
                       |        where  rw =1
                       |        group by localmedcode, localdescription, localndc
                       |        )"""
                        .stripMargin
                        .replace("{groupid}", groupId)
                        .replace("{client_ds_id}", clientDsId))
  }

}

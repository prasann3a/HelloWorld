package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.cdr.fe.etl.commercial.mckesson_pgn_procedure_cache
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_1 extends FEQueryAndMetadata[mckesson_pgn_procedure_cache]{
  override def name: String = "PROCEDURE_CACHE_1"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_ZH_TPB900_CHG_CODE_MS","MCKESSON_PGN_V1_ZH_TSM911_CPT4_REF","MCKESSON_PGN_V1_TPB105_CHARGE_DETAIL")

  override def sparkSql: String =
    """
      |WITH uni_visit1 AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
      |   WHERE vst_int_id IS NOT NULL )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'
      |   AND Psn_Int_Id IS NOT NULL ),
      |uni_ms AS
      |(SELECT * FROM
      |(SELECT a.*, ROW_NUMBER() OVER (PARTITION BY chg_cod_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
      |FROM MCKESSON_PGN_V1_ZH_TPB900_CHG_CODE_MS a
      |WHERE chg_cod_int_id IS NOT NULL )
      | WHERE rn = 1
      |   AND  row_sta_cd <> 'D'),
      |uni_cpt41 AS
      |(SELECT * FROM
      |   (SELECT r.*, ROW_NUMBER() OVER (PARTITION BY cpt4_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
      |      FROM MCKESSON_PGN_V1_ZH_TSM911_CPT4_REF r
      |      )
      | WHERE rn = 1
      |   AND  row_sta_cd <> 'D')
      |
      |SELECT m.*
      |      ,SUM(Chg_Unt_No) OVER (PARTITION BY claimid) AS quantity
      |      ,ROUND(SUM(Chg_Tot_At) OVER (PARTITION BY claimid), 2) AS charge
      |      ,ROW_NUMBER() OVER (PARTITION BY claimid,localcpt,localcptmod1,localcptmod2,localcptmod3,localcptmod4
      |                               ORDER BY Lst_Mod_Ts DESC NULLS LAST) clm_rn
      |      ,ROW_NUMBER() OVER (PARTITION BY patientid, encounterid,proceduredate,localcode
      |                               ORDER BY Lst_Mod_Ts DESC NULLS LAST) proc_rn
      |FROM (
      |SELECT '{groupid}'         	 AS groupid
      |      ,'charge_detail'           AS datasrc
      |      ,{client_ds_id}             AS client_ds_id
      |      ,dtl.Chg_Cod_Int_Id	 AS localcode
      |      ,uni_visit1.Psn_Int_Id      AS patientid
      |      ,dtl.Chg_Srv_Ts     	 AS proceduredate
      |      ,dtl.Vst_Int_Id 		 AS encounterid
      |      ,NULL		         AS orderingproviderid
      |      ,uni_ms.Chg_Desc     	 AS localname
      |      ,NULL 			 AS procseq
      |      ,NULL 			 AS hosp_px_flag
      |      ,'CPT4'	                 AS codetype
      |      ,CASE WHEN rlike(dtl.Cpt4_Ext_Id ,'^[0-9A-Z]{5,13}') THEN nullif(SUBSTR(dtl.Cpt4_Ext_Id,1,5), '')
      |            ELSE nullif(SUBSTR(uni_Cpt41.Cpt4_Ext_Id,1,5), '') END   AS mappedcode
      |      ,COALESCE(dtl.Ren_Car_Int_Id,dtl.Car_Gvr_Int_Id) AS performingproviderid
      |      ,dtl.Chg_Srv_Ts		 AS actualprocdate
      |      ,dtl.Chg_Cod_Int_Id	 AS localcpt
      |      ,dtl.Chg_Srv_Ts     	 AS servicedate
      |      ,concat_ws('', dtl.Vst_Int_Id, '.', dtl.Chg_Cod_Int_Id, '.', upper(date_format(dtl.Chg_Srv_Ts, 'dd-MMM-yy')))    AS claimid
      |      ,NULL		         AS facilityid
      |      ,NULL    			 AS seq
      |      ,dtl.Nrv_Cd 		 AS localrev
      |      ,nullif(REGEXP_SUBSTR(dtl.nrv_cd, '^[0-9]+$',1,1), '') AS mappedrev
      |      ,CASE WHEN rlike(dtl.Cpt4_Ext_Id ,'^[0-9A-Z]{5,13}') THEN nullif(SUBSTR(dtl.Cpt4_Ext_Id,1,5), '')
      |            ELSE nullif(SUBSTR(uni_Cpt41.Cpt4_Ext_Id,1,5), '') END AS mappedcpt
      |      ,nullif(SUBSTR(dtl.cpt4_ext_id , 6, 2), '') AS mappedcptmod1
      |      ,nullif(SUBSTR(dtl.cpt4_ext_id , 8, 2), '') AS mappedcptmod2
      |      ,nullif(SUBSTR(dtl.cpt4_ext_id ,10, 2), '') AS mappedcptmod3
      |      ,nullif(SUBSTR(dtl.cpt4_ext_id ,12, 2), '') AS mappedcptmod4
      |      ,nullif(SUBSTR(dtl.cpt4_ext_id , 6, 2), '') AS localcptmod1
      |      ,nullif(SUBSTR(dtl.cpt4_ext_id , 8, 2), '') AS localcptmod2
      |      ,nullif(SUBSTR(dtl.cpt4_ext_id ,10, 2), '') AS localcptmod3
      |      ,nullif(SUBSTR(dtl.cpt4_ext_id ,12, 2), '') AS localcptmod4
      |      ,dtl.Chg_Pst_Ts   AS post_dt
      |      ,COALESCE(dtl.Ren_Car_Int_Id,dtl.Car_Gvr_Int_Id) AS claimproviderid
      |      ,dtl.Chg_Unt_No
      |      ,dtl.Chg_Tot_At
      |      ,dtl.Lst_Mod_Ts
      |FROM MCKESSON_PGN_V1_TPB105_CHARGE_DETAIL dtl
      |   JOIN UNI_VISIT1 ON (dtl.vst_int_id = uni_visit1.vst_int_id)
      |   JOIN UNI_MS ON (dtl.chg_cod_int_id = uni_ms.chg_cod_int_id)
      |   LEFT OUTER JOIN UNI_CPT41 ON (uni_ms.cpt4_int_id = uni_cpt41.cpt4_int_id)
      |WHERE dtl.row_sta_cd <> 'D'
      |  AND dtl.Chg_Srv_Ts IS NOT NULL
      |  AND dtl.Chg_Cod_Int_Id IS NOT NULL
      |) m
    """.stripMargin


}

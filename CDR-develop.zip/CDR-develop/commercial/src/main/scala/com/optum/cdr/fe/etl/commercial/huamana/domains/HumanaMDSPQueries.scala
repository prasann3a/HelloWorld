package com.optum.cdr.fe.etl.commercial.huamana.domains
import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.oap.cdr.models.{map_predicate_values, ref_billtype_pos_xref, zo_bpo_map_employer}
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object HumanaMDSPQueries extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String,runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = HumanaMDSPInitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath,runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = HumanaMDSPQueryRegistry.queries
}


  object HumanaMDSPInitialDependencies {
    def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String,runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      FELoadFromParquet[relab](name = "RELAB", parquetLocation = s"$baseParquetLocation", tableName="RELAB")
      , FELoadFromParquet[rembx](name = "REMBX", parquetLocation = s"$baseParquetLocation", tableName="REMBX")
      , FELoadFromParquet[reclmdsp](name = "RECLMDSP", parquetLocation = s"$baseParquetLocation", tableName="RECLMDSP")
      , FELoadFromParquet[reclm627](name = "RECLM627", parquetLocation = s"$baseParquetLocation", tableName="RECLM627")
      , FELoadFromParquet[term_dict_loinc](name = "TERMDICTIOINC", parquetLocation = s"$mappingParquetPath", tableName="REF_TERM_DICT_LOINC")
      , FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName="MAP_PREDICATE_VALUES")
      , FELoadFromParquet[reprx](name = "REPRX", parquetLocation = s"$baseParquetLocation", tableName="REPRX")
      , FELoadFromParquet[zo_bpo_map_employer](name = "ZO_BPO_MAP_EMPLOYER", parquetLocation = s"$mappingParquetPath", tableName="ZO_BPO_MAP_EMPLOYER")
      , FELoadFromParquet[reclmdsp](name = "RECLMEXP", parquetLocation = s"$baseParquetLocation", tableName="RECLMDSP")


    )
  }

  object HumanaMDSPQueryRegistry {
    val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      INT_CLAIM_LABRESULT,
      INT_CLAIM_MEMBER,
      INT_CLAIM_MEDICAL,
      INT_CLAIM_PHARM

    )

}

package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_IMMUNIZATION extends FETableInfo[medication_map_src] {

  override def name: String = "MEDICATION_MAP_SRC_IMMUNIZATION"

  override def dependsOn: Set[String] = Set("INPUT_IMMUNIZATION", "REFERENCECODE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql("""select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, localgeneric, localbrand, localgpi, localform, localstrength, no_ndc, has_ndc, num_recs, ndc_src
                       |from
                       |(
                       |select
                       |                '{groupid}'                                                                     as groupid
                       |                ,'immunization'                                                         as datasrc
                       |                ,{client_ds_id}                                                                 as client_ds_id
                       |                ,localmedcode
                       |                ,localdescription
                       |                ,localgeneric
                       |                ,null as localndc
                       |                ,null as localbrand
                       |                ,null as localgpi
                       |                ,null as localform
                       |                ,null as localstrength
                       |                ,count(*) as no_ndc
                       |                ,0 as has_ndc
                       |                ,count(*) as num_recs
                       |                ,count(*) as ndc_src
                       |                from(
                       |                select
                       |                 mmn.code                                                                       as localmedcode
                       |                ,coalesce(mmn.product_name, rfr.display)        as localdescription
                       |                ,rfr.display                                                            as localgeneric
                       |                ,row_number() over (partition by mmn.code order by length(coalesce(mmn.product_name, rfr.display)) desc nulls first) as rw
                       |                from INPUT_IMMUNIZATION mmn
                       |                inner join REFERENCECODE rfr
                       |                on mmn.code = rfr.element_code and rfr.field = 'CODE' and  rfr.file_name = 'IMMUNIZATION'
                       |                where mmn.code is not null
                       |                )
                       |        where rw = 1
                       |        group by localmedcode, localdescription,localgeneric
                       |        )""".stripMargin
                                .replace("{groupid}", groupId)
                                .replace("{client_ds_id}", clientDsId))
  }
}

package com.optum.cdr.fe.etl.commercial.cernerasp.domains


import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.appointment
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object APPOINTMENT_CACHE extends FETableInfo[appointmentcache]{

  override def name:String = "TEMP_APPOINTMENT_CACHE"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select '{groupid}'	as groupid
         |	,{client_ds_id}	as client_ds_id
         |	,'schedules'	as datasrc
         |	,spa.unique_person_identifier	as patientid
         |	,s.unique_schedule_identifier	as appointmentid
         |	,spa.appointment_begin_date_time	as appointmentdate
         |	,s.location	as locationid
         |	,sra.unique_resource_personnel_id		as providerid
         |	,s.hum_type	as local_appt_type
         |	,s.status
         |	,row_number() over (partition by s.unique_schedule_identifier order by s.rescheduled_sequence desc nulls first, s.update_date_time desc nulls last)	as rownumber
         |from SCHEDULES s
         |	inner join SCHEDULEPERSONAPPOINTMENT spa on (spa.unique_schedule_identifier = s.unique_schedule_identifier
         |		and spa.rescheduled_sequence = s.rescheduled_sequence)
         |	left outer join SCHEDULERESOURCEAPPOINTMENT sra on (sra.unique_schedule_identifier = s.unique_schedule_identifier
         |		and sra.rescheduled_sequence = s.rescheduled_sequence)
         |where spa.unique_person_identifier is not null
         |and spa.appointment_begin_date_time is not null
         |and s.unique_schedule_identifier is not null
         |and s.location is not null
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)

    )
  }

  override def dependsOn: Set[String] = Set("SCHEDULES","SCHEDULERESOURCEAPPOINTMENT","SCHEDULEPERSONAPPOINTMENT")
}
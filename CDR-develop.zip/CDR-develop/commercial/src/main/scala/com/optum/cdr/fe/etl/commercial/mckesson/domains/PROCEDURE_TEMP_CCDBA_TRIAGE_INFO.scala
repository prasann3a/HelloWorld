package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.proceduredo
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object PROCEDURE_TEMP_CCDBA_TRIAGE_INFO extends FETableInfo[proceduredo]{
  override def name: String = "PROCEDURE_TEMP_CCDBA_TRIAGE_INFO"

  override def dependsOn: Set[String] = Set("CCDBA_TRIAGE_INFO","MCKESSON_ENT_PATIENT","MAP_CUSTOM_PROC")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |WITH uni_triage AS
         |(SELECT * FROM
         |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         | FROM CCDBA_TRIAGE_INFO p
         | WHERE pat_Seq IS NOT NULL
         |   AND Triage_Ddt IS NOT NULL )
         | WHERE rn = 1),
         | uni_pat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |   WHERE cpi_seq IS NOT NULL
         |     AND pat_Seq IS NOT NULL )
         |) WHERE rn = 1)
         |select datasrc, localcode, encounterid, patientid, proceduredate, localname, codetype, mappedcode, proceduredate as actualprocdate, facilityid, hosp_px_flag
         |from
         |(
         |SELECT 'ccdba_triage_info' AS datasrc
         |	,'CCDBA_TRIAGE_INFO' AS localcode
         |	,uni_pat.cpi_seq  AS patientid
         |	,uni_triage.Triage_Ddt  AS proceduredate
         |	,uni_pat.pat_seq  AS encounterid
         |	,NULL		  AS facilityid
         |	,NULL		  AS localname
         |	,Map.Mappedvalue  AS mappedcode
         |	,'CUSTOM'  	  AS codetype
         |	,'Y'              AS hosp_px_flag
         |	,ROW_NUMBER() OVER (PARTITION BY uni_pat.cpi_seq, uni_pat.pat_seq, uni_triage.Triage_Ddt
         |	 ORDER BY uni_triage.modified_dt DESC NULLS LAST) rn
         |FROM UNI_TRIAGE
         |   CROSS JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
         |                            map.datasrc = 'ccdba_triage_info' AND
         |   			    map.localcode = 'CCDBA_TRIAGE_INFO')
         |   JOIN UNI_PAT ON (uni_pat.pat_seq = uni_triage.pat_seq)
         |
 |)
         |where rn = 1 AND proceduredate IS NOT NULL
       """.stripMargin.replace("{groupid}",groupId))
  }
}

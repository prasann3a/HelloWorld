package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object CLAIM extends FEQueryAndMetadata[claim] {

  override def name: String = "CLAIM"

  override def dependsOn: Set[String] = Set("CLAIM_ORDERS", "CLAIM_RESULTS")

  override def sparkSql: String =
    """
      |select *
      |from
      |(
      |CLAIM_ORDERS
      |)
      |UNION ALL
      |select *
      |from
      |(
      |CLAIM_RESULTS
      |)
    """.stripMargin
}
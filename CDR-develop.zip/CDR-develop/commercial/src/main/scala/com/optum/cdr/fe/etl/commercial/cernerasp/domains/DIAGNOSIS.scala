package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object DIAGNOSIS extends FEQueryAndMetadata[diagnosis]{

  override def name: String = CDRFEParquetNames.diagnosis

  override def dependsOn: Set[String] = Set("DIAGNOSIS_CACHE_DIAGNOSIS", "DIAGNOSIS_CACHE_CHARGE", "DIAGNOSIS_CACHE_PROBLEM")

  override def sparkSql: String =
    """
      |select * from DIAGNOSIS_CACHE_DIAGNOSIS
      |UNION
      |select * from DIAGNOSIS_CACHE_CHARGE
      |UNION
      |select * from DIAGNOSIS_CACHE_PROBLEM
    """.stripMargin
}

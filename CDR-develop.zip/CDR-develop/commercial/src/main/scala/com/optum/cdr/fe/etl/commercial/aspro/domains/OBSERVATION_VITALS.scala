package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object OBSERVATION_VITALS extends FEQueryAndMetadata[observation] {

  override def name: String = "OBSERVATION_VITALS"

  override def dependsOn: Set[String] = Set("OBSERVATION_CACHE", "ZCM_OBSTYPE_CODE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, encounterid, patientid, obsdate, 'vital_weight' as localcode, 'WT' as obstype, vital_weight as localresult, {client_ds_id} as client_ds_id,
      |(select max(obstype_std_units) from ZCM_OBSTYPE_CODE where groupid = '{groupid}' and datasrc = 'vitals' and obscode='vital_weight' and obstype='WT') as std_obs_unit
      |from
      |(
      |OBSERVATION_CACHE
      |)
      |where vital_weight is not null
      |
      |union all
      |
      |select groupid, datasrc, encounterid, patientid, obsdate, 'vital_height' as localcode, 'HT' as obstype, vital_height as localresult, {client_ds_id} as client_ds_id,
      |(select max(obstype_std_units) from ZCM_OBSTYPE_CODE where groupid = '{groupid}' and datasrc = 'vitals' and obscode='vital_height' and obstype='HT') as std_obs_unit
      |from
      |(
      |OBSERVATION_CACHE
      |)
      |where vital_height is not null
      |
      |union all
      |
      |select groupid, datasrc, encounterid, patientid, obsdate, 'vital_bp_systolic' as localcode, 'SBP' as obstype, vital_bp_systolic as localresult, {client_ds_id} as client_ds_id,
      |(select max(obstype_std_units) from ZCM_OBSTYPE_CODE where groupid = '{groupid}' and datasrc = 'vitals' and obscode='vital_bp_systolic' and obstype='SBP') as std_obs_unit
      |from
      |(
      |OBSERVATION_CACHE
      |)
      |where vital_bp_systolic is not null
      |
      |union all
      |
      |select groupid, datasrc, encounterid, patientid, obsdate, 'vital_bp_diastolic' as localcode, 'DBP' as obstype, vital_bp_diastolic as localresult, {client_ds_id} as client_ds_id,
      |(select max(obstype_std_units) from ZCM_OBSTYPE_CODE where groupid = '{groupid}' and datasrc = 'vitals' and obscode='vital_bp_diastolic' and obstype='DBP') as std_obs_unit
      |from
      |(
      |OBSERVATION_CACHE
      |)
      |where vital_bp_diastolic is not null
      |
      |union all
      |
      |select groupid, datasrc, encounterid, patientid, obsdate, 'vital_pulse' as localcode, 'PULSE' as obstype, vital_pulse as localresult, {client_ds_id} as client_ds_id,
      |(select max(obstype_std_units) from ZCM_OBSTYPE_CODE where groupid = '{groupid}' and datasrc = 'vitals' and obscode='vital_pulse' and obstype='PULSE') as std_obs_unit
      |from
      |(
      |OBSERVATION_CACHE
      |)
      |where vital_pulse is not null
      |
      |union all
      |
      |select groupid, datasrc, encounterid, patientid, obsdate, 'vital_respiratn_rate' as localcode, 'RESP' as obstype, vital_respiratn_rate as localresult, {client_ds_id} as client_ds_id,
      |(select max(obstype_std_units) from ZCM_OBSTYPE_CODE where groupid = '{groupid}' and datasrc = 'vitals' and obscode='vital_respiratn_rate' and obstype='RESP') as std_obs_unit
      |from
      |(
      |OBSERVATION_CACHE
      |)
      |where vital_respiratn_rate is not null
      |
      |union all
      |
      |select groupid, datasrc, encounterid, patientid, obsdate, 'vital_pain_level' as localcode, 'PAIN' as obstype, vital_pain_level as localresult, {client_ds_id} as client_ds_id,
      |(select max(obstype_std_units) from ZCM_OBSTYPE_CODE where groupid = '{groupid}' and datasrc = 'vitals' and obscode='vital_pain_level' and obstype='PAIN') as std_obs_unit
      |from
      |(
      |OBSERVATION_CACHE
      |)
      |where vital_pain_level is not null
      |
      |union all
      |
      |select groupid, datasrc, encounterid, patientid, obsdate, 'vital_temperature' as localcode, 'TEMP' as obstype, vital_temperature as localresult, {client_ds_id} as client_ds_id,
      |(select max(obstype_std_units) from ZCM_OBSTYPE_CODE where groupid = '{groupid}' and datasrc = 'vitals' and obscode='vital_temperature' and obstype='TEMP') as std_obs_unit
      |from
      |(
      |OBSERVATION_CACHE
      |)
      |where vital_temperature is not null
    """.stripMargin

}


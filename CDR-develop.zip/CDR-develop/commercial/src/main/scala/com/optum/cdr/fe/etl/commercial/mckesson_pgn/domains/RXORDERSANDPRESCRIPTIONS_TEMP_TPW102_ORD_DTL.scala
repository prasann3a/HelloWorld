package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.{map_predicate_values, rxorder}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXORDERSANDPRESCRIPTIONS_TEMP_TPW102_ORD_DTL extends FETableInfo[rxorder]{
  override def name: String = "RXORDERSANDPRESCRIPTIONS_TEMP_TPW102_ORD_DTL"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TPW102_ORD_DTL","MCKESSON_PGN_V1_ZH_TRX800_ITEM_INVENTORY","MCKESSON_PGN_V1_TPW120_RX_DTL","MCKESSON_PGN_V1_ZH_TRX870_NDC","MCKESSON_PGN_V1_TPW100_ORD_HDR")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val uom_id_lst = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "DAYSUPPLIED","RXORDER","ORD_DTL","DPN_QNT_SFN_NO").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |
        |WITH uni_odtl AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY ppw_ord_dtl_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC nulls first) rn
        |   FROM MCKESSON_PGN_V1_TPW102_ORD_DTL v
        |  WHERE obs_ts IS NULL
        |    AND ppw_ord_hdr_int_id IS NOT NULL  )
        | WHERE rn = 1
        |   AND row_sta_cd NOT IN ('D','O')),
        |uni_invent AS
        |(SELECT * FROM
        |(SELECT i.*, ROW_NUMBER() OVER (PARTITION BY itm_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC nulls first) rn
        |   FROM MCKESSON_PGN_V1_ZH_TRX800_ITEM_INVENTORY i
        |    )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'),
        |uni_rodtl AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY prx_ord_dtl_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC nulls first) rn
        |   FROM MCKESSON_PGN_V1_TPW120_RX_DTL v
        |  WHERE prx_ord_dtl_int_id IS NOT NULL
        |    AND ppw_ord_dtl_int_id IS NOT NULL  )
        | WHERE rn = 1
        |   AND row_sta_cd NOT IN ('D','O')),
        |uni_ndc AS
        |(SELECT * FROM
        |(SELECT i.*, ROW_NUMBER() OVER (PARTITION BY itm_id ORDER BY Pri_Fg DESC nulls first, Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC nulls first) rn
        |   FROM MCKESSON_PGN_V1_ZH_TRX870_NDC i
        |    )
        | WHERE rn = 1
        |   AND row_sta_cd NOT IN ('D','O'))
        |select datasrc, issuedate, patientid, encounterid, rxid, discontinuedate, localinfusionrate, localdosefreq, localdoseunit, localform, localgenericdesc, localndc, localproviderid, ordertype, venue, localdescription, ordervsprescription, localmedcode, localroute, localstrengthperdoseunit, localstrengthunit, localtotaldose, facilityid, orderstatus, localdaw, localinfusionvolume, localqtyofdoseunit, localinfusionduration, quantityperfill, signature, fillnum, localdaysupplied
        |from
        |(
        |SELECT 'ord_dtl'       AS datasrc
        |    ,uni_rodtl.Ety_ts AS issuedate
        |    ,'P'             AS ordervsprescription
        |    ,odrh.Psn_Int_Id AS patientid
        |    ,uni_rodtl.Prx_Ord_Dtl_Int_Id  AS rxid
        |    ,odrh.Vst_Int_Id AS encounterid
        |    ,NULL            AS facilityid
        |    ,uni_odtl.Dpn_Stp_Ts  AS discontinuedate
        |    ,NULL 		  AS localinfusionrate
        |    ,NULL                 AS localinfusionvolume
        |    ,CASE WHEN uni_odtl.prn_fg = 'Y' THEN 'PRN' ELSE
        |        NVL2(uni_rodtl.feq_int_id, concat_ws('', '{client_ds_id}.', uni_rodtl.feq_int_id),NULL) END AS localdosefreq
        |    ,uni_rodtl.Dos_Unt_Ds  AS localdoseunit
        |    ,uni_invent.Gic_Nm    AS localdescription
        |    ,uni_rodtl.dos_unt_ds AS localform
        |    ,uni_invent.Gic_Nm    AS localgenericdesc
        |    ,uni_rodtl.Itm_Id     AS localmedcode
        |    ,COALESCE(uni_rodtl.Ndc_Id, uni_ndc.Ndc_Id) AS localndc
        |    ,NULL                 AS localqtyofdoseunit
        |    ,NVL2(uni_rodtl.Rte_Int_Id, concat_ws('', '{client_ds_id}.', uni_rodtl.Rte_Int_Id), NULL) AS localroute
        |    ,nullif(TRIM(nullif(regexp_replace_5param(uni_rodtl.dos_ds, '[A-Za-z%(),]+','',1,0), '')), '')   AS localstrengthperdoseunit
        |    ,COALESCE(nullif(TRIM(nullif(regexp_replace_5param(uni_rodtl.dos_ds,'[0-9.,-]+','',1,0), '')), ''), nullif(regexp_extract(uni_rodtl.dos_unt_ds,'^MG(S)?|GM(S)?|MEQ(S)?|MIL(S)?|GRAM(S)?|ML(S)?$', 0), '')) AS localstrengthunit
        |    ,odrh.Car_Gvr_Int_Id AS localproviderid
        |    ,NULL                AS orderstatus
        |    ,uni_odtl.Daw_Fg     AS localdaw
        |    ,NULL                AS localinfusionduration
        |    ,'CH002047'          AS ordertype
        |    ,NULL                AS localtotaldose
        |    ,'1'                 AS venue
        |    ,uni_odtl.Tot_Dpn_Qy AS quantityperfill
        |    ,uni_odtl.Sig_Fre_Fom_Tx AS signature
        |    ,nullif(TRIM(nullif(regexp_replace_5param(uni_odtl.dpn_rfl_tx, '[A-Za-z%(),]+','',1,0), '')), '') AS fillnum
        |    ,CASE WHEN uni_odtl.dpn_qnt_uom_id IN ({uom_id_lst}) THEN uni_odtl.dpn_qnt_sfn_no ELSE NULL END AS localdaysupplied
        |    ,ROW_NUMBER() OVER (PARTITION BY uni_rodtl.Prx_Ord_Dtl_Int_Id ORDER BY odrh.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM MCKESSON_PGN_V1_TPW100_ORD_HDR odrh
        |   JOIN UNI_ODTL ON (odrh.ppw_ord_hdr_int_id = uni_odtl.ppw_ord_hdr_int_id)
        |   JOIN UNI_RODTL ON (uni_odtl.ppw_ord_dtl_int_id = uni_rodtl.ppw_ord_dtl_int_id)
        |   LEFT OUTER JOIN UNI_INVENT ON (uni_rodtl.itm_id = uni_invent.itm_id)
        |   LEFT OUTER JOIN UNI_NDC ON (uni_invent.itm_id = uni_ndc.itm_id)
        |WHERE odrh.row_sta_cd NOT IN ('D','O')
        |  AND odrh.Psn_Int_Id IS NOT NULL
        |
        |)
        |where rxid IS NOT NULL AND rn = 1
      """
        .stripMargin.replace("{client_ds_id}",runtimeVar.clientDsId.toString).replace("{uom_id_lst}",uom_id_lst)
    )
  }


}

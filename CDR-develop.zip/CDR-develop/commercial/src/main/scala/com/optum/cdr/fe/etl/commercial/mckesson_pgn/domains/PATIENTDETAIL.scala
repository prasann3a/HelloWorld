package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.patientdetail
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTDETAIL extends FEQueryAndMetadata[patientdetail]{

override def name: String = CDRFEParquetNames.patientdetail

override def dependsOn: Set[String] = Set("TEMP_PATIENT_CACHE")

override def sparkSql: String =
  """
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,PATDETAIL_TIMESTAMP
    |       ,'FIRST_NAME' AS patientdetailtype
    |       ,firstname    AS localvalue
    |       ,client_ds_id
    |FROM
    |(
    |    TEMP_PATIENT_CACHE
    |)
    |WHERE first_row = 1
    |AND firstname is not null
    |
    |UNION ALL
    |
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,PATDETAIL_TIMESTAMP
    |       ,'LAST_NAME' AS patientdetailtype
    |       ,lastname    AS localvalue
    |       ,client_ds_id
    |FROM
    |(
    |    TEMP_PATIENT_CACHE
    |)
    |WHERE last_row = 1
    |AND lastname is not null
    |
    |UNION ALL
    |
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,PATDETAIL_TIMESTAMP
    |       ,'MIDDLE_NAME' AS patientdetailtype
    |       ,middlename    AS localvalue
    |       ,client_ds_id
    |FROM
    |(
    |    TEMP_PATIENT_CACHE
    |)
    |WHERE middle_row = 1
    |AND middlename is not null
    |
    |UNION ALL
    |
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,PATDETAIL_TIMESTAMP
    |       ,'GENDER' AS patientdetailtype
    |       ,gender   AS localvalue
    |       ,client_ds_id
    |FROM
    |(
    |    TEMP_PATIENT_CACHE
    |)
    |WHERE gender_row = 1
    |AND gender is not null
    |
    |UNION ALL
    |
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,PATDETAIL_TIMESTAMP
    |       ,'RACE' AS patientdetailtype
    |       ,race   AS localvalue
    |       ,client_ds_id
    |FROM
    |(
    |    TEMP_PATIENT_CACHE
    |)
    |WHERE race_row = 1
    |AND race is not null
    |
    |UNION ALL
    |
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,PATDETAIL_TIMESTAMP
    |       ,'MARITAL'     AS patientdetailtype
    |       ,Maritalstatus AS localvalue
    |       ,client_ds_id
    |FROM
    |(
    |    TEMP_PATIENT_CACHE
    |)
    |WHERE mstatus_row = 1
    |AND Maritalstatus is not null
    |
    |UNION ALL
    |
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,PATDETAIL_TIMESTAMP
    |       ,'ETHNICITY' AS patientdetailtype
    |       ,ethnicity   AS localvalue
    |       ,client_ds_id
    |FROM
    |(
    |    TEMP_PATIENT_CACHE
    |)
    |WHERE ethnicity_row = 1
    |AND ethnicity is not null
    |
    |UNION ALL
    |
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,PATDETAIL_TIMESTAMP
    |       ,'LANGUAGE' AS patientdetailtype
    |       ,language   AS localvalue
    |       ,client_ds_id
    |FROM
    |(
    |    TEMP_PATIENT_CACHE
    |)
    |WHERE language_row = 1
    |AND language is not null
    |
    |UNION ALL
    |
    |SELECT  groupid
    |       ,datasrc
    |       ,patientid
    |       ,PATDETAIL_TIMESTAMP
    |       ,'RELIGION'  AS patientdetailtype
    |       ,religion_cd AS localvalue
    |       ,client_ds_id
    |FROM
    |(
    |    TEMP_PATIENT_CACHE
    |)
    |WHERE religion_row = 1
    |AND religion_cd is not null
  """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_BILLINGDATA extends FEQueryAndMetadata[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_BILLINGDATA"

  override def dependsOn: Set[String] = Set("BILLINGDATA", CDRFEParquetNames.clinicalencounter, "ZH_ITEMS", "ZH_ITEMDETAIL")

  override def sparkSql: String =
    """
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,localcode
      |       ,encounterid
      |       ,patientid
      |       ,proceduredate
      |       ,hosp_px_flag
      |       ,localname
      |       ,procseq
      |       ,mappedcode
      |       ,codetype
      |       ,Sourceid
      |FROM
      |(
      |	SELECT  a.*
      |	FROM
      |	(
      |		SELECT distinct '{groupid}'                                                                    AS groupid
      |		       ,'billingdata'                                                                          AS datasrc
      |		       ,{client_ds_id}                                                                         AS client_ds_id
      |		       ,Billingdata.Itemid                                                                     AS localcode
      |		       ,Enc.Patientid                                                                          AS patientid
      |		       ,enc.arrivaltime                                                                        AS proceduredate
      |		       ,Billingdata.Encounterid                                                                AS encounterid
      |		       ,'N'                                                                                    AS hosp_px_flag
      |		       ,Zh_Items.Itemname                                                                      AS localname
      |		       ,Billingdata.Displayindex                                                               AS procseq
      |		       ,Zh_Itemdetail.Value                                                                    AS mappedcode
      |		       ,CASE WHEN rlike(Zh_Itemdetail.Value,'^[0-9]{4}[0-9A-Z]$') THEN 'CPT4'
      |		             WHEN rlike(Zh_Itemdetail.Value,'^[A-Z]{1,1}[0-9]{4}$') THEN 'HCPCS' ELSE NULL END AS codetype
      |		       ,Billingdata.Encounterid                                                                AS Sourceid
      |		       ,ROW_NUMBER() OVER (PARTITION BY Billingdata.id ORDER BY Billingdata.modifieddate DESC NULLS LAST) rn
      |		       ,Billingdata.deleteflag
      |		FROM BILLINGDATA
      |		JOIN {CLINICALENCOUNTER} enc
      |		  ON (Billingdata.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
      |		LEFT OUTER JOIN ZH_ITEMS
      |		  ON (Billingdata .ItemID = ZH_Items.ItemID)
      |		LEFT OUTER JOIN ZH_ITEMDETAIL
      |		  ON (Zh_Itemdetail.ItemID = Billingdata .ItemID AND Zh_ItemDetail.PropID = '13')
      |	) a
      |	WHERE rn = 1
      |)
      |WHERE DeleteFlag <> '1'
      |AND proceduredate IS NOT NULL
    """.stripMargin
      .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)


}

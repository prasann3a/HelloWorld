package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.oap.cdr.models.patientdetail
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENT_DETAIL extends FETableInfo [patientdetail]{

  override def name:String=CDRFEParquetNames.patientdetail

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }
    sparkSession.sql(
      s"""
         |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'FIRST_NAME' as patientdetailtype, first_name as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where first_row=1 and first_name is not null
         |
        |union all
         |
        |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'LAST_NAME' as patientdetailtype, last_name as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where last_row=1 and  last_name is not null
         |
        |union all
         |
        |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'GENDER' as patientdetailtype, gender as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where gender_row =1 and   gender is not null
         |
        |union all
         |
        |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'RACE' as patientdetailtype, race as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where race_row=1 and  race is not null
         |
        |union all
         |
        |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'ETHNICITY' as patientdetailtype, ethnicity_value as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where ethnicity_row=1 and ethnicity_value is not null
         |
        |union all
         |
        |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'DECEASED' as patientdetailtype, death_ind as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where status_row =1 and   death_ind is not null
         |
        |union all
         |
        |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'LANGUAGE' as patientdetailtype, language as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where language_row=1 and  language is not null
         |
        |union all
         |
        |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'MARITAL' as patientdetailtype, marital as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where  marital_row=1 and marital is not null
         |
        |union all
         |
        |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'MIDDLE_NAME' as patientdetailtype, middle_name as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where middle_row=1 and  middle_name is not null
         |
        |union all
         |
        |select groupid, datasrc, patientid, update_date as PATDETAIL_TIMESTAMP, 'RELIGION' as patientdetailtype, religion_cd as localvalue, client_ds_id
         |from
         |(
         |TEMP_PATIENT_CACHE
         |)
         |where religion_row=1 and  religion_cd is not null
      """.stripMargin)

  }

  override def dependsOn: Set[String] = Set("TEMP_PATIENT_CACHE")
}
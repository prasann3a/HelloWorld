package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.aspro_labresult_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE_LABRESULTS extends FEQueryAndMetadata[aspro_labresult_cache]{

  override def name: String = "LABRESULT_CACHE_LABRESULTS"

  override def dependsOn: Set[String] = Set("LABRESULTS", "LABORDERS")

  override def sparkSql: String =
    """
      |select v.*
      |       ,safe_to_number(localresult) as localresult_numeric
      |from (
      |SELECT  groupid
      |       ,datasrc
      |       ,labresultid
      |       ,laborderid
      |       ,facilityid
      |       ,encounterid
      |       ,patientid
      |       ,datecollected
      |       ,dateavailable
      |       ,resultstatus
      |       ,localresult
      |       ,localcode
      |       ,localname
      |       ,normalrange
      |       ,localunits
      |       ,statuscode
      |       ,labresult_date
      |       ,labordereddate
      |  FROM (
      |        SELECT DISTINCT
      |               '{groupid}'                     				AS groupid
      |              ,'labresults'                    			AS datasrc
      |              ,lr.result_id	      									AS labresultid
      |              ,nullif(concat_ws('', lr.observation_source, lr.observation_id), '')	AS laborderid
      |              ,NULL                         				AS facilityid
      |              ,lr.imreenc_code             	 				AS encounterid
      |              ,lr.imredem_code            					AS patientid
      |              ,lr.result_observationdate    				AS datecollected
      |              ,coalesce(lr.result_revieweddate,lr.result_observationdate)	AS dateavailable
      |              ,NULL                         				AS resultstatus
      |              ,lr.result_value   										AS localresult
      |              ,case when lr.imrelabcat_code is not null then upper(nullif(ltrim('*', nullif(trim(lr.imrelabcat_code), '')), ''))
      |               			when lr.imrelabcat_code is null and lr.external_id is not null
      |               			then nullif(substr(concat_ws('', 'ext.', nullif(trim(upper(lr.external_id)), ''), ':', nullif(trim(nullif(ltrim('*', upper(lr.result_name)), '')), '')),1,255), '') else null end as localcode
      |              ,upper(case when lr.result_name is not null then nullif(ltrim('*', lr.result_name), '')
      |              when lr.result_name is null and lr.external_id is not null then nullif(ltrim('*', lr.external_id), '') else null end)               	AS localname
      |              ,lr.result_normal_range	    					AS normalrange
      |              ,lr.result_units	 										AS localunits
      |              ,lr.result_completionstatus   				AS statuscode
      |              ,coalesce(lr.result_revieweddate,lr.result_observationdate)	AS labresult_date
      |              ,ROW_NUMBER() OVER (PARTITION BY lr.result_id,
      |              (case when lr.imrelabcat_code is not null then upper(nullif(ltrim('*', nullif(trim(lr.imrelabcat_code), '')), ''))
      |               			when lr.imrelabcat_code is null and lr.external_id is not null
      |               			then nullif(substr(concat_ws('', 'ext.', nullif(trim(upper(lr.external_id)), ''), ':', nullif(trim(nullif(ltrim('*', upper(lr.result_name)), '')), '')),1,255), '') else null end )
      |               			ORDER BY lr.tag_systemdate DESC nulls last) rownumber
      |             ,lo.laborder_orderdate                 as labordereddate
      |         FROM LABRESULTS lr
      |         LEFT OUTER JOIN LABORDERS lo on (lr.observation_id=lo.imrelaborder_code)
      |
      |        WHERE lr.tag_systemdate > TO_DATE('20050101','yyyyMMdd')
      |          AND lr.result_completionstatus = 3
      |
      |       )
      | WHERE rownumber = 1 and dateavailable is not null
      |
      |) v
    """.stripMargin
}

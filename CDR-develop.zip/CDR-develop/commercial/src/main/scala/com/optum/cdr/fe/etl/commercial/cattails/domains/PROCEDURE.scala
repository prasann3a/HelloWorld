package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROCEDURE extends FEQueryAndMetadata[proceduredo]{

  override def name: String = CDRFEParquetNames.proceduredo

  override def dependsOn: Set[String] = Set("EVENTS_VW", "PATIENT_FAC_GRP_SEG_TB", "ITEM_DETAILS_VW", "ZH_NATIONAL_CODES_TB")

  override def sparkSql: String =

  """
    |With Event as
    |(
    |select  * from (
    |select ev.patient_id,ev.Reception_Check_In_Date_Time,ev.Provider_Id,event_id,last_modified_date
    |,row_number() over (partition by Event_ID order by Last_Modified_Date desc nulls first) as rnbr
    |from EVENTS_VW ev )
    |where rnbr = 1
    |AND Patient_Id is not null
    |AND Reception_Check_In_Date_Time is not null
    |)
    |
    |,Patient_Fac as
    |(
    |Select  distinct PATIENT_ID from PATIENT_FAC_GRP_SEG_TB
    |)
    |
    |,National_Codes as
    |(
    |select
    |distinct NC.National_Code_Desc,NC.National_Code,Nc.National_Code_Type,NC.NATCODE_ID
    |From ZH_NATIONAL_CODES_TB nc
    |where (Nc.National_Code_Type = 'CPT 4') or (Nc.National_Code_Type= 'ICD 9' and rlike(Nc.national_code, '^[0-9]{2}\\.[0-9]{1,2}$'))
    |or (Nc.National_Code_Type= 'ICD 10'AND rlike(Nc.National_Code, '^[0-9A-Z]{1}[0-9A-Z]{6}'))
    |)
    |
    |select groupid, datasrc, client_ds_id, localcode, patientid, proceduredate, localname, orderingproviderid, actualprocdate, encounterid, performingproviderid, mappedcode, codetype
    |from
    |(
    |SELECT
    |        '{groupid}'                         AS groupid
    |       ,'item_details_vw'                AS datasrc
    |       ,{client_ds_id}                    AS client_ds_id
    |       ,IDV.Natcode_Id                   AS localcode
    |       ,EVE.Patient_Id                   AS patientid
    |       ,EVE.Reception_Check_In_Date_Time AS proceduredate
    |       ,NC.National_Code_Desc            AS localname
    |       ,EVE.Provider_Id                  AS orderingproviderid
    |       ,EVE.Reception_Check_In_Date_Time AS actualprocdate
    |       ,IDV.Event_Id                     AS encounterid
    |       ,EVE.Provider_Id                  AS performingproviderid
    |       ,NC.National_Code                 AS mappedcode
    |       ,case when nc.National_Code_Type = 'CPT 4' then 'CPT4'
    |             when nc.National_Code_Type = 'ICD 9' then 'ICD9'
    |             when nc.National_Code_Type = 'ICD 10' then 'ICD10'
    |             else null end AS codetype
    |       ,row_number() over (partition by eve.Patient_Id, nc.natcode_id, eve.Reception_Check_In_Date_Time
    |                               order by idv.Last_Modified_Date desc nulls first) as rnbr
    |FROM ITEM_DETAILS_VW IDV
    |INNER JOIN EVENT eve on (eve.event_id = idv.event_id)
    |INNER JOIN PATIENT_FAC pfg on (pfg.patient_id = eve.patient_id)
    |INNER JOIN NATIONAL_CODES NC ON (idv.NATCODE_ID = NC.NATCODE_ID )
    |WHERE IDV.Natcode_Id is not null
    |
    |)
    |where rnbr = 1
  """
  .stripMargin

}

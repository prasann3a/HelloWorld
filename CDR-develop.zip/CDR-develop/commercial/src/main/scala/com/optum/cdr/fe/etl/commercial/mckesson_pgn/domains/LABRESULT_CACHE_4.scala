package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.map_predicate_values
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.cdr.fe.etl.commercial.mckesson_pgn_labresult_cache
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE_4 extends FETableInfo[mckesson_pgn_labresult_cache]{
  override def name: String = "LABRESULT_CACHE_4"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_ZH_TLB800_TEST_CODE_MST","MCKESSON_PGN_V1_TOM100_ORDER_HEADER","MCKESSON_PGN_V1_TOM107_CHILD_ORDER","MCKESSON_PGN_V1_TLB280_REFLAB_DTL")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val tscodeint = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "EXCLUSION","LABRESULT","TLB280_REFLAB_DTL","TST_COD_INT_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |with  dedup_refpat_visit as ( select *
        |          from (select pv.*
        |                      ,row_number () over (partition by vst_int_id order by Lst_Mod_Ts desc nulls first, FileID desc nulls last) as rownumber
        |                from MCKESSON_PGN_V1_TPM300_PAT_VISIT pv
        |                )
        |        WHERE rownumber = 1
        |   AND nvl(row_sta_cd,'X') <> 'D' )
        |
        |,   dedup_refTest_Code as ( select *
        |          from (select cm.*
        |                      ,row_number () over (partition by tst_cod_int_id order by lst_mod_ts  desc nulls first, FileID desc nulls last) as rownumber
        |                from MCKESSON_PGN_V1_ZH_TLB800_TEST_CODE_MST cm
        |                )
        |        WHERE rownumber = 1
        |   AND nvl(row_sta_cd,'X') <> 'D' )
        |
        |,   dedup_refOrder_Header as ( select *
        |          from (select oh.*
        |                      ,row_number () over (partition by ord_int_id order by lst_mod_ts  desc nulls first, FileID desc nulls last) as rownumber
        |                from MCKESSON_PGN_V1_TOM100_ORDER_HEADER oh
        |                )
        |        WHERE rownumber = 1
        |   AND nvl(row_sta_cd,'X') <> 'D' )
        |
        |   ,   dedup_refChild_Order as ( select *
        |          from (select co.*
        |                      ,row_number () over (partition by chi_ord_int_id order by lst_mod_ts  desc nulls first, FileID desc nulls last) as rownumber
        |                from MCKESSON_PGN_V1_TOM107_CHILD_ORDER co
        |                )
        |        WHERE rownumber = 1
        |   AND nvl(row_sta_cd,'X') <> 'D' )
        |
        |
        |Select r.*,safe_to_number(localresult) as localresult_numeric
        |from
        |(
        |SELECT
        |'{groupid}' AS groupid
        |,'reflab_dtl' AS datasrc
        |,{client_ds_id} AS client_ds_id
        |,concat_ws('', 'rd.', dlb.Ref_Dtl_Int_Id) AS labresultid
        |,dlb.Tst_Cod_Int_Id  AS localcode
        |,dpv.Psn_Int_Id  AS patientid
        |,dlb.Vst_Int_Id         AS ENCOUNTERID
        |,dtc.Tst_Cod_Ds  AS localname
        |,doh.Specimen_Source_Id AS LOCALSPECIMENTYPE
        |,dtc.Tst_Cod_Abr_Cd  AS LOCALTESTNAME
        |,COALESCE(dlb.Tst_Unt_Cd,dtc.Unt_Msr_Cd)  AS LOCALUNITS
        |,dlb.Ref_Rng_Ds   AS NORMALRANGE
        |,dlb.Rsu_Ty  AS RESULTTYPE
        |,dlb.Tst_Sta_Cd    AS STATUSCODE
        |,safe_to_date_length(nullif(substr(dlb.Dta_Cd,0,19), ''),'yyyy-MM-dd HH:mm:ss',0)  AS DATEAVAILABLE
        |,coalesce(safe_to_date_length(dlb.Pfr_Bye_Int_Id,'yyyy-MM-dd HH:mm:ss',0),safe_to_date_length(dlb.Pfr_Bye_Int_Id,'yyyy-MM-dd',0))   AS LABORDEREDDATE
        |,dlb.Chi_Ord_Int_Id   AS LABORDERID
        |,dlb.Rsu_Val_Ds as localresult
        |,row_number () over (partition by dlb.ref_dtl_int_id order by dlb.lst_mod_ts  desc nulls first, dlb.FileID desc nulls last) as resw_row
        |                from MCKESSON_PGN_V1_TLB280_REFLAB_DTL dlb
        |inner join DEDUP_REFPAT_VISIT dpv on dlb.vst_int_id = dpv.vst_int_id
        |left join DEDUP_REFTEST_CODE dtc on dlb.tst_cod_int_id = dtc.tst_cod_int_id
        |left join DEDUP_REFCHILD_ORDER dco on dlb.chi_ord_int_id = dco.chi_ord_int_id
        |left join DEDUP_REFORDER_HEADER doh on dco.ord_int_id = doh.ord_int_id
        |WHERE dlb.Tst_Cod_Int_Id not in ({tscodeint})
        | AND nvl(dlb.row_sta_cd,'X') <> 'D'
        |and dlb.Dta_Cd is not null
        |
        |) r
      """
        .stripMargin
        .replace("{tscodeint}", tscodeint)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }


}

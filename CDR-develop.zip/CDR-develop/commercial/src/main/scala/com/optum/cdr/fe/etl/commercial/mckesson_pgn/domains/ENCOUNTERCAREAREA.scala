package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{encountercarearea, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ENCOUNTERCAREAREA extends FETableInfo[encountercarearea]{

override def name: String = CDRFEParquetNames.encountercarearea

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM330_VISIT_EVENT", "MCKESSON_PGN_V1_TPM300_PAT_VISIT", "MCKESSON_PGN_V1_ZH_TSM950_LOCATION_REF", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val event_list = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "VISIT_EVENT","ENCOUNTERCAREAREA","VISIT_EVENT","EVENT_TY").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
       | WITH uni_event AS (
       |SELECT  *
       |FROM
       |(
       |	SELECT  e.*
       |	       ,ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id,event_seq_no ORDER BY Lst_Mod_Ts DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_TPM330_VISIT_EVENT e
       |	WHERE Vst_Int_Id IS NOT NULL
       |	AND event_ty IN ({event_list})
       |)
       |WHERE rn = 1
       |AND row_sta_cd <> 'D' )
       |SELECT  groupid
       |       ,datasrc
       |       ,patientid
       |       ,encounterid
       |       ,encountertime
       |       ,servicecode
       |       ,facilityid
       |       ,localcareareacode
       |       ,careareastarttime
       |       ,careareaendtime
       |       ,client_ds_id
       |       ,locallocationname
       |FROM
       |(
       |	SELECT  '{groupid}'                                                                                              AS groupid
       |	       ,'visit_event'                                                                                            AS datasrc
       |	       ,{client_ds_id}                                                                                           AS client_ds_id
       |	       ,uni_event.Vst_Int_Id                                                                                     AS encounterid
       |	       ,COALESCE(safe_to_date_length(pv.arv_date_time,'yyyy-MM-dd HH:mm:ss',19),pv.adm_ts)                     AS encountertime
       |	       ,NVL2(uni_event.End_Lvl3_Int_Id,concat_ws('','{client_ds_id_prefix}',uni_event.End_Lvl3_Int_Id),NULL)     AS localcareareacode
       |	       ,pv.Psn_Int_Id                                                                                            AS patientid
       |	       ,COALESCE(LEAD(uni_event.Event_Srt_Ts) OVER (PARTITION BY uni_event.Vst_Int_Id ORDER BY uni_event.Event_Srt_Ts,uni_event.event_seq_no),uni_event.Event_Srt_Ts) AS careareaendtime
       |	       ,uni_event.Event_Srt_Ts                                                                                   AS careareastarttime
       |	       ,NULL                                                                                                     AS facilityid
       |	       ,zh.Loc_Ds                                                                                                AS locallocationname
       |	       ,NVL2(uni_event.End_Srv_Cd_Int_Id,concat_ws('','{client_ds_id_prefix}',uni_event.End_Srv_Cd_Int_Id),NULL) AS servicecode
       |	       ,ROW_NUMBER() OVER (PARTITION BY pv.Psn_Int_Id,uni_event.Vst_Int_Id,uni_event.End_Lvl3_Int_Id,uni_event.End_Srv_Cd_Int_Id ORDER BY uni_event.Lst_Mod_Ts DESC NULLS LAST) rn
       |	FROM UNI_EVENT
       |	JOIN MCKESSON_PGN_V1_TPM300_PAT_VISIT pv
       |	ON (uni_event.Vst_Int_Id = pv.Vst_Int_Id)
       |	LEFT OUTER JOIN MCKESSON_PGN_V1_ZH_TSM950_LOCATION_REF zh
       |	ON (uni_event.end_lvl3_int_id = zh.loc_int_id AND zh.Loc_Ds IS NOT NULL)
       |	WHERE pv.Psn_Int_Id IS NOT NULL
       |)
       |WHERE rn = 1
       |AND encountertime IS NOT NULL
       """
        .stripMargin
        .replace("{event_list}", event_list)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", runtimeVar.clientDsId.toString + ".")
    )
  }
}

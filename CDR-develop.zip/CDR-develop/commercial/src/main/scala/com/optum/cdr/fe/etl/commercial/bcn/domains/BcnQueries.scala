package com.optum.cdr.fe.etl.commercial.bcn.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.oap.cdr.models.zo_bpo_map_employer
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object BcnQueries extends BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] =
    InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries
}

object InitialDependencies {
  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      FELoadFromParquet[clcpv](name = "CLCPV", parquetLocation = s"$baseParquetLocation", tableName = "CLCPV", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[cldev](name = "CLDEV", parquetLocation = s"$baseParquetLocation", tableName = "CLDEV", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[eligibility](name = "ELIGIBILITY", parquetLocation = s"$baseParquetLocation", tableName = "ELIGIBILITY", ignoreExtraColumnsInDataFrame = true)
    , FELoadFromParquet[elgv](name = "ELGV", parquetLocation = s"$baseParquetLocation", tableName = "ELGV", ignoreExtraColumnsInDataFrame = true)

    , FELoadFromParquet[zo_bpo_map_employer](name = "ZO_BPO_MAP_EMPLOYER", parquetLocation = s"$mappingParquetPath", tableName = "ZO_BPO_MAP_EMPLOYER", ignoreExtraColumnsInDataFrame = true)
  )
}

object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
      ELIG_MEMID_BCN_CACHE
    , ELGV_MEMID_BCN_CACHE
    , INT_CLAIM_MEMBER
    , INT_CLAIM_MEDICAL
  )
}

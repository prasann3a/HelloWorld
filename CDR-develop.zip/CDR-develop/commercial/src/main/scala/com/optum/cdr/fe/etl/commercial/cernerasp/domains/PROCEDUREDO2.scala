package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDUREDO2 extends FETableInfo[proceduredo]{

  override def name:String= "PROCEDURE2"


  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
  }


    val list_cpt= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"CPT","PROCEDURE","REFERENCETERMINOLOGY","TERMINOLOGY").mkString(",")
    val list_icd9= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"ICD9","PROCEDURE","REFERENCETERMINOLOGY","TERMINOLOGY").mkString(",")
    val list_icd10= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"ICD10","PROCEDURE","REFERENCETERMINOLOGY","TERMINOLOGY").mkString(",")
    val list_snomed= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"SNOMED","PROCEDURE","REFERENCETERMINOLOGY","TERMINOLOGY").mkString(",")
    val list_hcpcs= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"HCPCS","PROCEDURE","REFERENCETERMINOLOGY","TERMINOLOGY").mkString(",")

    sparkSession.sql (
      s"""
         |with dedup_refterm as
         |  ( select * from (
         |       select
         |         refterm.terminology
         |        ,refterm.unique_terminology_identifier
         |        ,refterm.text
         |        ,refterm.code
         |        ,refterm.concept
         |        ,row_number() over (partition by unique_terminology_identifier order by update_date_time desc nulls last ) as rownumber
         |      from REFERENCETERMINOLOGY refterm
         |      WHERE refterm.terminology in ({list_cpt},{list_snomed},{list_hcpcs},{list_icd9},{list_icd10})
         |  ) where rownumber = 1  )
         |,  dedup_proc as
         |  ( select * from (
         |       select
         |         proc.unique_visit_identifier
         |        ,proc.unique_terminology_identifier
         |        ,proc.unique_procedure_identifier
         |        ,proc.procedure_date_time
         |        ,proc.effective_begin_date_time
         |        ,proc.ranking
         |        ,proc.update_date_time
         |        ,proc.effective_end_date_time
         |        ,row_number() over (partition by unique_terminology_identifier, proc.unique_visit_identifier, proc.unique_procedure_identifier
         |                                     order by update_date_time desc nulls last ) as rownumber
         |      from PROCEDURE proc
         |      WHERE proc.unique_terminology_identifier is not null and proc.effective_begin_date_time is not null and proc.unique_terminology_identifier <> '0'
         |            )
         |    where rownumber = 1  )
         |,
         |
         | dedup_visit as
         |  ( select * from (
         |       select
         |         visit.unique_person_identifier
         |        ,visit.unique_visit_identifier
         |        ,row_number() over (partition by unique_visit_identifier, unique_person_identifier order by update_date_time desc nulls last ) as rownumber
         |      from VISIT visit
         |      WHERE visit.unique_person_identifier is not null
         |  ) where rownumber = 1  )
         |,  dedup_procper as
         |  ( select * from (
         |       select
         |         procper.unique_personnel_identifier
         |        ,procper.unique_procedure_identifier
         |        ,row_number() over (partition by unique_personnel_identifier order by update_date_time desc nulls last ) as rownumber
         |      from PROCEDUREPERSONNEL procper
         |
         |  ) where rownumber = 1  )
         |  select groupid, datasrc, client_ds_id, encounterid, patientid, performingproviderid, proceduredate, localcode, codetype, mappedcode, localname, procseq, actualprocdate, localprincipleindicator
         |from
         |(
         |select '{groupid}'		as groupid
         |  	,'procedure'	as datasrc
         |  	,{client_ds_id}	as client_ds_id
         |  	,p.unique_visit_identifier	as encounterid
         |  	,v.unique_person_identifier	as patientid
         |  	,pp.unique_personnel_identifier	as performingproviderid
         |  	,coalesce(p.procedure_date_time,p.effective_end_date_time)	as proceduredate
         |  	,p.unique_terminology_identifier		as localcode
         |  	,case when rt.terminology in ({list_cpt}) then 'CPT4'
         |  		when rt.terminology in ({list_snomed}) then 'SNOMED'
         |  		when rt.terminology in ({list_icd9}) then 'ICD9'
         |  		when rt.terminology in ({list_icd10}) then 'ICD10'
         |  		when rt.terminology in ({list_hcpcs}) then 'HCPCS'
         |  		else null end	as codetype
         |  	,case when rt.terminology in ({list_snomed}) then nullif(ltrim('{SNOMED}', rt.concept), '')
         |  		else rt.code end	as mappedcode
         |  	,rt.text	as localname
         |  	,case when p.ranking in ('0','3310') then '1'
         |  		when p.ranking = '3311' then '2' end	as procseq
         |  	,p.procedure_date_time		as actualprocdate
         |  	,case when p.ranking in ('0','3310') then 'Y'
         |  		when p.ranking = '3311' then 'N' end	as localprincipleindicator
         |  	,row_number() over (partition by p.Unique_Terminology_Identifier,v.unique_person_identifier,p.unique_visit_identifier order by p.update_date_time desc nulls last)	as rownumber
         |  from DEDUP_PROC p
         |  	inner join DEDUP_VISIT v on (v.unique_visit_identifier = p.unique_visit_identifier)
         |  	inner join DEDUP_REFTERM rt on (p.unique_terminology_identifier = rt.unique_terminology_identifier)
         |  	left outer join DEDUP_PROCPER pp on (p.unique_procedure_identifier = pp.unique_procedure_identifier)
         |
         |)
         |where rownumber = 1
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_cpt}",list_cpt)
        .replace("{list_snomed}",list_snomed)
        .replace("{list_hcpcs}",list_hcpcs)
        .replace("{list_icd9}",list_icd9)
        .replace("{list_icd10}",list_icd10)
    )
  }



  override def dependsOn: Set[String] = Set("REFERENCETERMINOLOGY","PROCEDUREPERSONNEL","VISIT","PROCEDURE","MAP_PREDICATE_VALUES")
}

package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.oap.cdr.models.prov_client_rel
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROV_CLIENT_REL extends FEQueryAndMetadata[prov_client_rel] {

  override def name: String = CDRFEParquetNames.prov_client_rel

  override def dependsOn: Set[String] = Set("PROVIDER")

  override def sparkSql: String =
    """
      |
      |select groupid, client_ds_id, datasrc, enddate, localrelshipcode, providerid, startdate
      |from
      |(
      |select '{groupid}'                         as groupid
      |       ,{client_ds_id}                   as client_ds_id
      |       ,'provider'                      as datasrc
      |       ,enddate
      |       ,localrelshipcode
      |       ,providerid
      |       ,startdate
      |from
      |(
      |  select t.*
      |         ,row_number () over (partition by providerid order by enddate desc nulls first, startdate desc nulls first,localrelshiporder ) as provider_rank
      |  from
      |  (
      |    select
      |           case when Prov_Eff_End_Dt > current_date then null else prov_eff_end_dt end as enddate
      |           ,Case when PROV_CONTR_FLG in ('C', 'S', 'Y') then 'IN_NETWORK' else 'OUT_OF_NETWORK' end  as localrelshipcode
      |           ,Case when PROV_CONTR_FLG in ('C', 'S', 'Y') then 1 else 2 end  as localrelshiporder
      |           ,providerid
      |           ,case when date_format(Prov_Eff_Strt_Dt,'yyyy-MM-dd')='1900-01-01'
      |                 then to_date('2010-01-01' ,'yyyy-MM-dd')
      |                 else Prov_Eff_Strt_Dt  end
      |           as startdate
      |    from
      |(
      |select * from
      |(
      |select p.*,
      |stack(2,Uniq_Prov_Id,'UNIQ_PROV_ID',Src_Prov_Id,'SRC_PROV_ID') as (providerid, provider_name)
      |from
      |PROVIDER p
      |)
      |where providerid is not null
      |)
      |    where providerid is not null and Prov_Eff_End_Dt is not null and Prov_Eff_Strt_Dt is not null
      |
      |  ) t
      |) x
      |where provider_rank = 1
      |)
    """.stripMargin


}

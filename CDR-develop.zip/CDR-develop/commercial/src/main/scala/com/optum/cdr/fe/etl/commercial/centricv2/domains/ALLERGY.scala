package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.allergy
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window

object ALLERGY extends FETableInfo[allergy]{

  override def name: String = "ALLERGY"

  override def dependsOn: Set[String] = Set("CENTRICV2_PATIENTALLERGY", "CENTRICV2_DOCUMENTS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val documents = loadedDependencies("CENTRICV2_DOCUMENTS")
    //Renaming stopreason less than 5 char as it's duplicated at 3 places making sonar fail due to critical issue
    val patientAllergy=loadedDependencies("CENTRICV2_PATIENTALLERGY").withColumnRenamed("stopreason","s")

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "DOC_XID", "INCLUSION", "INCLUSION", "INCLUSION").mkString(",")
    val docXidInclusion = if(docXidInclusionMpv=="'NO_MPV_MATCHES'")  null else docXidInclusionMpv.replace("'","")

    import sparkSession.implicits._

    val groups = Window.partitionBy(documents("sdid")).orderBy(documents("db_updated_date").desc_nulls_last)
    val df = documents.withColumn("rn", row_number.over(groups))
    val doc_df = df.filter("rn = 1").drop("rn")


    val allergyDf1=
      patientAllergy.alias("pa")
        .join(doc_df.alias("doc"), Seq("pid","sdid"), "inner")
        .select(
          lit("patientallergy") as "datasrc"
          , $"pa.Allclass".as("LOCALALLERGENTYPE")
          , $"pa.Name".as("LOCALALLERGENCD")
          , coalesce($"pa.Onsetdate" , $"pa.Db_Create_Date" ).as("onsetdate")
          , $"pa.Pid".as("patientid")
          , $"pa.Sdid".as("encounterid")
          , $"pa.Name".as("localallergendesc")
          , $"pa.Gpi".as("localgpi")
          , when($"pa.Ndclabprod".isNull and $"pa.Ndcpackage".isNull, null).otherwise(concat_ws("",$"pa.Ndclabprod",$"pa.Ndcpackage")).as("localndc")
          , when($"pa.s".isNotNull, concat(lit(clientDsId), lit("."), $"pa.s")).otherwise(null).as("localstatus")
          , $"doc.xid".as("docxid")
          , $"pa.db_updated_date"
        ).filter(
             ($"pa.change".isNull or $"pa.change".isin(0,1,2))
          and ($"pa.s".isNull or $"pa.s".isin("A", "C", "O", "D", "P"))
          and $"doc.finalsign" === 1
          and $"doc.status" === "S"
          and $"onsetdate".isNotNull)

    val groups1 = Window.partitionBy(allergyDf1("PATIENTID"),allergyDf1("ONSETDATE"),allergyDf1("ENCOUNTERID"), allergyDf1("LOCALALLERGENCD"), allergyDf1("localstatus"))
      .orderBy(allergyDf1("db_updated_date").desc_nulls_last)
    val addcol_df = allergyDf1.withColumn("rn", row_number.over(groups1))
    val allergyDf = addcol_df.filter("rn = 1").drop("rn")

    if(docXidInclusion == null) allergyDf.drop("docxid") else allergyDf.filter($"docxid".cast("Decimal(38,0)").cast("String").isin(docXidInclusion)).drop("docxid")

  }

  override def cacheDataFrame: Option[StorageLevel] = None

  override def saveDataFrameToParquet: Boolean = true

}

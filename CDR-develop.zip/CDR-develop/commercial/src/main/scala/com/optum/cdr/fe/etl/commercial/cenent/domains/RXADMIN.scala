package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.rxadmin
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object RXADMIN extends FEQueryAndMetadata[rxadmin] {

  override def name: String = CDRFEParquetNames.rxadmin

  override def dependsOn: Set[String] = Set("ZH_XMEDCN", "IPPEV", "ZH_XMEDRT", "ZH_DICT31", "ZH_DICT32", "ZH_XSERVC", "ASSOCT", "SERVCE")

  override def sparkSql: String =
    """
      |WITH uni_zxm AS
      |       ( SELECT * FROM (
      |         SELECT x.*, ROW_NUMBER() OVER (PARTITION BY SERV_DESCR_NUM ORDER BY DATA_TS DESC NULLS LAST) rn
      |         FROM ZH_XMEDCN x)
      |         WHERE rn = 1 ),
      |     prejoin_ippev AS
      |        (SELECT ippev.*, zh_xmedrt.descr, Zh_Dict31.Med_Generic_Name
      |           ,zh_dict32.PROD_GENERIC_NAME_STRENGTH,zh_dict32.PROD_INGR_STRENGTH_1
      |           FROM IPPEV
      |                JOIN ZH_XMEDRT ON ippev.ippev_route_ptr = nullif(LTRIM('0', nullif(SUBSTR(zh_xmedrt.enscribe_use_seq_num,-2), '')), '')
      |                LEFT JOIN ZH_DICT31 ON (ippev.DICT21_31_33_SEQ = zh_dict31.dict_seq and ippev.DICT21_31_33_USE = '31')
      |                LEFT JOIN ZH_DICT32 ON (ippev.DICT32_SEQ_IPPEV_PROD_PTR = zh_dict32.DICT_SEQ)
      |           ),
      |      servc AS
      |        (SELECT      '{groupid}'                                                                             AS groupid
      |                     ,'servce'                                                                                 AS datasrc
      |                     ,{client_ds_id}                                                                           AS client_ds_id
      |                     ,s.pat_person_num                                                                         AS patientid
      |                     ,nullif(concat_ws('', s.pat_person_num, date_format(s.order_data_create_ts, 'yyyyMMddHHmmss'), s.serv_descr_num), '')  AS rxorderid
      |                     ,S.Beg_Dttm                                                                               AS administrationtime
      |                     ,s.encntr_num                                                                             AS encounterid
      |                     ,s.fac_num                                                                                AS facilityid
      |                     ,CASE sm.ippev_dose_units
      |                         WHEN '18' THEN 'MG'
      |			                    WHEN '23' THEN 'ML'
      |			                    WHEN '36' THEN 'UNIT'
      |			                    WHEN '33' THEN 'TAB'
      |			                    WHEN '10' THEN 'ML'
      |			                    WHEN '16' THEN 'MEQ' END                                                              AS localdoseunit
      |		                  ,sm.Chrg_Num_Units   								                                                      AS localqtyofdoseunit
      |                     ,COALESCE(uni_zxm.Nm,Zh_Xservc.Nm)                                                        AS localdrugdescription
      |                     ,s.serv_descr_num                                                                         AS localmedcode
      |                     ,sm.descr                                                                                   AS localroute
      |,coalesce(nullif(regexp_replace(nullif(regexp_extract(lower(sm.PROD_GENERIC_NAME_STRENGTH),' [-0-9.,]+ ?([-.,%/a-z0-9]+)?', 0), ''),'[- 0-9.,]+',''), ''),sm.IPPEV_DOSE_UNITS)  AS LOCALSTRENGTHUNIT
      |                     ,sm.Ippev_Amount                                                                          AS localtotaldose
      |                     ,nvl2(a.num, s.result_prov_assoc_num, NULL)                                               AS localproviderid
      |                     ,s.data_src_serv_id                                                                       AS rxadministrationid
      |                     ,uni_zxm.cde                                                                              AS localndc
      |                     ,sm.Med_Generic_Name 								                                                      AS localgenericdesc
      |,nullif(trim(nullif(regexp_extract(lower(sm.PROD_GENERIC_NAME_STRENGTH),' (24h|amp|band(age)?|cap|cr[eam]+|dr(essing)?|elix|gel|inh|inj|iv|kit|liq|oi[nlt]+|mis|patch|pac?k|pbag|pump|p[ow]+d|s[al]|sham|spr|sus|ss[uo]|syr|tab|tube|vial|\\s)+', 0), '')), '')            AS LOCALFORM
      |,coalesce(sm.PROD_INGR_STRENGTH_1,string(sm.IPPEV_AMOUNT))                                                AS LOCALSTRENGTHPERDOSEUNIT
      |       FROM SERVCE s
      |       JOIN prejoin_ippev sm
      |            ON (sm.ev_filepointer = nullif(LTRIM('0', s.data_src_serv_id), ''))
      |       LEFT JOIN uni_zxm
      |            ON (s.serv_descr_num = uni_zxm.serv_descr_num)
      |       LEFT JOIN ZH_XSERVC ON (s.serv_descr_num = zh_xservc.num)
      |       left outer join
      |       (
      |         select distinct num
      |         from ASSOCT
      |         where assoct.type_cde = 'P'
      |       ) a on s.result_prov_assoc_num = a.num
      |       WHERE s.serv_type_cde = 'MED' AND s.result_cde <> 'Not Given')
      |
      |SELECT groupid, datasrc, client_ds_id, patientid, rxorderid, administrationtime, encounterid, facilityid, localdoseunit, localndc, localdrugdescription, localmedcode, localroute, localstrengthunit, localtotaldose, localproviderid, rxadministrationid, localqtyofdoseunit, localgenericdesc, LOCALFORM, LOCALSTRENGTHPERDOSEUNIT
      |FROM
      |(
      |       SELECT
      |        servc.*
      |       ,row_number() OVER (PARTITION BY rxadministrationid ORDER BY administrationtime DESC NULLS LAST) AS rownumber
      |       FROM servc
      |)WHERE rownumber = 1
    """.stripMargin
}
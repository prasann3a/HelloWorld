package com.optum.cdr.fe.etl.commercial.med3000.domains


import com.optum.oap.cdr.models.allergy
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ALLERGY extends FEQueryAndMetadata[allergy] {

  override def name: String = CDRFEParquetNames.allergy

  override def dependsOn: Set[String] = Set("MED3000_PATIENT_ALLERGIES", "MED3000_ZH_ALG_MASTER", "MED3000_ZH_MEDICATION_MASTER")

  override def sparkSql: String =
    """
      select groupid, datasrc, client_ds_id, allergentype as localallergentype, localallergencode as localallergencd, onsetdate, patientid, localallergendescription as localallergendesc, localndc, localstatus, rxnormcode as rxnorm_code
 |from
 |(
 |select a.*,
 |       row_number() over (partition by patientid,onsetdate,localallergencode order by Update_Date desc nulls last) as rownumber
 |  from (
 |select '{groupid}' 			as groupid
 |       ,'pat_allergies' 	as datasrc
 |       ,{client_ds_id} 		as client_ds_id
 |       ,Alg.Type_Code  		as allergentype
 |       ,coalesce(Alg.Alg_Code,Alg.Alg_Description)  		as localallergencode
 |       ,coalesce(case when date_format(Alg.Diagnosis_Date,'yyyyMMdd') = '19000101' then null else Alg.Diagnosis_Date end, Alg.Create_Date ) as onsetdate
 |       ,Alg.Blind_Key  		as patientid
 |       ,Alg.Alg_Description as localallergendescription
 |       ,med.Ndc_Number  	as localndc
 |       ,Alg.Hum_Status  	as localstatus
 |       ,med.Rxcui  			as rxnormcode
 |	   ,Alg.Update_Date
 |  from MED3000_PATIENT_ALLERGIES Alg
 | inner join MED3000_ZH_ALG_MASTER mast on (Alg.Alg_Record_No = mast.Alg_Record_No)
 | left outer join MED3000_ZH_MEDICATION_MASTER med on (mast.Brand_Recno = med.Med_Brand_Recno)
 | where nvl(alg.Hum_Status,'X') <> 'E'  ) a
 |
 |
 |)
 |where rownumber = 1 and patientid is not null and onsetdate is not null
    """.stripMargin
}

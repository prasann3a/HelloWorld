package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.encountercarearea
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object ENCOUNTERCAREAREA extends FEQueryAndMetadata[encountercarearea] {

  override def name: String = CDRFEParquetNames.encountercarearea

  override def dependsOn: Set[String] = Set("ENCOUNTERCAREAREA_DISCH", "ENCOUNTERCAREAREA_TRANSFER")

  override def sparkSql: String =
    """
      |SELECT * FROM ENCOUNTERCAREAREA_DISCH
      |UNION ALL
      |SELECT * FROM ENCOUNTERCAREAREA_TRANSFER
    """.stripMargin
}
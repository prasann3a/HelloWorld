package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.patientcontact
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTCONTACT extends FEQueryAndMetadata[patientcontact]{

  override def name: String = CDRFEParquetNames.patientcontact

  override def dependsOn: Set[String] = Set("USERS", "PATIENT")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, update_dt, patientid, personal_email, home_phone, cell_phone
      |from
      |(
      |SELECT * FROM (
      |         SELECT '{groupid}' as groupid
      |                ,'users' as datasrc
      |                ,{client_ds_id} as client_ds_id
      |                ,users.mdate   AS update_dt
      |                ,Users.Hum_Uid AS patientid
      |                ,case when Users.Umobileno in ('0','000-000-0000') then null
      |                    else users.umobileno end AS cell_phone
      |                ,case when Users.Upphone in ('0','000-000-0000') then null
      |                    else  Users.Upphone end  AS home_phone
      |                ,Users.Uemail   AS personal_email
      |                ,ROW_NUMBER() OVER (PARTITION BY Users.Hum_Uid, Users.Uemail ORDER BY Users.Mdate DESC NULLS LAST) rn
      |                ,ROW_NUMBER() OVER (PARTITION BY Users.Hum_Uid ORDER BY Users.Mdate DESC NULLS LAST) rnp
      |           FROM USERS
      |           JOIN PATIENT pat ON (pat.PatientID = Users.Hum_Uid and pat.client_ds_id = {client_ds_id})
      |           WHERE USERS.USERTYPE IN ('1','3','10','4')
      |           AND   Users.Mdate IS NOT NULL
      |           AND   COALESCE(Users.upphone,Users.umobileno,Users.uemail) IS NOT NULL
      |           ) u
      |WHERE  (rn = 1 OR rnp = 1) AND
      |(COALESCE(personal_email ,home_phone ,cell_phone) IS NOT NULL)
      |)
      |where update_dt IS NOT NULL
    """.stripMargin
}

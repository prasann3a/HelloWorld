package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object PROCEDURE extends FEQueryAndMetadata[proceduredo] {

  override def name: String = "PROCEDURE"

  override def dependsOn: Set[String] = Set("PROCEDURE_ORDERS", "PROCEDURE_RESULTS")

  override def sparkSql: String =
    """
      |select *
      |from
      |(
      |PROCEDURE_ORDERS
      |)
      |UNION ALL
      |select *
      |from
      |(
      |PROCEDURE_RESULTS
      |)
    """.stripMargin

}
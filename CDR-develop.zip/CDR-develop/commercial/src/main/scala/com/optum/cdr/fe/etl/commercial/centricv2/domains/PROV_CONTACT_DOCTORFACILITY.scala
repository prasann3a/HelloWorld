package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.zh_provider_contact
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROV_CONTACT_DOCTORFACILITY extends FETableInfo[zh_provider_contact] {

  override def name: String = "PROV_CONTACT_DOCTORFACILITY"

  override def dependsOn: Set[String] = Set("CENTRICV2_ZH_DOCTORFACILITY","CENTRICV2_REGISTRATION","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }
    val whereclausempv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "INCLUSION", "PROVIDER", "PROVIDER", "PROVIDER").mkString(",")

    val constNoMpvMatches = "'NO_MPV_MATCHES'"
    val whereclausevalue = if (whereclausempv == constNoMpvMatches) "where 1=2" else "where 1=1"

    val sqlQuery =
      """
        |Select groupid, client_ds_id, datasrc, local_provider_id, email_address, update_date, address_line1, address_line2, city, state, zipcode, work_phone, local_contact_type, mapped_contact_type
        |from
        |(
        |select distinct
        |    '{groupid}' as groupid,
        |    '{client_ds_id}' as client_ds_id,
        |    'zh_doctorfacility' as datasrc,
        |    df.doctorfacilityid as local_provider_id,
        |    df.emailaddress as email_address,
        |    df.lastmodified as update_date,
        |    df.address1 as address_line1,
        |    df.address2 as address_line2,
        |    df.city as city,
        |    df.state as state,
        |    df.zip as zipcode,
        |    df.phone1 as work_phone,
        |    'PROVIDER'  as local_contact_type,
        |     null as mapped_contact_type
        |from CENTRICV2_ZH_DOCTORFACILITY df
        |join CENTRICV2_REGISTRATION reg
        |on df.doctorfacilityid=reg.pcpid
        |{where_clause}
        |)
      """.stripMargin.
        replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{where_clause}", whereclausevalue)

    sparkSession.sql(sqlQuery)
  }

}
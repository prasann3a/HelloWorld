package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.patientcontact
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENTCONTACT extends FETableInfo[patientcontact]{
  override def name:String=CDRFEParquetNames.patientcontact
  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {


    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    val list_email=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"EMAIL","PATIENT_CONTACT","ADDRESS","HUM_TYPE").mkString(",")
    val list_phone_home=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"PHONE_HOME","PATIENT_CONTACT","PHONE","HUM_TYPE").mkString(",")
    val list_phone_work=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"PHONE_WORK","PATIENT_CONTACT","PHONE","HUM_TYPE").mkString(",")
    val list_phone_cell=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"PHONE_CELL","PATIENT_CONTACT","PHONE","HUM_TYPE").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }


    sparkSession.sql(
      s"""
         |select groupid, client_ds_id, datasrc, patientid, update_dt, personal_email,null as home_phone,null as work_phone,null as cell_phone
         |from
         |(
         |select distinct '{groupid}'	as groupid
         |	,{client_ds_id}	as client_ds_id
         |	,'address'	as datasrc
         |	,a.entity_identifier	as patientid
         |	,a.update_date_time	as update_dt
         |	,case when a.hum_type in ({list_email}) then a.address_line_1
         |		else null end	as personal_email
         |from ADDRESS a
         |where a.entity_identifier is not null
         |and a.update_date_time is not null
         |and a.hum_sequence = 1
         |and a.entity_type = 'PERSON'
         |and a.hum_type in ({list_email})
         |
 |)
         |
 |union all
         |
 |select groupid, client_ds_id, datasrc, patientid, update_dt,null as personal_email, home_phone, work_phone, cell_phone
         |from
         |(
         |select distinct '{groupid}'		as groupid
         |	,{client_ds_id}	as client_ds_id
         |	,'phone'	as datasrc
         |	,p.entity_identifier	as patientid
         |	,p.update_date_time	as update_dt
         |	,case when p.hum_type in ({list_phone_home}) then nullif(regexp_replace(p.phone_number,'[^[\\\\D]]+', ''), '') else null end as home_phone
         |	,case when p.hum_type in ({list_phone_work}) then nullif(regexp_replace(p.phone_number,'[^[\\\\D]]+', ''), '') else null end as work_phone
         |	,case when p.hum_type in ({list_phone_cell}) then nullif(regexp_replace(p.phone_number,'[^[\\\\D]]+', ''), '') else null end as cell_phone
         |from PHONE p
         |where  p.entity_identifier is not null
         |		and p.update_date_time is not null
         |		and p.entity_type = 'PERSON'
         |        and p.phone_number not like '%@%'
         |        and length(p.phone_number) < 50
         |
         |)
       """.stripMargin
        .replace("{list_email}",list_email)
        .replace("{list_phone_home}",list_phone_home)
        .replace("{list_phone_work}",list_phone_work)
        .replace("{list_phone_cell}",list_phone_cell)
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
    )

  }

  override def dependsOn: Set[String] = Set("ADDRESS","PHONE","MAP_PREDICATE_VALUES")
}

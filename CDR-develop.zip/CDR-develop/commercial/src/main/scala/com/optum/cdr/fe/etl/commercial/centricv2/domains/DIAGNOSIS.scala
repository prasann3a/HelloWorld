package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object DIAGNOSIS extends FETableInfo[diagnosis] {

  import java.util.TimeZone

  System.setProperty("user.timezone", "")
  TimeZone.setDefault(null)

  override def name: String = CDRFEParquetNames.diagnosis

  override def dependsOn: Set[String] = Set("CENTRICV2_DOCUMENTS", "CENTRICV2_PATIENTPROBLEM", "CENTRICV2_PROBLEMASSESSMENT", "CENTRICV2_PROBLEMMASTERDIAGNOSIS", "MAP_PREDICATE_VALUES", "CENTRICV2_ZH_MASTERDIAGNOSIS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val noMpvString = "NO_MPV_MATCHES"
    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val listExclMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DIAGNOSIS",
      "DIAGNOSIS", "PATIENTPROBLEM", "STOPREASON").mkString(",")

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOC_XID",
      "INCLUSION", "INCLUSION", "INCLUSION").mkString(",").replace("'", "")

    val docXidInclusion = if (docXidInclusionMpv.toLowerCase() == noMpvString.toLowerCase()) "" else
      "  and d.xid in ( " + docXidInclusionMpv + " ) "

    val listExcl = if (listExclMpv.toLowerCase() == noMpvString.toLowerCase()) "" else listExclMpv

    sparkSession.sql(
      """
       select groupid, datasrc, client_ds_id, encounterid, patientid, diag_date as dx_timestamp, localdiagnosis,
        |standarddiagnosis as mappeddiagnosis, localdiagnosisstatus, activeindicator as localactiveind, resolutiondate
        |from
        |(
        |select  diag.*
        |         ,row_number() over (partition by  encounterid,patientid,localdiagnosis,date_trunc('DAY', diag_date) order by diag_date desc nulls last) rownumber
        |from (
        |select
        |'{groupid}'             				AS groupid
        |,'patprob'                  		AS datasrc
        |,{client_ds_id}                AS client_ds_id
        |,diag_date
        |,localdiagnosis
        |,patientid
        |,activeindicator
        |,encounterid
        |,localdiagnosisstatus
        |,resolutiondate
        |,standarddiagnosis
        | from
        |(
        |select unpivot_base.*,
        |stack(2,date1,'date1',date2,'date1') as (diag_date, data)
        |from
        |(SELECT
        |pa.Clinicaldate                          			  AS date1
        |,coalesce(pp.onsetdate,d.db_create_date) 			AS date2
        |,pp.Code                                 			AS localdiagnosis
        |,pp.Pid                                  			AS patientid
        |,case when pp.Stopreason is null then 'A'
        |      else pp.Stopreason end             			AS activeindicator
        |,d.Sdid                                  			AS encounterid
        |,pp.Qualifier                            			AS localdiagnosisstatus
        |,case when date_format(pp.stopdate,'yyyyMMdd') = '47001231' then null
        |      else safe_to_date(pp.stopdate,'yyyyMMddHHmmss') end   	AS resolutiondate
        |,case when M10.code is not null then M10.code
        |      when pp.code like 'ICD10-%' then nullif(substr(pp.code,7), '')
        |      when M9.code is not null then M9.code
        |      when pp.code like 'ICD9-%' then nullif(substr(pp.code,6), '')
        |      when MS.code is not null then MS.code
        |      when pp.code like 'ICD-%' then nullif(substr(pp.code,5), '')
        |      else pp.code end			                        as standarddiagnosis
        |FROM CENTRICV2_PATIENTPROBLEM pp
        |INNER JOIN CENTRICV2_DOCUMENTS d ON (d.sdid = pp.sdid and d.pid = pp.pid)
        |LEFT OUTER JOIN CENTRICV2_PROBLEMASSESSMENT pa ON (pp.sprid = pa.sprid and pp.pid = pa.pid)
        |LEFT OUTER JOIN CENTRICV2_ZH_MASTERDIAGNOSIS M9  ON (PP.ICD9MASTERDIAGNOSISID = M9.MASTERDIAGNOSISID)
        |LEFT OUTER JOIN CENTRICV2_ZH_MASTERDIAGNOSIS M10 ON (PP.ICD10MASTERDIAGNOSISID = M10.MASTERDIAGNOSISID)
        |LEFT OUTER JOIN CENTRICV2_ZH_MASTERDIAGNOSIS MS  ON (PP.SNOMEDMASTERDIAGNOSISID = MS.MASTERDIAGNOSISID)
        |   where pp.change in (0,1,2)
        |	and upper(pp.code) not like 'CPT%'
        |        and pp.qualifier in ('Hx of','Dx of','MDxof','S/P','H/F')
        |        {dox_xid_condition}
        |        and nvl(pp.stopreason,'X') not in ({list_excl_stprsn})
        |    	 ) unpivot_base
        |)) diag
        |)
        |where patientid is not null and localdiagnosis is not null and diag_date is not null and rownumber =1
    """.stripMargin
        .replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{dox_xid_condition}", docXidInclusion).
        replace("{list_excl_stprsn}", listExcl))

  }
}
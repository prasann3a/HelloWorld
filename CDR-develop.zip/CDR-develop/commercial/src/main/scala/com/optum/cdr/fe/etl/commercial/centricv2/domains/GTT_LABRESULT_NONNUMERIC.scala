package com.optum.cdr.fe.etl.commercial.centricv2.domains


import com.optum.cdr.fe.etl.commercial.centricv2_labresult_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object GTT_LABRESULT_NONNUMERIC extends FEQueryAndMetadata[centricv2_labresult_cache] {

  override def name: String = "GTT_LABRESULT_NONNUMERIC"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, labresultid, localresultcode as localcode,
      |nullif(substr(localresult, 1, 2000), '') as localresult, patientid, dateavailable as LABRESULT_DATE,
      |datecollected, dateavailable, encounterid, localresult_25, localresultname as localname,
      |localspecimensource as LOCALSPECIMENTYPE, localunits, normalrange, resulttype, local_loinc_code
      |from
      |(
      |LABRESULT_CACHE
      |)
      |where lab_row = 1 and datasrc ='results' and localresult_numeric is null
    """.stripMargin
}


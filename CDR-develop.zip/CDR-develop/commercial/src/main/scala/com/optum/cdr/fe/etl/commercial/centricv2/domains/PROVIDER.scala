package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROVIDER extends FEQueryAndMetadata[zh_provider] {

  override def name: String = "PROVIDER"

  override def dependsOn: Set[String] = Set("PROV_DOCTORFACILITY","PROV_STAFFREG")

  override def sparkSql: String =
      """
        select * from PROV_DOCTORFACILITY
        |
        |UNION ALL
        |
        |select * from PROV_STAFFREG
      """.stripMargin



}
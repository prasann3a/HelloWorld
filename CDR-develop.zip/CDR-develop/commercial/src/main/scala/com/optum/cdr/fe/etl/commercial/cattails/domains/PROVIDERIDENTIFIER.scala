package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.zh_provider_identifier
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PROVIDERIDENTIFIER extends FEQueryAndMetadata[zh_provider_identifier]{

  override def name: String = CDRFEParquetNames.zh_provider_identifier

  override def dependsOn: Set[String] = Set("PROVIDER_HISTORIES_TB")

  override def sparkSql: String =

  """
    |select groupid, client_ds_id, idtype as id_type, idvalue as id_value, providerid as provider_id
    |from
    |(
    |SELECT * FROM (
    |SELECT  z.*
    |        ,row_number() over (partition by ProviderID, IDType order by Last_Modified_Date desc nulls first, Active_Date desc nulls first, Thru_Date desc nulls last) as rownumber
    |FROM (
    |SELECT '{groupid}' as groupid,'provider_histories_tb' as datasrc
    |  ,{client_ds_id} as client_ds_id
    |  ,'NPI' AS idtype
    |  ,PHT.Cms_National_Prov_Id AS idvalue
    |  ,PHT.Provider_Id AS providerid
    |  ,PHT.LAST_MODIFIED_DATE, PHT.thru_date, PHT.active_date
    |FROM PROVIDER_HISTORIES_TB PHT
    |WHERE PHT.Cms_National_Prov_Id <> 0
    | AND PHT.Cms_National_Prov_Id is not null
    | AND PHT.Provider_Id is not null
    |
    | ) z
    | ) where rownumber=1
    |)
  """
  .stripMargin

}

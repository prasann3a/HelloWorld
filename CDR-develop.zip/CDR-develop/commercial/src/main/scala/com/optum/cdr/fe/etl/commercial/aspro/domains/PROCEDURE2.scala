package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE2 extends FEQueryAndMetadata[proceduredo]{

override def name: String = "PROCEDURE2"

override def dependsOn: Set[String] = Set("PROCEDURE_CACHE")

override def sparkSql: String =
  """
    |SELECT  groupid
    |       ,datasrc
    |       ,facilityid
    |       ,encounterid
    |       ,patientid
    |       ,sourceid
    |       ,performingproviderid
    |       ,referproviderid
    |       ,proceduredate
    |       ,procedurecodesourcetable
    |       ,localcode
    |       ,localname
    |       ,codetype
    |       ,procseq
    |       ,mappedcode
    |       ,orderingproviderid
    |       ,{client_ds_id} AS client_ds_id
    |FROM
    |( PROCEDURE_CACHE
    |)
    |WHERE rownumber=1
    |AND patientid is not null
  """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{immunization, map_predicate_values}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object IMMUNIZATION extends FETableInfo[immunization]{

  override def name: String = CDRFEParquetNames.immunization

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_ZH_TRX580_ROUTE", "MCKESSON_PGN_V1_TPP350_IMMUNIZATION_HX", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val exclStaRsn = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "IMMUNIZATION_EXC","IMMUNIZATION","IMMUNIZATION_HX","STA_RSN_CD").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |WITH uni_rte AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Rte_Int_ID ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_ZH_TRX580_ROUTE v
        |  )
        | WHERE rn = 1)
        |select groupid, datasrc, client_ds_id, localimmunizationcd, patientid, admindate, documenteddate, encounterid, localimmunizationdesc, localpatreportedflg, localroute, localdeferredreason
        |from
        |(
        |SELECT '{groupid}' AS groupid
        |	,'immunization_hx' AS datasrc
        |	,{client_ds_id} AS client_ds_id
        |	,UPPER(hx.Imm_Nm) AS localimmunizationcd
        |	,hx.Psn_Int_Id    AS patientid
        |	,hx.Ety_Ts        AS documenteddate
        |	,hx.Vst_Int_Id    AS encounterid
        |	,concat_ws('', '{client_ds_id}', '.', hx.Imm_Not_Gvn_Rsn_Int_Id) AS localdeferredreason
        |	,UPPER(hx.Imm_Nm) AS localimmunizationdesc
        |	,NULL             AS localpatreportedflg
        |	,COALESCE(hx.imm_rte_ds, uni_rte.Rte_Med_Ds)  AS localroute
        |	,hx.Imm_Ads_Dt    AS admindate
        |	,ROW_NUMBER() OVER (PARTITION BY hx.Psn_Int_Id, hx.Imm_Ads_Dt, hx.Vst_Int_Id, hx.Imm_Nm
        |	              ORDER BY hx.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM MCKESSON_PGN_V1_TPP350_IMMUNIZATION_HX hx
        |    LEFT OUTER JOIN UNI_RTE ON (Hx.Imm_Rte_Int_ID = uni_rte.Rte_Int_ID)
        |WHERE hx.Psn_Int_Id IS NOT NULL
        |  AND hx.row_sta_cd <> 'D'
        |  AND (hx.sta_rsn_cd NOT IN ({excl_sta_rsn}) OR hx.sta_rsn_cd is null)
        |  AND (hx.cvx_con_set_int_id IS NOT NULL OR hx.Imm_Ads_Dt IS NOT NULL OR hx.Imm_ads_fmt_nm IS NOT NULL)
        |
        |)
        |where rn = 1
      """.stripMargin
        .replace("{excl_sta_rsn}", exclStaRsn)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }
}

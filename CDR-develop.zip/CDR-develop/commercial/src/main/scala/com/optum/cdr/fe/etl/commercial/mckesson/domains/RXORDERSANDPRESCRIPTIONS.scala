package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.rxorder
import com.optum.oap.sparkdataloader.CDRFEParquetNames
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}

object RXORDERSANDPRESCRIPTIONS extends FEQueryAndMetadata[rxorder] {
  override def name: String = CDRFEParquetNames.rxorder

  override def dependsOn: Set[String] = Set("RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_MED_ORDER","RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_O_PAT")

  override def sparkSql: String =
  """
    |select * from RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_MED_ORDER
    |UNION ALL
    |select * from RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_O_PAT
  """.stripMargin
}

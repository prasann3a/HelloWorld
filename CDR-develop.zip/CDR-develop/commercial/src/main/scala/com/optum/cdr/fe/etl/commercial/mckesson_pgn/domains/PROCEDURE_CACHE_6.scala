package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object PROCEDURE_CACHE_6 extends FEQueryAndMetadata[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_6"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TED100_ED_VISIT","MCKESSON_PGN_V1_TED101_TRIAGE","MAP_CUSTOM_PROC")

  override def sparkSql: String =
    """
      |with uni_ed_visit AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY ed_vst_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TED100_ED_VISIT v
      | WHERE ed_vst_int_id IS NOT NULL
      |   AND Psn_Int_Id IS NOT NULL )
      | WHERE rn = 1  )
      |
      |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
      |from
      |(
      |SELECT '{groupid}'         	 AS groupid
      |      ,'triage'                  AS datasrc
      |      ,{client_ds_id}             AS client_ds_id
      |      ,'EDTRIAGE'                AS localcode
      |      ,uni_ed_visit.Psn_Int_Id   AS patientid
      |      ,tri.Tri_Start_Ts          AS proceduredate
      |      ,uni_ed_visit.Vst_Int_Id 	 AS encounterid
      |      ,NULL                      AS orderingproviderid
      |      ,'EDTRIAGE'                AS localname
      |      ,NULL              	 AS procseq
      |      ,tri.Tri_Stop_Ts           AS proc_end_date
      |      ,'Y' 			 AS hosp_px_flag
      |      ,'CUSTOM'  		 AS codetype
      |      ,NULL                      AS localprincipleindicator
      |      ,map.mappedvalue           AS mappedcode
      |      ,NULL        		 AS performingproviderid
      |      ,tri.Tri_Start_Ts          AS actualprocdate
      |      ,ROW_NUMBER() OVER (PARTITION BY uni_ed_visit.Psn_Int_Id, uni_ed_visit.Vst_Int_Id,tri.Tri_Start_Ts
      |                               ORDER BY tri.Lst_Mod_Ts DESC NULLS LAST) rn
      |FROM MCKESSON_PGN_V1_TED101_TRIAGE tri
      |   CROSS JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
      |                               map.datasrc = 'triage' AND
      |   			    map.localcode = 'EDTRIAGE')
      |   JOIN UNI_ED_VISIT ON (uni_ed_visit.ed_vst_int_id = tri.ed_vst_int_id)
      |WHERE uni_ed_visit.Psn_Int_Id IS NOT NULL
      |  AND tri.Tri_Start_Ts IS NOT NULL
      |)
      |where proceduredate IS NOT NULL AND patientid IS NOT NULL
    """.stripMargin
}

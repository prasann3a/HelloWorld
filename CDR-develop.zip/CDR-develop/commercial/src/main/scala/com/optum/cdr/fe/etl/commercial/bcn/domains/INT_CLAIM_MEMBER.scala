package com.optum.cdr.fe.etl.commercial.bcn.domains

import com.optum.oap.cdr.models.int_claim_member
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object INT_CLAIM_MEMBER extends FEQueryAndMetadata[int_claim_member]{
  override def name: String = CDRFEParquetNames.int_claim_member

  override def dependsOn: Set[String] = Set("ELIG_MEMID_BCN_CACHE", "ELGV_MEMID_BCN_CACHE", "ZO_BPO_MAP_EMPLOYER")

  override def sparkSql: String =
    """
      |WITH row_level AS
      |(
      |	SELECT  distinct concat_ws('',m.subscriber_id,'-',nullif(ltrim('0',m.member_suffix),''))                                                         AS member_id
      |	       ,CASE WHEN m.med_elig_effective_dt < m.med_elig_end_dt THEN med_elig_effective_dt
      |	             WHEN m.med_elig_effective_dt > med_elig_end_dt THEN covered_from_date  ELSE coalesce(m.med_elig_effective_dt,covered_from_date) END AS member_eff_date
      |	       ,employer_grp_subgrp_id                                                                                                                   AS emp_acct_id
      |	       ,CASE WHEN m.med_elig_end_dt > current_date THEN null
      |	             WHEN m.med_elig_effective_dt < m.med_elig_end_dt THEN m.med_elig_end_dt
      |	             WHEN m.med_elig_effective_dt > m.med_elig_end_dt THEN m.covered_through_dt  ELSE coalesce(m.med_elig_end_dt,covered_through_dt) END AS member_end_date
      |	       ,CASE WHEN m.medical_benefit IS null THEN 'N'  ELSE 'Y' END                                                                               AS medical_benefit_flag
      |	       ,CASE WHEN safe_to_date(m.pcp_end_date,'yyyyMMdd') < safe_to_date(m.pcp_effective_date,'yyyyMMdd') THEN null
      |	             WHEN m.pcp_end_date = '99991231' THEN null  ELSE safe_to_date(m.Pcp_end_Date,'yyyyMMdd') END                                        AS pcp_end_date
      |	       ,m.pcp_Npi                                                                                                                                AS pcp_id
      |	       ,m.pcp_Npi                                                                                                                                AS pcp_npi
      |	       ,safe_to_date(m.Pcp_Effective_Date,'yyyyMMdd')                                                                                            AS pcp_start_date
      |	FROM ELIG_MEMID_BCN_CACHE m
      |),
      |demos AS
      |(
      |	SELECT  *
      |	FROM
      |	(
      |		SELECT  m.gender                                                                AS member_gender_code
      |		       ,rtrim ('*',m.member_address)                                            AS member_addr_1
      |		       ,m.member_city                                                           AS member_city
      |		       ,m.birth_date                                                            AS member_dob
      |		       ,m.first_name                                                            AS member_fname
      |		       ,concat_ws('',m.subscriber_id,'-',nullif(ltrim('0',m.member_suffix),'')) AS member_id
      |		       ,m.last_name                                                             AS member_lname
      |		       ,m.middle_initial                                                        AS member_mname
      |		       ,m.mem_home_phone                                                        AS member_phone
      |		       ,m.member_state                                                          AS member_state_code
      |		       ,m.member_zip                                                            AS member_zip_code
      |		       ,row_number() over (partition by concat_ws('',m.subscriber_id,'-',nullif(ltrim('0',m.member_suffix),'')) ORDER BY transact_date desc nullS last,CASE WHEN m.med_elig_effective_dt < m.med_elig_end_dt THEN med_elig_effective_Dt WHEN m.med_elig_effective_dt > med_elig_end_dt THEN covered_from_date else coalesce(m.med_elig_effective_dt,covered_from_date) end desc nulls last) rn
      |		FROM ELIG_MEMID_BCN_CACHE m
      |	) a
      |	WHERE rn=1
      |),
      |row_level2 AS
      |(
      |	SELECT  distinct concat_ws('',m.subscriber_id,'-',nullif(ltrim('0',m.member_suffix),''))                                                              AS member_id
      |	       ,m.Med_Elig_Effective_Dt                                                                                                                       AS member_eff_date
      |	       ,Employer_Grp_Subgrp_Id                                                                                                                        AS emp_acct_id
      |	       ,CASE WHEN m.Med_Elig_end_Dt > current_date THEN NULL  ELSE m.Med_Elig_end_Dt END                                                              AS member_end_date
      |	       ,CASE WHEN m.medical_benefit IS null THEN 'N'  ELSE 'Y' END                                                                                    AS medical_benefit_flag
      |	       ,CASE WHEN m.pcp_end_date = '99991231' THEN date_add(ADD_MONTHS(date_trunc('YEAR',current_date),12),-1)  ELSE safe_to_date(m.Pcp_end_Date,'yyyyMMdd') END AS pcp_end_date
      |	       ,m.pcp_Npi                                                                                                                                     AS pcp_id
      |	       ,m.pcp_Npi                                                                                                                                     AS pcp_npi
      |	       ,safe_to_date(m.Pcp_Effective_Date,'yyyyMMdd')                                                                                                 AS pcp_start_date
      |	FROM ELGV_MEMID_BCN_CACHE m
      |),
      |demos2 AS
      |(
      |	SELECT  *
      |	FROM
      |	(
      |		SELECT  m.gender                                                                AS member_gender_code
      |		       ,rtrim ('*',m.member_address)                                            AS member_addr_1
      |		       ,m.member_city                                                           AS member_city
      |		       ,m.birth_date                                                            AS member_dob
      |		       ,m.first_name                                                            AS member_fname
      |		       ,concat_ws('',m.subscriber_id,'-',nullif(ltrim('0',m.member_suffix),'')) AS member_id
      |		       ,m.last_name                                                             AS member_lname
      |		       ,m.middle_initial                                                        AS member_mname
      |		       ,m.mem_home_phone                                                        AS member_phone
      |		       ,m.member_state                                                          AS member_state_code
      |		       ,m.member_zip                                                            AS member_zip_code
      |		       ,row_number() over (partition by concat_ws('',m.subscriber_id,'-',nullif(ltrim('0',m.member_suffix),'')) ORDER BY transact_date desc nullS last,m.Med_Elig_Effective_Dt desc nulls last) rn
      |		FROM ELGV_MEMID_BCN_CACHE m
      |	) a
      |	WHERE rn=1
      |)
      |SELECT  groupid
      |       ,client_ds_id
      |       ,datasrc
      |       ,member_id
      |       ,member_end_date
      |       ,member_dob
      |       ,member_gender_code
      |       ,member_fname
      |       ,member_lname
      |       ,member_eff_date
      |       ,emp_acct_id
      |       ,member_addr_1
      |       ,member_city
      |       ,member_state_code
      |       ,member_zip_code
      |       ,member_phone
      |       ,pcp_start_date
      |       ,pcp_end_date
      |       ,pcp_id
      |       ,pharmacy_benefit_flag
      |       ,medical_benefit_flag
      |       ,source_code
      |       ,financial_class
      |       ,payer_code
      |       ,payer_name
      |       ,plan_code
      |       ,plan_name
      |       ,pcp_npi
      |FROM
      |(
      |	SELECT  distinct '{groupid}' AS groupid
      |	       ,'eligibility'        AS datasrc
      |	       ,{client_ds_id}       AS client_ds_id
      |	       ,'Commercial'         AS financial_class
      |	       ,d.member_id          AS member_id
      |	       ,zo.employeraccountid AS payer_code
      |	       ,zo.employeraccountid AS payer_name
      |	       ,zo.employeraccountid AS plan_code
      |	       ,zo.employeraccountid AS plan_name
      |	       ,'N'                  AS pharmacy_benefit_flag
      |	       ,zo.employeraccountid AS source_code
      |	       ,r.member_eff_date
      |	       ,r.emp_acct_id
      |	       ,r.member_end_date
      |	       ,d.member_gender_code
      |	       ,r.medical_benefit_flag
      |	       ,d.member_addr_1
      |	       ,d.member_city
      |	       ,d.member_dob
      |	       ,d.member_fname
      |	       ,d.member_lname
      |	       ,d.member_mname
      |	       ,d.member_phone
      |	       ,d.member_state_code
      |	       ,d.member_zip_code
      |	       ,r.pcp_end_date
      |	       ,r.pcp_id
      |	       ,r.pcp_npi
      |	       ,r.pcp_start_date
      |	FROM DEMOS D
      |	INNER JOIN ROW_LEVEL R ON (R.member_id=D.member_id)
      |	cross JOIN ZO_BPO_MAP_EMPLOYER zo ON 1=1 AND zo.client_ds_id = {client_ds_id}
      |)
      |
      |UNION ALL
      |
      |SELECT  groupid
      |       ,client_ds_id
      |       ,datasrc
      |       ,member_id
      |       ,member_end_date
      |       ,member_dob
      |       ,member_gender_code
      |       ,member_fname
      |       ,member_lname
      |       ,member_eff_date
      |       ,emp_acct_id
      |       ,member_addr_1
      |       ,member_city
      |       ,member_state_code
      |       ,member_zip_code
      |       ,member_phone
      |       ,pcp_start_date
      |       ,pcp_end_date
      |       ,pcp_id
      |       ,pharmacy_benefit_flag
      |       ,medical_benefit_flag
      |       ,source_code
      |       ,financial_class
      |       ,payer_code
      |       ,payer_name
      |       ,plan_code
      |       ,plan_name
      |       ,pcp_npi
      |FROM
      |(
      |	SELECT  distinct '{groupid}' AS groupid
      |	       ,'elgv'               AS datasrc
      |	       ,{client_ds_id}       AS client_ds_id
      |	       ,'Commercial'         AS financial_class
      |	       ,d.member_id          AS member_id
      |	       ,zo.employeraccountid AS payer_code
      |	       ,zo.employeraccountid AS payer_name
      |	       ,zo.employeraccountid AS plan_code
      |	       ,zo.employeraccountid AS plan_name
      |	       ,'N'                  AS pharmacy_benefit_flag
      |	       ,zo.employeraccountid AS source_code
      |	       ,r.member_eff_date
      |	       ,r.emp_acct_id
      |	       ,r.member_end_date
      |	       ,d.member_gender_code
      |	       ,r.medical_benefit_flag
      |	       ,d.member_addr_1
      |	       ,d.member_city
      |	       ,d.member_dob
      |	       ,d.member_fname
      |	       ,d.member_lname
      |	       ,d.member_mname
      |	       ,d.member_phone
      |	       ,d.member_state_code
      |	       ,d.member_zip_code
      |	       ,r.pcp_end_date
      |	       ,r.pcp_id
      |	       ,r.pcp_npi
      |	       ,r.pcp_start_date
      |	FROM DEMOS2 D
      |	INNER JOIN ROW_LEVEL2 R ON (R.member_id=D.member_id)
      |	cross JOIN ZO_BPO_MAP_EMPLOYER zo ON 1=1 AND zo.client_ds_id = {client_ds_id}
      |)
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.aspro_labresult_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE_PROCRESULTS extends FEQueryAndMetadata[aspro_labresult_cache]{

  override def name: String = "LABRESULT_CACHE_PROCRESULTS"

  override def dependsOn: Set[String] = Set("PROCRESULTS", "PROCEDURES")

  override def sparkSql: String =
    """
      |select v.*
      |       ,safe_to_number(localresult) as localresult_numeric
      |from (
      |SELECT  groupid
      |       ,datasrc
      |       ,labresultid
      |       ,laborderid
      |       ,facilityid
      |       ,encounterid
      |       ,patientid
      |       ,datecollected
      |       ,dateavailable
      |       ,resultstatus
      |       ,localresult
      |       ,localcode
      |       ,localname
      |       ,normalrange
      |       ,localunits
      |       ,statuscode
      |       ,labresult_date
      |  FROM (
      |        SELECT DISTINCT
      |               '{groupid}'                     				AS groupid
      |              ,'procresults'                    		AS datasrc
      |             ,pr.result_id	      									AS labresultid
      |              ,nullif(concat_ws('', pr.observation_source, pr.observation_id), '')		AS laborderid
      |              ,NULL                         				AS facilityid
      |              ,pr.imreenc_code             	 				AS encounterid
      |              ,pr.imredem_code            					AS patientid
      |              ,pr.result_observationdate    				AS datecollected
      |              ,coalesce(pr.result_revieweddate,pr.result_observationdate)	AS dateavailable
      |              ,NULL                         				AS resultstatus
      |              ,pr.result_value   										AS localresult
      |              ,concat_ws('', 'proc.', p.proc_code) 			AS localcode
      |              ,p.proc_title               				AS localname
      |              ,pr.result_normal_range	    					AS normalrange
      |              ,pr.result_units	 										AS localunits
      |              ,pr.result_completionstatus   				AS statuscode
      |              ,coalesce(pr.result_revieweddate,pr.result_observationdate)	AS labresult_date
      |              ,ROW_NUMBER() OVER (PARTITION BY pr.imredem_code,pr.imreenc_code,concat_ws('', 'proc.', p.proc_code) ORDER BY pr.tag_systemdate DESC nulls last) rownumber
      |         FROM PROCRESULTS pr
      |         LEFT OUTER JOIN PROCEDURES p on (pr.observation_id=p.imreproc_code)
      |        WHERE pr.tag_systemdate > TO_DATE('20050101','yyyyMMdd')
      |          AND p.proc_completionstatus = 3
      |
      |       )
      | WHERE rownumber = 1 and dateavailable is not null
      |
      |) v
    """.stripMargin
}

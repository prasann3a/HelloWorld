package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.insurance
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object INSURANCE extends FEQueryAndMetadata[insurance] {

  override def name: String = CDRFEParquetNames.insurance

  override def dependsOn: Set[String] = Set("EXP_INSURANCE", "ASPRO_PATIENT", "ZH_EXP_INSURANCE")

  override def sparkSql: String =
    """
      |select datasrc, patientid, ins_timestamp, plancode, planname,
      |policynumber, plantype, insuranceorder
      |from
      |(
      |select distinct
      |        'exp_insurance' 		as datasrc
      |       ,pat.imredem_code 		as patientid
      |	      ,ai_maint_date 			as ins_timestamp
      |       ,ins.ai_ins	 				as plancode
      |       ,zi.in_name 					as planname
      |       ,ins.ai_claim 				as policynumber
      |       ,concat_ws('', 'a.', ins.dh_dept) 			as plantype
      |       ,ins.ai_seq 					as insuranceorder
      |  from EXP_INSURANCE ins
      |  inner join ASPRO_PATIENT pat on (string(ins.ai_acct) = nullif(substr(pat.dem_externalid,7,7), ''))
      |  left outer join ZH_EXP_INSURANCE zi on (ins.ai_ins = zi.in_ins)
      |  where ai_maint_date > TO_DATE('20050101','yyyyMMdd') and ai_maint_date is not null
      |
      |)
    """.stripMargin

}


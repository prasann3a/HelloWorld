package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.etl.commercial.ecw_pats_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object ECW_PATS_CACHE extends FEQueryAndMetadata[ecw_pats_cache]{

  override def name: String = "ECW_PATS_CACHE"

  override def dependsOn: Set[String] = Set("PATIENTS")

  override def sparkSql: String =
    """
      |SELECT  pid
      |       ,deceased
      |       ,deceaseddate
      |       ,race
      |       ,ethnicity
      |       ,maritalstatus
      |       ,language
      |       ,Controlno
      |       ,modifieddate
      |FROM
      |(
      |	SELECT  pat.Pid
      |	       ,pat.deceased
      |	       ,pat.deceaseddate
      |	       ,pat.race
      |	       ,pat.ethnicity
      |	       ,pat.maritalstatus
      |	       ,pat.language
      |	       ,pat.Controlno
      |	       ,MAX(pat.modifieddate) AS modifieddate
      |	FROM PATIENTS pat
      |	GROUP BY  pat.Pid
      |	         ,pat.deceased
      |	         ,pat.deceaseddate
      |	         ,pat.race
      |	         ,pat.ethnicity
      |	         ,pat.maritalstatus
      |	         ,pat.language
      |	         ,pat.Controlno
      |)
    """.stripMargin
}

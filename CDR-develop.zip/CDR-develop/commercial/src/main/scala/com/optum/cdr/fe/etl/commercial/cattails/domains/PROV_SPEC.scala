package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.prov_spec
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROV_SPEC extends FETableInfo[prov_spec]{

  override def name: String = CDRFEParquetNames.prov_spec

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES", "PROVIDER_HISTORIES_TB")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val listProvType = mpvList(mapPredicateValues, groupId, clientDsId.toString,"PROV_TYPE","PROVIDER","PROVIDER_HISTORIES_TB","PROV_TYPE_ID").mkString(",")

    sparkSession.sql(
      """
         |select groupid, localproviderid, localspecialtycode, client_ds_id
         |from
         |(
         |SELECT * FROM (
         |SELECT   z.*
         |         ,row_number() over (partition by localproviderid, SPECIALTY_ID order by Last_Modified_Date desc nulls first, Active_Date desc nulls first, Thru_Date desc nulls last) as rownumber
         |FROM (
         |SELECT '{groupid}' as groupid,'provider_histories_tb' as datasrc
         |  ,{client_ds_id} as client_ds_id
         |  ,PHT.Provider_Id AS localproviderid
         |  ,concat_ws('', {client_ds_id}, '.', PHT.Specialty_Id) AS localspecialtycode
         |  ,Last_Modified_Date, Active_Date, Thru_Date, specialty_id
         |FROM PROVIDER_HISTORIES_TB PHT
         |WHERE PHT.PROV_TYPE_ID NOT IN({list_PROV_TYPE})
         | AND PHT.Provider_Id is not null
         | AND PHT.Specialty_Id is not null
         |
         |) z
         |) where rownumber=1
         |)
      """.stripMargin
        .replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId.toString )
        .replace("{list_PROV_TYPE}", listProvType )
    )
  }

}

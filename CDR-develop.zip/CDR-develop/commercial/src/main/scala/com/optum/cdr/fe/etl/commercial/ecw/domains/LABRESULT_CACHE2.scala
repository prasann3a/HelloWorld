package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.ecw_labresult_cache
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.map_predicate_values
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object LABRESULT_CACHE2 extends FETableInfo[ecw_labresult_cache]{

  override def name: String = "LABRESULT_CACHE2"

  override def dependsOn: Set[String] = Set("VITALS", "ZH_VITALTYPES", "ZH_ITEMS", "MAP_PREDICATE_VALUES", CDRFEParquetNames.clinicalencounter)

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val vitalidMpvList = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "LABORDER", "VITALS",
      "VITALS", "VITALID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => if(!depName.equals("MAP_PREDICATE_VALUES")) df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |select  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,labresultid
        |       ,localcode
        |       ,localresult
        |       ,localresult_numeric
        |       ,patientid
        |       ,datecollected
        |       ,encounterid
        |       ,laborderid
        |       ,localname
        |       ,localtestname
        |       ,labresult_date
        |       ,dedup_row
        |from
        |(
        |  SELECT  '{groupid}'                                                                                           AS groupid
        |         ,'vitals'                                                                                              AS datasrc
        |         ,{client_ds_id}                                                                                        AS client_ds_id
        |         ,concat_ws('',vitals.id,'_',vitals.propid)                                                             AS labresultid
        |         ,vitals.vitalid                                                                                        AS localcode
        |         ,vitals.hum_value                                                                                      AS localresult
        |         ,safe_to_number(vitals.hum_value)                                                                      AS localresult_numeric
        |         ,Enc.patientid                                                                                         AS patientid
        |         ,updatedtime                                                                                           AS datecollected
        |         ,Enc.Encounterid                                                                                       AS Encounterid
        |         ,vitals.id                                                                                             AS laborderid
        |         ,CASE WHEN enc.client_ds_id = 2063 THEN 'SpO2' ELSE COALESCE(zh_vitaltypes.hum_type,zh_items.Itemname) END AS localname
        |         ,CASE WHEN enc.client_ds_id = 2063 THEN 'SpO2' ELSE COALESCE(zh_vitaltypes.hum_type,zh_items.Itemname) END AS localtestname
        |         ,enc.arrivaltime                                                                                       AS labresult_date
        |         ,row_number() over (partition by vitals.propid,vitals.id ORDER BY vitals.fileid desc nulls first)      AS dedup_row
        |  FROM VITALS vitals
        |  JOIN {CLINICALENCOUNTER} enc ON (vitals.Encounterid = enc.EncounterID)
        |  LEFT OUTER JOIN ZH_VITALTYPES zh_vitaltypes ON (vitals.vitalid = zh_vitaltypes.itemid)
        |  LEFT OUTER JOIN ZH_ITEMS ON vitals.vitalid = zh_items.itemid
        |  WHERE enc.client_ds_id = {client_ds_id}
        |  AND enc.arrivaltime IS NOT NULL
        |  AND vitals.hum_value is not null
        |  AND vitals.vitalid IN ({vitalidMpvList})
        |)
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{vitalidMpvList}", vitalidMpvList)
    )
  }


}

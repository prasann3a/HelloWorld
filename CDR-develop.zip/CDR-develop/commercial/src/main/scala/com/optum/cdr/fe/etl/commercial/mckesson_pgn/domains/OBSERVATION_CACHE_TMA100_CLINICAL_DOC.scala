package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.cdr.fe.etl.commercial.mckesson_pgn_observation_cache
import org.apache.spark.storage.StorageLevel

object OBSERVATION_CACHE_TMA100_CLINICAL_DOC extends FEQueryAndMetadata[mckesson_pgn_observation_cache]{
  override def name: String = "OBSERVATION_CACHE_TMA100_CLINICAL_DOC"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TMA100_CLINICAL_DOC","MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_TCP540_RX_ADS_INFO","MCKESSON_PGN_V1_TCP500_RX_ADS","MCKESSON_PGN_V1_TED101_TRIAGE","MCKESSON_PGN_V1_TED100_ED_VISIT","ZCM_OBSTYPE_CODE")

  override def sparkSql: String =
    """
      |WITH uni_doc AS
      |(SELECT * FROM
      |(SELECT ads_int_id, row_sta_cd, cli_doc_int_id, Lst_Mod_Ts,Spo2_Ds,Blo_Glu_Ds,Inr_Ds,
      |        nullif(Regexp_Substr(Bpr_DS, '[^/A-Za-z]*[0-9]{1,3}', 1, 1), '') AS S_BPR_DS,
      |        nullif(Regexp_Substr(Bpr_DS, '[^/-]*$', 1, 1), '') AS D_BPR_DS,
      |        nullif(Regexp_Substr(Pul_Ds,'[0-9.]+', 1, 1), '') AS PUL_DS,
      |        nullif(Regexp_Substr(Res_Ds,'[0-9.]+', 1, 1), '') AS RES_DS,
      |        nullif(Regexp_Substr(Tmp_Ds,'[0-9.]+', 1, 1), '') AS TMP_DS,
      |        nullif(Regexp_Substr(Pan_Sca_DS, '[^/A-Za-z]*[0-9]{1,2}', 1, 1), '') AS PAN_SCA_DS,
      |        ROW_NUMBER() OVER (PARTITION BY cli_doc_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TMA100_CLINICAL_DOC
      |  WHERE ads_int_id IS NOT NULL )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'  ),
      |uni_visit AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
      | WHERE Vst_Int_Id IS NOT NULL
      |   AND Psn_Int_Id IS NOT NULL )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'  ),
      |uni_info AS
      |(SELECT * FROM
      |(SELECT d.*, ROW_NUMBER() OVER (PARTITION BY ads_inf_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TCP540_RX_ADS_INFO d
      |  WHERE ads_inf_int_id IS NOT NULL
      |    AND vst_int_id IS NOT NULL )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'  ),
      |uni_ads AS
      |(SELECT * FROM
      |(SELECT a.*, ROW_NUMBER() OVER (PARTITION BY ads_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TCP500_RX_ADS a
      |  WHERE ads_int_id IS NOT NULL
      |
      |    AND ads_inf_int_id IS NOT NULL )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'  ),
      |uni_triage AS
      |(SELECT * FROM
      |(SELECT tri_Int_Id, ed_vst_int_id,Tri_Start_Ts,Lst_Mod_Ts, pat_hgt_cd, pat_wgt_cd, vit_tmp_unt_cd,
      |        pat_hgt, pat_wgt, vit_bp_sys_no, vit_bp_dia_no, vit_puls_no, vit_tmp_no, vit_rsp_no, vit_pain_no,
      |        nullif(REGEXP_SUBSTR(pain_scl_ds,'^[0-9]{1,2}', 1, 1), '') AS PAIN_SCL_DS,
      |        Vit_Pox_No, Vit_Bld_Sug_No,
      |        ROW_NUMBER() OVER (PARTITION BY tri_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TED101_TRIAGE
      |  WHERE ed_vst_int_id IS NOT NULL )
      | WHERE rn = 1  ),
      |uni_ed_visit AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY ed_vst_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC NULLS LAST) rn
      |   FROM MCKESSON_PGN_V1_TED100_ED_VISIT v
      | WHERE ed_vst_int_id IS NOT NULL
      |   AND Psn_Int_Id IS NOT NULL )
      | WHERE rn = 1  )
      |SELECT '{groupid}' 		AS groupid,
      |	'clinical_doc' 		AS datasrc
      |	,{client_ds_id} 		AS client_ds_id
      |	,uni_unpvt_doc.localresult AS localresult
      |	,concat_ws('', '{client_ds_id}', '.cd.', uni_unpvt_doc.localcode)   AS localcode
      |	,COALESCE(uni_Ads.Ads_Ts, uni_Info.Ads_Srt_Dt) AS obsdate
      |	,uni_visit.Psn_Int_Id  	AS patientid
      |	,uni_Info.Vst_Int_Id	AS encounterid
      |	,NULL		 	AS facilityid
      |	,z.obstype
      |	,z.localunit 		AS local_obs_unit
      |    	,z.obstype_std_units 	AS std_obs_unit
      |	,NULL 	                AS obsresult
      |	,ROW_NUMBER() OVER (PARTITION BY uni_visit.Psn_Int_Id,uni_Info.Vst_Int_Id,
      |	                          uni_unpvt_doc.localcode,COALESCE(uni_Ads.Ads_Ts, uni_Info.Ads_Srt_Dt),z.obstype
      |			    ORDER BY uni_unpvt_doc.Lst_Mod_Ts DESC NULLS LAST) obs_rn
      |
      |	,concat_ws('', 'cd.', uni_unpvt_doc.Cli_Doc_Int_Id) AS labresultid
      |	,safe_to_number(uni_unpvt_doc.localresult)  AS localresult_numeric
      |	,COALESCE(uni_Ads.Ads_Ts, uni_Info.Ads_Srt_Dt) AS dateavailable
      |	,uni_unpvt_doc.localcode AS localname
      |	,uni_unpvt_doc.localcode AS localtestname
      |	,z.localunit             AS localunits
      |	,uni_unpvt_doc.Lst_Mod_Ts AS labresult_date
      |	,ROW_NUMBER() OVER (PARTITION BY uni_unpvt_doc.Cli_Doc_Int_Id, z.obstype
      |                    ORDER BY uni_unpvt_doc.Lst_Mod_Ts DESC NULLS LAST) res_row
      |FROM (SELECT * from
      |(
      |select * from
      |(
      |select unpivot_base.*,
      |stack(9,S_BPR_DS,'S_BPR_DS',D_BPR_DS,'D_BPR_DS',PUL_DS,'PUL_DS',RES_DS,'RES_DS',TMP_DS,'TMP_DS',PAN_SCA_DS,'PAN_SCA_DS',Spo2_Ds,'SPO2_DS',Blo_Glu_Ds,'BLO_GLU_DS',Inr_Ds,'INR_DS') as (localresult, localcode)
      |from
      |UNI_DOC unpivot_base
      |)
      |where localresult is not null
      |)) uni_unpvt_doc
      |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
      |                                z.datasrc = 'clinical_doc' AND
      |				z.obscode = concat_ws('', '{client_ds_id}', '.cd.', uni_unpvt_doc.localcode))
      |    JOIN UNI_ADS ON (uni_unpvt_doc.ads_int_id = uni_ads.ads_int_id)
      |    JOIN UNI_INFO ON (uni_ads.ads_inf_int_id = uni_info.ads_inf_int_id)
      |    JOIN UNI_VISIT ON (uni_info.vst_int_id = uni_visit.vst_int_id)
      |
      |union all
      |
      |
      |SELECT '{groupid}' 		AS groupid,
      |	'triage' 		AS datasrc
      |	,{client_ds_id} 		AS client_ds_id
      |	,uni_unpvt_triage.localresult AS localresult
      |	,concat_ws('', '{client_ds_id}', '.tr.', uni_unpvt_triage.localcode)   AS localcode
      |	,uni_unpvt_triage.Tri_Start_Ts AS obsdate
      |	,uni_ed_visit.Psn_Int_Id       AS patientid
      |	,uni_ed_visit.Vst_Int_Id       AS encounterid
      |	,NULL		 	AS facilityid
      |	,z.obstype
      |	,CASE uni_unpvt_triage.localcode
      |	     WHEN 'PAT_HGT' THEN
      |	        CASE uni_unpvt_triage.pat_hgt_cd WHEN 'I' THEN 'in' WHEN 'C' THEN 'cm' END
      |	     WHEN 'PAT_WGT' THEN
      |	        CASE uni_unpvt_triage.pat_wgt_cd WHEN 'L' THEN 'lb' WHEN 'K' THEN 'kg' END
      |	     WHEN 'VIT_TMP_NO' THEN uni_unpvt_triage.vit_tmp_unt_cd
      |	     ELSE z.localunit   END  AS local_obs_unit
      |    	,z.obstype_std_units 	AS std_obs_unit
      |	,NULL 	                AS obsresult
      |	,ROW_NUMBER() OVER (PARTITION BY uni_ed_visit.Psn_Int_Id,uni_ed_visit.Vst_Int_Id,
      |	                          uni_unpvt_triage.localcode,uni_unpvt_triage.Tri_Start_Ts,z.obstype
      |			    ORDER BY uni_unpvt_triage.Lst_Mod_Ts DESC NULLS LAST) obs_rn
      |
      |	,concat_ws('', 'tr.', uni_unpvt_triage.tri_Int_Id) AS labresultid
      |	,safe_to_number(uni_unpvt_triage.localresult)  AS localresult_numeric
      |	,uni_unpvt_triage.Tri_Start_Ts AS dateavailable
      |	,uni_unpvt_triage.localcode AS localname
      |	,uni_unpvt_triage.localcode AS localtestname
      |	,z.localunit             AS localunits
      |	,uni_unpvt_triage.Lst_Mod_Ts AS labresult_date
      |	,ROW_NUMBER() OVER (PARTITION BY uni_unpvt_triage.tri_Int_Id, z.obstype
      |                    ORDER BY uni_unpvt_triage.Lst_Mod_Ts DESC NULLS LAST) res_row
      |FROM (SELECT * from
      |(
      |select * from
      |(
      |select unpivot_base.*,
      |stack(11,pat_hgt,'PAT_HGT',pat_wgt,'PAT_WGT',vit_bp_sys_no,'VIT_BP_SYS_NO',vit_bp_dia_no,'VIT_BP_DIA_NO',vit_puls_no,'VIT_PULS_NO',vit_tmp_no,'VIT_TMP_NO',vit_rsp_no,'VIT_RSP_NO',pain_scl_ds,'PAIN_SCL_DS',vit_pain_no,'VIT_PAIN_NO',vit_pox_no,'VIT_POX_NO',vit_bld_sug_no,'VIT_BLD_SUG_NO') as (localresult, localcode)
      |from
      |UNI_TRIAGE unpivot_base
      |)
      |where localresult is not null
      |)) uni_unpvt_triage
      |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
      |                                z.datasrc = 'triage' AND
      |				z.obscode = concat_ws('', '{client_ds_id}', '.tr.', uni_unpvt_triage.localcode))
      |    JOIN UNI_ED_VISIT ON (uni_unpvt_triage.ed_vst_int_id = uni_ed_visit.ed_vst_int_id)
    """.stripMargin



}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{rxadmin, map_predicate_values, patient}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object RXADMIN extends FETableInfo[rxadmin] {

  override def name: String = CDRFEParquetNames.rxadmin

  override def dependsOn: Set[String] = Set("IMMUNIZATIONS", "PATIENT", "ZH_ITEMS", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    loadedDependencies("IMMUNIZATIONS").as[immunizations].createOrReplaceTempView("IMMUNIZATIONS")
    loadedDependencies("ZH_ITEMS").as[zh_items].createOrReplaceTempView("ZH_ITEMS")
    loadedDependencies("PATIENT").as[patient].createOrReplaceTempView("PATIENT")

    val predicate_values = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val column_valueDf = mpvList(predicate_values, runtimeVar.groupId, runtimeVar.clientDsId.toString, "RXORDER", "RXORDER AND PRESCRIPTIONS", "ZH_ITEMS"
      , "PARENTID").mkString(",")

    sparkSession.sql(
      """
    WITH dedup_immu AS
 |(SELECT * FROM (
 |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY immunizationid ORDER BY modifieddate DESC NULLS LAST) rn
 |      FROM IMMUNIZATIONS i
 |      WHERE DELETEFLAG <> '1' and itemid not in ('0', '-1'))
 |WHERE rn = 1)
 |select groupid, datasrc, client_ds_id, localmedcode, patientid, administrationtime, encounterid, localroute, rxorderid, rxadministrationid, localdrugdescription, localstrengthperdoseunit, localstrengthunit, localtotaldose, localproviderid
 |from
 |(
 |SELECT '{groupid}' as groupid
 |,'immunizations' as datasrc
 |,{client_ds_id} as client_ds_id
 |,dedup_immu.Itemid  AS localmedcode
 |,dedup_immu.Patientid  AS patientid
 |,case when dedup_immu.Encounterid = '0' then null
 |      else dedup_immu.Encounterid end AS encounterid
 |,dedup_immu.Route  AS localroute
 |,dedup_immu.Immunizationid  AS rxorderid
 |,dedup_immu.Immunizationid  AS rxadministrationid
 |,Zh_Items.Itemname  AS localdrugdescription
 |,nullif(trim(nullif(regexp_extract(dedup_immu.Dose,'(\\.|\\/|-|\\s|[0-9])+', 0), '')), '')     AS localstrengthperdoseunit
 |,nullif(trim(nullif(regexp_replace_5param(dedup_immu.Dose,'(\\.|\\/|-|\\s|[()0-9])+','', 1,1), '')), '')  AS localstrengthunit
 |,dedup_immu.Dose  AS localtotaldose
 |,NULLIF(dedup_immu.Givenbyid,'0')  AS localproviderid
 |,safe_to_date(nullif(concat_ws('', date_format(dedup_immu.Givendate, 'yyyy-MM-dd'), coalesce(dedup_immu.Giventime, '00:00:00')), ''),
 |'yyyy-MM-ddHH:mm:ss') AS administrationtime
 |FROM DEDUP_IMMU
 |    JOIN PATIENT c ON (dedup_immu.patientid = c.patientid AND
 |                                                c.client_ds_id = {client_ds_id})
   |    JOIN ZH_ITEMS ON (dedup_immu.ItemID = zh_items.itemid AND zh_items.parentid in ({column_valueDf}))
 |
 |)

  """.stripMargin
        .replace("{column_valueDf}", column_valueDf)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )

  }

}
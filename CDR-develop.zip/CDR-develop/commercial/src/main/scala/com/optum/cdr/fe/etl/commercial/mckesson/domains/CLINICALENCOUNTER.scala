package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.clinicalencounter
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader,CDRFEParquetNames}
import org.apache.spark.sql.{DataFrame, SparkSession}

object CLINICALENCOUNTER extends FETableInfo[clinicalencounter] {
  override def name: String = CDRFEParquetNames.clinicalencounter


  override def dependsOn: Set[String] = Set("MCKESSON_ENT_PATIENT", "MAP_PREDICATE_VALUES")


  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val cnclListMpMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "ENT_PATIENT", "CLINICALENCOUNTER", "ENT_PATIENT", "CANCEL_REASON_LSEQ").mkString(",")

    sparkSession.sql(
      s"""
       WITH clinicalencounter_unfiltered AS
       (
          SELECT 'ent_patient'  AS datasrc
            ,COALESCE(admit_dt, transfer_dt, discharge_dt, created_dt) AS arrivaltime
            ,Pat_Seq	    AS encounterid
            ,cpi_Seq  	  AS patientid
            ,admit_dt	    AS admittime
            ,patient_id	  AS alt_encounterid
            ,discharge_dt AS dischargetime
            ,facility_id  AS facilityid
            ,NVL2(Admit_Source, concat_ws('','$clientDsId', '.' ,admit_source), NULL)                    AS localadmitsource
            ,NVL2(Discharge_Disposition, concat_ws('', '$clientDsId', '.', Discharge_Disposition), NULL) AS localdischargedisposition
            ,NVL2(Pat_Type_Group_Lseq, concat_ws('', '$clientDsId','.',pat_type_group_lseq,'-',patient_type_seq,'-',service), NULL)  AS localpatienttype
            ,ROW_NUMBER() OVER (PARTITION BY Pat_Seq ORDER BY modified_dt DESC NULLS LAST) rn
          FROM MCKESSON_ENT_PATIENT
          WHERE  (cancel_reason_lseq IS NULL OR  cancel_reason_lseq NOT IN ( $cnclListMpMpv )
                  )
            AND  Cpi_Seq IS NOT NULL
            AND  Pat_Seq IS NOT NULL
        )
        SELECT
          datasrc,
          arrivaltime,
          encounterid,
          patientid,
          facilityid,
          localpatienttype,
          admittime,
          alt_encounterid,
          dischargetime,
          localadmitsource,
          localdischargedisposition
        FROM clinicalencounter_unfiltered
        WHERE rn = 1
          AND arrivaltime IS NOT NULL
    """.stripMargin)

  }

}

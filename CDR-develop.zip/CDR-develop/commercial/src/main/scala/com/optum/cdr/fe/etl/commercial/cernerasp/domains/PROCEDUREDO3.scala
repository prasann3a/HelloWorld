package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDUREDO3 extends FETableInfo[proceduredo]{

  override def name:String="PROCEDURE3"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }


    sparkSession.sql(
      s"""
         |with   dedup_proc as
         |  ( select * from (
         |       select
         |         proc.unique_visit_identifier
         |        ,proc.unique_terminology_identifier
         |        ,proc.unique_procedure_identifier
         |        ,proc.procedure_date_time
         |        ,proc.effective_begin_date_time
         |        ,proc.ranking
         |        ,proc.update_date_time
         |        ,proc.effective_end_date_time
         |        ,proc.note
         |        ,row_number() over (partition by unique_terminology_identifier, proc.unique_visit_identifier, proc.unique_procedure_identifier
         |                                     order by update_date_time desc nulls last ) as rownumber
         |      from PROCEDURE proc
         |      WHERE proc.unique_terminology_identifier is not null and proc.effective_begin_date_time is not null and proc.unique_terminology_identifier = '0'
         |            )
         |    where rownumber = 1  )
         |,  dedup_visit as
         |  ( select * from (
         |       select
         |         visit.unique_person_identifier
         |        ,visit.unique_visit_identifier
         |        ,row_number() over (partition by unique_visit_identifier, unique_person_identifier order by update_date_time desc nulls last ) as rownumber
         |      from VISIT visit
         |      WHERE visit.unique_person_identifier is not null
         |  ) where rownumber = 1  )
         |  select groupid, datasrc, client_ds_id, encounterid, patientid, performingproviderid, proceduredate, localcode, codetype, mappedcode, localname, procseq, actualprocdate, localprincipleindicator
         |from
         |(
         |select '{groupid}'		as groupid
         |  	,'procedure_custom'	as datasrc
         |  	,{client_ds_id}	as client_ds_id
         |  	,p.unique_visit_identifier	as encounterid
         |  	,v.unique_person_identifier	as patientid
         |  	,pp.unique_personnel_identifier	as performingproviderid
         |  	,coalesce(p.procedure_date_time,p.effective_end_date_time)	as proceduredate
         |  	,concat_ws('', '{client_ds_id}', '.', p.note)		as localcode
         |  	,'CUSTOM'	as codetype
         |  	,mcp.mappedvalue as mappedcode
         |  	,p.note	as localname
         |  	,case when p.ranking in ('0','3310') then '1'
         |  		when p.ranking = '3311' then '2' end	as procseq
         |  	,p.procedure_date_time		as actualprocdate
         |  	,case when p.ranking in ('0','3310') then 'Y'
         |  		when p.ranking = '3311' then 'N' end	as localprincipleindicator
         |  	,row_number() over (partition by p.Unique_Terminology_Identifier,v.unique_person_identifier,p.unique_visit_identifier order by p.update_date_time desc nulls last)	as rownumber
         |  from DEDUP_PROC p
         |  	inner join DEDUP_VISIT v on (v.unique_visit_identifier = p.unique_visit_identifier)
         |  	inner join MAP_CUSTOM_PROC mcp on (mcp.groupid = '{groupid}'
         |  	     and mcp.datasrc = 'procedure_custom'
         |  	     and mcp.localcode= concat_ws('', '{client_ds_id}', '.', p.note))
         |  	left outer join PROCEDUREPERSONNEL pp on (p.unique_procedure_identifier = pp.unique_procedure_identifier)
         |
         |
         |
         |
         |
         |
         |)
         |where rownumber = 1
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId))
  }




  override def dependsOn: Set[String] = Set("PROCEDURE","PROCEDUREPERSONNEL","VISIT","MAP_CUSTOM_PROC")
}

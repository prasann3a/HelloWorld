package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{diagnosis, map_predicate_values}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object DIAGNOSIS_CACHE_DIAGNOSIS extends FETableInfo[diagnosis]{

  override def name: String = "DIAGNOSIS_CACHE_DIAGNOSIS"

  override def dependsOn: Set[String] = Set("INPUT_DIAGNOSIS", "REFERENCETERMINOLOGY", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listIcd9 = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "ICD9","DIAGNOSIS","DIAGNOSIS","TERMINOLOGY").mkString(",")
    val listIcd10 = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "ICD10","DIAGNOSIS","DIAGNOSIS","TERMINOLOGY").mkString(",")
    val listSnomed = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "SNOMED","DIAGNOSIS","DIAGNOSIS","TERMINOLOGY").mkString(",")
    val listHumType = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "HUM_TYPE","DIAGNOSIS","DIAGNOSIS","HUM_TYPE").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,client_ds_id
        |       ,datasrc
        |       ,patientid
        |       ,encounterid
        |       ,localdiagnosis
        |       ,dx_timestamp
        |       ,mappeddiagnosis
        |       ,localdiagnosisproviderid
        |       ,codetype
        |FROM
        |(
        |	SELECT  '{groupid}'                                                                                                  AS groupid
        |	       ,{client_ds_id}                                                                                               AS client_ds_id
        |	       ,'diagnosis'                                                                                                  AS datasrc
        |	       ,d.unique_person_identifier                                                                                   AS patientid
        |	       ,d.unique_visit_identifier                                                                                    AS encounterid
        |	       ,d.unique_terminology_identifier                                                                              AS localdiagnosis
        |	       ,d.diagnosis_date_time                                                                                        AS dx_timestamp
        |	       ,CASE WHEN rt.terminology IN ({list_snomed}) THEN nullif(ltrim('{SNOMED}',rt.concept),'') ELSE rt.code END    AS mappeddiagnosis
        |	       ,d.diagnosis_by                                                                                               AS localdiagnosisproviderid
        |	       ,CASE WHEN rt.terminology IN ({list_snomed}) THEN 'SNOMED'
        |	             WHEN rt.terminology IN ({list_icd9}) THEN 'ICD9' WHEN rt.terminology IN ({list_icd10}) THEN 'ICD10' END AS codetype
        |	       ,row_number() over (partition by d.unique_person_identifier,d.unique_terminology_identifier,d.diagnosis_date_time ORDER BY d.update_date_time desc nulls last) AS rownumber
        |	FROM INPUT_DIAGNOSIS d
        |	INNER JOIN REFERENCETERMINOLOGY rt ON (rt.unique_terminology_identifier = d.unique_terminology_identifier)
        |	WHERE d.unique_person_identifier is not null
        |	AND d.unique_terminology_identifier is not null
        |	AND d.diagnosis_date_time is not null
        |	AND d.active <> '0'
        |	AND rt.terminology IN ({list_snomed},{list_icd9},{list_icd10})
        |	AND d.hum_type IN ({list_hum_type})
        |)
        |WHERE rownumber = 1
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{list_icd9}", listIcd9)
        .replace("{list_icd10}", listIcd10)
        .replace("{list_snomed}", listSnomed)
        .replace("{list_hum_type}", listHumType)
    )
  }


}

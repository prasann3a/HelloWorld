package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, observation}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_SOCIAL extends FETableInfo[observation]{

  override def name: String = "OBSERVATION_SOCIAL"

  override def dependsOn: Set[String] = Set("SOCIAL", CDRFEParquetNames.clinicalencounter, "ZCM_OBSTYPE_CODE", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()

    val listItemidSocial = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "SOCIAL", "OBSERVATION",
      "SOCIAL", "ITEMID").mkString(",")
    val listItemidObservation = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "SOCIAL", "OBSERVATION",
      "OBSERVATION", "ITEMID").mkString(",")

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,encounterid
        |       ,patientid
        |       ,obsdate
        |       ,localcode
        |       ,localresult
        |       ,obstype
        |       ,null              AS obsresult
        |       ,local_obs_unit
        |       ,obstype_std_units AS std_obs_unit
        |FROM
        |(
        |	SELECT  a.*
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                                                        AS groupid
        |		       ,'social'                                                                                                           AS datasrc
        |		       ,{client_ds_id}                                                                                                     AS client_ds_id
        |		       ,CASE WHEN social.itemid IN ({list_itemid_social}) THEN 'Completed'
        |		             WHEN social.itemid = '318681' AND (social.propid = '91' or social.propid = '83') THEN nullif(SUBSTR(social.hum_value,INSTR(social.hum_value,':')+3,(INSTR(social.hum_value,'smoke')+3 - INSTR(social.hum_value,':')+1)),'')
        |		             WHEN social.itemid IN ({list_itemid_observation}) THEN nullif(regexp_extract(nullif(SUBSTR(Hum_Value,60,150),''),'^[^,]*,[^,]*',0),'')
        |		             WHEN social.propid = '91' AND social.hum_value is not null THEN nullif(SUBSTR(Social.Hum_Value,1,255),'')
        |		             WHEN social.propid = '83' AND social.hum_value is not null THEN nullif(SUBSTR(Social.Hum_Value,1,255),'') END AS localresult
        |		       ,concat_ws('','{client_ds_id_prefix}',Social.Itemid)                                                                AS localcode
        |		       ,cEnc.arrivaltime                                                                                                   AS obsdate
        |		       ,cEnc.Patientid                                                                                                     AS patientid
        |		       ,Social.Encounterid                                                                                                 AS encounterid
        |		       ,z.obstype
        |		       ,z.obsregex
        |		       ,z.obsconvfactor
        |		       ,z.datatype
        |		       ,z.begin_range
        |		       ,z.end_range
        |		       ,z.ROUND_PREC
        |		       ,z.localunit                                                                                                        AS local_obs_unit
        |		       ,z.obstype_std_units
        |		       ,z.localunit_cui
        |		       ,z.conv_fact
        |		       ,z.function_applied
        |		       ,ROW_NUMBER() OVER (PARTITION BY cEnc.Patientid,social.Encounterid,z.obscode,z.obstype,cEnc.arrivaltime ORDER BY social.modifieddate DESC NULLS LAST) rn
        |		FROM SOCIAL
        |		JOIN {CLINICALENCOUNTER} cEnc
        |			ON (social.encounterid = cEnc.encounterid AND cEnc.client_ds_id = {client_ds_id})
        |		JOIN ZCM_OBSTYPE_CODE z
        |			ON (z.obscode = concat_ws('', '{client_ds_id_prefix}', social.Itemid) AND z.groupid = '{groupid}' AND z.datasrc = 'social')
        |		WHERE social.hum_value IS NOT NULL
        |	) a
        |	WHERE rn = 1
        |)
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{list_itemid_social}", listItemidSocial)
        .replace("{list_itemid_observation}", listItemidObservation)
    )
  }


}


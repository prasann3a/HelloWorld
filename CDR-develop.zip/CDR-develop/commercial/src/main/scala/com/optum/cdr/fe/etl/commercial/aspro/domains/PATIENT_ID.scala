package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.patient_id
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT_ID extends FEQueryAndMetadata[patient_id]{

  override def name: String = CDRFEParquetNames.patient_id

  override def dependsOn: Set[String] = Set("PATIENT_CACHE")

  override def sparkSql: String =
    """
      |select '{groupid}' as groupid, 'patient' as datasrc, patientid, 'SSN' as idtype, ssn as idvalue, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where ssn_row = 1  and ssn is not null
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.allergy
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ALLERGY extends FEQueryAndMetadata[allergy]{

  override def name: String = CDRFEParquetNames.allergy

  override def dependsOn: Set[String] = Set("INPUT_ALLERGIES", "ENC", "ZH_ITEMS", CDRFEParquetNames.patient)

  override def sparkSql: String =
    """
      |WITH dedup_allergy AS (
      |SELECT  *
      |FROM
      |(
      |	SELECT  a.*
      |	       ,ROW_NUMBER() OVER (PARTITION BY nullif(concat_ws('',Encounterid,DisplayIndex,Drug),'') ORDER BY modifieddate DESC NULLS LAST) rn
      |	FROM INPUT_ALLERGIES a
      |)
      |WHERE rn = 1),
      |
      |dedup_enc AS (
      |SELECT  *
      |FROM
      |(
      |	SELECT  b.*
      |	       ,ROW_NUMBER() OVER (PARTITION BY b.Encounterid ORDER BY b.ModifiedDate DESC NULLS LAST,b.fileid DESC NULLS LAST) rn
      |	FROM ENC b
      |)
      |WHERE rn = 1)
      |
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,localallergencd
      |       ,onsetdate
      |       ,patientid
      |       ,encounterid
      |       ,localallergendesc
      |       ,localndc
      |       ,localstatus
      |       ,localallergentype
      |FROM
      |(
      |	SELECT  distinct '{groupid}'                                                                    AS groupid
      |	       ,'allergies'                                                                             AS datasrc
      |	       ,{client_ds_id}                                                                          AS client_ds_id
      |	       ,CASE WHEN Allergies.ItemID IN ('0','-1') THEN Allergies.Drug ELSE allergies.itemid END  AS localallergencd
      |	       ,coalesce(Allergies.Modifieddate,Enc.enc_date)                                           AS onsetdate
      |	       ,Allergies.Patientid                                                                     AS patientid
      |	       ,Allergies.Encounterid                                                                   AS encounterid
      |	       ,CASE WHEN Allergies.ItemID IN ('0','-1') THEN Allergies.Drug ELSE zh_items.itemname END AS localallergENDesc
      |	       ,Allergies.Ndc_Code                                                                      AS localndc
      |	       ,Allergies.Status                                                                        AS localstatus
      |	       ,'Other'                                                                                 AS localallergentype
      |	FROM
      |	(
      |		SELECT  da.*
      |		FROM DEDUP_ALLERGY da
      |		JOIN {PATIENT} c
      |		ON (da.patientid = c.patientid AND c.client_ds_id = {client_ds_id})
      |	) allergies
      |	LEFT OUTER JOIN ZH_ITEMS
      |	ON (Allergies.ItemID = ZH_Items.ItemID)
      |	LEFT OUTER JOIN DEDUP_ENC Enc
      |	ON (Enc.Encounterid = Allergies.encounterid)
      |	WHERE Allergies.AllergyType NOT IN ('3','4','5')
      |)
      |WHERE localallergencd IS NOT NULL
      |AND onsetdate IS NOT NULL
    """.stripMargin
    .replace("{PATIENT}", CDRFEParquetNames.patient)
}

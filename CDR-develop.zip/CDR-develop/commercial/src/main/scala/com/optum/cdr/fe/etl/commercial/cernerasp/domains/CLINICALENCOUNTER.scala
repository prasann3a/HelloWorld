package com.optum.cdr.fe.etl.commercial.cernerasp.domains
import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.clinicalencounter
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object CLINICALENCOUNTER extends FETableInfo[clinicalencounter]{

  override def name:String= CDRFEParquetNames.clinicalencounter

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    val list_pat_type_exclude=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"PAT_TYPE_EXCLUDE","CLINICALENCOUNTER","VISIT","HUM_TYPE").mkString(",")


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select groupid, client_ds_id, datasrc, facilityid, patientid, encounterid, arrivaltime, admittime, dischargetime, localpatienttype, alt_encounterid
         |from
         |(
         |  CLINICALCACHE
         |)
         |where ce_rownumber = 1 and encounterid is not null and hum_type not in ({list_pat_type_exclude})
       """.stripMargin
        .replace("{list_pat_type_exclude}",list_pat_type_exclude)
    )
  }


  override def dependsOn: Set[String] = Set("CLINICALCACHE","MAP_PREDICATE_VALUES")
}
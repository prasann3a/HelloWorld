package com.optum.cdr.fe.etl.commercial.icrc.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_pharm
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.optum.cdr.fe.utils.Functions.mpvList
import org.apache.spark.sql.functions.lit

object INT_CLAIM_PHARM extends FETableInfo[int_claim_pharm]
{
  override def name: String = CDRFEParquetNames.int_claim_pharm


  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame =
  {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId


    val intClaimmpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId, "INT_CLAIM_PHARM", "INT_CLAIM_PHARM", "INT_CLAIM_PHARM", "PHARMACY").mkString(",")

    var pharmDf = loadedDependencies("PHARMV2")
    // Add this column with null value if this column is not present
    // This is because the stage parquets may/may not have this column, but the query needs this
    Seq("UHC_MEMBER").foreach(col => {
      pharmDf = if(!pharmDf.columns.contains(col)) pharmDf.withColumn(col, lit(null)) else pharmDf
    })
    pharmDf.createOrReplaceTempView("PHARMV2")

    loadedDependencies("PHARMACY").createOrReplaceTempView("PHARMACY")
    loadedDependencies("ZO_BPO_MAP_EMPLOYER").createOrReplaceTempView("ZO_BPO_MAP_EMPLOYER")

    val intclaimsql= if(intClaimmpv.contains(groupId)) // FOR H834852
          s"""
             |select  groupid,datasrc,client_ds_id, CLAIM_ID, DAYS_SUPPLY, MEMBER_ID, METRIC_QUANTITY, NDC, QUANTITY_PER_FILL, RX_ID, SERVICE_DATE, ALLOWED_AMOUNT, COINSURANCE_AMOUNT, COPAY_AMOUNT, DEDUCTIBLE_AMOUNT, DENIED_FLAG, DENIED_REASON, GENERIC_STATUS, NETWORK_PAID_STATUS, PATIENT_LIABILITY_AMOUNT, PAYMENT_AMOUNT, PAY_PROCESS_DATE, PHARMACY_ID, PHARMACY_NAME, PRESC_PROV_ID, PRESC_PROV_NPI, PSEUDO_FLAG, REQUESTED_AMOUNT, CONTRACT_ID,ENCOUNTERID
             |from
             |(
             |select * from (
             | select
             |  distinct '{groupid}' AS groupid
             | ,'Pharmacy' AS datasrc
             | ,{client_ds_id} AS client_ds_id
             | ,nullif(concat_ws('', MEMBER, upper(date_format(DOS,'dd-MMM-yy')), NDC, PLAN_SOURCE), '') AS CLAIM_ID
             | ,Day_Sup AS DAYS_SUPPLY
             | ,Member AS MEMBER_ID
             | ,Met_Qty AS METRIC_QUANTITY
             | ,Ndc AS NDC
             | ,Met_Qty AS QUANTITY_PER_FILL
             | ,nullif(concat_ws('', MEMBER, upper(date_format(DOS, 'dd-MMM-yy')), NDC, PLAN_SOURCE), '') AS RX_ID
             | ,DOS AS SERVICE_DATE
             | ,Amt_Eqv AS ALLOWED_AMOUNT
             | ,Amt_Coin AS COINSURANCE_AMOUNT
             | ,Amt_Cop AS COPAY_AMOUNT
             | ,Amt_Ded AS DEDUCTIBLE_AMOUNT
             | ,Denied_Flag AS DENIED_FLAG
             | ,Denied_Ind AS DENIED_REASON
             | ,CASE
             |     WHEN Gbo in ('0', '1') THEN 'Y'
             |     WHEN Gbo in ('2') THEN 'N'
             |     ELSE NULL  End AS GENERIC_STATUS
             |,Network_Paid_Status  AS NETWORK_PAID_STATUS
             | ,Amt_Liab AS PATIENT_LIABILITY_AMOUNT
             | ,Amt_Pay AS PAYMENT_AMOUNT
             | ,Pay_Dt AS PAY_PROCESS_DATE
             | ,Provider AS PHARMACY_ID
             | ,Pharmacy_Name AS PHARMACY_NAME
             | ,Pres_Prv AS PRESC_PROV_ID
             | ,Pres_Prv AS PRESC_PROV_NPI
             | ,Pseudo AS PSEUDO_FLAG
             | ,Amt_Req AS REQUESTED_AMOUNT
             | ,bme.Employeraccountid as CONTRACT_ID
             | ,nullif(concat_ws('', MEMBER, upper(date_format(DOS, 'dd-MMM-yy')), NDC, PLAN_SOURCE), '') AS ENCOUNTERID
             | ,row_number() over(partition by MEMBER,DOS, NDC, PLAN_SOURCE order by transact_date desc nulls last) as rnk
             |  from PHARMACY P
             |  cross join ZO_BPO_MAP_EMPLOYER bme on bme.client_ds_id='{client_ds_id}'
             |
             |  )
             |   Where rnk = 1
             |
             |)
           """.stripMargin
    else     //FOR H827927
          s"""

             |select datasrc, CLAIM_ID, DAYS_SUPPLY, MEMBER_ID, METRIC_QUANTITY, NDC, QUANTITY_PER_FILL, RX_ID, SERVICE_DATE, ALLOWED_AMOUNT, COINSURANCE_AMOUNT, COPAY_AMOUNT, DEDUCTIBLE_AMOUNT, DENIED_FLAG, DENIED_REASON, GENERIC_STATUS, NETWORK_PAID_STATUS, PATIENT_LIABILITY_AMOUNT, PAYMENT_AMOUNT, PAY_PROCESS_DATE, PHARMACY_ID, PHARMACY_NAME, PRESC_PROV_ID, PRESC_PROV_NPI, PSEUDO_FLAG, REQUESTED_AMOUNT
             |from
             |(
             | select
             | distinct '{​​​​​groupid}​​​​​' AS groupid
             |,'Pharmacy' AS datasrc
             |,{client_ds_id} AS client_ds_id
             |,nullif(concat_ws('', UHC_MEMBER, upper(date_format(DOS,'dd-MMM-yy')), NDC, PLAN_SOURCE), '') AS CLAIM_ID
             |,Day_Sup AS DAYS_SUPPLY
             |,'' as MEMBER_ID
             |,Met_Qty AS METRIC_QUANTITY
             |,Ndc AS NDC
             |,Met_Qty AS QUANTITY_PER_FILL
             |,nullif(concat_ws('', UHC_MEMBER, upper(date_format(DOS,'dd-MMM-yy')), NDC, PLAN_SOURCE), '') AS RX_ID
             |,DOS AS SERVICE_DATE
             |,Amt_Eqv AS ALLOWED_AMOUNT
             |,Amt_Coin AS COINSURANCE_AMOUNT
             |,Amt_Cop AS COPAY_AMOUNT
             |,Amt_Ded AS DEDUCTIBLE_AMOUNT
             |,Denied_Flag AS DENIED_FLAG
             |,Denied_Ind AS DENIED_REASON
             |,CASE
             |WHEN Gbo in ('0', '1') THEN 'Y'
             |WHEN Gbo in ('2') THEN 'N'
             |ELSE NULL End AS GENERIC_STATUS
             |,Network_Paid_Status AS NETWORK_PAID_STATUS
             |,Amt_Liab AS PATIENT_LIABILITY_AMOUNT
             |,Amt_Pay AS PAYMENT_AMOUNT
             |,Pay_Dt AS PAY_PROCESS_DATE
             |,Provider AS PHARMACY_ID
             |,Pharmacy_Name AS PHARMACY_NAME
             |,Pres_Prv AS PRESC_PROV_ID
             |,Pres_Prv AS PRESC_PROV_NPI
             |,Pseudo AS PSEUDO_FLAG
             |,Amt_Req AS REQUESTED_AMOUNT
             |,row_number() over(partition by UHC_MEMBER, upper(date_format(DOS,'dd-MMM-yy')), NDC, PLAN_SOURCE order by transact_date desc nulls last) as rnk
             |from PHARMV2 P
             |)
            """.stripMargin

    sparkSession.sql(intclaimsql.replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId))
  }

  override def dependsOn: Set[String] = Set("PHARMACY","PHARMV2","MAP_PREDICATE_VALUES","ZO_BPO_MAP_EMPLOYER")

}

package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.{patient => cdrpatient}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

// This is named PATIENT_QUERY to avoid conflict with the case class patient
object PATIENT_QUERY extends FEQueryAndMetadata[cdrpatient]{

  override def name: String = CDRFEParquetNames.patient

  override def dependsOn: Set[String] = Set("PATIENT_CACHE")

  override def sparkSql: String =
    """
      |select patientid, '{groupid}' as groupid, 'patient' as datasrc, dob as dateofbirth, dod as dateofdeath, mrn as medicalrecordnumber, {client_ds_id} as client_ds_id
      |from
      |(
      |PATIENT_CACHE
      |)
      |where rownumber = 1
    """.stripMargin
}

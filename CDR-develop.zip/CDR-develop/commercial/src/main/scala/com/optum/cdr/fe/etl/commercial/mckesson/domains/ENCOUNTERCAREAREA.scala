package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.encountercarearea
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}

object ENCOUNTERCAREAREA extends FEQueryAndMetadata[encountercarearea] {
  override def name: String = CDRFEParquetNames.encountercarearea

  override def dependsOn: Set[String] = Set("MCKESSON_ENT_PATIENT", "MCKESSON_ZH_ENT_CONFIG_ORGANIZATION")

  override def sparkSql: String =
    """
       WITH encountercarearea_unfiltered AS
       (
          SELECT
            pat.pat_seq  	      AS encounterid
            ,COALESCE(pat.admit_dt, pat.transfer_dt, pat.discharge_dt, pat.created_dt)  AS encountertime
            ,NVL2(pat.Organization_Seq, CONCAT_WS('', {client_ds_id}, '.' ,pat.Organization_Seq), NULL)  AS localcareareacode
            ,pat.cpi_seq  	      AS patientid
            ,pat.discharge_dt     AS careareaendtime
            ,pat.admit_dt         AS careareastarttime
            ,pat.facility_id      AS facilityid
            ,zh.name              AS locallocationname
            ,NVL2(pat.Service, CONCAT_WS('','{client_ds_id}','.',pat.Service), NULL) AS servicecode
            ,pat.pat_type_group
            ,ROW_NUMBER() OVER (PARTITION BY pat.cpi_seq, pat.pat_seq, pat.Organization_Seq, pat.Service
                                ORDER BY pat.modified_dt DESC NULLS LAST) rn
            FROM MCKESSON_ENT_PATIENT pat
            LEFT OUTER JOIN MCKESSON_ZH_ENT_CONFIG_ORGANIZATION zh ON (pat.organization_seq = zh.organization_seq)
            WHERE pat.Cpi_Seq IS NOT NULL
              AND pat.Pat_Seq IS NOT NULL
              AND pat.pat_type_group = 'I'
              AND zh.organization_type = 'Location'
        )
        SELECT
          'ent_patient_org' AS datasrc,
          patientid,
          encounterid,
          encountertime,
          servicecode,
          facilityid,
          localcareareacode,
          careareastarttime,
          careareaendtime,
          locallocationname
        FROM encountercarearea_unfiltered
        WHERE rn = 1
          AND encountertime IS NOT NULL
    """.stripMargin

}

package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE_PAT_PROCS extends FEQueryAndMetadata[proceduredo]{

  override def name: String = "PROCEDURE_PAT_PROCS"

  override def dependsOn: Set[String] = Set("MED3000_PATIENT_PROCEDURES","MED3000_ZH_PROC_MASTER")

  override def sparkSql: String =
    """
     select groupid, datasrc, client_ds_id, localcode, patientid, proceduredate, actualproceduredate as actualprocdate, localname, mappedcode, codetype, performingproviderid
 |from
 |(
 |select
 |       '{groupid}'         as groupid
 |       ,'pat_procs'       as datasrc
 |       ,{client_ds_id}       as client_ds_id
 |       ,proc.Procedure_Code   as localcode
 |       ,proc.Blind_Key      as patientid
 |       ,proc.Procedure_Date   as proceduredate
 |       ,proc.Procedure_Date   as actualproceduredate
 |       ,coalesce(mast.Description,proc.Procedure_Description) as localname
 |       ,proc.Procedure_Pcp    as performingproviderid
 |       ,lpad(proc.Procedure_Code,5,'0')   as mappedcode
 |       ,case when rlike(nullif(substr(proc.Procedure_Code,1,5), ''),'^[0-9]{4}[0-9A-Z]$')        then 'CPT4'
 |             when rlike(nullif(substr(proc.Procedure_Code,1,5), ''),'^[A-Z]{1,1}[0-9]{4}$')      then 'HCPCS'
 |             when rlike(nullif(substr(proc.Procedure_Code,1,5), ''), '^[0-9]{2,2}\\.[0-9]{1,2}$') then 'ICD9'
 |        end as codetype
 |    ,row_number() over (partition by proc.Blind_Key,proc.Procedure_Code,proc.Procedure_Date order by proc.Update_Date desc nulls last) as rank_proc
 |  from  MED3000_PATIENT_PROCEDURES proc
 |  left join MED3000_ZH_PROC_MASTER mast on (proc.Procedure_Code = mast.Procedure_Code)
 |  where Pt_Exempt <> 'Y'
 |
 |)
 |where proceduredate is not null and patientid is not null
 |
    """.stripMargin


}

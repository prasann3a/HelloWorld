package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object TEMP_DIAGNOSIS_PART2 extends FEQueryAndMetadata[diagnosis] {

  override def name: String = "TEMP_DIAGNOSIS_PART2"

  override def dependsOn: Set[String] = Set("DISCH", "ENCNTR")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, patientid, encounterid, dx_timestamp, null as localactiveind,
      |null as localdiagnosisstatus, null as localdiagnosisproviderid, localdiagnosis, null as primarydiagnosis,
      |null as resolutiondate, localdiagnosis as mappeddiagnosis, null as localadmitflg, null as localdischargeflg,
      |hosp_dx_flag, null as codetype, null as facilityid
      |from
      |(
      |SELECT * FROM (
      |SELECT * FROM (
      |SELECT m.*, ROW_NUMBER() OVER (PARTITION BY patientid, dx_timestamp,
      |    encounterid, localdiagnosis ORDER BY localdiagnosis) rn
      |FROM (
      |SELECT '{groupid}' as groupid
      |,'disch' as datasrc
      |,{client_ds_id} as client_ds_id
      |,Disch.Ddate  AS dx_timestamp
      |,Encntr.Pat_Person_Num  AS patientid
      |,Encntr.Num  AS encounterid
      |,Encntr.Fac_Num  AS facilityid
      |,'Y'  AS hosp_dx_flag
      |,CASE WHEN Disch.seq = 16 THEN '1' ELSE '0' END  AS localadmitflag
      |,CASE WHEN Disch.seq = 16 THEN '0' ELSE '1' END   AS localdischargeflag
      |,Disch.srcdiag AS localdiagnosis
      |FROM (SELECT acct_num, ddate, srcdiag, seq FROM
      |(SELECT * from
      |(
      |select * from
      |(
      |select unpivot_base.*,
      |stack(16,Disch_Diag_1,1,Disch_Diag_2,2,Disch_Diag_3,3,
      |    Disch_Diag_4,4,Disch_Diag_5,5,Disch_Diag_6,6,
      |    Disch_Diag_7,7,Disch_Diag_8,8,Disch_Diag_9,9,
      |    Disch_Diag_10,10,Disch_Diag_11,11,Disch_Diag_12,12,
      |    Disch_Diag_13,13,Disch_Diag_14,14,Disch_Diag_15,15,
      |    Adm_Diag_Code,16) as (srcdiag, seq)
      |from
      |DISCH unpivot_base
      |)
      |where srcdiag is not null
      |))) Disch
      |     JOIN ENCNTR ON (encntr.prim_acct_num = disch.acct_num)
      |) m )
      |WHERE rn=1
      |)
      |where dx_timestamp IS NOT NULL AND patientid IS NOT NULL
      |)
    """.stripMargin

}

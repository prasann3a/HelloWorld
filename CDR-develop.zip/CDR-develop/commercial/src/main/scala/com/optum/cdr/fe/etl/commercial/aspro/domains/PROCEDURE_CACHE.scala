package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.aspro_procedure_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE extends FEQueryAndMetadata[aspro_procedure_cache]{

override def name: String = "PROCEDURE_CACHE"

override def dependsOn: Set[String] = Set("LABORDERS", "ZH_LABCATALOG", "ZH_PROVIDERS")

override def sparkSql: String =
  """
    |SELECT  DISTINCT '{groupid}'                                                                                            AS groupid
    |       ,'laborders'                                                                                                     AS datasrc
    |       ,NULL                                                                                                            AS facilityid
    |       ,l.imreenc_code                                                                                                  AS encounterid
    |       ,l.imredemec_code                                                                                                AS patientid
    |       ,null                                                                                                            AS sourceid
    |       ,null                                                                                                            AS performingproviderid
    |       ,l.Imreprov_Code                                                                                                 AS referproviderid
    |       ,l.laborder_orderdate                                                                                            AS proceduredate
    |       ,'PROCEDURES'                                                                                                    AS procedurecodesourcetable
    |       ,l.imrelabcat_code                                                                                               AS localcode
    |       ,ln.labcat_name                                                                                                  AS localname
    |       ,CASE WHEN rlike(nullif(substr(ln.labcat_cptcode,1,5),''),'^[0-9]{4}[0-9A-Z]$') THEN 'CPT4'
    |             WHEN rlike(nullif(substr(ln.labcat_cptcode,1,5),''),'^[A-Z]{1,1}[0-9]{4}$') THEN 'HCPCS'
    |             WHEN rlike(nullif(substr(ln.labcat_cptcode,1,5),''),'^[0-9]{2,2}\\.[0-9]{1,2}$') THEN 'ICD9' ELSE NULL END AS codetype
    |       ,NULL                                                                                                            AS procseq
    |       ,ln.labcat_cptcode                                                                                               AS mappedcode
    |       ,coalesce(null,CASE WHEN prv1.imreprov_code is not null THEN l.laborder_notifyprovcode else null end,CASE WHEN prv2.imreprov_code is not null THEN l.imreprov_code else null end) AS orderingproviderid
    |       ,ROW_NUMBER() OVER (PARTITION BY l.imredemec_code,l.imreenc_code,l.laborder_orderdate,l.imrelabcat_code ORDER BY l.tag_systemdate DESC nulls last) rownumber
    |       ,ROW_NUMBER() OVER (PARTITION BY l.imredemec_code,l.imreenc_code,l.laborder_orderdate,l.imrelabcat_code,coalesce(null,CASE WHEN prv1.imreprov_code is not null THEN l.laborder_notifyprovcode else null end,CASE WHEN prv2.imreprov_code is not null THEN l.imreprov_code else null end) ORDER BY l.tag_systemdate DESC nulls last) AS ordprov_row
    |FROM LABORDERS l
    |LEFT OUTER JOIN ZH_LABCATALOG ln
    |ON (l.imrelabcat_code = ln.imrelabcat_code)
    |LEFT OUTER JOIN
    |(
    |	  SELECT  *
    |	  FROM ZH_PROVIDERS
    |) prv1
    |ON (l.laborder_notifyprovcode = prv1.imreprov_code)
    |LEFT OUTER JOIN
    |(
    |	  SELECT  *
    |	  FROM ZH_PROVIDERS
    |) prv2
    |ON (l.imreprov_code = prv2.imreprov_code)
    |WHERE l.laborder_completionstatus = 3
    |AND l.tag_systemdate > TO_DATE('20050101','yyyyMMdd')
  """.stripMargin
}

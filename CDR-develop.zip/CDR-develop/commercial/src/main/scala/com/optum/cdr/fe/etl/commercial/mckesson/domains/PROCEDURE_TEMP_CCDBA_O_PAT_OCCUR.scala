package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.proceduredo
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object PROCEDURE_TEMP_CCDBA_O_PAT_OCCUR extends FETableInfo[proceduredo]{
  override def name: String = "PROCEDURE_TEMP_CCDBA_O_PAT_OCCUR"

  override def dependsOn: Set[String] = Set("MCKESSON_CCDBA_O_PAT_OCCUR","MCKESSON_ENT_PATIENT","CCDBA_O_PAT","MCKESSON_CCDBA_ANC_RESULTS","MAP_CUSTOM_PROC","ZH_CCDEV_O_ITEM")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |WITH uni_occur AS
         |(SELECT * FROM
         |(SELECT p.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY modified_dt DESC NULLS LAST) rn
         | FROM MCKESSON_CCDBA_O_PAT_OCCUR p
         | WHERE pat_Seq IS NOT NULL
         |   AND Completion_Ddt IS NOT NULL
         |   AND order_item_seq <> '0'
         |   AND order_seq <> '0' )
         | WHERE rn = 1),
         |uni_epat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |   WHERE cpi_seq IS NOT NULL
         |     AND pat_seq IS NOT NULL )
         |) WHERE rn = 1),
         |uni_opat AS
         |(SELECT * FROM (
         |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY order_seq ORDER BY order_ddt DESC NULLS LAST) rn
         |      FROM CCDBA_O_PAT i
         |      WHERE pat_seq IS NOT NULL
         |        AND Order_Item_Seq IS NOT NULL
         |       )
         |WHERE rn = 1),
         |uni_anc AS
         |(SELECT * FROM (
         | SELECT a.*, ROW_NUMBER() OVER (PARTITION BY result_seq ORDER BY pat_results_perform_ddt DESC NULLS LAST) rn
         | FROM MCKESSON_CCDBA_ANC_RESULTS a
         | WHERE status_desc = 'Final Report' )
         | WHERE rn = 1)
         |select datasrc, localcode, encounterid, patientid, proceduredate, localname, codetype, mappedcode, proceduredate as actualprocdate, facilityid, hosp_px_flag
         |from
         |(
         |SELECT 'ccdba_o_pat_occur' AS datasrc
         |	,concat_ws('', '{client_ds_id}', '.', uni_opat.Order_Item_Seq) AS localcode
         |	,uni_epat.cpi_seq  AS patientid
         |	,uni_occur.Completion_Ddt  AS proceduredate
         |	,uni_opat.pat_seq  AS encounterid
         |	,NULL		  AS facilityid
         |	,zh.Order_Name	  AS localname
         |	,Map.Mappedvalue  AS mappedcode
         |	,'CUSTOM'  	  AS codetype
         |	,'Y'              AS hosp_px_flag
         |	,ROW_NUMBER() OVER (PARTITION BY uni_epat.cpi_seq, uni_opat.pat_seq, uni_occur.Completion_Ddt, uni_opat.Order_Item_Seq
         |	 			ORDER BY uni_occur.modified_dt DESC NULLS LAST) rn
         |FROM UNI_OCCUR
         |   JOIN UNI_OPAT ON (uni_occur.order_seq = uni_opat.order_seq)
         |   JOIN UNI_EPAT ON (uni_epat.pat_seq = uni_opat.pat_seq)
         |   JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
         |                            map.datasrc = 'ccdba_o_pat_occur' AND
         |   			    map.localcode = concat_ws('', '{client_ds_id}', '.', uni_opat.Order_Item_Seq))
         |   JOIN ZH_CCDEV_O_ITEM zh ON (uni_opat.Order_Item_Seq = zh.order_item_seq)
         |   JOIN UNI_ANC ON (uni_occur.pat_seq = uni_anc.pat_seq AND uni_occur.o_occur_seq = uni_anc.o_occur_seq)
         |
 |)
         |where rn = 1 AND proceduredate IS NOT NULL
       """.stripMargin.replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId))
  }
}

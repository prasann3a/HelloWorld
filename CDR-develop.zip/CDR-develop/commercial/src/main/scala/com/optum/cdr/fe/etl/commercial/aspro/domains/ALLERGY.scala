package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.allergy
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, RuntimeVariables}

object ALLERGY extends FEQueryAndMetadata[allergy]{

override def name: String = CDRFEParquetNames.allergy

override def dependsOn: Set[String] = Set("HXDIAGNOSIS", "ZH_DRUGS")

override def sparkSql: String =
"""
   SELECT *
   FROM
   (
  |SELECT 'hxdiagnosis' AS datasrc
  |	,'OTHER'       AS localallergentype
  |	,Hxdiagnosis.Source_Code  AS localallergencd
  |	,coalesce(Hxdiagnosis.Onset_Date ,Hxdiagnosis.Tag_Systemdate ) AS onsetdate
  |	,Hxdiagnosis.Patient_Id    AS patientid
  |	,Hxdiagnosis.Imreenc_Code  AS encounterid
  |	,coalesce(Zh_Drugs.Drug_Title ,Hxdiagnosis.Title ) AS localallergendesc
  |	,Zh_Drugs.Drug_Gpi     AS localgpi
  |	,NULL  AS localndc
  |	,case when '{code_prefix}' = 'EXCEPTION' then  concat_ws('','as.', cast(Hxdiagnosis.Activity_Code as string)) else cast(Hxdiagnosis.Activity_Code as string) end AS localstatus
  |FROM HXDIAGNOSIS as Hxdiagnosis
  |	LEFT OUTER JOIN ZH_DRUGS as Zh_Drugs ON (Hxdiagnosis.source_code = Zh_drugs.drug_code)
  |WHERE hxdiagnosis.category_code = '21'
  |  AND source_code <> 'FREETEXT'
  |  )
  |  WHERE onsetdate IS NOT NULL
""".stripMargin

  override protected def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val codePrefix = if (loaderVars.groupId == "H770635" && loaderVars.clientDsId == 45) "H770635"
    else if(loaderVars.groupId=="H717614" && loaderVars.clientDsId==2801) "EXCEPTION" else "UNDEFINED"
    sparkSql.replace("{code_prefix}", codePrefix)
  }
}

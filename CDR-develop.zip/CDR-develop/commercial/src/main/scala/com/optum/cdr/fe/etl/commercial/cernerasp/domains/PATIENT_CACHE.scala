
package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENT_CACHE extends FETableInfo[cerner_patient_cache]{

  override def name:String="TEMP_PATIENT_CACHE"
  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_alt_pat_id= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"ALT_PAT_ID","PATIENT","IDENTIFIERS","IDENTIFIER_TYPE").mkString(",")

    sparkSession.sql(
      s"""
         |select t1.*
         |	,'{groupid}'	as groupid
         | 	,'patient'	as datasrc
         | 	,{client_ds_id}	as client_ds_id
         |    ,first_value(t1.dateofbirth) over (partition by t1.patientid order by nvl2(t1.dateofbirth,1,0) desc nulls first, t1.update_date desc nulls last) as dob
         |    ,last_value(t1.dateofdeath) over (partition by t1.patientid order by t1.update_date nulls first ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as dod
         |    ,first_value(t1.mrn ) over (partition by t1.patientid order by nvl2(t1.mrn,1,0) desc nulls first, t1.update_date desc nulls last) as medicalrecordnumber
         |    ,row_number() over (partition by t1.patientid order by t1.update_date desc nulls last) as rownumber
         |    ,row_number() over (partition by t1.patientid, t1.death_ind order by t1.update_date desc nulls last) as status_row
         |    ,row_number() over (partition by t1.patientid, nvl(t1.ethnicity_value, t1.race)  order by t1.update_date desc nulls last) as ethnicity_row
         |    ,row_number() over (partition by t1.patientid, upper(t1.first_name)  order by t1.update_date desc nulls last) as first_row
         |    ,row_number() over (partition by t1.patientid, upper(t1.last_name)   order by t1.update_date desc nulls last) as last_row
         |    ,row_number() over (partition by t1.patientid, upper(t1.gender)     order by t1.update_date desc nulls last) as gender_row
         |    ,row_number() over (partition by t1.patientid, upper(t1.race)       order by t1.update_date desc nulls last) as race_row
         |    ,row_number() over (partition by t1.patientid, t1.mrn order by t1.update_date desc nulls last) as mrn_row
         |    ,row_number() over (partition by t1.patientid, upper(t1.language)   order by t1.update_date desc nulls last) as language_row
         |    ,row_number() over (partition by t1.patientid, upper(t1.marital)   order by t1.update_date desc nulls last) as marital_row
         |    ,row_number() over (partition by t1.patientid, upper(t1.middle_name)   order by t1.update_date desc nulls last) as middle_row
         |    ,row_number() over (partition by t1.patientid, upper(t1.religion_cd)   order by t1.update_date desc nulls last) as religion_row
         |from (
         |	select p.unique_person_identifier	as patientid
         |		,p.birth_date_time	as dateofbirth
         |		,nullif(p.deceased_date_time,to_date('1900-01-01 00:00:00','yyyy-MM-dd HH:mm:ss'))	as dateofdeath
         |		,i.alt_mrn as mrn
         |		,p.first_name	as first_name
         |		,p.last_name		as last_name
         |		,case when p.gender = '0' then null  else concat_ws('', {client_ds_id}, '.', p.gender) end	as gender
         |		,coalesce(case when p.race = '0' then null  else concat_ws('', {client_ds_id}, '.r.', p.race) end, case when p.additional_race = '0' then null  else concat_ws('', {client_ds_id}, '.ar.', p.additional_race) end
         |			,case when pi.person_info_code = '0' then null  else concat_ws('', {client_ds_id}, '.pic.', pi.person_info_code) end)	as race
         |		,coalesce(case when p.ethnicity = '0' then null  else concat_ws('', {client_ds_id}, '.e.', p.ethnicity) end, case when p.additional_ethnicity = '0' then null  else concat_ws('', {client_ds_id}, '.ae.', p.additional_ethnicity) end
         |			,case when pi.person_info_code = '0' then null  else concat_ws('', {client_ds_id}, '.pic.', pi.person_info_code) end)	as ethnicity_value
         |		,case when p.deceased = '0' then null  else concat_ws('', {client_ds_id}, '.', p.deceased) end	as death_ind
         |		,coalesce(case when p.hum_language = '0' then null  else concat_ws('', {client_ds_id}, '.l.', p.hum_language) end, case when p.additional_language = '0' then null  else concat_ws('', {client_ds_id}, '.al.', p.additional_language) end) as language
         |		,case when p.marital_status = '0' then null  else concat_ws('', {client_ds_id}, '.', p.marital_status) end	as marital
         |		,p.middle_name	as middle_name
         |		,rc.display	as religion_cd
         |		,case when p.active	 = '1' then 'N'
         |			when p.active = '0' then 'Y' end		as inactive_flag
         |		,p.update_date_time	as update_date
         |	from PERSON p
         |		left outer join PERSONINFO pi on (p.unique_person_identifier = pi.unique_person_identifier)
         |		left outer join (select id.entity_identifier
         |					,max(id.identifier) over (partition by id.update_date_time)	as alt_mrn
         |				from IDENTIFIERS id
         |				where id.entity_type = 'PERSON'
         |				and id.identifier_type in ({list_alt_pat_id})
         |				) i on (p.unique_person_identifier = i.entity_identifier)
         |		left outer join REFERENCECODE rc on (p.religion = rc.element_code and rc.file_name = 'PERSON' and rc.field = 'RELIGION')
         |	where p.unique_person_identifier is not null
         |	and not (lower(p.first_name) like 'zz%' or lower(p.first_name) like '%patient%' or lower(p.first_name) = 'test')
         |	and not (lower(p.last_name) like 'zz%' or lower(p.last_name) like '%patient%' or lower(p.last_name) = 'test')
         |	) t1
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_alt_pat_id}",list_alt_pat_id)
    )


  }

  override def dependsOn: Set[String] = Set("PERSON","PERSONINFO","MAP_PREDICATE_VALUES","REFERENCECODE","IDENTIFIERS")
}
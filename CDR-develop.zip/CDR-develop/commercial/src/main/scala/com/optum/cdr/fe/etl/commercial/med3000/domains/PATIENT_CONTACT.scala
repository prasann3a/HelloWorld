package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.patientcontact
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT_CONTACT extends FEQueryAndMetadata[patientcontact]{

  override def name: String = CDRFEParquetNames.patientcontact

  override def dependsOn: Set[String] = Set("TEMP_PATIENT_CACHE")

  override def sparkSql: String =
    """select  datasrc, patientid, nvl(lastupdateddate,current_date) as update_dt, home_phone, cell_phone, work_phone, personal_email
      |from
      |(
      |TEMP_PATIENT_CACHE
      |)
      |where rank_con=1  and patientid is not null and coalesce(cell_phone,home_phone,work_phone,personal_email) is not null
    """.stripMargin
}

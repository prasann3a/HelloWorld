package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.cdr.fe.etl.commercial.med3000_gtt_labresult_nonnumeric
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object GTT_LABRESULT_NONNUMERIC extends FEQueryAndMetadata[med3000_gtt_labresult_nonnumeric] {

  override def name: String = "GTT_LABRESULT_NONNUMERIC"

  override def dependsOn: Set[String] = Set("TEMP_LABRESULT_CACHE")

  override def sparkSql: String =
    """
     |select groupid, datasrc, labresultid,laborderid, patientid, datecollected, labordereddate, dateavailable, labresult_date, localresult, localresult_numeric, localresult_inferred, localcode, localname, normalrange, localunits, client_ds_id, localspecimentype, localtestname,
     | substring(localresult,1,(case when locate(localresult,' ',25) = 0 then length(localresult) else locate(localresult,' ',25) end)) as localresult_25
     | from TEMP_LABRESULT_CACHE lc where localresult_numeric is null
    """.stripMargin
}

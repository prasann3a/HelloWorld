package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROCEDURE_CACHE_9 extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_9"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_ZH_TOM200_ORDER_CODE","MCKESSON_PGN_V1_TRD100_REQSEQ_EVENT","MAP_CUSTOM_PROC","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val evtStaLst = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "PROC_INC","PROCEDUREDO","REQSEQ_EVENT","EVT_STA_CD").mkString(",")
    val clientDsIdPrefix = runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |with uni_visit4 AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        |   WHERE Psn_Int_Id IS NOT NULL
        |     AND vst_int_id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'),
        |uni_code2 AS
        |(SELECT * FROM
        |    (SELECT c.*, ROW_NUMBER() OVER (PARTITION BY order_code_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
        |       FROM MCKESSON_PGN_V1_ZH_TOM200_ORDER_CODE c
        |      WHERE order_code_int_id IS NOT NULL )
        |  WHERE rn = 1
        |    AND row_sta_cd <> 'D')
        |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
        |from
        |(
        |SELECT '{groupid}'         	 AS groupid
        |      ,'reqseq_event'            AS datasrc
        |      ,{client_ds_id}             AS client_ds_id
        |      ,concat_ws('', '{client_ds_id_prefix}', evt.Order_Code_Int_Id) AS localcode
        |      ,uni_visit4.Psn_Int_Id      AS patientid
        |      ,evt.evt_ts		 AS proceduredate
        |      ,uni_visit4.Vst_Int_Id 	 AS encounterid
        |      ,NULL                      AS orderingproviderid
        |      ,uni_Code2.Order_Code_Desc1 AS localname
        |      ,evt.Req_Seq_No   	 AS procseq
        |      ,NULL                      AS proc_end_date
        |      ,NULL 			 AS hosp_px_flag
        |      ,'CUSTOM'  		 AS codetype
        |      ,NULL                      AS localprincipleindicator
        |      ,map.mappedvalue           AS mappedcode
        |      ,NULL        		 AS performingproviderid
        |      ,NULL                      AS actualprocdate
        |      ,ROW_NUMBER() OVER (PARTITION BY uni_visit4.Psn_Int_Id, uni_visit4.Vst_Int_Id,evt.evt_ts,evt.Order_Code_Int_Id
        |                               ORDER BY evt.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM MCKESSON_PGN_V1_TRD100_REQSEQ_EVENT evt
        |   JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
        |                               map.datasrc = 'reqseq_event' AND
        |   			    map.localcode = concat_ws('', '{client_ds_id_prefix}', evt.Order_Code_Int_Id))
        |   JOIN UNI_VISIT4 ON (uni_visit4.vst_int_id = evt.vst_int_id)
        |   JOIN UNI_CODE2 ON (uni_code2.order_code_int_id = evt.order_code_int_id)
        |WHERE evt.row_sta_cd <> 'D'
        |  AND evt.evt_ts IS NOT NULL
        |  AND evt.evt_sta_cd IN ({evt_sta_lst})
        |)
        |where proceduredate IS NOT NULL AND patientid IS NOT NULL
      """.stripMargin
        .replace("{evt_sta_lst}",evtStaLst)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}",clientDsIdPrefix)
    )
  }
}

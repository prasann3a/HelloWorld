package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.encountercarearea
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


object ENCOUNTERCAREAREA_DISCH extends FETableInfo[encountercarearea] {

  override def name: String = "ENCOUNTERCAREAREA_DISCH"

  override def dependsOn: Set[String] = Set("ENCNTR", "MAP_PREDICATE_VALUES", "DISCH", "ZH_VT")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val listEncntrTypCd = mpvList(mapPredicateValues, groupId, clientDsId.toString,"TRANSFER_DISCH","ENCOUNTERCAREAREA","ENCNTR","ENCNTR_TYPE_CDE").mkString(",")

    sparkSession.sql(
      """
        |with dedup_encntr as
        |( select * from (
        |  select enc.*
        |         ,row_number() over (partition by num ORDER BY data_ts DESC NULLS LAST) rn
        |  from ENCNTR enc
        |  where enc.Num is not null AND enc.Begin_Dttm is not null AND enc.Pat_Person_Num is not null and encntr_type_cde NOT IN ({list_encntr_typ_cd} )
        |
        |  ) where rn=1
        |)
        |, dedup_disch as
        |( select * from (
        |        select disch.ns_vt0021, disch.acct_num
        |              ,row_number() over (partition by disch.acct_num ORDER BY disch.fileid desc nulls last) rn
        |        from DISCH disch
        |    ) where rn=1
        |)
        |
        |select groupid, datasrc, patientid, encounterid, encountertime, servicecode, facilityid, localcareareacode, careareastarttime, careareaendtime, client_ds_id, locallocationname
        |from
        |(
        |SELECT '{groupid}' as groupid,'disch' as datasrc
        |  ,{client_ds_id} as client_ds_id
        |  ,enc.Num AS encounterid
        |  ,enc.Begin_Dttm AS encountertime
        |  ,enc.Pat_Person_Num AS patientid
        |  ,enc.Fac_Num AS facilityid
        |  ,enc.End_Dttm AS careareaendtime
        |  ,ENC.End_DTTM - INTERVAL 1 MINUTE AS careareastarttime
        |  ,concat_ws('', {client_ds_id}, '.', dsc.NS_VT0021) AS localcareareacode
        |  ,ZHV.Vt_Descr AS locallocationname
        |  ,enc.Medical_Serv_Cde AS servicecode
        |FROM DEDUP_DISCH dsc
        |INNER JOIN DEDUP_ENCNTR enc ON (enc.prim_acct_num = dsc.acct_num)
        |LEFT OUTER JOIN ZH_VT ZHV ON (dsc.NS_VT0021 = ZHv.vt_name1 and vt_NUM9 = 21)
        |WHERE enc.encntr_cat_cde = 'ACTV'
        |
        |)
        |where encounterid IS NOT NULL AND encountertime IS NOT NULL
      """.stripMargin
        .replace("{list_encntr_typ_cd}", listEncntrTypCd)
        .replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId.toString )
    )
  }
}
package com.optum.cdr.fe.etl.commercial.eods.domains

import com.optum.oap.cdr.models.patient_attribute
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT_ATTRIBUTE extends FEQueryAndMetadata[patient_attribute] {

  override def name: String = CDRFEParquetNames.patient_attribute

  override def dependsOn: Set[String] = Set("MEMBER")

  override def sparkSql: String =
    """
      |
      |select groupid, client_ds_id, datasrc, patientid, attribute_type_cui, attribute_value
      |from
      |(
      |select  '{groupid}' as groupid
      |       ,{client_ds_id} as client_ds_id
      |       ,'member' as datasrc
      |       ,uniq_mbr_id as patientid
      |       ,attribute_type_cui
      |       ,attribute_value
      |       ,row_number() over (partition by uniq_mbr_id, attribute_type_cui order by mbr_eff_dt desc nulls last) as row_nbr
      |from
      |(
      |select * from
      |(
      |select pa.*,
      |stack(3,ENRL_USER_DFN_3,'CH002785',ENRL_USER_DFN_4,'CH002786',RISK_LEVEL,'CH002788') as (attribute_value, attribute_type_cui)
      |from
      |MEMBER pa
      |)
      |where attribute_value is not null
      |)
      |where uniq_mbr_id is not null
      |and 1=1
      |
      |)
      |where row_nbr = 1
      |
    """.stripMargin

}

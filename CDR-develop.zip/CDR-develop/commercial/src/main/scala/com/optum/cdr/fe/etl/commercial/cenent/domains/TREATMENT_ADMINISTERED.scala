package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.treatment_administered
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object TREATMENT_ADMINISTERED extends FETableInfo[treatment_administered] {

  override def name: String = CDRFEParquetNames.treatment_administered

  override def dependsOn: Set[String] = Set("CHRG", "MAP_PREDICATE_VALUES", "ZH_DICT21_CHARGEMASTER", "ENCNTR")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId

    val adminList = mpvList(mapPredicateValues, groupId, clientDsId.toString,"CHRG","TREATMENT_ADMIN","CHRG","DICT_SEQ_A").mkString(",")

    sparkSession.sql(
    s"""
      |select groupid, datasrc, client_ds_id, administered_id, administered_date, localcode, patientid, administered_prov_id, local_unit, encounterid, administered_quantity
      |from
      |(
      |select
      |     distinct '{groupid}' 	as groupid
      |    ,'chrg' 				as datasrc
      |	   ,{client_ds_id} 		as client_ds_id
      |	   ,nullif(concat_ws('', acct_num, event_ptr, line_num), '') as administered_id
      |	   ,chr.Service_Date 	as administered_date
      |	   ,chr.Dict_Seq_A 		as localcode
      |	   ,e.Pat_Person_Num 	as patientid
      |	   ,chr.Provider 		as administered_prov_id
      |	   ,'cc' 				as local_unit
      |	   ,e.Num 				as encounterid
      |	   ,chr.Quantity        as administered_quantity
      | from CHRG chr
      | inner join ZH_DICT21_CHARGEMASTER zdc on (chr.dict_seq_a = zdc.DICT21_SEQ)
      | inner join (select distinct pat_person_num, prim_acct_num , num ,begin_dttm ,  end_dttm from ENCNTR ) e on ( e.prim_acct_num=chr.acct_num)
      | where chr.dict_seq_a  in ({admin_list})
      |  and charge_credit_flag='0'
      |  and date_trunc('DAY', chr.service_date) between date_trunc('DAY', begin_dttm) and  date_trunc('DAY', end_dttm)
      |
      |)
      |where patientid is not null
    """.stripMargin
       .replace("{admin_list}", adminList)
       .replace("{groupid}", groupId)
       .replace("{client_ds_id}", clientDsId.toString )
    )
  }
}
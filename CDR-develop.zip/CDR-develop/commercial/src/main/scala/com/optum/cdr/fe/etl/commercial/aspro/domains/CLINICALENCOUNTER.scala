package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.clinicalencounter
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object CLINICALENCOUNTER extends FEQueryAndMetadata[clinicalencounter]{

override def name: String = CDRFEParquetNames.clinicalencounter

override def dependsOn: Set[String] = Set("ENCOUNTERS", "ZH_PROVIDERS")

override def sparkSql: String =
  """
    |SELECT  datasrc
    |       ,encounterid
    |       ,facilityid
    |       ,patientid
    |       ,admittingphysician
    |       ,attendingphysician
    |       ,referproviderid
    |       ,admittime
    |       ,arrivaltime
    |       ,dischargetime
    |       ,localpatienttype
    |       ,localencountertype
    |       ,pcpid
    |FROM
    |(
    |	SELECT  'encounters'                          AS datasrc
    |	       ,en.imreenc_code                       AS encounterid
    |	       ,en.location_id                        AS facilityid
    |	       ,en.imredemec_code                     AS patientid
    |	       ,NULL                                  AS admittingphysician
    |	       ,zp.imreprov_code                      AS attendingphysician
    |	       ,NULL                                  AS referproviderid
    |	       ,null                                  AS admittime
    |	       ,en.enc_chartpulltime                  AS arrivaltime
    |	       ,null                                  AS dischargetime
    |	       ,concat_ws('','asp.',en.enc_visittype) AS localpatienttype
    |	       ,en.enc_visittype                      AS localencountertype
    |	       ,NULL                                  AS pcpid
    |	       ,ROW_NUMBER() OVER (PARTITION BY en.imreenc_code ORDER BY en.COSIGN_DATETIME DESC nulls last) rownumber
    |	FROM ENCOUNTERS en
    |	LEFT OUTER JOIN
    |	(
    |		SELECT  distinct imreprov_code
    |		FROM ZH_PROVIDERS
    |		WHERE imreprov_code is not null
    |	) zp
    |	ON (en.imreprov_code = zp.imreprov_code)
    |	WHERE en.enc_chartpulltime > TO_DATE('20050101','yyyyMMdd')
    |)
    |WHERE rownumber=1
    |AND patientid is not null
  """.stripMargin
}

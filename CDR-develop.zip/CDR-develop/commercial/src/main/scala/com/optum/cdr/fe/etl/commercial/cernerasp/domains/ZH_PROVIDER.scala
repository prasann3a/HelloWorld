package com.optum.cdr.fe.etl.commercial.cernerasp.domains


import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object ZH_PROVIDER extends FETableInfo[zh_provider]{

  override def name:String =CDRFEParquetNames.zh_provider

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_npi= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"NPI","PROVIDER","IDENTIFIERS","IDENTIFIER_TYPE").mkString(",")

    val list_dea= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"DEA","PROVIDER","IDENTIFIERS","IDENTIFIER_TYPE").mkString(",")

    val list_hum_position= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"PROVIDEREXCLUDE","PROVIDER","REFERENCEPERSONNEL","HUM_POSITION").mkString(",")

    sparkSession.sql(
      s"""
         |select groupid, client_ds_id, datasrc, localproviderid, npi, first_name, last_name, middle_name, gender
         |from
         |(
         |   PROVIDERCACHE
         |)
         |where prov_rownumber=1
         |
       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_npi}",list_npi)
        .replace("{list_dea}",list_dea)
        .replace("{list_hum_position}",list_hum_position)
    )



  }


  override def dependsOn: Set[String] =Set("PROVIDERCACHE","MAP_PREDICATE_VALUES")



}
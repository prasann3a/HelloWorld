package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object ZH_FACILITY extends FEQueryAndMetadata[zh_facility]{

  override def name: String = CDRFEParquetNames.zh_facility

  override def dependsOn: Set[String] = Set("ZH_EDI_FACILITIES", "ZH_FACILITYIDTYPE")

  override def sparkSql: String =
    """
      select groupid, client_ds_id, facilityid, facilityname, facilitypostalcd, localfacilitytype, npi
 |from
 |(
 |SELECT
 |	'{groupid}' as groupid
 |	,{client_ds_id} as client_ds_id
 |	,Zh_Edi_Facilities.Id  AS facilityid
 |	,Zh_Edi_Facilities.Hum_Name  AS facilityname
 |	,Zh_Edi_Facilities.Zip  AS facilitypostalcd
 |	,Zh_Facilityidtype.Hum_Name  AS localfacilitytype
 |	,Zh_Edi_Facilities.Npi as npi
 |FROM ZH_EDI_FACILITIES
 |    LEFT OUTER JOIN ZH_FACILITYIDTYPE ON (zh_edi_facilities.facilitytype = zh_facilityidtype.code)
 |
 |)
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.mckesson.domains


import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object LABRESULT_MCKESSON extends FEQueryAndMetadata[labresult] {
  override def name: String = "LABRESULT_MCKESSON"

  override def dependsOn: Set[String] = Set("LABRESULT_CACHE_1","LABRESULT_CACHE_2")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, datecollected, LABORDEREDDATE, Localspecimentype, dateavailable, encounterid, laborderid, localname, normalrange, resulttype, statuscode, localtestname, localunits, LABRESULT_DATE, localresult_numeric, localresult_numeric as localresult_inferred
      |from
      |(
      |LABRESULT_CACHE_1
      |)
      |where res_row = 1 AND localresult_numeric IS NOT NULL AND labresultid IS NOT NULL
      |
      |union all
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, datecollected, LABORDEREDDATE,null as Localspecimentype, dateavailable, encounterid, laborderid, localname, normalrange, resulttype, statuscode, localtestname, localunits, LABRESULT_DATE, localresult_numeric, localresult_numeric as localresult_inferred
      |from
      |(
      |LABRESULT_CACHE_2
      |)
      |where res_row = 1 AND localresult_numeric IS NOT NULL AND labresultid IS NOT NULL
    """.stripMargin


}

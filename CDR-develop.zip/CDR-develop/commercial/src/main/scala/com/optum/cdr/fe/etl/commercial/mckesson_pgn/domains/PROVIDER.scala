package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.{map_predicate_values, zh_provider}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROVIDER extends FETableInfo[zh_provider]{

  override def name: String = CDRFEParquetNames.zh_provider

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TPM100_CARE_GIVER","MCKESSON_PGN_V1_TSM040_PERSON_HDR","MCKESSON_PGN_V1_TPM115_CAR_GVR_LIC")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val licIds = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "NPI","ZH_PROVIDER","CAR_GVR_LIC","CAR_GVR_LIC_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |select groupid, client_ds_id, datasrc, localproviderid, credentials, dob, first_name, last_name, middle_name, providername, gender, npi, emailaddress
        |from
        |(
        |SELECT '{groupid}' 	AS groupid,
        |'care_giver' 		AS datasrc
        |,{client_ds_id} 		AS client_ds_id
        |,zg.Car_Gvr_Int_Id	AS localproviderid
        |,CASE WHEN hdr.nam_sfx_cd IN ('RN', 'DO', 'MD') THEN hdr.nam_sfx_cd ELSE NULL END AS credentials
        |,hdr.Bth_Ts		AS dob
        |,hdr.Fst_Nm		AS first_name
        |,NULL         		AS providername
        |,hdr.Sex_Cd		AS gender
        |,hdr.LST_NM     	AS last_name
        |,hdr.mid_Nm		AS middle_name
        |,CASE WHEN zl.Car_Gvr_Lic_ID IN ({lic_ids}) THEN  zl.Car_Gvr_Lic_No ELSE NULL END AS npi
        |,CASE WHEN hdr.nam_sfx_cd IN ('SR', 'JR', 'ii', 'iii', 'IV') THEN hdr.nam_sfx_cd ELSE NULL END AS suffix
        |,CASE WHEN hdr.e_mail_adr LIKE '%@%.%' THEN hdr.e_mail_adr ELSE NULL END AS emailaddress
        |,ROW_NUMBER() OVER (PARTITION BY zg.Car_Gvr_Int_Id ORDER BY zg.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM MCKESSON_PGN_V1_TPM100_CARE_GIVER zg
        |   JOIN MCKESSON_PGN_V1_TSM040_PERSON_HDR hdr ON (zg.psn_int_id = hdr.psn_int_id)
        |   LEFT OUTER JOIN MCKESSON_PGN_V1_TPM115_CAR_GVR_LIC zl ON (zg.car_gvr_int_id = zl.car_gvr_int_id AND zl.row_sta_cd <> 'D')
        |WHERE zg.Car_Gvr_Int_Id IS NOT NULL
        |  AND zg.row_sta_cd <> 'D'
        |  AND hdr.row_sta_cd <> 'D'
        |
        |)
        |where rn = 1
      """
        .stripMargin
        .replace("{lic_ids}", licIds)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }

}

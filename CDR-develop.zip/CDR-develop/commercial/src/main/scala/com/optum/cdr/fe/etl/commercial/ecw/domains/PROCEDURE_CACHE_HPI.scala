package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_HPI extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_HPI"

  override def dependsOn: Set[String] = Set("HPI", CDRFEParquetNames.clinicalencounter, "MAP_CUSTOM_PROC", "ZH_PROPERTIES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localcode
        |       ,encounterid
        |       ,patientid
        |       ,proceduredate
        |       ,localname
        |       ,codetype
        |       ,mappedcode
        |FROM
        |(
        |	SELECT  *
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                      AS groupid
        |		       ,'hpi'                                            AS datasrc
        |		       ,{client_ds_id}                                   AS client_ds_id
        |		       ,concat_ws('','{client_ds_id_prefix}',Hpi.Propid) AS localcode
        |		       ,Enc.Patientid                                    AS patientid
        |		       ,coalesce(hpi.createdate,enc.arrivaltime)         AS proceduredate
        |		       ,Hpi.Encounterid                                  AS encounterid
        |		       ,Zh_Properties.Hum_Name                           AS localname
        |		       ,Map_Custom_Proc.Mappedvalue                      AS mappedcode
        |		       ,'CUSTOM'                                         AS codetype
        |		       ,ROW_NUMBER() OVER (PARTITION BY hpi.EncounterID,hpi.propid,coalesce(hpi.createdate,enc.arrivaltime),map_custom_proc.mappedvalue ORDER BY hpi.hum_date DESC NULLS LAST) rn
        |		FROM HPI
        |		JOIN {CLINICALENCOUNTER} enc
        |			ON (hpi.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
        |		JOIN MAP_CUSTOM_PROC
        |			ON (map_custom_proc.groupid = '{groupid}' AND map_custom_proc.datasrc = 'hpi' AND map_custom_proc.localcode = concat_ws('', '{client_ds_id_prefix}', hpi.propid))
        |		LEFT OUTER JOIN ZH_PROPERTIES
        |		ON (hpi.propid = zh_properties.propid)
        |	)
        |	WHERE rn = 1
        |)
        |WHERE proceduredate IS NOT NULL
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }


}

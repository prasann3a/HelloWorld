package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.mborder
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader, CDRFEParquetNames}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MBORDER extends FETableInfo[mborder] {
  override def name: String = CDRFEParquetNames.mborder

  override def dependsOn: Set[String] = Set("MCKESSON_CCDBA_O_PAT_OCCUR", "MCKESSON_CCDBA_ANC_ORDER", "MCKESSON_ZH_CCDEV_ANC_TEST_CODES",
    "MCKESSON_ENT_PATIENT", "MCKESSON_ZH_ENT_CONFIG_ORGANIZATION", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val statusCd = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_O_PAT_OCCUR", "MBORDER", "CCDBA_O_PAT_OCCUR", "ANC_STATUS").mkString(",")
    val orderItemSeq = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_O_PAT_OCCUR", "MBORDER", "CCDBA_O_PAT_OCCUR", "ORDER_ITEM_SEQ").mkString(",")

    sparkSession.sql(
      s"""
      WITH uni_occur AS (
         |  SELECT  *
         |  FROM
         |  (
         |    SELECT  A.*
         |          ,ROW_NUMBER() OVER (PARTITION BY O_OCCUR_SEQ ORDER BY COMPLETION_DDT DESC NULLS LAST,CHART_DDT DESC NULLS LAST) AS rn
         |    FROM MCKESSON_CCDBA_O_PAT_OCCUR A
         |    WHERE ANC_STATUS IN ($statusCd)
         |    AND ORDER_ITEM_SEQ IN ($orderItemSeq)
         |  )
         |  WHERE RN = 1
         |),
         |deduped_anc_order AS (
         |  SELECT  *
         |  FROM
         |  (
         |    SELECT  b.*
         |          ,ROW_NUMBER() OVER (PARTITION BY O_OCCUR_SEQ ORDER BY ORDER_DDT DESC NULLS LAST) AS RN
         |    FROM MCKESSON_CCDBA_ANC_ORDER b
         |  )
         |  WHERE RN = 1
         |),
         |uni_zh AS (
         |  SELECT  *
         |  FROM
         |  (
         |    SELECT  p.*
         |          ,ROW_NUMBER() OVER (PARTITION BY order_item_seq ORDER BY creation_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ZH_CCDEV_ANC_TEST_CODES p
         |  )
         |  WHERE rn = 1
         |),
         |uni_pat AS (
         |  SELECT  *
         |  FROM
         |  (
         |    SELECT  p.*
         |          ,ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |    WHERE cpi_seq IS NOT NULL
         |  )
         |  WHERE rn = 1
         |),
         |DEDUPED_ORG AS (
         |  SELECT  *
         |  FROM
         |  (
         |    SELECT  c.*
         |          ,ROW_NUMBER() OVER (PARTITION BY ORGANIZATION_SEQ ORDER BY MODIFIED_DT DESC NULLS LAST) RN
         |    FROM MCKESSON_ZH_ENT_CONFIG_ORGANIZATION c
         |  )
         |  WHERE RN = 1
         |)
         |SELECT  groupid
         |       ,datasrc
         |       ,facilityid
         |       ,encounterid
         |       ,patientid
         |       ,mbprocorderid
         |       ,datecollected
         |       ,dateordered
         |       ,localorderstatus
         |       ,localordercode
         |       ,mborder_date
         |       ,client_ds_id
         |       ,localorderdesc
         |       ,hts_specimen_source
         |       ,localspecimensource
         |FROM
         |(
         |	SELECT  '{groupid}'                  AS GROUPID
         |	       ,'ccdba_o_pat_occur'          AS DATASRC
         |	       ,'{client_ds_id}'             AS CLIENT_DS_ID
         |	       ,uni_pat.CPI_SEQ              AS PATIENTID
         |	       ,uni_occur.PAT_SEQ            AS ENCOUNTERID
         |	       ,uni_occur.O_OCCUR_SEQ        AS MBPROCORDERID
         |	       ,org.NAME                     AS FACILITYID
         |	       ,uni_occur.ORDER_ITEM_SEQ     AS LOCALORDERCODE
         |	       ,uni_zh.DISPLAY_NAME          AS LOCALORDERDESC
         |	       ,uni_occur.COMPLETION_DDT     AS DATECOLLECTED
         |	       ,uni_occur.SCHED_DDT          AS DATEORDERED
         |	       ,uni_occur.COMPLETION_DDT     AS MBORDER_DATE
         |	       ,ord.SPECIMEN_SRC             AS LOCALSPECIMENNAME
         |	       ,UPPER(uni_occur.STATUS_DESC) AS LOCALORDERSTATUS
         |	       ,NULL                         AS hts_specimen_source
         |	       ,NULL                         AS localspecimensource
         |	FROM UNI_OCCUR
         |	JOIN UNI_PAT ON (uni_occur.PAT_SEQ = uni_pat.PAT_SEQ)
         |	JOIN UNI_ZH ON (uni_occur.ORDER_ITEM_SEQ = uni_zh.ORDER_ITEM_SEQ)
         |	LEFT OUTER JOIN DEDUPED_ORG org ON (uni_pat.ORGANIZATION_SEQ = org.ORGANIZATION_SEQ)
         |	LEFT OUTER JOIN DEDUPED_ANC_ORDER ord
         |	ON (uni_occur.O_OCCUR_SEQ = ord.O_OCCUR_SEQ)
         |)
         |WHERE mborder_date IS NOT NULL
    """.stripMargin.replace("{groupid}", groupId).replace("{client_ds_id}", clientDsId))
  }

}

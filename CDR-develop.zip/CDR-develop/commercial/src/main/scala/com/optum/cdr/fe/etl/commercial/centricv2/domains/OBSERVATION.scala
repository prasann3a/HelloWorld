package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object OBSERVATION extends FETableInfo[observation] {

  import java.util.TimeZone
  System.setProperty("user.timezone", "")
  TimeZone.setDefault(null)

  override def name: String = CDRFEParquetNames.observation

  override def dependsOn: Set[String] = Set("CENTRICV2_DOCUMENTS", "CENTRICV2_OBSERVATIONS", "CENTRICV2_ZH_OBSHEAD",
    "MAP_PREDICATE_VALUES", "ZCM_OBSTYPE_CODE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    val noMPVmatches = "NO_MPV_MATCHES"
    loadedDependencies.foreach { case (depName, df) => df.createOrReplaceTempView(depName) }

    val docXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "DOC_XID",
      "INCLUSION", "INCLUSION", "INCLUSION").mkString(",").replace("'", "")

    val docXidInclusion = if (docXidInclusionMpv.toLowerCase() == noMPVmatches.toLowerCase()) "" else
      "  and  xid in ( " + docXidInclusionMpv + " ) "

    val obsXidInclusionMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "OBS_XID",
      "INCLUSION", "INCLUSION", "INCLUSION").mkString(",").replace("'", "")

    val obsXidInclusion = if (obsXidInclusionMpv.toLowerCase() == noMPVmatches.toLowerCase()) "" else
      "  and  xid in ( " + obsXidInclusionMpv + " ) "

    val hdidefresult1 = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "OBSERVATION",
      "HDID", "EF_RESULT", "EF_RESULT").mkString(",").replace("'", "")

    val hdidefresult = if (noMPVmatches == hdidefresult1) "''" else hdidefresult1

    val hdidefdate1 = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "OBSERVATION",
      "HDID", "EF_DATE", "EF_DATE").mkString(",").replace("'", "")

    val hdidefdate = if (noMPVmatches == hdidefdate1) "''" else hdidefdate1

    val lvef_script_flag = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "OBSERVATION",
      "LVEF_SCRIPT", "CUSTOM", "CUSTOM").mkString(",").replace("'", "")
    val Whereclause = if (lvef_script_flag =="Y") " AND 1=1" else " AND 1=0"

    sparkSession.conf.set("spark.sql.crossJoin.enabled", "true")

    sparkSession.sql(
      """
        |with dedup_doc AS
        |(SELECT * FROM
        |        (SELECT b.*, ROW_NUMBER() OVER (PARTITION BY b.sdid
        |         ORDER BY b.db_updated_date  DESC NULLS LAST) rn
        |         FROM CENTRICV2_DOCUMENTS b)
        | WHERE rn = 1),
        |
        | dedup_doc1 as(
        |  SELECT * FROM
        |       (SELECT b.*, ROW_NUMBER() OVER (PARTITION BY b.sdid
        |        ORDER BY b.db_updated_date  DESC NULLS LAST, fileid desc nulls last) rn
        |        FROM CENTRICV2_DOCUMENTS b
        |        WHERE 1=1)
        |  WHERE rn = 1
        |),
        |
        |obs_filter as(
        |   SELECT * FROM (
        |         SELECT a.*,CASE when HDID={hdid_ef_result} then obsvalue end ef_results,
        |         CASE when HDID={hdid_ef_date} then obsvalue end ef_Date, {hdid_ef_result} as hdid_new,
        |          row_number() over (partition by pid, sdid, obsdate, hdid order by db_updated_date desc nulls last,
        |          fileid desc nulls last) as rnum
        |           from CENTRICV2_OBSERVATIONS a WHERE pid is not null and hdid in({hdid_ef_result},{hdid_ef_date})
        |         and (state IS NULL OR state NOT IN ('D','I','P','S'))
        |          and (Change IS NULL OR Change IN ('0','1','2'))
        |        {Where_clause}
        |        )
        |        where rnum = 1
        |    ),
        |obs_final as (
        |            select sdid,pid,hdid_new,state,description,db_updated_date,max(to_date(ef_date,'MM/dd/yyyy'))as obsdate,
        |            max(ef_results) as obsresult
        |             from obs_filter group by sdid,pid,hdid_new,state,description,db_updated_date
        |          )
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localobscode as localcode, obstype,
        |obsresult, statuscode, sub_result as localresult, obsdate as resultdate, localobsunit as local_obs_unit, std_obs_unit
        |from
        |(
        |select a.*
        |   , null as obsresult
        |   ,ROW_NUMBER() OVER (PARTITION BY PATIENTID,ENCOUNTERID,localobscode,OBSDATE,OBSTYPE,STATUSCODE
        |         ORDER BY db_updated_date  DESC NULLS LAST) rownumber
        |from( SELECT '{groupid}'                           as groupid
        |,'results'                                      as datasrc
        |,{client_ds_id}                                  as client_ds_id
        |,o.Obsvalue                                     AS localresult
        |,nullif(substr(o.Obsvalue,1,200), '')                      as sub_result
        |,o.Hdid                                         AS localobscode
        |,o.OBSDATE                                      AS obsdate
        |,o.Pid                                          AS patientid
        |,o.Sdid                                         AS encounterid
        |,zcm.Localunit                                  AS localobsunit
        |,zcm.obstype_std_units						              as std_obs_unit
        |,zcm.OBSTYPE                                    as obstype
        |,zcm.CUI
        |,o.State                                       AS statuscode
        |,o.db_updated_date
        |FROM (SELECT * FROM CENTRICV2_OBSERVATIONS
        |      WHERE (state IS NULL OR state NOT IN ('D','I','P','S'))
        |      AND (Change IS NULL OR Change IN ('0','1','2'))
        |      {obs_xid_condition}
        |      ) o
        | INNER JOIN CENTRICV2_ZH_OBSHEAD zh_obs ON (o.hdid = zh_obs.hdid)
        | INNER JOIN (SELECT * FROM dedup_doc
        |             WHERE finalsign = 1 AND status ='S'
        |              {dox_xid_condition}
        |              ) d ON (d.SDID= o.SDID and d.pid = o.pid)
        | INNER JOIN ZCM_OBSTYPE_CODE zcm ON (o.hdid = zcm.obscode and zcm.groupid = '{groupid}'
        |			    and zcm.datasrc = 'results'
        |			    AND zcm.OBSTYPE <> 'LABRESULT'
        |			    )
        |  ) a
        |)
        |where patientid is not null and encounterid is not null and obsdate is not null and rownumber =1
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode, obstype, obsresult,
        |statuscode, sub_result as localresult, obsdate as resultdate, local_obs_unit, std_obs_unit
        |from
        |(
        |select t.*
        |       , null as obsresult
        |from (select '{groupid}'			                          as groupid
        |		       ,'results_def'	                        as datasrc
        |		       ,{client_ds_id}	                        as client_ds_id
        |		       ,o.sdid			                          as encounterid
        |		       ,o.pid			                            as patientid
        |		       ,o.obsdate		                          as obsdate
        |		       ,o.hdid			                          as localcode
        |		       ,o.obsvalue		                        as localresult
        |		       ,nullif(substr(o.obsvalue,1,200), '')	            as sub_result
        |		       ,zcm.obstype	                          as obstype
        |		       ,o.state		                            as statuscode
        |		       ,zcm.localunit	                        as local_obs_unit
        |		       ,zcm.obstype_std_units	                as std_obs_unit
        |		       ,case when lower(o.obsvalue) like '%decline%' then 'Y'
        |         	   		  when lower(o.obsvalue) like '%elsewhere%' then 'Y'
        |         	   		  when lower(o.obsvalue) like '%refuse%' then 'Y'
        |        	   		  when lower(o.obsvalue) like '%immune%' then 'Y'
        |          	    		  when lower(o.obsvalue) like '%defer%' then 'Y'
        |         	    		  when lower(o.obsvalue) like 'not%' then 'Y'
        |         	    		  when lower(o.obsvalue) like '%received at%' then 'Y'
        |         	    		  when lower(o.obsvalue) like '%recommend%' then 'Y'
        |         	    		  when lower(o.obsvalue) like '%not indicated%' then 'Y'
        |                     when lower(o.obsvalue) like '%discuss%' and lower(o.description) not like '%fall%' then 'Y'
        |                     else 'N' end as obs_obsvalue_ok
        |         	   ,row_number() over (partition by o.pid, o.sdid, o.obsdate, o.hdid order by o.db_updated_date desc nulls last) as rownumber
        |		 FROM (SELECT * FROM CENTRICV2_OBSERVATIONS
        |		       WHERE pid is not null and hdid is not null and obsdate is not null
        | 			AND (state IS NULL OR state NOT IN ('D','I','P','S'))
        |   			AND (Change IS NULL OR Change IN ('0','1','2'))
        |          		{obs_xid_condition}
        |			 ) o
        |            INNER JOIN CENTRICV2_ZH_OBSHEAD zh_obs ON (o.hdid = zh_obs.hdid)
        |            INNER JOIN (SELECT * FROM CENTRICV2_DOCUMENTS
        |                        WHERE finalsign = 1 AND status ='S'
        |                        {dox_xid_condition}
        |                        ) d ON (d.SDID= o.SDID and d.pid = o.pid)
        |            INNER JOIN ZCM_OBSTYPE_CODE zcm ON (o.hdid = zcm.obscode and zcm.groupid = '{groupid}'
        |            				    and zcm.datasrc = 'results_def'
        |            				    AND zcm.OBSTYPE <> 'LABRESULT'
        |            				    )
        | 		  ) t
        |)
        |where rownumber = 1 and sub_result is not null and obsdate is not null and obs_obsvalue_ok = 'Y'
        |
        |union all
        |
        |select groupid, datasrc, client_ds_id, encounterid, patientid, obsdate, localcode as localcode, obstype,
        |obsresult, statuscode, localresult as localresult, obsdate as resultdate, local_obs_unit as local_obs_unit, std_obs_unit
        |from
        |(
        |select
        |  '{groupid}'              as groupid
        |  ,'results_ef'         as datasrc
        |  ,{client_ds_id}        as client_ds_id
        |  ,o.sdid               as encounterid
        |  ,o.pid                as patientid
        |  ,o.obsdate            as obsdate
        |  ,o.hdid_NEW           as localcode
        |  ,o.obsresult          as localresult
        |  ,zcm.obstype          as obstype
        |  ,o.state              as statuscode
        |  ,null 				as obsresult
        |  ,zcm.localunit        as local_obs_unit
        |  ,zcm.obstype_std_units as std_obs_unit
        |FROM obs_final o
        |INNER JOIN
        |  (SELECT * FROM dedup_doc1
        |  WHERE finalsign = 1 AND status ='S'
        |  {dox_xid_condition}) d
        |ON (d.SDID= o.SDID and d.pid = o.pid)
        |INNER JOIN zcm_obstype_code zcm
        |ON (o.hdid_new = zcm.obscode and zcm.groupid = '{groupid}'
        |  and zcm.datasrc = 'results_ef'
        |  AND zcm.OBSTYPE <> 'LABRESULT')
        |WHERE 1=1 )
        |where localresult is not null and obsdate is not null
        |
    """.stripMargin
        .replace("{groupid}", groupId).
        replace("{client_ds_id}", clientDsId).
        replace("{dox_xid_condition}", docXidInclusion).
        replace("{obs_xid_condition}", obsXidInclusion).
        replace("{hdid_ef_result}", hdidefresult).
        replace("{hdid_ef_date}", hdidefdate).
        replace("{Where_clause}", Whereclause)
    )


  }
}
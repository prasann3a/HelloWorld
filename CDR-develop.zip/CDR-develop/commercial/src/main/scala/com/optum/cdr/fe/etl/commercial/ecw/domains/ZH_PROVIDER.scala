package com.optum.cdr.fe.etl.commercial.ecw.domains


import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo,RuntimeVariables,UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object ZH_PROVIDER extends FETableInfo[zh_provider] {

  override def name: String = CDRFEParquetNames.zh_provider

  override def dependsOn: Set[String] = Set("USERS", "DOCTORS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val Whereclause = if (groupId == "H770635") {"upper(uni_user.Ulname) not like 'ZZZ%'"} else {"1=1"}

    sparkSession.conf.set("spark.sql.crossJoin.enabled", "true")

    sparkSession.sql(
    """
      |WITH uni_user AS (
      |SELECT  *
      |FROM
      |(
      |	SELECT  u.*
      |	       ,ROW_NUMBER() OVER (PARTITION BY hum_uid ORDER BY mdate DESC NULLS LAST) rn
      |	FROM USERS u
      |	WHERE usertype IN ('1','2','5','9')
      |)
      |WHERE rn = 1),
      |
      |uni_doctor AS (
      |SELECT  *
      |FROM
      |(
      |	SELECT  d.*
      |	       ,ROW_NUMBER() OVER (PARTITION BY doctorid ORDER BY modifieddate DESC NULLS LAST) rn
      |	FROM DOCTORS d
      |)
      |WHERE rn = 1)
      |
      |SELECT  groupid
      |       ,client_ds_id
      |       ,'users' AS datasrc
      |       ,localproviderid
      |       ,credentials
      |       ,dob
      |       ,emailaddress
      |       ,first_name
      |       ,last_name
      |       ,middle_name
      |       ,providername
      |       ,gender
      |       ,npi
      |FROM
      |(
      |	SELECT  '{groupid}'                                                                                                                      AS groupid
      |	       ,{client_ds_id}                                                                                                                   AS client_ds_id
      |	       ,uni_user.Hum_Uid                                                                                                                 AS localproviderid
      |	       ,coalesce(uni_user.Initials,uni_user.Suffix )                                                                                     AS credentials
      |	       ,safe_to_date_length(uni_user.Dob,'MM/dd/yyyy',0)                                                                                          AS dob
      |	       ,uni_user.Uemail                                                                                                                  AS emailaddress
      |	       ,uni_user.Ufname                                                                                                                  AS first_name
      |	       ,uni_user.Ulname                                                                                                                  AS last_name
      |	       ,uni_user.Uminitial                                                                                                               AS middle_name
      |	       ,uni_doctor.Printname                                                                                                             AS providername
      |	       ,uni_user.Sex                                                                                                                     AS gender
      |	       ,CASE WHEN uni_doctor.Npi IN ('9999999999','0000000000','1111111111','1234567890','0123456789') THEN null ELSE uni_doctor.Npi END AS npi
      |	FROM UNI_USER
      |	LEFT OUTER JOIN UNI_DOCTOR
      |	ON (uni_doctor.DoctorID = uni_user.Hum_UID)
      | where {Where_clause}
      |)
    """.stripMargin
      .replace("{groupid}", groupId)
      .replace("{client_ds_id}", clientDsId)
      .replace("{Where_clause}", Whereclause)
    )
  }
}

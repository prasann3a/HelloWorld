package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object LABRESULT_FINAL extends FEQueryAndMetadata[labresult]{

  override def name: String = CDRFEParquetNames.labresult

  override def dependsOn: Set[String] = Set("LABRESULT_WITHOUT_NONNUMERIC", "NONNUMERIC_LABRESULT")

  override def sparkSql: String =
    """
      |SELECT * from LABRESULT_WITHOUT_NONNUMERIC
      |
      |UNION ALL
      |
      |SELECT * from NONNUMERIC_LABRESULT
    """.stripMargin
}

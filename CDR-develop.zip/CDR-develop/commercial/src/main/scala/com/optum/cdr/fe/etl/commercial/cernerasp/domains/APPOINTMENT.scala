package com.optum.cdr.fe.etl.commercial.cernerasp.domains
import com.optum.oap.cdr.models.appointment
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object APPOINTMENT extends FETableInfo[appointment]{

  override def name:String = CDRFEParquetNames.appointment
  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select groupid, client_ds_id, datasrc, patientid, appointmentid, appointmentdate, locationid, providerid, local_appt_type
         |from
         |(
         |TEMP_APPOINTMENT_CACHE
         |)
         |where rownumber=1 and status not in ('APPT_STATUS')
         |
         |union all
         |
         |select groupid, client_ds_id, datasrc, patientid, appointmentid, appointmentdate, locationid, providerid, local_appt_type
         |from
         |(
         |TEMP_APPOINTMENT_CACHE
         |)
         |where rownumber=1 and status in ('APPT_STATUS')
       """.stripMargin)
  }

  override def dependsOn: Set[String] = Set("TEMP_APPOINTMENT_CACHE")
}
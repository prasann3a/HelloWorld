package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.clinicalencounter
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object CLINICALENCOUNTER extends FEQueryAndMetadata[clinicalencounter]{

  override def name: String = CDRFEParquetNames.clinicalencounter

  override def dependsOn: Set[String] = Set("EVENTS_VW", "PATIENT_FAC_GRP_SEG_TB")

  override def sparkSql: String =

  """
    |select groupid, client_ds_id, datasrc, encounterid, facilityid, patientid, arrivaltime, localpatienttype
    |from
    |(
    |SELECT * FROM (
    |SELECT z.*
    |       ,row_number() over (partition by EncounterID order by Last_Modified_Date desc nulls first, FileID desc nulls first ) as rownumber
    |FROM (
    |SELECT '{groupid}' as groupid,'events_vw' as datasrc
    |  ,{client_ds_id} as client_ds_id
    |  ,EVE.Reception_Check_In_Date_Time AS arrivaltime
    |  ,EVE.Event_Id AS encounterid
    |  ,EVE.Patient_Id AS patientid
    |
    |  ,EVE.Facility_Num AS facilityid
    |  ,concat_ws('', {client_ds_id}, '.', EVE.Event_Type_Id) AS localpatienttype
    |  ,EVE.LAST_MODIFIED_DATE, EVE.FileID
    |FROM EVENTS_VW EVE
    |INNER JOIN PATIENT_FAC_GRP_SEG_TB PFG ON (PFG.PATIENT_ID = EVE.PATIENT_ID)
    |WHERE EVE.APPT_STATUS_ID = 0
    |          AND EVE.EVENT_TYPE_ID =1
    |          AND EVE.EVENT_STATUS_CODE = 'A'
    |          AND EVE.RECEPTION_CHECK_IN_OPERHX_ID > 0
    | AND EVE.Reception_Check_In_Date_Time is not null
    | AND EVE.Event_Id is not null
    | AND EVE.Patient_Id is not null
    |
    | ) z
    | ) where rownumber=1
    |)
  """
  .stripMargin

}

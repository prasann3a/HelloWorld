package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, zh_service_line}
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ZH_SERVICE_LINE extends FETableInfo[zh_service_line]{

override def name: String = CDRFEParquetNames.zh_service_line

override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val hdr_int_id = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "SERVICECODE","ZH_SERVICE_LINE","MST_COD_DTL","COD_HDR_INT_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
       |SELECT  groupid
       |       ,client_ds_id
       |       ,localservicecode
       |       ,servicecodedesc
       |FROM
       |(
       |	SELECT  '{groupid}'                                                                       AS groupid
       |	       ,{client_ds_id}                                                                    AS client_ds_id
       |	       ,concat_ws('','{client_ds_id}','.',Cod_Dtl_Int_Id)                                 AS localservicecode
       |	       ,Cod_Dtl_ds                                                                        AS servicecodedesc
       |	       ,ROW_NUMBER() OVER (PARTITION BY Cod_Dtl_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,FileID DESC NULLS LAST) rn
       |	FROM MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL
       |	WHERE Cod_Dtl_Int_Id IS NOT NULL
       |	AND Cod_Dtl_ds IS NOT NULL
       |	AND Cod_Hdr_Int_ID IN ({hdr_int_id})
       |)
       |WHERE rn = 1
       """
        .stripMargin
        .replace("{hdr_int_id}", hdr_int_id)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }
}

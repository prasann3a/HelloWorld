package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.cdr.models.zh_facility

object ZH_FACILITY extends FEQueryAndMetadata[zh_facility]{

  override def name: String = "ZH_FACILITY"

  override def dependsOn: Set[String] = Set("CENTRICV2_ZH_LOCATIONREG")

  override def sparkSql: String =
    """
      |SELECT f.locid       AS facilityid
      |         ,MIN(f.name)   AS facilityname
      |         ,f.zip         AS facilitypostalcd
      |    FROM CENTRICV2_ZH_LOCATIONREG f
      |   GROUP BY f.locid, f.zip
  """.stripMargin

  override def saveDataFrameToParquet: Boolean = true

}

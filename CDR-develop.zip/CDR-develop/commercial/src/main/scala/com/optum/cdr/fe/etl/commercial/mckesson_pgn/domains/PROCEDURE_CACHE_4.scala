package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROCEDURE_CACHE_4 extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_4"

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_TOM100_ORDER_HEADER","MCKESSON_PGN_V1_ZH_TOM200_ORDER_CODE","MCKESSON_PGN_V1_TOM101_ORDER_DETAIL","MAP_PREDICATE_VALUES","MAP_CUSTOM_PROC")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val odrStaLst = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "ORDER_DETAIL","PROCEDURE","ORDER_HEADER","ORD_STA_CD").mkString(",")
    val clientDsIdPrefix = runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |with uni_visit2 AS
        |(SELECT * FROM
        |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
        |                              FileID DESC NULLS LAST) rn
        |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
        |   WHERE Psn_Int_Id IS NOT NULL
        |     AND vst_int_id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'),
        |uni_hdr AS
        |(SELECT * FROM
        |   (SELECT r.*, ROW_NUMBER() OVER (PARTITION BY ord_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
        |      FROM MCKESSON_PGN_V1_TOM100_ORDER_HEADER r
        |     WHERE ord_int_id IS NOT NULL )
        | WHERE rn = 1
        |   AND row_sta_cd <> 'D'
        |   AND Start_Datetime_Ts IS NOT NULL
        |   AND ord_sta_cd IN ({odr_sta_lst})),
        |uni_code1 AS
        |(SELECT * FROM
        |    (SELECT c.*, ROW_NUMBER() OVER (PARTITION BY order_code_int_id ORDER BY Lst_Mod_Ts DESC NULLS LAST, fileid DESC nulls first) rn
        |       FROM MCKESSON_PGN_V1_ZH_TOM200_ORDER_CODE c
        |      WHERE order_code_int_id IS NOT NULL )
        |  WHERE rn = 1
        |    AND row_sta_cd <> 'D')
        |
        |select groupid, datasrc, patientid, proceduredate, encounterid, localcode, codetype, mappedcode, client_ds_id, localname, orderingproviderid, performingproviderid, procseq, hosp_px_flag, actualprocdate, proc_end_date, localprincipleindicator
        |from
        |(
        |SELECT '{groupid}'         	 AS groupid
        |      ,'order_detail'            AS datasrc
        |      ,{client_ds_id}             AS client_ds_id
        |      ,concat_ws('', '{client_ds_id_prefix}', od.Order_Code_Int_Id) AS localcode
        |      ,uni_visit2.Psn_Int_Id      AS patientid
        |      ,CASE WHEN uni_hdr.Start_Datetime_Ts < current_date THEN uni_hdr.Start_Datetime_Ts ELSE NULL END AS proceduredate
        |      ,od.Vst_Int_Id 	         AS encounterid
        |      ,uni_hdr.Car_Gvr_Int_Id    AS orderingproviderid
        |      ,COALESCE(uni_Code1.Order_Code_Desc1,uni_Code1.Order_Code_Desc2)  AS localname
        |      ,od.Order_Seq_Number	 AS procseq
        |      ,CASE WHEN uni_hdr.Stop_Datetime_Ts < current_date THEN uni_hdr.Stop_Datetime_Ts ELSE NULL END  AS proc_end_date
        |      ,NULL 			 AS hosp_px_flag
        |      ,'CUSTOM'  		 AS codetype
        |      ,NULL                      AS localprincipleindicator
        |      ,map.mappedvalue           AS mappedcode
        |      ,NULL        		 AS performingproviderid
        |      ,NULL                      AS actualprocdate
        |      ,ROW_NUMBER() OVER (PARTITION BY uni_visit2.Psn_Int_Id, od.Vst_Int_Id,uni_hdr.Start_Datetime_Ts,od.Order_Code_Int_Id
        |                               ORDER BY od.Lst_Mod_Ts DESC NULLS LAST) rn
        |FROM MCKESSON_PGN_V1_TOM101_ORDER_DETAIL od
        |   JOIN MAP_CUSTOM_PROC map ON (map.groupid = '{groupid}' AND
        |                               map.datasrc = 'order_detail' AND
        |   			    map.localcode = concat_ws('', '{client_ds_id_prefix}', od.Order_Code_Int_Id))
        |   JOIN UNI_VISIT2 ON (uni_visit2.vst_int_id = od.vst_int_id)
        |   JOIN UNI_HDR ON (od.ord_int_id = uni_hdr.ord_int_id)
        |   JOIN UNI_CODE1 ON (uni_code1.order_code_int_id = od.order_code_int_id)
        |WHERE od.row_sta_cd <> 'D'
        |  AND od.Order_Code_Int_Id IS NOT NULL
        |)
        |where proceduredate IS NOT NULL AND patientid IS NOT NULL
      """.stripMargin
        .replace("{odr_sta_lst}",odrStaLst)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{client_ds_id_prefix}",clientDsIdPrefix)
    )
  }
}

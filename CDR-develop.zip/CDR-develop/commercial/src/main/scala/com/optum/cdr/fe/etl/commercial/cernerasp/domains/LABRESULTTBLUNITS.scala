package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.etl.commercial.med3000.domains.lab_result
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object LABRESULTTBLUNITS extends FETableInfo[labsubquery]{

  override def name:String="LABRESULTTBLUNITS"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }
    val lab_status= mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"LAB_STATUS","LAB","RESULT","STATUS").mkString(",")

    sparkSession.sql(
      s"""
         |select element_code, description from (
         |                  select element_code, lower(description) as description,
         |                  row_number() over (partition by element_code order by length(description) desc nulls first) as rw
         |                  from REFERENCECODE
         |                  where field = 'UNITS' and file_name = 'RESULT'
         |                  )where rw=1

       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{lab_status}",lab_status)

    )
  }

  override def dependsOn: Set[String] = Set("REFERENCECODE","MAP_PREDICATE_VALUES")


}
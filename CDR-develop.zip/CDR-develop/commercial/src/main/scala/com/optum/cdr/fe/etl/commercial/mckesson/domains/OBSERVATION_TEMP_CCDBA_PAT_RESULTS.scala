package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.observation
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_TEMP_CCDBA_PAT_RESULTS extends FETableInfo[observation]{
  override def name: String = "OBSERVATION_TEMP_CCDBA_PAT_RESULTS"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_CCDBA_PAT_RESULTS","MCKESSON_ENT_PATIENT","ZCM_OBSTYPE_CODE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val deptid_list = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), groupId, clientDsId, "CCDBA_PAT_RESULTS", "OBSERVATION", "CCDBA_PAT_RESULTS", "DEPT_ID").mkString(",")

    sparkSession.sql(
      s"""
         |WITH uni_res AS
         |(SELECT * FROM
         |(SELECT p.*, CASE WHEN label_seq IN ('25494', '193045') AND dept_id IN ({deptid_list}) THEN
         |	   	concat_ws('', {client_ds_id}, '.', label_seq, '-', dept_id)
         |	      ELSE concat_ws('', {client_ds_id}, '.', label_seq) END AS localcode_str
         |	   ,ROW_NUMBER() OVER (PARTITION BY result_seq ORDER BY chart_ddt DESC NULLS LAST) rn
         | FROM MCKESSON_CCDBA_PAT_RESULTS p
         | WHERE label_Seq IS NOT NULL
         |   AND (result_value IS NOT NULL OR annotation IS NOT NULL)
         |   AND Perform_Ddt IS NOT NULL )
         | WHERE rn = 1),
         | uni_pat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |   WHERE cpi_seq IS NOT NULL )
         |) WHERE rn = 1)
         |select datasrc, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid
         |from
         |(
         |SELECT 'ccdba_pat_results' 	AS datasrc
         |	,CASE WHEN z.obstype IN ('SMOKE', 'ALCOHOL', 'CH001850') THEN concat_ws('', {client_ds_id}, '.', COALESCE(uni_res.result_value,uni_res.annotation))
         |              ELSE COALESCE(uni_res.result_value,uni_res.annotation) END AS localresult
         |
         |	,uni_res.localcode_str  AS localcode
         |	,uni_res.Perform_Ddt  	AS obsdate
         |	,uni_pat.cpi_seq  	AS patientid
         |	,uni_res.pat_seq  	AS encounterid
         |	,uni_res.facility_id 	AS facilityid
         |	,z.obstype
         |
         |	,COALESCE(uni_res.units, z.localunit) AS local_obs_unit
         |    	,z.obstype_std_units 	AS std_obs_unit
         |	,NULL 			AS obsresult
         |	,ROW_NUMBER() OVER (PARTITION BY uni_pat.cpi_seq,uni_res.pat_seq,uni_res.localcode_str,uni_res.Perform_Ddt,z.obstype
         |			    ORDER BY uni_res.chart_ddt DESC NULLS LAST) obs_rn
         |FROM UNI_RES
         |    JOIN UNI_PAT ON (uni_res.pat_seq = uni_pat.pat_seq)
         |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
         |				z.datasrc = 'ccdba_pat_results' AND
         |				z.obstype <> 'LABRESULT' AND
         |				z.obscode = uni_res.localcode_str)
         |
         |)
         |where obs_rn = 1
       """.stripMargin.replace("{deptid_list}",deptid_list).replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId))
  }
}

package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.BaseQueryConfig
import com.optum.cdr.fe.etl.commercial.ecw.domains.QueryRegistry
import com.optum.cdr.fe.utils.nonnumeric_labs_localresult_25.NONNUMERIC_LABRESULT
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{FELoadFromParquet, RuntimeVariables, TableInfo}

object McKessonQueries extends  BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries
}

object McKessonQueriesWithDrugAssign extends  BaseQueryConfig {
  override def initialDependenciesSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = InitialDependencies.initialDataSeq(baseParquetLocation, mappingParquetPath, runtimeVariables)
  override def queryRegistry: Seq[TableInfo[_ <: Product with Serializable]] = QueryRegistry.queries ++ QueryRegistry.drug_assign_queries
}

object InitialDependencies {

  def initialDataSeq(baseParquetLocation: String, mappingParquetPath: String, runtimeVariables: RuntimeVariables): Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    FELoadFromParquet[mckesson_ccdba_o_pat_occur](name = "MCKESSON_CCDBA_O_PAT_OCCUR", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_O_PAT_OCCUR", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_ccdba_anc_order](name = "MCKESSON_CCDBA_ANC_ORDER", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_ANC_ORDER", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_ccdba_anc_results](name = "MCKESSON_CCDBA_ANC_RESULTS", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_ANC_RESULTS", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_ccdba_pat_results](name = "MCKESSON_CCDBA_PAT_RESULTS", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_PAT_RESULTS", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ccdba_med_order](name = "CCDBA_MED_ORDER", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_MED_ORDER", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ccdba_med_admin](name = "CCDBA_MED_ADMIN", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_MED_ADMIN", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ccdba_o_pat](name = "CCDBA_O_PAT", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_O_PAT", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ccdba_triage_info](name = "CCDBA_TRIAGE_INFO", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_TRIAGE_INFO", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ccdba_iv_admin](name = "CCDBA_IV_ADMIN", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_IV_ADMIN", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ccdba_o_action](name = "CCDBA_O_ACTION", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_O_ACTION", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ccdba_tb_patient](name = "CCDBA_TB_PATIENT", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_TB_PATIENT", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ent_cpi](name = "ENT_CPI", parquetLocation = s"$baseParquetLocation", tableName="ENT_CPI", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ccdba_pf_results](name = "CCDBA_PF_RESULTS", parquetLocation = s"$baseParquetLocation", tableName="CCDBA_PF_RESULTS", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_ent_cpi_allergy](name = "MCKESSON_ENT_CPI_ALLERGY", parquetLocation = s"$baseParquetLocation", tableName="ENT_CPI_ALLERGY", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ent_cpi_address](name = "ENT_CPI_ADDRESS", parquetLocation = s"$baseParquetLocation", tableName="ENT_CPI_ADDRESS", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ent_cpi_insurance](name = "MCKESSON_ENT_CPI_INSURANCE", parquetLocation = s"$baseParquetLocation", tableName="ENT_CPI_INSURANCE", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ent_cpi_contact](name = "ENT_CPI_CONTACT", parquetLocation = s"$baseParquetLocation", tableName="ENT_CPI_CONTACT", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ent_cpi_problem](name = "ENT_CPI_PROBLEM", parquetLocation = s"$baseParquetLocation", tableName="ENT_CPI_PROBLEM", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_ent_patient](name = "MCKESSON_ENT_PATIENT", parquetLocation = s"$baseParquetLocation", tableName="ENT_PATIENT", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ent_patient_diagnosis](name = "ENT_PATIENT_DIAGNOSIS", parquetLocation = s"$baseParquetLocation", tableName="ENT_PATIENT_DIAGNOSIS", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_ent_patient_insurance](name = "MCKESSON_ENT_PATIENT_INSURANCE", parquetLocation = s"$baseParquetLocation", tableName="ENT_PATIENT_INSURANCE", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ent_cpi_medication](name = "ENT_CPI_MEDICATION", parquetLocation = s"$baseParquetLocation", tableName="ENT_CPI_MEDICATION", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[ent_staff_assign](name = "ENT_STAFF_ASSIGN", parquetLocation = s"$baseParquetLocation", tableName="ENT_STAFF_ASSIGN", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_hhs_cpi_immunization](name = "MCKESSON_HHS_CPI_IMMUNIZATION", parquetLocation = s"$baseParquetLocation", tableName="HHS_CPI_IMMUNIZATION", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_hhs_cpi_procedure](name = "MCKESSON_HHS_CPI_PROCEDURE", parquetLocation = s"$baseParquetLocation", tableName="HHS_CPI_PROCEDURE", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_zh_ccdev_anc_res_code_seqs](name = "MCKESSON_ZH_CCDEV_ANC_RES_CODE_SEQS", parquetLocation = s"$baseParquetLocation", tableName="ZH_CCDEV_ANC_RES_CODE_SEQS", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_zh_ccdev_anc_test_codes](name = "MCKESSON_ZH_CCDEV_ANC_TEST_CODES", parquetLocation = s"$baseParquetLocation", tableName="ZH_CCDEV_ANC_TEST_CODES", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_zh_ccdev_pcq_label](name = "MCKESSON_ZH_CCDEV_PCQ_LABEL", parquetLocation = s"$baseParquetLocation", tableName="ZH_CCDEV_PCQ_LABEL", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[zh_ccdev_drug](name = "ZH_CCDEV_DRUG", parquetLocation = s"$baseParquetLocation", tableName="ZH_CCDEV_DRUG", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[zh_ccdev_o_item](name = "ZH_CCDEV_O_ITEM", parquetLocation = s"$baseParquetLocation", tableName="ZH_CCDEV_O_ITEM", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[zh_drug1_fdb_packageddrug](name = "ZH_DRUG1_FDB_PACKAGEDDRUG", parquetLocation = s"$baseParquetLocation", tableName="ZH_DRUG1_FDB_PACKAGEDDRUG", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_zh_ent_config_code_set](name = "MCKESSON_ZH_ENT_CONFIG_CODE_SET", parquetLocation = s"$baseParquetLocation", tableName="ZH_ENT_CONFIG_CODE_SET", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[zh_ent_config_lov](name = "ZH_ENT_CONFIG_LOV", parquetLocation = s"$baseParquetLocation", tableName="ZH_ENT_CONFIG_LOV", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[zh_ent_config_staff](name = "ZH_ENT_CONFIG_STAFF", parquetLocation = s"$baseParquetLocation", tableName="ZH_ENT_CONFIG_STAFF", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[zh_ent_config_staff_address](name = "ZH_ENT_CONFIG_STAFF_ADDRESS", parquetLocation = s"$baseParquetLocation", tableName="ZH_ENT_CONFIG_STAFF_ADDRESS", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[zh_ent_config_staff_specialty](name = "ZH_ENT_CONFIG_STAFF_SPECIALTY", parquetLocation = s"$baseParquetLocation", tableName="ZH_ENT_CONFIG_STAFF_SPECIALTY", ignoreExtraColumnsInDataFrame = true)
    ,FELoadFromParquet[mckesson_zh_ent_config_organization](name = "MCKESSON_ZH_ENT_CONFIG_ORGANIZATION", parquetLocation = s"$baseParquetLocation", tableName="ZH_ENT_CONFIG_ORGANIZATION", ignoreExtraColumnsInDataFrame = true)

    ,FELoadFromParquet[map_predicate_values](name = "MAP_PREDICATE_VALUES", parquetLocation = s"$mappingParquetPath", tableName="MAP_PREDICATE_VALUES")
    ,FELoadFromParquet[map_provider_role](name = "MAP_PROVIDER_ROLE", parquetLocation = s"$mappingParquetPath", tableName="MAP_PROVIDER_ROLE")
    ,FELoadFromParquet[zcm_obstype_code](name = "ZCM_OBSTYPE_CODE", parquetLocation = s"$mappingParquetPath", tableName="ZCM_OBSTYPE_CODE")
    ,FELoadFromParquet[zcm_treatment_type_code](name = "ZCM_TREATMENT_TYPE_CODE", parquetLocation = s"$mappingParquetPath", tableName="ZCM_TREATMENT_TYPE_CODE")
    ,FELoadFromParquet[ref_snomed_icd9](name = "REF_SNOMED_ICD9", parquetLocation = s"$mappingParquetPath", tableName="REF_SNOMED_ICD9")
    ,FELoadFromParquet[ref_snomed_icd10](name = "REF_SNOMED_ICD10", parquetLocation = s"$mappingParquetPath", tableName="REF_SNOMED_ICD10")
    ,FELoadFromParquet[map_custom_proc](name = "MAP_CUSTOM_PROC", parquetLocation = s"$mappingParquetPath", tableName="MAP_CUSTOM_PROC")
    , FELoadFromParquet[map_unit](name = "MAP_UNIT", parquetLocation = s"$mappingParquetPath", tableName="MAP_UNIT")
    , FELoadFromParquet[unit_remap](name = "UNIT_REMAP", parquetLocation = s"$mappingParquetPath", tableName="UNIT_REMAP")
    , FELoadFromParquet[metadata_lab](name = "METADATA_LAB", parquetLocation = s"$mappingParquetPath", tableName="METADATA_LAB")
    , FELoadFromParquet[unit_conversion](name = "UNIT_CONVERSION", parquetLocation = s"$mappingParquetPath", tableName="UNIT_CONVERSION")
  )
}


object QueryRegistry {
  val queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    ALLERGY,
    CLAIM,
    CLINICALENCOUNTER,
    ENCOUNTERCAREAREA,
    IMMUNIZATION,
    INSURANCE,
    LABRESULT,
    MBORDER,
    ZH_FACILITY
    ,LABMAPPERDICT
    ,PATIENTADDRESS
    ,PATIENTREPORTEDMEDS
    ,PATIENTCONTACT
    ,RXORDERSANDPRESCRIPTIONS
    ,RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_O_PAT
    ,RXORDERSANDPRESCRIPTIONS_TEMP_CCDBA_MED_ORDER
    ,TREATMENT_ADMINISTERED
    ,TREATMENT_ORDERED
    ,PROVIDERCONTACT
    ,PROVIDER
    ,PROVIDERSPECIALTY
    ,PROVIDERPATIENTRELATION
    ,ENCOUNTERPROVIDER
    ,DIAGNOSIS
    ,DIAGNOSIS_TEMP_ENT_CPI_PROBLEM
    ,DIAGNOSIS_TEMP_ENT_PATIENT_DIAGNOSIS
    ,RXMEDADMINISTRATIONS
    ,RXMEDADMINISTRATIONS_TEMP_CCDBA_MED_ORDER
    ,RXMEDADMINISTRATIONS_TEMP_CCDBA_O_PAT
    ,PROCEDURE
    ,PROCEDURE_TEMP_CCDBA_PAT_RESULTS
    ,PROCEDURE_TEMP_HHS_CPI_PROCEDURE
    ,PROCEDURE_TEMP_HHS_CPI_PROCEDURE2
    ,PROCEDURE_TEMP_CCDBA_TRIAGE_INFO
    ,PROCEDURE_TEMP_CCDBA_IV_ADMIN
    ,PROCEDURE_TEMP_CCDBA_O_ACTION
    ,PROCEDURE_TEMP_CCDBA_O_PAT_OCCUR
    ,PROCEDURE_TEMP_ENT_PATIENT
    ,PATIENT_CACHE
    ,PATIENT
    ,PATIENTDETAIL
    ,PATIENTIDENTIFIER
    ,OBSERVATION
    ,OBSERVATION_TEMP_CCDBA_O_PAT
    ,OBSERVATION_TEMP_CCDBA_PAT_RESULTS
    ,OBSERVATION_TEMP_ENT_PATIENT
    ,OBSERVATION_TEMP_CCDBA_PF_RESULTS
    ,LABRESULT_MCKESSON
    ,NONNUMERIC_LABRESULT
    ,GTT_LABRESULT_NONNUMERIC
    ,LABRESULT_CACHE_1
    ,LABRESULT_CACHE_2
  )

  val drug_assign_queries: Seq[TableInfo[_ <: Product with Serializable]] = Seq(
    MEDICATION_MAP_SRC
    ,  MEDICATION_MAP_SRC_ALLERGIES
    ,  MEDICATION_MAP_SRC_IMMUNIZATIONS
    ,  MEDICATION_MAP_SRC_RX_PATIENT_REPORTED
    ,  MEDICATION_MAP_SRC_RXADMIN
    ,  MEDICATION_MAP_SRC_RXORDER_CCDBA_MED_ORDER
    ,  MEDICATION_MAP_SRC_RXORDER_CCDBA_O_PAT
  )
} 

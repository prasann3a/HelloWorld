package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.cdr.fe.utils.verify.MedicationMapSrcVerify
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC extends FETableInfo[medication_map_src]{

  override def name: String = CDRFEParquetNames.medication_map_src

  override def dependsOn: Set[String] = Set("MEDICATIONS", "ZH_DRUGS", "ZH_DRUG_NDC", "ASPRO_HX_MEDICATION","HXDIAGNOSIS","ASPRO_IMMUNIZATIONS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val srcMedMapInput = sparkSession.sql(
    """
       select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs, localbrand, localgeneric, localgpi, localform, localstrength, ndc_src
         from
        (
        select '{groupid}' as groupid
                ,'medications' as datasrc
                ,{client_ds_id} as client_ds_id
                ,a.med_code as localmedcode
                ,d.ndc_code AS localndc
                ,COALESCE(zd.Drug_Title, a.Med_Originaltitle) AS localdescription
                ,null as localbrand
                ,null as localgeneric
                ,a.med_gpi as localgpi
                ,a.med_doseunit as localform
                ,zd.drug_strength as localstrength
                ,sum(nvl2(d.Ndc_Code,0,1)) as no_ndc
                ,sum(nvl2(d.Ndc_Code,1,0)) as has_ndc
                ,count(*) as num_recs
                ,cast(null as String) as ndc_src
        from MEDICATIONS a
        left outer join ZH_DRUGS zd on (a.med_code = zd.drug_code)
        LEFT OUTER JOIN ZH_DRUG_NDC d ON (a.med_code = d.ndc_drugdescid)
        where a.med_code is not null
        group by a.med_code, d.ndc_code, COALESCE(zd.Drug_Title, a.Med_Originaltitle), a.med_gpi
              ,a.med_doseunit,zd.drug_strength
        )

        union all

        select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs, localbrand, localgeneric, localgpi, localform, localstrength, ndc_src
        from
        (
        SELECT '{groupid}' as groupid
                ,'hx_medications' as datasrc
                ,{client_ds_id} as client_ds_id
                ,hx.source_code as localmedcode
                ,Zh_Drug_Ndc.Ndc_Code as localndc
                ,coalesce(Zh_Drugs.Drug_Title,hx.Originaltitle) as localdescription
                ,sum(nvl2(Zh_Drug_Ndc.Ndc_Code,0,1)) as no_ndc
                ,sum(nvl2(Zh_Drug_Ndc.Ndc_Code,1,0)) as has_ndc
                ,count(*) as num_recs
                ,null as localbrand
                ,null as localgeneric
                ,null as localgpi
                ,null as localform
                ,null as localstrength
                ,cast(null as String) as ndc_src
        FROM ASPRO_HX_MEDICATION hx
          LEFT OUTER JOIN ZH_DRUGS ON (hx.source_code = zh_drugs.drug_code)
          LEFT OUTER JOIN ZH_DRUG_NDC ON (zh_drugs.drug_code = zh_drug_ndc.ndc_drugdescid)
          LEFT OUTER JOIN MEDICATIONS ON (medications.imremed_code = hx.medication_id and medications.imredemec_code = hx.patient_id)
        WHERE hx.source_code not in ('FREETEXT', 'NONE', 'RECONCIL')
        GROUP BY hx.source_code, Zh_Drug_Ndc.Ndc_Code, coalesce(Zh_Drugs.Drug_Title,hx.Originaltitle)
        )

        union all

        select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs, localbrand, localgeneric, localgpi, localform, localstrength, ndc_src
        from
        (
        SELECT '{groupid}' as groupid
                ,'hxdiagnosis' as datasrc
                ,{client_ds_id} as client_ds_id
                ,Hxdiagnosis.Source_Code as localmedcode
                ,Zh_Drug_Ndc.Ndc_Code as localndc
                ,coalesce(Zh_Drugs.Drug_Title ,Hxdiagnosis.Title) as localdescription
                ,sum(nvl2(Zh_Drug_Ndc.Ndc_Code,0,1)) as no_ndc
                ,sum(nvl2(Zh_Drug_Ndc.Ndc_Code,1,0)) as has_ndc
                ,count(*) as num_recs
                ,null as localbrand
                ,null as localgeneric
                ,null as localgpi
                ,null as localform
                ,null as localstrength
                ,cast(null as String) as ndc_src
        FROM HXDIAGNOSIS
          LEFT OUTER JOIN ZH_DRUGS ON (hxdiagnosis.source_code = zh_drugs.drug_code)
          LEFT OUTER JOIN ZH_DRUG_NDC ON (zh_drugs.drug_code = zh_drug_ndc.ndc_drugdescid)
        WHERE hxdiagnosis.category_code = '21'
          AND source_code <> 'FREETEXT'
        GROUP BY Hxdiagnosis.Source_Code, Zh_Drug_Ndc.Ndc_Code, coalesce(Zh_Drugs.Drug_Title ,Hxdiagnosis.Title)
        )

        union all

        select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs, localbrand, localgeneric, localgpi, localform, localstrength, ndc_src
        from
        (
        SELECT '{groupid}' as groupid
                ,'immunizations' as datasrc
                ,{client_ds_id} as client_ds_id
                ,im.Immunization_Id as localmedcode
                ,Zh_Drug_Ndc.Ndc_Code as localndc
                ,im.Immunization_Name as localdescription
                ,sum(nvl2(Zh_Drug_Ndc.Ndc_Code,0,1)) as no_ndc
                ,sum(nvl2(Zh_Drug_Ndc.Ndc_Code,1,0)) as has_ndc
                ,count(*) as num_recs
                ,null as localbrand
                ,null as localgeneric
                ,null as localgpi
                ,null as localform
                ,null as localstrength
                ,cast(null as String) as ndc_src
        FROM ASPRO_IMMUNIZATIONS im
          LEFT OUTER JOIN ZH_DRUGS ON (im.DRUG_CODE = ZH_DRUGS.DRUG_CODE)
          LEFT OUTER JOIN ZH_DRUG_NDC ON (zh_drugs.drug_code = zh_drug_ndc.ndc_drugdescid)
        WHERE im.status_code = '4'
        GROUP BY im.Immunization_Id, Zh_Drug_Ndc.Ndc_Code, im.Immunization_Name
        )
      """.replace("{groupid}", groupId)
         .replace("{client_ds_id}", clientDsId))

          MedicationMapSrcVerify.run(srcMedMapInput)

        }
}

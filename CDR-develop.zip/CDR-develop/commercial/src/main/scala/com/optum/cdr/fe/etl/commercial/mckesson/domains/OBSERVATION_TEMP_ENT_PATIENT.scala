package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object OBSERVATION_TEMP_ENT_PATIENT extends FETableInfo[observation] {
  override def name: String = "OBSERVATION_TEMP_ENT_PATIENT"

  override def dependsOn: Set[String] = Set("MCKESSON_ENT_PATIENT","ZCM_OBSTYPE_CODE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |WITH uni_pat AS
         | (SELECT * FROM (
         | (SELECT p.*, ROW_NUMBER() OVER (PARTITION BY pat_seq ORDER BY modified_dt DESC NULLS LAST) rn
         |    FROM MCKESSON_ENT_PATIENT p
         |   WHERE cpi_seq IS NOT NULL )
         |) WHERE rn = 1)
         |select datasrc, encounterid, patientid, obsdate, localcode, obsresult, localresult, obstype, local_obs_unit, std_obs_unit, facilityid
         |from
         |(
         |SELECT 'hospice' 		AS datasrc
         |	,uni_pat.Patient_Type_Seq AS localresult
         |	,concat_ws('', {client_ds_id}, '.', uni_pat.Patient_Type_Seq) AS localcode
         |	,COALESCE(uni_pat.Admit_Dt,uni_pat.Transfer_Dt,uni_pat.Discharge_Dt,uni_pat.Created_Dt)	AS obsdate
         |	,uni_pat.cpi_seq  	AS patientid
         |	,uni_pat.pat_seq  	AS encounterid
         |	,uni_pat.pat_seq 	AS facilityid
         |	,z.obstype
         |	,z.localunit 		AS local_obs_unit
         |    	,z.obstype_std_units 	AS std_obs_unit
         |	,NULL 			AS obsresult
         |	,ROW_NUMBER() OVER (PARTITION BY uni_pat.cpi_seq,uni_pat.pat_seq,uni_pat.Patient_Type_Seq,COALESCE(uni_pat.Admit_Dt,uni_pat.Transfer_Dt,uni_pat.Discharge_Dt,uni_pat.Created_Dt),z.obstype
         |			    ORDER BY uni_pat.modified_dt DESC NULLS LAST) obs_rn
         |FROM UNI_PAT
         |    JOIN ZCM_OBSTYPE_CODE z ON (z.groupid = '{groupid}' AND
         |				z.datasrc = 'hospice' AND
         |				z.obscode = concat_ws('', {client_ds_id}, '.', uni_pat.Patient_Type_Seq))
         |
         |)
         |where obs_rn = 1
       """.stripMargin.replace("{groupid}",groupId).replace("{client_ds_id}",clientDsId))
  }
}

package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.encounterprovider
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ENCOUNTERPROVIDER extends  FETableInfo[encounterprovider]{


  override def name:String=CDRFEParquetNames.encounterprovider

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    val list_provrole=mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"PROVROLE","ENCOUNTERPROVIDER","RELATION","RELATIONSHIP_TYPE").mkString(",")


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      s"""
         |select groupid, client_ds_id, datasrc, encounterid, facilityid, patientid, providerid, providerrole, encountertime
         |from
         |(
         |CLINICALCACHE
         |)
         |where  ep_rownumber = 1 and providerid is not null and providerrole in ({list_provrole})
       """.stripMargin
        .replace("{list_provrole}", list_provrole)
    )

  }

  override def dependsOn: Set[String] = Set("CLINICALCACHE","MAP_PREDICATE_VALUES")
}
package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.rxadmin

object RXMEDADMINISTRATIONS extends FEQueryAndMetadata[rxadmin]{
  override def name: String = CDRFEParquetNames.rxadmin

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT","MCKESSON_PGN_V1_TCP540_RX_ADS_INFO","MCKESSON_PGN_V1_TCP500_RX_ADS")

  override def sparkSql: String =
    """
      |WITH uni_visit AS
      |(SELECT * FROM
      |(SELECT v.*, ROW_NUMBER() OVER (PARTITION BY Vst_Int_Id ORDER BY Lst_Mod_Ts DESC NULLS LAST,
      |                              FileID DESC nulls first) rn
      |   FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT v
      |  WHERE Psn_Int_Id IS NOT NULL
      |    AND Vst_Int_Id IS NOT NULL )
      | WHERE rn = 1
      |   AND row_sta_cd <> 'D'),
      |uni_adm_info AS
      |(SELECT * FROM (
      |      SELECT i.*, ROW_NUMBER() OVER (PARTITION BY ads_inf_int_id, ads_inf_seq_no
      |                       ORDER BY Lst_Mod_Ts DESC NULLS LAST, FileID DESC nulls first) rn
      |      FROM MCKESSON_PGN_V1_TCP540_RX_ADS_INFO i
      |      WHERE ads_inf_int_id IS NOT NULL )
      |WHERE row_sta_cd <> 'D' AND rn = 1)
      |select groupid, datasrc, client_ds_id, localmedcode, patientid, administrationtime, encounterid, concat_ws('','{client_ds_id}','.',localroute) as localroute, rxorderid, localdrugdescription, localtotaldose, localproviderid, localinfusionrate, localinfusionvolume, localdoseunit, localform, localgenericdesc, localndc, localqtyofdoseunit, localstrengthperdoseunit, localstrengthunit, qtydispensed, rxadministrationid, rxnorm_code
      |from
      |(
      |SELECT
      |	'{groupid}' 	   AS groupid
      |	,'rx_ads' 	   AS datasrc
      |	,{client_ds_id}     AS client_ds_id
      |	,COALESCE(uni_adm_info.Brd_Ds,uni_adm_info.Med_Ds) AS localmedcode
      |	,uni_visit.Psn_Int_Id     AS patientid
      |	,Uni_adm_info.Vst_Int_Id  AS encounterid
      |	,CASE WHEN NVL(COALESCE(adm.Ads_Rte_Ds,uni_adm_Info.Rte_Ds), '--') <> '--' THEN
      |             COALESCE(adm.Ads_Rte_Ds,uni_adm_Info.Rte_Ds) END AS localroute
      |	,concat_ws('', adm.Prx_Int_Id, '_', adm.Prx_Itm_Int_Id)   AS rxorderid
      |	,Ads_Rat_Ds       AS localinfusionrate
      |	,NULL             AS localinfusionvolume
      |	,uni_adm_info.Fom_Ds   AS localdoseunit
      |	,COALESCE(uni_adm_info.Brd_Ds,uni_adm_info.Med_Ds) AS localdrugdescription
      |	,uni_adm_info.Fom_Ds   AS localform
      |	,uni_adm_info.Med_Ds   AS localgenericdesc
      |	,COALESCE(adm.Ndc_Cd_Adm,adm.Ndc_Cd)  AS localndc
      |	,NULL                  AS localqtyofdoseunit
      |    ,nullif(Trim(nullif(regexp_replace_5param(regexp_replace_5param(Coalesce(adm.Ads_Dse_Ds,uni_adm_info.Dse_Ds), '[A-Za-z%(),]+','',1,0),'/$','',1,0), '')), '') AS localstrengthperdoseunit
      |    ,nullif(Trim(nullif(regexp_replace_5param(Coalesce(adm.Ads_Dse_Ds,uni_adm_info.Dse_Ds), '[0-9.,]+', '',1,0), '')), '') AS localstrengthunit
      |    ,nullif(Trim(nullif(regexp_replace_5param(regexp_replace_5param(Coalesce(adm.Ads_Dse_Ds,uni_adm_info.Dse_Ds), '[A-Za-z%(),]+','',1,0),'/$','',1,0), '')), '') AS localtotaldose
      |    ,adm.Rx_Nor_Cd_Adm AS rxnorm_code
      |	,adm.Ads_Dos_Qy    AS qtydispensed
      |	,concat_ws('', adm.Ads_Int_Id, '_', adm.Rx_Seq_No)  AS rxadministrationid
      |	,NULL              AS localproviderid
      |	,COALESCE(adm.Ads_Ts,uni_adm_info.Ads_Srt_Dt) AS administrationtime
      |        ,ROW_NUMBER() OVER (PARTITION BY concat_ws('', adm.Ads_Int_Id, '_', adm.Rx_Seq_No) ORDER BY adm.Lst_Mod_Ts DESC NULLS LAST) rn
      |FROM MCKESSON_PGN_V1_TCP500_RX_ADS adm
      |   JOIN UNI_ADM_INFO ON (adm.ads_inf_int_id = uni_adm_info.ads_inf_int_id)
      |   JOIN UNI_VISIT ON (uni_adm_info.vst_int_id = uni_visit.vst_int_id)
      |WHERE adm.row_sta_cd <> 'D'
      |
      |)
      |where patientid IS NOT NULL AND rn = 1
    """.stripMargin

}

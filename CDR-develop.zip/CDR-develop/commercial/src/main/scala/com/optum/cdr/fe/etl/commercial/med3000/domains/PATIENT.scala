package com.optum.cdr.fe.etl.commercial.med3000.domains

import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT extends FEQueryAndMetadata[patient]{

  override def name: String = CDRFEParquetNames.patient

  override def dependsOn: Set[String] = Set("TEMP_PATIENT_CACHE")

  override def sparkSql: String =
    """
      select patientid, dateofdeath,  datasrc, dob as dateofbirth,  medicalrecordnumber
 |from
 |(
 |TEMP_PATIENT_CACHE
 |)
 |where rank_pat=1  and patientid is not null
    """.stripMargin
}

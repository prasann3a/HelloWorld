package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.insurance
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, CDRFEParquetNames}

object INSURANCE extends FEQueryAndMetadata[insurance]{

  override def name: String = CDRFEParquetNames.insurance

  override def dependsOn: Set[String] = Set("LSS_PBRACCOUNTS", "LSS_PBRACCOUNTEPISODES", "LSS_DPBRINSURANCE", "LSS_PBRACCOUNTEPIINSURANCE", "LSS_PBRACCOUNTEPIINSURANCEORDER", "LSS_PBRACCOUNTTRANSACTIONS")

  override def sparkSql: String =
    """
      |with act_qry AS (
      |     SELECT  *
      |     FROM
      |     (
      |          SELECT  z.*
      |               ,row_number () over ( Partition by SourceID,AccountID ORDER BY RowUpdateDateTime desc nulls first,PatientID desc nulls first ) AS act_rownumber
      |          FROM LSS_PBRACCOUNTS z
      |     )
      |     WHERE act_rownumber = 1
      |)
      |, epi_qry AS (
      |     SELECT  *
      |     FROM
      |     (
      |          SELECT  t.*
      |               ,row_number () over ( partition by sourceid,accountid ORDER BY RowUpdateDateTime desc nulls first,FileId Desc nulls first ) epi_rownumber
      |          FROM LSS_PBRACCOUNTEPISODES t
      |     )
      |     WHERE epi_rownumber=1
      |)
      |, ins_qry AS (
      |     SELECT  distinct insuranceid
      |          ,name
      |          ,payorid
      |          ,payorname
      |          ,glcomp
      |     FROM LSS_DPBRINSURANCE
      |)
      |, act_ins_qry AS (
      |     SELECT  *
      |     FROM
      |     (
      |          SELECT  sourceid
      |               ,accountid
      |               ,episeqid
      |               ,Groupnumber
      |               ,Policynumber
      |               ,Expirationdatetime
      |               ,Effectivedatetime
      |               ,grouporplanname
      |               ,epiinsuranceid
      |               ,row_number() over ( partition by sourceid,accountid,episeqid ORDER BY RowUpdateDateTime desc nulls first,FileId desc nulls first ) AS act_ins_rownumber
      |          FROM LSS_PBRACCOUNTEPIINSURANCE
      |          WHERE episeqid is not null
      |     )
      |     WHERE act_ins_rownumber = 1
      |)
      |, act_ins_odr_qry AS (
      |     SELECT  *
      |     FROM
      |     (
      |          SELECT  t.*
      |               ,row_number() over (partition by sourceid,accountid,episeqid,insuranceid ORDER BY RowUpdateDateTime desc nulls first,FileId Desc nulls first) AS aio_rownumber
      |          FROM LSS_PBRACCOUNTEPIINSURANCEORDER t
      |     )
      |     WHERE aio_rownumber = 1
      |)
      |SELECT  groupid
      |       ,client_ds_id
      |       ,datasrc
      |       ,insurancetimestamp  AS ins_timestamp
      |       ,patientid
      |       ,groupnumber         AS groupnbr
      |       ,insuranceorder
      |       ,policynumber
      |       ,encounterid
      |       ,enrollenddate       AS enrollenddt
      |       ,enrollmentstartdate AS enrollstartdt
      |       ,plantype
      |       ,payorcode
      |       ,payorname
      |       ,plancode
      |       ,planname
      |FROM
      |(
      |	SELECT  z.*
      |	       ,row_number() over (partition by EncounterID,PatientID,InsuranceOrder,PlanCode ORDER BY RowUpdateDateTime desc nulls first ) AS rownumber
      |	FROM
      |	(
      |		SELECT  /*+ parallel(32) */ '{groupid}'                                                                                        AS groupid
      |		       ,'pbraccountepiinsurance'                                                                                               AS datasrc
      |		       ,{client_ds_id}                                                                                                         AS client_ds_id
      |		       ,pbr.Servicedatetime                                                                                                    AS insurancetimestamp
      |		       ,nullif(concat_ws('',pbr.Sourceid,act.Patientid),'')                                                                    AS patientid
      |		       ,i.Groupnumber                                                                                                          AS groupnumber
      |		       ,o.Epiinsseqid                                                                                                          AS insuranceorder
      |		       ,i.Policynumber                                                                                                         AS policynumber
      |		       ,nullif(concat_ws('',pbr.Sourceid,act.Accountid,pbr.Locationid,upper(date_format(pbr.Servicedatetime,'dd-MMM-yy'))),'') AS encounterid
      |		       ,i.Expirationdatetime                                                                                                   AS enrollenddate
      |		       ,i.Effectivedatetime                                                                                                    AS enrollmentstartdate
      |		       ,id.payorname                                                                                                           AS plantype
      |		       ,id.Insuranceid                                                                                                         AS payorcode
      |		       ,id.Name                                                                                                                AS payorname
      |		       ,nvl(i.grouporplanname,id.name)                                                                                         AS plancode
      |		       ,nvl(i.grouporplanname,id.name)                                                                                         AS planname
      |		       ,pbr.RowUpdateDateTime
      |		FROM LSS_PBRACCOUNTTRANSACTIONS pbr
      |		  INNER JOIN ACT_QRY act ON ( act.SourceID = pbr.SourceID AND act.AccountID = pbr.AccountID )
      |		  INNER JOIN EPI_QRY ae ON ( ae.sourceid=act.sourceid AND ae.accountid=act.accountid )
      |		  INNER JOIN ACT_INS_QRY i ON ( pbr.sourceid=i.sourceid AND pbr.accountid=i.accountid AND pbr.episeqid=i.episeqid )
      |		  INNER JOIN ACT_INS_ODR_QRY o ON ( i.sourceid=o.sourceid AND i.accountid=o.accountid AND i.episeqid=o.episeqid AND i.epiinsuranceid=o.insuranceid )
      |		  INNER JOIN INS_QRY id ON ( o.insuranceid=id.insuranceid )
      |		WHERE pbr.Servicedatetime is not null
      |		AND nullIF(concat_ws('', pbr.Sourceid, act.Patientid), '') is not null
      |	) z
      |)
      |WHERE rownumber = 1
    """.stripMargin
}

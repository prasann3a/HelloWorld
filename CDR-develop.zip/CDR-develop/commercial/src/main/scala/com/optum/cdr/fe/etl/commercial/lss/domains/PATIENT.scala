package com.optum.cdr.fe.etl.commercial.lss.domains

import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENT extends FEQueryAndMetadata[patient]{

  override def name: String = CDRFEParquetNames.patient

  override def dependsOn: Set[String] = Set("LSS_TEMP_PATIENT_CACHE")

  override def ignoreExtraColumnsInDataFrame:Boolean=false

  override def sparkSql: String =
    """
      |select datasrc,patientid,dateofbirth,dateofdeath,inactiveflag as inactive_flag
      |from LSS_TEMP_PATIENT_CACHE
      |where rownumber = 1 and patientid is not null
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.{map_predicate_values, rx_patient_reported}
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RX_PAT_REP_CACHE_MEDICATIONRECONCILIATION extends FETableInfo[rx_patient_reported]{

  override def name: String = "RX_PAT_REP_CACHE_MEDICATIONRECONCILIATION"

  override def dependsOn: Set[String] = Set("MEDICATIONRECONCILIATION", "MEDICATIONRECONCILIATIONDETAIL", "MEDICATIONS", "MEDICATIONDETAILS", "REFERENCEMEDICATION", "MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val listDOSEUNIT = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "DOSE_UNIT","RX","RX","DETAIL_QUESTION").mkString(",")
    val listQTYDOSEUNIT = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "QTY_DOSE_UNIT","RX","RX","DETAIL_QUESTION").mkString(",")
    val listROUTE = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "ROUTE","RX","RX","DETAIL_QUESTION").mkString(",")
    val listSTRGDOSE = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "STRG_DOSE","RX","RX","DETAIL_QUESTION").mkString(",")
    val listSTRGDOSEUNIT = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "STRG_DOSE_UNIT","RX","RX","DETAIL_QUESTION").mkString(",")
    val listMEDSTATUS = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString,
      "MED_STATUS","RX","MEDICATION","STATUS").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,patientid
        |       ,localactioncode
        |       ,actiontime
        |       ,localcategorycode
        |       ,localdoseunit
        |       ,localdrugdescription
        |       ,encounterid
        |       ,localform
        |       ,localmedcode
        |       ,localndc
        |       ,localproviderid
        |       ,localqtyofdoseunit
        |       ,localroute
        |       ,localstrengthperdoseunit
        |       ,localstrengthunit
        |       ,medreportedtime
        |       ,reportedmedid
        |       ,rxnorm_code
        |       ,localtotaldose
        |FROM
        |(
        |	SELECT  groupid
        |	       ,datasrc
        |	       ,client_ds_id
        |	       ,patientid
        |	       ,localactioncode
        |	       ,actiontime
        |	       ,localcategorycode
        |	       ,localdoseunit
        |	       ,localdrugdescription
        |	       ,encounterid
        |	       ,localform
        |	       ,nullif(substr(localmedcode,1,100),'')                                                       AS localmedcode
        |	       ,localndc
        |	       ,localproviderid
        |	       ,localqtyofdoseunit
        |	       ,localroute
        |	       ,localstrengthperdoseunit
        |	       ,localstrengthunit
        |	       ,medreportedtime
        |	       ,reportedmedid
        |	       ,rxnorm_code
        |	       ,nvl(safe_to_number(localstrengthperdoseunit),0) * nvl(safe_to_number(localqtyofdoseunit),0) AS localtotaldose
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                                                                                      AS groupid
        |		       ,'medicationreconciliation'                                                                                                       AS datasrc
        |		       ,{client_ds_id}                                                                                                                   AS client_ds_id
        |		       ,mr.unique_person_identifier                                                                                                      AS patientid
        |		       ,concat_ws('','{client_ds_id}','.',mdc.hum_action)                                                                                AS localactioncode
        |		       ,mr.performed_date_time                                                                                                           AS actiontime
        |		       ,'INSTRUCTION'                                                                                                                    AS localcategorycode
        |		       ,MAX(case WHEN md.detail_question IN ({list_DOSE_UNIT}) THEN md.text_answer end) over (partition by mdc.record_identifier)        AS localdoseunit
        |		       ,MAX(mdc.mnemonic) over (partition by mdc.record_identifier)                                                                      AS localdrugdescription
        |		       ,mr.unique_visit_identifier                                                                                                       AS encounterid
        |		       ,MAX(case WHEN md.detail_question IN ({list_DOSE_UNIT}) THEN CASE WHEN lower(md.text_answer) = 'ml' THEN 'liquid' else md.text_answer end else null end) over (partition by mdc.record_identifier) AS localform
        |		       ,MAX(case WHEN lower(mdc.mnemonic) like '%misc%' or m.unique_synonym_identifier = '0' THEN mdc.mnemonic else coalesce(m.unique_synonym_identifier,mdc.mnemonic) end) over (partition by mdc.record_identifier) AS localmedcode
        |		       ,MAX(nullif(replace(rm.ndc,'-',''),'')) over (partition by mdc.record_identifier)                                                 AS localndc
        |		       ,MAX(mr.performed_by) over (partition by mdc.record_identifier)                                                                   AS localproviderid
        |		       ,MAX(case WHEN md.detail_question IN ({list_QTY_DOSE_UNIT}) THEN md.text_answer end) over (partition by mdc.record_identifier)    AS localqtyofdoseunit
        |		       ,MAX(case WHEN md.detail_question IN ({list_ROUTE}) THEN concat_ws('','{client_ds_id}','.',md.coded_answer) end) over (partition by mdc.record_identifier) AS localroute
        |		       ,MAX(case WHEN md.detail_question IN ({list_STRG_DOSE}) THEN md.text_answer end) over (partition by mdc.record_identifier)        AS localstrengthperdoseunit
        |		       ,MAX(case WHEN md.detail_question IN ({list_STRG_DOSE_UNIT}) THEN md.text_answer end) over (partition by mdc.record_identifier)   AS localstrengthunit
        |		       ,mr.performed_date_time                                                                                                           AS medreportedtime
        |		       ,mdc.record_identifier                                                                                                            AS reportedmedid
        |		       ,MAX(rm.rxnorm) over (partition by m.unique_synonym_identifier)                                                                   AS rxnorm_code
        |		       ,row_number() over (partition by mdc.record_identifier ORDER BY mdc.update_date_time desc nulls first,mdc.fileid desc nulls last) AS rw
        |		FROM MEDICATIONRECONCILIATION mr
        |		INNER JOIN MEDICATIONRECONCILIATIONDETAIL mdc
        |		ON mr.unique_med_reconciliation_id = mdc.unique_med_reconciliation_id
        |		INNER JOIN MEDICATIONS m
        |		ON mdc.unique_medication_identifier = m.unique_medication_identifier
        |		INNER JOIN MEDICATIONDETAILS md
        |		ON mdc.unique_medication_identifier = md.unique_medication_identifier
        |		INNER JOIN
        |		(
        |			SELECT  unique_synonym_identifier
        |			       ,rxnorm
        |			       ,ndc
        |			FROM
        |			(
        |				SELECT  r.unique_synonym_identifier      AS unique_synonym_identifier
        |				       ,r.rxnorm                         AS rxnorm
        |				       ,nullif(replace(r.ndc,'-',''),'') AS ndc
        |				       ,row_number() over (partition by unique_synonym_identifier,ndc,rxnorm ORDER BY fileid desc nulls first) rn
        |				FROM REFERENCEMEDICATION r
        |			)
        |			WHERE rn =1
        |		) rm
        |		ON m.unique_synonym_identifier = rm.unique_synonym_identifier
        |		WHERE nvl(m.placed_order_as, '2') ='2'
        |		AND mr.unique_person_identifier is not null
        |		AND mdc.record_identifier is not null
        |	)
        |	WHERE rw =1
        |)
      """.stripMargin
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
        .replace("{list_DOSE_UNIT}", listDOSEUNIT)
        .replace("{list_QTY_DOSE_UNIT}", listQTYDOSEUNIT)
        .replace("{list_ROUTE}", listROUTE)
        .replace("{list_STRG_DOSE}", listSTRGDOSE)
        .replace("{list_STRG_DOSE_UNIT}", listSTRGDOSEUNIT)
        .replace("{list_MED_STATUS}", listMEDSTATUS)
    )
  }


}
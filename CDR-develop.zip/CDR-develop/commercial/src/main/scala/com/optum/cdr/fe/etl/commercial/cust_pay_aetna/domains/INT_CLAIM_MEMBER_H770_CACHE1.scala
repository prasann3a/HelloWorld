package com.optum.cdr.fe.etl.commercial.cust_pay_aetna.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.int_claim_member
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INT_CLAIM_MEMBER_H770_CACHE1 extends FETableInfo[int_claim_member] {

  override def name: String = "INT_CLAIM_MEMBER_H770_CACHE1"
  override def dependsOn: Set[String] = Set("AETACOE6","ZO_BPO_MAP_EMPLOYER")
  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val clientDsId = loaderVars.clientDsId.toString
    val groupId = loaderVars.groupId.toString

 // int_claim_member_H770.sql
   sparkSession.sql(
   s"""
   |with ll as
   |(
   |  select
   |        al.fileid, max(al.transact_date) as transact_date
   |  from AETACOE6 al
   |  group by al.fileid
   |)
   |,
   |sub as (
   |        select distinct
   |               asu.calculated, asu.member_id, asu.eff_mm
   |        from AETACOE6 asu
   |        where asu.mbr_rtp_type_cd='E'
   |       )
   |
   |select groupid, datasrc, client_ds_id, contract_id, member_eff_date, financial_class, member_gender_code,
   |       medical_benefit_flag, member_dob, member_fname, member_id, member_lname, payer_code, payer_name,
   |       pharmacy_benefit_flag, plan_code, plan_name, alternate_member_id, eligibile_member_month, emp_acct_id,
   |       member_end_date, member_addr_1, member_addr_2, member_city, member_state_code, member_zip_code, pcp_id,
   |       pcp_name, pcp_npi, pcp_spclty_cd, pcp_spclty_desc, product_code, product_name, subscriber_flag, subscriber_id
   |from
   |(
   | select
   |       '{groupid}' 					as groupid
   |      ,'AETACOE6' 					as datasrc
   |      ,{client_ds_id} 					as client_ds_id
   |      ,last_value(ac.org_id, true) OVER (PARTITION BY ac.member_id ORDER BY ac.eff_mm desc nulls last) as contract_id
   |      ,safe_to_date(ac.eff_mm,'yyyyMM') 		as member_eff_date
   |      ,bme.employeraccountid   			as financial_class
   |      ,ac.mbr_gender_cd 				as member_gender_code
   |      ,ac.medical_ind 				as medical_benefit_flag
   |      ,ac.birth_dt 					as member_dob
   |      ,ac.mbr_first_nm 				as member_fname
   |      ,ac.member_id 					as member_id
   |      ,ac.mbr_last_nm 				as member_lname
   |      ,bme.employeraccountid 				as payer_code
   |      ,bme.employeraccountid 				as payer_name
   |      ,ac.drug_ind 					as pharmacy_benefit_flag
   |      ,bme.employeraccountid 				as plan_code
   |      ,bme.employeraccountid 				as plan_name
   |      ,ac.individual_id 				as alternate_member_id
   |      ,ac.eff_mm 					as eligibile_member_month
   |      ,ac.grp_cntl_name 				as emp_acct_id
   |      ,last_day(safe_to_date_length(ac.eff_mm,'yyyyMM',0)) 	as member_end_date
   |      ,ac.mbr_address_line_1_txt 			as member_addr_1
   |      ,ac.mbr_address_line_2_txt 			as member_addr_2
   |      ,ac.Mbr_City_Nm 				as member_city
   |      ,case when upper(ac.mbr_state_postal_cd) = 'U'then null
   |            else ac.mbr_state_postal_cd end as member_state_code
   |      ,case when upper(ac.mbr_zip_cd) = 'U' then null
   |            else ac.mbr_zip_cd end as member_zip_code
   |      ,case when upper(ac.ATTR_PRVDR_PRINT_NM) in ('PCP NO ELECTION REQUIRED', 'MC DEFAULT PROVIDER',
   |                          'PCP ELECTION INVALID','PCP INVALID CHOICE') or ac.ATTR_PRVDR_NPI_NBR = '0' then null else ac.ATTR_PRVDR_NPI_NBR end as pcp_id
   |      ,case when upper(ac.ATTR_PRVDR_PRINT_NM) in ('PCP NO ELECTION REQUIRED', 'MC DEFAULT PROVIDER',
   |                          'PCP ELECTION INVALID','PCP INVALID CHOICE') or ac.ATTR_PRVDR_NPI_NBR = '0' then null else ac.ATTR_PRVDR_PRINT_NM end as pcp_name
   |      ,case when upper(ac.ATTR_PRVDR_PRINT_NM) in ('PCP NO ELECTION REQUIRED', 'MC DEFAULT PROVIDER',
   |                          'PCP ELECTION INVALID','PCP INVALID CHOICE') or ac.ATTR_PRVDR_NPI_NBR = '0' then null else ac.ATTR_PRVDR_NPI_NBR end as pcp_npi
   |      ,case when upper(ac.ATTR_PRVDR_SPECIALTY_CTG_CD) = 'ZZZZ' then null
   |            else ac.ATTR_PRVDR_SPECIALTY_CTG_CD end 	as pcp_spclty_cd
   |      ,case when upper(ac.ATTR_PRVDR_SPECIALTY_CTG_CD) = 'ZZZZ' then null
   |            else ac.ATTR_PRVDR_SPECIALTY_CTG_CD end as pcp_spclty_desc
   |      ,bme.employeraccountid 				as product_code
   |      ,bme.employeraccountid 				as product_name
   |      ,case when ac.mbr_rtp_type_cd='E' then 'Y'
   |            else 'N' end as subscriber_flag
   |      ,sub.member_id 					as subscriber_id
   |      ,row_number() over (partition by ac.member_id, ac.eff_mm order by ll.transact_date nulls last) as rw_id
   | from AETACOE6 ac
   | inner join LL on ll.fileid = ac.fileid
   | cross join ZO_BPO_MAP_EMPLOYER bme on bme.client_ds_id = {client_ds_id}
   | left outer join SUB on sub.member_id = ac.member_id and sub.calculated = ac.calculated and sub.eff_mm = ac.eff_mm
   | where ac.member_id <> '00000000000000000000'
   | )
   | where rw_id = 1
    """.stripMargin.replace("{client_ds_id}",clientDsId).replace("{groupid}",groupId)
   )
}

}

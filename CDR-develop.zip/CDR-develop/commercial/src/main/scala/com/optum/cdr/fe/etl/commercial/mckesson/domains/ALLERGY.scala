package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.oap.cdr.models.allergy
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}

object ALLERGY extends FEQueryAndMetadata[allergy] {
  override def name: String = CDRFEParquetNames.allergy

  override def dependsOn: Set[String] = Set("MCKESSON_ENT_CPI_ALLERGY")

  override def sparkSql: String =
    """
       WITH allergy_subq AS
       (
          SELECT
            'ent_cpi_allergy'     AS datasrc
            ,NULLIF(LTRIM(RTRIM(REGEXP_EXTRACT(LOWER(allergen_description), '([0-9a-z /s]+)', 1))),'')  AS localallergencd
            ,Allergy_Created_Dt   AS onsetdate
            ,cpi_seq 	            AS patientid
            ,Created_Pat_Seq      AS encounterid
            ,NULLIF(LTRIM(RTRIM(REGEXP_EXTRACT(LOWER(allergen_description), '([0-9a-z /s]+)', 1))),'')             AS localallergendesc
            ,NULL                 AS localndc
            ,CASE WHEN inactive_dt IS NULL THEN 'ACTIVE' ELSE 'INACTIVE' END                        AS localstatus
            ,NVL2(Allergen_Type_Lseq,concat_ws('', {client_ds_id} ,'.',Allergen_Type_Lseq), NULL)   AS localallergentype
            ,ROW_NUMBER() OVER (PARTITION BY cpi_seq, Allergy_Created_Dt, Created_Pat_Seq, COALESCE(allergen_code, allergen_description)
                          ORDER BY modified_dt DESC NULLS LAST)                                     AS rn
          FROM  MCKESSON_ENT_CPI_ALLERGY
          WHERE cpi_seq IS NOT NULL
            AND  Allergy_Created_Dt IS NOT NULL
        )
        SELECT
          datasrc,
          localallergencd,
          onsetdate,
          patientid,
          encounterid,
          localallergendesc,
          localstatus,
          localallergentype
        FROM allergy_subq
        WHERE rn = 1
    """.stripMargin

}

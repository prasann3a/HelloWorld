package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.oap.cdr.models.patientaddr
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object PATIENTADDR extends FEQueryAndMetadata[patientaddr]{

  override def name: String = CDRFEParquetNames.patientaddr

  override def dependsOn: Set[String] = Set("USERS")

  override def sparkSql: String =
    """
      |SELECT  groupid
      |       ,datasrc
      |       ,client_ds_id
      |       ,address_date
      |       ,patientid
      |       ,state
      |       ,zipcode
      |       ,address_line1
      |       ,address_line2
      |       ,city
      |FROM
      |(
      |	SELECT  '{groupid}'      AS groupid
      |	       ,'users'          AS datasrc
      |	       ,{client_ds_id}   AS client_ds_id
      |	       ,Users.Mdate      AS address_date
      |	       ,Users.Hum_Uid    AS patientid
      |	       ,CASE WHEN LENGTH(nullif(regexp_replace(users.upstate,'[^a-zA-Z]',''),'')) = 2 THEN nullif(regexp_replace(Users.Upstate,'[^a-zA-Z]',''),'') ELSE NULL END AS state
      |	       ,CASE WHEN LENGTH(nullif(regexp_replace(Users.Zipcode,'[^a-zA-Z]',''),'')) IS NULL AND LENGTH(Users.Zipcode) IN (5,9,10) THEN users.zipcode ELSE NULL END AS zipcode
      |	       ,Users.Upaddress  AS address_line1
      |	       ,Users.Upaddress2 AS address_line2
      |	       ,Users.Upcity     AS city
      |	       ,users.usertype
      |	FROM USERS
      |	WHERE Users.Hum_Uid IS NOT NULL
      |	AND Users.Mdate IS NOT NULL
      |	AND ( COALESCE(Users.Upaddress, Users.Upaddress2, users.upcity) IS not NULL OR LENGTH(nullIF(regexp_replace(users.upstate,'[^a-zA-Z]', ''), '')) = 2 OR (nullif(regexp_replace(Users.Zipcode,'[^a-zA-Z]', ''), '') IS NULL AND LENGTH(Users.Zipcode) IN (5,9,10) ))
      |)
      |WHERE usertype IN ('1','3','10','4')
      |
    """.stripMargin
}

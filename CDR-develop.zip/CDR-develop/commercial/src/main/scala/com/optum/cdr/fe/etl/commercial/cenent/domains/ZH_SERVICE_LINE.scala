package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.zh_service_line
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object ZH_SERVICE_LINE extends FEQueryAndMetadata[zh_service_line] {

  override def name: String = CDRFEParquetNames.zh_service_line

  override def dependsOn: Set[String] = Set("ZH_VT")

  override def sparkSql: String =
    """
      |select groupid, client_ds_id, localservicecode, servicecodedesc
      |from
      |(
      |select
      |  	 '{groupid}'         as groupid
      |	,{client_ds_id}    as client_ds_id
      |    ,vt_name1         as localservicecode
      |    ,vt_descr         as servicecodedesc
      |from ZH_VT
      |where vt_num9='217'
      |)
    """.stripMargin
}
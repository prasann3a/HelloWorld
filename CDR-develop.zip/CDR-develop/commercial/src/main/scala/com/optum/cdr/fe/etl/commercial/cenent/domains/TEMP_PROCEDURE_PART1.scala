package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel


object TEMP_PROCEDURE_PART1 extends FEQueryAndMetadata[proceduredo] {

  override def name: String = "TEMP_PROCEDURE_PART1"

  override def dependsOn: Set[String] = Set("TEMP_CLAIM_PROC_CACHE1")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localcpt as localcode, encounterid, patientid,
      |servicedate as proceduredate, 'Y' as hosp_px_flag, seq as procseq, localcpt as mappedcode, facilityid,
      |claimproviderid as performingproviderid, CASE WHEN seq = 1 THEN 'Y' ELSE 'N' END as localprincipleindicator
      |from
      |(
      |TEMP_CLAIM_PROC_CACHE1
      |)
      |where servicedate IS NOT NULL AND patientid IS NOT NULL
    """.stripMargin

}

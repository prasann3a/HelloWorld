package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.cdr.fe.etl.commercial.aspro_observation_cache
import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import org.apache.spark.storage.StorageLevel

object OBSERVATION_CACHE extends FEQueryAndMetadata[aspro_observation_cache] {

  override def name: String = "OBSERVATION_CACHE"

  override def dependsOn: Set[String] = Set("VITALS")

  override def sparkSql: String =
    """
      |select 	'{groupid}' 										as groupid
      |		      ,'vitals' 										as datasrc
      |       	,v.imreenc_code 						as encounterid
      |       	,v.imredem_code 						as patientid
      |       	,v.vital_datetime 					as obsdate
      |       	,v.vital_height 						as vital_height
      |       	,v.vital_weight							as vital_weight
      |      	,case when vital_bp_cuff_location_code in (1,2,7) and vital_bp_pat_postn_code=3 then v.vital_bp_diastolic else null end as vital_bp_diastolic
      |        ,case when vital_bp_cuff_location_code in (1,2,7) and vital_bp_pat_postn_code=3 then v.vital_bp_systolic else null end as vital_bp_systolic
      |       	,v.vital_pulse			  			as vital_pulse
      |       	,v.vital_respiratn_rate 		as vital_respiratn_rate
      |       	,v.vital_pain_level					as vital_pain_level
      |       	,v.vital_temperature				as vital_temperature
      |
      |      --commenting the below 2 lines, since they aren't used anywhere in the query. Also, couldn't infer the datatype for these columns while creating the case class
      |
      |      --,case when v.vital_weight_unit_code=6 then .4536 else 1 end as WT_CONV
      |      --,case when v.vital_height_unit_code=2 then 2.5400 else 1 end as HT_CONV
      |
      |from VITALS v
      |where v.imredem_code is not null
      |      and v.vital_datetime >= to_date('20050101','yyyyMMdd')
    """.stripMargin

}


package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.FEQueryAndMetadata
import com.optum.oap.cdr.models.labresult
import org.apache.spark.storage.StorageLevel

object LABRESULT_MCKESSON_PGN extends FEQueryAndMetadata[labresult]{
  override def name: String = "LABRESULT_MCKESSON_PGN"

  override def dependsOn: Set[String] = Set("OBSERVATION_CACHE_TMA100_CLINICAL_DOC","OBSERVATION_CACHE_TPM300_PAT_VISIT","LABRESULT_CACHE_1","LABRESULT_CACHE_2","LABRESULT_CACHE_3","LABRESULT_CACHE_4")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, dateavailable, encounterid, localname, localtestname, localunits, LABRESULT_DATE, localresult_numeric, localresult_numeric as localresult_inferred, null as laborderid, null as LABORDEREDDATE, null as datecollected, null as LOCALSPECIMENTYPE, null as normalrange, null as resulttype, null as statuscode, null as local_loinc_code
      |from
      |(
      |OBSERVATION_CACHE_TMA100_CLINICAL_DOC
      |)
      |where obstype = 'LABRESULT' AND res_row = 1 AND localresult_numeric IS NOT NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, dateavailable, encounterid, localname, localtestname, localunits, LABRESULT_DATE, localresult_numeric, localresult_numeric as localresult_inferred, null as laborderid, null as LABORDEREDDATE, null as datecollected, null as LOCALSPECIMENTYPE, null as normalrange, null as resulttype, null as statuscode, null as local_loinc_code
      |from
      |(
      |OBSERVATION_CACHE_TPM300_PAT_VISIT
      |)
      |where obstype = 'LABRESULT' AND res_row = 1 AND localresult_numeric IS NOT NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, dateavailable, encounterid, localname, localtestname, localunits, LABRESULT_DATE, localresult_numeric, localresult_numeric as localresult_inferred, laborderid, LABORDEREDDATE, datecollected, null as LOCALSPECIMENTYPE, normalrange, resulttype, statuscode, local_loinc_code
      |from
      |(
      |LABRESULT_CACHE_1
      |)
      |where res_row = 1 AND localresult_numeric IS NOT NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, dateavailable, encounterid, localname, LOCALTESTNAME, null as localunits, dateavailable as LABRESULT_DATE, localresult_numeric, localresult_numeric as localresult_inferred, laborderid, labordereddate, null as datecollected, null as LOCALSPECIMENTYPE, null as normalrange, null as resulttype, null as statuscode, null as local_loinc_code
      |from
      |(
      |LABRESULT_CACHE_2
      |)
      |where res_no = 1 AND localresult_numeric IS NOT NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, DATEAVAILABLE, ENCOUNTERID, localname, LOCALTESTNAME, LOCALUNITS, DATEAVAILABLE as LABRESULT_DATE, localresult_numeric, localresult_numeric as localresult_inferred, LABORDERID, null as LABORDEREDDATE, DATECOLLECTED, LOCALSPECIMENTYPE, NORMALRANGE, RESULTTYPE, STATUSCODE,null as local_loinc_code
      |from
      |(
      |LABRESULT_CACHE_3
      |)
      |where re_row = 1 AND localresult_numeric IS NOT NULL AND labresultid IS NOT NULL
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, labresultid, localcode, localresult, patientid, DATEAVAILABLE, ENCOUNTERID, localname, LOCALTESTNAME, LOCALUNITS, DATEAVAILABLE as LABRESULT_DATE, localresult_numeric, localresult_numeric as localresult_inferred, LABORDERID, LABORDEREDDATE, null as datecollected, LOCALSPECIMENTYPE, NORMALRANGE, RESULTTYPE, STATUSCODE,null as local_loinc_code
      |from
      |(
      |LABRESULT_CACHE_4
      |)
      |where resw_row = 1 AND localresult_numeric IS Not NULL AND labresultid IS NOT NULL
    """.stripMargin



}

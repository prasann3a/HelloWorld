package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.allergy
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}


object ALLERGY extends FEQueryAndMetadata[allergy] {

  override def name: String = CDRFEParquetNames.allergy

  override def dependsOn: Set[String] = Set("ZH_XCNCPT", "PROBLM")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, localallergencd, onsetdate, patientid, encounterid, localallergendesc, localstatus, localallergentype
      |from
      |(
      |SELECT distinct '{groupid}' as groupid
      |,'problm' as datasrc
      |,{client_ds_id} as client_ds_id
      |,uni_allergy.Xcncpt_Descr_Num AS localallergencd
      |,uni_allergy.actv_ts  AS onsetdate
      |,uni_allergy.pat_person_num  AS patientid
      |,NULL  AS encounterid
      |,Zh_Xcncpt.Nm AS localallergendesc
      |,NULL  AS localndc
      |,uni_allergy.Status_Cde  AS localstatus
      |,CASE WHEN cat_cde = 6 THEN 'Med'
      |      WHEN cat_cde = 7 THEN 'Non-Med'
      |      ELSE 'Other' END AS localallergentype
      |FROM PROBLM uni_allergy
      |      LEFT OUTER JOIN ZH_XCNCPT ON (uni_allergy.xcncpt_descr_num =zh_xcncpt.num)
      |WHERE zh_xcncpt.concept_type_cde = 'ALLRGY'
      |)
      |where onsetdate IS NOT NULL
    """.stripMargin

}
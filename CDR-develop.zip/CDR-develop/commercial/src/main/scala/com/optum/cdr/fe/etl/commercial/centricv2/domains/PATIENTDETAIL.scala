package com.optum.cdr.fe.etl.commercial.centricv2.domains

import com.optum.oap.cdr.models.patientdetail
import com.optum.oap.sparkdataloader.FEQueryAndMetadata

object PATIENTDETAIL extends FEQueryAndMetadata[patientdetail] {

  override def name: String = "PATIENTDETAIL"

  override def dependsOn: Set[String] = Set("PATIENT_PART1_CACHE", "PATIENT_PART2_CACHE")

  override def sparkSql: String =
    """
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'FIRST_NAME' as patientdetailtype, firstname as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where first_row = 1  and firstname is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'MIDDLE_NAME' as patientdetailtype, mi as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where mi_row = 1  and mi is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'LAST_NAME' as patientdetailtype, lastname as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where last_row = 1  and lastname is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'MARITAL' as patientdetailtype, maritalstatus as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where marital_row = 1  and maritalstatus is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'LANGUAGE' as patientdetailtype, language as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where language_row = 1  and language is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'DECEASED' as patientdetailtype, deathindicator as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where deathindicator_row = 1  and deathindicator is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'RACE' as patientdetailtype, nullif(concat_ws('', client_ds_id, '.', race), '') as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where race_row = 1  and race is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'ETHNICITY' as patientdetailtype, nullif(concat_ws('', client_ds_id, '.', ethnicity), '') as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where ethnicity_row = 1  and ethnicity is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'CITY' as patientdetailtype, city as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where city_row = 1  and city is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'STATE' as patientdetailtype, state as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where state_row = 1  and state is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'ZIPCODE' as patientdetailtype, zipcode as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where zip_row = 1  and zipcode is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'GENDER' as patientdetailtype, gender as localvalue
      |from
      |(
      |PATIENT_PART1_CACHE
      |)
      |where gender_row = 1  and gender is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'FIRST_NAME' as patientdetailtype, firstname as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where first_row = 1  and firstname is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'MIDDLE_NAME' as patientdetailtype, mi as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where mi_row = 1  and mi is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'LAST_NAME' as patientdetailtype, lastname as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where last_row = 1  and lastname is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'MARITAL' as patientdetailtype, nullif(concat_ws('', client_ds_id, '.', maritalstatus), '') as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where marital_row = 1  and maritalstatus is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'LANGUAGE' as patientdetailtype, nvl2(language,concat_ws('', client_ds_id, '.', language),null) as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where language_row = 1  and language is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'DECEASED' as patientdetailtype, deathindicator as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where deathindicator_row = 1  and deathindicator is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'RACE' as patientdetailtype, nullif(concat_ws('', client_ds_id, '.', race), '') as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where race_row = 1  and race is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'ETHNICITY' as patientdetailtype, nullif(concat_ws('', client_ds_id, '.', ethnicity), '') as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where ethnicity_row = 1  and ethnicity is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'CITY' as patientdetailtype, city as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where city_row = 1  and city is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'STATE' as patientdetailtype, state as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where state_row = 1  and state is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'ZIPCODE' as patientdetailtype, zipcode as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where zip_row = 1  and zipcode is not null and patientid is not null and lastupdateddate is not null
      |
      |UNION ALL
      |
      |select groupid, datasrc, client_ds_id, patientid, lastupdateddate as patdetail_timestamp, 'GENDER' as patientdetailtype, gender as localvalue
      |from
      |(
      |PATIENT_PART2_CACHE
      |)
      |where gender_row = 1  and gender is not null and patientid is not null and lastupdateddate is not null
      |
    """.stripMargin
}
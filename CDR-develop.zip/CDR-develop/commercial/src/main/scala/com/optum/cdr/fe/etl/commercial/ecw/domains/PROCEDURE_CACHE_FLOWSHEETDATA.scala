package com.optum.cdr.fe.etl.commercial.ecw.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.cdr.models.proceduredo
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object PROCEDURE_CACHE_FLOWSHEETDATA extends FETableInfo[proceduredo]{

  override def name: String = "PROCEDURE_CACHE_FLOWSHEETDATA"

  override def dependsOn: Set[String] = Set("FLOWSHEETDATA", CDRFEParquetNames.clinicalencounter, "MAP_CUSTOM_PROC", "ZH_FLOWSHEETITEMS")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val clientDsIdPrefix= runtimeVar.clientDsId.toString + "."

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |SELECT  groupid
        |       ,datasrc
        |       ,client_ds_id
        |       ,localcode
        |       ,encounterid
        |       ,patientid
        |       ,proceduredate
        |       ,localname
        |       ,codetype
        |       ,mappedcode
        |FROM
        |(
        |	SELECT  a.*
        |	FROM
        |	(
        |		SELECT  '{groupid}'                                                        AS groupid
        |		       ,'flowsheetdata'                                                    AS datasrc
        |		       ,{client_ds_id}                                                     AS client_ds_id
        |		       ,concat_ws('','{client_ds_id_prefix}',fs.Flowsheetid,'_',fs.Itemid) AS localcode
        |		       ,Enc.Patientid                                                      AS patientid
        |		       ,CASE WHEN concat_ws('',fs.Flowsheetid,'_',fs.Itemid) IN ('6_100','6_101','6_102','6_103','6_106') AND fs.Hum_Value IS NOT NULL THEN CASE
        |		             WHEN rlike(fs.Hum_Value,'^(0[1-9]|1[012])[- /.]([012][0-9]|3[01])[- /.](0[1-9])$') THEN safe_to_date(concat_ws('',nullif(SUBSTR(fs.Hum_Value,1,LENGTH(fs.Hum_Value)-2),''),'20',nullif(substr(fs.Hum_Value,-2,2),'')),'MM/dd/yyyy')
        |		             WHEN rlike(fs.Hum_Value,'^[1-9][- /.]([012][0-9]|3[01])[- /.](0[1-9])$') THEN safe_to_date(concat_ws('',nullif(SUBSTR(concat_ws('','0',fs.Hum_Value),1,LENGTH(concat_ws('','0',fs.Hum_Value))-2),''),'20',nullif(substr(fs.Hum_Value,-2,2),'')),'MM/dd/yyyy')
        |		             WHEN rlike(fs.Hum_Value,'^[1-9][- /.]([012][0-9]|3[01])[- /.]((20|19)[0-9][0-9])$') THEN safe_to_date(concat_ws('','0',fs.Hum_Value),'MM/dd/yyyy')
        |		             WHEN rlike(fs.Hum_Value,'^(0[1-9]|1[012])[- /.]([012][0-9]|3[01])[- /.]((20|19)[0-9][0-9])$') THEN safe_to_date(fs.Hum_Value,'MM/dd/yyyy') ELSE NULL END ELSE enc.arrivaltime END AS proceduredate
        |		       ,fs.Encounterid                                                     AS encounterid
        |		       ,Zh_Flowsheetitems.Hum_Name                                         AS localname
        |		       ,map_custom_proc.mappedvalue                                        AS mappedcode
        |		       ,'CUSTOM'                                                           AS codetype
        |		       ,ROW_NUMBER() OVER (PARTITION BY fs.EncounterID,fs.FlowsheetID,fs.ItemID,map_custom_proc.mappedvalue ORDER BY fs.modifieddate DESC NULLS LAST) rn
        |		FROM FLOWSHEETDATA fs
        |		JOIN {CLINICALENCOUNTER} enc
        |			ON (fs.encounterid = enc.encounterid AND enc.client_ds_id = {client_ds_id})
        |		JOIN MAP_CUSTOM_PROC
        |			ON (map_custom_proc.LocalCode = concat_ws('', '{client_ds_id_prefix}', fs.Flowsheetid, '_', fs.Itemid) AND map_custom_proc.groupid = '{groupid}' AND map_custom_proc.datasrc = 'flowsheetdata')
        |		LEFT OUTER JOIN ZH_FLOWSHEETITEMS
        |			ON (nullif(concat_ws('', fs.flowsheetid, fs.itemid), '') = nullif(concat_ws('', zh_flowsheetitems.flowsheetid, zh_flowsheetitems.id), ''))
        |		WHERE fs.hum_value IS NOT NULL
        |		AND (CASE WHEN concat_ws('', fs.Flowsheetid, '_', fs.Itemid) = '6_98' THEN CASE WHEN fs.Hum_Value = 'today' THEN 1 ELSE 0 END ELSE 0 END)=1
        |	) a
        |	WHERE rn = 1
        |)
        |WHERE proceduredate IS NOT NULL
      """.stripMargin
        .replace("{CLINICALENCOUNTER}", CDRFEParquetNames.clinicalencounter)
        .replace("{client_ds_id_prefix}", clientDsIdPrefix)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }


}

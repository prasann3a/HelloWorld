package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.sparkdataloader.{FEQueryAndMetadata,CDRFEParquetNames}
import com.optum.oap.cdr.models.claim

object CLAIM extends FEQueryAndMetadata[claim]{
  override def name: String = CDRFEParquetNames.claim

  override def dependsOn: Set[String] = Set("PROCEDURE_CACHE_1","PROCEDURE_CACHE_2")

  override def sparkSql: String =
    """
      |select groupid, 'charge_detail_claim' as datasrc, client_ds_id, claimid, patientid, servicedate, facilityid, encounterid, localcpt, mappedcpt, claimproviderid, mappedcptmod1, mappedcptmod2, mappedcptmod3, mappedcptmod4, localcptmod1, localcptmod2, localcptmod3, localcptmod4, localrev, mappedrev, post_dt, charge, quantity
      |from
      |(
      |PROCEDURE_CACHE_1
      |)
      |where clm_rn = 1 AND servicedate IS NOT NULL AND claimid IS NOT NULL AND patientid IS NOT NULL
      |
      |union all
      |
      |select groupid, 'visit_cpt4_claim' as datasrc, client_ds_id, claimid, patientid, servicedate, facilityid, encounterid, localcpt, mappedcpt, claimproviderid, mappedcptmod1, mappedcptmod2, mappedcptmod3, mappedcptmod4, localcptmod1, localcptmod2, localcptmod3, localcptmod4, localrev, mappedrev, post_dt, null as charge, null as quantity
      |from
      |(
      |PROCEDURE_CACHE_2
      |)
      |where clm_rn = 1 AND servicedate IS NOT NULL AND claimid IS NOT NULL AND patientid IS NOT NULL
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.oap.cdr.models.mbresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object MBRESULT extends FEQueryAndMetadata[mbresult]{
  override def name: String = CDRFEParquetNames.mbresult

  override def dependsOn: Set[String] = Set("MCKESSON_PGN_V1_TPM300_PAT_VISIT", "MCKESSON_PGN_V1_TMB300_MICRO_ORD_DTL", "MCKESSON_PGN_V1_TMB305_MICRO_ORD_SUSCEPT_DTL", "MCKESSON_PGN_V1_TMB820_CATEGORY_INTERPRETATION", "MCKESSON_PGN_V1_TOM107_CHILD_ORDER")

  override def sparkSql: String =
    """
      |with dedup_pat_visit AS (
      |SELECT  *
      |FROM
      |(
      |	SELECT  x.*
      |	       ,row_number () over (partition by vst_int_id ORDER BY lst_mod_ts desc nulls first,fileid desc nulls last) AS rownumber
      |	FROM MCKESSON_PGN_V1_TPM300_PAT_VISIT x
      |)
      |WHERE rownumber = 1
      |AND nvl(row_sta_cd,'X') <> 'D' ),
      |
      |dedup_micro_order AS (
      |      SELECT  *
      |      FROM
      |      (
      |            SELECT  x.*
      |                  ,row_number () over (partition by chi_ord_int_id,rsu_typ_seq_no ORDER BY lst_mod_ts desc nulls first,fileid desc nulls last) AS rownumber
      |            FROM MCKESSON_PGN_V1_TMB300_MICRO_ORD_DTL x
      |      )
      |      WHERE rownumber = 1
      |      AND nvl(row_sta_cd,'X') <> 'D'
      |),
      |
      |dedup_micro_suscept AS (
      |      SELECT  *
      |      FROM
      |      (
      |            SELECT  x.*
      |                  ,row_number () over (partition by chi_ord_int_id,rsu_seq_no,atb_int_id ORDER BY lst_mod_ts desc nulls first,fileid desc nulls last) AS rownumber
      |            FROM MCKESSON_PGN_V1_TMB305_MICRO_ORD_SUSCEPT_DTL x
      |      )
      |      WHERE rownumber = 1
      |      AND nvl(row_sta_cd,'X') <> 'D'
      |),
      |
      |dedup_category AS (
      |      SELECT  *
      |      FROM
      |      (
      |            SELECT  x.*
      |                  ,row_number () over (partition by cat_itp_int_id ORDER BY lst_mod_ts desc nulls first,fileid desc nulls last) AS rownumber
      |            FROM MCKESSON_PGN_V1_TMB820_CATEGORY_INTERPRETATION x
      |      )
      |      WHERE rownumber = 1
      |      AND nvl(row_sta_cd,'X') <> 'D'
      |),
      |
      |dedup_child_order AS (
      |      SELECT  *
      |      FROM
      |      (
      |            SELECT  x.*
      |                  ,row_number () over (partition by chi_ord_int_id ORDER BY lst_mod_ts desc nulls first,fileid desc nulls last) AS rownumber
      |            FROM MCKESSON_PGN_V1_TOM107_CHILD_ORDER x
      |      )
      |      WHERE rownumber = 1
      |      AND nvl(row_sta_cd,'X') <> 'D'
      |)
      |SELECT  groupid
      |       ,datasrc
      |       ,encounterid
      |       ,patientid
      |       ,mbprocorderid
      |       ,mbprocresultid
      |       ,dateavailable
      |       ,localantibioticcode
      |       ,localsensitivity
      |       ,dateavailable AS mbresult_date
      |       ,localsensitivity_value
      |       ,localantibioticname
      |       ,client_ds_id
      |       ,localorganismcode
      |       ,localorganismname
      |       ,localsensitivityname
      |FROM
      |(
      |	SELECT  *
      |	FROM
      |	(
      |		SELECT  '{groupid}'                                                                                                              AS groupid
      |		       ,{client_ds_id}                                                                                                           AS client_ds_id
      |		       ,'micro_ord_dtl'                                                                                                          AS datasrc
      |		       ,pv.psn_int_id                                                                                                            AS patientid
      |		       ,pv.vst_int_id                                                                                                            AS encounterid
      |		       ,mo.chi_ord_int_id                                                                                                        AS mbprocorderid
      |		       ,concat_ws('',mo.chi_ord_int_id,'_',mo.rsu_typ_seq_no,'_',s.atb_int_id)                                                   AS mbprocresultid
      |		       ,mo.rsu_rel_ts                                                                                                            AS dateavailable
      |		       ,s.atb_int_id                                                                                                             AS localantibioticcode
      |		       ,nullif(regexp_replace(s.atb_ds,'[0-9]|\\s',''),'')                                                                 AS localantibioticname
      |		       ,mo.rsu_cod_int_id                                                                                                        AS localorganismcode
      |		       ,concat_ws('',mo.rsu_qnt_ds,' ',mo.rsu_tx)                                                                                AS localorganismname
      |		       ,s.cat_itp_int_id                                                                                                         AS localsensitivity
      |		       ,c.cat_itp_ds                                                                                                             AS localsensitivityname
      |		       ,concat_ws('',s.rsu_qal_cd,' ',s.rsu_val_no)                                                                              AS localsensitivity_value
      |		       ,row_number() over (partition by mo.chi_ord_int_id,mo.rsu_typ_seq_no,s.atb_int_id ORDER BY mo.lst_mod_ts desc nulls last) AS rownumber
      |		FROM DEDUP_MICRO_ORDER mo
      |		INNER JOIN DEDUP_CHILD_ORDER co ON mo.chi_ord_int_id = co.chi_ord_int_id
      |		INNER JOIN DEDUP_PAT_VISIT pv ON co.vst_int_id = pv.vst_int_id
      |		LEFT JOIN DEDUP_MICRO_SUSCEPT s ON mo.chi_ord_int_id = s.chi_ord_int_id AND mo.rsu_typ_seq_no = s.rsu_seq_no
      |		LEFT JOIN DEDUP_CATEGORY c ON s.cat_itp_int_id = c.cat_itp_int_id
      |	)
      |	WHERE rownumber = 1
      |)
      |WHERE patientid is not null
      |AND dateavailable is not null
      |AND rownumber = 1
    """.stripMargin
}

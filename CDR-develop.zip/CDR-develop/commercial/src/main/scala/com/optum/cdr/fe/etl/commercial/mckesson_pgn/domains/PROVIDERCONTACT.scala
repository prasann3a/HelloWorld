package com.optum.cdr.fe.etl.commercial.mckesson_pgn.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, CDRFEParquetNames, RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oap.cdr.models.{map_predicate_values, zh_provider_contact}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PROVIDERCONTACT extends FETableInfo[zh_provider_contact]{
  override def name: String = CDRFEParquetNames.zh_provider_contact

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES","MCKESSON_PGN_V1_TSM021_ENT_ADR","MCKESSON_PGN_V1_TPM100_CARE_GIVER","MCKESSON_PGN_V1_TSM020_ADDRESS","MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL","MAP_PROV_CONTACT_TYPE")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values].toDF()
    val runtimeVar = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]
    val adrUseLst = mpvList(mapPredicateValues, runtimeVar.groupId, runtimeVar.clientDsId.toString, "PROVIDERADR_INC","ZH_PROVIDER_CONTACT","ENT_ADR","ADR_USE_CD").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        |select groupid, client_ds_id, 'ent_adr' as datasrc, local_provider_id, email_address, update_date, address_line1, address_line2, city, state, zipcode, work_phone, local_contact_type, mapped_contact_type
        |from
        |(
        |SELECT  '{groupid}'              AS groupid
        |       ,'{client_ds_id}'       AS client_ds_id
        |       ,zg.Car_Gvr_Int_Id     AS local_provider_id
        |
        |       ,NULL                  AS email_address
        |       ,ent.Adr_Eff_Ts	      AS update_date
        |       ,COALESCE(addr.adr_str_1,concat_ws('', 'PO BOX ', addr.box_no))	 AS address_line1
        |       ,addr.Adr_Str_2        AS address_line2
        |       ,addr.Cty_Nm           AS city
        |       ,dtl.Cod_Dtl_Ext_Id    AS state
        |       ,REPLACE(Zip_Cd, '-')  AS zipcode
        |       ,NULL                  AS work_phone
        |       ,ent.Adr_Use_Cd        AS local_contact_type
        |       ,map.Hts_Code          AS mapped_contact_type
        |       ,ROW_NUMBER() OVER (PARTITION BY zg.Car_Gvr_Int_Id,
        |                            ent.Adr_Use_Cd
        |                           ORDER BY ent.Lst_Mod_Ts DESC NULLS LAST, ent.fileid DESC nulls first) AS rn
        |FROM MCKESSON_PGN_V1_TSM021_ENT_ADR ent
        |   JOIN MCKESSON_PGN_V1_TPM100_CARE_GIVER zg ON (ent.psn_int_id = zg.psn_int_id)
        |   JOIN MCKESSON_PGN_V1_TSM020_ADDRESS addr ON (ent.adr_int_id = addr.adr_int_id)
        |   LEFT OUTER JOIN MCKESSON_PGN_V1_ZH_TSM180_MST_COD_DTL dtl ON (addr.ste_cd = dtl.cod_dtl_int_id AND dtl.row_sta_cd <> 'D')
        |   LEFT OUTER JOIN MAP_PROV_CONTACT_TYPE map ON (ent.Adr_Use_CD = map.Local_Code)
        |WHERE zg.Car_Gvr_Int_Id IS NOT NULL
        |  AND ent.Adr_Eff_Ts IS NOT NULL
        |  AND ent.row_sta_cd <> 'D'
        |  AND zg.row_sta_cd <> 'D'
        |  AND addr.row_sta_cd <> 'D'
        |  AND ent.Adr_Use_Cd IN ({adr_use_lst})
        |
        |)
        |where rn = 1
      """
        .stripMargin
        .replace("{adr_use_lst}", adrUseLst)
        .replace("{groupid}", runtimeVar.groupId)
        .replace("{client_ds_id}", runtimeVar.clientDsId.toString)
    )
  }

}

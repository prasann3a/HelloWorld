package com.optum.cdr.fe.etl.commercial.cernerasp.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.observation
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object OBSERVATION_PART_1 extends FETableInfo[observation]{

  override def name:String="OBSERVATION1"

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    val list_OBS_STATUS = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"), loaderVars.groupId, clientDsId,"STATUS", "OBSERVATION", "OBSERVATION", "STATUS").mkString(",")

    sparkSession.sql(
      s"""
         |select
         |groupid
         |,datasrc
         |,client_ds_id
         |,localresult
         |,localcode
         |,obsdate
         |,patientid
         |,encounterid
         |,local_obs_unit
         |,obstype
         |,statuscode
         |from (
         |select
         |	'H328218' 																		as groupid
         |	,'result' 																		as datasrc
         |	,5104 																	as client_ds_id
         |	,nullif(substr(case when z.CUI in ('CH001639','CH001850','CH001851','CH001638','CH001637'
         |						,'CH002749','CH001640','CH002643') then
         |						  concat_ws('', tbl_code.description, '.', rsl.result_value)
         |						  else rsl.result_value end , 1, 255), '')						as localresult
         |	,concat_ws('', '5104', '.', rsl.code, '_', rsl.units) 							as localcode
         |	,coalesce(rsl.performed_date_time, rsl.start_date_time, rsl.end_date_time) 		as obsdate
         |	,rsl.unique_person_identifier 													as patientid
         |	,rsl.unique_visit_identifier 													as encounterid
         |	,tbl_units.description															as local_obs_unit
         |	,z.obstype 																		as obstype
         |	,tbl_status.description 														as statuscode
         |	,row_number() over (partition by rsl.result_value, rsl.code, rsl.unique_visit_identifier,z.obstype order by coalesce(rsl.performed_date_time, rsl.start_date_time, rsl.end_date_time) desc nulls first) as rw
         |	from RESULT rsl
         |join ZCM_OBSTYPE_CODE z on (z.groupid = 'H328218' and z.datasrc = 'result' and lower(z.obscode) = concat_ws('', '5104', '.', rsl.code, '_', rsl.units))
         |left outer join (select element_code, description from (
         |                  select element_code, lower(description) as description,
         |                  row_number() over (partition by element_code order by length(description) desc nulls first) as rw
         |                  from REFERENCECODE
         |                  where field = 'UNITS' and file_name = 'RESULT'
         |                  )where rw=1 ) tbl_units
         |on tbl_units.element_code = rsl.units
         |left outer join (select element_code, description from (
         |                  select element_code, lower(description) as description,
         |                  row_number() over (partition by element_code order by length(description) desc nulls first) as rw
         |                  from REFERENCECODE
         |                  where field = 'STATUS' and file_name = 'RESULT'
         |                  )where rw=1 ) tbl_status
         |on tbl_status.element_code = rsl.status
         |left outer join (select element_code, description from (
         |                  select element_code, lower(description) as description,
         |                  row_number() over (partition by element_code order by length(description) desc nulls first) as rw
         |                  from REFERENCECODE
         |                  where field = 'CODE' and file_name = 'RESULT'
         |                  )where rw=1 ) tbl_code
         |on tbl_code.element_code = rsl.code
         |where rsl.result_value is not null
         |and rsl.status not in ('NO_MPV_MATCHES')
         |and rsl.unique_person_identifier is not null
         |and rsl.unique_visit_identifier is not null
         |)
         |where rw=1
         |

       """.stripMargin
        .replace("{groupid}",groupId)
        .replace("{client_ds_id}",clientDsId)
        .replace("{list_OBS_STATUS}",list_OBS_STATUS)
    )
  }

  override def dependsOn: Set[String] = Set("RESULT","ZCM_OBSTYPE_CODE","REFERENCECODE","MAP_PREDICATE_VALUES")

}
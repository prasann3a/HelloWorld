package com.optum.cdr.fe.etl.commercial.cenent.domains

import com.optum.oap.cdr.models.diagnosis
import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.oap.sparkdataloader.{FEQueryAndMetadata, RuntimeVariables}
import org.apache.spark.storage.StorageLevel


object TEMP_DIAGNOSIS_PART1 extends FEQueryAndMetadata[diagnosis] {

  override def name: String = "TEMP_DIAGNOSIS_PART1"

  override def dependsOn: Set[String] = Set("PROBLM", "ZH_XCNCPT")

  override def sparkSql: String =
    """
      |SELECT distinct groupid, datasrc, client_ds_id, patientid, encounterid, dx_timestamp, localactiveind,
      |localdiagnosisstatus, localdiagnosisproviderid, localdiagnosis, primarydiagnosis, resolutiondate,
      |localdiagnosis as mappeddiagnosis, null as localadmitflg, null as localdischargeflg, null as hosp_dx_flag,
      |null as codetype, null as facilityid
      |FROM
      |(
      |    SELECT
      |     '{groupid}' as groupid
      |    ,'problm' as datasrc
      |    ,{client_ds_id} as client_ds_id
      |    ,Problm.data_create_ts  AS dx_timestamp
      |    ,Problm.Pat_Person_Num  AS patientid
      |    ,Problm.num AS encounterid
      |    ,Problm.Status_Cde  AS localactiveind
      |    ,Problm.Cat_Cde  AS localdiagnosisstatus
      |    ,Problm.Orig_Provdr_Num  AS localdiagnosisproviderid
      |    ,0  AS primarydiagnosis
      |    ,CASE WHEN Problm.Status_Cde = 'R'
      |    THEN Problm.Data_Update_Ts ELSE NULL END  AS resolutiondate
      |    ,zh_xcncpt1.srcdiag AS localdiagnosis
      |    FROM PROBLM JOIN (
      |   SELECT * FROM (
      |    SELECT unpivot_base.*,
      |    stack(2,Icd_Cde,1, Icd_2_Cde,2) as (srcdiag, seq) FROM
      |    (
      |    SELECT num, icd_cde, icd_2_cde FROM ZH_XCNCPT
      |        WHERE concept_type_cde = 'PROBL'
      |        AND icd_cde <> '000.00') unpivot_base
      |    ) WHERE srcdiag IS NOT NULL ) Zh_Xcncpt1
      |     ON (problm.xcncpt_descr_num = zh_xcncpt1.num)
      |    WHERE problm.type_cde = 'D'
      |   AND problm.status_cde <> 'E'
      |   AND  Problm.data_create_ts IS NOT NULL
      |   AND Problm.Pat_Person_Num IS NOT NULL
      |    {incl_diag_exception}
      |) where dx_timestamp IS NOT NULL AND patientid IS NOT NULL
    """.stripMargin

  override protected def replaceTokens(runtimeVariables: RuntimeVariables): String = {
    val loaderVars = runtimeVariables.asInstanceOf[LoaderRunTimeVariables]

    val inclDiagVal = if (loaderVars.groupId == "H984216" ) {"EXCEPTION"} else {"UNDEFINED"}
    val inclDiagExcp =  if (inclDiagVal == "EXCEPTION") { "---" } else { " AND problm.cat_cde <> '5'"}

    sparkSql.replace("{groupid}", loaderVars.groupId)
      .replace("{client_ds_id}", loaderVars.clientDsId.toString)
      .replace("{incl_diag_exception}", inclDiagExcp)
  }

}

package com.optum.cdr.fe.etl.commercial.mckesson.domains

import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.cdr.models.medication_map_src
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MEDICATION_MAP_SRC_RX_PATIENT_REPORTED extends FETableInfo[medication_map_src]{

  override def name: String = "MEDICATION_MAP_SRC_RX_PATIENT_REPORTED"

  override def dependsOn: Set[String] = Set("ENT_CPI_MEDICATION","MAP_PREDICATE_VALUES")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId.toString
    val excl_id = mpvList(mapPredicateValues, groupId, clientDsId, "ENT_CPI_MEDICATION", "MEDS", "ENT_CPI_MEDICATION", "DRUG_ID").mkString(",")

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }

    sparkSession.sql(
      """
        WITH uni_meds AS
        (SELECT * FROM
        (SELECT m.*, ROW_NUMBER() OVER (PARTITION BY cpi_medication_seq ORDER BY modified_dt DESC NULLS LAST) rn_m
        FROM ENT_CPI_MEDICATION m
        WHERE Cpi_Seq IS NOT NULL)
        WHERE rn_m = 1)
        select groupid, datasrc, client_ds_id, localmedcode, localndc, localdescription, no_ndc, has_ndc, num_recs
        from
        (
        SELECT '{groupid}' AS groupid
                ,'ent_cpi_medication' AS datasrc
            ,{client_ds_id} AS client_ds_id
                ,SUM(CASE WHEN localndc IS NULL THEN 1 ELSE 0 END) AS no_ndc
                ,SUM(CASE WHEN localndc IS NULL THEN 0 ELSE 1 END) AS has_ndc
                ,COUNT(*) AS num_recs
                ,localmedcode, localndc, localdescription
        FROM (SELECT  CASE WHEN uni_meds.Drug_id IN ({excl_id}) OR uni_meds.Drug_id IS NULL THEN uni_meds.drug_name
                            ELSE COALESCE(uni_meds.drug_id, uni_meds.drug_name) END AS localmedcode
                ,normalize_NDC(ndc) AS localndc
                ,drug_name AS localdescription
            FROM UNI_MEDS)
        GROUP BY localmedcode, localndc, localdescription
        )
            """.replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId)
        .replace("{excl_id}", excl_id))
  }
}
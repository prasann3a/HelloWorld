package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.claim
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object CLAIM extends FEQueryAndMetadata[claim]{

  override def name: String = CDRFEParquetNames.claim

  override def dependsOn: Set[String] = Set("ENCOUNTERS", "LABORDERS", "ZH_LABCATALOG", "PROCEDURES")

  override def sparkSql: String =
    """
--    Encounters
      |SELECT
      | datasrc
      |,claimid
      |,patientid
      |,servicedate
      |,facilityid
      |,encounterid
      |,mappedcpt as localcpt
      |,localbillingproviderid
      |,mappedcpt
      |,mappedcptmod1
      |,mappedcptmod2
      |,mappedcptmod3
      |,mappedcptmod4
      |,localcptmod1
      |,localcptmod2
      |,localcptmod3
      |,localcptmod4
      |,NULL AS quantity
      |FROM
      |(
      |SELECT 'encounters' AS datasrc
      |	,Imreenc_Code  AS claimid
      |	,Imredemec_Code  AS patientid
      |	,Enc_Chartpulltime  AS servicedate
      |	,Bill_Modifier1  AS mappedcptmod1
      |	,Bill_Modifier2  AS mappedcptmod2
      |	,Bill_Modifier3  AS mappedcptmod3
      |	,Bill_Modifier4  AS mappedcptmod4
      |	,CASE WHEN enc_billlevel LIKE '%DEF' THEN '99213'
      |              ELSE enc_billlevel END AS mappedcpt
      |	,Imreenc_Code  AS encounterid
      |	,Location_Id  AS facilityid
      |	,Enc_Billingprov_Code  AS localbillingproviderid
      |	,Bill_Modifier1  AS localcptmod1
      |	,Bill_Modifier2  AS localcptmod2
      |	,Bill_Modifier3  AS localcptmod3
      |	,Bill_Modifier4  AS localcptmod4
      |	,ROW_NUMBER() OVER (PARTITION BY Imreenc_Code, Imredemec_Code, Enc_Chartpulltime
      |	                    ORDER BY Enc_Chartpulltime DESC NULLS LAST) rn
      |FROM ENCOUNTERS
      |)
      |WHERE
      |    servicedate IS NOT NULL
      |AND claimid IS NOT NULL
      |AND patientid IS NOT NULL
      |AND rn = 1
      |
      |UNION
      |
      |--Laborders
      |SELECT
      | datasrc
      |,claimid
      |,patientid
      |,servicedate
      |,NULL AS facilityid
      |,encounterid
      |,localcpt
      |,NULL AS localbillingproviderid
      |,mappedcpt
      |,mappedcptmod1
      |,mappedcptmod2
      |,NULL AS mappedcptmod3
      |,NULL AS mappedcptmod4
      |,localcptmod1
      |,localcptmod2
      |,NULL AS localcptmod3
      |,NULL AS localcptmod4
      |,NULL AS quantity
      |FROM
      |(
      |SELECT 'laborders' as datasrc
      |	,Laborders.Imrelaborder_Code  AS claimid
      |	,Laborders.Imredemec_Code  AS patientid
      |	,Laborders.Laborder_Orderdate  AS servicedate
      |	,Laborders.Billingmodifier1  AS mappedcptmod1
      |	,Laborders.Billingmodifier2  AS mappedcptmod2
      |	,Zh_Labcatalog.Labcat_Cptcode  AS mappedcpt
      |	,Laborders.Imreenc_Code  AS encounterid
      |	,Zh_Labcatalog.Labcat_Cptcode  AS localcpt
      |	,Laborders.Billingmodifier1  AS localcptmod1
      |	,Laborders.Billingmodifier2  AS localcptmod2
      |	,ROW_NUMBER() OVER (PARTITION BY Laborders.Imrelaborder_Code, Laborders.Imredemec_Code, Laborders.Laborder_Orderdate
      |	                    ORDER BY Laborders.tag_systemdate DESC NULLS LAST) rn
      |FROM LABORDERS laborders
      |    JOIN ZH_LABCATALOG Zh_Labcatalog ON (Zh_Labcatalog.imrelabcat_code = laborders.imrelabcat_code)
      |WHERE laborders.laborder_completionstatus = 3
      |)
      |WHERE
      |    servicedate IS NOT NULL
      |AND claimid IS NOT NULL
      |AND patientid IS NOT NULL
      |AND rn = 1
      |
      |UNION
      |
      |--Procedures
      |SELECT
      |datasrc
      |,claimid
      |,patientid
      |,servicedate
      |,NULL AS facilityid
      |,encounterid
      |,localcpt
      |,NULL AS localbillingproviderid
      |,mappedcpt
      |,mappedcptmod1
      |,mappedcptmod2
      |,NULL AS mappedcptmod3
      |,NULL AS mappedcptmod4
      |,localcptmod1
      |,localcptmod2
      |,NULL AS localcptmod3
      |,NULL AS localcptmod4
      |,quantity
      |FROM
      |(
      |SELECT 'procedures' AS datasrc
      |	,Imreproc_Code  AS claimid
      |	,Imredemec_Code  AS patientid
      |	,COALESCE(Proc_Completiondate, Proc_Collecteddate) AS servicedate
      |	,Proc_Modifier1  AS mappedcptmod1
      |	,Proc_Modifier2  AS mappedcptmod2
      |	,Proc_Code  AS mappedcpt
      |	,Imreenc_Code  AS encounterid
      |	,Proc_Code  AS localcpt
      |	,Proc_Modifier1  AS localcptmod1
      |	,Proc_Modifier2  AS localcptmod2
      |	,Proc_Units  AS quantity
      |	,ROW_NUMBER() OVER (PARTITION BY Imreproc_Code, Imredemec_Code, COALESCE(Proc_Completiondate, Proc_Collecteddate)
      |	                    ORDER BY tag_systemdate DESC NULLS LAST) rn
      |FROM PROCEDURES Procedures
      |WHERE proc_completionstatus = 3
      |)
      |WHERE
      |    servicedate IS NOT NULL
      |AND claimid IS NOT NULL
      |AND patientid IS NOT NULL
      |AND rn = 1
    """.stripMargin
}

package com.optum.cdr.fe.etl.commercial.aspro.domains

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{CDRFEParquetNames, FEQueryAndMetadata}

object LABRESULT extends FEQueryAndMetadata[labresult]{

  override def name: String = CDRFEParquetNames.labresult

  override def dependsOn: Set[String] = Set("LABRESULT_LABRESULTS", "LABRESULT_PROCRESULTS", "LABRESULT_VITALS", "NONNUMERIC_LABRESULT")

  override def sparkSql: String =
    """
       select * from LABRESULT_LABRESULTS

       union all

       select * from LABRESULT_PROCRESULTS

       union all

       select * from LABRESULT_VITALS

       union all

       select * from NONNUMERIC_LABRESULT
    """.stripMargin

}

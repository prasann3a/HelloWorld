package com.optum.cdr.fe.etl.commercial.cattails.domains

import com.optum.oap.cdr.models.rxorder
import com.optum.cdr.fe.core.LoaderRunTimeVariables
import com.optum.cdr.fe.utils.Functions.mpvList
import com.optum.oap.sparkdataloader.{FETableInfo, RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RXORDER_ITEM_DETAIL_MEDICATIONS_TB extends FETableInfo[rxorder]{

  override def name: String = "RXORDER_ITEM_DETAIL_MEDICATIONS_TB"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES", "ITEM_DETAIL_MEDICATIONS_TB", "ZH_DATES_TB", "ZH_TIMES_TB", "MECCA_TERM_DETAILS_TB", "EVENTS_VW", "ITEM_DETAILS_VW")

  override def createDataFrameFromSource(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies.foreach {
      case (depName, df) => df.createOrReplaceTempView(depName)
    }
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES")
    val groupId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].groupId
    val clientDsId = runtimeVariables.asInstanceOf[LoaderRunTimeVariables].clientDsId
    val listFillnumExcp = mpvList(mapPredicateValues, groupId, clientDsId.toString,"FILLNUM","RXORDER","MEDICATION","REFILLS_PRESCRIBED").mkString(",")

    sparkSession.sql(
      """
        |with dedup_idm as
        |  (select * from (
        |                   select
        |                     mectrmdtl_id
        |                   , item_id
        |		   , event_id
        |                   , Action_Value_Id
        |                   , Action_Value_Desc
        |                   , CREATION_DATES_ID
        |                   , zd.Date_Oracle
        |                   , idm.CREATION_TIME_ID
        |                   , zt.formatted_military_time
        |                   , Freq_Value_Id
        |                   , Qty_Units_Value_Id
        |                   , route_value_id
        |                   , route_value_desc
        |                   , dose_value_id
        |                   , dose_value_desc
        |                   , dose_load_value_id
        |                   , dose_load_value_desc
        |                   , Supply_Value_Id
        |                   , supply_value_desc
        |                   , daily_load_value_id
        |                   , daily_load_value_desc
        |                   , refills_value_id
        |                   , quantity_value_desc
        |                   , dur_value_id
        |                   , dispunit_value_id
        |                   , min(zd.date_oracle) over (partition by item_id) as min_date_oracle
        |                   , min(zt.formatted_military_time) over (partition by item_id) as min_time
        |                   , dose_units_value_desc
        |		   , dispunit_value_desc
        |		   , disp_drug_value_desc
        |		   , row_number() over (partition by item_Id order by date_oracle desc nulls first, formatted_military_time desc nulls last)  as rownumber
        |                  FROM ITEM_DETAIL_MEDICATIONS_TB idm
        |                  inner JOIN ZH_DATES_TB zd ON (ZD.DATES_ID = iDM.CREATION_DATES_ID)
        |                  inner JOIN ZH_TIMES_TB zt ON (ZT.TIME_ID = iDM.CREATION_TIME_ID)
        |
        |               ) idm where rownumber=1
        |   ),
        |MECCA_DEDUPE AS
        |	( SELECT t.*
        |                    FROM (SELECT MECTRMDTL_ID,MECTRM_ID,term_desc,formatted_term_desc
        |                                ,row_number () over ( Partition by MECTRMDTL_ID order by LAST_MODIFIED_DATE desc nulls first ) as rownumber
        |                                FROM MECCA_TERM_DETAILS_TB
        |                                 ) t
        |                    WHERE t.rownumber = 1
        |	),
        |EVENT_DEDUPE AS
        |	(SELECT t.*
        |                FROM (
        |                        SELECT Patient_Id,Event_id,provider_id,EVENT_DATE_TIME
        |                        ,row_number () over ( Partition by Event_id order by LAST_MODIFIED_DATE desc nulls first ) as rownumber
        |                        FROM EVENTS_VW
        |                         ) t
        |                WHERE t.rownumber = 1
        |	)
        |, dedupe_idv as
        |   (select * from ( select   item_id
        |                           , event_id
        |                           , Facility_Num
        |                           , Do_Not_Substitute_Code
        |                           , row_number() over (partition by item_id, event_id order by last_modified_date desc nulls last)  as rnum
        |                    from ITEM_DETAILS_VW
        |                  ) where rnum=1
        |   )
        |select groupid, datasrc, client_ds_id, issuedate, ordervsprescription, patientid, rxid, localDaySupplied, encounterid, expiredate, facilityid, localdosefreq, localdrugdescription as localdescription, localform, localgenericdesc, localmedcode, localndc, localproviderid, localroute, localstrengthperdoseunit, localstrengthunit, localtotaldose, fillnum, orderstatus, quantityperfill, venue, ordertype
        |from
        |(
        |SELECT
        |    '{groupid}'                      AS groupid
        |   ,'item_detail_medications_tb'  AS datasrc
        |   ,{client_ds_id}                 AS client_ds_id
        |   , to_timestamp((concat_ws('', date_format(min_DATE_ORACLE,'yyyy-MM-dd'), ' ', min_TIME)),'yyyy-MM-dd HH:mm:ss') as issuedate
        |   , 'P' as ordervsprescription
        |   , EV.Patient_Id as patientid
        |   , idm.item_id as rxid
        |   , safe_to_number(case when idm.Supply_Value_Id = '0' then null else idm.Supply_Value_Desc end) as localdaysupplied
        |   , idm.Event_Id  as encounterid
        |   , case when ACTION_VALUE_ID ='21' then (concat_ws('', date_format(idm.DATE_ORACLE,'yyyy-MM-dd'), ' ', idm.FORMATTED_MILITARY_TIME)) else null end as discontinue_date
        |   , null as expiredate
        |   , idv.Facility_Num as facilityid
        |   , idv.do_not_substitute_code as daw
        |   , case when idm.freq_value_id='0' then null else concat_ws('', {client_ds_id}, '.', idm.freq_value_id) end as localdosefreq
        |   , case when idm.qty_units_value_id='0' then null else idm.qty_units_value_id end as dose_unit
        |   , idm.dur_value_id as duration
        |   , mtd.term_desc as localdrugdescription
        |   , case when idm.dose_load_value_desc <> '*Not Available' then idm.dose_units_value_desc else idm.dispunit_value_desc end  as localform
        |   , mtd.formatted_term_desc as localgenericdesc
        |   , mtd.Mectrm_Id as localmedcode
        |   , null as localndc
        |   , ev.provider_id as localproviderid
        |   , case when idm.dose_value_id = '0' then null else idm.dose_value_desc end as Qty_Of_Dose_Unit
        |   , case when idm.route_value_id = '0' then null else idm.route_value_desc end as localroute
        |   , case when idm.dose_load_value_desc <> '*Not Available' then nullif(regexp_extract(idm.DOSE_LOAD_VALUE_DESC,'^[-.,/0-9]+', 0), '') else nullif(regexp_extract(idm.disp_drug_value_desc,'^[-.,/0-9]+', 0), '') end as localstrengthperdoseunit
        |   , case when idm.dose_load_value_desc <> '*Not Available' then nullif(regexp_extract(idm.DOSE_LOAD_VALUE_DESC,'[a-zA-Z%]+([-/][ .0-9a-zA-Z%]+)?', 0), '') else nullif(regexp_extract(idm.disp_drug_value_desc,'[a-zA-Z%]+([-/][ .0-9a-zA-Z%]+)?', 0), '') end as localstrengthunit
        |   , case when idm.DAILY_LOAD_VALUE_ID = '0' then null else nullif(regexp_extract(idm.DAILY_LOAD_VALUE_DESC, '(\\S*)', 0), '') end as localtotaldose
        |
        |   , case when idm.refills_value_id  in ({list_fillnum_excp}) then null else nullif(substr(idm.refills_value_id,1,4), '') end fillnum
        |   , concat_ws('', {client_ds_id}, '.', idm.action_value_id) as orderstatus
        |   , idm.quantity_value_desc as quantityperfill
        |   , '1' as venue
        |   , 'CH002047' as ordertype
        |FROM DEDUP_IDM idm
        |inner JOIN MECCA_DEDUPE mtd ON (MTD.MECTRMDTL_ID = IDM.MECTRMDTL_ID)
        |inner JOIN DEDUPE_IDV idv ON (IDM.ITEM_ID = IDV.ITEM_ID )
        |inner JOIN EVENT_DEDUPE EV ON (EV.EVENT_ID = IDV.EVENT_ID)
        |
        |)
      """.stripMargin
        .replace("{groupid}", groupId)
        .replace("{client_ds_id}", clientDsId.toString )
        .replace("{list_fillnum_excp}", listFillnumExcp )
    )
  }

}

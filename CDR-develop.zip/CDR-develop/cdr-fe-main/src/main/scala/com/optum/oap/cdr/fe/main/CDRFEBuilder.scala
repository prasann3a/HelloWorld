package com.optum.cdr.fe.main

import java.util.concurrent.Executors

import com.optum.cdr.fe.core.{BaseDataLoader, BaseQueryConfig, ClientETLConf, LoaderRunTimeVariables}
import com.optum.cdr.fe.utils.UDFs.UDFRegistry
import com.optum.cdr.fe.utils.{CommonUtils, LoadersPathConfig}
import com.optum.oap.sparkdataloader.DataLoader
import com.optum.oap.sparklib.SparkUtils
import com.optum.oap.utils.CliUtils.getOptionalSeq
import com.optum.oap.utils.FileUtils
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

import scala.concurrent.{ExecutionContext, ExecutionContextExecutorService}

object CDRFEBuilder {

  private val logger = LoggerFactory.getLogger(this.getClass)

  def build(conf: ClientETLConf): Unit = {
    logger.warn(conf.toString)
    val executionThreads = conf.threads()

    implicit val executionContext: ExecutionContextExecutorService = ExecutionContext.fromExecutorService(Executors.newFixedThreadPool(executionThreads))
    val sparkSession: SparkSession = SparkUtils.createSparkSession("cdr-custom-clients-front-end", verboseLogging = false, logWarnings = true)
    val runtimeVariables = LoaderRunTimeVariables.getRunTimeVariables(conf)
    val targetTables = getOptionalSeq(conf.targetTables)
    val loaderPathConfig = LoadersPathConfig(conf.groupId(), conf.clientDsId(), conf.clientDsName(), conf.targetPathPrefix(),
      conf.targetCdrSchema(), conf.instanceDateStamp(), conf.environment.toOption)
    val udfs = UDFRegistry.ALL_UDFS
    val baseTargetPath = CommonUtils.gettargetBasePath(loaderPathConfig)
    val sourceParquetPath = FileUtils.ensureNonTrailingCharacter(conf.extStageLocation(), '/')
    val mappingParquetPath = FileUtils.ensureNonTrailingCharacter(conf.mappingDirLocation(), '/')
    val loader = new DataLoader(baseTargetPath)

    val queryConfig = getQueryConfigForClientDataSource(conf.emr(), conf.groupId(), conf.clientDsId())
    BaseDataLoader.loadData(sparkSession, loader, queryConfig, sourceParquetPath, mappingParquetPath, udfs, runtimeVariables, targetTables)(executionContext)
    sparkSession.stop()
  }

  private def getQueryConfigForClientDataSource(emr: String, clientId: String, clientDsId: Int): BaseQueryConfig = {
    val c = Class.forName("com.optum.cdr.fe.etl."+emr.toLowerCase()+".LoaderConfig$").getField("MODULE$").get(null).asInstanceOf[{val CLIENT_QUERIES_MAP: Map[String, BaseQueryConfig]}]
    c.CLIENT_QUERIES_MAP.getOrElse(s"${clientId}_$clientDsId", throw new IllegalArgumentException(s"No query config defined for client $clientId"))
  }
}

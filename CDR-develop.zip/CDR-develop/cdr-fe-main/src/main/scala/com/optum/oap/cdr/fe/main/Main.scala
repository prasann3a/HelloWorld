package com.optum.cdr.fe.main

import com.optum.cdr.fe.core.ClientETLConf

object Main {

  def main(args: Array[String]): Unit = {

    val conf = new ClientETLConf(args)
    CDRFEBuilder.build(conf)

  }
}

define prev_schema=&1
define curr_schema=&2

select 'CDR FE QC Report:  Start: ' ||  to_char(sysdate,'HH24:MI') from dual;
Select 'Previous schema = ' ||  '&prev_schema' from dual;
Select 'Current schema = ' ||  '&curr_schema' from dual;

begin
  for rec in (select distinct groupid, to_char(client_ds_id) as client_ds_id from cdr_common.external_data_job
                where target_schema = '&curr_schema'
                and status in ('SUCCESS','EXCHANGED')
              minus
               select distinct groupid, client_ds_id From cdr_10p.qc_cdr_fe_report
               where rel_cycle = '&curr_schema'
      )
loop
  QC_CDR_FE_DATA(rec.groupid, rec.client_ds_id, '&prev_schema', '&curr_schema');
end loop;
end;
/
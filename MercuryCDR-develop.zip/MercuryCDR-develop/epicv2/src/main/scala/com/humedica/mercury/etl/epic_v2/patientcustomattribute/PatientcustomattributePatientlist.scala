package com.humedica.mercury.etl.epic_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame

class PatientcustomattributePatientlist(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patient_list", "patient:epic_v2.patient.PatientPatreg")

  columnSelect = Map(
    "patient_list" -> List("MRN", "PAYOR")
    , "patient" -> List("PATIENTID", "MEDICALRECORDNUMBER")
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("patient_list")
      .join(dfs("patient"), dfs("patient_list")("MRN") === dfs("patient")("MEDICALRECORDNUMBER"), "inner")
  }

  afterJoin = (df: DataFrame) => {
    df.select("PATIENTID", "PAYOR").distinct
  }

  map = Map(
    "DATASRC" -> literal("PATIENT_LIST"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ATTRIBUTE_TYPE_CUI" -> literal("CH002787"),
    "ATTRIBUTE_VALUE" -> mapFrom("PAYOR")
  )
}
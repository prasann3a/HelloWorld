package com.humedica.mercury.etl.epic_v2.labresult

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class LabresultDmdiabetes(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("dm_diabetes")

  columnSelect = Map(
    "dm_diabetes" -> List("PAT_ID", "HBA1C_LAST", "LDL_DIR_LAST", "LDL_CALC_LAST", "HDL_LAST", "VLDL_LAST", "LDL_HDL_RT_LAST",
      "TTL_CHL_LAST", "TRIGLY_LAST", "BUN_LAST", "UR_MALB_LAST", "UR_PROT_LAST", "PROT_CR_RT_LAST", "CREAT_LAST",
      "CREAT_CLR_LAST", "TSH_LAST", "T3_LAST", "T4_LAST", "HBA1C_L_UNIT", "LDL_DIR_L_UNIT", "LDL_CALC_L_UNIT", "HDL_L_UNIT",
      "VLDL_L_UNIT", "LDL_HDL_RT_L_UNIT", "TTL_CHL_L_UNIT", "TRIGLY_L_UNIT", "BUN_L_UNIT", "UR_MALB_L_UNIT", "UR_PROT_L_UNIT",
      "PROT_CR_RT_L_UNIT", "CREAT_L_UNIT", "CREAT_CLR_L_UNIT", "TSH_L_UNIT", "T3_L_UNIT", "T4_L_UNIT", "HBA1C_LAST_DT",
      "LDL_DIR_LAST_DT", "LDL_CALC_LAST_DT", "HDL_LAST_DT", "VLDL_LAST_DT", "LDL_HDL_RT_LAST_DT", "TTL_CHL_LAST_DT",
      "TRIGLY_LAST_DT", "BUN_LAST_DT", "UR_MALB_LAST_DT", "UR_PROT_LAST_DT", "PROT_CR_RT_LAST_DT", "CREAT_LAST_DT",
      "CREAT_CLR_LAST_DT", "TSH_LAST_DT", "T3_LAST_DT", "T4_LAST_DT")
  )

  afterJoin = (df: DataFrame) => {

    val df1 = df.select(df("PAT_ID"), expr("stack(17, 'HBA1C_LAST', HBA1C_LAST, HBA1C_L_UNIT, HBA1C_LAST_DT," +
      "'LDL_DIR_LAST', LDL_DIR_LAST, LDL_DIR_L_UNIT, LDL_DIR_LAST_DT," +
      "'LDL_CALC_LAST', LDL_CALC_LAST, LDL_CALC_L_UNIT, LDL_CALC_LAST_DT," +
      "'HDL_LAST', HDL_LAST, HDL_L_UNIT, HDL_LAST_DT," +
      "'VLDL_LAST', VLDL_LAST, VLDL_L_UNIT, VLDL_LAST_DT," +
      "'LDL_HDL_RT_LAST', LDL_HDL_RT_LAST, LDL_HDL_RT_L_UNIT, LDL_HDL_RT_LAST_DT," +
      "'TRIGLY_LAST', TRIGLY_LAST, TRIGLY_L_UNIT, TRIGLY_LAST_DT," +
      "'TTL_CHL_LAST', TTL_CHL_LAST, TTL_CHL_L_UNIT, TTL_CHL_LAST_DT," +
      "'BUN_LAST', BUN_LAST, BUN_L_UNIT, BUN_LAST_DT," +
      "'UR_MALB_LAST', UR_MALB_LAST, UR_MALB_L_UNIT, UR_MALB_LAST_DT," +
      "'UR_PROT_LAST', UR_PROT_LAST, UR_PROT_L_UNIT, UR_PROT_LAST_DT," +
      "'PROT_CR_RT_LAST', PROT_CR_RT_LAST, PROT_CR_RT_L_UNIT, PROT_CR_RT_LAST_DT," +
      "'CREAT_LAST', CREAT_LAST, CREAT_L_UNIT, CREAT_LAST_DT," +
      "'CREAT_CLR_LAST', CREAT_CLR_LAST, CREAT_CLR_L_UNIT, CREAT_CLR_LAST_DT," +
      "'TSH_LAST', TSH_LAST, TSH_L_UNIT, TSH_LAST_DT," +
      "'T3_LAST', T3_LAST, T3_L_UNIT, T3_LAST_DT," +
      "'T4_LAST', T4_LAST, T4_L_UNIT, T4_LAST_DT) as (LOCALCODE, LOCALRESULT, LOCALUNITS, DATEAVAILABLE)"))
    df1.withColumn("LOCALUNITS", lower(df1("LOCALUNITS")))
      .filter("localresult is not null and dateavailable is not null and pat_id is not null")

  }

  map = Map(
    "DATASRC" -> literal("dm_diabetes"),
    "LABRESULTID" -> concatFrom(Seq("PAT_ID", "LOCALCODE", "LOCALUNITS", "DATEAVAILABLE"), delim = "_"),
    "PATIENTID" -> mapFrom("PAT_ID"),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "LOCALRESULT" -> mapFrom("LOCALRESULT"),
    "LOCALUNITS" -> mapFrom("LOCALUNITS"),
    "DATEAVAILABLE" -> mapFrom("DATEAVAILABLE"),
    "LABRESULT_DATE" -> mapFrom("DATEAVAILABLE")
  )

}

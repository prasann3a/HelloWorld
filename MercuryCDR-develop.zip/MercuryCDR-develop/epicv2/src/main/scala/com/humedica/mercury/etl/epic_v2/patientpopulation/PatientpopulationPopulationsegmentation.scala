package com.humedica.mercury.etl.epic_v2.patientpopulation

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class PatientpopulationPopulationsegmentation(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("humedica_patient_list", "cdr.map_predicate_values")

  columnSelect = Map(
    "humedica_patient_list" -> List("PATIENTID", "POPULATION", "UPDATE_DATE")
  )

  beforeJoin = Map(
    "cdr.map_predicate_values" -> ((df: DataFrame) => {
      df.filter("GROUPID = '" + config(GROUP) + "' and CLIENT_DS_ID = '" + config(CLIENT_DS_ID) + "'" +
        "and DATA_SRC = 'POPULATION' and ENTITY = 'PATIENT_POPULATION' and TABLE_NAME = 'POPULATION'")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("humedica_patient_list")
      .join(dfs("cdr.map_predicate_values"), dfs("humedica_patient_list")("POPULATION") === dfs("cdr.map_predicate_values")("COLUMN_VALUE"),"left_outer")
  }

  map = Map(
    "DATASRC" -> literal("hum_pat_list"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "POPULATION_TYPE_CUI" -> mapFrom("COLUMN_NAME")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID"), df("POPULATION")).orderBy(length(df("UPDATE_DATE")).desc_nulls_last)
    val addColumn = df.withColumn("rn", row_number.over(groups))
    addColumn.filter("rn = 1 and PATIENTID IS NOT NULL").drop("rn")
  }
}

package com.humedica.mercury.etl.epic_v2.appointment

import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Constants._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import com.humedica.mercury.etl.core.engine.Types._


class AppointmentEncountervisit (config: Map[String, String]) extends EntitySource(config: Map[String, String]) {


    tables = List("encountervisit", "cdr.map_predicate_values", "encounter_comment")

    columnSelect = Map(
        "encountervisit" -> List("Appt_Time", "Pat_Enc_Csn_Id", "Department_Id", "Pat_Id", "Visit_Prov_Id", "UPDATE_DATE", "APPT_STATUS_C", "ENC_TYPE_C", "APPT_PRC_ID"),
        "encounter_comment" -> List("PATIENT_ENCOUNTER_ID", "PATIENT_ID", "UPDATED_DATE", "ENCOUNTER_COMMENT")
    )

    beforeJoin = Map(
        "encountervisit" -> ((df: DataFrame) => {
            val list_enc_type_c_incl = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "ENCOUNTERVISIT", "APPOINTMENT", "ENCOUNTERVISIT", "ENC_TYPE_C_INCL")
            val list_appt_prc_id_excl = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "ENCOUNTERVISIT", "APPOINTMENT", "ENCOUNTERVISIT", "APPT_PRC_ID_EXCL")
            val list_enc_type_c_excl = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "ENCOUNTERVISIT", "APPOINTMENT", "ENCOUNTERVISIT", "ENC_TYPE_C_EXCL")
            val list_appt_prc_id_incl = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "ENCOUNTERVISIT", "APPOINTMENT", "ENCOUNTERVISIT", "APPT_PRC_ID_INCL")
            val fil = includeIf("pat_enc_csn_id is not null and pat_id is not null and appt_time is not null and department_id is not null")(df)
            val addColumn = fil.withColumn("nullColumn",lit("'NO_MPV_MATCHES'"))
            addColumn.withColumn("incude_row", when(addColumn("nullColumn") isin(list_enc_type_c_incl:_*),"y")
              .when((coalesce(fil("ENC_TYPE_C"),lit("X")) isin(list_enc_type_c_incl:_*))
                && (coalesce(fil("APPT_PRC_ID"),lit("X")) isin(list_appt_prc_id_incl:_*))
                && ((!(coalesce(fil("ENC_TYPE_C"),lit("X")) isin(list_enc_type_c_excl:_*))) || (!(coalesce(fil("APPT_PRC_ID"),lit("X")) isin(list_appt_prc_id_excl:_*))))
                  , "y"))
        }),
        "encounter_comment" -> ((df: DataFrame) => {
            val groups1 = Window.partitionBy(df("PATIENT_ENCOUNTER_ID"), df("PATIENT_ID")).orderBy(df("UPDATED_DATE").desc)
            val addColumn = df.withColumn("rn", row_number.over(groups1))
            addColumn.filter("rn = 1").drop("rn").drop("UPDATED_DATE")
        })
    )

    join = (dfs: Map[String, DataFrame]) => {
        dfs("encountervisit")
          .join(dfs("encounter_comment"), dfs("encountervisit")("Pat_Enc_Csn_Id") === dfs("encounter_comment")("PATIENT_ENCOUNTER_ID") &&
            dfs("encountervisit")("Pat_Id") === dfs("encounter_comment")("PATIENT_ID"), "left_outer")
    }



    map = Map(
        "DATASRC" -> literal("encountervisit"),
        "APPOINTMENTDATE" -> mapFrom("Appt_Time"),
        "APPOINTMENTID" -> mapFrom("Pat_Enc_Csn_Id"),
        "LOCATIONID" -> mapFrom("Department_Id"),
        "PATIENTID" -> mapFrom("Pat_Id"),
        "PROVIDERID" -> mapFrom("Visit_Prov_Id"),
        "APPOINTMENT_REASON" -> ((col:String,df:DataFrame) => df.withColumn(col, substring(df("ENCOUNTER_COMMENT"),1,249)))
    )


    afterMap = (df: DataFrame) => {
        val groups = Window.partitionBy(df("APPOINTMENTID")).orderBy(df("UPDATE_DATE").desc)
        val addColumn = df.withColumn("rn", row_number.over(groups))
        addColumn.filter("rn = 1 and APPT_STATUS_C = '1' and incude_row = 'y'").drop("rn")
    }
}
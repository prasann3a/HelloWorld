package com.humedica.mercury.etl.epic_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Constants._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import com.humedica.mercury.etl.core.engine.Functions._

class PatientcustomattributePatreg(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patreg")

  columnSelect = Map(
    "patreg" -> List("PAT_ID", "ADD_LINE_1", "ADD_LINE_2", "ZIP", "UPDATE_DATE")
  )

  afterJoin = (df: DataFrame) => {
    df.withColumn("rn", row_number.over(Window.partitionBy(df("PAT_ID")).orderBy(df("UPDATE_DATE").desc_nulls_last)))
      .filter("rn = 1")
  }

  map = Map(
    "DATASRC" -> literal("patreg"),
    "PATIENTID" -> mapFrom("PAT_ID"),
    "ATTRIBUTE_TYPE_CUI" -> literal("CH002788"),
    "ATTRIBUTE_VALUE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat_ws(" - ", concat_ws(" ", df("ADD_LINE_1"), df("ADD_LINE_2")), df("ZIP")))
    })
  )

}

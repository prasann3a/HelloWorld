package com.humedica.mercury.etl.epic_v2.observation

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class ObservationDeprscreeningscore(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables=List("deprscreeningscore", "cdr.zcm_obstype_code")

  columnSelect = Map(
    "deprscreeningscore" -> List("PAT_ID", "PAT_ENC_CSN_ID", "CONCEPT_ID", "CONTACT_DATE", "FILEID", "DEPRSCREENINGSCORENUM"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "DATASRC", "OBSTYPE", "OBSCODE")
  )

  beforeJoin = Map(
    "cdr.zcm_obstype_code" -> ((df: DataFrame) => {
      df.filter("GROUPID = '" + config(GROUP) + "' and DATASRC = 'deprscreeningscore' and OBSTYPE <> 'LABRESULT'")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("deprscreeningscore")
      .join(dfs("cdr.zcm_obstype_code"), concat(lit(config(CLIENT_DS_ID)+"."), dfs("deprscreeningscore")("CONCEPT_ID")) === dfs("cdr.zcm_obstype_code")("obscode"), "inner")
  }


  map = Map(
    "DATASRC" -> literal("deprscreeningscore"),
    "LOCALRESULT" -> mapFrom("DEPRSCREENINGSCORENUM"),
    "LOCALCODE" -> mapFrom("CONCEPT_ID", nullIf=Seq(null), prefix=config(CLIENT_DS_ID) + "."),
    "OBSDATE" -> mapFrom("CONTACT_DATE"),
    "PATIENTID" -> mapFrom("PAT_ID"),
    "ENCOUNTERID" -> mapFrom("PAT_ENC_CSN_ID"),
    "OBSTYPE" -> mapFrom("OBSTYPE")
  )

  afterMap = (df: DataFrame) => {
      val groups = Window.partitionBy(df("PATIENTID"), df("ENCOUNTERID"), df("LOCALCODE"), df("OBSDATE"), df("OBSTYPE")).orderBy(df("FILEID").desc, df("DEPRSCREENINGSCORENUM").desc_nulls_last)
      val addColumn = df.withColumn("rn", row_number.over(groups))
      addColumn.filter("rn = 1 AND LOCALRESULT IS NOT NULL AND PATIENTID IS NOT NULL AND OBSDATE IS NOT NULL")
    }

}

package com.humedica.mercury.etl.epic_v2.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcImmunizations(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "Immunizations"
  )

  columnSelect = Map(
    "Immunizations" -> List("IMMUNZATN_ID", "NAME", "PAT_ID", "IMM_CSN", "IMMUNIZATION_TIME", "IMMUNE_DATE", "IMMNZTN_STATUS_C")
  )

  beforeJoin = Map(
    "Immunizations" -> includeIf(
      "nvl(IMMNZTN_STATUS_C, '1')  NOT IN ('2','3') " +
        "AND PAT_ID is NOT NULL " +
        "AND IMMUNZATN_ID is NOT NULL " +
        "AND coalesce(IMMUNIZATION_TIME ,IMMUNE_DATE) IS NOT NULL")
  )

  map = Map(
    "DATASRC" -> literal("immunization"),
    "LOCALMEDCODE" -> mapFrom("IMMUNZATN_ID"),
    "LOCALDESCRIPTION" -> mapFrom("NAME"),
    "LOCALNDC" -> nullValue()
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PAT_ID"), df("IMM_CSN"), df("IMMUNZATN_ID"), coalesce(df("IMMUNIZATION_TIME"), df("IMMUNE_DATE")))
      .orderBy(df("PAT_ID"), df("IMM_CSN"), df("IMMUNZATN_ID"), coalesce(df("IMMUNIZATION_TIME"), df("IMMUNE_DATE")).desc_nulls_last)
    val addColumn_df = df.withColumn("rn", row_number.over(groups))
    val filter_rn_df = addColumn_df.filter("rn = 1").drop("rn")

    val group_df = Window.partitionBy(filter_rn_df("DATASRC"), filter_rn_df("LOCALMEDCODE"), filter_rn_df("LOCALDESCRIPTION"), filter_rn_df("LOCALNDC"))
    val df1 = filter_rn_df.withColumn("NO_NDC", sum(when(filter_rn_df("LOCALNDC").isNull, 1).otherwise(0)).over(group_df))
                          .withColumn("HAS_NDC", lit(0))
    val df2 = df1.withColumn("NUM_RECS", df1("NO_NDC"))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df2.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcImmunizations(cfg); val med_s = build(a, allColumns = true) ;

package com.humedica.mercury.etl.epic_v2.labresult

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class LabresultDmhypertension(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("dm_hypertension")

  columnSelect = Map(
    "dm_hypertension" -> List("PAT_ID", "BUN_LAST", "UR_MALB_LAST", "UR_PROT_LAST", "PROT_CR_RT_LAST", "CREAT_LAST",
      "CREAT_CLR_LAST", "POTASSIUM_LAST", "BUN_L_UNIT", "UR_MALB_L_UNIT", "UR_PROT_L_UNIT", "PROT_CR_RT_L_UNIT", "CREAT_L_UNIT",
      "CREAT_CLR_L_UNIT", "POTASSIUM_L_UNIT", "BUN_LAST_DT", "UR_MALB_LAST_DT", "UR_PROT_LAST_DT", "PROT_CR_RT_LAST_DT", "CREAT_LAST_DT",
      "CREAT_CLR_LAST_DT", "POTASSIUM_LAST_DT")
  )

  afterJoin = (df: DataFrame) => {

    val df1 = df.select(df("PAT_ID"), expr("stack(7, 'BUN_LAST', BUN_LAST, BUN_L_UNIT, BUN_LAST_DT," +
      "'UR_MALB_LAST', UR_MALB_LAST, UR_MALB_L_UNIT, UR_MALB_LAST_DT," +
      "'UR_PROT_LAST', UR_PROT_LAST, UR_PROT_L_UNIT, UR_PROT_LAST_DT," +
      "'PROT_CR_RT_LAST', PROT_CR_RT_LAST, PROT_CR_RT_L_UNIT, PROT_CR_RT_LAST_DT," +
      "'CREAT_LAST', CREAT_LAST, CREAT_L_UNIT, CREAT_LAST_DT," +
      "'CREAT_CLR_LAST', CREAT_CLR_LAST, CREAT_CLR_L_UNIT, CREAT_CLR_LAST_DT," +
      "'POTASSIUM_LAST', POTASSIUM_LAST, POTASSIUM_L_UNIT, POTASSIUM_LAST_DT) as (LOCALCODE, LOCALRESULT, LOCALUNITS, DATEAVAILABLE)"))
    df1.withColumn("LOCALUNITS", lower(df1("LOCALUNITS")))
      .filter("localresult is not null and dateavailable is not null and pat_id is not null")

  }

  map = Map(
    "DATASRC" -> literal("dm_hypertension"),
    "LABRESULTID" -> concatFrom(Seq("PAT_ID", "LOCALCODE", "LOCALUNITS", "DATEAVAILABLE"), delim = "_"),
    "PATIENTID" -> mapFrom("PAT_ID"),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "LOCALRESULT" -> mapFrom("LOCALRESULT"),
    "LOCALUNIT" -> mapFrom("LOCALUNITS"),
    "DATEAVAILABLE" -> mapFrom("DATEAVAILABLE"),
    "LABRESULT_DATE" -> mapFrom("DATEAVAILABLE")
  )

}

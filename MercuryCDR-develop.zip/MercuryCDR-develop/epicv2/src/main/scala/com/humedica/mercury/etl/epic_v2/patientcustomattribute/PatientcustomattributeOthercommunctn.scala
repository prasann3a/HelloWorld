package com.humedica.mercury.etl.epic_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class PatientcustomattributeOthercommunctn(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("other_communctn")

  columnSelect = Map(
    "other_communctn" -> List("PAT_ID", "OTHER_COMMUNIC_C", "OTHER_COMMUNIC_NUM", "LINE", "UPDATE_DATE")
  )

  afterJoin = (df: DataFrame) => {
    val dedupe = df.filter("other_communic_c in ('1', '7') and other_communic_num <> '000-000-0000'")
      .withColumn("rn", row_number.over(
        Window.partitionBy(df("PAT_ID"), df("OTHER_COMMUNIC_C"))
          .orderBy(df("UPDATE_DATE").desc_nulls_last, df("LINE").desc_nulls_last)
        )
      )
      .filter("rn = 1")

    dedupe.groupBy("PAT_ID")
      .agg(
        max(when(dedupe("OTHER_COMMUNIC_C") === 1, dedupe("OTHER_COMMUNIC_NUM"))).as("MOBILE"),
        max(when(dedupe("OTHER_COMMUNIC_C") === 7, dedupe("OTHER_COMMUNIC_NUM"))).as("HOME")
      )
  }

  map = Map(
    "DATASRC" -> literal("other_communctn"),
    "PATIENTID" -> mapFrom("PAT_ID"),
    "ATTRIBUTE_TYPE_CUI" -> literal("CH002949"),
    "ATTRIBUTE_VALUE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col,
        when(df("MOBILE") =!= df("HOME"), concat_ws(", ", df("MOBILE"), df("HOME")))
        .otherwise(coalesce(df("MOBILE"), df("HOME")))
      )
    })
  )


}

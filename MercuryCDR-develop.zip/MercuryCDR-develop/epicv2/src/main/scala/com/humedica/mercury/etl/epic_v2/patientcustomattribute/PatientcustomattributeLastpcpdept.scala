package com.humedica.mercury.etl.epic_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{lit, row_number}

class PatientcustomattributeLastpcpdept(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "last_pcp_dept",
    "patientidentifierIdentityid:epic_v2.patientidentifier.PatientidentifierIdentityid",
    "patientidentifierIdentityidsubtype:epic_v2.patientidentifier.PatientidentifierIdentityidsubtype",
    "patientidentifierPatreg:epic_v2.patientidentifier.PatientidentifierPatreg"
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patientidentifierDf = dfs.filterKeys(_.startsWith("patientidentifier")).values.reduce(_ union _) // union all input patientidentifier dataframes
    val lastPcpDeptDf = dfs("last_pcp_dept")
    lastPcpDeptDf.join(
      patientidentifierDf,
      lastPcpDeptDf("IDX_MRN") === patientidentifierDf("IDVALUE")
      and patientidentifierDf("IDTYPE") === lit("MRN")
      and patientidentifierDf("ID_SUBTYPE") === lit("IDX")
    )
  }

  afterJoin = (df: DataFrame) => {
    val patientidPartition = Window.partitionBy(df("PATIENTID")).orderBy(df("LAST_VISIT_WITH_TPI_PCP_DEPT").desc_nulls_last)
    val rownumberFilteredDf = df.filter("PATIENTID is not null")
      .withColumn("rn", row_number.over(patientidPartition)).filter("rn = 1")
      .select("IDX_MRN","LAST_VISIT_PROVIDER","LAST_VISIT_DEPT","LAST_VISIT_DEPT_MNE","LAST_VISIT_PROVIDER_NPI","PATIENTID")

    val unpivotFunc = unpivot(
      Seq("LAST_VISIT_PROVIDER", "LAST_VISIT_DEPT", "LAST_VISIT_DEPT_MNE", "LAST_VISIT_PROVIDER_NPI"),
      types = Seq("CH002785", "CH002786", "CH002787", "CH002788"),
      typeColumnName = "CUI"
    )
    unpivotFunc("ATTRIBUTEVALUE", rownumberFilteredDf)
      .filter("attributevalue is not null")
  }

  map = Map(
    "DATASRC" -> literal("last_pcp_dept"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ATTRIBUTE_TYPE_CUI" -> mapFrom("CUI"),
    "ATTRIBUTE_VALUE" -> mapFrom("ATTRIBUTEVALUE")
  )
}

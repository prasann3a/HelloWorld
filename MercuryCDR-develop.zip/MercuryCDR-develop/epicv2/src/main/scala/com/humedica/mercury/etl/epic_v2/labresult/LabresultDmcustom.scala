package com.humedica.mercury.etl.epic_v2.labresult

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window

class LabresultDmcustom(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("diab:epic_v2.labresult.LabresultDmdiabetes",
    "cad:epic_v2.labresult.LabresultDmcad",
    "hyper:epic_v2.labresult.LabresultDmhypertension")

  columnSelect = Map(
    "diab" -> List("DATASRC", "PATIENTID", "LABRESULTID", "LOCALCODE", "LOCALRESULT", "LOCALUNITS", "DATEAVAILABLE", "LABRESULT_DATE"),
    "cad" -> List("DATASRC", "PATIENTID", "LABRESULTID", "LOCALCODE", "LOCALRESULT", "LOCALUNITS", "DATEAVAILABLE", "LABRESULT_DATE"),
    "hyper" -> List("DATASRC", "PATIENTID", "LABRESULTID", "LOCALCODE", "LOCALRESULT", "LOCALUNITS", "DATEAVAILABLE", "LABRESULT_DATE")
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("diab").union(dfs("cad")).union(dfs("hyper"))
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("LABRESULTID"))
      .orderBy(when(df("DATASRC") === "dm_diabetes", 1).otherwise(2))

    df.withColumn("rn", row_number.over(groups))
      .withColumn("LOCALRESULT_25", when(!df("LOCALRESULT").rlike("^[+-]?(\\.\\d+|\\d+\\.?\\d*)$"),
        when(locate(" ", df("LOCALRESULT"), 25) === 0, expr("substr(LOCALRESULT,1,length(LOCALRESULT))"))
          .otherwise(expr("substr(LOCALRESULT,1,locate(' ', LOCALRESULT, 25))"))).otherwise(null))
      .withColumn("LOCALRESULT_NUMERIC", when(df("LOCALRESULT").rlike("^[+-]?(\\.\\d+|\\d+\\.?\\d*)$"), df("LOCALRESULT")).otherwise(null))
      .filter("rn = 1")
  }

  map = Map(
    "DATASRC" -> mapFrom("DATASRC"),
    "LABRESULTID" -> mapFrom("LABRESULTID"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "LOCALRESULT" -> mapFrom("LOCALRESULT"),
    "LOCALRESULT_NUMERIC" -> mapFrom("LOCALRESULT_NUMERIC"),
    "LOCALRESULT_INFERRED" -> extract_value(),
    "LOCALUNITS" -> mapFrom("LOCALUNITS"),
    "DATEAVAILABLE" -> mapFrom("DATEAVAILABLE"),
    "LABRESULT_DATE" -> mapFrom("LABRESULT_DATE")
  )


}

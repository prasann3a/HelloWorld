package com.humedica.mercury.etl.epic_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.row_number

class PatientcustomattributeInsurance(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "insuranceEncountervisit:epic_v2.insurance.InsuranceEncountervisit",
    "insuranceInptbillingacct:epic_v2.insurance.InsuranceInptbillingacct",
    "insurancePatacctcvg:epic_v2.insurance.InsurancePatacctcvg",
    "insuranceProfbilling:epic_v2.insurance.InsuranceProfbilling"
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs.values.reduce(_ union _) // union all input dataframes
  }

  afterJoin = (df: DataFrame) => {
    val patientidPartition = Window.partitionBy(df("PATIENTID")).orderBy(df("INS_TIMESTAMP").desc_nulls_last, df("INSURANCEORDER").asc_nulls_last)
    df.filter("PLANNAME is not null")
      .withColumn("rn", row_number.over(patientidPartition)).filter("rn = 1")
  }

  map = Map(
    "DATASRC" -> literal("ins_plan_name"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ATTRIBUTE_TYPE_CUI" -> literal("CH002949"),
    "ATTRIBUTE_VALUE" -> mapFrom("PLANNAME")
  )
}

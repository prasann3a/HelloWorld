package com.humedica.mercury.etl.epic_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, expr, row_number}

import scala.collection.JavaConverters._

class PatientcustomattributePatpayorplan(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "pat_payor_plan"
  )

  afterJoin = (df: DataFrame) => {
    val patientidPartition = Window.partitionBy(df("PAT_ID"))
      .orderBy(df("PRIM_START_DATE").desc_nulls_last, df("UPDATE_DATE_A").desc_nulls_last, df("UPDATE_DATE_B").desc_nulls_last,df("PRIM_PLAN_ID"), df("MEDICARE_MEDICAL_DUAL"))
    val filteredDf = df.filter("PAT_ID is not null")
      .withColumn("rn", row_number.over(patientidPartition))
      .filter("rn = 1")
      .withColumn("MM_DUAL", expr("NVL(MEDICARE_MEDICAL_DUAL,'N')"))
      .withColumn("PLAN", expr("concat_ws('',prim_plan_id,' (',prim_plan_name,')')"))
      .select("PAT_ID", "MM_DUAL", "PLAN")
    val unpivotFunc = unpivot(
      Seq("PLAN", "MM_DUAL"),
      types = Seq("CH002785", "CH002786"),
      typeColumnName = "CUI"
    )
    unpivotFunc("VALUE", filteredDf)
  }

  map = Map(
    "DATASRC" -> literal("pat_payor_plan"),
    "PATIENTID" -> mapFrom("PAT_ID"),
    "ATTRIBUTE_TYPE_CUI" -> mapFrom("CUI"),
    "ATTRIBUTE_VALUE" -> mapFrom("VALUE")
  )

  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Patientcustomattribute").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*)
      .filter("patientid is not null")
      .distinct()
  }
}

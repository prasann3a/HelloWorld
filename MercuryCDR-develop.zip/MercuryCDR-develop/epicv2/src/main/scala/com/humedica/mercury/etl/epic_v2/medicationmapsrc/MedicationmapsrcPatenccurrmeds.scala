package com.humedica.mercury.etl.epic_v2.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcPatenccurrmeds(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "medorders",
    "pat_enc_curr_meds",
    "zh_claritymed","zh_rx_ndc_code"
  )

  columnSelect = Map(
    "medorders" -> List("ORDER_MED_ID", "MEDICATION_ID", "NAME", "UPDATE_DATE"),
    "pat_enc_curr_meds" -> List("MEDICATION_ID", "CURRENT_MED_ID", "IS_ACTIVE_YN"),
    "zh_claritymed" -> List("MEDICATION_ID", "NAME", "RAW_11_DIGIT_NDC"),
    "zh_rx_ndc_code" -> List("MEDICATION_ID","NDC_CODE")
  )

  beforeJoin = Map(
    "zh_rx_ndc_code" -> ((df: DataFrame) => {
      df.withColumnRenamed("MEDICATION_ID", "MEDICATION_ID_ndc")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val group_df = Window.partitionBy(dfs("medorders")("ORDER_MED_ID")).orderBy(dfs("medorders")("UPDATE_DATE").desc_nulls_last)
    val med_df = dfs("medorders").withColumn("rn", row_number.over(group_df)).filter("rn = 1")

    val pat_df = table("pat_enc_curr_meds").withColumnRenamed("MEDICATION_ID", "PAT_MEDICATION_ID")
    val zh_df = table("zh_claritymed").withColumnRenamed("MEDICATION_ID", "ZH_MEDICATION_ID")
                                    .withColumnRenamed("NAME", "ZHC_NAME")
    val join_df = pat_df.join(med_df, med_df("ORDER_MED_ID") === pat_df("CURRENT_MED_ID"), "left_outer")
                        .withColumn("NEW_MEDICATION_ID", coalesce(pat_df("PAT_MEDICATION_ID"), med_df("MEDICATION_ID")))

    val filter_df = join_df.filter("NEW_MEDICATION_ID != '-1' AND IS_ACTIVE_YN = 'Y'")

    filter_df.join(zh_df, zh_df("ZH_MEDICATION_ID") === filter_df("NEW_MEDICATION_ID"), "left_outer")
  }

  joinExceptions = Map(
    "H770319_EP3_V1" -> ((dfs: Map[String, DataFrame]) => {
      val group_df = Window.partitionBy(dfs("medorders")("ORDER_MED_ID")).orderBy(dfs("medorders")("UPDATE_DATE").desc_nulls_last)
      val med_df = dfs("medorders").withColumn("rn", row_number.over(group_df)).filter("rn = 1")

      val pat_df = table("pat_enc_curr_meds").withColumnRenamed("MEDICATION_ID", "PAT_MEDICATION_ID")
      val zh_df = table("zh_claritymed").withColumnRenamed("MEDICATION_ID", "ZH_MEDICATION_ID")
                                      .withColumnRenamed("NAME", "ZHC_NAME")
      val join_df = pat_df.join(med_df, med_df("ORDER_MED_ID") === pat_df("CURRENT_MED_ID"), "left_outer")
        .withColumn("NEW_MEDICATION_ID", coalesce(pat_df("PAT_MEDICATION_ID"), med_df("MEDICATION_ID")))

      val filter_df = join_df.filter("NEW_MEDICATION_ID != '-1' AND IS_ACTIVE_YN = 'Y'")

      filter_df.join(zh_df, zh_df("ZH_MEDICATION_ID") === filter_df("NEW_MEDICATION_ID"), "left_outer")
               .join(dfs("zh_rx_ndc_code"), dfs("zh_rx_ndc_code")("MEDICATION_ID_ndc") === filter_df("NEW_MEDICATION_ID"), "left_outer")
    })
  )

  map = Map(
    "DATASRC" -> literal("pat_enc_curr_meds"),
    "LOCALMEDCODE" -> mapFrom("NEW_MEDICATION_ID"),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, trim(substring(df("RAW_11_DIGIT_NDC"), 1, 11)))),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, coalesce(lower(df("ZHC_NAME")), lower(df("NAME"))))),
    "NDC_SRC" -> literal("src"),
    "LOCALBRAND" -> nullValue(),
    "LOCALGENERIC" -> nullValue(),
    "LOCALGPI" -> nullValue(),
    "LOCALFORM" -> nullValue(),
    "LOCALSTRENGTH" -> nullValue()
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALNDC"), df("LOCALDESCRIPTION"))
    val df1 = df.withColumn("NUM_RECS", count("*").over(groups))
                .withColumn("NO_NDC", sum(when(df("LOCALNDC").isNull, 1).otherwise(0)).over(groups))
                .withColumn("HAS_NDC", sum(when(df("LOCALNDC").isNull, 0).otherwise(1)).over(groups))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }

  mapExceptions = Map(
    ("H770319_EP3_V1", "LOCALNDC") -> ((col: String, df: DataFrame) =>
      df.withColumn(col, trim(substring(df("NDC_CODE"), 1, 11))))
  )
}

//val a = new MedicationmapsrcPatenccurrmeds(cfg); val med_s = build(a, allColumns = true) ;

package com.humedica.mercury.etl.epic_v2.labresult

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

class LabresultDmcad(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("dm_cad")

  columnSelect = Map(
    "dm_cad" -> List("PAT_ID", "LDL_DIR_LAST", "LDL_CALC_LAST", "HDL_LAST", "VLDL_LAST", "LDL_HDL_RT_LAST", "TTL_CHL_LAST",
      "TRIGLY_LAST", "LDL_DIR_L_UNIT", "LDL_CALC_L_UNIT", "HDL_L_UNIT", "VLDL_L_UNIT", "LDL_HDL_RT_L_UNIT", "TTL_CHL_L_UNIT",
      "TRIGLY_L_UNIT", "LDL_DIR_LAST_DT", "LDL_CALC_LAST_DT", "HDL_LAST_DT", "VLDL_LAST_DT", "LDL_HDL_RT_LAST_DT", "TTL_CHL_LAST_DT",
      "TRIGLY_LAST_DT")
  )

  afterJoin = (df: DataFrame) => {

    val df1 = df.select(df("PAT_ID"), expr("stack(7, 'LDL_DIR_LAST', LDL_DIR_LAST, LDL_DIR_L_UNIT, LDL_DIR_LAST_DT," +
      "'LDL_CALC_LAST', LDL_CALC_LAST, LDL_CALC_L_UNIT, LDL_CALC_LAST_DT," +
      "'HDL_LAST', HDL_LAST, HDL_L_UNIT, HDL_LAST_DT," +
      "'VLDL_LAST', VLDL_LAST, VLDL_L_UNIT, VLDL_LAST_DT," +
      "'TTL_CHL_LAST', TTL_CHL_LAST, TTL_CHL_L_UNIT, TTL_CHL_LAST_DT," +
      "'LDL_HDL_RT_LAST', LDL_HDL_RT_LAST, LDL_HDL_RT_L_UNIT, LDL_HDL_RT_LAST_DT," +
      "'TRIGLY_LAST', TRIGLY_LAST, TRIGLY_L_UNIT, TRIGLY_LAST_DT) as (LOCALCODE, LOCALRESULT, LOCALUNITS, DATEAVAILABLE)"))
    df1.withColumn("LOCALUNITS", lower(df1("LOCALUNITS")))
      .filter("localresult is not null and dateavailable is not null and pat_id is not null")

  }

  map = Map(
    "DATASRC" -> literal("dm_cad"),
    "LABRESULTID" -> concatFrom(Seq("PAT_ID", "LOCALCODE", "LOCALUNITS", "DATEAVAILABLE"), delim = "_"),
    "PATIENTID" -> mapFrom("PAT_ID"),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "LOCALRESULT" -> mapFrom("LOCALRESULT"),
    "LOCALUNITS" -> mapFrom("LOCALUNITS"),
    "DATEAVAILABLE" -> mapFrom("DATEAVAILABLE"),
    "LABRESULT_DATE" -> mapFrom("DATEAVAILABLE")
  )

}

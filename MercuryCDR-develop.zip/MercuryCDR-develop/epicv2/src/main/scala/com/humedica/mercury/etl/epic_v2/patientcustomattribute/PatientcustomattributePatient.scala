package com.humedica.mercury.etl.epic_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col,expr}

import scala.collection.JavaConverters._

class PatientcustomattributePatient(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patient:epic_v2.patient.PatientPatreg")

  columnSelect = Map(
    "patient" -> List("CLIENT_DS_ID", "DATASRC", "PATIENTID")
  )

  afterJoin = (df: DataFrame) => {
    df.withColumn("ATTRIBUTE_TYPE_CUI", expr("case when CLIENT_DS_ID = 11110 then 'CH002788' when CLIENT_DS_ID = 10931 then 'CH002949' end"))
  }

  map = Map(
    "DATASRC" -> mapFrom("DATASRC"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ATTRIBUTE_VALUE" -> mapFrom("CLIENT_DS_ID"),
    "ATTRIBUTE_TYPE_CUI" -> mapFrom("ATTRIBUTE_TYPE_CUI")
  )

  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Patientcustomattribute").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*)
      .filter("patientid is not null")
      .distinct()
  }
}

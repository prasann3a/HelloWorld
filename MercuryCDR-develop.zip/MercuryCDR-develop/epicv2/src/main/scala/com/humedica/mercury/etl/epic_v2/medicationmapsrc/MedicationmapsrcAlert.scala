package com.humedica.mercury.etl.epic_v2.medicationmapsrc

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcAlert(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "alert",
    "cdr.map_predicate_values"
  )

  columnSelect = Map(
    "alert" -> List("ALERT_DESC", "PAT_ID", "PAT_CSN", "UPDATE_DATE", "MED_ALERT_TYPE_C")
  )

  beforeJoin = Map(
    "alert" -> ((df: DataFrame) => {
      val med_alert_type_c_col = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "ALERT",
                                            "ALLERGY", "ALERT", "MED_ALERT_TYPE_C")
      val fil = df.filter("(MED_ALERT_TYPE_C = '2' or MED_ALERT_TYPE_C in (" + med_alert_type_c_col + ")) " +
                                          "AND ALERT_DESC is NOT NULL " +
                                          "AND PAT_ID is NOT NULL " +
                                          "AND UPDATE_DATE is NOT NULL")
      val groups = Window.partitionBy(fil("PAT_ID"), fil("ALERT_DESC"), fil("PAT_CSN"), fil("UPDATE_DATE")).
                                      orderBy(fil("PAT_ID"), fil("ALERT_DESC"), fil("PAT_CSN"), fil("UPDATE_DATE").desc_nulls_last)
      val addColumn_df = fil.withColumn("rn", row_number.over(groups))
      addColumn_df.filter("rn = 1").drop("rn")
    })
  )

  map = Map(
    "DATASRC" -> literal("alert"),
    "LOCALDESCRIPTION" -> mapFrom("ALERT_DESC"),
    "LOCALMEDCODE" -> ((col:String, df:DataFrame) => df.withColumn(col, substring(df("ALERT_DESC"),0,100))),
    "LOCALNDC" -> nullValue()
  )


  afterMap = (df: DataFrame) => {
    val fil = df.filter("length(LOCALMEDCODE) <=100 ")
    val group_df = Window.partitionBy(fil("DATASRC"), fil("LOCALDESCRIPTION"), fil("LOCALMEDCODE"), fil("LOCALNDC"))
    val df1 = fil.withColumn("NO_NDC", sum(when(fil("LOCALNDC").isNull, 1).otherwise(0)).over(group_df))
                 .withColumn("HAS_NDC", sum(when(fil("LOCALNDC").isNull, 0).otherwise(1)).over(group_df))
                 .withColumn("NUM_RECS", count("*").over(group_df))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcAlert(cfg); val med_s = build(a, allColumns = true) ;

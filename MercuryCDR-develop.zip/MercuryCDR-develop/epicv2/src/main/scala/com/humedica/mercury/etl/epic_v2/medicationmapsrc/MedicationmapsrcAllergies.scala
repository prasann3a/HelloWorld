package com.humedica.mercury.etl.epic_v2.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Constants._
import scala.collection.JavaConverters._

class MedicationmapsrcAllergies(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "allergies",
    "zh_cl_elg",
    "zh_cl_elg_ndc_list",
    "cdr.map_predicate_values"
  )

  columnSelect = Map(
    "allergies" -> List("ALLERGEN_ID", "DESCRIPTION", "PAT_ID", "UPDATE_DATE", "DATE_NOTED", "ALRGY_ENTERED_DTTM", "STATUS"),
    "zh_cl_elg" -> List("ALLERGEN_ID"),
    "zh_cl_elg_ndc_list" -> List("ALLERGEN_ID", "MED_INTRCT_NDC")
  )

  beforeJoin = Map(
    "allergies" -> includeIf(
      "coalesce(DATE_NOTED ,ALRGY_ENTERED_DTTM ) IS NOT NULL " +
        "AND PAT_ID is NOT NULL " +
        "AND ALLERGEN_ID is NOT NULL " +
        "AND nvl(STATUS,'X') <> '2'")
  )

  join = (dfs: Map[String,DataFrame]) =>
    dfs("allergies")
      .join(dfs("zh_cl_elg")
        .join(dfs("zh_cl_elg_ndc_list"), Seq("ALLERGEN_ID"), "left_outer")
      ,Seq("ALLERGEN_ID"),"left_outer")

  map = Map(
    "DATASRC" -> literal("Allergies"),
    "LOCALMEDCODE" -> ((col: String, df: DataFrame) => {
      val list_drug = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "LOCALMEDCODE", "ALLERGY", "MEDORDERS", "DISPLAY_NAME")
      df.withColumn(col, when(df("ALLERGEN_ID").isin(list_drug: _*), trim(substring(df("DESCRIPTION"),1,100)))
        .otherwise(trim(substring(df("ALLERGEN_ID"), 1, 100))))
    }),
    "LOCALDESCRIPTION" -> mapFrom("DESCRIPTION"),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, normalizeNDC(df, "MED_INTRCT_NDC")))
  )

  mapExceptions = Map(
    ("H969755_EP2","LOCALNDC") -> nullValue(),
    ("H303173_EPIC_EL","LOCALNDC") -> nullValue(),
    ("H770494_EP2_EVERETT_V1","LOCALNDC") -> nullValue(),
    ("H827927_UPH_EP2", "LOCALNDC") -> nullValue(),
    ("H770494_EP2_PCL_EVRT_V1", "LOCALNDC") -> nullValue(),
    ("H831111_EP2_V1", "LOCALNDC") -> nullValue()
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PAT_ID"), df("LOCALMEDCODE"), df("UPDATE_DATE"))
      .orderBy(df("PAT_ID"), df("LOCALMEDCODE"), df("UPDATE_DATE").desc_nulls_last)
    val addColumn_df = df.withColumn("rn", row_number.over(groups))
    val filter_df = addColumn_df.filter("rn = 1").drop("rn")

    val group_df = Window.partitionBy(filter_df("DATASRC"), filter_df("LOCALMEDCODE"), filter_df("LOCALDESCRIPTION"), filter_df("LOCALNDC"))
    val df1 = filter_df.withColumn("NO_NDC", sum(when(filter_df("LOCALNDC").isNull, 1).otherwise(0)).over(group_df))
             .withColumn("HAS_NDC", sum(when(filter_df("LOCALNDC").isNull, 0).otherwise(1)).over(group_df))
      .withColumn("NUM_RECS", count("*").over(group_df))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcAllergies(cfg); val med_s = build(a, allColumns = true) ;

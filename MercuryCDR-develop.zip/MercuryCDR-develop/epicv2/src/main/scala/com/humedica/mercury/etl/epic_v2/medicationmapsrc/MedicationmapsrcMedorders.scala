package com.humedica.mercury.etl.epic_v2.medicationmapsrc

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcMedorders(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "zh_claritymed",
    "medorders",
    "cdr.map_predicate_values","zh_rx_ndc_code"
  )

  columnSelect = Map(
    "medorders" -> List("MEDICATION_ID", "NAME", "GENERIC_NAME", "DESCRIPTION", "GPI", "DISPLAY_NAME"),
    "zh_claritymed" -> List("MEDICATION_ID","RAW_11_DIGIT_NDC"),
    "zh_rx_ndc_code" -> List("MEDICATION_ID","NDC_CODE")
  )

  beforeJoin = Map(
    "medorders" -> ((df: DataFrame) => {
      val df1 = df.filter("nvl(MEDICATION_ID,'-1') != '-1'")
                  .groupBy("MEDICATION_ID", "NAME", "GENERIC_NAME", "DESCRIPTION", "GPI", "DISPLAY_NAME")
                  .agg(count("*").alias("CT"))
      val list_drug = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "LOCALMEDCODE",
        "RXORDER", "MEDORDERS", "DISPLAY_NAME")
      df1.withColumn("LOCALMEDCODE", when(df1("MEDICATION_ID").isin(list_drug:_*), trim(substring(coalesce(df1("DISPLAY_NAME"), df1("NAME"),df1("GENERIC_NAME"),df1("DESCRIPTION")),1,100)))
            .otherwise(df1("MEDICATION_ID")))
         .withColumn("LOCALDESCRIPTION", when(df1("MEDICATION_ID").isin(list_drug:_*), coalesce(df1("DISPLAY_NAME"), df1("NAME"),df1("GENERIC_NAME"),df1("DESCRIPTION")))
            .otherwise(coalesce(df1("NAME"), df1("GENERIC_NAME"),df1("DESCRIPTION"))))
    }),
    "zh_rx_ndc_code" -> ((df: DataFrame) => {
      df.withColumnRenamed("MEDICATION_ID", "MEDICATION_ID_ndc")
    })
  )

  join = (dfs: Map[String,DataFrame]) =>
    dfs("medorders")
      .join(dfs("zh_claritymed"),
    Seq("MEDICATION_ID"),"left_outer")

  joinExceptions = Map(
    "H770319_EP3_V1" -> ((dfs: Map[String, DataFrame]) => {
      dfs("medorders")
        .join(dfs("zh_rx_ndc_code"), dfs("medorders")("MEDICATION_ID") === dfs("zh_rx_ndc_code")("MEDICATION_ID_ndc"), "left_outer")
    })
  )

  map = Map(
    "DATASRC" -> literal("medorders"),
    "LOCALGENERIC" -> mapFrom("GENERIC_NAME"),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, trim(substring(df("RAW_11_DIGIT_NDC"), 1, 11)))),
    "NDC_SRC" -> literal("src"),
    "LOCALBRAND" -> nullValue(),
    "LOCALFORM" -> nullValue(),
    "LOCALSTRENGTH" -> nullValue()
  )

  afterMap = (df: DataFrame) => {
    val addColumn = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALNDC"), df("LOCALDESCRIPTION"), df("LOCALGENERIC"))
    val df1 = df.withColumn("NUM_RECS", sum("CT").over(addColumn))
      .withColumn("NO_NDC", sum(when(df("LOCALNDC").isNull, 1).otherwise(0)).over(addColumn))
      .withColumn("HAS_NDC", sum(when(df("LOCALNDC").isNull, 0).otherwise(1)).over(addColumn))
      .withColumn("LOCALGPI", min("GPI").over(addColumn))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }

  mapExceptions = Map(
    ("H770319_EP3_V1", "LOCALNDC") -> ((col: String, df: DataFrame) =>
      df.withColumn(col, trim(substring(df("NDC_CODE"), 1, 11))))
  )
}

//val a = new MedicationmapsrcMedorders(cfg); val med_s = build(a, allColumns = true) ;

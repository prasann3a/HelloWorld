package com.humedica.mercury.etl.epic_v2.labmapperdict

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.Constants._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

/**
  * Created by abendiganavale on 3/19/18.
  */
class LabmapperdictO2sats(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("cdr.map_observation",
    "temptablepatass:epic_v2.observation.ObservationTemptablepatass")

  columnSelect = Map(
    "cdr.map_observation" -> List("GROUPID", "LOCALCODE", "LOCAL_NAME","LOCALUNIT"),
    "temptablepatass" -> List("FLO_MEAS_ID")
  )

  beforeJoin = Map(
    "cdr.map_observation" -> includeIf("groupid = '" + config(GROUP) + "' and obstype = 'LABRESULT' and datasrc = 'patass'"),
    "temptablepatass" -> ((df: DataFrame) => {
      df.distinct
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("cdr.map_observation")
      .join(dfs("temptablepatass"), concat(lit(config(CLIENT_DS_ID) + ".pa."), dfs("temptablepatass")("FLO_MEAS_ID")) === dfs("cdr.map_observation")("LOCALCODE"), "inner")
  }

  map = Map(
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "LOCALDESC" -> mapFrom("LOCAL_NAME"),
    "LOCALNAME" -> mapFrom("LOCAL_NAME"),
    "LOCALUNITS" -> mapFrom("LOCALUNIT")
  )

}

// val x = new  LabmapperdictO2sats(cfg); val ld = build(x) ; ld.show ; ld.count

package com.humedica.mercury.etl.epic_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{lit, row_number, when}

class PatientcustomattributeCllqh(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("cl_lqh_1", "registry_data_info")

  columnSelect = Map(
    "cl_lqh_1" -> List("fileid", "sdoh_transport_yn", "sdoh_food_insec_yn", "record_id"),
    "registry_data_info" -> List("record_id", "networked_id")
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("cl_lqh_1")
      .join(dfs("registry_data_info"), Seq("record_id"), "inner")
  }

  afterJoin = (df: DataFrame) => {
    val df1 = df.withColumn("transport_yn", when(df("sdoh_transport_yn") === lit("Y"), lit("YES"))
      .when(df("sdoh_transport_yn") === lit("N"), lit("NO"))
      .otherwise(null))
    .withColumn("food_insec_yn", when(df("sdoh_food_insec_yn") === lit("Y"), lit("YES"))
      .when(df("sdoh_food_insec_yn") === lit("N"), lit("NO"))
      .otherwise(null))

    val fpiv = unpivot(Seq("transport_yn", "food_insec_yn"), Seq("CH002788", "CH002949"), typeColumnName = "cui")
    fpiv("value", df1)
  }

  map = Map(
    "DATASRC" -> literal("cl_lqh_1"),
    "PATIENTID" -> mapFrom("networked_id"),
    "ATTRIBUTE_VALUE" -> mapFrom("value"),
    "ATTRIBUTE_TYPE_CUI" -> mapFrom("cui"),
    "EFF_DATE" -> nullValue()
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID"), df("ATTRIBUTE_TYPE_CUI")).orderBy(df("fileid"))
    val addcol = df.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1 and ATTRIBUTE_VALUE is not null ").drop("rn")
  }
}

// val es = new PatientcustomattributeCllqh(cfg);
// val pc = build(es)

package com.humedica.mercury.etl.epic_v2.observation

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


/**
  * Created by ckatragadda on 01/28/2020.
  */
class ObservationSurghistory(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables=List("surghistory", "cdr.zcm_obstype_code")

  columnSelect = Map(
    "surghistory" -> List("PROC_CODE", "CONTACT_DATE", "PAT_ID", "PAT_ENC_CSN_ID", "FILEID"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "DATASRC", "OBSTYPE", "OBSCODE", "LOCALUNIT", "OBSTYPE_STD_UNITS")
  )

  beforeJoin = Map(

    "surghistory" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("PAT_ID"),df("CONTACT_DATE"),df("PROC_CODE")).orderBy(df("FILEID").desc_nulls_last)
      df.withColumn("rn", row_number.over(groups))
        .filter("rn = 1 and PAT_ID is not null and CONTACT_DATE is not null and PROC_CODE is not null").drop("rn")
    }),

    "cdr.zcm_obstype_code" -> ((df: DataFrame) => {
      df.filter("DATASRC = 'surghistory' and GROUPID='"+config(GROUP)+"'").drop("GROUPID")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("surghistory")
      .join(dfs("cdr.zcm_obstype_code"), concat(lit(config(CLIENT_DS_ID)+"."), dfs("surghistory")("PROC_CODE")) === dfs("cdr.zcm_obstype_code")("OBSCODE"), "inner")
  }

  map = Map(
    "DATASRC" -> literal("surghistory"),
    "ENCOUNTERID" -> mapFrom("PAT_ENC_CSN_ID"),
    "PATIENTID" -> mapFrom("PAT_ID"),
    "OBSDATE" -> mapFrom("CONTACT_DATE"),
    "LOCALCODE" -> mapFrom("PROC_CODE", prefix=config(CLIENT_DS_ID) + "."),
    "LOCALRESULT" -> mapFrom("PROC_CODE", prefix=config(CLIENT_DS_ID) + "."),
    "LOCAL_OBS_UNIT" -> mapFrom("LOCALUNIT"),
    "STD_OBS_UNIT" -> mapFrom("OBSTYPE_STD_UNITS")
  )

}

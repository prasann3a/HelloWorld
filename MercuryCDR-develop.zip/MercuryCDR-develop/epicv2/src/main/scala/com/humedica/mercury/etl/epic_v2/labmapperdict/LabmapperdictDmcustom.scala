package com.humedica.mercury.etl.epic_v2.labmapperdict

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame


class LabmapperdictDmcustom(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("dm_diabetes")

  afterJoin = (df: DataFrame) => {
    val session = Engine.spark
    import session.implicits._

    Seq("BUN_LAST",
     "CREAT_LAST",
     "CREAT_CLR_LAST",
     "HBA1C_LAST",
     "HDL_LAST",
     "LDL_CALC_LAST",
     "LDL_DIR_LAST",
     "LDL_HDL_RT_LAST",
     "POTASSIUM_LAST",
     "PROT_CR_RT_LAST",
     "TRIGLY_LAST",
     "TSH_LAST",
     "TTL_CHL_LAST",
     "UR_MALB_LAST",
     "UR_PROT_LAST",
     "VLDL_LAST").toDF("LOCALCODE")
  }

  map = Map(
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "LOCALNAME" -> mapFrom("LOCALCODE")
  )

}

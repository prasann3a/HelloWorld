package com.humedica.mercury.etl.epic_v2.procedure

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window

class ProcedureEncountervisit(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("encountervisit:epic_v2.clinicalencounter.ClinicalencounterTemptable", "cdr.map_custom_proc","cdr.map_predicate_values")

  columnSelect = Map(
    "encountervisit" -> List("PAT_ID","PAT_ENC_CSN_ID", "ARRIVALTIME", "ENC_TYPE_C", "APPT_PRC_ID"),
    "cdr.map_custom_proc" -> List("LOCALCODE", "DATASRC", "GROUPID","MAPPEDVALUE")
  )

  beforeJoin = Map(
    "encountervisit" -> ((df: DataFrame) => {
      val list_prc_id = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "LOCALCODE_APPT_CONCAT", "PROCEDUREDO", "ENCOUNTERVISIT", "APPT_PRC_ID")
      df.withColumn("LOCALCODE", concat_ws("", lit(config(CLIENT_DS_ID) + "."),
        when(concat_ws("",df("enc_type_c"), lit("."), df("appt_prc_id")).isin(list_prc_id: _*), concat_ws("",df("enc_type_c"), lit("."), df("appt_prc_id")))
          .otherwise(df("enc_type_c"))))
    }),
    "cdr.map_custom_proc" -> ((df: DataFrame) => {
      df.filter("GROUPID = '" + config(GROUP) + "' AND DATASRC = 'encountervisit'")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("encountervisit")
      .join(dfs("cdr.map_custom_proc"),Seq("LOCALCODE"),"inner")
  }

  map = Map(
    "DATASRC" -> literal("encountervisit"),
    "ENCOUNTERID" -> mapFrom("PAT_ENC_CSN_ID", nullIf = Seq("-1")),
    "PATIENTID" -> mapFrom("PAT_ID", nullIf = Seq("-1")),
    "PROCEDUREDATE" -> mapFrom("ARRIVALTIME"),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "CODETYPE" -> literal("CUSTOM"),
    "MAPPEDCODE" -> mapFrom("MAPPEDVALUE")
  )

  afterMap = (df:DataFrame) => {
    df.distinct()
  }

}
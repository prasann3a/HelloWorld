package com.humedica.mercury.etl.epic_v2.patientidentifier

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.row_number

class PatientidentifierPatxwalk(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("demographics")

  columnSelect = Map(
    "demographics" -> List("MEM_NUMBER", "PAT_ID", "PAYOR", "FILEID")
  )

  map = Map(
    "DATASRC" -> literal("demographics"),
    "IDTYPE" -> literal("MEMBERID"),
    "IDVALUE" -> mapFrom("MEM_NUMBER"),
    "PATIENTID" -> mapFrom("PAT_ID"),
    "ID_SUBTYPE" -> mapFrom("PAYOR")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID"), df("ID_SUBTYPE"), df("IDVALUE")).orderBy(df("FILEID").desc_nulls_last)
    val addColumn = df.withColumn("rn", row_number.over(groups))
    addColumn.filter("rn = 1 AND PATIENTID IS NOT NULL AND IDVALUE IS NOT NULL")
  }
}
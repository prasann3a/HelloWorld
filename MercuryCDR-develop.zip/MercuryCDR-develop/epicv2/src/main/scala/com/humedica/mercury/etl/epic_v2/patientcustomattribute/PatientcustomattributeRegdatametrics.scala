package com.humedica.mercury.etl.epic_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.Constants.{CLIENT_DS_ID, GROUPID}
import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.EntitySource
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{expr, lit, row_number, when}

class PatientcustomattributeRegdatametrics(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("reg_data_metrics", "registry_data_info", "cdr.map_predicate_values")

  columnSelect = Map(
    "reg_data_metrics" -> List("metrics_id", "metric_string_value", "record_id"),
    "registry_data_info" -> List("record_id", "networked_id", "record_creation_dt", "instant_of_upd_tm")
  )

  beforeJoin = Map(
    "cdr.map_predicate_values" -> ((df: DataFrame) => {
      df.filter("groupid='" + config(GROUPID) + "' AND data_src='ATTRIBUTE_FILTER_METRIC' AND entity='PATIENT_ATTRIBUTE' " +
        "AND table_name='REG_DATA_METRICS' AND column_name='METRICS_ID.ATTRIBUTE_TYPE_CUI' AND client_ds_id=" + config(CLIENT_DS_ID))
      df.select(expr("SUBSTR(column_value, 1, INSTR(column_value,'.') -1)").as("metrics_id")
        , expr("SUBSTR(column_value, INSTR(column_value,'.') + 1 )").as("attribute_type_cui")
      )
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("reg_data_metrics")
      .join(dfs("cdr.map_predicate_values"), Seq("metrics_id"), "inner")
      .join(dfs("registry_data_info"), Seq("record_id"), "inner")
  }

  map = Map(
    "DATASRC" -> literal("reg_data_metrics"),
    "PATIENTID" -> mapFrom("networked_id"),
    "ATTRIBUTE_VALUE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("metric_string_value") > lit("0"), lit("YES"))
        .otherwise(lit("NO")))
    }),
    "ATTRIBUTE_TYPE_CUI" -> mapFrom("attribute_type_cui"),
    "EFF_DATE" -> mapFrom("record_creation_dt")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID"), df("ATTRIBUTE_TYPE_CUI")).orderBy(df("instant_of_upd_tm").desc_nulls_last, df("record_id").desc_nulls_last)
    val addcol = df.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1 and ATTRIBUTE_VALUE is not null ").drop("rn")
  }
}

// val es = new PatientcustomattributeRegdatametrics(cfg);
// val pc = build(es)
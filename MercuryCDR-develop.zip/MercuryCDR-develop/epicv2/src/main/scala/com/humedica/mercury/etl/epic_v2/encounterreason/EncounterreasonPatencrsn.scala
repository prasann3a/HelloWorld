package com.humedica.mercury.etl.epic_v2.encounterreason

import com.humedica.mercury.etl.core.engine.{Engine,EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

/**
 * Auto-generated on 02/01/2017
 */


class EncounterreasonPatencrsn(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

      tables = List("pat_enc_rsn")

      beforeJoin = Map(
        "pat_enc_rsn" -> ((df: DataFrame) => {
          val groups = Window.partitionBy(df("PAT_ID"),df("PAT_ENC_CSN_ID"),df("ENC_REASON_NAME"),df("ENC_REASON_OTHER"),df("CONTACT_DATE")).orderBy(df("UPDATE_DATE").desc,df("LINE").asc,df("FILEID").desc)
          val df1 = df.withColumn("rn", row_number.over(groups))
          df1.filter("rn=1 and pat_id is not null and (enc_reason_name is not null or enc_reason_other is not null)").drop("rn")
        })
      )

      join = noJoin()

      map = Map(
        "DATASRC" -> literal("pat_enc_rsn"),
        "ENCOUNTERID" -> mapFrom("PAT_ENC_CSN_ID"),
        "PATIENTID" -> mapFrom("PAT_ID"),
        "REASONTIME" -> mapFrom("CONTACT_DATE"),
        "LOCALREASONTEXT" -> cascadeFrom(Seq("ENC_REASON_NAME", "ENC_REASON_OTHER"))
      )
  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Encounterreason").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*)
      .distinct
  }

 }
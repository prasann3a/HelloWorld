package com.humedica.mercury.etl.asent.microbioorder

import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Constants._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window


class MicrobioorderAsorders(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("AS_ORDERS", "AS_ZC_QO_CLASSIFICATION_DE", "AS_ZC_WHERE_PERFORMED_DE", "AS_ZC_ORDER_STATUS_DE"
                , "AS_ZH_SOURCE_DE", "cdr.map_predicate_values")

  columnSelect = Map(
    "AS_ORDERS" -> List("PATIENT_MRN", "ORDER_ITEM_ID", "ORDER_NAME", "CREATE_DATE", "WHERE_PERFORMED_ID"
      , "ORDER_STATUS_ID", "SOURCE_ID", "ENCOUNTER_ID", "SPECIMENTYPEDE", "LAST_UPDATED_DATE", "CLINICAL_DATETIME"
      , "CHILD_ORDER_ID", "DONEFUZZYSORTAS"),
    "AS_ZC_QO_CLASSIFICATION_DE" -> List("ENTRYNAME", "ID"),
    "AS_ZC_WHERE_PERFORMED_DE" -> List("ENTRYNAME", "ID"),
    "AS_ZC_ORDER_STATUS_DE" -> List("ENTRYNAME", "ID"),
    "AS_ZH_SOURCE_DE" -> List("ENTRYNAME", "ID")
  )

  beforeJoin = Map(
    "AS_ORDERS" -> ((df: DataFrame) => {
      val list_order_ids = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID),
        "AS_ORDERS", "MBORDER", "AS_ORDERS", "ORDER_ITEM_ID")
      val list_status_ids = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID),
        "AS_ORDERS", "MBORDER", "AS_ORDERS", "ORDER_STATUS_ID")

      val df2 = df.filter(" ORDER_ITEM_ID IN (" + list_order_ids + ") AND ORDER_STATUS_ID NOT IN (" + list_status_ids + ") AND nvl (date_format(DONEFUZZYSORTAS, 'YYYY-MM-DD'),'X') <> '1900-01-01' "
      )
      val groups = Window.partitionBy(df2("PATIENT_MRN"), df2("ENCOUNTER_ID"), df2("ORDER_ITEM_ID"))
        .orderBy(df2("LAST_UPDATED_DATE").desc_nulls_last, df2("CLINICAL_DATETIME").desc_nulls_last, df2("CHILD_ORDER_ID").desc_nulls_last)
      df2.withColumn("rn", row_number.over(groups))
        .filter("rn = 1 ")
        .drop("rn")
    }),

    "AS_ZC_QO_CLASSIFICATION_DE" -> ((df: DataFrame) => {
      df.withColumnRenamed("ENTRYNAME", "ENTRYNAME_ZC_QO")
    }),

    "AS_ZC_WHERE_PERFORMED_DE" -> ((df: DataFrame) => {
      df.withColumnRenamed("ENTRYNAME", "ENTRYNAME_PERF")
    }),

    "AS_ZC_ORDER_STATUS_DE" -> ((df: DataFrame) => {
      df.withColumnRenamed("ENTRYNAME", "ENTRYNAME_STATUS")
    }),

    "AS_ZH_SOURCE_DE" -> ((df: DataFrame) => {
      df.withColumnRenamed("ENTRYNAME", "ENTRYNAME_SOURCE")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("AS_ORDERS")
      .join(dfs("AS_ZC_QO_CLASSIFICATION_DE"), dfs("AS_ORDERS")("ORDER_ITEM_ID") === dfs("AS_ZC_QO_CLASSIFICATION_DE")("ID"), "left_outer")
      .join(dfs("AS_ZC_WHERE_PERFORMED_DE"), dfs("AS_ORDERS")("WHERE_PERFORMED_ID") === dfs("AS_ZC_WHERE_PERFORMED_DE")("ID"), "left_outer")
      .join(dfs("AS_ZC_ORDER_STATUS_DE"), dfs("AS_ORDERS")("ORDER_STATUS_ID") === dfs("AS_ZC_ORDER_STATUS_DE")("ID"), "left_outer")
      .join(dfs("AS_ZH_SOURCE_DE"), dfs("AS_ORDERS")("SOURCE_ID") === dfs("AS_ZH_SOURCE_DE")("ID"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("AS_ORDERS"),
    "PATIENTID" -> mapFrom("PATIENT_MRN"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTER_ID"),
    "MBPROCORDERID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat(df("PATIENT_MRN"), lit("_"), df("ENCOUNTER_ID"), lit("_"), df("ORDER_ITEM_ID")))
    }),
    "DATEORDERED" -> mapFrom("CREATE_DATE"),
    "MBORDER_DATE" -> mapFrom("CREATE_DATE"),
    "FACILITYID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("WHERE_PERFORMED_ID").isNotNull && df("WHERE_PERFORMED_ID") =!="0",
        concat(df("WHERE_PERFORMED_ID"), lit("-"), df("ENTRYNAME_PERF"))).otherwise(null))

    }),
    "LOCALORDERCODE" -> mapFrom("ORDER_ITEM_ID"),
    "LOCALORDERDESC" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(upper(df("ENTRYNAME_ZC_QO")), upper(df("ORDER_NAME"))))
    }),
    "LOCALSPECIMENSOURCE" -> mapFrom("SOURCE_ID"),
    "LOCALSPECIMENNAME" -> ((col: String, df: DataFrame) => {
      df.withColumn(col,upper(df("ENTRYNAME_SOURCE")))
    }),
    "LOCALORDERSTATUS" -> ((col: String, df: DataFrame) => {
    df.withColumn(col,upper(df("ENTRYNAME_STATUS")))
    })

  )

  afterMap = includeIf("PATIENTID is not null and LOCALORDERDESC is not null and MBORDER_DATE is not null")

}


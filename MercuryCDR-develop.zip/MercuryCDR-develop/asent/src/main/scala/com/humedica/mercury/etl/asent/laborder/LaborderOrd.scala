package com.humedica.mercury.etl.asent.laborder

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import org.apache.spark.sql.DataFrame
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._
import org.apache.spark.sql.expressions.Window

class LaborderOrd (config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("as_orders",
    "as_zc_qo_classification_de")

  columnSelect = Map(
    "as_orders" -> List("ORDER_ITEM_ID", "ENCOUNTER_ID", "PATIENT_MRN","CLINICAL_DATETIME",
      "ORDER_ITEM_ID","ORDER_STATUS_ID","CREATE_DATE","CHILD_ORDER_ID","ORDERING_PROVIDER_ID",
    "LAST_UPDATED_DATE"),
    "as_zc_qo_classification_de" -> List("ENTRYCODE", "ENTRYNAME", "ID", "CPT4CODE")
    )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("as_orders")
      .join(dfs("as_zc_qo_classification_de"), dfs("as_orders")("ORDER_ITEM_ID") === dfs("as_zc_qo_classification_de")("ID"), "left_outer")
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("CHILD_ORDER_ID")).orderBy(df("LAST_UPDATED_DATE").desc_nulls_last)
    val df2 = df.withColumn("rn", row_number.over(groups))
    df2.filter("rn=1 AND ORDER_STATUS_ID = '3' AND CPT4CODE like '8%'").drop("rn")
  }

  map = Map(
    "DATASRC" -> literal("orders"),
    "LABORDERID" -> mapFrom("ORDER_ITEM_ID"),
    "FACILITYID" -> nullValue(),
    "ENCOUNTERID" -> mapFrom("ENCOUNTER_ID"),
    "PATIENTID" -> mapFrom("PATIENT_MRN"),
    "DATEORDERED" -> mapFrom("CLINICAL_DATETIME"),
    "LOCALTESTNAME" -> mapFrom("ORDER_ITEM_ID"),
    "LOCALTESTDESCRIPTION" -> nullValue(),
    "STATUSCODE" -> mapFrom("ORDER_STATUS_ID"),
    "SPECIMINCOLLECTTIME" -> nullValue(),
    "LABORDER_DATE" -> cascadeFrom(Seq("CLINICAL_DATETIME","CREATE_DATE")),
    "MAPPEDTESTNAME" -> mapFrom("ENTRYCODE"),
    "MAPPEDTESTDESCRIPTION" -> mapFrom("ENTRYNAME"),
    "ORDERINGPROVIDERID" -> mapFrom("ORDERING_PROVIDER_ID",nullIf = Seq("0"))
  )

  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Laborder").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*)
      .distinct
  }

}

//val L =new LaborderOrd(cfg); val Lab = build(L,true); Lab.count
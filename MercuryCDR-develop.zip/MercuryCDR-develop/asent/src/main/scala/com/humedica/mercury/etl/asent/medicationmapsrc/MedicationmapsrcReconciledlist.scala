package com.humedica.mercury.etl.asent.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcReconciledlist(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "as_reconciled_list",
    "as_erx",
    "as_zc_medication_de"
  )

  columnSelect = Map(
    "as_reconciled_list" -> List("PATIENTID", "ENCOUNTERID", "ITEMTYPE", "RECORDEDDTTM", "ITEMCHILDID"),
    "as_erx" -> List("MED_DICT_DE", "NDC", "MEDICATION_NDC", "DRUG_DESCRIPTION", "DRUG_FORM", "DRUG_STRENGTH", "CHILD_MEDICATION_ID", "PATIENT_MRN", "THERAPY_END_DATE"),
    "as_zc_medication_de" -> List("GPI_TC3", "ID")
  )

  beforeJoin = Map(
    "as_reconciled_list" -> ((df: DataFrame) => {
      val reconciled_list_filter_df = df.filter("ITEMTYPE = 'ME' AND RECORDEDDTTM is not null")
      val group = Window.partitionBy(reconciled_list_filter_df("PATIENTID"), reconciled_list_filter_df("ENCOUNTERID"), reconciled_list_filter_df("ITEMCHILDID"), reconciled_list_filter_df("RECORDEDDTTM"))
        .orderBy(lit(1))
      reconciled_list_filter_df.withColumn("rn", row_number.over(group)).filter("rn = 1")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val filter_df = dfs("as_reconciled_list").join(dfs("as_erx"), dfs("as_reconciled_list")("ITEMCHILDID") === dfs("as_erx")("CHILD_MEDICATION_ID"), "inner")
      .join(dfs("as_zc_medication_de"), dfs("as_erx")("MED_DICT_DE") === dfs("as_zc_medication_de")("ID"), "inner")

    filter_df.filter("PATIENT_MRN is not null AND (RECORDEDDTTM > THERAPY_END_DATE OR THERAPY_END_DATE is null)")
  }

  map = Map(
    "DATASRC" -> literal("reconciled_list"),
    "LOCALMEDCODE" -> mapFrom("MED_DICT_DE"),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, coalesce(df("NDC"), df("MEDICATION_NDC")))),
    "LOCALDESCRIPTION" ->mapFrom("DRUG_DESCRIPTION"),
    "LOCALGPI" -> mapFrom("GPI_TC3"),
    "LOCALFORM" -> mapFrom("DRUG_FORM"),
    "LOCALSTRENGTH" -> mapFrom("DRUG_STRENGTH")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALNDC"), df("LOCALDESCRIPTION"), df("LOCALGPI"), df("LOCALFORM"), df("LOCALSTRENGTH"))
    val df1 = df.withColumn("NUM_RECS", count("*").over(groups))
      .withColumn("NO_NDC", sum(when(df("LOCALNDC").isNull, 1).otherwise(0)).over(groups))
      .withColumn("HAS_NDC", sum(when(df("LOCALNDC").isNull, 0).otherwise(1)).over(groups))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcReconciledlist(cfg); val med_s = build(a, allColumns = true) ;

package com.humedica.mercury.etl.asent.insurance

import org.apache.spark.sql.DataFrame
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._

/**
  * Created by vadive1 on 02/22/21.
  */

class InsuranceGtt(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

    tables = List(
      "ie:asent.insurance.InsuranceEncounters"
      ,"as_zc_insurance_class_de"
      ,"zc_financial_class_de"
    )

    columnSelect = Map(
      "ie" -> List("DATASRC", "FACILITYID", "ENCOUNTERID", "PATIENTID", "INS_TIMESTAMP", "INSURANCEORDER", "PAYORCODE", "PAYORNAME", "PLANCODE",
        "PLANNAME", "GROUPNBR", "POLICYNUMBER"),
      "as_zc_insurance_class_de" -> List("ID", "ENTRYCODE"),
      "zc_financial_class_de" -> List("INS_CODE", "INS_CLASS")
    )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("ie")
      .join(dfs("as_zc_insurance_class_de"), dfs("ie")("PAYORCODE") === dfs("as_zc_insurance_class_de")("id"),"left_outer")
      .join(dfs("zc_financial_class_de"), dfs("as_zc_insurance_class_de")("ENTRYCODE") === dfs("zc_financial_class_de")("INS_CODE") ,"left_outer")
  }

    map = Map(
      "DATASRC" -> literal("encounters"),
      "INS_TIMESTAMP" -> mapFrom("INS_TIMESTAMP"),
      "PATIENTID" -> mapFrom("PATIENTID"),
      "FACILITYID" -> mapFrom("FACILITYID"),
      "GROUPNBR" -> mapFrom("GROUPNBR"),
      "POLICYNUMBER" -> mapFrom("POLICYNUMBER"),
      "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
      "PAYORCODE" -> mapFrom("PAYORCODE"),
      "PAYORNAME" -> mapFrom("PAYORNAME"),
      "PLANCODE" -> mapFrom("PLANCODE"),
      "PLANNAME" -> mapFrom("PLANNAME"),
      "INSURANCEORDER" -> mapFrom("INSURANCEORDER"),
      "PLANTYPE" -> mapFrom("INS_CLASS")
    )


  }

//val in = new InsuranceGtt(cfg); val Ins = build(in,true)
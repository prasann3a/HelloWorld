package com.humedica.mercury.etl.asent.immunization

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.{Engine,EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.Constants._
import org.apache.spark.sql.expressions.Window
import scala.collection.JavaConverters._

class ImmunizationImmunizations(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("as_zc_medication_de",
    "as_immunizations",
    "as_zc_route_of_admin_de")

  columnSelect = Map(
    "as_zc_medication_de" -> List("GPI_TC3", "ID", "NDC","ROUTEOFADMINDE"),
    "as_immunizations" -> List("MRN", "DATE_TO_ADMINISTER", "WHO_ADMINISTERED", "ROUTE_OF_ADMIN",
      "LAST_UPDATED_DATE", "MEDICATION_ID", "IMMUNIZATION_DESCRIPTION", "MEDICATION_NDC", "IMMUNIZATION_ID", "IMMUNIZATION_STATUS"),
    "as_zc_route_of_admin_de" -> List("ID", "ENTRYNAME")
  )

  beforeJoin = Map(
    "as_immunizations" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("IMMUNIZATION_ID"), df("MRN"), df("MEDICATION_ID")).orderBy(df("LAST_UPDATED_DATE").desc_nulls_last)
      val addColumn = df.withColumn("rn", row_number.over(groups))
      addColumn.filter("rn = 1 AND IMMUNIZATION_STATUS != '5'").drop("rn")
    }),
    "as_zc_route_of_admin_de" -> ((df: DataFrame) => {
      df.withColumnRenamed("ID","RTID")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("as_immunizations")
      .join(dfs("as_zc_medication_de"), dfs("as_zc_medication_de")("id") === dfs("as_immunizations")("medication_id"), "left_outer")
      .join(dfs("as_zc_route_of_admin_de"), dfs("as_zc_route_of_admin_de")("RTID") === dfs("as_zc_medication_de")("ROUTEOFADMINDE"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("immunizations"),
    "PATIENTID" -> mapFrom("MRN"),
    "LOCALDEFERREDREASON" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(lower(df("DATE_TO_ADMINISTER")).like("%decline%"), lit("D"))
        .when(lower(df("DATE_TO_ADMINISTER")).like("%refuse%"), lit("D"))
        .when(lower(df("DATE_TO_ADMINISTER")).like("%immune%"), lit("I"))
        .when(lower(df("DATE_TO_ADMINISTER")).like("%disease%"), lit("I"))
        .when(lower(df("DATE_TO_ADMINISTER")).like("%hospital%"), lit("M"))
        .otherwise(null))
    }),
    "LOCALGPI" -> mapFrom("GPI_TC3"),
    "LOCALPATREPORTEDFLG" -> ((col, df) => df.withColumn(col, when(df("WHO_ADMINISTERED").notEqual(0), lit("Y")).otherwise(lit("N")))),
    "LOCALROUTE" -> mapFrom("ENTRYNAME"),
    "ADMINDATE" -> ((col: String, df: DataFrame) => {
      //Some pre-processing for DATE_TO_ADMINISTER3 to throw out trailing non-date characters 
      val df_tmp = df.withColumn("DATE_TO_ADMINISTER3_tmp", regexp_extract(regexp_replace(df("DATE_TO_ADMINISTER"), "[\\.|-]", "/"), "^([0-9/]+)", 1))
      val df1 = df_tmp
        //For dates like "Oct 17 2000"
        .withColumn("DATE_TO_ADMINISTER1", when(lower(df_tmp("DATE_TO_ADMINISTER")).rlike("^\\p{Alpha}"), substring(df_tmp("DATE_TO_ADMINISTER"), 1, 11)))
        //For dates like "06May2013" and "25 Jan 2013"
        .withColumn("DATE_TO_ADMINISTER2", substring(translate(df_tmp("DATE_TO_ADMINISTER"), " ", ""), 1, 9))
        //For dates like "6-25-10", "08.31.10", "06.26/2002"; 
        .withColumn("DATE_TO_ADMINISTER3", substring(df_tmp("DATE_TO_ADMINISTER3_tmp"), 1, 10))
        .withColumn("DATE_TO_ADMINISTER4", substring(regexp_replace(df_tmp("DATE_TO_ADMINISTER"), "[\\.|/-]", ""), 1, 8))
        .withColumn("DATE_TO_ADMINISTER5", substring(regexp_replace(df_tmp("DATE_TO_ADMINISTER"), "[\\.|/-]", ""), 1, 6))
      val df2 = safe_to_date(df1, "DATE_TO_ADMINISTER1", "DATE_TO_ADMINISTER1_safe", "MMM dd yyyy", 0)
      val df3 = safe_to_date(df2, "DATE_TO_ADMINISTER2", "DATE_TO_ADMINISTER2_safe", "ddMMMyyyy", 0)
      val df4 = safe_to_date(df3, "DATE_TO_ADMINISTER3", "DATE_TO_ADMINISTER3_safe", "MM/dd/yy", 0)
      val df5 = safe_to_date(df4, "DATE_TO_ADMINISTER4", "DATE_TO_ADMINISTER4_safe", "MMddyy", 0)
      val df6 = safe_to_date(df5, "DATE_TO_ADMINISTER5", "DATE_TO_ADMINISTER5_safe", "MMddyy", 0)
      val df7 = df6.withColumn("date_coalesce", coalesce(df6("DATE_TO_ADMINISTER1_safe"), df6("DATE_TO_ADMINISTER2_safe"), df6("DATE_TO_ADMINISTER3_safe"), df6("DATE_TO_ADMINISTER4_safe"), df6("DATE_TO_ADMINISTER5_safe")))
      val df8 = df7.withColumn("date_output", when(df7("date_coalesce").between(to_timestamp(lit("19000101"), "yyyyMMdd"), current_timestamp()), df7("date_coalesce")).otherwise(null))
      df8.withColumn(col, when(df8("date_output").rlike("^[0-9]{4}\\-[0-9]{2}\\-[0-9]{2} [0-9]{2}[:]{1}[0-9]{2}[:]{1}[0-9]{2}$"), df8("date_output")).otherwise(null))
    }),
    "DOCUMENTEDDATE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, from_unixtime(unix_timestamp(df("LAST_UPDATED_DATE"))))
    }),
    "LOCALIMMUNIZATIONCD" -> mapFrom("MEDICATION_ID"),
    "LOCALIMMUNIZATIONDESC" -> mapFrom("IMMUNIZATION_DESCRIPTION"),
    "LOCALNDC" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(when(length(regexp_replace(df("MEDICATION_NDC"), "0", "")) === 0, null).otherwise(df("MEDICATION_NDC")),
        when(length(regexp_replace(df("NDC"), "0", "")) === 0, null).otherwise(df("NDC"))))
    })
  )
   afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Immunization").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*)
      .distinct
  }
}
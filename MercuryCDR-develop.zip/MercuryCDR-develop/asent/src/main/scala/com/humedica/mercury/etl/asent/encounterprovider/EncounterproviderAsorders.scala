package com.humedica.mercury.etl.asent.encounterprovider

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.Constants._


class EncounterproviderAsorders(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("as_orders", "cdr.map_predicate_values")

  columnSelect = Map(
    "as_orders" -> List("CLINICAL_DATETIME", "APPROVING_PROVIDER_ID", "PATIENT_MRN", "ENCOUNTER_ID", "LAST_UPDATED_DATE")
  )

  beforeJoin = Map(
    "as_orders" -> ((df: DataFrame) => {
      val excl_encprov = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "AS_ORDERS", "ENCOUNTERPROVIDER", "AS_ORDERS", "APPROVING_PROVIDER_ID")
      val fil = if (excl_encprov == "'N'") df.filter("1=0") else df 
      val groups = Window.partitionBy(fil("ENCOUNTER_ID"), fil("APPROVING_PROVIDER_ID")).orderBy(fil("CLINICAL_DATETIME").desc_nulls_last, fil("LAST_UPDATED_DATE").desc_nulls_last)
      fil.withColumn("rn", row_number.over(groups)).filter("rn = 1").drop("rn")
    })
  )

  beforeJoinExceptions = Map(
    Seq("H319046_AS_ENT","H053731_AS_ENT") -> Map(
      "as_orders" -> ((df: DataFrame) => {
        val excl_encprov = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "AS_ORDERS", "ENCOUNTERPROVIDER", "AS_ORDERS", "APPROVING_PROVIDER_ID")
        if (excl_encprov == "'N'") df.filter("1=0") else df
      })
    )
  )
  
  join = noJoin()



  map = Map(
    "DATASRC" -> literal("as_orders"),
    "ENCOUNTERTIME" -> mapFrom("CLINICAL_DATETIME"),
    "PROVIDERID" -> mapFrom("APPROVING_PROVIDER_ID", nullIf = Seq("0")),
    "PATIENTID" -> mapFrom("PATIENT_MRN"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTER_ID"),
    "PROVIDERROLE" -> literal("Approving provider")
  )

  afterMap = (df: DataFrame) => {
    df.filter("ENCOUNTERTIME is not null and PATIENTID is not null and PROVIDERID is not null")
  }

  afterMapExceptions = Map(
    (Seq("H319046_AS_ENT","H053731_AS_ENT"), (df: DataFrame) => {
      val groups = Window.partitionBy(df("ENCOUNTERID"), df("PROVIDERID")).orderBy(df("CLINICAL_DATETIME").desc_nulls_last)
      df.withColumn("rn", row_number.over(groups))
        .filter("rn = 1 and ENCOUNTERTIME is not null and PATIENTID is not null and PROVIDERID is not null")
        .drop("rn")
    })
  )
}
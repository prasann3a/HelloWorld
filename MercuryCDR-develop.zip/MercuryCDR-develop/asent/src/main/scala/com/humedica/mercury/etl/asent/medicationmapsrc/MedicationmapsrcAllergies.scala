package com.humedica.mercury.etl.asent.medicationmapsrc

import com.humedica.mercury.etl.core.engine.Constants.CLIENT_DS_ID
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import scala.collection.JavaConverters._

class MedicationmapsrcAllergies(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "as_allergies",
    "as_zc_allergen_de",
    "as_zc_medication_allergy_de",
    "as_zc_medication_de"
  )

  columnSelect = Map(
    "as_allergies" -> List("MEDICATION_ALLERGY_ID", "NON_MEDICATION_ALLERGY_ID", "ALLERGY_STATUS_ID"),
    "as_zc_allergen_de" -> List("ENTRYNAME", "ID"),
    "as_zc_medication_allergy_de" -> List("ENTRYNAME", "ID", "MEDDICTDE"),
    "as_zc_medication_de" -> List("NDC", "ID")
  )

  beforeJoin = Map(
    "as_allergies" -> includeIf(
      "ALLERGY_STATUS_ID != '4'")
  )

  join = (dfs: Map[String, DataFrame]) => {
    val as_zc_med_allergy_de_df = table("as_zc_medication_allergy_de").withColumnRenamed("ENTRYNAME", "AS_ZC_MED_ALLERGY_ENTRYNAME")
      .withColumnRenamed("ID", "AS_ZC_MED_ALLERGY_ID")
    val as_zc_med_de_df = table("as_zc_medication_de").withColumnRenamed("ID", "AS_ZC_MED_ID")

    dfs("as_allergies").join(dfs("as_zc_allergen_de"), dfs("as_allergies")("NON_MEDICATION_ALLERGY_ID") === dfs("as_zc_allergen_de")("ID"), "left_outer")
      .join(as_zc_med_allergy_de_df, dfs("as_allergies")("MEDICATION_ALLERGY_ID") === as_zc_med_allergy_de_df("AS_ZC_MED_ALLERGY_ID"), "left_outer")
      .join(as_zc_med_de_df, as_zc_med_de_df("AS_ZC_MED_ID") === as_zc_med_allergy_de_df("MEDDICTDE"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("allergies"),
    "LOCALNDC" -> mapFrom("NDC"),
    "LOCALMEDCODE" -> ((col, df) => df.withColumn(col, when(df("MEDICATION_ALLERGY_ID").cast("String") =!= 0, substring(concat(lit(config(CLIENT_DS_ID)), lit("."), df("MEDICATION_ALLERGY_ID")),1,100))
      .otherwise(substring(concat(lit("n."), df("NON_MEDICATION_ALLERGY_ID").cast("String")), 1, 100)))),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, when(df("MEDICATION_ALLERGY_ID").cast("String") =!= 0, df("AS_ZC_MED_ALLERGY_ENTRYNAME"))
      .otherwise(df("ENTRYNAME"))))
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("DATASRC"), df("LOCALMEDCODE"), df("LOCALDESCRIPTION"), df("LOCALNDC"))
    val df1 = df.withColumn("NO_NDC", count("*").over(groups))
      .withColumn("HAS_NDC", lit(0))
      .withColumn("NUM_RECS", count("*").over(groups))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcAllergies(cfg); val med_s = build(a, allColumns = true) ;

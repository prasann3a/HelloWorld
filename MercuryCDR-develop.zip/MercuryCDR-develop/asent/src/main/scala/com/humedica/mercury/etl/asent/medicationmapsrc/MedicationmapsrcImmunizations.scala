package com.humedica.mercury.etl.asent.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{when, _}

import scala.collection.JavaConverters._

class MedicationmapsrcImmunizations(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "as_immunizations",
    "as_zc_medication_de"
  )

  columnSelect = Map(
    "as_immunizations" -> List("MEDICATION_ID", "IMMUNIZATION_DESCRIPTION", "IMMUNIZATION_STATUS", "MEDICATION_NDC"),
    "as_zc_medication_de" -> List("NDC", "ID")
  )

  beforeJoin = Map(
    "as_immunizations" -> includeIf(
      "IMMUNIZATION_STATUS != '5'" +
        "AND (length(nvl(MEDICATION_NDC,'x'))<=11 )")
  )

  join = (dfs: Map[String,DataFrame]) =>
    dfs("as_immunizations")
      .join(dfs("as_zc_medication_de"), dfs("as_immunizations")("MEDICATION_ID") === dfs("as_zc_medication_de")("ID"), "left_outer")

  map = Map(
    "DATASRC" -> literal("immunizations"),
    "LOCALMEDCODE" -> mapFrom("MEDICATION_ID"),
    "LOCALDESCRIPTION" -> mapFrom("IMMUNIZATION_DESCRIPTION"),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, coalesce(when(regexp_replace(df("MEDICATION_NDC"), "0+","") === "", lit(null))
      .otherwise(df("MEDICATION_NDC")),
      when(regexp_replace(df("NDC"), "0+","") === "", lit(null))
        .otherwise(df("NDC")))))
  )

  afterMap = (df: DataFrame) => {
    val group = Window.partitionBy(df("DATASRC"), df("LOCALMEDCODE"), df("LOCALDESCRIPTION"), df("LOCALNDC"))
    val df1 = df.withColumn("NO_NDC", count("*").over(group))
      .withColumn("HAS_NDC", lit(0))
      .withColumn("NUM_RECS", count("*").over(group))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcImmunizations(cfg); val med_s = build(a, allColumns = true) ;

package com.humedica.mercury.etl.asent.patientcustomattribute

import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col

import scala.collection.JavaConverters._

class PatientcustomattributePatient(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patient:asent.patient.PatientPatdem")

  columnSelect = Map(
    "patient" -> List("CLIENT_DS_ID", "DATASRC", "PATIENTID")
  )

  map = Map(
    "DATASRC" -> mapFrom("DATASRC"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ATTRIBUTE_VALUE" -> mapFrom("CLIENT_DS_ID"),
    "ATTRIBUTE_TYPE_CUI" -> literal("CH002786")
  )

  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Patientcustomattribute").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*)
      .filter("patientid is not null")
      .distinct()
  }
}

package com.humedica.mercury.etl.asent.patientdetail

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class PatientdetailEthnicity(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {
  tables = List("as_patdem")

  columnSelect = Map(
    "as_patdem" -> List("PATIENT_MRN", "LAST_UPDATED_DATE", "ETHNICITYDE", "RACE_ID", "PATIENT_LAST_NAME", "PATIENT_FIRST_NAME")
  )

  beforeJoin = Map(
    "as_patdem" -> ((df: DataFrame) => {
      val df1 = df.withColumn("ETHNICITY_FIL", when(df("ETHNICITYDE") === "0", null).otherwise(df("ETHNICITYDE")))
        .withColumn("RACE_FIL", when(df("RACE_ID") === "0", null).otherwise(df("RACE_ID")))
      val addColumn = df1.withColumn("ETHNICITY", coalesce(df1("ETHNICITY_FIL"), concat(lit("r."), df1("RACE_FIL"))))
      val groups = Window.partitionBy(addColumn("PATIENT_MRN"), coalesce(addColumn("ETHNICITY_FIL"), addColumn("RACE_FIL")))
        .orderBy(df("LAST_UPDATED_DATE").desc_nulls_last)
      addColumn.withColumn("rn", row_number.over(groups))
        .filter("rn=1 and ETHNICITY is not null")
    })
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> literal("patdem"),
    "PATIENTID" -> mapFrom("PATIENT_MRN"),
    "PATDETAIL_TIMESTAMP" -> mapFrom("LAST_UPDATED_DATE"),
    "PATIENTDETAILTYPE" -> literal("ETHNICITY"),
    "LOCALVALUE" -> mapFrom("ETHNICITY", prefix = config(CLIENT_DS_ID) + ".")
  )

  afterMap = (df: DataFrame) => {
    df.filter("length(PATIENT_MRN) > 0 and (not " +
      "((PATIENT_LAST_NAME like '*%' and PATIENT_FIRST_NAME is null)" +
      "or rlike(upper(PATIENT_LAST_NAME), '(^TEST |TEST$|ZZTEST)') " +
      "or rlike(upper(PATIENT_FIRST_NAME), 'TEST')) " +
      "or upper(PATIENT_LAST_NAME) = 'TEST')")
  }
}

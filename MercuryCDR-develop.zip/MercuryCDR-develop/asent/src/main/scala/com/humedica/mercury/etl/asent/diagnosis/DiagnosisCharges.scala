package com.humedica.mercury.etl.asent.diagnosis

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.Engine
import scala.collection.JavaConverters._

class DiagnosisCharges(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("as_charges", "as_zc_icd9_diagnosis_de", "cdr.map_predicate_values")

  columnSelect = Map(
    "as_charges" -> List("BILLING_LOCATION_ID", "ENCOUNTER_DATE_TIME", "LINKED_ICD9_ID", "PATIENT_MRN",
      "CHARGE_ID", "ENCOUNTER_ID", "ICD9DIAGNOSISCODE", "ICD10DIAGNOSISCODE", "ICD10_CODE", "LAST_UPDATED_DATE"),
    "as_zc_icd9_diagnosis_de" -> List("ENTRYCODE", "ID")
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("as_charges")
      .join(dfs("as_zc_icd9_diagnosis_de"), dfs("as_zc_icd9_diagnosis_de")("ID") === dfs("as_charges")("LINKED_ICD9_ID"), "left_outer")
  }


  afterJoin = (df: DataFrame) => {
    val addColumn = df.withColumn("ICD9", coalesce(when(df("LINKED_ICD9_ID") =!= lit("0"), df("LINKED_ICD9_ID")).otherwise(null), df("ICD9DIAGNOSISCODE")))
    val groups = Window.partitionBy(addColumn("PATIENT_MRN"), addColumn("ENCOUNTER_DATE_TIME"), addColumn("ENCOUNTER_ID"), addColumn("ICD9"),
      addColumn("ICD10_CODE"), addColumn("ICD10DIAGNOSISCODE")).orderBy(addColumn("LAST_UPDATED_DATE").desc_nulls_last)
    val addColumn2 = addColumn.withColumn("rn", row_number.over(groups))
    val pivcodetype = unpivot(
      Seq("ICD10_CODE", "ICD9", "ICD10DIAGNOSISCODE"),
      Seq("ICD10", "ICD9", "ICD10_dx"), typeColumnName = "ICD_CODE_TYPE")

    val pivcode = pivcodetype("ICD_CODE_VALUE", addColumn2)

    pivcode.repartition(1000).withColumn("LOCALDIAGNOSIS", pivcode("ICD_CODE_VALUE"))
      .withColumn("CODETYPE",
        when(pivcode("ICD_CODE_TYPE") === lit("ICD10_dx"), lit("ICD10")).otherwise(pivcode("ICD_CODE_TYPE")))
      .withColumn("MAPPEDDIAGNOSIS",
        when(pivcode("ICD_CODE_TYPE") === lit("ICD9"), coalesce(pivcode("ENTRYCODE"), pivcode("ICD_CODE_VALUE")))
          .otherwise(pivcode("ICD_CODE_VALUE")))
  }

  afterJoinExceptions = Map(
    Seq("H319046_AS_ENT","H053731_AS_ENT") -> ((df: DataFrame) => {
      val addColumn = df.withColumn("ICD9", coalesce(when(df("LINKED_ICD9_ID") =!= lit("0"), df("LINKED_ICD9_ID")).otherwise(null), df("ICD9DIAGNOSISCODE")))

      val pivcodetype = unpivot(
        Seq("ICD10_CODE", "ICD9", "ICD10DIAGNOSISCODE"),
        Seq("ICD10", "ICD9", "ICD10_dx"), typeColumnName = "ICD_CODE_TYPE", includeNulls = true)

      val pivcode = pivcodetype("ICD_CODE_VALUE", addColumn)

      pivcode.repartition(1000).withColumn("LOCALDIAGNOSIS", pivcode("ICD_CODE_VALUE"))
        .withColumn("CODETYPE",
          when(pivcode("ICD_CODE_TYPE") === lit("ICD10_dx"), lit("ICD10")).otherwise(pivcode("ICD_CODE_TYPE")))
        .withColumn("MAPPEDDIAGNOSIS",
          when(pivcode("ICD_CODE_TYPE") === lit("ICD9"), coalesce(pivcode("ENTRYCODE"), pivcode("ICD_CODE_VALUE")))
            .otherwise(pivcode("ICD_CODE_VALUE")))
    })
  )


  map = Map(
    "DATASRC" -> literal("charges"),
    "PATIENTID" -> mapFrom("PATIENT_MRN"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTER_ID"),
    "DX_TIMESTAMP" -> mapFrom("ENCOUNTER_DATE_TIME")
  )
  
  afterMap = (df: DataFrame) => {
    val drop_diag = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "AS_ENT", "DIAGNOSIS", "DIAGNOSIS", "LOCALDIAGNOSIS")
    val ct_window = Window.partitionBy(df("PATIENTID"), df("DX_TIMESTAMP"), df("rn"))
    val fil = df.withColumn("ICD9_CT", sum(when(df("CODETYPE") === lit("ICD9"), 1).otherwise(0)).over(ct_window))
      .withColumn("ICD10_CT", sum(when(df("CODETYPE") === lit("ICD10"), 1).otherwise(0)).over(ct_window))
    val icdfil = fil.withColumn("drop_icd9s",
      when(lit("'Y'") === drop_diag && expr("DX_TIMESTAMP >= from_unixtime(unix_timestamp(\"20151001\",\"yyyyMMdd\"))"),
        when(fil("ICD9_CT").gt(lit(0)) && fil("ICD10_CT").gt(lit(0)), lit("1")).otherwise(lit("0"))).otherwise(lit("0")))
      .withColumn("drop_icd10s",
        when(lit("'Y'") === drop_diag && expr("DX_TIMESTAMP < from_unixtime(unix_timestamp(\"20151001\",\"yyyyMMdd\"))"),
          when(fil("ICD9_CT").gt(lit(0)) && fil("ICD10_CT").gt(lit(0)), lit("1")).otherwise(lit("0"))).otherwise(lit("0")))
    val rnfil = icdfil.filter("rn = 1 AND DX_TIMESTAMP IS NOT NULL AND PATIENTID IS NOT NULL and LOCALDIAGNOSIS is not null " +
      "and ((codetype = 'ICD9' and drop_icd9s = '0') or (codetype = 'ICD10' and drop_icd10s = '0'))")
    val cols = Engine.schema.getStringList("Diagnosis").asScala.map(_.split("-")(0).toUpperCase())
    rnfil.select(cols.map(col): _*).distinct
  }

  afterMapExceptions = Map(
    (Seq("H319046_AS_ENT","H053731_AS_ENT"), (df: DataFrame) => {
      val groups = Window.partitionBy(df("PATIENTID"), df("ENCOUNTERID"), df("LOCALDIAGNOSIS"), df("DX_TIMESTAMP")).orderBy(df("LAST_UPDATED_DATE").desc_nulls_last)
      val addColumn = df.withColumn("rn", row_number.over(groups))
      addColumn.filter(" rn =1 and LOCALDIAGNOSIS IS NOT NULL AND MAPPEDDIAGNOSIS IS NOT NULL").drop(addColumn("rn"))
    })
  )
  
}

//val d =new DiagnosisCharges(cfg); val dia =build(d,true)
package com.humedica.mercury.etl.asent.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcErx(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "as_erx",
    "as_zc_medication_de"
  )

  columnSelect = Map(
    "as_erx" -> List("MED_DICT_DE", "MEDICATION_BRAND", "DRUG_DESCRIPTION", "DRUG_FORM", "DRUG_STRENGTH", "MEDICATION_NDC"),
    "as_zc_medication_de" -> List("NDC", "ID")
  )

  join = (dfs: Map[String,DataFrame]) =>
    dfs("as_erx")
      .join(dfs("as_zc_medication_de"), dfs("as_erx")("MED_DICT_DE") === dfs("as_zc_medication_de")("ID"),"left_outer")

  map = Map(
    "DATASRC" -> literal("erx"),
    "LOCALMEDCODE" -> mapFrom("MED_DICT_DE"),
    "LOCALNDC" -> ((col, df) => df.withColumn(col,when(df("NDC").isNotNull, substring(df("NDC"), 1, 11))
      .otherwise(substring(df("MEDICATION_NDC"), 1, 11)))),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, lower(df("DRUG_DESCRIPTION")))),
    "LOCALBRAND" -> mapFrom("MEDICATION_BRAND"),
    "LOCALGENERIC" -> mapFrom("DRUG_DESCRIPTION"),
    "LOCALGPI" -> nullValue(),
    "LOCALFORM" -> mapFrom("DRUG_FORM"),
    "LOCALSTRENGTH" -> mapFrom("DRUG_STRENGTH")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALNDC"), df("DRUG_DESCRIPTION"), df("LOCALFORM"), df("LOCALSTRENGTH"), df("LOCALBRAND"))
    val df1 = df.withColumn("NO_NDC", sum(when(substring(df("MEDICATION_NDC"), 1,11).isNull, 1).otherwise(0)).over(groups))
      .withColumn("HAS_NDC", sum(when(substring(df("MEDICATION_NDC"), 1,11).isNull, 0).otherwise(1)).over(groups))
      .withColumn("NUM_RECS", count("*").over(groups))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcErx(cfg); val med_s = build(a, allColumns = true) ;

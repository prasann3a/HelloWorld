package com.humedica.mercury.etl.asent.observation

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.core.engine.Constants._
import scala.collection.JavaConverters._


class ObservationVitals(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("as_vitals",
    "as_zc_unit_code_de",
    "cdr.zcm_obstype_code",
    "cdr.map_predicate_values")

  columnSelect = Map(
    "as_vitals" -> List("VITAL_ENTRY_NAME", "PERFORMED_DATETIME", "PATIENT_MRN", "VITAL_ENTRY_NAME", "STATUS_ID",
      "ENCOUNTER_ID", "VITAL_VALUE", "UNITS_ID", "CHILD_ID", "LAST_UPDATED_DATE", "FINDING_ANSWER_DET"),
    "as_zc_unit_code_de" -> List("ENTRYNAME", "ID", "ENTRYMNEMONIC"),
    "cdr.zcm_obstype_code" -> List("OBSCODE", "GROUPID", "DATASRC", "OBSTYPE", "LOCALUNIT", "OBSTYPE_STD_UNITS")
  )

  beforeJoin = Map(
    "as_vitals" -> ((df: DataFrame) => {
      val vitalEntrylist = mpvList1(table("cdr.map_predicate_values"), config(GROUPID), config(CLIENT_DS_ID), "VITALS", "OBSERVATION", "AS_VITALS", "VITAL_ENTRY_NAME")
      df.withColumn("LOCALRESULT", when(df("VITAL_ENTRY_NAME").isin(vitalEntrylist: _*), df("FINDING_ANSWER_DET")).otherwise(df("VITAL_VALUE")))
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val firstJoin = dfs("as_vitals")
      .join(dfs("as_zc_unit_code_de"), dfs("as_zc_unit_code_de")("ID") === dfs("as_vitals")("UNITS_ID"), "left_outer")
    val groups = Window.partitionBy(firstJoin("CHILD_ID")).orderBy(firstJoin("LAST_UPDATED_DATE").desc_nulls_last)
    firstJoin.withColumn("rn", row_number.over(groups)).filter("rn = 1").drop("rn")
  }


  map = Map(
    "DATASRC" -> literal("vitals"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTER_ID"),
    "PATIENTID" -> mapFrom("PATIENT_MRN"),
    "OBSDATE" -> mapFrom("PERFORMED_DATETIME"),
    "LOCALCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("ENTRYNAME").isNotNull, concat_ws("_", df("VITAL_ENTRY_NAME"), df("ENTRYNAME"))).otherwise(df("VITAL_ENTRY_NAME")))
    }),
    "STATUSCODE" -> mapFrom("STATUS_ID"),
    "LOCALRESULT" -> mapFrom("LOCALRESULT")
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.drop("OBSTYPE")
    val zcm = table("cdr.zcm_obstype_code")
    val zcm_fil = zcm.withColumn("LOCALCODE", zcm("OBSCODE"))
      .filter(zcm("OBSTYPE").isNotNull && zcm("OBSTYPE") =!= lit("LABRESULT") && zcm("GROUPID") === config(GROUPID) && zcm("DATASRC") === lit("vitals"))
    val fil = df1.join(zcm_fil, Seq("GROUPID", "DATASRC", "LOCALCODE"), "inner")
    val df2=fil.withColumn("LOCAL_OBS_UNIT", coalesce(fil("ENTRYMNEMONIC"), fil("LOCALUNIT")))
      .withColumn("STD_OBS_UNIT", fil("OBSTYPE_STD_UNITS"))
      .filter("STATUS_ID is null or STATUS_ID != '6'")
    val cols = Engine.schema.getStringList("Observation").asScala.map(_.split("-")(0).toUpperCase())
    df2.select(cols.map(col): _*)
      .distinct
  }

  mapExceptions = Map(
    ("H984926_AS_ENT_MISAG", "LOCALCODE") -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("tmp", when(df("ENTRYNAME").isNotNull, concat_ws("_", df("VITAL_ENTRY_NAME"), df("ENTRYNAME"))).otherwise(df("VITAL_ENTRY_NAME")))
      df1.withColumn(col, concat_ws(".", lit(config(CLIENT_DS_ID)), df1("tmp"))).drop("tmp")
    })
  )
}


// Test
// val bobs = new ObservationVitals(cfg) ; val obs = build(bobs) ; obs.show(false); obs.count
package com.humedica.mercury.etl.asent.patientcustomattribute

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import scala.collection.JavaConverters._


class PatientcustomattributePatdem(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("as_patdem")

  columnSelect = Map(
    "as_patdem" -> List("PATIENT_MRN", "HOME_CHART_LOCATION_NAME")
  )

  beforeJoin = Map(
    "as_patdem" -> ((df: DataFrame) => {
      df.filter("PATIENT_MRN is not null and HOME_CHART_LOCATION_NAME is not null")
    })
  )

  map = Map(
    "DATASRC" -> literal("as_patdem"),
    "PATIENTID" -> mapFrom("PATIENT_MRN"),
    "ATTRIBUTE_VALUE" -> mapFrom("HOME_CHART_LOCATION_NAME"),
    "ATTRIBUTE_TYPE_CUI" -> literal("CH002785")
  )

  afterMap = (df: DataFrame) => {
   val cols = Engine.schema.getStringList("Patientcustomattribute").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*).distinct
  }

}

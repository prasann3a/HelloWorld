package com.humedica.mercury.etl.asent.labmapperdict

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame

class LabmapperdictLabdictionary(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("as_zc_qo_de")

  columnSelect = Map(
    "as_zc_qo_de" -> List("ID", "ENTRYNAME")
  )

  beforeJoin = Map(
    "as_zc_qo_de" -> ((df: DataFrame) => {
      df.filter("ENTRYNAME is not null").distinct
    })
  )

  join = noJoin()

  map = Map(
    "LOCALCODE" -> mapFrom("ID"),
    "LOCALNAME" -> mapFrom("ENTRYNAME"),
    "LOCALDESC" -> mapFrom("ENTRYNAME")
  )
}

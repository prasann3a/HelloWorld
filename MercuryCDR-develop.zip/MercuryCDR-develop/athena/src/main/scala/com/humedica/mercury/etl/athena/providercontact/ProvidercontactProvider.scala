package com.humedica.mercury.etl.athena.providercontact

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class ProvidercontactProvider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("provider",
    "fileIdDates:athena.util.UtilFileIdDates",
    "prov:athena.util.UtilSplitProvider"
  )

  columnSelect = Map(
    "provider" -> List("PROVIDER_ID", "DIRECT_ADDRESS", "FILEID"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "prov" -> List("PROVIDER_ID")
  )

  join = (dfs: Map[String, DataFrame]) => {
    val provJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("provider")
      .join(dfs("fileIdDates"), Seq("FILEID"), "inner")
      .join(dfs("prov"), Seq("PROVIDER_ID"), provJoinType)
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PROVIDER_ID"), df("DIRECT_ADDRESS"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)

    df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1 and direct_address is not null and filedate is not null")
  }

  map = Map(
    "DATASRC" -> literal("provider"),
    "LOCAL_CONTACT_TYPE" -> literal("PROVIDER"),
    "LOCAL_PROVIDER_ID" -> mapFrom("PROVIDER_ID"),
    "EMAIL_ADDRESS" -> mapFrom("DIRECT_ADDRESS"),
    "UPDATE_DATE" -> mapFrom("FILEDATE")
  )

}

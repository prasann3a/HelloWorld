package com.humedica.mercury.etl.athena.procedure

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProcedureFlowsheet(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("flowsheet",
    "fileExtractDates:athena.util.UtilFileIdDates",
    "pat:athena.util.UtilSplitPatient",
    "cdr.map_custom_proc")

  columnSelect = Map(
    "flowsheet" -> List("FLOW_SHEET_ID", "FILEID", "DELETED_DATETIME", "FLOW_SHEET_ELEMENT", "PATIENT_ID", "FLOW_SHEET_ELEMENT_VALUE"),
    "fileExtractDates" -> List("FILEID", "FILEDATE"),
    "pat" -> List("PATIENT_ID"),
    "cdr.map_custom_proc" -> List("GROUPID", "DATASRC", "LOCALCODE", "MAPPEDVALUE")
  )

  beforeJoin = Map(
    "cdr.map_custom_proc" -> ((df: DataFrame) => {
      df.filter("groupid = '" + config(GROUP) + "' and datasrc = 'flowsheet'")
        .drop("GROUPID", "DATASRC")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("flowsheet")
      .join(dfs("fileExtractDates"), Seq("FILEID"), "left_outer")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
      .join(dfs("cdr.map_custom_proc"), dfs("flowsheet")("FLOW_SHEET_ELEMENT") === dfs("cdr.map_custom_proc")("LOCALCODE"), "inner")
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("FLOW_SHEET_ID"), df("MAPPEDVALUE"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)

    val df1 = df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1 and deleted_datetime is null and patient_id is not null and flow_sheet_element_value is not null")

    val df2 = df1.withColumn("cnt_delimiter", size(split(df1("FLOW_SHEET_ELEMENT_VALUE"), "(/|-)")) - 1)
    val df3 = df2.withColumn("months",
      when(df2("cnt_delimiter") === 0, null)
        .otherwise(regexp_extract(df2("FLOW_SHEET_ELEMENT_VALUE"), "^([0-9]{1,2})[/|-]([0-9]{0,2})[/|-]?([0-9]{2,4})$", 1)))
      .withColumn("days",
        when(df2("cnt_delimiter").isin(List(0, 1): _*), null)
          .otherwise(regexp_extract(df2("FLOW_SHEET_ELEMENT_VALUE"), "^([0-9]{1,2})[/|-]([0-9]{0,2})[/|-]?([0-9]{2,4})$", 2)))
      .withColumn("years",
        when(df2("cnt_delimiter") === 0, regexp_extract(df2("FLOW_SHEET_ELEMENT_VALUE"), "^([0-9]{4})$", 1))
          .when(df2("cnt_delimiter") === 1, regexp_extract(df2("FLOW_SHEET_ELEMENT_VALUE"), "^([0-9]{1,2})[/|-]([0-9]{2,4})$", 2))
          .otherwise(regexp_extract(df2("FLOW_SHEET_ELEMENT_VALUE"), "^([0-9]{1,2})[/|-]([0-9]{0,2})[/|-]?([0-9]{2,4})$", 3)))

    df3.withColumn("PROC_DATE",
      to_date(
        concat_ws(
          "-",
          lpad(df3("years"), 4, "20"),
          when(df3("months").isNotNull, lpad(df3("months"), 2, "0")).otherwise(lit("12")),
          when(df3("days").isNotNull, lpad(df3("days"), 2, "0")).otherwise(lit("01"))
        )
      )
    )
  }

  map = Map(
    "DATASRC" -> literal("flowsheet"),
    "LOCALCODE" -> mapFrom("FLOW_SHEET_ELEMENT"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "PROCEDUREDATE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("cnt_delimiter") < 2, last_day(df("PROC_DATE"))).otherwise(df("PROC_DATE")))
    }),
    "LOCALNAME" -> mapFrom("FLOW_SHEET_ELEMENT"),
    "MAPPEDCODE" -> mapFrom("MAPPEDVALUE"),
    "CODETYPE" -> literal("CUSTOM")
  )

  afterMap = includeIf("patientid is not null and proceduredate is not null")

}
package com.humedica.mercury.etl.athena.procedure

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProcedurePatientobgynhistory(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patientobgynhistory:athena.util.UtilDedupedPatientObgynHistory",
    "cdr.map_custom_proc")

  columnSelect = Map(
    "patientobgynhistory" -> List("OBGYN_HISTORY_QUESTION", "PATIENT_ID", "OBGYN_HISTORY_ANSWER", "OBGYN_DATE",
      "DELETED_DATETIME", "FD_FILEDATE", "FILEID"),
    "cdr.map_custom_proc" -> List("GROUPID", "DATASRC", "LOCALCODE", "MAPPEDVALUE", "CODETYPE")
  )

  beforeJoin = Map(
    "patientobgynhistory" -> ((df: DataFrame) => {
      val fil = df.filter(length(year(df("OBGYN_DATE"))) > 2)
      val groups = Window.partitionBy(fil("PATIENT_ID"), fil("OBGYN_DATE"), fil("OBGYN_HISTORY_QUESTION"))
        .orderBy(fil("FD_FILEDATE").desc_nulls_last, fil("FILEID").desc_nulls_last)

      fil.withColumn("LOCALCODE", when(expr("upper(obgyn_history_question) like '%NOTES%'"), null)
        .otherwise(fil("OBGYN_HISTORY_QUESTION")))
        .withColumn("rn", row_number.over(groups))
        .filter("rn = 1")
    }),
    "cdr.map_custom_proc" -> ((df: DataFrame) => {
      df.filter("groupid = '" + config(GROUP) + "' and datasrc = 'patientobgynhistory'")
        .drop("GROUPID", "DATASRC")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("patientobgynhistory")
      .join(dfs("cdr.map_custom_proc"), Seq("LOCALCODE"), "inner")
  }

  map = Map(
    "DATASRC" -> literal("patientobgynhistory"),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "PROCEDUREDATE" -> mapFrom("OBGYN_DATE"),
    "LOCALNAME" -> mapFrom("LOCALCODE"),
    "MAPPEDCODE" -> mapFrom("MAPPEDVALUE"),
    "CODETYPE" -> mapFrom("CODETYPE")
  )

  afterMap = includeIf("proceduredate is not null and patientid is not null")

}
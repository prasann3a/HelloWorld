package com.humedica.mercury.etl.athena.immunization

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class ImmunizationPatientvaccinecv(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "patientvaccine",
    "fileIdDates:athena.util.UtilFileIdDates",
    "tempDoc:athena.util.UtilDedupedDocument",
    "tempClinRes:athena.util.UtilDedupedClinicalResult",
    "tempMed:athena.util.UtilDedupedMedication",
    "splitTable:athena.util.UtilSplitPatient"
  )

  columnSelect = Map(
    "patientvaccine" -> List("FILEID", "PATIENT_ID", "CLINICAL_ENCOUNTER_ID", "ADMINISTER_NOTE", "VACCINE_ROUTE", "ADMINISTERED_DATETIME", "PROVIDER_NOTE",
      "CVX", "VACCINE_NAME", "HUM_TYPE", "PATIENT_VACCINE_ID", "STATUS", "DELETED_DATETIME", "DOCUMENT_ID", "VIS_GIVEN_DATE", "REFUSED_REASON")
  )

  beforeJoin = Map(
    "patientvaccine" -> ((df: DataFrame) => {
      val fileIdDates = table("fileIdDates")
      val joined = df.join(fileIdDates, Seq("FILEID"), "left_outer")
      val groups = Window.partitionBy(joined("PATIENT_VACCINE_ID"), joined("HUM_TYPE")).orderBy(joined("FILEDATE").desc_nulls_last, joined("FILEID").desc_nulls_last)
      joined.withColumn("rn", row_number.over(groups)).filter("rn = 1 and DELETED_DATETIME is null and (STATUS <> 'DELETED' or STATUS is null) and HUM_TYPE = 'CLINICALVACCINE'")
    }),
    "tempClinRes" -> ((df: DataFrame) => {
      df.withColumnRenamed("DOCUMENT_ID", "DOCUMENT_ID_cln")
        .withColumnRenamed("FBD_MED_ID", "FBD_MED_ID_cl")
        .withColumnRenamed("CVX", "CVX_cl")
        .withColumnRenamed("PROVIDER_NOTE", "PROVIDER_NOTE_cl")
    }),
    "tempDoc" -> ((df: DataFrame) => {
      df.withColumnRenamed("FBD_MED_ID", "FBD_MED_ID_doc")
        .withColumnRenamed("CVX", "CVX_doc")
        .withColumnRenamed("PATIENT_ID", "PATIENT_ID_doc")
        .withColumnRenamed("CLINICAL_ENCOUNTER_ID", "CLINICAL_ENCOUNTER_ID_doc")
        .withColumnRenamed("VACCINE_ROUTE", "VACCINE_ROUTE_doc")
        .withColumnRenamed("PROVIDER_NOTE", "PROVIDER_NOTE_doc")
    }),
    "splitTable" -> ((df: DataFrame) => {
      df.withColumnRenamed("PATIENT_ID", "PATIENT_ID_split")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientvaccine")
      .join(dfs("tempDoc"), Seq("DOCUMENT_ID"), "inner")
      .join(dfs("tempClinRes"), dfs("patientvaccine")("DOCUMENT_ID") === coalesce(dfs("tempClinRes")("DOCUMENT_ID_cln"), dfs("tempClinRes")("RESULT_DOCUMENT_ID")), "left_outer")
      .join(dfs("tempMed"), dfs("tempMed")("FDB_MED_ID") === coalesce(dfs("tempDoc")("FBD_MED_ID_doc"), dfs("tempClinRes")("FBD_MED_ID_cl")), "inner")
      .join(dfs("splitTable"), dfs("splitTable")("PATIENT_ID_split") === coalesce(dfs("patientvaccine")("PATIENT_ID"), dfs("tempDoc")("PATIENT_ID_doc")), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("patientvaccine_cv"),
    "PATIENTID" -> cascadeFrom(Seq("PATIENT_ID", "PATIENT_ID_doc")),
    "ENCOUNTERID" -> cascadeFrom(Seq("CLINICAL_ENCOUNTER_ID_doc", "CLINICAL_ENCOUNTER_ID")),
    "LOCALDEFERREDREASON" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("tmp", when(df("REFUSED_REASON").isNotNull, concat(lit(config(CLIENT_DS_ID) + "."), df("REFUSED_REASON")))
        .otherwise(regexp_extract(coalesce(lower(df("PROVIDER_NOTE_doc")), lower(df("ADMINISTER_NOTE")), lower(df("PROVIDER_NOTE")), lower(df("PROVIDER_NOTE_cl")))
          , "(pt|patient)*\\.*\\s*(refuse|reuse|decline)(s|d)*", 0)))
      df1.withColumn(col, when(df1("tmp") =!= lit(""), df1("tmp")).otherwise(lit(null))).drop("tmp")
    }),
    "LOCALROUTE" -> cascadeFrom(Seq("VACCINE_ROUTE_doc", "VACCINE_ROUTE")),
    "RXNORM_CODE" -> mapFrom("RXNORM"),
    "ADMINDATE" -> cascadeFrom(Seq("ADMINISTERED_DATETIME", "VIS_GIVEN_DATE", "ORDER_DATETIME")),
    "LOCALIMMUNIZATIONCD" -> cascadeFrom(Seq("MEDICATION_NAME", "VACCINE_NAME")),
    "LOCALIMMUNIZATIONDESC" -> cascadeFrom(Seq("MEDICATION_NAME", "VACCINE_NAME")),
    "LOCALNDC" -> mapFrom("NDC")
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("LOCALIMMUNIZATIONCD is not null and PATIENTID is not null")
    val cols = Engine.schema.getStringList("Immunization").asScala.map(_.split("-")(0).toUpperCase())
    fil.select(cols.map(col): _*)
      .distinct
  }
}
package com.humedica.mercury.etl.athena.labmapperdict

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class LabmapperdictClinicalresultobservation(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("clinicalresultobservation", "cdr.map_predicate_values")

  columnSelect = Map(
    "clinicalresultobservation" -> List("OBSERVATION_IDENTIFIER", "OBSERVATION_IDENTIFIER_TEXT")
  )

  beforeJoin = Map(
    "clinicalresultobservation" -> ((df: DataFrame) => {
      val list_localname = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CLINICALRESULTOBSERVATION", "LAB_MAPPER_DICT", "CLINICALRESULTOBSERVATION", "OBSERVATION_IDENTIFIER_TEXT")
      val df1 = df.filter("coalesce(upper(OBSERVATION_IDENTIFIER_TEXT), '~') not in (" + list_localname + ")")
        .withColumn("count_localresultname",
          count(df("OBSERVATION_IDENTIFIER_TEXT"))
            .over(
              Window.partitionBy(
                coalesce(df("OBSERVATION_IDENTIFIER"), df("OBSERVATION_IDENTIFIER_TEXT"))
              )
            )
        )
        .withColumn("OBSERVATION_IDENTIFIER_TEXT", substring(df("OBSERVATION_IDENTIFIER_TEXT"), 1, 255))

      val groups = Window.partitionBy(coalesce(df1("OBSERVATION_IDENTIFIER"), df1("OBSERVATION_IDENTIFIER_TEXT")))
        .orderBy(df1("count_localresultname").desc)
      df1.withColumn("rn", row_number.over(groups))
        .filter("rn = 1")
    })
  )

  map = Map(
    "LOCALCODE" -> cascadeFrom(Seq("OBSERVATION_IDENTIFIER", "OBSERVATION_IDENTIFIER_TEXT")),
    "LOCALNAME" -> mapFrom("OBSERVATION_IDENTIFIER_TEXT")
  )

  afterMap = includeIf("localcode is not null")

}
package com.humedica.mercury.etl.athena.labresult

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class LabresultVitalsign(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {


  tables = List("vitalsign"
    , "cdr.zcm_obstype_code"
    , "fileIdDates:athena.util.UtilFileIdDates"
    , "clinicEnc:athena.util.UtilDedupedClinicalEncounter"
    , "cdr.map_predicate_values")

  columnSelect = Map(
    "vitalsign" -> List("FILEID", "HUM_KEY", "CLINICAL_ENCOUNTER_ID", "DELETED_DATETIME", "ENCOUNTER_DATA_ID", "HUM_TYPE", "DB_UNIT", "HUM_VALUE", "CONTEXT_ID"),
    "clinicEnc" -> List("PATIENT_ID", "CLINICAL_ENCOUNTER_ID", "ENCOUNTER_DATE", "DEPARTMENT_ID"),
    "fileIdDates" -> List("FILEDATE", "FILEID"),
    "cdr.zcm_obstype_code" -> List("OBSTYPE", "OBSCODE", "OBSTYPE_STD_UNITS", "LOCALUNIT", "GROUPID", "DATASRC")
  )

  beforeJoin = Map(
    "vitalsign" -> ((df: DataFrame) => {
      val vitalDf = df.join(table("fileIdDates"), Seq("FILEID"), "left_outer")
      val zcm = table("cdr.zcm_obstype_code")
        .filter("GROUPID = '" + config(GROUP) + "' AND DATASRC = 'vitalsign' and cui = 'CH002048'")
      val groups = Window.partitionBy(vitalDf("CONTEXT_ID"), vitalDf("ENCOUNTER_DATA_ID"), vitalDf("HUM_TYPE"))
        .orderBy(vitalDf("FILEDATE").desc_nulls_last, vitalDf("FILEID").desc_nulls_last)

      vitalDf.withColumn("rw", row_number.over(groups))
        .filter("rw=1 and DELETED_DATETIME is null and ENCOUNTER_DATA_ID is not null and HUM_VALUE is not null")
        .join(zcm, vitalDf("HUM_KEY") === zcm("OBSCODE"), "inner")
        .withColumn("LOCALRESULT_NUMERIC", when(df("HUM_VALUE").rlike("^[+-]?(\\.\\d+|\\d+\\.?\\d*)$"), df("HUM_VALUE")).otherwise(null))
        .withColumn("LOCALRESULT_25", when(!df("HUM_VALUE").rlike("^[+-]?(\\.\\d+|\\d+\\.?\\d*)$"),
          when(locate(" ", df("HUM_VALUE"), 25) === 0, expr("substr(HUM_VALUE,1,length(HUM_VALUE))"))
            .otherwise(expr("substr(HUM_VALUE,1,locate(' ', HUM_VALUE, 25))"))).otherwise(null))
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("vitalsign")
      .join(dfs("clinicEnc"), Seq("CLINICAL_ENCOUNTER_ID"), "inner")
  }


  map = Map(
    "DATASRC" -> literal("vitalsign"),
    "LABRESULTID" -> mapFrom("ENCOUNTER_DATA_ID", prefix = "v."),
    "LOCALCODE" -> mapFrom("HUM_KEY"),
    "LOCALRESULT" -> mapFrom("HUM_VALUE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "DATECOLLECTED" -> mapFrom("ENCOUNTER_DATE"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "FACILITYID" -> mapFrom("DEPARTMENT_ID"),
    "LOCALNAME" -> mapFrom("HUM_KEY"),
    "LOCALTESTNAME" -> mapFrom("HUM_KEY"),
    "LOCALUNITS" -> mapFrom("DB_UNIT"),
    "LABRESULT_DATE" -> mapFrom("ENCOUNTER_DATE"),
    "LOCALRESULT_NUMERIC" -> mapFrom("LOCALRESULT_NUMERIC"),
    "LOCALRESULT_INFERRED" -> extract_value(),
    "LOCALUNITS_INFERRED" -> labresults_extract_uom(),
    "RELATIVEINDICATOR" -> labresults_extract_relativeindicator()
  )

  afterMap = (df: DataFrame) => {
    df.withColumn("LOCALRESULT", substring(df("LOCALRESULT"),0,2000)) // https://workflow.advisory.com/browse/IV-11082
  }

}


// test
//  val lr = new LabresultVitalsign(cfg); val lrc = build(lr,true); lrc.show ; lrc.count;

package com.humedica.mercury.etl.athena.provider

import com.humedica.mercury.etl.core.engine.{Engine,EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

/**
 * Auto-generated on 09/21/2018
 */


class ProviderClinicalprovider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("clinicalprovider:athena.util.UtilDedupedClinicalProvider",
    "cdr.ref_cmsnpi")

  columnSelect = Map(
    "clinicalprovider" -> List("CLINICAL_PROVIDER_ID", "NAME", "FIRST_NAME", "GENDER", "LAST_NAME", "MIDDLE_NAME", "NPI"),
    "cdr.ref_cmsnpi" -> List("NPI", "ENTITY_TYPE_CODE")
  )

  beforeJoin = Map(
    "clinicalprovider" -> includeIf("clinical_provider_id is not null")
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> literal("clinicalprovider"),
    "LOCALPROVIDERID" -> mapFrom("CLINICAL_PROVIDER_ID", prefix = "cp."),
    "CREDENTIALS" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(regexp_extract(df("NAME"), "(MD|DO|NP)", 1) === "", null)
        .otherwise(regexp_extract(df("NAME"), "(MD|DO|NP)", 1)))
    }),
    "PROVIDERNAME" -> mapFrom("NAME"),
    "FIRST_NAME" -> mapFrom("FIRST_NAME"),
    "MIDDLE_NAME" -> mapFrom("MIDDLE_NAME"),
    "LAST_NAME" -> mapFrom("LAST_NAME"),
    "GENDER" -> mapFrom("GENDER"),
    "NPI" -> mapFrom("NPI"),
    "SUFFIX" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(regexp_extract(df("NAME"), "(JR|SR|III)", 1) === "", null)
        .otherwise(regexp_extract(df("NAME"), "(JR|SR|III)", 1)))
    })
  )

  afterMap = (df: DataFrame) => {
    val npiProv = df.filter("npi is not null")
      .withColumn("LOCALPROVIDERID", concat(lit("npi."), df("NPI")))
    val dfnpiProv = df.union(npiProv)
    val cols = Engine.schema.getStringList("Provider").asScala.map(_.split("-")(0).toUpperCase())
    dfnpiProv.select(cols.map(col): _*)
      .distinct
  }

  joinExceptions = Map(
    "H984728_ATHENA_DWF_4" -> ((dfs: Map[String, DataFrame]) => {
      dfs("clinicalprovider")
        .join(dfs("cdr.ref_cmsnpi"), Seq("NPI"), "left_outer")
    })
  )

  mapExceptions = Map(
    ("H984728_ATHENA_DWF_4", "NPI") -> mapFromSecondColumnValueIsIn("NPI", "ENTITY_TYPE_CODE", Seq("1"))
  )

}
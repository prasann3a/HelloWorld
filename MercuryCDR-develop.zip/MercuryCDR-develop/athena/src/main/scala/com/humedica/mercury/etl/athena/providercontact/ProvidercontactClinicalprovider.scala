package com.humedica.mercury.etl.athena.providercontact

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class ProvidercontactClinicalprovider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("clinicalprovider",
    "fileIdDates:athena.util.UtilFileIdDates"
  )

  columnSelect = Map(
    "clinicalprovider" -> List("CLINICAL_PROVIDER_ID", "ADDRESS1", "ADDRESS2", "CITY", "HUM_STATE", "PHONE", "ZIP", "FILEID"),
    "fileIdDates" -> List("FILEID", "FILEDATE")
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("clinicalprovider")
      .join(dfs("fileIdDates"), Seq("FILEID"), "inner")
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("CLINICAL_PROVIDER_ID"), df("ADDRESS1"), df("ADDRESS2"), df("CITY"), df("HUM_STATE"), df("PHONE"), df("ZIP"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)

    df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1 and coalesce(address1, address2, city, hum_state, phone, zip) is not null and filedate is not null")
  }

  map = Map(
    "DATASRC" -> literal("clinicalprovider"),
    "LOCAL_CONTACT_TYPE" -> literal("PROVIDER"),
    "LOCAL_PROVIDER_ID" -> mapFrom("CLINICAL_PROVIDER_ID", prefix = "cp."),
    "ADDRESS_LINE1" -> mapFrom("ADDRESS1"),
    "ADDRESS_LINE2" -> mapFrom("ADDRESS2"),
    "CITY" -> mapFrom("CITY"),
    "STATE" -> mapFrom("HUM_STATE"),
    "WORK_PHONE" -> mapFrom("PHONE"),
    "ZIPCODE" -> mapFrom("ZIP"),
    "UPDATE_DATE" -> mapFrom("FILEDATE")
  )

}

package com.humedica.mercury.etl.athena.procedure

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import scala.collection.JavaConverters._

/**
  * Auto-generated on 09/21/2018
  */


class ProcedurePatientsurgerycust(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patientsurgery:athena.util.UtilDedupedPatientSurgery",
    "cdr.map_custom_proc")

  columnSelect = Map(
    "patientsurgery" -> List("HUM_PROCEDURE", "PATIENT_ID", "SURGERY_DATETIME", "CLINICAL_ENCOUNTER_ID"),
    "cdr.map_custom_proc" -> List("GROUPID", "DATASRC", "LOCALCODE", "MAPPEDVALUE")
  )

  beforeJoin = Map(
    "cdr.map_custom_proc" -> ((df: DataFrame) => {
      df.filter("groupid = '" + config(GROUP) + "' and datasrc = 'patientsurgery_cust'")
        .drop("GROUPID", "DATASRC")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("patientsurgery")
      .join(dfs("cdr.map_custom_proc"), dfs("patientsurgery")("HUM_PROCEDURE") === dfs("cdr.map_custom_proc")("LOCALCODE"), "inner")
  }

  map = Map(
    "DATASRC" -> literal("patientsurgery_cust"),
    "LOCALCODE" -> mapFrom("HUM_PROCEDURE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "PROCEDUREDATE" -> mapFrom("SURGERY_DATETIME"),
    "LOCALNAME" -> mapFrom("HUM_PROCEDURE"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "MAPPEDCODE" -> mapFrom("MAPPEDVALUE"),
    "CODETYPE" -> literal("CUSTOM")
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("PROCEDUREDATE is not null and PATIENTID is not null")
    val cols = Engine.schema.getStringList("Procedure").asScala.map(_.split("-")(0).toUpperCase())
    fil.select(cols.map(col): _*)
      .distinct
  }

}
package com.humedica.mercury.etl.athena.util

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import com.humedica.mercury.etl.athena.util.UtilSplitTable
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class UtilDedupedQmresult(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  cacheMe = true

  columns = List("PATIENTID", "LOCALCODE", "OBSDATE", "DATASRC", "FILEID", "RESULT_STATUS", "P4P_MEASURE", "EXCLUSION_REASON",
    "LOCALUNIT", "OBSTYPE")

  tables = List("qmresult",
    "extractinfo",
    "fileIdDates:athena.util.UtilFileIdDates",
    "pat:athena.util.UtilSplitPatient",
    "cdr.zcm_obstype_code"
  )

  columnSelect = Map(
    "qmresult" -> List("PATIENT_ID", "P4P_MEASURE", "SATISFIED_DATE", "RESULT_STATUS", "EXCLUSION_REASON", "FILEID",
      "P4P_PROGRAM", "PROVIDER_ID", "CHART_ID", "CONTEXT_ID"),
    "extractinfo" -> List("FILEID", "HUM_PARAMETER", "HUM_VALUE"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "pat" -> List("PATIENT_ID"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "DATASRC", "OBSCODE", "CUI", "LOCALUNIT", "OBSTYPE")
  )

  beforeJoin = Map(
    "qmresult" -> ((df: DataFrame) => {
      val ext = table("extractinfo")
        .filter("hum_parameter = 'FILENAME'")
      val fil = ext.orderBy(ext("FILEID").desc_nulls_last)
        .limit(1)
        .select(split(ext("HUM_VALUE"), "_").getItem(1).as("VERSION"))

      val qm_ext = df
        .withColumn("SATISFIED_DATE", regexp_replace(df("SATISFIED_DATE"),"\\.0$", ""))
        .crossJoin(fil)
        .join(table("fileIdDates"), Seq("FILEID"), "left_outer")
      val groups1 = Window.partitionBy(qm_ext("PATIENT_ID"), qm_ext("P4P_MEASURE"), qm_ext("SATISFIED_DATE"))
        .orderBy(qm_ext("FILEDATE").desc_nulls_last, qm_ext("FILEID").desc_nulls_last)

      val groups2 = Window.partitionBy(qm_ext("PATIENT_ID"), qm_ext("P4P_PROGRAM"), qm_ext("P4P_MEASURE"), qm_ext("PROVIDER_ID"), qm_ext("CHART_ID"), qm_ext("CONTEXT_ID"))
        .orderBy(qm_ext("FILEDATE").desc_nulls_last, qm_ext("FILEID").desc_nulls_last)

      qm_ext.withColumn("rn", when(qm_ext("VERSION") === "4.0", row_number.over(groups1))
        .otherwise(row_number.over(groups2)))
        .filter("rn = 1")
    }),
    "cdr.zcm_obstype_code" -> includeIf("groupid = '" + config(GROUP) + "' and datasrc in ('qmresult', 'qmresult_exclude') and cui <> 'CH002048'")
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("qmresult")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
      .join(dfs("cdr.zcm_obstype_code"), dfs("qmresult")("P4P_MEASURE") === dfs("cdr.zcm_obstype_code")("OBSCODE"), "inner")
  }

  map = Map(
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "LOCALCODE" -> mapFrom("P4P_MEASURE"),
    "OBSDATE" -> mapFrom("SATISFIED_DATE")
  )

  beforeJoinExceptions = Map(
    "H542284_ATH_DWF4" -> Map(
      "qmresult" -> ((df: DataFrame) => {
        val qm_ext = df
          .join(table("fileIdDates"), Seq("FILEID"), "left_outer")

        val groups = Window.partitionBy(qm_ext("PATIENT_ID"), qm_ext("P4P_PROGRAM"), qm_ext("P4P_MEASURE"), qm_ext("PROVIDER_ID"), qm_ext("CHART_ID"), qm_ext("CONTEXT_ID"))
          .orderBy(qm_ext("FILEDATE").desc_nulls_last, qm_ext("FILEID").desc_nulls_last)

        qm_ext.withColumn("rn", row_number.over(groups))
          .filter("rn = 1")
      }),
      "cdr.zcm_obstype_code" -> includeIf("groupid = '" + config(GROUP) + "' and datasrc in ('qmresult', 'qmresult_exclude') and cui <> 'CH002048'")
    )
  )

}

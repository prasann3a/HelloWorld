package com.humedica.mercury.etl.athena.allergies

import com.humedica.mercury.etl.core.engine.{Engine,EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.athena.util.UtilSplitTable
import scala.collection.JavaConverters._

/**
  * Auto-generated on 09/21/2018
  */


class AllergiesAllergy(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("allergy:athena.util.UtilDedupedAllergy",
    "chart:athena.util.UtilDedupedChart",
    "pat:athena.util.UtilSplitPatient")

  columnSelect = Map(
    "allergy" -> List("ALLERGY_CONCEPT_TYPE", "ONSET_DATE", "CREATED_DATETIME", "PATIENT_ID", "DEACTIVATED_DATETIME",
      "ALLERGY_NAME", "NOTE", "RXNORM_CODE", "HUM_TYPE", "CHART_ID", "ALLERGY_ID", "FILEID"),
    "chart" -> List("CHART_ID", "ENTERPRISE_ID"),
    "pat" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "pat" -> renameColumns(List(
      ("PATIENT_ID", "PATIENT_ID_pat"))
    )
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("allergy")
      .join(dfs("chart"), Seq("CHART_ID"), "left_outer")
      .join(dfs("pat"), coalesce(dfs("allergy")("PATIENT_ID"),dfs("chart")("ENTERPRISE_ID")) === dfs("pat")("PATIENT_ID_pat"), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("allergy"),
    "LOCALALLERGENCD" -> cascadeFrom(Seq("ALLERGY_NAME","NOTE")),
    "LOCALALLERGENTYPE" -> mapFrom("ALLERGY_CONCEPT_TYPE"),
    "ONSETDATE" -> ((col: String, df: DataFrame) => {
      val df1 = safe_to_date(df, "ONSET_DATE", "ONSET_DATE", "yyyy-MM-dd", 0)
      val df2 = safe_to_date(df1, "CREATED_DATETIME", "CREATED_DATETIME", "yyyy-MM-dd", 0)
      df2.withColumn(col, coalesce(
        when(df2("ONSET_DATE") === to_date(lit("1900-01-01")), null).otherwise(df2("ONSET_DATE")),
        when(df2("CREATED_DATETIME") === to_date(lit("1900-01-01")), null).otherwise(df2("CREATED_DATETIME"))
      )
      )
    }),
    "PATIENTID" -> cascadeFrom(Seq("PATIENT_ID", "ENTERPRISE_ID")),
    "LOCALSTATUS" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("DEACTIVATED_DATETIME").isNotNull, lit("Inactive")).otherwise(null))
    }),
    "LOCALALLERGENDESC" -> cascadeFrom(Seq("ALLERGY_NAME", "NOTE")),
    "RXNORM_CODE" -> mapFrom("RXNORM_CODE")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("ALLERGY_ID"), df("HUM_TYPE")).orderBy(df("FILEID"))
    val df1= df.withColumn("rn", row_number.over(groups)).filter("rn = 1 and localallergencd is not null and onsetdate is not null and patientid is not null")
    val cols = Engine.schema.getStringList("Allergies").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct
  }

}
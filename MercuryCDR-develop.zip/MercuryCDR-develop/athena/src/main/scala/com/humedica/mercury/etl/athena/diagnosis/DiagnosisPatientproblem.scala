package com.humedica.mercury.etl.athena.diagnosis

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class DiagnosisPatientproblem(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "patientproblem",
    "patient",
    "chart",
    "fileIdDates:athena.util.UtilFileIdDates",
    "splitpatient:athena.util.UtilSplitPatient",
    "cdr.ref_snomed_icd9",
    "cdr.ref_snomed_icd10"
  )

  columnSelect = Map(
    "patientproblem" -> List("FILEID", "HUM_TYPE", "PATIENT_PROBLEM_ID", "DIAGNOSIS_CODE", "PATIENT_ID", "SNOMED_CODE", "ONSET_DATE", "CHART_ID", "DELETED_DATETIME"),
    "patient" -> List("FILEID", "PATIENT_ID", "ENTERPRISE_ID"),
    "chart" -> List("CHART_ID", "ENTERPRISE_ID", "CREATED_DATETIME"),
    "splitpatient" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "patientproblem" -> ((df: DataFrame) => {
      val fileIdDates = table("fileIdDates")
      val fil = df.filter("HUM_TYPE <> 'PATIENTPROBLEMLIST_FREETEXT'")
      val joined = fil.join(fileIdDates, Seq("FILEID"), "left_outer")
      val groups = Window.partitionBy(joined("PATIENT_PROBLEM_ID")).orderBy(joined("FILEDATE").desc_nulls_last, joined("FILEID").desc_nulls_last)
      joined.withColumn("rn", row_number.over(groups)).filter("rn = 1 and DELETED_DATETIME is null").drop("rn")
    }),
    "patient" -> ((df: DataFrame) => {
      val patJoinType = new UtilSplitTable(config).patprovJoinType
      val fil = df.join(table("splitpatient"), Seq("PATIENT_ID"), patJoinType)
      val fileIdDates = table("fileIdDates")
      val joined = fil.join(fileIdDates, Seq("FILEID"), "left_outer")
      val groups = Window.partitionBy(joined("ENTERPRISE_ID")).orderBy(joined("FILEDATE").desc_nulls_last, joined("FILEID").desc_nulls_last)
      joined.withColumn("rn", row_number.over(groups)).filter("rn = 1").drop("rn")
        .withColumnRenamed("PATIENT_ID", "PATIENT_ID_p")
    }),
    "cdr.ref_snomed_icd9" -> ((df: DataFrame) => {
      df.withColumnRenamed("SNOMED_ID", "SNOMED_ID9")
    }),
    "cdr.ref_snomed_icd10" -> ((df: DataFrame) => {
      df.withColumnRenamed("SNOMED_ID", "SNOMED_ID10")
    }),
    "splitpatient" -> ((df: DataFrame) => {
      df.withColumnRenamed("PATIENT_ID", "PATIENTID_split")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientproblem")
      .join(dfs("chart"), Seq("CHART_ID"), "left_outer")
      .join(dfs("patient"), Seq("ENTERPRISE_ID"), "left_outer")
      .join(dfs("splitpatient"), dfs("splitpatient")("PATIENTID_split") === coalesce(dfs("patientproblem")("PATIENT_ID"), dfs("patient")("PATIENT_ID_p")), patJoinType)
      .join(dfs("cdr.ref_snomed_icd9"), dfs("patientproblem")("SNOMED_CODE") === dfs("cdr.ref_snomed_icd9")("SNOMED_ID9") &&
        when(from_unixtime(unix_timestamp(coalesce(dfs("patientproblem")("ONSET_DATE"), lit("1900-01-01 00:00:00")))) =!= from_unixtime(unix_timestamp(lit("1900-01-01 00:00:00"))),
          from_unixtime(unix_timestamp(dfs("patientproblem")("ONSET_DATE"))))
          .otherwise(from_unixtime(unix_timestamp(dfs("chart")("CREATED_DATETIME")))) < from_unixtime(unix_timestamp(lit("2015-10-01 00:00:00"))), "left_outer")
      .join(dfs("cdr.ref_snomed_icd10"), dfs("patientproblem")("SNOMED_CODE") === dfs("cdr.ref_snomed_icd10")("SNOMED_ID10") &&
        when(from_unixtime(unix_timestamp(coalesce(dfs("patientproblem")("ONSET_DATE"), lit("1900-01-01 00:00:00")))) =!= from_unixtime(unix_timestamp(lit("1900-01-01 00:00:00"))),
          from_unixtime(unix_timestamp(dfs("patientproblem")("ONSET_DATE"))))
          .otherwise(from_unixtime(unix_timestamp(dfs("chart")("CREATED_DATETIME")))) >= from_unixtime(unix_timestamp(lit("2015-10-01 00:00:00"))), "left_outer")
  }

  afterJoin = (df: DataFrame) => {
    val addColumns = df.withColumn("DX_TIMESTAMP",
      when(from_unixtime(unix_timestamp(coalesce(df("ONSET_DATE"), lit("1900-01-01 00:00:00")))) =!= from_unixtime(unix_timestamp(lit("1900-01-01 00:00:00"))),
        from_unixtime(unix_timestamp(df("ONSET_DATE"))))
        .otherwise(from_unixtime(unix_timestamp(df("CREATED_DATETIME")))))
      .withColumn("PATIENTID", coalesce(df("PATIENT_ID"), df("PATIENT_ID_p")))
      .withColumn("CODE_TYPE_ICD", when(df("HUM_TYPE") === lit("ICD9PATIENTPROBLEM"), lit("ICD9")).when(df("HUM_TYPE") === lit("ICD10PATIENTPROBLEM"), lit("ICD10"))
        .otherwise(df("HUM_TYPE")))
      .withColumn("CODE_TYPE_SNOMED", when(df("SNOMED_ID9").isNotNull, lit("ICD9")).when(df("SNOMED_ID10").isNotNull, lit("ICD10")))
      .withColumn("MAPPEDDIAGNOSIS_sno", coalesce(df("ICD9CM_CODE"), df("ICD10_CODE")))

    val insert1 = addColumns.filter("DIAGNOSIS_CODE is not null")
      .withColumn("LOCALDIAGNOSIS", addColumns("DIAGNOSIS_CODE"))
      .withColumn("MAPPEDDIAGNOSIS", addColumns("DIAGNOSIS_CODE"))
      .withColumn("CODETYPE", addColumns("CODE_TYPE_ICD"))
      .select("PATIENTID", "DX_TIMESTAMP", "LOCALDIAGNOSIS", "MAPPEDDIAGNOSIS", "CODETYPE")
    val insert2 = addColumns.filter("SNOMED_CODE is not null")
      .withColumn("LOCALDIAGNOSIS", addColumns("SNOMED_CODE"))
      .withColumn("MAPPEDDIAGNOSIS", addColumns("SNOMED_CODE"))
      .withColumn("CODETYPE", addColumns("CODE_TYPE_ICD"))
      .select("PATIENTID", "DX_TIMESTAMP", "LOCALDIAGNOSIS", "MAPPEDDIAGNOSIS", "CODETYPE")
    val insert3 = addColumns.filter("SNOMED_CODE is not null and MAPPEDDIAGNOSIS_sno is not null")
      .withColumn("LOCALDIAGNOSIS", addColumns("SNOMED_CODE"))
      .withColumn("MAPPEDDIAGNOSIS", addColumns("MAPPEDDIAGNOSIS_sno"))
      .withColumn("CODETYPE", addColumns("CODE_TYPE_SNOMED"))
      .select("PATIENTID", "DX_TIMESTAMP", "LOCALDIAGNOSIS", "MAPPEDDIAGNOSIS", "CODETYPE")
    insert1.unionAll(insert2).unionAll(insert3).filter("DX_TIMESTAMP is not null and PATIENTID is not null")
  }

  map = Map(
    "DATASRC" -> literal("patientproblem")
  )
  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Diagnosis").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*)
      .distinct
  }
}
package com.humedica.mercury.etl.athena.provider

import com.humedica.mercury.etl.core.engine.{Engine,EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

/**
 * Auto-generated on 09/21/2018
 */


class ProviderProvider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("provider:athena.util.UtilDedupedProvider")

  columnSelect = Map(
    "provider" -> List("PROVIDER_ID", "PROVIDER_TYPE", "PROVIDER_FIRST_NAME", "PROVIDER_LAST_NAME", "PROVIDER_TYPE_CATEGORY",
      "PROVIDER_NPI_NUMBER", "BILLED_NAME")
  )

  beforeJoin = Map(
    "provider" -> includeIf("provider_id is not null")
  )

  map = Map(
    "DATASRC" -> literal("provider"),
    "LOCALPROVIDERID" -> mapFrom("PROVIDER_ID"),
    "CREDENTIALS" -> mapFrom("PROVIDER_TYPE"),
    "FIRST_NAME" -> mapFrom("PROVIDER_FIRST_NAME"),
    "LAST_NAME" -> mapFrom("PROVIDER_LAST_NAME"),
    "NPI" -> mapFrom("PROVIDER_NPI_NUMBER"),
    "SUFFIX" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(regexp_extract(df("BILLED_NAME"), "(JR|SR|III)", 1) === "", null)
        .otherwise(regexp_extract(df("BILLED_NAME"), "(JR|SR|III)", 1)))
    })
  )

  afterMap = (df: DataFrame) => {
    val npiProv = df.filter("npi is not null")
      .withColumn("LOCALPROVIDERID", concat(lit("npi."), df("NPI")))
    val dfnpiProv = df.union(npiProv)
    val cols = Engine.schema.getStringList("Provider").asScala.map(_.split("-")(0).toUpperCase())
    dfnpiProv.select(cols.map(col): _*)
      .distinct
  }

  mapExceptions = Map(
    ("H984728_ATHENA_DWF_4", "NPI") -> mapFromSecondColumnValueIsIn("PROVIDER_NPI_NUMBER", "PROVIDER_TYPE_CATEGORY", Seq("MD"))
  )

}
package com.humedica.mercury.etl.athena.procedure

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProcedureQmresult(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("qmresult",
    "extractinfo",
    "fileIdDates:athena.util.UtilFileIdDates",
    "pat:athena.util.UtilSplitPatient",
    "cdr.map_custom_proc"
  )

  columnSelect = Map(
    "qmresult" -> List("P4P_PROGRAM", "P4P_MEASURE", "PATIENT_ID", "SATISFIED_DATE", "PROVIDER_ID", "CHART_ID",
      "CONTEXT_ID", "FILEID", "RESULT_STATUS"),
    "extractinfo" -> List("FILEID", "HUM_PARAMETER", "HUM_VALUE"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "pat" -> List("PATIENT_ID"),
    "cdr.map_custom_proc" -> List("GROUPID", "DATASRC", "LOCALCODE", "MAPPEDVALUE")
  )

  beforeJoin = Map(
    "qmresult" -> ((df: DataFrame) => {
      df.withColumn("SATISFIED_DATE", regexp_replace(df("SATISFIED_DATE"),"\\.0$", ""))
    }),
    "cdr.map_custom_proc" -> ((df: DataFrame) => {
      df.filter("groupid = '" + config(GROUP) + "' and datasrc = 'qmresult'")
        .drop("GROUPID", "DATASRC")
    }),
    "extractinfo" -> ((df: DataFrame) => {
      val fil = df.filter("hum_parameter = 'FILENAME'")
      fil.orderBy(fil("FILEID").desc_nulls_last)
        .limit(1)
        .select(split(fil("HUM_VALUE"), "_").getItem(1).as("VERSION"))
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("qmresult")
      .join(dfs("fileIdDates"), Seq("FILEID"), "left_outer")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
      .join(dfs("cdr.map_custom_proc"), dfs("qmresult")("P4P_MEASURE") === dfs("cdr.map_custom_proc")("LOCALCODE"), "inner")
      .crossJoin(dfs("extractinfo"))
  }

  afterJoin = (df: DataFrame) => {
    val groups1 = Window.partitionBy(df("PATIENT_ID"), df("P4P_MEASURE"), df("SATISFIED_DATE"), df("CHART_ID"), df("MAPPEDVALUE"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)

    val groups2 = Window.partitionBy(df("PATIENT_ID"), df("P4P_PROGRAM"), df("P4P_MEASURE"), df("PROVIDER_ID"), df("CHART_ID"), df("CONTEXT_ID"), df("MAPPEDVALUE"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last, df("SATISFIED_DATE").desc_nulls_last)

    df.withColumn("rn", when(df("VERSION") === "4.0", row_number.over(groups1))
      .otherwise(row_number.over(groups2)))
      .filter("rn = 1 and coalesce(result_status, 'X') not in ('NOTSATISFIED', 'EXCLUDED')")
  }

  map = Map(
    "DATASRC" -> literal("qmresult"),
    "LOCALCODE" -> mapFrom("P4P_MEASURE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "PROCEDUREDATE" -> mapFrom("SATISFIED_DATE"),
    "LOCALNAME" -> mapFrom("P4P_MEASURE"),
    "PERFORMINGPROVIDERID" -> mapFrom("PROVIDER_ID"),
    "MAPPEDCODE" -> mapFrom("MAPPEDVALUE"),
    "CODETYPE" -> literal("CUSTOM")
  )

  afterMap = (df: DataFrame) => {
    df.filter("proceduredate is not null and patientid is not null")
      .dropDuplicates(List("DATASRC", "LOCALCODE", "PATIENTID", "PROCEDUREDATE", "LOCALNAME", "PERFORMINGPROVIDERID", "MAPPEDCODE", "CODETYPE"))
  }

  afterJoinExceptions = Map(
    "H542284_ATH_DWF4" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("PATIENT_ID"), df("P4P_PROGRAM"), df("P4P_MEASURE"), df("PROVIDER_ID"), df("CHART_ID"), df("CONTEXT_ID"), df("MAPPEDVALUE"))
        .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)

      df.withColumn("rn", row_number.over(groups))
        .filter("rn = 1 and coalesce(result_status, 'X') not in ('NOTSATISFIED', 'EXCLUDED')")
    })
  )

}
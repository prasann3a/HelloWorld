package com.humedica.mercury.etl.athena.providerspecialty

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProviderspecialtyProvider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("provider:athena.util.UtilDedupedProvider")

  columnSelect = Map(
    "provider" -> List("PROVIDER_ID", "SPECIALTY_CODE", "SPECIALTY")
  )

  beforeJoin = Map(
    "provider" -> includeIf("provider_id is not null")
  )

  map = Map(
    "LOCALCODESOURCE" -> literal("provider"),
    "LOCALPROVIDERID" -> mapFrom("PROVIDER_ID"),
    "LOCALSPECIALTYCODE" -> cascadeFrom(Seq("SPECIALTY_CODE", "SPECIALTY"), prefix = config(CLIENT_DS_ID) + ".")
  )

  afterMap = includeIf("localspecialtycode is not null")

}
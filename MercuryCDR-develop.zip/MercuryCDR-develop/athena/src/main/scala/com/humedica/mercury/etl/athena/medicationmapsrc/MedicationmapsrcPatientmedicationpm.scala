package com.humedica.mercury.etl.athena.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcPatientmedicationpm(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "patientmedication",
    "medication"
  )

  columnSelect = Map(
    "patientmedication" -> List("MEDICATION_ID", "FILEID", "NDC", "MEDICATION_NAME", "DOCUMENT_DESCRIPTION", "RXNORM", "PATIENT_MEDICATION_ID", "MEDICATION_TYPE"),
    "medication" -> List("MEDICATION_ID", "FILEID", "NDC", "MEDICATION_NAME", "RXNORM")
  )

  beforeJoin = Map(
    "patientmedication" -> ((df: DataFrame) => {
      val filter_df = df.filter("MEDICATION_TYPE = 'PATIENTMEDICATION'")
      val groups = Window.partitionBy(filter_df("PATIENT_MEDICATION_ID")).orderBy(filter_df("FILEID").desc)
      filter_df.withColumn("pat_med_rn", row_number.over(groups)).filter("pat_med_rn = 1").drop("pat_med_rn")
    }),
    "medication" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("MEDICATION_ID")).orderBy(df("FILEID").desc)
      df.withColumnRenamed("MEDICATION_NAME", "MED_MEDICATION_NAME")
        .withColumnRenamed("NDC", "MED_NDC")
        .withColumnRenamed("RXNORM", "MED_RXNORM")
        .withColumn("med_rn", row_number.over(groups)).filter("med_rn = 1").drop("med_rn")
    })
  )

  join = (dfs: Map[String,DataFrame]) =>
    dfs("patientmedication").join(dfs("medication"),Seq("MEDICATION_ID"),"left_outer")

  map = Map(
    "DATASRC" -> literal("patientmedication_pm"),
    "LOCALMEDCODE" -> ((col, df) => df.withColumn(col, substring(coalesce(df("MEDICATION_ID"), df("MEDICATION_NAME"), df("DOCUMENT_DESCRIPTION")), 1, 100))),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, coalesce(df("MEDICATION_NAME"), df("MED_MEDICATION_NAME"), df("DOCUMENT_DESCRIPTION")))),
    "LOCALGENERIC" -> ((col, df) => df.withColumn(col, coalesce(df("MED_MEDICATION_NAME"), df("MEDICATION_NAME")))),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, coalesce(df("MED_NDC"), df("NDC")))),
    "NDC_SRC" -> literal("src"),
    "RXNORM_CODE" -> ((col, df) => df.withColumn(col, coalesce(df("MED_RXNORM"), df("RXNORM"))))
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALDESCRIPTION"), df("LOCALGENERIC"), df("LOCALNDC"), df("RXNORM_CODE"))
    val df1 = df.withColumn("NUM_RECS", count("*").over(groups))
      .withColumn("NO_NDC", sum(when(df("LOCALNDC").isNull, 1).otherwise(0)).over(groups))
      .withColumn("HAS_NDC", sum(when(df("LOCALNDC").isNull, 0).otherwise(1)).over(groups))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct().filter("LOCALMEDCODE is NOT NULL")
  }
}

//val a = new MedicationmapsrcPatientmedicationpm(cfg); val med_s = build(a, allColumns = true);

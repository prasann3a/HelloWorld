package com.humedica.mercury.etl.athena.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcPatientvaccinecv(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "patientvaccine",
    "document",
    "medication",
    "clinicalresult"
  )

  columnSelect = Map(
    "patientvaccine" -> List("PATIENT_VACCINE_ID", "HUM_TYPE", "FILEID", "CVX", "VACCINE_NAME", "DOCUMENT_ID"),
    "document" -> List("DOCUMENT_ID", "FILEID", "CVX", "FBD_MED_ID"),
    "medication" -> List("MEDICATION_ID", "FILEID", "NDC", "MEDICATION_NAME", "FDB_MED_ID"),
    "clinicalresult" -> List("CVX", "DOCUMENT_ID", "RESULT_DOCUMENT_ID")
  )

  beforeJoin = Map(
    "patientvaccine" -> ((df: DataFrame) => {
      val filter_df = df.filter("HUM_TYPE = 'CLINICALVACCINE'")
      val groups = Window.partitionBy(filter_df("PATIENT_VACCINE_ID"), filter_df("HUM_TYPE")).orderBy(filter_df("FILEID").desc)
      filter_df.withColumn("vacc_rn", row_number.over(groups)).filter("vacc_rn = 1").drop("vacc_rn")
    }),
    "document" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("DOCUMENT_ID")).orderBy(df("FILEID").desc)
      df.withColumnRenamed("CVX", "DOC_CVX")
        .withColumn("doc_rn", row_number.over(groups)).filter("doc_rn = 1").drop("doc_rn")
    }),
    "medication" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("MEDICATION_ID")).orderBy(df("FILEID").desc)
      df.withColumn("med_rn", row_number.over(groups)).filter("med_rn = 1").drop("med_rn")
    }),
    "clinicalresult" -> ((df: DataFrame) => {
      df.withColumnRenamed("CVX", "CLC_CVX")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("patientvaccine").join(dfs("document"), dfs("patientvaccine")("DOCUMENT_ID") === dfs("document")("DOCUMENT_ID"), "inner")
                         .join(dfs("medication"), dfs("medication")("FDB_MED_ID") === dfs("document")("FBD_MED_ID"), "inner")
                         .join(dfs("clinicalresult"), dfs("document")("DOCUMENT_ID") === coalesce(dfs("clinicalresult")("DOCUMENT_ID"), dfs("clinicalresult")("RESULT_DOCUMENT_ID")), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("patientvaccine_cv"),
    "LOCALMEDCODE" -> ((col, df) => df.withColumn(col, coalesce(df("MEDICATION_NAME"), df("VACCINE_NAME")))),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, normalizeNDC(df, "NDC"))),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, coalesce(df("MEDICATION_NAME"), df("VACCINE_NAME"))))
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALNDC"), df("LOCALDESCRIPTION"))
    val df1 = df.withColumn("NUM_RECS", count("*").over(groups))
                .withColumn("NO_NDC", sum(when(df("NDC").isNull, 1).otherwise(0)).over(groups))
                .withColumn("HAS_NDC", sum(when(df("NDC").isNull, 0).otherwise(1)).over(groups))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcPatientvaccinecv(cfg); val med_s = build(a, allColumns = true);

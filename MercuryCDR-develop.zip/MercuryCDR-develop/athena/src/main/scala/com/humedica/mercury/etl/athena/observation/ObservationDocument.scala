package com.humedica.mercury.etl.athena.observation

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame


class ObservationDocument(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "document:athena.util.UtilDedupedDocument",
    "cdr.zcm_obstype_code",
    "pat:athena.util.UtilSplitPatient")


  columnSelect = Map(
    "document" -> List("CLINICAL_ORDER_TYPE", "ORDER_DATETIME", "PATIENT_ID", "DEPARTMENT_ID", "CLINICAL_ENCOUNTER_ID", "DELETED_DATETIME"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "DATASRC", "OBSCODE", "CUI", "LOCALUNIT", "OBSTYPE", "OBSTYPE_STD_UNITS"),
    "pat" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "document" -> ((df: DataFrame) => {
      val zcm = table("cdr.zcm_obstype_code").filter("groupid = '" + config(GROUP) + "' and datasrc = 'document'")
      df.filter("PATIENT_ID IS NOT NULL AND ORDER_DATETIME IS NOT NULL AND CLINICAL_ORDER_TYPE IS NOT NULL AND DELETED_DATETIME IS NULL")
        .drop("DELETED_DATETIME")
        .join(zcm, df("CLINICAL_ORDER_TYPE") === zcm("OBSCODE"), "inner")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("document")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("document"),
    "LOCALRESULT" -> mapFrom("CLINICAL_ORDER_TYPE"),
    "LOCALCODE" -> mapFrom("CLINICAL_ORDER_TYPE"),
    "OBSDATE" -> mapFrom("ORDER_DATETIME"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "FACILITYID" -> mapFrom("DEPARTMENT_ID"),
    "LOCAL_OBS_UNIT" -> mapFrom("LOCALUNIT"),
    "OBSTYPE" -> mapFrom("OBSTYPE")
  )

  afterMap = (df: DataFrame) => {
    df.dropDuplicates(List("DATASRC", "LOCALRESULT", "LOCALCODE", "OBSDATE", "PATIENTID", "ENCOUNTERID", "FACILITYID", "LOCAL_OBS_UNIT", "OBSTYPE"))
  }
}


// test
//  val ob = new ObservationDocument(cfg); val obs = build(ob); obs.show ; obs.count;

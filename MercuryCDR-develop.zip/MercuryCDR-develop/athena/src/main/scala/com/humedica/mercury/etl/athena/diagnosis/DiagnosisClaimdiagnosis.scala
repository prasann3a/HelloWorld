package com.humedica.mercury.etl.athena.diagnosis

import com.humedica.mercury.etl.core.engine.{Engine,EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.athena.util.UtilSplitTable
import scala.collection.JavaConverters._

class DiagnosisClaimdiagnosis(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "claimdiagnosis",
    "chargediagnosis",
    "icdcodeall",
    "fileIdDates:athena.util.UtilFileIdDates",
    "dedupedClaim:athena.util.UtilDedupedClaim",
    "dedupedTrans:athena.util.UtilDedupedTransaction",
    "dedupedTranscl:athena.util.UtilDedupedTransactionClaim",
    "dedupedCE:athena.util.UtilDedupedClinicalEncounter",
    "pat:athena.util.UtilSplitPatient"
  )

  columnSelect = Map(
    "claimdiagnosis" -> List("FILEID", "CLAIM_DIAGNOSIS_ID", "DELETED_DATETIME", "CLAIM_ID", "DIAGNOSIS_CODE", "DIAGNOSIS_CODESET_NAME", "ICD_CODE_ID", "SEQUENCE_NUMBER"),
    "chargediagnosis" -> List("FILEID", "CHARGE_DIAGNOSIS_ID", "CLAIM_DIAGNOSIS_ID", "DELETED_DATETIME", "CHARGE_ID"),
    "icdcodeall" -> List("FILEID", "ICD_CODE_ID", "DIAGNOSIS_CODE_SET", "EFFECTIVE_DATE", "EXPIRATION_DATE", "UNSTRIPPED_DIAGNOSIS_CODE"),
    "dedupedClaim" -> List("CLAIM_APPOINTMENT_ID", "CLAIM_SERVICE_DATE", "RENDERING_PROVIDER_ID", "PATIENT_ID", "CLAIM_ID"),
    "dedupedTrans" -> List("CHARGE_ID"),
    "dedupedTranscl" -> List("CLAIM_ID", "CLAIM_APPOINTMENT_ID", "CLAIM_SERVICE_DATE", "CLAIM_PATIENT_ID", "RENDERING_PROVIDER_ID"),
    "dedupedCE" -> List("CLINICAL_ENCOUNTER_ID", "CLAIM_ID", "APPOINTMENT_ID"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "pat" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "claimdiagnosis" -> ((df: DataFrame) => {
      val cd_joined = table("chargediagnosis").join(table("fileIdDates"), Seq("FILEID"), "left_outer").coalesce(10000)
      val groups = Window.partitionBy(cd_joined("CHARGE_DIAGNOSIS_ID")).orderBy(cd_joined("FILEDATE").desc_nulls_last)
      val cd_joined2 = cd_joined.withColumn("rn", row_number.over(groups)).filter("rn = 1 and DELETED_DATETIME is null").drop("rn", "DELETED_DATETIME", "FILEDATE", "FILEID")
      val fil = table("dedupedTrans").select("CHARGE_ID").distinct()
      val cd_fil = cd_joined2.join(fil, Seq("CHARGE_ID"), "inner")
      val dx_joined = df.join(table("fileIdDates"), Seq("FILEID"), "left_outer")
        .join(cd_fil, Seq("CLAIM_DIAGNOSIS_ID"), "left_outer").coalesce(10000)
      val groups2 = Window.partitionBy(dx_joined("CLAIM_DIAGNOSIS_ID"), dx_joined("CHARGE_DIAGNOSIS_ID")).orderBy(dx_joined("FILEDATE").desc_nulls_last, dx_joined("FILEID").desc_nulls_last)
      dx_joined.withColumn("rn", row_number.over(groups2)).filter("rn = 1 and DELETED_DATETIME is null").drop("rn", "DELETED_DATETIME").coalesce(10000)
    }),
    "icdcodeall" -> ((df: DataFrame) => {
      val fil = df.filter("DIAGNOSIS_CODE_SET = 'ICD10'").withColumnRenamed("ICD_CODE_ID", "ICD_CODE_ID_dict")
      val joined = fil.join(table("fileIdDates"), Seq("FILEID"), "left_outer")
      val groups = Window.partitionBy(joined("ICD_CODE_ID_dict")).orderBy(joined("FILEDATE").desc_nulls_last, joined("FILEID").desc_nulls_last)
      joined.withColumn("rn", row_number.over(groups)).filter("rn = 1").drop("rn")
    }),
    "dedupedClaim" -> ((df: DataFrame) => {
      df.withColumnRenamed("CLAIM_APPOINTMENT_ID", "CLAIM_APPOINTMENT_ID_clm")
        .withColumnRenamed("CLAIM_SERVICE_DATE", "CLAIM_SERVICE_DATE_clm")
        .withColumnRenamed("RENDERING_PROVIDER_ID", "RENDERING_PROVIDER_ID_clm")
        .withColumnRenamed("PATIENT_ID", "PATIENT_ID_clm")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    val ce_cols = dfs("dedupedCE").columns.map(c => dfs("dedupedCE")(c).as(c + "_two"))
    val dedupedCE2 = dfs("dedupedCE").select(ce_cols: _*)
    dfs("claimdiagnosis")
      .join(dfs("dedupedClaim"), Seq("CLAIM_ID"), "left_outer")
      .join(dfs("dedupedTranscl"), Seq("CLAIM_ID"), "left_outer")
      .join(dfs("dedupedCE"), Seq("CLAIM_ID"), "left_outer")
      .join(dedupedCE2, dedupedCE2("APPOINTMENT_ID_two") === coalesce(dfs("dedupedClaim")("CLAIM_APPOINTMENT_ID_clm"), dfs("dedupedTranscl")("CLAIM_APPOINTMENT_ID")), "left_outer")
      .join(dfs("icdcodeall"), dfs("icdcodeall")("ICD_CODE_ID_dict") === dfs("claimdiagnosis")("ICD_CODE_ID")
        && from_unixtime(unix_timestamp(coalesce(dfs("dedupedClaim")("CLAIM_SERVICE_DATE_clm"), dfs("dedupedTranscl")("CLAIM_SERVICE_DATE")))).between(
        from_unixtime(unix_timestamp(dfs("icdcodeall")("EFFECTIVE_DATE"))), from_unixtime(unix_timestamp(coalesce(dfs("icdcodeall")("EXPIRATION_DATE"), current_timestamp)))),
        "left_outer")
      .join(dfs("pat"), dfs("pat")("PATIENT_ID") === coalesce(dfs("dedupedClaim")("PATIENT_ID_clm"), dfs("dedupedTranscl")("CLAIM_PATIENT_ID")), patJoinType)
  }

  afterJoin = (df: DataFrame) => {
    df.withColumn("ENC_ID_t", concat(lit("a."), df("CLAIM_APPOINTMENT_ID"))).drop("CLAIM_APPOINTMENT_ID")
  }

  map = Map(
    "DATASRC" -> literal("claimdiagnosis"),
    "PATIENTID" -> cascadeFrom(Seq("PATIENT_ID_clm", "CLAIM_PATIENT_ID")),
    "ENCOUNTERID" -> cascadeFrom(Seq("CLINICAL_ENCOUNTER_ID", "CLINICAL_ENCOUNTER_ID_two", "ENC_ID_t")),
    "DX_TIMESTAMP" -> cascadeFrom(Seq("CLAIM_SERVICE_DATE_clm", "CLAIM_SERVICE_DATE")),
    "LOCALDIAGNOSIS" -> cascadeFrom(Seq("ICD_CODE_ID_dict", "DIAGNOSIS_CODE")),
    "LOCALDIAGNOSISPROVIDERID" -> cascadeFrom(Seq("RENDERING_PROVIDER_ID_clm", "RENDERING_PROVIDER_ID")),
    "SOURCEID" -> mapFrom("CHARGE_ID"),
    "MAPPEDDIAGNOSIS" -> cascadeFrom(Seq("UNSTRIPPED_DIAGNOSIS_CODE", "DIAGNOSIS_CODE")),
    "CODETYPE" -> cascadeFrom(Seq("DIAGNOSIS_CODE_SET", "DIAGNOSIS_CODESET_NAME")),
    "SEQ" -> mapFrom("SEQUENCE_NUMBER")
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.filter("DX_TIMESTAMP is not null and LOCALDIAGNOSIS is not null and MAPPEDDIAGNOSIS is not null and PATIENTID is not null")
    val groups = Window.partitionBy(df1("PatientId"), df1("Dx_Timestamp"), df1("EncounterID"), df1("SourceID"), df1("SEQ"))
      .orderBy(
        when (df1("codetype") === "ICD9" && date_format(df1("dx_timestamp"),"yyyy-MM") < "2015-10" ,lit("1"))
        .when(df1("codetype") === "ICD10" &&  date_format(df1("dx_timestamp"),"yyyy-MM") >= "2015-10"  ,lit("1"))
          .otherwise(lit("2")),df1("LOCALDIAGNOSISPROVIDERID").asc_nulls_last)
    val df2 = df1.withColumn("rn", row_number.over(groups))
              .filter("rn = 1")
              .drop("rn")

    val cols = Engine.schema.getStringList("Diagnosis").asScala.map(_.split("-")(0).toUpperCase())
    df2.select(cols.map(col): _*).distinct
  }

}
package com.humedica.mercury.etl.athena.observation

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine,EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import scala.collection.JavaConverters._

class ObservationPatientassertion(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patientassertion"
    , "pat:athena.util.UtilSplitPatient"
    , "fileIdDates:athena.util.UtilFileIdDates"
    , "cdr.zcm_obstype_code")


  columnSelect = Map(
    "patientassertion" -> List("PATIENT_ASSERTION_KEY", "PATIENT_ASSERTION_VALUE", "PATIENT_ID", "PATIENT_ASSERTION_ID", "HUM_TYPE", "FILEID", "DELETED_DATETIME"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "DATASRC", "OBSCODE", "CUI", "LOCALUNIT", "OBSTYPE", "OBSTYPE_STD_UNITS"),
    "pat" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "patientassertion" -> ((df: DataFrame) => {
      val fd = table("fileIdDates")
      val zcm = table("cdr.zcm_obstype_code").filter("groupid = '" + config(GROUP) + "' and datasrc = 'patientassertion'")
      val pa_df = safe_to_date(df, "PATIENT_ASSERTION_VALUE", "OBSDATE", "MM/dd/yyyy")
        .filter("PATIENT_ASSERTION_KEY <> 'ASSERTIONVALUE_DEPRESSIONASSESSMENTANDPLAN' AND PATIENT_ID IS NOT NULL AND DELETED_DATETIME IS NULL AND PATIENT_ASSERTION_KEY IS NOT NULL AND OBSDATE IS NOT NULL")
        .drop("DELETED_DATETIME")
        .join(fd, Seq("FILEID"), "left_outer")
      val groups = Window.partitionBy(pa_df("OBSDATE"), pa_df("PATIENT_ASSERTION_ID"), pa_df("HUM_TYPE")).orderBy(pa_df("FILEDATE").desc_nulls_last, pa_df("FILEID").desc_nulls_last)
      pa_df
        .withColumn("rn", row_number.over(groups))
        .filter("rn=1")
        .drop("rn")
        .join(zcm, pa_df("PATIENT_ASSERTION_KEY") === zcm("OBSCODE"), "inner")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientassertion")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("patientassertion"),
    "LOCALRESULT" -> mapFrom("PATIENT_ASSERTION_KEY"),
    "LOCALCODE" -> mapFrom("PATIENT_ASSERTION_KEY"),
    "OBSDATE" -> mapFrom("OBSDATE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "LOCAL_OBS_UNIT" -> mapFrom("LOCALUNIT"),
    "OBSTYPE" -> mapFrom("OBSTYPE")
  )

  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Observation").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*)
      .distinct
  }
}


// test
//  val ob = new ObservationPatientassertion(cfg); val obs = build(ob,true); obs.show ; obs.count;

package com.humedica.mercury.etl.athena.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import scala.collection.JavaConverters._

class MedicationmapsrcPatientmedication(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "patientmedication",
    "document",
    "medication"
  )

  columnSelect = Map(
    "patientmedication" -> List("FILEID", "NDC", "DOCUMENT_ID", "MEDICATION_NAME", "DOCUMENT_DESCRIPTION", "RXNORM", "MEDICATION_ID", "PATIENT_MEDICATION_ID"),
    "document" -> List("DOCUMENT_ID", "FILEID", "FBD_MED_ID"),
    "medication" -> List("MEDICATION_ID", "FILEID", "NDC", "MEDICATION_NAME", "RXNORM", "FDB_MED_ID")
  )

  beforeJoin = Map(
    "patientmedication" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("PATIENT_MEDICATION_ID")).orderBy(df("FILEID").desc_nulls_last)
      df.withColumn("pat_med_rn", row_number.over(groups)).filter("pat_med_rn = 1").drop("pat_med_rn")
    }),
    "document" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("DOCUMENT_ID")).orderBy(df("FILEID").desc_nulls_last)
      df.withColumn("doc_rn", row_number.over(groups)).filter("doc_rn = 1").drop("doc_rn")
    }),
    "medication" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("MEDICATION_ID")).orderBy(df("FILEID").desc_nulls_last)
      df.withColumnRenamed("MEDICATION_NAME", "MED_MEDICATION_NAME")
        .withColumnRenamed("NDC", "MED_NDC")
        .withColumnRenamed("RXNORM", "MED_RXNORM")
        .withColumn("med_rn", row_number.over(groups)).filter("med_rn = 1").drop("med_rn")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("patientmedication").join(table("document"), table("patientmedication")("DOCUMENT_ID") === table("document")("DOCUMENT_ID"), "left_outer")
                            .join(table("medication"), table("medication")("FDB_MED_ID") === table("document")("FBD_MED_ID"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("patientmedication"),
    "LOCALMEDCODE" -> ((col, df) => df.withColumn(col, coalesce(df("FBD_MED_ID"), when(df("RXNORM").isNull, concat(lit("r."), df("RXNORM"))).otherwise(null)))),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, coalesce(df("MED_NDC"), df("NDC")))),
    "RXNORM_CODE" -> ((col, df) => df.withColumn(col, coalesce(df("MED_RXNORM"), df("RXNORM"))))
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALNDC"), df("RXNORM_CODE"))
    val df1 = df.withColumn("NUM_RECS", count("*").over(groups))
                .withColumn("NO_NDC", sum(when(df("LOCALNDC").isNull, 1).otherwise(0)).over(groups))
                .withColumn("HAS_NDC", sum(when(df("LOCALNDC").isNull, 0).otherwise(1)).over(groups))
                .withColumn("LOCALGENERIC", min("MED_MEDICATION_NAME").over(groups))
                .withColumn("LOCALDESCRIPTION", min(coalesce(df("MED_MEDICATION_NAME"), df("DOCUMENT_DESCRIPTION"))).over(groups))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct().filter("LOCALMEDCODE is NOT NULL")
  }
}

//val a = new MedicationmapsrcPatientmedication(cfg); val med_s = build(a, allColumns = true);

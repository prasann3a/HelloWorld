package com.humedica.mercury.etl.athena.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcPatientvaccinepv(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "patientvaccine"
  )

  columnSelect = Map(
    "patientvaccine" -> List("CVX", "VACCINE_NAME", "HUM_TYPE")
  )

  beforeJoin = Map(
    "patientvaccine" -> ((df: DataFrame) => {
      df.filter("HUM_TYPE = 'PATIENTVACCINE'")
    })
  )

  map = Map(
    "DATASRC" -> literal("patientvaccine_pv"),
    "LOCALMEDCODE" -> mapFrom("CVX"),
    "LOCALDESCRIPTION" -> mapFrom("VACCINE_NAME")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALDESCRIPTION"))
    val df1 = df.withColumn("NUM_RECS", count("*").over(groups))
      .withColumn("NO_NDC", count("*").over(groups))
      .withColumn("HAS_NDC", lit(0))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct().filter("LOCALMEDCODE is NOT NULL")
  }
}

//val a = new MedicationmapsrcPatientvaccinepv(cfg); val med_s = build(a, allColumns = true);

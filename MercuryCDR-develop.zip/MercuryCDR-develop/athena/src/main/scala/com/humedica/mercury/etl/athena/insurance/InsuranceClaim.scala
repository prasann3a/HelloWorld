package com.humedica.mercury.etl.athena.insurance

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class InsuranceClaim(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "patientinsurance",
    "payer",
    "fileIdDates:athena.util.UtilFileIdDates",
    "tempClm:athena.util.UtilDedupedClaim",
    "tempClinEnc:athena.util.UtilDedupedClinicalEncounter",
    "pat:athena.util.UtilSplitPatient"
  )

  columnSelect = Map(
    "patientinsurance" -> List("POLICY_GROUP_NUMBER", "SEQUENCE_NUMBER", "POLICY_ID_NUMBER", "CANCELLATION_DATE", "ISSUE_DATE", "PATIENT_INSURANCE_ID",
      "EXPIRATION_DATE", "FILEID", "INSURANCE_PACKAGE_ID"),
    "payer" -> List("INSURANCE_PACKAGE_TYPE", "INSURANCE_REPORTING_CATEGORY", "INSURANCE_PACKAGE_ID", "INSURANCE_PACKAGE_NAME",
      "DELETED_DATETIME", "FILEID"),
    "tempClm" -> List("CLAIM_APPOINTMENT_ID", "CLAIM_PRIMARY_PATIENT_INS_ID", "CLAIM_SECONDARY_PATIENT_INS_ID", "CLAIM_SERVICE_DATE", "SERVICE_DEPARTMENT_ID",
      "PATIENT_ID"),
    "tempClinEnc" -> List("APPOINTMENT_ID", "CLINICAL_ENCOUNTER_ID"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "pat" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "payer" -> ((df: DataFrame) => {
      val joined = df.join(table("fileIdDates"), Seq("FILEID"), "left_outer").coalesce(1000)
      val groups = Window.partitionBy(joined("INSURANCE_PACKAGE_ID")).orderBy(joined("FILEDATE").desc_nulls_last, joined("FILEID").desc_nulls_last)
      joined.withColumn("rn", row_number.over(groups)).filter("rn = 1 and DELETED_DATETIME is null")
        .drop("rn", "DELETED_DATETIME", "FILEID", "FILEDATE")
    }),
    "patientinsurance" -> ((df: DataFrame) => {
      val joined = df.join(table("fileIdDates"), Seq("FILEID"), "left_outer").coalesce(1000)
      val groups = Window.partitionBy(joined("PATIENT_INSURANCE_ID")).orderBy(joined("FILEDATE").desc_nulls_last, joined("FILEID").desc_nulls_last)
      joined.withColumn("rn", row_number.over(groups)).filter("rn = 1").drop("rn", "FILEID", "FILEDATE")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    val payer_cols = dfs("payer").columns.map(c => dfs("payer")(c).as(c + "_sec"))
    val payer2 = dfs("payer").select(payer_cols: _*)
    val patins_cols = dfs("patientinsurance").columns.map(c => dfs("patientinsurance")(c).as(c + "_sec"))
    val patins2 = dfs("patientinsurance").select(patins_cols: _*)
    dfs("tempClm")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
      .join(dfs("tempClinEnc"), dfs("tempClm")("CLAIM_APPOINTMENT_ID") === dfs("tempClinEnc")("APPOINTMENT_ID"), "left_outer")
      .join(dfs("patientinsurance"), dfs("tempClm")("CLAIM_PRIMARY_PATIENT_INS_ID") === dfs("patientinsurance")("PATIENT_INSURANCE_ID")
        && dfs("tempClm")("CLAIM_PRIMARY_PATIENT_INS_ID") =!= lit("0"), "left_outer")
      .join(patins2, dfs("tempClm")("CLAIM_SECONDARY_PATIENT_INS_ID") === patins2("PATIENT_INSURANCE_ID_sec")
        && dfs("tempClm")("CLAIM_SECONDARY_PATIENT_INS_ID") =!= lit("0"), "left_outer")
      .join(dfs("payer"), Seq("INSURANCE_PACKAGE_ID"), "left_outer")
      .join(payer2, Seq("INSURANCE_PACKAGE_ID_sec"), "left_outer")
  }

  afterJoin = (df: DataFrame) => {
    val primary = df.withColumn("ENROLLENDDT", coalesce(df("CANCELLATION_DATE"), df("EXPIRATION_DATE")))
      .withColumnRenamed("ISSUE_DATE", "ENROLLSTARTDT")
      .withColumnRenamed("POLICY_GROUP_NUMBER", "GROUPNBR")
      .withColumnRenamed("SEQUENCE_NUMBER", "INSURANCEORDER")
      .withColumnRenamed("POLICY_ID_NUMBER", "POLICYNUMBER")
      .withColumnRenamed("INSURANCE_PACKAGE_TYPE", "PLANTYPE")
      .withColumn("PAYORCODE", df("INSURANCE_REPORTING_CATEGORY"))
      .withColumnRenamed("INSURANCE_REPORTING_CATEGORY", "PAYORNAME")
      .withColumnRenamed("INSURANCE_PACKAGE_ID", "PLANCODE")
      .withColumnRenamed("INSURANCE_PACKAGE_NAME", "PLANNAME")
      .select("CLAIM_SERVICE_DATE", "PATIENT_ID", "SERVICE_DEPARTMENT_ID", "CLAIM_APPOINTMENT_ID", "CLINICAL_ENCOUNTER_ID",
        "ENROLLENDDT", "ENROLLSTARTDT", "GROUPNBR", "INSURANCEORDER", "PAYORCODE", "PAYORNAME", "PLANCODE", "PLANNAME", "PLANTYPE", "POLICYNUMBER")
      .filter("PLANCODE is not null and PLANNAME is not null and PATIENT_ID is not null and CLAIM_SERVICE_DATE is not null").coalesce(1000)
    val secondary = df.withColumn("ENROLLENDDT", coalesce(df("CANCELLATION_DATE_sec"), df("EXPIRATION_DATE")))
      .withColumnRenamed("ISSUE_DATE_sec", "ENROLLSTARTDT")
      .withColumnRenamed("POLICY_GROUP_NUMBER_sec", "GROUPNBR")
      .withColumnRenamed("SEQUENCE_NUMBER_sec", "INSURANCEORDER")
      .withColumnRenamed("POLICY_ID_NUMBER_sec", "POLICYNUMBER")
      .withColumnRenamed("INSURANCE_PACKAGE_TYPE_sec", "PLANTYPE")
      .withColumn("PAYORCODE", df("INSURANCE_REPORTING_CATEGORY_sec"))
      .withColumnRenamed("INSURANCE_REPORTING_CATEGORY_sec", "PAYORNAME")
      .withColumnRenamed("INSURANCE_PACKAGE_ID_sec", "PLANCODE")
      .withColumnRenamed("INSURANCE_PACKAGE_NAME_sec", "PLANNAME")
      .select("CLAIM_SERVICE_DATE", "PATIENT_ID", "SERVICE_DEPARTMENT_ID", "CLAIM_APPOINTMENT_ID", "CLINICAL_ENCOUNTER_ID",
        "ENROLLENDDT", "ENROLLSTARTDT", "GROUPNBR", "INSURANCEORDER", "PAYORCODE", "PAYORNAME", "PLANCODE", "PLANNAME", "PLANTYPE", "POLICYNUMBER")
      .filter("PLANCODE is not null and PLANNAME is not null and PATIENT_ID is not null and CLAIM_SERVICE_DATE is not null").coalesce(1000)
    primary.union(secondary)
  }

  map = Map(
    "DATASRC" -> literal("claim"),
    "INS_TIMESTAMP" -> mapFrom("CLAIM_SERVICE_DATE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "FACILITYID" -> mapFrom("SERVICE_DEPARTMENT_ID"),
    "SOURCEID" -> mapFrom("CLAIM_APPOINTMENT_ID"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PatientID"), df("EncounterID"), df("Ins_Timestamp"), df("Payorcode"), df("Plantype"), df("INSURANCEORDER"), df("PLANCODE"), df("ENROLLSTARTDT"))
      .orderBy(df("enrollenddt").desc_nulls_first)
    df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1")
      .drop("rn")
  }

}
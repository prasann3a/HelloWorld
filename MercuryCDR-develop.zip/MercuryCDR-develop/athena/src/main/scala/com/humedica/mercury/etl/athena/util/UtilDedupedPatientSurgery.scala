package com.humedica.mercury.etl.athena.util

import com.humedica.mercury.etl.core.engine.EntitySource
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


class UtilDedupedPatientSurgery(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  cacheMe = true

  columns = List("APPROVED_BY", "APPROVED_DATETIME", "CHART_ID", "CLINICAL_ENCOUNTER_ID", "CLINICAL_ORDER_TYPE_GROUP",
    "CLINICAL_PROVIDER_ID", "CONTEXT_ID", "CONTEXT_NAME", "CONTEXT_PARENTCONTEXTID", "CREATED_BY", "CREATED_DATETIME",
    "DEACTIVATED_BY", "DEACTIVATED_DATETIME", "DELETED_BY", "DELETED_DATETIME", "FILEID", "HUM_PROCEDURE", "HUM_TYPE",
    "IMAGE_EXISTS_YN", "NOTE", "PATIENT_ID", "PATIENT_SURGERY_ID", "PROCEDURE_CODE", "PROVIDER_USERNAME", "REACTIVATED_BY",
    "REACTIVATED_DATETIME", "SURGERY_DATETIME")

  tables = List("patientsurgery",
    "fileExtractDates:athena.util.UtilFileIdDates",
    "pat:athena.util.UtilSplitPatient")

  columnSelect = Map(
    "patientsurgery" -> List("APPROVED_BY", "APPROVED_DATETIME", "CHART_ID", "CLINICAL_ENCOUNTER_ID", "CLINICAL_ORDER_TYPE_GROUP",
      "CLINICAL_PROVIDER_ID", "CONTEXT_ID", "CONTEXT_NAME", "CONTEXT_PARENTCONTEXTID", "CREATED_BY", "CREATED_DATETIME",
      "DEACTIVATED_BY", "DEACTIVATED_DATETIME", "DELETED_BY", "DELETED_DATETIME", "FILEID", "HUM_PROCEDURE", "HUM_TYPE",
      "IMAGE_EXISTS_YN", "NOTE", "PATIENT_ID", "PATIENT_SURGERY_ID", "PROCEDURE_CODE", "PROVIDER_USERNAME", "REACTIVATED_BY",
      "REACTIVATED_DATETIME", "SURGERY_DATETIME"),
    "fileExtractDates" -> List("FILEID", "FILEDATE"),
    "pat" -> List("PATIENT_ID")
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientsurgery")
      .join(dfs("fileExtractDates"), Seq("FILEID"), "left_outer")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
  }


  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENT_SURGERY_ID"), df("HUM_TYPE"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)
    df.withColumn("dedupe_row", row_number.over(groups))
      .filter("dedupe_row = 1 and deleted_datetime is null and " +
        "(deactivated_datetime is null or (deactivated_datetime is not null and reactivated_datetime is not null))")
  }

}

package com.humedica.mercury.etl.athena.providerpatientrelation

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProviderpatientrelationPatient(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patient",
    "fileIdDates:athena.util.UtilFileIdDates",
    "splitpatient:athena.util.UtilSplitPatient",
    "cdr.map_pcp_order",
    "cdr.map_predicate_values")

  columnSelect = Map(
    "patient" -> List("PATIENT_ID", "PRIMARY_PROVIDER_ID", "FILEID"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "splitpatient" -> List("PATIENT_ID"),
    "cdr.map_pcp_order" -> List("GROUPID", "CLIENT_DS_ID", "DATASRC", "PCP_EXCLUDE_FLG")
  )

  beforeJoin = Map(
    "patient" -> includeIf("patient_id is not null and primary_provider_id is not null"),
    "cdr.map_pcp_order" -> ((df: DataFrame) => {
      df.filter("groupid = '" + config(GROUPID) + "' and client_ds_id = '" + config(CLIENT_DS_ID) + "' and datasrc = 'patient'")
        .drop("GROUPID", "CLIENT_DS_ID", "DATASRC")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patient")
      .join(dfs("fileIdDates"), Seq("FILEID"), "inner")
      .join(dfs("splitpatient"), Seq("PATIENT_ID"), patJoinType)
      .join(dfs("cdr.map_pcp_order"), dfs("cdr.map_pcp_order")("pcp_exclude_flg") === lit("Y"), "left_anti")
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(to_date(df("FILEDATE")), df("PATIENT_ID"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)

    df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1")
      .drop("rn")
  }


  map = Map(
    "DATASRC" -> literal("patient"),
    "LOCALRELSHIPCODE" -> literal("PCP"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "PROVIDERID" -> mapFrom("PRIMARY_PROVIDER_ID"),
    "STARTDATE" -> mapFrom("FILEDATE"),
    "ENDDATE" -> ((col: String, df: DataFrame) => {
      val load_ppr = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "ATHENA_DWF", "CALL_LOAD_PROV_PAT_REL", "PROV_PAT_REL", "N/A")
      df.withColumn(col, when(lit("Y").isin(load_ppr: _*), current_timestamp()).otherwise(null))
    })
  )

}
package com.humedica.mercury.etl.athena.labmapperdict

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class LabmapperdictVitalsign(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("vitalsign",
    "cdr.zcm_obstype_code",
    "fileExtractDates:athena.util.UtilFileIdDates")

  columnSelect = Map(
    "vitalsign" -> List("HUM_KEY", "DB_UNIT", "FILEID"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "OBSTYPE", "OBSCODE"),
    "fileExtractDates" -> List("FILEID", "FILEDATE")
  )

  beforeJoin = Map(
    "cdr.zcm_obstype_code" -> ((df: DataFrame) => {
      df.filter("groupid = '" + config(GROUP) + "' and obstype = 'LABRESULT'")
        .drop("GROUPID")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("vitalsign")
      .join(dfs("cdr.zcm_obstype_code"), dfs("vitalsign")("HUM_KEY") === dfs("cdr.zcm_obstype_code")("OBSCODE"), "inner")
      .join(dfs("fileExtractDates"), Seq("FILEID"), "left_outer")
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("HUM_KEY"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)

    df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1 and hum_key is not null")
  }

  map = Map(
    "LOCALCODE" -> mapFrom("HUM_KEY"),
    "LOCALNAME" -> mapFrom("HUM_KEY"),
    "LOCALUNITS" -> mapFrom("DB_UNIT")
  )

  afterMap = includeIf("localcode is not null")

}
package com.humedica.mercury.etl.athena.provideridentifier

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame

/**
  * Auto-generated on 09/21/2018
  */


class ProvideridentifierReferringprovider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("referringprovider:athena.util.UtilDedupedReferringProvider",
    "cdr.ref_cmsnpi")

  columnSelect = Map(
    "referringprovider" -> List("NPI_NUMBER", "REFERRING_PROVIDER_ID"),
    "cdr.ref_cmsnpi" -> List("NPI", "ENTITY_TYPE_CODE")
  )

  beforeJoin = Map(
    "referringprovider" -> includeIf("referring_provider_id is not null")
  )

  join = noJoin()

  map = Map(
    "ID_TYPE" -> literal("NPI"),
    "ID_VALUE" -> mapFrom("NPI_NUMBER"),
    "PROVIDER_ID" -> mapFrom("REFERRING_PROVIDER_ID", prefix = "rp.")
  )

  afterMap = includeIf("id_value is not null")

  joinExceptions = Map(
    "H984728_ATHENA_DWF_4" -> ((dfs: Map[String, DataFrame]) => {
      dfs("referringprovider")
        .join(dfs("cdr.ref_cmsnpi"), dfs("referringprovider")("NPI_NUMBER") === dfs("cdr.ref_cmsnpi")("NPI"), "left_outer")
    })
  )

  mapExceptions = Map(
    ("H984728_ATHENA_DWF_4", "ID_VALUE") -> mapFromSecondColumnValueIsIn("NPI", "ENTITY_TYPE_CODE", Seq("1"))
  )

}
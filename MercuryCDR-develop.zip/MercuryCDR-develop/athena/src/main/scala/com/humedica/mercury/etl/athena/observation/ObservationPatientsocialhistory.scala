package com.humedica.mercury.etl.athena.observation

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class ObservationPatientsocialhistory(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "patsocialhistory:athena.util.UtilDedupedPatientSocialHistory",
    "revsocialhistory:athena.util.UtilDedupedReviewedSocialHistory",
    "tobaccosocialhistory:athena.util.UtilDedupedRecentTobaccoSocialHistory",
    "cdr.zcm_obstype_code",
    "pat:athena.util.UtilSplitPatient"
  )

  columnSelect = Map(
    "patsocialhistory" -> List("SOCIAL_HISTORY_ID", "SOCIAL_HISTORY_KEY", "PATIENT_ID", "SOCIAL_HISTORY_ANSWER", "CREATED_DATETIME", "FD_FILEDATE",
      "SOCIAL_HISTORY_NAME", "DELETED_DATETIME", "FILEID"),
    "revsocialhistory" -> List("DELETED_DATETIME", "SOCIAL_HISTORY_ANSWER", "SOCIAL_HISTORY_KEY", "REVIEWED_DATE", "PATIENT_ID"),
    "tobaccosocialhistory" -> List("DELETED_DATETIME", "SOCIAL_HISTORY_ANSWER", "SOCIAL_HISTORY_KEY", "TOBACCO_DATE", "PATIENT_ID"),
    "cdr.zcm_obstype_code" -> List("OBSTYPE", "OBSCODE", "OBSTYPE_STD_UNITS", "LOCALUNIT", "GROUPID", "DATASRC"),
    "pat" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "patsocialhistory" -> ((df: DataFrame) => {
      val df1 = df.filter("SOCIAL_HISTORY_KEY <> 'REVIEWED.SOCIALHISTORY' AND SOCIAL_HISTORY_KEY <> 'SOCIALHISTORY.MOSTRECENTTOBACCOUSESCREENING'")
        .withColumn("OBSDATE", when(df("CREATED_DATETIME") > df("FD_FILEDATE") || df("FD_FILEDATE") > current_timestamp, df("CREATED_DATETIME"))
          .otherwise(coalesce(df("FD_FILEDATE"), df("CREATED_DATETIME"))))
      val groups = Window.partitionBy(df1("SOCIAL_HISTORY_ID"), df1("SOCIAL_HISTORY_ANSWER"), df1("OBSDATE"))
        .orderBy(df1("FILEID").desc_nulls_last)
      df1.withColumn("rn", row_number.over(groups))
        .filter("rn = 1")
        .withColumnRenamed("SOCIAL_HISTORY_ANSWER", "LOCALRESULT")
        .select("LOCALRESULT", "SOCIAL_HISTORY_KEY", "OBSDATE", "PATIENT_ID", "DELETED_DATETIME")
    }),
    "revsocialhistory" -> ((df: DataFrame) => {
      df.withColumnRenamed("SOCIAL_HISTORY_ANSWER", "LOCALRESULT")
        .withColumnRenamed("REVIEWED_DATE", "OBSDATE")
        .select("LOCALRESULT", "SOCIAL_HISTORY_KEY", "OBSDATE", "PATIENT_ID", "DELETED_DATETIME")
    }),
    "tobaccosocialhistory" -> ((df: DataFrame) => {
      df.withColumnRenamed("SOCIAL_HISTORY_ANSWER", "LOCALRESULT")
        .withColumnRenamed("TOBACCO_DATE", "OBSDATE")
        .select("LOCALRESULT", "SOCIAL_HISTORY_KEY", "OBSDATE", "PATIENT_ID", "DELETED_DATETIME")
    }),
    "cdr.zcm_obstype_code" -> includeIf("GROUPID = '" + config(GROUP) + "' AND DATASRC = 'patientsocialhistory' and CUI <> 'CH002048'")
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    val un = dfs("patsocialhistory").union(dfs("revsocialhistory")).union(dfs("tobaccosocialhistory"))
    un.join(dfs("cdr.zcm_obstype_code"), un("SOCIAL_HISTORY_KEY") === dfs("cdr.zcm_obstype_code")("OBSCODE"), "inner")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("patientsocialhistory"),
    "LOCALCODE" -> mapFrom("SOCIAL_HISTORY_KEY"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "LOCAL_OBS_UNIT" -> mapFrom("LOCALUNIT"),
    "OBSTYPE" -> mapFrom("OBSTYPE")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID"), df("LOCALCODE"), df("OBSTYPE"), df("LOCALRESULT"), substring(df("OBSDATE"), 1, 10))
      .orderBy(df("OBSDATE").desc_nulls_last)
    df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1 and PATIENTID is not null and OBSDATE is not null and LOCALRESULT is not null and DELETED_DATETIME is null")
  }

}
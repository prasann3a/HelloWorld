package com.humedica.mercury.etl.athena.provider

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProviderReferringprovider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("referringprovider:athena.util.UtilDedupedReferringProvider",
    "cdr.ref_cmsnpi")

  columnSelect = Map(
    "referringprovider" -> List("REFERRING_PROVIDER_ID", "REFERRING_PROVIDER_NAME", "NPI_NUMBER"),
    "cdr.ref_cmsnpi" -> List("NPI", "ENTITY_TYPE_CODE")
  )

  beforeJoin = Map(
    "referringprovider" -> includeIf("referring_provider_id is not null")
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> literal("referringprovider"),
    "LOCALPROVIDERID" -> mapFrom("REFERRING_PROVIDER_ID", prefix = "rp."),
    "CREDENTIALS" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(regexp_extract(df("REFERRING_PROVIDER_NAME"), "(MD|DO|NP)", 1) === "", null)
        .otherwise(regexp_extract(df("REFERRING_PROVIDER_NAME"), "(MD|DO|NP)", 1)))
    }),
    "PROVIDERNAME" -> mapFrom("REFERRING_PROVIDER_NAME"),
    "NPI" -> mapFrom("NPI_NUMBER"),
    "SUFFIX" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(regexp_extract(df("REFERRING_PROVIDER_NAME"), "(JR|SR|III)", 1) === "", null)
        .otherwise(regexp_extract(df("REFERRING_PROVIDER_NAME"), "(JR|SR|III)", 1)))
    })
  )

  afterMap = (df: DataFrame) => {
    val npiProv = df.filter("npi is not null")
      .withColumn("LOCALPROVIDERID", concat(lit("npi."), df("NPI")))

    df.union(npiProv)
  }

  joinExceptions = Map(
    "H984728_ATHENA_DWF_4" -> ((dfs: Map[String, DataFrame]) => {
      dfs("referringprovider")
        .join(dfs("cdr.ref_cmsnpi"), dfs("referringprovider")("NPI_NUMBER") === dfs("cdr.ref_cmsnpi")("NPI"), "left_outer")
    })
  )

  mapExceptions = Map(
    ("H984728_ATHENA_DWF_4", "NPI") -> mapFromSecondColumnValueIsIn("NPI", "ENTITY_TYPE_CODE", Seq("1"))
  )

}
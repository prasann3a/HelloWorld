package com.humedica.mercury.etl.athena.observation

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame

/**
  * Auto-generated on 09/21/2018
  */


class ObservationQmresult(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("qmresult:athena.util.UtilDedupedQmresult")

  columnSelect = Map(
    "qmresult" -> List("PATIENTID", "LOCALCODE", "OBSDATE", "RESULT_STATUS", "DATASRC", "LOCALUNIT", "OBSTYPE")
  )

  beforeJoin = Map(
    "qmresult" -> includeIf("datasrc = 'qmresult' and coalesce(result_status, 'X') not in ('EXCLUDED', 'NOTSATISFIED')")
  )

  map = Map(
    "DATASRC" -> mapFrom("DATASRC"),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "OBSDATE" -> mapFrom("OBSDATE"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "LOCALRESULT" -> concatFrom(Seq("RESULT_STATUS", "LOCALCODE"), delim = "."),
    "LOCAL_OBS_UNIT" -> mapFrom("LOCALUNIT"),
    "OBSTYPE" -> mapFrom("OBSTYPE")
  )

  afterMap = (df: DataFrame) => {
    df.filter("localresult is not null and obsdate is not null and patientid is not null")
      .dropDuplicates(List("DATASRC", "LOCALCODE", "OBSDATE", "PATIENTID", "LOCALRESULT", "LOCAL_OBS_UNIT", "OBSTYPE"))
  }

}
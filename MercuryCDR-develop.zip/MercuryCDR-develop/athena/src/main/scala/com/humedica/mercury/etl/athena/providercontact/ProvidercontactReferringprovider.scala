package com.humedica.mercury.etl.athena.providercontact

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class ProvidercontactReferringprovider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("referringprovider",
    "fileIdDates:athena.util.UtilFileIdDates"
  )

  columnSelect = Map(
    "referringprovider" -> List("REFERRING_PROVIDER_ID", "ADDRESS", "ADDRESS_2", "CITY", "HUM_STATE", "PHONE_NUMBER", "ZIP_CODE", "FILEID"),
    "fileIdDates" -> List("FILEID", "FILEDATE")
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("referringprovider")
      .join(dfs("fileIdDates"), Seq("FILEID"), "inner")
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("REFERRING_PROVIDER_ID"), df("ADDRESS"), df("ADDRESS_2"), df("CITY"), df("HUM_STATE"), df("PHONE_NUMBER"), df("ZIP_CODE"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)

    df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1 and coalesce(address, address_2, city, hum_state, phone_number, zip_code) is not null and filedate is not null")
  }

  map = Map(
    "DATASRC" -> literal("referringprovider"),
    "LOCAL_CONTACT_TYPE" -> literal("PROVIDER"),
    "LOCAL_PROVIDER_ID" -> mapFrom("REFERRING_PROVIDER_ID", prefix = "rp."),
    "ADDRESS_LINE1" -> mapFrom("ADDRESS"),
    "ADDRESS_LINE2" -> mapFrom("ADDRESS_2"),
    "CITY" -> mapFrom("CITY"),
    "STATE" -> mapFrom("HUM_STATE"),
    "WORK_PHONE" -> mapFrom("PHONE_NUMBER"),
    "ZIPCODE" -> mapFrom("ZIP_CODE"),
    "UPDATE_DATE" -> mapFrom("FILEDATE")
  )

}

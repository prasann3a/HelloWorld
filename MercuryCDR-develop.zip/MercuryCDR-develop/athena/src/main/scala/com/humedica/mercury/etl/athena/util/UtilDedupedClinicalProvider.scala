package com.humedica.mercury.etl.athena.util

import com.humedica.mercury.etl.core.engine.EntitySource
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


class UtilDedupedClinicalProvider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  cacheMe = true
  columns = List("ADDRESS1", "ADDRESS2", "CITY", "CLINICAL_PROVIDER_ID", "CONTEXT_ID", "CONTEXT_NAME", "CONTEXT_PARENTCONTEXTID",
    "COUNTRY", "CREATED_DATETIME", "DELETED_DATETIME", "DUPLICATE_OF_CLINICAL_PROV_ID", "FAX", "FILEID", "FIRST_NAME",
    "GENDER", "HUM_STATE", "LAST_NAME", "MIDDLE_NAME", "NAME", "NPI", "PHONE", "REPLACED_BY_CLINICAL_PROV_ID", "TITLE", "ZIP")

  tables = List("clinicalprovider",
    "fileExtractDates:athena.util.UtilFileIdDates")

  columnSelect = Map(
    "clinicalprovider" -> List("ADDRESS1", "ADDRESS2", "CITY", "CLINICAL_PROVIDER_ID", "CONTEXT_ID", "CONTEXT_NAME", "CONTEXT_PARENTCONTEXTID",
      "COUNTRY", "CREATED_DATETIME", "DELETED_DATETIME", "DUPLICATE_OF_CLINICAL_PROV_ID", "FAX", "FILEID", "FIRST_NAME",
      "GENDER", "HUM_STATE", "LAST_NAME", "MIDDLE_NAME", "NAME", "NPI", "PHONE", "REPLACED_BY_CLINICAL_PROV_ID", "TITLE", "ZIP"),
    "fileExtractDates" -> List("FILEID", "FILEDATE")
  )


  join = (dfs: Map[String, DataFrame]) => {
    dfs("clinicalprovider")
      .join(dfs("fileExtractDates"), Seq("FILEID"), "left_outer")
  }


  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("CLINICAL_PROVIDER_ID"))
      .orderBy(df("CREATED_DATETIME").desc_nulls_last, df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)
    df.withColumn("dedupe_row", row_number.over(groups))
      .filter("dedupe_row = 1")
  }


}

// test
//  val a = new UtilDedupedProvider(cfg); val o = build(a); o.count


package com.humedica.mercury.etl.athena.procedure

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProcedurePatientsurgerystd(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patientsurgery:athena.util.UtilDedupedPatientSurgery")

  columnSelect = Map(
    "patientsurgery" -> List("PROCEDURE_CODE", "PATIENT_ID", "SURGERY_DATETIME", "CLINICAL_ENCOUNTER_ID")
  )

  map = Map(
    "DATASRC" -> literal("patientsurgery_std"),
    "LOCALCODE" -> mapFrom("PROCEDURE_CODE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "PROCEDUREDATE" -> mapFrom("SURGERY_DATETIME"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "MAPPEDCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, substring(df("PROCEDURE_CODE"), 1, 5))
    }),
    "CODETYPE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col,
        when(substring(df("PROCEDURE_CODE"), 1, 5).rlike("^[0-9]{4}[0-9A-Z]$"), lit("CPT4"))
          .when(substring(df("PROCEDURE_CODE"), 1, 5).rlike("^[A-Z][0-9]{4}$"), lit("HCPCS"))
          .when(substring(df("PROCEDURE_CODE"), 1, 5).rlike("[0-9]{4}$"), lit("REV"))
          .when(substring(df("PROCEDURE_CODE"), 1, 5).rlike("^[0-9]{2}.[0-9]{1,2}$"), lit("ICD9"))
          .otherwise(null)
      )
    })
  )

  afterMap = includeIf("proceduredate is not null and patientid is not null and localcode is not null")

}
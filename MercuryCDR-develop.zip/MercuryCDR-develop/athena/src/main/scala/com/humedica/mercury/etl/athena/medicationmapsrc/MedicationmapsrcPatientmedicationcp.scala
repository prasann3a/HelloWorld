package com.humedica.mercury.etl.athena.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcPatientmedicationcp(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "patientmedication",
    "document",
    "medication"
  )

  columnSelect = Map(
    "patientmedication" -> List("PATIENT_MEDICATION_ID", "FILEID", "MEDICATION_NAME", "DOCUMENT_DESCRIPTION", "DOCUMENT_ID", "RXNORM", "MEDICATION_TYPE"),
    "document" -> List("DOCUMENT_ID", "FILEID", "CLINICAL_ORDER_TYPE", "FBD_MED_ID"),
    "medication" -> List("MEDICATION_ID", "FILEID", "NDC", "MEDICATION_NAME", "FDB_MED_ID", "RXNORM")
  )

  beforeJoin = Map(
    "patientmedication" -> ((df: DataFrame) => {
      val filter_df = df.filter("MEDICATION_TYPE = 'CLINICALPRESCRIPTION'")
      val groups = Window.partitionBy(filter_df("PATIENT_MEDICATION_ID")).orderBy(filter_df("FILEID").desc)
      filter_df.withColumnRenamed("MEDICATION_NAME", "PAT_MEDICATION_NAME")
               .withColumnRenamed("RXNORM", "PAT_RXNORM")
               .withColumn("pat_med_rn", row_number.over(groups)).filter("pat_med_rn = 1").drop("pat_med_rn")
    }),
    "document" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("DOCUMENT_ID")).orderBy(df("FILEID").desc)
      df.withColumn("doc_rn", row_number.over(groups)).filter("doc_rn = 1").drop("doc_rn")
    }),
    "medication" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("MEDICATION_ID")).orderBy(df("FILEID").desc)
      df.withColumn("med_rn", row_number.over(groups)).filter("med_rn = 1").drop("med_rn")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("document").join(table("medication"), table("medication")("FDB_MED_ID") === table("document")("FBD_MED_ID"), "inner")
      .join(dfs("patientmedication"), dfs("patientmedication")("DOCUMENT_ID") === table("document")("DOCUMENT_ID"), "inner")
  }

  map = Map(
    "DATASRC" -> literal("patientmedication_cp"),
    "LOCALMEDCODE" -> ((col, df) => df.withColumn(col, substring(coalesce(df("FBD_MED_ID"), df("CLINICAL_ORDER_TYPE")), 1, 100))),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, coalesce(df("MEDICATION_NAME"), df("PAT_MEDICATION_NAME"), df("DOCUMENT_DESCRIPTION"), df("CLINICAL_ORDER_TYPE")))),
    "LOCALGENERIC" -> ((col, df) => df.withColumn(col, coalesce(df("MEDICATION_NAME"), df("PAT_MEDICATION_NAME")))),
    "LOCALNDC" -> mapFrom("NDC"),
    "RXNORM_CODE" -> ((col, df) => df.withColumn(col, coalesce(df("RXNORM"), df("PAT_RXNORM"))))
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALDESCRIPTION"), df("LOCALGENERIC"), df("RXNORM_CODE"), df("LOCALNDC"))
    val df1 = df.withColumn("NUM_RECS", count("*").over(groups))
                .withColumn("NO_NDC", sum(when(df("LOCALNDC").isNull, 1).otherwise(0)).over(groups))
                .withColumn("HAS_NDC", sum(when(df("LOCALNDC").isNull, 0).otherwise(1)).over(groups))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct().filter("LOCALMEDCODE is NOT NULL")
  }
}

//val a = new MedicationmapsrcPatientmedicationcp(cfg); val med_s = build(a, allColumns = true);

package com.humedica.mercury.etl.athena.patientreportedmeds

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._


class PatientreportedmedsPatpm(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("medication:athena.util.UtilDedupedMedication",
    "patientmedication:athena.util.UtilDedupedPatientMedication",
    "cdr.map_predicate_values",
    "splitpatient:athena.util.UtilSplitPatient")

  columnSelect = Map(
    "medication" -> List("RXNORM", "MEDICATION_NAME", "NDC", "MEDICATION_ID"),
    "patientmedication" -> List("PATIENT_ID", "PATIENT_MEDICATION_ID", "STOP_DATE", "DEACTIVATION_DATETIME", "DEACTIVATION_REASON",
      "PRESCRIBER_NPI", "CREATED_DATETIME", "MEDICATION_ID", "MEDICATION_NAME", "SIG", "DOSAGE_ROUTE", "DOSAGE_QUANTITY",
      "DISPLAY_DOSAGE_UNITS", "DOSAGE_FORM", "DELETED_DATETIME", "MEDICATION_TYPE", "SOURCE_CODE_TYPE","CLINICAL_ENCOUNTER_ID","DOCUMENT_DESCRIPTION",
    "FILL_DATE","START_DATE"),
    "splitpatient" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "medication" -> ((df: DataFrame) => {
      df.withColumnRenamed("RXNORM", "RXNORM_med")
        .withColumnRenamed("MEDICATION_NAME", "MEDICATION_NAME_med")
        .withColumnRenamed("NDC", "NDC_med")
        .withColumnRenamed("MEDICATION_ID", "MEDICATION_ID_med")


    }),
    "patientmedication" -> ((df: DataFrame) => {
      val df1=df.filter("deleted_datetime is null and (deactivation_reason <> 'entered in error' or deactivation_reason is null) " +
        "and MEDICATION_TYPE = 'PATIENTMEDICATION' and (SOURCE_CODE_TYPE is null or SOURCE_CODE_TYPE <> 'FORMULARYSOURCEID')")
        .withColumnRenamed("RXNORM", "RXNORM_pm")
        .withColumnRenamed("MEDICATION_NAME", "MEDICATION_NAME_pm")
        .withColumnRenamed("NDC", "NDC_pm")
        .withColumnRenamed("MEDICATION_ID", "MEDICATION_ID_pm")
      df1.repartition(1000,df1("MEDICATION_ID_pm"))

    })
  )
  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientmedication")
      .join(dfs("medication"), dfs("patientmedication")("MEDICATION_ID_pm") === dfs("medication")("MEDICATION_ID_med"), "left_outer")
      .join(dfs("splitpatient"), Seq("PATIENT_ID"), patJoinType)
  }

  map = Map(

    "DATASRC" -> literal("patientmedication_pm"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "REPORTEDMEDID" -> mapFrom("PATIENT_MEDICATION_ID"),
    "DISCONTINUEDATE" -> cascadeFrom(Seq("STOP_DATE", "DEACTIVATION_DATETIME")),
    "DISCONTINUEREASON" -> mapFrom("DEACTIVATION_REASON"),
    "LOCALPROVIDERID" -> mapFrom("PRESCRIBER_NPI"),
    "MEDREPORTEDTIME" -> cascadeFrom(Seq("FILL_DATE", "START_DATE", "CREATED_DATETIME")),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "LOCALMEDCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("MEDICATION_ID_pm"), df("MEDICATION_NAME_pm")))
    }),
    "LOCALDRUGDESCRIPTION" -> cascadeFrom(Seq("MEDICATION_NAME_pm", "MEDICATION_NAME_med", "DOCUMENT_DESCRIPTION")),
    "LOCALNDC" -> mapFrom("NDC_med"),
    "RXNORM_CODE" -> mapFrom("RXNORM_med"),
    "LOCALSTRENGTHPERDOSEUNIT" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(trim(regexp_extract(lower(df("MEDICATION_NAME_med")), "([0-9]*\\.*[0-9]+)\\s*((m*c*g|ml|meq|milligram))", 1)) === "", null)
        .otherwise(trim(regexp_extract(lower(df("MEDICATION_NAME_med")), "([0-9]*\\.*[0-9]+)\\s*((m*c*g|ml|meq|milligram))", 1))))
    }),
    "LOCALSTRENGTHUNIT" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(trim(regexp_extract(lower(df("MEDICATION_NAME_med")), "([0-9]*\\.*[0-9]+)\\s*((m*c*g|ml|meq|milligram))", 2)) === "", null)
        .otherwise(trim(regexp_extract(lower(df("MEDICATION_NAME_med")), "([0-9]*\\.*[0-9]+)\\s*((m*c*g|ml|meq|milligram))", 2))))
    }),
    "LOCALFORM" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, regexp_replace(substring(coalesce(df("DOSAGE_FORM"), df("SIG"), df("DISPLAY_DOSAGE_UNITS"),
        regexp_extract(lower(df("MEDICATION_NAME_med")),"[a-z]+$",0)),1,255), "[^\\p{Print}]", ""))
    }),
    "LOCALROUTE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("DOSAGE_ROUTE"), trim(regexp_extract(lower(df("SIG")),
        "(inhal(ation|e)|oral|by mouth|transdermal|topical|otic|ophthalmic|eye|ear|(sub|trans)(lingual|cutaneous)|injection|(intra)?nasal|intra(venous|muscular)|vaginal|as directed| ?po[^a-z])", 0))))
    }),
    "LOCALQTYOFDOSEUNIT" -> mapFrom("DOSAGE_QUANTITY"),
    "LOCALDOSEUNIT" -> cascadeFrom(Seq("DISPLAY_DOSAGE_UNITS", "DOSAGE_FORM"))
  )

  afterMap = (df: DataFrame) => {
    df.withColumn("LOCALTOTALDOSE", coalesce(df("LOCALSTRENGTHPERDOSEUNIT").multiply(df("LOCALQTYOFDOSEUNIT")), lit(0)))
  }
}




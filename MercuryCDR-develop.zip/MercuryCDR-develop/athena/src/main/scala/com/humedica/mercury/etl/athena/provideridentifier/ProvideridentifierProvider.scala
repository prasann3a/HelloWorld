package com.humedica.mercury.etl.athena.provideridentifier

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProvideridentifierProvider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("provider:athena.util.UtilDedupedProvider")

  columnSelect = Map(
    "provider" -> List("PROVIDER_ID", "PROVIDER_TYPE_CATEGORY", "PROVIDER_NPI_NUMBER", "PROVIDER_NDC_TAT_NUMBER")
  )

  beforeJoin = Map(
    "provider" -> ((df: DataFrame) => {
      val fil = df.filter("provider_id is not null")
      fil.withColumn("NPI", df("PROVIDER_NPI_NUMBER"))
    })
  )

  afterJoin = (df: DataFrame) => {
    val idTypes = unpivot(
      Seq("NPI", "PROVIDER_NDC_TAT_NUMBER"),
      Seq("NPI", "Provider NDC"),
      "ID_TYPE")
    idTypes("ID_VALUE", df)
  }

  map = Map(
    "PROVIDER_ID" -> mapFrom("PROVIDER_ID"),
    "ID_TYPE" -> mapFrom("ID_TYPE"),
    "ID_VALUE" -> mapFrom("ID_VALUE")
  )

  beforeJoinExceptions = Map(
    "H984728_ATHENA_DWF_4" -> Map(
      "provider" -> ((df: DataFrame) => {
        val fil = df.filter("provider_id is not null")
        fil.withColumn("NPI", when(df("PROVIDER_TYPE_CATEGORY") === "MD", df("PROVIDER_NPI_NUMBER"))
          .otherwise(null))
      })
    )
  )

}
package com.humedica.mercury.etl.athena.observation

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{coalesce, row_number, when, _}

class ObservationPatientassertiondepression(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patientassertion"
    , "pat:athena.util.UtilSplitPatient"
    , "fileIdDates:athena.util.UtilFileIdDates"
    , "cdr.zcm_obstype_code")


  columnSelect = Map(
    "patientassertion" -> List("PATIENT_ASSERTION_KEY", "PATIENT_ASSERTION_VALUE", "PATIENT_ID", "PATIENT_ASSERTION_ID", "HUM_TYPE", "FILEID", "CREATED_DATETIME", "DELETED_DATETIME"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "DATASRC", "OBSCODE", "CUI", "LOCALUNIT", "OBSTYPE", "OBSTYPE_STD_UNITS"),
    "pat" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "patientassertion" -> ((df: DataFrame) => {
      val fd = table("fileIdDates")
      val zcm = table("cdr.zcm_obstype_code").filter("groupid = '" + config(GROUP) + "' and datasrc = 'patientassertion_depression'")

      val pa_df = df.join(fd, Seq("FILEID"), "inner")

      val pa_fd = pa_df.withColumn("OBSDATE", when(pa_df("CREATED_DATETIME") > pa_df("FILEDATE") || pa_df("FILEDATE") > current_timestamp, pa_df("CREATED_DATETIME"))
        .otherwise(coalesce(pa_df("FILEDATE"), pa_df("CREATED_DATETIME"))))
        .filter("PATIENT_ASSERTION_KEY = 'ASSERTIONVALUE_DEPRESSIONASSESSMENTANDPLAN' AND PATIENT_ID IS NOT NULL AND DELETED_DATETIME IS NULL AND OBSDATE IS NOT NULL AND PATIENT_ASSERTION_VALUE IS NOT NULL")
        .drop("DELETED_DATETIME")

      val groups = Window.partitionBy(pa_fd("OBSDATE"), pa_fd("PATIENT_ASSERTION_VALUE"), pa_fd("PATIENT_ASSERTION_ID"), pa_fd("HUM_TYPE")).orderBy(pa_fd("FILEDATE").desc_nulls_last, pa_fd("FILEID").desc_nulls_last)
      pa_fd
        .withColumn("rn", row_number.over(groups))
        .filter("rn=1")
        .drop("rn")
        .join(zcm, pa_fd("PATIENT_ASSERTION_KEY") === zcm("OBSCODE"), "inner")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientassertion")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("patientassertion_depression"),
    "LOCALRESULT" -> mapFrom("PATIENT_ASSERTION_VALUE"),
    "LOCALCODE" -> mapFrom("PATIENT_ASSERTION_KEY"),
    "OBSDATE" -> mapFrom("OBSDATE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "LOCAL_OBS_UNIT" -> mapFrom("LOCALUNIT"),
    "OBSTYPE" -> mapFrom("OBSTYPE")
  )

}


// test
//  val ob = new ObservationPatientassertiondepression(cfg); val obs = build(ob,true); obs.show ; obs.count;


package com.humedica.mercury.etl.athena.labmapperdict

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class LabmapperdictDocument(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("clinicalresult:athena.util.UtilDedupedClinicalResult",
    "clinicalresultobservation:athena.util.UtilDedupedClinicalResultObservation",
    "document:athena.util.UtilDedupedDocument",
    "dictVital:athena.labmapperdict.LabmapperdictVitalsign",
    "dictClinObs:athena.labmapperdict.LabmapperdictClinicalresultobservation")

  columnSelect = Map(
    "clinicalresult" -> List("DOCUMENT_ID", "RESULT_DOCUMENT_ID", "SPECIMEN_SOURCE", "CLINICAL_ORDER_TYPE", "CLINICAL_RESULT_ID"),
    "clinicalresultobservation" -> List("TEMPLATE_ANALYTE_NAME", "CLINICAL_RESULT_ID"),
    "document" -> List("DOCUMENT_ID", "DOCUMENT_CLASS", "CLINICAL_ORDER_TYPE", "SPECIMEN_SOURCE"),
    "dictVital" -> List("LOCALCODE"),
    "dictClinObs" -> List("LOCALCODE")
  )

  beforeJoin = Map(
    "clinicalresult" -> renameColumns(List(("CLINICAL_ORDER_TYPE", "CLINICAL_ORDER_TYPE_cr"), ("SPECIMEN_SOURCE", "SPECIMEN_SOURCE_cr"))),
    "document" -> ((df: DataFrame) => {
      df.filter("document_class = 'LABRESULT'")
        .withColumnRenamed("CLINICAL_ORDER_TYPE", "CLINICAL_ORDER_TYPE_doc")
        .withColumnRenamed("SPECIMEN_SOURCE", "SPECIMEN_SOURCE_doc")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("document")
      .join(dfs("clinicalresult"), dfs("document")("DOCUMENT_ID") === coalesce(dfs("clinicalresult")("DOCUMENT_ID"), dfs("clinicalresult")("RESULT_DOCUMENT_ID")), "left_outer")
      .join(dfs("clinicalresultobservation"), Seq("CLINICAL_RESULT_ID"), "left_outer")
  }

  map = Map(
    "LOCALCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("TEMPLATE_ANALYTE_NAME").isNotNull, concat_ws("_", coalesce(df("CLINICAL_ORDER_TYPE_doc"), df("CLINICAL_ORDER_TYPE_cr")), df("TEMPLATE_ANALYTE_NAME")))
        .otherwise(coalesce(df("CLINICAL_ORDER_TYPE_doc"), df("CLINICAL_ORDER_TYPE_cr"))))
    }),
    "LOCALNAME" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("TEMPLATE_ANALYTE_NAME").isNotNull, concat_ws("_", coalesce(df("CLINICAL_ORDER_TYPE_doc"), df("CLINICAL_ORDER_TYPE_cr")), df("TEMPLATE_ANALYTE_NAME")))
        .otherwise(coalesce(df("CLINICAL_ORDER_TYPE_doc"), df("CLINICAL_ORDER_TYPE_cr"))))
    })
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.withColumn("cnt", count(coalesce(df("SPECIMEN_SOURCE_doc"), df("SPECIMEN_SOURCE_cr")))
      .over(Window.partitionBy(coalesce(df("SPECIMEN_SOURCE_doc"), df("SPECIMEN_SOURCE_cr")), coalesce(df("CLINICAL_ORDER_TYPE_doc"), df("CLINICAL_ORDER_TYPE_cr")))))

    val df2 = df1.withColumn("rn", row_number.over(Window.partitionBy(df1("LOCALCODE")).orderBy(df1("cnt").desc)))
      .filter("rn = 1 and localcode is not null")

    val dicts = table("dictVital").union(table("dictClinObs"))
    df2.join(dicts, Seq("LOCALCODE"), "left_anti")
  }

}
package com.humedica.mercury.etl.athena.procedure

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

/**
  * Auto-generated on 09/21/2018
  */


class ProcedureDocument(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("clinicalencounter:athena.util.UtilDedupedClinicalEncounter",
    "clinicalresult:athena.util.UtilDedupedClinicalResult",
    "document:athena.util.UtilDedupedDocument",
    "cdr.map_custom_proc",
    "cdr.map_predicate_values")

  columnSelect = Map(
    "clinicalencounter" -> List("ENCOUNTER_DATE", "CLINICAL_ENCOUNTER_ID"),
    "clinicalresult" -> List("OBSERVATION_DATETIME", "DOCUMENT_ID", "RESULT_DOCUMENT_ID"),
    "document" -> List("CLINICAL_ORDER_TYPE", "PATIENT_ID", "FUTURE_SUBMIT_DATETIME", "DOCUMENT_ID", "CLINICAL_ENCOUNTER_ID",
      "ORDER_DOCUMENT_ID", "DOCUMENT_CLASS", "DELETED_DATETIME", "STATUS", "OBSERVATION_DATETIME"),
    "cdr.map_custom_proc" -> List("GROUPID", "DATASRC", "LOCALCODE", "MAPPEDVALUE")
  )

  beforeJoin = Map(
    "document" -> ((df: DataFrame) => {
      val list_exclude_doc_class = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "DOCUMENT", "PROCEDUREDO", "DOCUMENT", "DOCUMENT_CLASS")
      df.filter("document_class not in (" + list_exclude_doc_class + ") and deleted_datetime is null and status <> 'DELETED' " +
        "and (document_class in ('LABRESULT', 'CLINICALDOCUMENT', 'IMAGINGRESULT', 'ENCOUNTERDOCUMENT') or " +
        "(document_class in ('ORDER', 'VACCINE') and future_submit_datetime is not null and future_submit_datetime < current_timestamp()))")
        .withColumnRenamed("OBSERVATION_DATETIME", "OBSERVATION_DATETIME_doc")
    }),
    "cdr.map_custom_proc" -> ((df: DataFrame) => {
      df.filter("groupid = '" + config(GROUP) + "' and datasrc = 'document'")
        .drop("GROUPID", "DATASRC")
    }),
    "clinicalresult" -> renameColumn("OBSERVATION_DATETIME", "OBSERVATION_DATETIME_cr")
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("document")
      .join(dfs("cdr.map_custom_proc"), dfs("document")("CLINICAL_ORDER_TYPE") === dfs("cdr.map_custom_proc")("LOCALCODE"), "inner")
      .join(dfs("clinicalresult"), dfs("document")("DOCUMENT_ID") === coalesce(dfs("clinicalresult")("DOCUMENT_ID"), dfs("clinicalresult")("RESULT_DOCUMENT_ID")), "left_outer")
      .join(dfs("clinicalencounter"), Seq("CLINICAL_ENCOUNTER_ID"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("document"),
    "LOCALCODE" -> mapFrom("CLINICAL_ORDER_TYPE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "PROCEDUREDATE" -> cascadeFrom(Seq("FUTURE_SUBMIT_DATETIME", "OBSERVATION_DATETIME_doc", "OBSERVATION_DATETIME_cr", "ENCOUNTER_DATE")),
    "LOCALNAME" -> mapFrom("CLINICAL_ORDER_TYPE"),
    "ACTUALPROCDATE" -> mapFrom("ENCOUNTER_DATE"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "MAPPEDCODE" -> mapFrom("MAPPEDVALUE"),
    "CODETYPE" -> literal("CUSTOM")
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.filter("patientid is not null and proceduredate is not null")
    val cols = Engine.schema.getStringList("Procedure").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*)
      .distinct
  }

}
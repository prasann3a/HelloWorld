package com.humedica.mercury.etl.athena.util

import com.humedica.mercury.etl.core.engine.EntitySource
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


class UtilDedupedReferringProvider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  cacheMe = true
  columns = List("ADDRESS", "ADDRESS_2", "CITY", "CONTEXT_ID", "CONTEXT_NAME", "CONTEXT_PARENTCONTEXTID", "DELETED_BY",
    "DELETED_DATETIME", "ENTITY_TYPE", "FAX_NUMBER", "FILEID", "HUM_STATE", "NOTES", "NPI_NUMBER", "PHONE_NUMBER",
    "REFERRING_PROVIDER_GROUP", "REFERRING_PROVIDER_ID", "REFERRING_PROVIDER_NAME", "SPECIALITY_CODE", "SPECIALTY", "ZIP_CODE")

  tables = List("referringprovider",
    "fileExtractDates:athena.util.UtilFileIdDates")

  columnSelect = Map(
    "referringprovider" -> List("ADDRESS", "ADDRESS_2", "CITY", "CONTEXT_ID", "CONTEXT_NAME", "CONTEXT_PARENTCONTEXTID", "DELETED_BY",
      "DELETED_DATETIME", "ENTITY_TYPE", "FAX_NUMBER", "FILEID", "HUM_STATE", "NOTES", "NPI_NUMBER", "PHONE_NUMBER",
      "REFERRING_PROVIDER_GROUP", "REFERRING_PROVIDER_ID", "REFERRING_PROVIDER_NAME", "SPECIALITY_CODE", "SPECIALTY", "ZIP_CODE"),
    "fileExtractDates" -> List("FILEID", "FILEDATE")
  )


  join = (dfs: Map[String, DataFrame]) => {
    dfs("referringprovider")
      .join(dfs("fileExtractDates"), Seq("FILEID"), "left_outer")
  }


  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("REFERRING_PROVIDER_ID")).orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)
    df.withColumn("dedupe_row", row_number.over(groups))
      .filter("dedupe_row = 1")
  }


}

// test
//  val a = new UtilDedupedProvider(cfg); val o = build(a); o.count


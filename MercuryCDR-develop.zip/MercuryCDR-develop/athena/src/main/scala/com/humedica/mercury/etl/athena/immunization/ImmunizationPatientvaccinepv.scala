package com.humedica.mercury.etl.athena.immunization

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._


class ImmunizationPatientvaccinepv(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "patientvaccine",
    "fileIdDates:athena.util.UtilFileIdDates",
    "splitTable:athena.util.UtilSplitPatient"
  )

  columnSelect = Map(
    "patientvaccine" -> List("FILEID", "PATIENT_ID", "CLINICAL_ENCOUNTER_ID", "ADMINISTER_NOTE", "VACCINE_ROUTE", "ADMINISTERED_DATETIME",
      "CVX", "VACCINE_NAME", "HUM_TYPE", "PATIENT_VACCINE_ID", "STATUS", "DELETED_DATETIME")
  )

  beforeJoin = Map(
    "patientvaccine" -> ((df: DataFrame) => {
      val fileIdDates = table("fileIdDates")
      val fil = df.filter("HUM_TYPE = 'PATIENTVACCINE'")
      val joined = fil.join(fileIdDates, Seq("FILEID"), "left_outer")
      val groups = Window.partitionBy(joined("PATIENT_VACCINE_ID")).orderBy(joined("FILEDATE").desc_nulls_last, joined("FILEID").desc_nulls_last)
      joined.withColumn("rn", row_number.over(groups)).filter("rn = 1 and DELETED_DATETIME is null")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientvaccine").join(dfs("splitTable"), Seq("PATIENT_ID"), patJoinType)
  }

  afterJoin = (df: DataFrame) => {
    val fil = df.filter("STATUS <> 'DELETED' or STATUS is null")
    val groups = Window.partitionBy(fil("PATIENT_ID"),fil("CLINICAL_ENCOUNTER_ID"),fil("CVX"),fil("ADMINISTERED_DATETIME"),fil("VACCINE_NAME")).orderBy(fil("VACCINE_ROUTE").desc_nulls_last)
    fil.withColumn("rn", row_number.over(groups)).filter("rn = 1")
  }

  map = Map(
    "DATASRC" -> literal("patientvaccine_pv"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "LOCALDEFERREDREASON" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("ADMINISTER_NOTE").rlike("refused|declined|reused"), df("ADMINISTER_NOTE")).otherwise(lit(null)))
    }),
    "LOCALROUTE" -> mapFrom("VACCINE_ROUTE"),
    "ADMINDATE" -> mapFrom("ADMINISTERED_DATETIME"),
    "LOCALIMMUNIZATIONCD" -> mapFrom("CVX"),
    "LOCALIMMUNIZATIONDESC" -> mapFrom("VACCINE_NAME")
  )

  afterMap = (df: DataFrame) => {
    val fil =  df.filter("LOCALIMMUNIZATIONCD is not null and PATIENTID is not null")
    val cols = Engine.schema.getStringList("Immunization").asScala.map(_.split("-")(0).toUpperCase())
    fil.select(cols.map(col): _*).distinct

  }
}
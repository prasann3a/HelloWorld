package com.humedica.mercury.etl.athena.rxordersandprescriptions

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class RxordersandprescriptionsPatientmedicationpm(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("medication:athena.util.UtilDedupedMedication",
    "patientmedication:athena.util.UtilDedupedPatientMedication",
    "cdr.map_predicate_values",
    "splitpatient:athena.util.UtilSplitPatient")

  columnSelect = Map(
    "medication" -> List("RXNORM", "MEDICATION_NAME", "NDC", "MEDICATION_ID"),
    "patientmedication" -> List("FILL_DATE", "START_DATE", "CREATED_DATETIME", "PATIENT_ID", "LENGTH_OF_COURSE", "STOP_DATE",
      "DEACTIVATION_DATETIME", "DEACTIVATION_REASON", "DISPLAY_DOSAGE_UNITS", "DOSAGE_FORM", "DOSAGE_ROUTE", "MEDICATION_NAME",
      "DOCUMENT_DESCRIPTION", "LENGTH_OF_COURSE", "SIG", "NDC", "NUMBER_OF_REFILLS_PRESCRIBED", "STATUS", "PRESCRIPTION_FILL_QUANTITY",
      "RXNORM", "PRESCRIBER_NPI", "MEDICATION_ID", "DELETED_DATETIME", "MEDICATION_TYPE", "PATIENT_MEDICATION_ID", "FREQUENCY",
      "SOURCE_CODE_TYPE", "PRESCRIBER", "PHARMACY_NAME"),
    "splitpatient" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "medication" -> ((df: DataFrame) => {
      df.withColumnRenamed("RXNORM", "RXNORM_med")
        .withColumnRenamed("MEDICATION_NAME", "MEDICATION_NAME_med")
        .withColumnRenamed("NDC", "NDC_med")
    }),
    "patientmedication" -> ((df: DataFrame) => {
      df.filter("deleted_datetime is null and coalesce(deactivation_reason, 'X') <> 'entered in error' and medication_type = 'PATIENTMEDICATION'")
        .withColumnRenamed("RXNORM", "RXNORM_pm")
        .withColumnRenamed("MEDICATION_NAME", "MEDICATION_NAME_pm")
        .withColumnRenamed("NDC", "NDC_pm")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientmedication")
      .join(dfs("medication"), Seq("MEDICATION_ID"), "left_outer")
      .join(dfs("splitpatient"), Seq("PATIENT_ID"), patJoinType)
  }


  map = Map(
    "DATASRC" -> literal("patientmedication_pm"),
    "ISSUEDATE" -> cascadeFrom(Seq("FILL_DATE", "START_DATE", "CREATED_DATETIME")),
    "ORDERVSPRESCRIPTION" -> literal("P"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "RXID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat(df("PATIENT_MEDICATION_ID"), lit("_2")))
    }),
    "ALTMEDCODE" -> mapFrom("RXNORM_med"),
    "LOCALDAYSUPPLIED" -> mapFrom("LENGTH_OF_COURSE"),
    "DISCONTINUEDATE" -> cascadeFrom(Seq("STOP_DATE", "DEACTIVATION_DATETIME")),
    "DISCONTINUEREASON" -> mapFrom("DEACTIVATION_REASON"),
    "LOCALDOSEUNIT" -> cascadeFrom(Seq("DISPLAY_DOSAGE_UNITS", "DOSAGE_FORM")),
    "LOCALDESCRIPTION" -> cascadeFrom(Seq("MEDICATION_NAME_pm", "MEDICATION_NAME_med", "DOCUMENT_DESCRIPTION")),
    "LOCALDURATION" -> mapFrom("LENGTH_OF_COURSE"),
    "LOCALFORM" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, regexp_replace(substring(coalesce(df("DOSAGE_FORM"), df("SIG"), df("DOCUMENT_DESCRIPTION"), 
        regexp_extract(lower(df("MEDICATION_NAME_med")),"[a-z]+$",0)),1,255), "[^\\p{Print}]", ""))
    }),
    "LOCALGENERICDESC" -> cascadeFrom(Seq("MEDICATION_NAME_med", "MEDICATION_NAME_pm")),
    "LOCALMEDCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, substring(coalesce(df("MEDICATION_ID"), df("MEDICATION_NAME_pm"), df("DOCUMENT_DESCRIPTION")), 1, 100))
    }),
    "LOCALNDC" -> cascadeFrom(Seq("NDC_med", "NDC_pm")),
    "LOCALPROVIDERID" -> mapFrom("PRESCRIBER_NPI", prefix = "npi."),
    "LOCALQTYOFDOSEUNIT" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(regexp_extract(df("SIG"), "(?i)([0-9]+\\.*[0-9]*|one|two|three|four|five)+\\s*((tab|unit|caps|spray|patch|puff|t\\s|ts\\s|tea\\s|drop))", 1) === "", null)
        .otherwise(regexp_extract(df("SIG"), "(?i)([0-9]+\\.*[0-9]*|one|two|three|four|five)+\\s*((tab|unit|caps|spray|patch|puff|t\\s|ts\\s|tea\\s|drop))", 1)))
    }),
    "LOCALROUTE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("DOSAGE_ROUTE"), trim(regexp_extract(lower(df("MEDICATION_NAME_MED")),
        "(drops?|ear|eye|capsules?|cream|inhal(ation|er)|intramuscular| gel| im |lotion|mouthwash|nasal|for|nebulization|ointment|oral|patch|shampoo|spray|subcutaneous|suspension|syringe|tablets?|topical|transdermal|vaginal| ){2,}", 0))))
    }),
    "LOCALSTRENGTHPERDOSEUNIT" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(trim(regexp_extract(lower(df("MEDICATION_NAME_med")), "([0-9]*\\.*[0-9]+)\\s*((m*c*g|ml|meq|milligram))", 1)) === "", null)
        .otherwise(trim(regexp_extract(lower(df("MEDICATION_NAME_med")), "([0-9]*\\.*[0-9]+)\\s*((m*c*g|ml|meq|milligram))", 1))))
    }),
    "LOCALSTRENGTHUNIT" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(trim(regexp_extract(lower(df("MEDICATION_NAME_med")), "([0-9]*\\.*[0-9]+)\\s*((m*c*g|ml|meq|milligram))", 2)) === "", null)
        .otherwise(trim(regexp_extract(lower(df("MEDICATION_NAME_med")), "([0-9]*\\.*[0-9]+)\\s*((m*c*g|ml|meq|milligram))", 2))))
    }),
    "FILLNUM" -> mapFrom("NUMBER_OF_REFILLS_PRESCRIBED"),
    "QUANTITYPERFILL" -> mapFrom("PRESCRIPTION_FILL_QUANTITY"),
    "SIGNATURE" -> mapFrom("SIG"),
    "VENUE" -> literal("1"),
    "RXNORM_CODE" -> cascadeFrom(Seq("RXNORM_pm", "RXNORM_med")),
    "ORDERSTATUS" -> mapFrom("STATUS"),
    "LOCALDOSEFREQ" -> mapFrom("FREQUENCY"),
    "ORDERTYPE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SOURCE_CODE_TYPE") === "FORMULARYSOURCEID" && coalesce(df("PRESCRIBER_NPI"), df("PRESCRIBER"), df("PHARMACY_NAME")).isNotNull, "CH002047")
        .otherwise(null))
    })
  )

  afterMap = (df: DataFrame) => {
    val mpv = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENTMEDICATION_PM", "RXORDER", "PATIENTMEDICATION", "PATIENTMEDICATION")
    val athena_start_dt = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENTMEDICATION_PM", "RXORDER", "PATIENTMEDICATION", "ISSUEDATE")
    val df1=df.withColumn("LOCALTOTALDOSE", coalesce(df("LOCALSTRENGTHPERDOSEUNIT").multiply(df("LOCALQTYOFDOSEUNIT")), lit(0)))
      .withColumn("ATH_START_DT", to_date(when(lit("'NO_MPV_MATCHES'").isin(athena_start_dt: _*), lit("19010101")).otherwise(lit(athena_start_dt.head)), "yyyyMMdd"))
      .filter("patientid is not null and issuedate >= ath_start_dt")
    if (mpv.head == "Y")
      df1.filter("SOURCE_CODE_TYPE = 'FORMULARYSOURCEID' ")
    else
      df1
  }

}
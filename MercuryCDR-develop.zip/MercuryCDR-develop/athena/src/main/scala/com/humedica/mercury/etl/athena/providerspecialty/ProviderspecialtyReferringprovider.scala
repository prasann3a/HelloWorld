package com.humedica.mercury.etl.athena.providerspecialty

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProviderspecialtyReferringprovider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("referringprovider:athena.util.UtilDedupedReferringProvider")

  columnSelect = Map(
    "referringprovider" -> List("REFERRING_PROVIDER_ID", "SPECIALITY_CODE", "SPECIALTY")
  )

  beforeJoin = Map(
    "referringprovider" -> includeIf("referring_provider_id is not null")
  )

  map = Map(
    "LOCALCODESOURCE" -> literal("referringprov"),
    "LOCALPROVIDERID" -> mapFrom("REFERRING_PROVIDER_ID", prefix = "rp."),
    "LOCALSPECIALTYCODE" -> cascadeFrom(Seq("SPECIALITY_CODE", "SPECIALTY"), prefix = config(CLIENT_DS_ID) + ".")
  )

  afterMap = includeIf("localspecialtycode is not null")

}
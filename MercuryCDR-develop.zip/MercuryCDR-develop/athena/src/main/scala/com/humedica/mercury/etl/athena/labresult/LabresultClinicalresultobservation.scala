package com.humedica.mercury.etl.athena.labresult

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


class LabresultClinicalresultobservation(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("clinicalResultObs:athena.util.UtilDedupedClinicalResultObservation"
    , "clinicalResult:athena.util.UtilDedupedClinicalResult"
    , "document:athena.util.UtilDedupedDocument"
    , "fileIdDates:athena.util.UtilFileIdDates"
    , "loinc"
    , "cdr.map_predicate_values")

  columnSelect = Map(
    "clinicalResultObs" -> List("TEMPLATE_ANALYTE_NAME", "HUM_RESULT", "OBSERVATION_IDENTIFIER", "OBSERVATION_IDENTIFIER_TEXT",
      "CLINICAL_RESULT_ID", "DELETED_DATETIME", "LOINC_ID", "CLINICAL_OBSERVATION_ID", "OBSERVATION_UNITS", "REFERENCE_RANGE", "OBSERVATION_ABNORMAL_FLAG_ID"),
    "clinicalResult" -> List("CREATED_DATETIME", "RESULT_STATUS", "CLINICAL_RESULT_ID", "DOCUMENT_ID", "RESULT_DOCUMENT_ID",
      "RESULTS_REPORTED_DATETIME", "SPECIMEN_SOURCE", "CLINICAL_ORDER_TYPE"),
    "document" -> List("DOCUMENT_ID", "OBSERVATION_DATETIME", "PATIENT_ID", "CLINICAL_ENCOUNTER_ID", "DEPARTMENT_ID",
      "DOCUMENT_CLASS", "SPECIMEN_COLLECTED_DATETIME", "ORDER_DATETIME", "CLINICAL_ORDER_TYPE", "ORDER_DOCUMENT_ID"),
    "loinc" -> List("LOINC_CODE", "LOINC_ID", "FILEID")
  )

  beforeJoin = Map(
    "clinicalResultObs" -> ((df: DataFrame) => {
      val list_localname = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CLINICALRESULTOBSERVATION", "LABRESULT", "CLINICALRESULTOBSERVATION", "OBSERVATION_IDENTIFIER_TEXT")
      df.filter("DELETED_DATETIME is null and coalesce(upper(OBSERVATION_IDENTIFIER_TEXT), '~') not in (" + list_localname + ")")
        .withColumn("LOCALRESULT_NUMERIC",
          when(df("HUM_RESULT").rlike("^[+-]?(\\..\\d+|\\d+\\..?\\d*)$"), expr("replace(HUM_RESULT, '..', '.')"))
          .when(df("HUM_RESULT").rlike("^[+-]?(\\.\\d+|\\d+\\.?\\d*)$"), df("HUM_RESULT"))
          .otherwise(null)
        )
        .withColumn("LOCALRESULT_25", when(!df("HUM_RESULT").rlike("^[+-]?(\\.\\d+|\\d+\\.?\\d*)$"),
          when(locate(" ", df("HUM_RESULT"), 25) === 0, expr("substr(HUM_RESULT,1,length(HUM_RESULT))"))
            .otherwise(expr("substr(HUM_RESULT,1,locate(' ', HUM_RESULT, 25))"))).otherwise(null))
        .withColumn("RESULTTYPE", substring(df("OBSERVATION_ABNORMAL_FLAG_ID"), 1, 16))
        .withColumn("OBSERVATION_IDENTIFIER_TEXT", substring(df("OBSERVATION_IDENTIFIER_TEXT"), 1, 255))
        .drop("DELETED_DATETIME", "OBSERVATION_ABNORMAL_FLAG_ID")
    }),
    "clinicalResult" -> ((df: DataFrame) => {
      df.filter("RESULT_STATUS is null or lower(RESULT_STATUS) NOT IN ('canceled','cancelled','incomplete','partial','pending','preliminary')")
        .withColumnRenamed("CLINICAL_ORDER_TYPE", "CLINICAL_ORDER_TYPE_cr")
        .withColumnRenamed("DOCUMENT_ID", "DOCUMENT_ID_cr")

    }),
    "loinc" -> ((df: DataFrame) => {
      val joined = df.join(table("fileIdDates"), Seq("FILEID"), "left_outer")
      val groups = Window.partitionBy(joined("LOINC_ID")).orderBy(joined("FILEDATE").desc_nulls_last, joined("FILEID").desc_nulls_last)
      joined.withColumn("rn", row_number.over(groups))
        .filter("rn = 1")

    })

  )

  join = (dfs: Map[String, DataFrame]) => {
    val doc_ord = dfs("document")
      .filter("document_class = 'ORDER'")
      .select("DOCUMENT_ID", "ORDER_DATETIME")
      .withColumnRenamed("DOCUMENT_ID", "DOCUMENT_ID_ord")

    val doc_res = dfs("document")
      .filter("document_class = 'LABRESULT'")
      .drop("DOCUMENT_CLASS", "ORDER_DATETIME")
      .withColumnRenamed("DOCUMENT_ID", "DOCUMENT_ID_res")
      .withColumnRenamed("CLINICAL_ORDER_TYPE", "CLINICAL_ORDER_TYPE_doc")

    dfs("clinicalResultObs")
      .join(dfs("clinicalResult"), Seq("clinical_result_id"), "inner")
      .join(doc_res, doc_res("DOCUMENT_ID_res") === coalesce(dfs("clinicalResult")("DOCUMENT_ID_cr"), dfs("clinicalResult")("RESULT_DOCUMENT_ID")), "inner")
      .join(doc_ord, doc_ord("DOCUMENT_ID_ord") === doc_res("ORDER_DOCUMENT_ID"), "left_outer")
      .join(dfs("loinc"), Seq("LOINC_ID"), "left_outer")
  }

  afterJoin = (df: DataFrame) => {
    df.filter("CLINICAL_OBSERVATION_ID is not null and HUM_RESULT is not null and PATIENT_ID is not null")
      .withColumn("LOCALCODE", coalesce(df("OBSERVATION_IDENTIFIER"), df("OBSERVATION_IDENTIFIER_TEXT"),
        when(df("TEMPLATE_ANALYTE_NAME").isNotNull, concat_ws("_", coalesce(df("CLINICAL_ORDER_TYPE_doc"), df("CLINICAL_ORDER_TYPE_cr")), df("TEMPLATE_ANALYTE_NAME"))).otherwise(coalesce(df("CLINICAL_ORDER_TYPE_doc"), df("CLINICAL_ORDER_TYPE_cr")))))
      .withColumn("LOCALNAME", coalesce(df("OBSERVATION_IDENTIFIER_TEXT"),
        when(df("TEMPLATE_ANALYTE_NAME").isNotNull, concat_ws("_", coalesce(df("CLINICAL_ORDER_TYPE_doc"), df("CLINICAL_ORDER_TYPE_cr")), df("TEMPLATE_ANALYTE_NAME"))).otherwise(coalesce(df("CLINICAL_ORDER_TYPE_doc"), df("CLINICAL_ORDER_TYPE_cr")))))

  }

  map = Map(
    "DATASRC" -> literal("clinicalresultobservation"),
    "LABRESULTID" -> mapFrom("CLINICAL_OBSERVATION_ID"),
    "LOCALRESULT" -> mapFrom("HUM_RESULT"),
    "LOCALRESULT_NUMERIC" -> mapFrom("LOCALRESULT_NUMERIC"),
    "LOCALRESULT_INFERRED" -> extract_value(),
    "LOCALUNITS_INFERRED" -> labresults_extract_uom(),
    "RELATIVEINDICATOR" -> labresults_extract_relativeindicator(),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "LOCALNAME" -> mapFrom("LOCALNAME"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "DATECOLLECTED" -> cascadeFrom(Seq("OBSERVATION_DATETIME", "SPECIMEN_COLLECTED_DATETIME")),
    "LABORDEREDDATE" -> mapFrom("ORDER_DATETIME"),
    "DATEAVAILABLE" -> cascadeFrom(Seq("RESULTS_REPORTED_DATETIME", "CREATED_DATETIME")),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "LABORDERID" -> mapFrom("DOCUMENT_ID_res"),
    "LOCALSPECIMENTYPE" -> mapFrom("SPECIMEN_SOURCE"),
    "LOCALTESTNAME" -> cascadeFrom(Seq("CLINICAL_ORDER_TYPE_doc", "CLINICAL_ORDER_TYPE_cr")),
    "LOCALUNITS" -> ((col: String, df: DataFrame) => { df.withColumn(col,when(lower(df("OBSERVATION_UNITS")).like ("http%"),null).otherwise(df("OBSERVATION_UNITS")))}),
    "NORMALRANGE" -> mapFrom("REFERENCE_RANGE"),
    "RESULTTYPE" -> mapFrom("RESULTTYPE"),
    "STATUSCODE" -> mapFrom("RESULT_STATUS"),
    "LOCAL_LOINC_CODE" -> mapFrom("LOINC_CODE")
  )

  afterMap = (df: DataFrame) => {
    val athena_start_dt = mpvList1(table("cdr.map_predicate_values"), config(GROUP), null, "CLINICALRESULTOBSERVATION", "LABRESULT", "CLINICALRESULT", "DATEAVAILABLE")
    df.withColumn("ATH_START_DT", to_date(when(lit("'NO_MPV_MATCHES'").isin(athena_start_dt: _*), lit("19010101")).otherwise(lit(athena_start_dt.head)), "yyyyMMdd"))
      .withColumn("LABRESULT_DATE", coalesce(df("DATEAVAILABLE"), df("DATECOLLECTED"), df("LABORDEREDDATE")))
      .filter("dateavailable >= ath_start_dt")
      .withColumn("LOCALRESULT", substring(df("LOCALRESULT"),0,2000)) // https://workflow.advisory.com/browse/IV-11082
  }


}


// test
//  val lr = new LabresultClinicalresultobservation(cfg); val lrc = build(lr,true); lrc.show ; lrc.count;

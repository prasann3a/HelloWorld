package com.humedica.mercury.etl.athena.microbioorder

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class MicrobioorderClinicalresultobservation(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("clinicalResultObs:athena.util.UtilDedupedClinicalResultObservation",
    "clinicalResult:athena.util.UtilDedupedClinicalResult",
    "document:athena.util.UtilDedupedDocument",
    "cdr.map_predicate_values"
  )

  columnSelect = Map(
    "clinicalResultObs" -> List("OBSERVATION_IDENTIFIER", "OBSERVATION_IDENTIFIER_TEXT", "CLINICAL_RESULT_ID", "CLINICAL_OBSERVATION_ID"),
    "clinicalResult" -> List("CLINICAL_RESULT_ID", "DOCUMENT_ID", "RESULTS_REPORTED_DATETIME", "CLINICAL_ORDER_TYPE",
      "SPECIMEN_RECEIVED_DATETIME", "RESULT_DOCUMENT_ID","ORDER_DOCUMENT_ID"),
    "document" -> List("DOCUMENT_ID", "OBSERVATION_DATETIME", "PATIENT_ID", "CLINICAL_ENCOUNTER_ID",
       "SPECIMEN_COLLECTED_DATETIME", "ORDER_DATETIME", "CLINICAL_ORDER_TYPE",
      "SPECIMEN_SOURCE", "SPECIMEN_DESCRIPTION")
  )

  beforeJoin = Map(
    "clinicalResultObs" -> ((df: DataFrame) => {
      val list_culture_names = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CLINICALRESULTOBSERVATION", "MBORDER", "CLINICALRESULTOBSERVATION", "OBSERVATION_IDENTIFIER_TEXT")
      df.filter(df("OBSERVATION_IDENTIFIER_TEXT").isin(list_culture_names: _*))
    }),
    "clinicalResult" -> ((df: DataFrame) => {
      df.withColumnRenamed("CLINICAL_ORDER_TYPE", "CLINICAL_ORDER_TYPE_cr")
        .withColumn("DOC_RESULT_ID", coalesce(df("ORDER_DOCUMENT_ID"), df("DOCUMENT_ID"), df("RESULT_DOCUMENT_ID")))
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("clinicalResultObs")
      .join(dfs("clinicalResult"), Seq("CLINICAL_RESULT_ID"), "inner")
      .join(dfs("document"), dfs("clinicalResult")("DOC_RESULT_ID") === dfs("document")("DOCUMENT_ID"), "inner")
  }

  map = Map(
    "DATASRC" -> literal("clinicalresultobservation"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "MBPROCORDERID" -> mapFrom("CLINICAL_OBSERVATION_ID"),
    "LOCALORDERCODE" -> ((col: String, df: DataFrame) => {df.withColumn(col,upper(df("OBSERVATION_IDENTIFIER")))}),
    "LOCALORDERDESC" -> ((col: String, df: DataFrame) => {df.withColumn(col,upper(df("OBSERVATION_IDENTIFIER_TEXT")))}),
    "LOCALSPECIMENSOURCE" -> ((col: String, df: DataFrame) => {df.withColumn(col,upper(df("SPECIMEN_SOURCE")))}),
    "LOCALSPECIMENNAME" -> ((col: String, df: DataFrame) => {df.withColumn(col,upper(df("SPECIMEN_DESCRIPTION")))}),
    "DATEORDERED" -> mapFrom("ORDER_DATETIME"),
    "DATECOLLECTED" -> cascadeFrom(Seq("SPECIMEN_COLLECTED_DATETIME","OBSERVATION_DATETIME")),
    "DATERECEIVED" -> mapFrom("SPECIMEN_RECEIVED_DATETIME"),
    "MBORDER_DATE" -> cascadeFrom(Seq("ORDER_DATETIME","SPECIMEN_COLLECTED_DATETIME", "OBSERVATION_DATETIME", "SPECIMEN_RECEIVED_DATETIME"))
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID"),df("LOCALORDERCODE"),df("DATEORDERED"),df("DATECOLLECTED"),df("DATERECEIVED"))
      .orderBy(df("MBPROCORDERID").desc_nulls_last)
    val addColumn1 = df.withColumn("rn", row_number.over(groups))
    addColumn1.filter("rn = 1 AND PATIENTID IS NOT NULL AND LOCALORDERCODE IS NOT NULL AND MBORDER_DATE IS NOT NULL ").drop("rn")
  }
}
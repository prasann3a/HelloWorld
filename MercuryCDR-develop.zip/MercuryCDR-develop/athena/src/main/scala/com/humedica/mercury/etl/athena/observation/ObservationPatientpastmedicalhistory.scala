package com.humedica.mercury.etl.athena.observation

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{coalesce, row_number, when, _}

class ObservationPatientpastmedicalhistory(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patientpastmedicalhistory"
    , "pat:athena.util.UtilSplitPatient"
    , "fileIdDates:athena.util.UtilFileIdDates"
    , "cdr.zcm_obstype_code")


  columnSelect = Map(
    "patientpastmedicalhistory" -> List("CREATED_DATETIME", "PAST_MEDICAL_HISTORY_QUESTION","PAST_MEDICAL_HISTORY_ANSWER", "PATIENT_ID", "PAST_MEDICAL_HISTORY_ID","FILEID", "CREATED_DATETIME", "DELETED_DATETIME"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "DATASRC", "OBSCODE", "CUI", "LOCALUNIT", "OBSTYPE", "OBSTYPE_STD_UNITS"),
    "pat" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "patientpastmedicalhistory" -> ((df: DataFrame) => {
      val fd = table("fileIdDates")
      val zcm = table("cdr.zcm_obstype_code").filter("groupid = '" + config(GROUP) + "' and datasrc = 'patientpastmedicalhistory'")

      val ph_df = df.join(fd, Seq("FILEID"), "inner")

      val ph_fd = ph_df.withColumn("OBSDATE", when(ph_df("CREATED_DATETIME") > ph_df("FILEDATE") || ph_df("FILEDATE") > current_timestamp, ph_df("CREATED_DATETIME"))
        .otherwise(coalesce(ph_df("FILEDATE"), ph_df("CREATED_DATETIME"))))
        .filter("PATIENT_ID IS NOT NULL AND OBSDATE IS NOT NULL AND DELETED_DATETIME IS NULL AND PAST_MEDICAL_HISTORY_ANSWER IS NOT NULL")
        .drop("DELETED_DATETIME")

      val groups = Window.partitionBy(ph_fd("OBSDATE"), ph_fd("PAST_MEDICAL_HISTORY_ID"), ph_fd("PAST_MEDICAL_HISTORY_ANSWER")).orderBy(ph_fd("FILEID").desc_nulls_last)
      ph_fd
        .withColumn("rn", row_number.over(groups))
        .filter("rn=1")
        .drop("rn")
        .join(zcm, ph_fd("PAST_MEDICAL_HISTORY_QUESTION") === zcm("OBSCODE"), "inner")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientpastmedicalhistory")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("patientpastmedicalhistory"),
    "LOCALRESULT" -> mapFrom("PAST_MEDICAL_HISTORY_ANSWER",prefix="pmh."),
    "LOCALCODE" -> mapFrom("PAST_MEDICAL_HISTORY_QUESTION"),
    "OBSDATE" -> mapFrom("OBSDATE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "LOCAL_OBS_UNIT" -> mapFrom("LOCALUNIT"),
    "OBSTYPE" -> mapFrom("OBSTYPE")
  )

}
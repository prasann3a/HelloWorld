package com.humedica.mercury.etl.athena.procedure

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class ProcedureTransaction(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "procedurecode",
    "fileIdDates:athena.util.UtilFileIdDates",
    "dedupedTrans:athena.util.UtilDedupedTransaction",
    "dedupedCE:athena.util.UtilDedupedClinicalEncounter",
    "tempClm:athena.util.UtilDedupedClaim",
    "pat:athena.util.UtilSplitPatient"
  )

  columnSelect = Map(
    "procedurecode" -> List("PROCEDURE_CODE_DESCRIPTION", "CONTEXT_ID", "PROCEDURE_CODE_ID", "PROCEDURE_CODE", "FILEID"),
    "dedupedTrans" -> List("PROCEDURE_CODE", "CLAIM_PATIENT_ID", "CHARGE_FROM_DATE", "SERVICE_DEPARTMENT_ID", "CLAIM_REFERRING_PROVIDER_ID",
      "CLAIM_APPOINTMENT_ID", "RENDERING_PROVIDER_ID", "CLAIM_ID", "VOIDED_DATE", "CLAIM_SERVICE_DATE", "CHARGE_ID"),
    "dedupedCE" -> List("CLINICAL_ENCOUNTER_ID", "CLAIM_ID", "APPOINTMENT_ID"),
    "tempClm" -> List("CLAIM_ID", "CLAIM_APPOINTMENT_ID", "PATIENT_ID", "CLAIM_SERVICE_DATE", "SERVICE_DEPARTMENT_ID", "RENDERING_PROVIDER_ID",
      "CLAIM_REFERRING_PROVIDER_ID"),
    "pat" -> List("PATIENT_ID")
  )

  beforeJoin = Map(
    "procedurecode" -> ((df: DataFrame) => {
      val joined = df.join(table("fileIdDates"), Seq("FILEID"), "left_outer")
      val groups = Window.partitionBy(joined("CONTEXT_ID"), joined("PROCEDURE_CODE_ID"), joined("PROCEDURE_CODE"))
        .orderBy(joined("FILEDATE").desc_nulls_last, joined("FILEID").desc_nulls_last)
      joined.withColumn("rn", row_number.over(groups)).filter("rn = 1").drop("rn").repartition(200)
    }),
    "tempClm" -> ((df: DataFrame) => {
      df.withColumnRenamed("CLAIM_APPOINTMENT_ID", "CLAIM_APPOINTMENT_ID_clm")
        .withColumnRenamed("CLAIM_SERVICE_DATE", "CLAIM_SERVICE_DATE_clm")
        .withColumnRenamed("SERVICE_DEPARTMENT_ID", "SERVICE_DEPARTMENT_ID_clm")
        .withColumnRenamed("RENDERING_PROVIDER_ID", "RENDERING_PROVIDER_ID_clm")
        .withColumnRenamed("CLAIM_REFERRING_PROVIDER_ID", "CLAIM_REFERRING_PROVIDER_ID_clm")
        .withColumnRenamed("PATIENT_ID", "PATIENT_ID_clm")
    }),
    "dedupedTrans" -> ((df: DataFrame) => {
      df.filter("VOIDED_DATE is null")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    val ce_cols = dfs("dedupedCE").columns.map(c => dfs("dedupedCE")(c).as(c + "_two"))
    val dedupedCE2 = dfs("dedupedCE").select(ce_cols: _*)
    dfs("dedupedTrans")
      .join(dfs("procedurecode"), Seq("PROCEDURE_CODE"), "left_outer")
      .join(dfs("tempClm"), Seq("CLAIM_ID"), "left_outer")
      .join(dfs("dedupedCE"), Seq("CLAIM_ID"), "left_outer")
      .join(dedupedCE2, dedupedCE2("APPOINTMENT_ID_two") === coalesce(dfs("tempClm")("CLAIM_APPOINTMENT_ID_clm"),
        dfs("dedupedTrans")("CLAIM_APPOINTMENT_ID")), "left_outer").repartition(10000)
      .join(dfs("pat"), dfs("pat")("PATIENT_ID") === coalesce(dfs("dedupedTrans")("CLAIM_PATIENT_ID"), dfs("tempClm")("PATIENT_ID_clm")), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("transaction"),
    "LOCALCODE" -> mapFrom("PROCEDURE_CODE"),
    "PATIENTID" -> cascadeFrom(Seq("CLAIM_PATIENT_ID", "PATIENT_ID_clm")),
    "PROCEDUREDATE" -> cascadeFrom(Seq("CHARGE_FROM_DATE", "CLAIM_SERVICE_DATE_clm", "CLAIM_SERVICE_DATE")),
    "ACTUALPROCDATE" -> mapFrom("PROCEDUREDATE"),
    "ENCOUNTERID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("CLINICAL_ENCOUNTER_ID"), df("CLINICAL_ENCOUNTER_ID_two"), concat(lit("a."), df("CLAIM_APPOINTMENT_ID"))))
    }),
    "FACILITYID" -> cascadeFrom(Seq("SERVICE_DEPARTMENT_ID", "SERVICE_DEPARTMENT_ID_clm")),
    "LOCALNAME" -> mapFrom("PROCEDURE_CODE_DESCRIPTION"),
    "PERFORMINGPROVIDERID" -> cascadeFrom(Seq("RENDERING_PROVIDER_ID", "RENDERING_PROVIDER_ID_clm")),
    "REFERPROVIDERID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat(lit("rp."), coalesce(df("CLAIM_REFERRING_PROVIDER_ID"), df("CLAIM_REFERRING_PROVIDER_ID_clm"))))
    }),
    "SOURCEID" -> mapFrom("CHARGE_ID"),
    "MAPPEDCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, substring(df("PROCEDURE_CODE"), 1, 5))
    }),
    "CODETYPE" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("tmp", substring(df("PROCEDURE_CODE"), 1, 5))
      df1.withColumn(col,
        when(df1("tmp").rlike("^[0-9]{4}[0-9A-Z]$"), lit("CPT4"))
          .when(df1("tmp").rlike("^[A-Z][0-9]{4}$"), lit("HCPCS"))
          .when(df1("tmp").rlike("[0-9]{4}$"), lit("REV"))
          .when(df1("tmp").rlike("^[0-9]{2}.[0-9]{1,2}$"), lit("ICD9"))
          .otherwise(lit(null)))
    })
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.filter("PROCEDUREDATE is not null and PATIENTID is not null")
    val cols = Engine.schema.getStringList("Procedure").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*)
      .distinct
  }  
}
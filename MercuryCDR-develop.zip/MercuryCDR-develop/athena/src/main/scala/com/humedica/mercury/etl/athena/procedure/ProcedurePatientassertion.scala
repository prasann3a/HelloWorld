package com.humedica.mercury.etl.athena.procedure

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

/**
  * Auto-generated on 09/21/2018
  */


class ProcedurePatientassertion(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patientassertion",
    "fileExtractDates:athena.util.UtilFileIdDates",
    "pat:athena.util.UtilSplitPatient",
    "cdr.map_custom_proc")

  columnSelect = Map(
    "patientassertion" -> List("PATIENT_ASSERTION_ID", "HUM_TYPE", "PATIENT_ASSERTION_KEY", "PATIENT_ID",
      "PATIENT_ASSERTION_VALUE", "FILEID", "DELETED_DATETIME"),
    "fileExtractDates" -> List("FILEID", "FILEDATE"),
    "pat" -> List("PATIENT_ID"),
    "cdr.map_custom_proc" -> List("GROUPID", "DATASRC", "LOCALCODE", "MAPPEDVALUE")
  )

  beforeJoin = Map(
    "cdr.map_custom_proc" -> ((df: DataFrame) => {
      df.filter("groupid = '" + config(GROUP) + "' and datasrc = 'patientassertion'")
        .drop("GROUPID", "DATASRC")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientassertion")
      .join(dfs("fileExtractDates"), Seq("FILEID"), "left_outer")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
      .join(dfs("cdr.map_custom_proc"), dfs("patientassertion")("PATIENT_ASSERTION_KEY") === dfs("cdr.map_custom_proc")("LOCALCODE"), "inner")
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENT_ASSERTION_ID"), df("HUM_TYPE"), df("MAPPEDVALUE"))
      .orderBy(df("FILEDATE").desc_nulls_last, df("FILEID").desc_nulls_last)

    df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1 and deleted_datetime is null and patient_id is not null")
  }

  map = Map(
    "DATASRC" -> literal("patientassertion"),
    "LOCALCODE" -> mapFrom("PATIENT_ASSERTION_KEY"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "PROCEDUREDATE" -> ((col: String, df: DataFrame) => {
      safe_to_date(df, "PATIENT_ASSERTION_VALUE", col, "MM/dd/yyyy")
    }),
    "LOCALNAME" -> mapFrom("PATIENT_ASSERTION_KEY"),
    "MAPPEDCODE" -> mapFrom("MAPPEDVALUE"),
    "CODETYPE" -> literal("CUSTOM")
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("PROCEDUREDATE is not null and PATIENTID is not null")
    val cols = Engine.schema.getStringList("Procedure").asScala.map(_.split("-")(0).toUpperCase())
    fil.select(cols.map(col): _*)
     .distinct
  }
}
package com.humedica.mercury.etl.athena.observation

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window


class ObservationClinicalresultobservation(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {


  tables = List("clinicalResultObs:athena.util.UtilDedupedClinicalResultObservation"
    , "clinicalResult:athena.util.UtilDedupedClinicalResult"
    , "document:athena.util.UtilDedupedDocument"
    , "pat:athena.util.UtilSplitPatient"
    , "cdr.zcm_obstype_code")

  columnSelect = Map(
    "clinicalResultObs" -> List("HUM_RESULT", "OBSERVATION_IDENTIFIER_TEXT", "CLINICAL_RESULT_ID", "DELETED_DATETIME"),
    "clinicalResult" -> List("CREATED_DATETIME", "RESULT_STATUS", "CLINICAL_RESULT_ID", "DOCUMENT_ID", "RESULT_DOCUMENT_ID", "DELETED_DATETIME"),
    "document" -> List("DOCUMENT_ID", "OBSERVATION_DATETIME", "PATIENT_ID", "CLINICAL_ENCOUNTER_ID", "DEPARTMENT_ID"),
    "pat" -> List("PATIENT_ID"),
    "cdr.zcm_obstype_code" -> List("OBSTYPE", "OBSCODE", "OBSTYPE_STD_UNITS", "LOCALUNIT", "GROUPID", "DATASRC")
  )


  beforeJoin = Map(
    "clinicalResultObs" -> ((df: DataFrame) => {
      val clinicalResultObsDf = df.filter("DELETED_DATETIME is null").drop("DELETED_DATETIME")
      val zcm = table("cdr.zcm_obstype_code").filter("GROUPID = '" + config(GROUP) + "' AND DATASRC = 'clinicalresultobservation' and cui <> 'CH002048'")
      clinicalResultObsDf.join(zcm, clinicalResultObsDf("OBSERVATION_IDENTIFIER_TEXT") === zcm("OBSCODE"), "inner")
    }),
    "clinicalResult" -> ((df: DataFrame) => {
      df.filter("DELETED_DATETIME is null").drop("DELETED_DATETIME")
    })
  )


  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("clinicalResultObs")
      .join(dfs("clinicalResult"), Seq("clinical_result_id"), "inner")
      .join(dfs("document"), dfs("document")("DOCUMENT_ID") === coalesce(dfs("clinicalResult")("DOCUMENT_ID"), dfs("clinicalResult")("RESULT_DOCUMENT_ID")), "inner")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("clinicalresultobservation"),
    "LOCALRESULT" -> mapFrom("HUM_RESULT"),
    "LOCALCODE" -> mapFrom("OBSERVATION_IDENTIFIER_TEXT"),
    "OBSDATE" -> cascadeFrom(Seq("OBSERVATION_DATETIME", "CREATED_DATETIME")),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "FACILITYID" -> mapFrom("DEPARTMENT_ID"),
    "LOCAL_OBS_UNIT" -> mapFrom("LOCALUNIT"),
    "STATUSCODE" -> mapFrom("RESULT_STATUS"),
    "OBSTYPE" -> mapFrom("OBSTYPE"),
    "STD_OBS_UNIT" -> mapFrom("OBSTYPE_STD_UNITS")
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.filter("PATIENTID is not null and LOCALRESULT is not null and OBSDATE is not null")
    val groups = Window.partitionBy(df1("PatientId"), df1("ENCOUNTERID"), df1("LOCALCODE"), df1("OBSDATE"), df1("OBSTYPE"), df1("LOCALRESULT"), df1("STATUSCODE"))
      .orderBy(df1("facilityid").asc_nulls_last)
    df1.withColumn("rn", row_number.over(groups))
      .filter("rn = 1")
      .drop("rn")
  }

}

// test
//  val ob = new ObservationClinicalresultobservation(cfg); val obs = build(ob,true); obs.show ; obs.count;

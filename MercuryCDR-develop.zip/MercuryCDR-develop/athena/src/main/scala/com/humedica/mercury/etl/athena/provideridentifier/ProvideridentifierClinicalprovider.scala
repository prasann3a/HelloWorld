package com.humedica.mercury.etl.athena.provideridentifier

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame

/**
  * Auto-generated on 09/21/2018
  */


class ProvideridentifierClinicalprovider(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("clinicalprovider:athena.util.UtilDedupedClinicalProvider",
    "cdr.ref_cmsnpi")

  columnSelect = Map(
    "clinicalprovider" -> List("NPI", "CLINICAL_PROVIDER_ID"),
    "cdr.ref_cmsnpi" -> List("NPI", "ENTITY_TYPE_CODE")
  )

  beforeJoin = Map(
    "clinicalprovider" -> includeIf("clinical_provider_id is not null")
  )

  join = noJoin()

  map = Map(
    "ID_TYPE" -> literal("NPI"),
    "ID_VALUE" -> mapFrom("NPI"),
    "PROVIDER_ID" -> mapFrom("CLINICAL_PROVIDER_ID", prefix = "cp.")
  )

  afterMap = includeIf("id_value is not null")

  joinExceptions = Map(
    "H984728_ATHENA_DWF_4" -> ((dfs: Map[String, DataFrame]) => {
      dfs("clinicalprovider")
        .join(dfs("cdr.ref_cmsnpi"), Seq("NPI"), "left_outer")
    })
  )

  mapExceptions = Map(
    ("H984728_ATHENA_DWF_4", "ID_VALUE") -> mapFromSecondColumnValueIsIn("NPI", "ENTITY_TYPE_CODE", Seq("1"))
  )

}
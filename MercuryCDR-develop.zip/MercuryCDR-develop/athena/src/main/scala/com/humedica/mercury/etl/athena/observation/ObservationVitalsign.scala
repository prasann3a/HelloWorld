package com.humedica.mercury.etl.athena.observation

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine,EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

/**
  * Auto-generated on 09/21/2018
  */


class ObservationVitalsign(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("vitalsign",
    "ce:athena.util.UtilDedupedClinicalEncounter",
    "fileIdDates:athena.util.UtilFileIdDates",
    "cdr.zcm_obstype_code",
    "cdr.map_predicate_values")

  columnSelect = Map(
    "vitalsign" -> List("HUM_KEY", "CLINICAL_ENCOUNTER_ID", "HUM_VALUE", "FILEID", "CREATED_DATETIME", "DELETED_DATETIME",
      "ENCOUNTER_DATA_ID", "HUM_TYPE"),
    "ce" -> List("CLINICAL_ENCOUNTER_ID", "ENCOUNTER_DATE", "PATIENT_ID"),
    "fileIdDates" -> List("FILEID", "FILEDATE"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "DATASRC", "OBSCODE", "CUI", "LOCALUNIT", "OBSTYPE", "OBSTYPE_STD_UNITS")
  )

  beforeJoin = Map(
    "vitalsign" -> ((df: DataFrame) => {
      val fd = table("fileIdDates")
      val zcm = table("cdr.zcm_obstype_code")
        .filter("groupid = '" + config(GROUP) + "' and datasrc = 'vitalsign' and cui <> 'CH002048'")
        .drop("GROUPID", "DATASRC")

      val vital_fd = df.join(fd, Seq("FILEID"), "left_outer")
      val groups = Window.partitionBy(vital_fd("ENCOUNTER_DATA_ID"), vital_fd("HUM_TYPE"))
        .orderBy(vital_fd("FILEDATE").desc_nulls_last, vital_fd("FILEID").desc_nulls_last)

      vital_fd.join(zcm, vital_fd("HUM_KEY") === zcm("OBSCODE"), "inner")
        .withColumn("rn", row_number.over(groups))
        .filter("rn = 1 and deleted_datetime is null")
        .drop("rn")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("vitalsign")
      .join(dfs("ce"), Seq("CLINICAL_ENCOUNTER_ID"), "inner")
  }

  afterJoin = (df: DataFrame) => {
    val athena_start_dt = mpvList1(table("cdr.map_predicate_values"), config(GROUP), null, "VITALSIGN", "OBSERVATION", "CLINICALENCOUNTER", "ENCOUNTER_DATE")
    df.withColumn("ATH_START_DT", to_date(when(lit("'NO_MPV_MATCHES'").isin(athena_start_dt: _*), lit("20991231")).otherwise(lit(athena_start_dt.head)), "yyyyMMdd"))
  }

  map = Map(
    "DATASRC" -> literal("vitalsign"),
    "LOCALCODE" -> mapFrom("HUM_KEY"),
    "OBSDATE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("ENCOUNTER_DATE") < df("ATH_START_DT"), df("ENCOUNTER_DATE")).otherwise(df("CREATED_DATETIME")))
    }),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "ENCOUNTERID" -> mapFrom("CLINICAL_ENCOUNTER_ID"),
    "LOCALRESULT" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, substring(df("HUM_VALUE"), 1, 255))
    }),
    "LOCAL_OBS_UNIT" -> mapFrom("LOCALUNIT"),
    "STD_OBS_UNIT" -> mapFrom("OBSTYPE_STD_UNITS"),
    "OBSTYPE" -> mapFrom("OBSTYPE")
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.filter("patientid is not null and obsdate is not null and localresult is not null")
    val cols = Engine.schema.getStringList("Observation").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*)
      .distinct
  }

}
package com.humedica.mercury.etl.athena.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcAllergy(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "allergy"
  )

  columnSelect = Map(
    "allergy" -> List("ALLERGY_NAME", "NOTE", "HUM_TYPE", "ALLERGY_CODE", "RXNORM_CODE")
  )

  beforeJoin = Map(
    "allergy" -> ((df: DataFrame) => {
      df.filter("HUM_TYPE = 'PATIENTALLERGY'")
    })
  )

  map = Map(
    "DATASRC" -> literal("allergy"),
    "LOCALMEDCODE" -> ((col, df) => df.withColumn(col, coalesce(df("ALLERGY_NAME"), df("NOTE")))),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, coalesce(df("ALLERGY_NAME"), df("NOTE")))),
    "RXNORM_CODE" -> mapFrom("RXNORM_CODE")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("ALLERGY_CODE"), df("LOCALDESCRIPTION"), df("RXNORM_CODE"))
    val df1 = df.withColumn("NUM_RECS", count("*").over(groups))
      .withColumn("NO_NDC", count("*").over(groups))
      .withColumn("HAS_NDC", lit(0))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcAllergy(cfg); val med_s = build(a, allColumns = true);

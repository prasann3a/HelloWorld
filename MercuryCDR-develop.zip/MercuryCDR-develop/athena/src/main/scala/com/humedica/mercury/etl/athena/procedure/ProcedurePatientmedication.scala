package com.humedica.mercury.etl.athena.procedure

import com.humedica.mercury.etl.athena.util.UtilSplitTable
import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
  * Auto-generated on 09/21/2018
  */


class ProcedurePatientmedication(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patientmedication",
    "fileExtractDates:athena.util.UtilFileIdDates",
    "pat:athena.util.UtilSplitPatient",
    "cdr.map_custom_proc")

  columnSelect = Map(
    "patientmedication" -> List("MEDICATION_TYPE", "PATIENT_ID", "CLINICAL_ENCOUNTER_ID", "NOTE", "FILEID", "DELETED_DATETIME"),
    "fileExtractDates" -> List("FILEID", "FILEDATE"),
    "pat" -> List("PATIENT_ID"),
    "cdr.map_custom_proc" -> List("GROUPID", "LOCALCODE", "MAPPEDVALUE", "CODETYPE", "DATASRC")
  )

  beforeJoin = Map(
    "patientmedication" -> ((df: DataFrame) => {
      val fileExtractDates = table("fileExtractDates")
      val joined = df.join(fileExtractDates, Seq("FILEID"), "left_outer")
      val joinedDate = coalesceDate(joined, "NOTE", "PROC_DATE")
      val groups = Window.partitionBy(joinedDate("PATIENT_ID"), joinedDate("CLINICAL_ENCOUNTER_ID"), joinedDate("PROC_DATE"), joinedDate("MEDICATION_TYPE"))
        .orderBy(joinedDate("FILEDATE").desc_nulls_last, joinedDate("FILEID").desc_nulls_last)

      joinedDate.withColumn("dedupe_row", row_number.over(groups))
        .filter("dedupe_row = 1 and DELETED_DATETIME is null")
    }),
    "cdr.map_custom_proc" -> ((df: DataFrame) => {
      df.filter("groupid = '" + config(GROUPID) + "' and datasrc = 'patientmedication'")
        .drop("GROUPID", "DATASRC")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val patJoinType = new UtilSplitTable(config).patprovJoinType
    dfs("patientmedication")
      .join(dfs("cdr.map_custom_proc"), dfs("patientmedication")("MEDICATION_TYPE") === dfs("cdr.map_custom_proc")("LOCALCODE"), "inner")
      .join(dfs("pat"), Seq("PATIENT_ID"), patJoinType)
  }

  map = Map(
    "DATASRC" -> literal("patientmedication"),
    "LOCALCODE" -> mapFrom("MEDICATION_TYPE"),
    "PATIENTID" -> mapFrom("PATIENT_ID"),
    "PROCEDUREDATE" -> mapFrom("PROC_DATE"),
    "LOCALNAME" -> mapFrom("MEDICATION_TYPE"),
    "MAPPEDCODE" -> mapFrom("MAPPEDVALUE"),
    "CODETYPE" -> mapFrom("CODETYPE")
  )

  afterMap = (df: DataFrame) => {
    df.filter("PROCEDUREDATE is not null and PATIENTID is not null")
  }    
  
}
package com.humedica.mercury.etl.athena.util

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


class UtilDedupedRecentTobaccoSocialHistory(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  cacheMe = true
  columns = List("PATIENT_ID", "SOCIAL_HISTORY_KEY", "SOCIAL_HISTORY_ANSWER", "TOBACCO_DATE", "DELETED_DATETIME")

  tables = List("recenttobaccodate:athena.util.UtilDedupedPatientSocialHistory",
    "obsfiledate:athena.util.UtilDedupedPatientSocialHistory",
    "cdr.zcm_obstype_code")

  columnSelect = Map(
    "obsfiledate" -> List("PATIENT_ID", "SOCIAL_HISTORY_KEY", "SOCIAL_HISTORY_NAME", "SOCIAL_HISTORY_ANSWER", "DELETED_DATETIME", "FD_FILEDATE", "CHART_ID"),
    "recenttobaccodate" -> List("SOCIAL_HISTORY_KEY", "SOCIAL_HISTORY_NAME", "SOCIAL_HISTORY_ANSWER", "FD_FILEDATE", "CHART_ID"),
    "cdr.zcm_obstype_code" -> List("GROUPID", "OBSCODE", "DATASRC", "CUI", "OBSTYPE")
  )


  beforeJoin = Map(
    "obsfiledate" -> ((df: DataFrame) => {
      val obsdf = df.withColumnRenamed("SOCIAL_HISTORY_NAME", "OBS_NAME")
        .withColumnRenamed("FD_FILEDATE", "OBS_FILE_DATE")
        .withColumnRenamed("CHART_ID", "CHART_ID_obs")

      val zcm = table("cdr.zcm_obstype_code")
        .filter("DATASRC = 'patientsocialhistory' and GROUPID = '" + config(GROUP) + "' and cui <> 'CH002048' and OBSTYPE in ('SMOKE', 'CH001850')")
        .select("OBSCODE")
        .distinct()

      obsdf.join(zcm, obsdf("SOCIAL_HISTORY_KEY") === zcm("OBSCODE"), "inner")
        .select("PATIENT_ID", "SOCIAL_HISTORY_KEY", "OBS_NAME", "SOCIAL_HISTORY_ANSWER", "OBS_FILE_DATE", "DELETED_DATETIME", "CHART_ID_obs")
        .distinct()
    }),
    "recenttobaccodate" -> ((df: DataFrame) => {
      val fil = df.filter("SOCIAL_HISTORY_KEY = 'SOCIALHISTORY.MOSTRECENTTOBACCOUSESCREENING'")
        .withColumnRenamed("FD_FILEDATE", "TOBACCO_FILE_DATE")
        .withColumnRenamed("SOCIAL_HISTORY_NAME", "TOBACCO_NAME")
      coalesceDate(fil, "SOCIAL_HISTORY_ANSWER", "TOBACCO_DATE")
        .select("CHART_ID", "TOBACCO_DATE", "TOBACCO_FILE_DATE", "TOBACCO_NAME")
        .distinct()

    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("recenttobaccodate")
      .join(dfs("obsfiledate"), dfs("recenttobaccodate")("CHART_ID") === dfs("obsfiledate")("CHART_ID_obs") && dfs("recenttobaccodate")("TOBACCO_DATE") >= dfs("obsfiledate")("OBS_FILE_DATE"), "inner")
  }


  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENT_ID"), df("TOBACCO_FILE_DATE"), coalesce(df("OBS_NAME"), df("SOCIAL_HISTORY_KEY")))
      .orderBy(df("TOBACCO_DATE").desc, df("OBS_FILE_DATE").desc, df("OBS_NAME").desc)
    df.withColumn("rw", row_number.over(groups))
      .filter("rw = 1")
  }

}


// test
//  val a = new UtilDedupedReviewedSocialHistory(cfg); val o = build(a); o.count

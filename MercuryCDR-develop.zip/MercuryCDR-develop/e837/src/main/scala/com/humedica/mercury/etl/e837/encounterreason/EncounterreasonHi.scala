package com.humedica.mercury.etl.e837.encounterreason

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import org.apache.spark.sql.DataFrame
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class EncounterreasonHi(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temphi:e837.temptable.TemptableTemphisegment"
  )

  columnSelect = Map(
    "temphi" -> List("CLM_TYPE","PATIENTID","ENCOUNTERID","LOCALCODE","CD_TIMESTAMP","ENCOUNTERREASON")
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "LOCALREASONTEXT" -> mapFrom("LOCALCODE"),
    "REASONTIME" -> mapFrom("CD_TIMESTAMP")
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("ENCOUNTERREASON = 'Y' and REASONTIME is not null")
    val cols = Engine.schema.getStringList("Encounterreason").asScala.map(_.split("-")(0).toUpperCase())
    fil.select(cols.map(col): _*)
      .distinct
  }
}

// val es = new EncounterreasonHi(cfg); val er = build(es,allColumns=true)
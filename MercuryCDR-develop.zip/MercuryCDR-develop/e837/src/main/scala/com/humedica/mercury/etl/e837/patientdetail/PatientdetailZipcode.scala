package com.humedica.mercury.etl.e837.patientdetail

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class PatientdetailZipcode(config: Map[String,String]) extends EntitySource(config: Map[String,String])  {

  tables = List(
    "temptable:e837.temptable.TemptableTemppatient"
  )

  columnSelect = Map(
    "temptable" -> List("PATIENTID", "CLM_TYPE", "FILE_ID","ENCOUNTERID", "UPDATE_DT","SUBISPAT", "PAT_ZIP")
  )


  map = Map(
    "PATIENTID" -> mapFrom("PATIENTID"),
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "FACILITYID" -> nullValue(),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "PATIENTDETAILTYPE" -> literal("ZIPCODE"),
    "PATDETAIL_TIMESTAMP"  -> mapFrom("UPDATE_DT"),
    "LOCALVALUE" ->  standardizeZip("PAT_ZIP",zip5=true)
  )
  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID"), df("LOCALVALUE")).orderBy(df("FILE_ID").desc_nulls_last)
    val addcol = df.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1 and PATIENTID is not null and LOCALVALUE is not null ").drop("rn")

  }


}

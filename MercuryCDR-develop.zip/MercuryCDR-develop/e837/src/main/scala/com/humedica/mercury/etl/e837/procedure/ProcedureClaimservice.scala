package com.humedica.mercury.etl.e837.procedure

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class ProcedureClaimservice(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "tempservice:e837.temptable.TemptableTempservice"
  )

  columnSelect = Map(
    "tempservice" -> List("PATIENTID","CLAIMID","ENCOUNTERID","CLM_TYPE","SUBMIT_DT","PROC_DT","CHARGE_AMT","QTY"
      ,"PROC_CD","CPTMOD1","CPTMOD2","CPTMOD3","CPTMOD4","PERFPROVID","CLAIMLINEID","REFPROVID","ORDERINGPROVID"
      ,"PROC_TYP")
  )

  beforeJoin = Map(
    "temptable" -> ((df: DataFrame) => {
      df.filter("PATEINTID is not null and PROC_CD is not null and PROC_DT is not null")
    })
  )

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "SOURCEID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(substring(df("CLM_TYPE"),1,4) === lit("837P"), df("CLAIMLINEID"))
        .when(substring(df("CLM_TYPE"),1,4) === lit("837I"), df("ENCOUNTERID"))
        .otherwise(null))
    }),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "PERFORMINGPROVIDERID" -> mapFrom("PERFPROVID"),
    "REFERPROVIDERID" -> mapFrom("REFPROVID"),
    "LOCALBILLINGPROVIDERID" -> nullValue(),
    "ORDERINGPROVIDERID" -> mapFrom("ORDERINGPROVID"),
    "PROCEDUREDATE" -> mapFrom("PROC_DT"),
    "LOCALCODE" -> mapFrom("PROC_CD"),
    "CODETYPE" -> mapFrom("PROC_TYP"),
    "MAPPEDCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, substring(df("PROC_CD"),1,5))
    }),
    "HOSP_PX_FLAG" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("CLM_TYPE").like("837I%"), lit("Y")).otherwise(lit("N")))
    }),
    "ACTUALPROCDATE" -> mapFrom("PROC_DT")
  )

  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Procedure").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*).distinct()
      .filter("PROCEDUREDATE is not null and PATIENTID is not null")
  }

}

//val es = new ProcedureClaimservice(cfg); val proc = build(es,allColumns=true)
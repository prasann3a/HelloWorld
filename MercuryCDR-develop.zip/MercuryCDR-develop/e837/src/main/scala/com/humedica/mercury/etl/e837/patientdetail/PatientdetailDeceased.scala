package com.humedica.mercury.etl.e837.patientdetail

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class PatientdetailDeceased(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temptable:e837.temptable.TemptableTemppatient"
  )
  columnSelect = Map(
    "temptable" -> List("PATIENTID", "CLM_TYPE", "FILE_ID","ENCOUNTERID", "UPDATE_DT", "DOD")
  )


  map = Map(
    "PATIENTID" -> mapFrom("PATIENTID"),
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "FACILITYID" -> nullValue(),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "PATIENTDETAILTYPE" -> literal("DECEASED"),
    "PATDETAIL_TIMESTAMP"  -> mapFrom("UPDATE_DT"),
    "LOCALVALUE" -> literal("DeathDatePresent")
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("PATIENTID is not null and DOD is not null ")
    val groups = Window.partitionBy(fil("PATIENTID"), fil("LOCALVALUE")).orderBy(fil("FILE_ID").desc_nulls_last)
    val addcol = fil.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1").drop("rn")

  }
}

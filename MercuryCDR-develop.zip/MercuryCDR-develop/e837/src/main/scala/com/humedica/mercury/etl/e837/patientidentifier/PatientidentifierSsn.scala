package com.humedica.mercury.etl.e837.patientidentifier

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class PatientidentifierSsn(config: Map[String,String]) extends EntitySource(config: Map[String,String])  {

  tables = List(
    "temptable:e837.temptable.TemptableTemppatient"
  )

  columnSelect = Map(
    "temptable" -> List("PATIENTID", "CLM_TYPE", "FILE_ID", "MRN", "PAT_ALT_ID", "SUBISPAT", "PAT_ALT_ID_QUAL","SUB_ALT_ID")
  )


  map = Map(
    "PATIENTID" -> mapFrom("PATIENTID"),
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "IDTYPE" -> literal("SSN"),
    "IDVALUE" ->  ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("PAT_ALT_ID_QUAL") === lit("SY"), df("PAT_ALT_ID"))
        .otherwise(null))
    }),
    "ID_SUBTYPE" -> nullValue()
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.withColumn("alt_id",when(df("SUBISPAT") === lit(0), df("PAT_ALT_ID")).otherwise(df("SUB_ALT_ID")))
    val groups = Window.partitionBy(df1("PATIENTID"), df1("alt_id")).orderBy(df1("FILE_ID").desc_nulls_last)
    val addcol = df1.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1 and PATIENTID is not null and IDVALUE is not null").drop("rn", "alt_id")

  }
}

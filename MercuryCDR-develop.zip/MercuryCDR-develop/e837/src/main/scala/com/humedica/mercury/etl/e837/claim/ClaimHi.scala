package com.humedica.mercury.etl.e837.claim

import com.humedica.mercury.etl.core.engine.{Engine,EntitySource}
import org.apache.spark.sql.DataFrame
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class ClaimHi(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temphi:e837.temptable.TemptableTemphisegment"
  )

  columnSelect = Map(
    "temphi" -> List("CLM_TYPE","PATIENTID","ENCOUNTERID","CLAIM_ID","LOCALCODE","CD_TIMESTAMP","PERFPROV_ID","SOURCEID"
      ,"CD_QUAl_FINAL")
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "FACILITYID" -> nullValue(),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "CLAIMID" -> mapFrom("CLAIM_ID"),
    "SERVICEDATE" -> mapFrom("CD_TIMESTAMP"),
    "LOCALCPT" -> mapFrom("LOCALCODE"),
    "CLAIMPROVIDERID" -> mapFrom("PERFPROV_ID"),
    "MAPPEDCPT" -> mapFrom("LOCALCODE"),
    "SOURCEID" -> mapFrom("SOURCEID")
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.withColumn("LCODE", when(df("LOCALCODE").rlike("^[0-9]{4}[0-9A-Z]$") || df("LOCALCODE").rlike("^[A-Z][0-9]{4}$'"), lit("Y"))
        .otherwise(lit("N")))
    val df2 = df1.filter("CD_QUAL_FINAL = 'Px' and SERVICEDATE is not null and LCODE = 'Y' and PATIENTID is not null")
    val cols = Engine.schema.getStringList("Claim").asScala.map(_.split("-")(0).toUpperCase())
    df2.select(cols.map(col): _*).distinct()
  }
}

//val es = new ClaimHi(cfg); val er = build(es,allColumns=true)
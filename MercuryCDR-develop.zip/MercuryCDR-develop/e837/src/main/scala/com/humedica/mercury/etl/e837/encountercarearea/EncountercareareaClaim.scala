package com.humedica.mercury.etl.e837.encountercarearea

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Constants._

class EncountercareareaClaim(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temptable:e837.temptable.TemptableTempclaim"
    ,"e837_loop_2300_hi"
    ,"e837_loop_2300_cl1"
    ,"e837_loop_2400_sv2"
    ,"e837_loop_2400_dtp"
    ,"e837_loop_2310_nm1"
    ,"cdr.map_care_area"
  )

  columnSelect = Map(
    "temptable" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","MED_REC_NBR","CLM_TYPE","SUBISPAT","SUBMIT_DT","CLM_DT","MRN","ENC_ID","ADMIT_DT","CLM_START_DT"
      ,"DISCHARGE_DT","DISCHARGE_TM","CLM_END_DT","LOC_TYPE_CD","TOTAL_CHARGE","FACILITYID","BATCH_ID"),
    "e837_loop_2300_hi" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","R01_R01","R01_R02"),
    "e837_loop_2300_cl1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","R01","R02","R03"),
    "e837_loop_2400_sv2" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","LOOP_2400_IDX","SEGMENT_IDX","R01"),
    "e837_loop_2400_dtp" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","LOOP_2400_IDX","R01","R02","R03"),
    "e837_loop_2310_nm1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","LOOP_QUALIFIER","R02","R09","BATCH_ID"),
    "cdr.map_care_area" -> List("GROUPID","LOCAL_CODE","CUI")
  )

  beforeJoin = Map(
    "temptable" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .withColumn("SUPRESS_DRGS", when(lit(config(CLIENT_DS_ID)).isin("2241","561","4825","7548","7549"), lit("Y"))
          .otherwise(lit("N")))
        .filter("MED_REC_NBR is not null and ENC_ID is not null and CLM_DT is not null")
    }),
    "e837_loop_2300_hi" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("R01_R01 = 'DR'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R01_R01","DRG_R01_R01")
        .withColumnRenamed("R01_R02","DRG_R01_R02")
    }),
    "e837_loop_2300_cl1" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R01","CL1_R01")
        .withColumnRenamed("R02","CL1_R02")
        .withColumnRenamed("R03","CL1_R03")
    }),
    "e837_loop_2400_sv2" -> ((df: DataFrame) => {
      val svctbl = df.coalesce(1000)
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumn("SVC_R01", lpad(df("R01"),4,"0"))

      val dtptbl = table("e837_loop_2400_dtp").coalesce(1000).filter("R01 = '472'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R01","DTP_R01")
        .withColumnRenamed("R02","DTP_R02")
        .withColumnRenamed("R03","DTP_R03")

      svctbl.join(dtptbl, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX","LOOP_2400_IDX"), "left_outer")
    }),
    "e837_loop_2310_nm1" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("LOOP_QUALIFIER = 'D' and R02 = '2'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R01","CLMRENDPROV_R02")
        .withColumnRenamed("R02","CLMRENDPROV_R09")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("temptable")
      .join(dfs("e837_loop_2300_hi"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX"),"left_outer")
      .join(dfs("e837_loop_2300_cl1"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX"),"left_outer")
      .join(dfs("e837_loop_2400_sv2"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX"),"left_outer")
      .join(dfs("e837_loop_2310_nm1"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX","BATCH_ID"),"left_outer")
      .join(dfs("cdr.map_care_area"), lit(config(GROUP)) === dfs("cdr.map_care_area")("GROUPID")
        && dfs("e837_loop_2400_sv2")("SVC_R01") === dfs("cdr.map_care_area")("LOCAL_CODE"), "left_outer")
  }

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "PATIENTID" -> mapFrom("MED_REC_NBR"),
    "ENCOUNTERID" -> mapFrom("ENC_ID"),
    "ENCOUNTERTIME" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("DTP_R03_1", substring(df("DTP_R03"),1,8))
      //val df2 = safe_to_date(df1, "DTP_R03", "DTP_R03_DT", "yyyyMMdd", 8)

      val len = df1.withColumn("lenAddm", datelengthcheck(df1("DTP_R03_1"), lit("yyyyMMdd")))
      val df2 = len.withColumn("DTP_R03_2",
        when(length(len("DTP_R03_1")).lt(len("lenAddm")), expr("rpad(DTP_R03_1, lenAddm, '0')"))
          .when(length(len("DTP_R03_1")).gt(len("lenAddm")), expr("substr(DTP_R03_1, 0, lenAddm)"))
          .otherwise(len("DTP_R03_1")))

      val df3 = df2.withColumn("DTP_R03_DT", to_timestamp(df2("DTP_R03_2"), "yyyyMMdd"))

      df3.withColumn(col, when(df3("DTP_R03_DT").isNull, df3("CLM_DT"))
        .when(df3("DTP_R02") === lit("RD8"), df3("DTP_R03_DT"))
        .otherwise(df3("DTP_R03_DT")))
    }),
    "FACILITYID" -> cascadeFrom(Seq("FACILITYID","CLMRENDPROV_R09")),
    "LOCALCAREAREACODE" -> mapFrom("SVC_R01"),
    "CAREAREASTARTTIME" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("START_TM", when(df("DTP_R02") === lit("RD8"), substring(df("DTP_R03"),1,8)).otherwise(df("DTP_R03")))
      val len = df1.withColumn("lenAddm", datelengthcheck(df1("START_TM"), lit("yyyyMMdd")))
      val df2 = len.withColumn("START_TM_1",
        when(length(len("START_TM")).lt(len("lenAddm")), expr("rpad(START_TM, lenAddm, '0')"))
          .when(length(len("START_TM")).gt(len("lenAddm")), expr("substr(START_TM, 0, lenAddm)"))
          .otherwise(len("START_TM")))

      df2.withColumn(col, to_timestamp(df2("START_TM_1"), "yyyyMMdd"))
    }),
    "CAREAREAENDTIME" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("END_TM", when(df("DTP_R02") === lit("RD8"), substring(df("DTP_R03"),10,8)).otherwise(df("DTP_R03")))
      val len = df1.withColumn("lenAddm", datelengthcheck(df1("END_TM"), lit("yyyyMMdd")))
      val df2 = len.withColumn("END_TM_1",
        when(length(len("END_TM")).lt(len("lenAddm")), expr("rpad(END_TM, lenAddm, '0')"))
          .when(length(len("END_TM")).gt(len("lenAddm")), expr("substr(END_TM, 0, lenAddm)"))
          .otherwise(len("END_TM")))

      df2.withColumn(col, to_timestamp(df2("END_TM_1"), "yyyyMMdd"))
    })
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("ENCOUNTERID"),df("ENCOUNTERTIME"),df("LOCALCAREAREACODE")).orderBy(df("CLM_DT").asc_nulls_last)
    val addcol = df.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1 and PATIENTID is not null and ENCOUNTERID is not null and CLM_DT is not null and LOCALCAREAREACODE is not null")
  }
}

//val es = new EncountercareareaClaim(cfg); val eca = build(es,allColumns=true)
package com.humedica.mercury.etl.e837.clinicalencounter

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class ClinicalencounterCustdrg(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List(
    "enc_drg", "clinicalencounter:e837.clinicalencounter.ClinicalencounterClaim"
  )

  beforeJoin = Map(
    "enc_drg" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("ENCOUNTER_ID")).orderBy(df("SYSTEM_DATE").desc, df("FILEID").desc)
      val addcol = df.withColumn("rank", row_number.over(groups))
      addcol.filter("ENCOUNTER_ID is not null and rank = 1")
    })
    , "clinicalencounter" -> ((df: DataFrame) => {
      df.withColumn("encounterid1", expr("regexp_extract(substr(encounterid, 6), '(^[^-]*)', 1)")).drop("CLIENT_DS_ID")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("clinicalencounter")
      .join(dfs("enc_drg"), dfs("clinicalencounter")("encounterid1") === dfs("enc_drg")("encounter_id"), "left_outer")
  }

  map = Map(
    "LOCALDRG" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("MS_DRG").rlike("^[0-9]{1}$"), concat(lit("00"), df("MS_DRG")))
        .when(df("MS_DRG").rlike("^[0-9]{2}$"), concat(lit("0"), df("MS_DRG")))
        .when(df("MS_DRG").rlike("^[0-9]{3}$"), df("MS_DRG"))
        .otherwise(null))
    }),
    "APRDRG_CD" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("APR_DRG").rlike("^[0-9]{1}$"), concat(lit("00"), df("APR_DRG")))
        .when(df("APR_DRG").rlike("^[0-9]{2}$"), concat(lit("0"), df("APR_DRG")))
        .when(df("APR_DRG").rlike("^[0-9]{3}$"), df("APR_DRG"))
        .otherwise(null))
    }),
    "APRDRG_ROM" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("APR_ROM") === lit("-"), null)
        .otherwise(df("APR_ROM")))
    }),
    "APRDRG_SOI" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("APR_SOI") === lit("-"), null)
        .otherwise(df("APR_SOI")))
    }),
    "LOCALDRGTYPE" -> literal("MS"),
    "ADMITTIME" -> mapFrom("ADMITTIME"),
    "ADMITTINGPHYSICIAN" -> mapFrom("ADMITTINGPHYSICIAN"),
    "ALT_ENCOUNTERID" -> mapFrom("ALT_ENCOUNTERID"),
    "ARRIVALTIME" -> mapFrom("ARRIVALTIME"),
    "ATTENDINGPHYSICIAN" -> mapFrom("ATTENDINGPHYSICIAN"),
    "DATASRC" -> mapFrom("DATASRC"),
    "DISCHARGETIME" -> mapFrom("DISCHARGETIME"),
    "ELOS" -> mapFrom("ELOS"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "FACILITYID" -> mapFrom("FACILITYID"),
    "GRP_MPI" -> mapFrom("GRP_MPI"),
    "HGPID" -> mapFrom("HGPID"),
    "INFERRED_PAT_TYPE" -> mapFrom("INFERRED_PAT_TYPE"),
    "INPATIENTLOCATION" -> mapFrom("INPATIENTLOCATION"),
    "LOCALACCOUNTSTATUS" -> mapFrom("LOCALACCOUNTSTATUS"),
    "LOCALADMITSOURCE" -> mapFrom("LOCALADMITSOURCE"),
    "LOCALDISCHARGEDISPOSITION" -> mapFrom("LOCALDISCHARGEDISPOSITION"),
    "LOCALENCOUNTERTYPE" -> mapFrom("LOCALENCOUNTERTYPE"),
    "LOCALFINANCIALCLASS" -> mapFrom("LOCALFINANCIALCLASS"),
    "LOCALMDC" -> mapFrom("LOCALMDC"),
    "LOCALPATIENTTYPE" -> mapFrom("LOCALPATIENTTYPE"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "PCPID" -> mapFrom("PCPID"),
    "REFERPROVIDERID" -> mapFrom("REFERPROVIDERID"),
    "TOTALCHARGE" -> mapFrom("TOTALCHARGE"),
    "TOTALCOST" -> mapFrom("TOTALCOST"),
    "VISITID" -> mapFrom("VISITID"),
    "WASPLANNEDFLG" -> mapFrom("WASPLANNEDFLG")
  )
}

// val es = new ClinicalencounterCustdrg(cfg);
// val ce = build(es)
package com.humedica.mercury.etl.e837.temptable

import com.humedica.mercury.etl.core.engine.EntitySource
import org.apache.spark.sql.DataFrame
import com.humedica.mercury.etl.core.engine.Functions._

class TemptableSer837dgpt(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "tempservice:e837.temptable.TemptableTempservice"
  )

  columnSelect = Map(
    "tempservice" -> List("CLAIMID","CLAIMLINEID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000C_IDX"
      ,"LOOP_2000A_IDX","LOOP_2000B_IDX","DIAG_PT_1", "DIAG_PT_2", "DIAG_PT_3", "DIAG_PT_4")
  )

  columns = List("CLAIMID","CLAIMLINEID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000C_IDX"
    ,"LOOP_2000A_IDX","LOOP_2000B_IDX","DIAG_POINTER_FIELD","DIAG_POINTER"
  )

  beforeJoin = Map(
    "tempservice" -> ((df: DataFrame) => {
      val df0 = df.drop("DIAG_POINTER")
      val fpiv = unpivot(
        Seq("DIAG_PT_1", "DIAG_PT_2", "DIAG_PT_3", "DIAG_PT_4"),
        Seq("DIAG_PT_1", "DIAG_PT_2", "DIAG_PT_3", "DIAG_PT_4"), typeColumnName = "DIAG_POINTER_FIELD")

      fpiv("DIAG_POINTER",df0)
    })
  )

}

//val es = new TemptableSer837dgpt(cfg); val temp = build(es,allColumns=true)

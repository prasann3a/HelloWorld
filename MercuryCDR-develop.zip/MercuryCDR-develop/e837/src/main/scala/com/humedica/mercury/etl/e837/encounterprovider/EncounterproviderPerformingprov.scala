package com.humedica.mercury.etl.e837.encounterprovider


import com.humedica.mercury.etl.core.engine.EntitySource
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window

class EncounterproviderPerformingprov (config: Map[String,String]) extends EntitySource(config: Map[String,String])  {


  tables = List(
    "temptable:e837.temptable.TemptableTempservice"
  )
  columnSelect = Map(
    "temptable" -> List("ENCOUNTERID","PATIENTID","CLM_TYPE","PERFPROVID","PROC_DT")
  )

  map = Map(
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID")
    ,"DATASRC" -> mapFrom("CLM_TYPE")
    ,"FACILITYID" -> nullValue()
    ,"PATIENTID" -> mapFrom("PATIENTID")
    ,"PROVIDERID"  -> mapFrom("PERFPROVID")
    , "PROVIDERROLE" -> literal("Performing Provider")
    , "ENCOUNTERTIME" -> mapFrom("PROC_DT")
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID"), df("PERFPROVID") , df("PROC_DT") ).orderBy(df("PERFPROVID").asc_nulls_last)
    val addcol = df.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1 and PATIENTID is not null and PROC_DT is not null and PERFPROVID is not null ").drop("rn")

  }

}

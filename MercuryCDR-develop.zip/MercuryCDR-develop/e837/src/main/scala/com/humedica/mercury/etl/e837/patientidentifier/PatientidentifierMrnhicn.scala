package com.humedica.mercury.etl.e837.patientidentifier

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class PatientidentifierMrnhicn(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temptable:e837.temptable.TemptableTemppatient"
  )

  columnSelect = Map(
    "temptable" -> List("PATIENTID", "CLM_TYPE", "FILE_ID", "MRN", "PAT_ALT_ID", "SUBISPAT", "PAT_ALT_ID_QUAL","SUB_ALT_ID")
  )

  map = Map(
    "PATIENTID" -> mapFrom("PATIENTID"),
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "IDTYPE" -> literal("MRN_HICN"),
    "IDVALUE" ->  nullValue(),
    "ID_SUBTYPE" -> nullValue()
  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID")).orderBy(df("FILE_ID").asc_nulls_last)
    val addcol = df.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1 and PATIENTID is not null and ID_SUBTYPE is not null ").drop("rn")
  }

  mapExceptions = Map(
    (Seq("H984474_837_ATH_9582_ALMOB","H984474_837_ATH_9582_FLPEN"),"IDVALUE") -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("PATIENTID").rlike("^([A-Z]{1,3}[0-9]{6}([0-9]{3})?|[0-9]{9}[A-Z][A-Z0-9]?)($|_)"),
        expr("regexp_extract(PATIENTID,'^([A-Z]{1,3}[0-9]{6}([0-9]{3})?|[0-9]{9}[A-Z][A-Z0-9]?)',1)")).otherwise(null))
    })
  )

  afterMapExceptions = Map(
    (Seq("H984474_837_ATH_9582_ALMOB","H984474_837_ATH_9582_FLPEN"), (df: DataFrame) => {
      val groups = Window.partitionBy(df("PATIENTID")).orderBy(df("FILE_ID").asc_nulls_last)
      val addcol = df.withColumn("rn", row_number.over(groups))
      addcol.filter("rn = 1 and PATIENTID is not null and IDVALUE is not null ").drop("rn")
    })
  )
}

// val p=new PatientidentifierMrnhicn(cfg); val p1=build(p)

package com.humedica.mercury.etl.e837.temptable

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Constants.{CLIENT_DS_ID, GROUP}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window

class TemptableTempclaim(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  cacheMe = true

  tables = List("e837_loop_2300_clm"
    ,"e837_loop_2010_ref"
    ,"e837_loop_2010_nm1" // JOINED 3 TIMES: INNER JOIN loop_qualifier = 'AA'; LEFT JOIN - loop_qualifier='AB' AND loop_qualifier='AA'
    //,"npi_filter"
    ,"e837_gs"
    ,"e837_loop_2010_dmg" // JOINED 2 TIMES: loop_qualifier = 'BA' AND loop_qualifier = 'CA'
    ,"e837_loop_2300_ref"
    ,"e837_loop_2400_dtp"
    ,"e837_loop_2300_dtp"
  )

  columnSelect = Map(
    "e837_loop_2300_clm" -> List("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX",
      "LOOP_2000C_IDX","LOOP_2300_IDX","R01","R02","R05_R01","R05_R02","R05_R03"),
    "e837_loop_2010_ref" -> List("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_QUALIFIER","R01","LOOP_2000A_IDX",
      "R02"),
    "e837_loop_2010_nm1" -> List("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_QUALIFIER","R01","LOOP_2000A_IDX",
      "LOOP_2000B_IDX","LOOP_2000C_IDX","R01","R02","R03","R04","R08","R09"),
    //"npi_filter" -> List("NPI"),
    "e837_gs" -> List("FILE_ID","BATCH_ID","INTERCHANGE_IDX","R04","R05","R08"),
    "e837_loop_2010_dmg" -> List("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_QUALIFIER","LOOP_2000A_IDX",
      "LOOP_2000B_IDX","LOOP_2000C_IDX","R02"),
    "e837_loop_2300_ref" -> List("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX",
      "LOOP_2000C_IDX","R01","R02"),
    "e837_loop_2400_dtp" -> List("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX",
      "LOOP_2000C_IDX","LOOP_2300_IDX","R01","R02","R03"),
    "e837_loop_2300_dtp" -> List("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX",
      "LOOP_2000C_IDX","LOOP_2300_IDX","R01","R02","R03")
  )

  columns = List("FILE_ID", "BATCH_ID", "DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000C_IDX","LOOP_2000B_IDX"
    ,"LOOP_2000A_IDX","CLM_DT","SUBMIT_DT","MIN_SVC_DT","MAX_SVC_DT","MIN_ASS_DT","CLM_START_DT"
    ,"CLM_END_DT","ADMIT_DT","DISCHARGE_DT","DISCHARGE_TM","ONSET_DT","MED_REC_NBR","CLM_ID","ENC_ID","LOC_TYPE_CD"
    ,"FACILITY_ID","TOTAL_CHARGE","BILLING_PROV","BILL_PROV_LNAME","BILL_PROV_FNAME","ORDER_PROV","CLM_TYPE","SUBISPAT"
    ,"CLM_VERSION","FACILITYID","FACILITY_NM","MRN"
  )

  beforeJoin = Map(
    "e837_loop_2010_nm1" -> ((df: DataFrame) => {
      val df1 = df.coalesce(1000)
        .filter("LOOP_QUALIFIER in ('BA','CA')")
        .withColumn("LOOP_2000C_IDX", when(df("LOOP_2000C_IDX").isNull, lit("0")).otherwise(df("LOOP_2000C_IDX")))

      val df2 = df1.withColumn("PATSUB", when(df1("LOOP_2000C_IDX") === lit("0"), lit("1")).otherwise(lit("0")))
        .withColumn("SUBCID", when(df1("R01") === "IL" && df1("R08") === "MI", df1("R09")).otherwise(null))
        .withColumn("PATCID", when(df1("R01") === "QC" && df1("R08") === "MI", df1("R09")).otherwise(null))

      val tbl1_dmg1 = table("e837_loop_2010_dmg").filter("LOOP_QUALIFIER = 'BA'")
        .withColumnRenamed("R02","SUBDMG_R02")
      val tbl1 = tbl1_dmg1.select("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","SUBDMG_R02")

      val tbl2_dmg2 = table("e837_loop_2010_dmg").filter("LOOP_QUALIFIER = 'CA'")
        .withColumnRenamed("R02","PATDMG_R02")
      val tbl2 = tbl2_dmg2.withColumn("LOOP_2000C_IDX", when(tbl2_dmg2("LOOP_2000C_IDX").isNull, lit("0")).otherwise(tbl2_dmg2("LOOP_2000C_IDX")))
          .select("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX","PATDMG_R02")

      val tbl3_ref = table("e837_loop_2300_ref").filter("R01 = 'EA'")
      val tbl3_ref1 =  tbl3_ref.withColumn("LOOP_2000C_IDX", when(tbl3_ref("LOOP_2000C_IDX").isNull, lit("0")).otherwise(tbl3_ref("LOOP_2000C_IDX")))
        .withColumn("EAID", when(tbl3_ref("R01") === "EA", tbl3_ref("R02")).otherwise(null))
      val tbl3 = tbl3_ref1.select("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX","EAID")

      val join1 = df2.join(tbl1, Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"),"left_outer")
        .join(tbl2, Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
        .join(tbl3, Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")

      val df3 = join1.groupBy(join1("FILE_ID"),join1("BATCH_ID"),join1("INTERCHANGE_IDX"),join1("DOC_IDX"),join1("LOOP_2000A_IDX"),join1("LOOP_2000B_IDX"))
        .agg(
          max(join1("LOOP_2000C_IDX")).as("LOOP_2000C_IDX"),
          min(join1("PATSUB")).as("PAT_IS_SUB"),
          min(join1("SUBDMG_R02")).as("SUB_DOB"),
          max(join1("SUBCID")).as("SUB_CID"),
          min(join1("PATDMG_R02")).as("PAT_DOB"),
          min(join1("PATCID")).as("PAT_CID"),
          max(join1("EAID")).as("EA_ID")
        )

      df3.select("FILE_ID","BATCH_ID","INTERCHANGE_IDX","DOC_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
        ,"LOOP_2000C_IDX","PAT_IS_SUB","SUB_DOB","SUB_CID","PAT_DOB","PAT_CID","EA_ID")
    }),
    "e837_loop_2300_clm" -> ((df: DataFrame) => {
      val df1 = df.coalesce(1000)
        .withColumn("LOOP_2000C_IDX", when(df("LOOP_2000C_IDX").isNull, lit("0")).otherwise(df("LOOP_2000C_IDX")))
        .withColumnRenamed("R01","CLM_R01")
        .withColumnRenamed("R02","CLM_R02")
        .withColumnRenamed("R05_R01","CLM_R05_R01")
        .withColumnRenamed("R05_R02","CLM_R05_R02")
        .withColumnRenamed("R05_R03","CLM_R05_R03")

      val nm1_ptp = table("e837_loop_2010_nm1").coalesce(1000)
        .filter("LOOP_QUALIFIER = 'AB' and R08 in ('XX','24') and R02 = '1' and R01 = '87'")
        .withColumnRenamed("R09","PTP_R09")
        .drop("LOOP_2000B_IDX","LOOP_2000C_IDX")

      val nm1_bpn = table("e837_loop_2010_nm1").coalesce(1000)
        .filter("LOOP_QUALIFIER = 'AA' and R08 in ('XX','24')")
        .withColumnRenamed("R02","BPN_R02")
        .withColumnRenamed("R03","BPN_R03")
        .withColumnRenamed("R04","BPN_R04")
        .withColumnRenamed("R09","BPN_R09")
        .drop("LOOP_2000B_IDX","LOOP_2000C_IDX")

      val clm_join = df1.join(nm1_ptp,Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX"),"left_outer")
        .join(nm1_bpn,Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX"),"left_outer")

      clm_join.select("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX",
        "LOOP_2000C_IDX","LOOP_2300_IDX","CLM_R01","CLM_R02","CLM_R05_R01","CLM_R05_R02","CLM_R05_R03","PTP_R09","BPN_R02",
        "BPN_R03","BPN_R04","BPN_R09")
    }),
    "e837_gs" -> ((df: DataFrame) => {
      val df1 = df.coalesce(1000)
        .withColumn("LAST_SUBMIT_DT",concat_ws("", df("R04"), lit(" "), df("R05")))
        .withColumnRenamed("R04","GS_R04")
        .withColumnRenamed("R05","GS_R05")
        .withColumnRenamed("R08","GS_R08")


      val len = df1.withColumn("lenAddm", datelengthcheck(df1("LAST_SUBMIT_DT"), lit("yyyyMMdd HHmm")))
      val df2 = len.withColumn("LAST_SUBMIT_DATE_1",
        when(length(len("LAST_SUBMIT_DT")).lt(len("lenAddm")), expr("rpad(LAST_SUBMIT_DT, lenAddm, '0')"))
          .when(length(len("LAST_SUBMIT_DT")).gt(len("lenAddm")), expr("substr(LAST_SUBMIT_DT, 0, lenAddm)"))
          .otherwise(len("LAST_SUBMIT_DT")))

      df2.withColumn("LAST_SUBMIT_DATE", to_timestamp(df2("LAST_SUBMIT_DATE_1"), "yyyyMMdd HHmm"))
    }),
    "e837_loop_2400_dtp" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("R01 in ('472','866')")
        .withColumn("LOOP_2000C_IDX", when(df("LOOP_2000C_IDX").isNull, lit("0")).otherwise(df("LOOP_2000C_IDX")))
        .withColumnRenamed("R01","DTP2400_R01")
        .withColumnRenamed("R02","DTP2400_R02")
        .withColumnRenamed("R03","DTP2400_R03")

    }),
    "e837_loop_2300_dtp" -> ((df: DataFrame) => {
      val df1 = df.coalesce(1000)
        .filter("R01 in ('434','435','096')")
        .withColumn("LOOP_2000C_IDX", when(df("LOOP_2000C_IDX").isNull, lit("0")).otherwise(df("LOOP_2000C_IDX")))
      val df2 = df1.groupBy(df1("FILE_ID"),df1("BATCH_ID"),df1("DOC_IDX"),df1("INTERCHANGE_IDX"),df1("LOOP_2300_IDX")
        ,df1("LOOP_2000C_IDX"),df1("LOOP_2000B_IDX"),df1("LOOP_2000A_IDX"))
        .agg(
          min(df1("R02")).as("DT_TYPE"),
          min(when(df1("R01") === lit("431"), df1("R03")).otherwise(null)).as("ONSET_DT"),
          min(when(df1("R01") === lit("434"), df1("R03")).otherwise(null)).as("STATEMENT_DT"),
          min(when(df1("R01") === lit("435"), df1("R03")).otherwise(null)).as("ADMIT_DT"),
          max(when(df1("R01") === lit("096") && df1("R02") === lit("D8"), df1("R03")).otherwise(null)).as("DISCHARGE_DT"),
          max(when(df1("R01") === lit("096") && df1("R02") === lit("TM"), df1("R03")).otherwise(null)).as("DISCHARGE_TM")
        )

      df2.select("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000C_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000A_IDX","ONSET_DT","STATEMENT_DT","ADMIT_DT","DISCHARGE_DT","DISCHARGE_TM")
    }),
    "e837_loop_2010_ref" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("LOOP_QUALIFIER = 'AA' and R01 = 'EI'")
        .withColumnRenamed("R01","REF2010_R01")
        .withColumnRenamed("R02","REF2010_R02")
    })
  )
  join = (dfs: Map[String, DataFrame]) => {
    dfs("e837_loop_2300_clm")
      .join(dfs("e837_gs"),Seq("FILE_ID","BATCH_ID","INTERCHANGE_IDX"),"inner")
      .join(dfs("e837_loop_2010_nm1"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX",
        "LOOP_2000B_IDX","LOOP_2000C_IDX"),"inner")
      .join(dfs("e837_loop_2400_dtp"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX",
        "LOOP_2000B_IDX","LOOP_2000C_IDX","LOOP_2300_IDX"),"left_outer")
      .join(dfs("e837_loop_2300_dtp"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
  }

  joinExceptions = Map(Seq("H984474_837_ATH_9582_ALMOB","H984474_837_ATH_9582_FLPEN","H984926_837_ATH_V2","H984926_837_ATH_8209_MIDET_V2","H984926_837_ATH_8209_MIROC_V2") -> ((dfs: Map[String, DataFrame]) => {

    val dataSrc = "837"
    val entity = "WHITELIST"

    val columnValue = lookupValue(readTable("cdr.map_predicate_values", config).where("GROUPID='" + config(GROUP) + "' AND CLIENT_DS_ID='" + config(CLIENT_DS_ID) + "' AND DATA_SRC = '" + dataSrc + "' AND ENTITY ='" + entity + "' AND instr(table_name, '.') >0"), "1=1", "COLUMN_VALUE")
    val columnName = lookupValue(readTable("cdr.map_predicate_values", config).where("GROUPID='" + config(GROUP) + "' AND CLIENT_DS_ID='" + config(CLIENT_DS_ID) + "' AND DATA_SRC = '" + dataSrc + "' AND ENTITY ='" + entity + "' AND instr(table_name, '.') >0"), "1=1", "COLUMN_NAME")
    val tblName = lookupValue(readTable("cdr.map_predicate_values", config).where("GROUPID='" + config(GROUP) + "' AND CLIENT_DS_ID='" + config(CLIENT_DS_ID) + "' AND DATA_SRC = '" + dataSrc + "' AND ENTITY ='" + entity + "' AND instr(table_name, '.') >0"), "1=1", "TABLE_NAME")
    val tableName = if (tblName == null) null else tblName.substring(tblName.indexOf(".") + 1)

    if (tableName == null) {

      dfs("e837_loop_2300_clm")
        .join(dfs("e837_gs"),Seq("FILE_ID","BATCH_ID","INTERCHANGE_IDX"),"inner")
        .join(dfs("e837_loop_2010_nm1"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX",
          "LOOP_2000B_IDX","LOOP_2000C_IDX"),"inner")
        .join(dfs("e837_loop_2400_dtp"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX",
          "LOOP_2000B_IDX","LOOP_2000C_IDX","LOOP_2300_IDX"),"left_outer")
        .join(dfs("e837_loop_2300_dtp"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX"
          ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
    }
    else {

      val df = dfs("e837_loop_2300_clm")
        .join(dfs("e837_gs"),Seq("FILE_ID","BATCH_ID","INTERCHANGE_IDX"),"inner")
        .join(dfs("e837_loop_2010_nm1"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX",
          "LOOP_2000B_IDX","LOOP_2000C_IDX"),"inner")
        .join(dfs("e837_loop_2400_dtp"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX",
          "LOOP_2000B_IDX","LOOP_2000C_IDX","LOOP_2300_IDX"),"left_outer")
        .join(dfs("e837_loop_2300_dtp"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX"
          ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
        .join(dfs("e837_loop_2010_ref"),Seq("FILE_ID","BATCH_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX"),"inner")

      val splitDF = readTable(tableName, config)
      val splitDFGrp = splitDF.groupBy("FEDERAL_ID_NUMBER").agg(min(columnName).as("SPLIT_COLUMN"))
      df.join(splitDFGrp, df("REF2010_R02") === splitDFGrp("FEDERAL_ID_NUMBER"), "inner")
        .filter("SPLIT_COLUMN = '" + columnValue + "'")
    }
  })
  )

  afterJoin = (df: DataFrame) => {
    val df1 = df.groupBy(df("FILE_ID"), df("BATCH_ID"), df("DOC_IDX"), df("INTERCHANGE_IDX"), df("LOOP_2000A_IDX"),
      df("LOOP_2000B_IDX"), df("LOOP_2000C_IDX"), df("LOOP_2300_IDX"), df("GS_R08"))
      .agg(
        min(when(df("GS_R08").isin("004010X096A1", "004050X156", "004010X096A1", "005010X223A2", "005010X223A1", "005010X096A1"), lit("I"))
          .when(df("GS_R08").isin("004010X098A1", "005010X222A1", "005010X222", "0050100X222"), lit("P"))
          .otherwise(null)).as("CLAIM_TYPE"),
        min(when(df("DTP2400_R01") === lit("472") && df("DTP2400_R02").isin("DT", "D8", "RD8"), substring(df("DTP2400_R03"), 1, 8))
          .otherwise(null)).as("SVC_START_DT"),
        max(when(df("DTP2400_R01") === lit("472") && df("DTP2400_R02").isin("RD8"), substring(df("DTP2400_R03"), 10, 8))
          .when(df("DTP2400_R01") === lit("472") && df("DTP2400_R02").isin("DT", "D8"), substring(df("DTP2400_R03"), 1, 8))
          .otherwise(null)).as("SVC_END_DT"),
        min(when(df("DTP2400_R01") === lit("866") && df("DTP2400_R02").isin("DT", "D8", "RD8"), substring(df("DTP2400_R03"), 1, 8))
          .otherwise(null)).as("ASS_START_DT"),
        max(when(df("DTP2400_R01") === lit("866") && df("DTP2400_R02").isin("RD8"), substring(df("DTP2400_R03"), 10, 8))
          .when(df("DTP2400_R01") === lit("866") && df("DTP2400_R02").isin("DT", "D8"), substring(df("DTP2400_R03"), 1, 8))
          .otherwise(null)).as("ASS_END_DT"),
        min(df("ADMIT_DT")).as("ADMIT_DT"),
        max(df("DISCHARGE_DT")).as("DISCHARGE_DT"),
        max(df("DISCHARGE_TM")).as("DISCHARGE_TM"),
        min(df("STATEMENT_DT")).as("STATEMENT_DT"),
        min(df("ONSET_DT")).as("ONSET_DT"),
        max(df("LAST_SUBMIT_DATE")).as("LAST_SUBMIT_DATE"),
        min(when(df("PAT_IS_SUB") === lit("1"), concat_ws("", df("SUB_CID"), lit("_"), df("SUB_DOB")))
          .when(df("PAT_IS_SUB") === lit("0"), concat_ws("", coalesce(df("PAT_CID"), df("SUB_CID")), lit("_"), df("PAT_DOB")))
          .otherwise(null)).as("CID"),
        min(df("PAT_IS_SUB")).as("SUBISPAT"),
        min(df("EA_ID")).as("EA_ID"),
        min(df("CLM_R01")).as("CLM_ID"),
        min(df("CLM_R02")).as("TOTAL_CHARGE"),
        min(df("BPN_R09")).as("LOCALBILLINGPROVIDERID"),
        max(df("BPN_R04")).as("LOCALBILLINGPROVFNAME"),
        max(df("BPN_R03")).as("LOCALBILLINGPROVLNAME"),
        min(when(df("BPN_R02") === lit("2"), df("BPN_R09")).otherwise(null)).as("FACILITYID"),
        min(when(df("BPN_R02") === lit("2"), df("BPN_R03")).otherwise(null)).as("FACILITY_NM"),
        min(df("PTP_R09")).as("LOCALORDERPROVIDERID"),
        concat_ws("", min(df("CLM_R05_R02")), min(df("CLM_R05_R01"))).as("LOC_TYPE_CD"),
        min(df("CLM_R05_R03")).as("BILL_TYPE")
      )

    val groups = Window.partitionBy(df1("CLAIM_TYPE"),df1("CLM_ID")).orderBy(df1("LAST_SUBMIT_DATE").desc_nulls_last,df1("LOOP_2000A_IDX").asc)
    val addColumn = df1.withColumn("rn", row_number.over(groups))
    addColumn.filter("rn = 1 and CLAIM_TYPE is not null").drop("rn")
      .withColumnRenamed("GS_R08","CLM_VERSION")
  }

  afterJoinExceptions = Map(
    "H973241_837" -> ((df: DataFrame) => {
      val df1 = df.groupBy(df("FILE_ID"), df("BATCH_ID"), df("DOC_IDX"), df("INTERCHANGE_IDX"), df("LOOP_2000A_IDX"),
        df("LOOP_2000B_IDX"), df("LOOP_2000C_IDX"), df("LOOP_2300_IDX"), df("GS_R08"))
        .agg(
          min(when(df("GS_R08").isin("004010X096A1", "004050X156", "004010X096A1", "005010X223A2", "005010X223A1"), lit("I"))
            .when(df("GS_R08").isin("004010X098A1", "005010X222A1"), lit("P"))
            .otherwise(null)).as("CLAIM_TYPE"),
          min(when(df("DTP2400_R01") === lit("472") && df("DTP2400_R02").isin("DT", "D8", "RD8"), substring(df("DTP2400_R03"), 1, 8))
            .otherwise(null)).as("SVC_START_DT"),
          max(when(df("DTP2400_R01") === lit("472") && df("DTP2400_R02").isin("RD8"), substring(df("DTP2400_R03"), 10, 8))
            .when(df("DTP2400_R01") === lit("472") && df("DTP2400_R02").isin("DT", "D8"), substring(df("DTP2400_R03"), 1, 8))
            .otherwise(null)).as("SVC_END_DT"),
          min(when(df("DTP2400_R01") === lit("866") && df("DTP2400_R02").isin("DT", "D8", "RD8"), substring(df("DTP2400_R03"), 1, 8))
            .otherwise(null)).as("ASS_START_DT"),
          max(when(df("DTP2400_R01") === lit("866") && df("DTP2400_R02").isin("RD8"), substring(df("DTP2400_R03"), 10, 8))
            .when(df("DTP2400_R01") === lit("866") && df("DTP2400_R02").isin("DT", "D8"), substring(df("DTP2400_R03"), 1, 8))
            .otherwise(null)).as("ASS_END_DT"),
          min(df("ADMIT_DT")).as("ADMIT_DT"),
          max(df("DISCHARGE_DT")).as("DISCHARGE_DT"),
          max(df("DISCHARGE_TM")).as("DISCHARGE_TM"),
          min(df("STATEMENT_DT")).as("STATEMENT_DT"),
          min(df("ONSET_DT")).as("ONSET_DT"),
          max(df("LAST_SUBMIT_DATE")).as("LAST_SUBMIT_DATE"),
          min(when(df("PAT_IS_SUB") === lit("1"), concat_ws("", df("SUB_CID"), lit("_"), df("SUB_DOB")))
            .when(df("PAT_IS_SUB") === lit("0"), concat_ws("", coalesce(df("PAT_CID"), df("SUB_CID")), lit("_"), df("PAT_DOB")))
            .otherwise(null)).as("CID"),
          min(df("PAT_IS_SUB")).as("SUBISPAT"),
          min(df("EA_ID")).as("EA_ID"),
          min(df("CLM_R01")).as("CLM_ID"),
          min(df("CLM_R02")).as("TOTAL_CHARGE"),
          min(df("BPN_R09")).as("LOCALBILLINGPROVIDERID"),
          max(df("BPN_R04")).as("LOCALBILLINGPROVFNAME"),
          max(df("BPN_R03")).as("LOCALBILLINGPROVLNAME"),
          min(when(df("BPN_R02") === lit("2"), df("BPN_R09")).otherwise(null)).as("FACILITYID"),
          min(when(df("BPN_R02") === lit("2"), df("BPN_R03")).otherwise(null)).as("FACILITY_NM"),
          min(df("PTP_R09")).as("LOCALORDERPROVIDERID"),
          concat_ws("", min(df("CLM_R05_R02")), min(df("CLM_R05_R01"))).as("LOC_TYPE_CD"),
          min(df("CLM_R05_R03")).as("BILL_TYPE")
        )


     /* val df2 = safe_to_date(df1, "LAST_SUBMIT_DATE", "LAST_SUBMIT_DATE", "yyyyMMdd HHmm", 13)
      val df3 = safe_to_date(df2, "SVC_START_DT", "MIN_SVC_DATE","yyyyMMdd",8)
      val df4 = safe_to_date(df3, "STATEMENT_DT", "STATEMENT_DATE","yyyyMMdd",8)
      val df5 = safe_to_date(df4, "ASS_START_DT", "ASS_START_DATE","yyyyMMdd",8)
*/
     val groups = Window.partitionBy(df1("CLAIM_TYPE"),df1("LOC_TYPE_CD"),df1("CLM_ID")
        ,to_date(coalesce(df1("SVC_START_DT"),coalesce(df1("STATEMENT_DT"),df1("SVC_START_DT")),df1("ASS_START_DT")),"yyyyMMdd"))
        .orderBy(df1("LAST_SUBMIT_DATE"),df1("TOTAL_CHARGE").desc_nulls_last)
      val addColumn = df1.withColumn("rn", row_number.over(groups))
      addColumn.filter("rn = 1 and CLAIM_TYPE is not null and BILL_TYPE != '8'").drop("rn")
        .withColumnRenamed("GS_R08", "CLM_VERSION")
    })
  )


  map = Map(
    "MED_REC_NBR" -> cascadeFrom(Seq("EA_ID","CID")),
    "MIN_SVC_DT" -> ((col: String, df: DataFrame) => {
      val len = df.withColumn("lenAddm", datelengthcheck(df("SVC_START_DT"), lit("yyyyMMdd")))
      val df1 = len.withColumn("SVC_START_DT_1",
        when(length(len("SVC_START_DT")).lt(len("lenAddm")), expr("rpad(SVC_START_DT, lenAddm, '0')"))
          .when(length(len("SVC_START_DT")).gt(len("lenAddm")), expr("substr(SVC_START_DT, 0, lenAddm)"))
          .otherwise(len("SVC_START_DT")))

      df1.withColumn(col, to_timestamp(df1("SVC_START_DT_1"), "yyyyMMdd"))
    }),
    "MAX_SVC_DT" -> ((col: String, df: DataFrame) => {
      val len = df.withColumn("lenAddm", datelengthcheck(df("SVC_END_DT"), lit("yyyyMMdd")))
      val df1 = len.withColumn("SVC_END_DT_1",
        when(length(len("SVC_END_DT")).lt(len("lenAddm")), expr("rpad(SVC_END_DT, lenAddm, '0')"))
          .when(length(len("SVC_END_DT")).gt(len("lenAddm")), expr("substr(SVC_END_DT, 0, lenAddm)"))
          .otherwise(len("SVC_END_DT")))

      df1.withColumn(col, to_timestamp(df1("SVC_END_DT_1"), "yyyyMMdd"))
    }),
    "MIN_ASS_DT" -> ((col: String, df: DataFrame) => {
      val len = df.withColumn("lenAddm", datelengthcheck(df("ASS_START_DT"), lit("yyyyMMdd")))
      val df1 = len.withColumn("ASS_START_DT_1",
        when(length(len("ASS_START_DT")).lt(len("lenAddm")), expr("rpad(ASS_START_DT, lenAddm, '0')"))
          .when(length(len("ASS_START_DT")).gt(len("lenAddm")), expr("substr(ASS_START_DT, 0, lenAddm)"))
          .otherwise(len("ASS_START_DT")))

      df1.withColumn(col, to_timestamp(df1("ASS_START_DT_1"), "yyyyMMdd"))
    }),
    "MAX_ASS_DT" -> ((col: String, df: DataFrame) => {
      val len = df.withColumn("lenAddm", datelengthcheck(df("ASS_END_DT"), lit("yyyyMMdd")))
      val df1 = len.withColumn("ASS_END_DT_1",
        when(length(len("ASS_END_DT")).lt(len("lenAddm")), expr("rpad(ASS_END_DT, lenAddm, '0')"))
          .when(length(len("ASS_END_DT")).gt(len("lenAddm")), expr("substr(ASS_END_DT, 0, lenAddm)"))
          .otherwise(len("ASS_END_DT")))

      df1.withColumn(col, to_timestamp(df1("ASS_END_DT_1"), "yyyyMMdd"))
    }),
    "CLM_START_DT" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("STATEMENT_DT1",when(length(substring(df("STATEMENT_DT"),1,8)) === "0", null).otherwise(substring(df("STATEMENT_DT"),1,8)))
      val df2 = df1.withColumn("CLM_START_DATE", coalesce(df1("STATEMENT_DT1"),df1("SVC_START_DT")))
      val len = df2.withColumn("lenAddm", datelengthcheck(df2("CLM_START_DATE"), lit("yyyyMMdd")))
      val df3 = len.withColumn("CLM_START_DATE_1",
        when(length(len("CLM_START_DATE")).lt(len("lenAddm")), expr("rpad(CLM_START_DATE, lenAddm, '0')"))
          .when(length(len("CLM_START_DATE")).gt(len("lenAddm")), expr("substr(CLM_START_DATE, 0, lenAddm)"))
          .otherwise(len("CLM_START_DATE")))

      df3.withColumn(col, to_timestamp(df3("CLM_START_DATE_1"), "yyyyMMdd"))
    }),
    "CLM_END_DT" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("STATEMENT_DT1",when( length(substring(df("STATEMENT_DT"),10,8)) === "0", null).otherwise(substring(df("STATEMENT_DT"),10,8)))
      df1.withColumn(col, coalesce(df1("STATEMENT_DT1"),df1("SVC_END_DT")))
    }),
    "ADMIT_DT" -> ((col: String, df: DataFrame) => {
      val len = df.withColumn("lenAddm", datelengthcheck(df("ADMIT_DT"), lit("yyyyMMddHHmm")))
      val df1 = len.withColumn("ADMIT_DT_1",
        when(length(len("ADMIT_DT")).lt(len("lenAddm")), expr("rpad(ADMIT_DT, lenAddm, '0')"))
          .when(length(len("ADMIT_DT")).gt(len("lenAddm")), expr("substr(ADMIT_DT, 0, lenAddm)"))
          .otherwise(len("ADMIT_DT")))

      df1.withColumn(col, to_timestamp(df1("ADMIT_DT_1"), "yyyyMMddHHmm"))
    }),
    "DISCHARGE_DT" -> mapFrom("DISCHARGE_DT"),
    "DISCHARGE_TM" -> mapFrom("DISCHARGE_TM"),
    "ONSET_DT" -> ((col: String, df: DataFrame) => {
      val len = df.withColumn("lenAddm", datelengthcheck(df("ONSET_DT"), lit("yyyyMMddHHmm")))
      val df1 = len.withColumn("ONSET_DT_1",
        when(length(len("ONSET_DT")).lt(len("lenAddm")), expr("rpad(ONSET_DT, lenAddm, '0')"))
          .when(length(len("ONSET_DT")).gt(len("lenAddm")), expr("substr(ONSET_DT, 0, lenAddm)"))
          .otherwise(len("ONSET_DT")))

      df1.withColumn(col, to_timestamp(df1("ONSET_DT_1"), "yyyyMMddHHmm"))
    }),
    "CLM_ID" -> mapFrom("CLM_ID"),
    "ENC_ID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat_ws("",lit("e837"),df("CLAIM_TYPE"),df("CLM_ID")))
    }),
    "FACILITYID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("CLAIM_TYPE") === lit("I"), df("FACILITYID")).otherwise(null))
    }),
    "FACILITY_NM" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("CLAIM_TYPE") === lit("I"), df("FACILITY_NM")).otherwise(null))
    }),
    "CLM_TYPE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat_ws("",lit("837"),df("CLAIM_TYPE"),
        when(substring(df("CLM_VERSION"),1,3) === lit("004"), lit("_40"))
       .when(substring(df("CLM_VERSION"),1,3) === lit("005"), lit("_50"))
       .otherwise(null)))
    }),
    "MRN" -> nullValue(),
    "SUBMIT_DT" -> mapFrom("LAST_SUBMIT_DATE"),
    "BILLING_PROV" -> mapFrom("LOCALBILLINGPROVIDERID"),
    "BILL_PROV_LNAME" -> mapFrom("LOCALBILLINGPROVLNAME"),
    "BILL_PROV_FNAME" -> mapFrom("LOCALBILLINGPROVFNAME"),
    "ORDER_PROV" -> mapFrom("LOCALORDERPROVIDERID")
  )

  afterMap = (df: DataFrame) => {
    df.withColumn("CLM_DT", coalesce(df("MIN_SVC_DT"),df("CLM_START_DT"),df("MIN_ASS_DT")))
      .filter("regexp_replace(MED_REC_NBR,'0','') is not null and BILL_TYPE != '8' and MED_REC_NBR <> '999999' and MED_REC_NBR <> '0000000' and MED_REC_NBR <> '_'")
  }

  afterMapExceptions = Map(
  (Seq("H973241_837"), (df: DataFrame) => {
      df.withColumn("CLM_DT", coalesce(df("MIN_SVC_DT"),df("CLM_START_DT"),df("MIN_ASS_DT")))
        .filter("replace(MED_REC_NBR,'0') is not null and BILL_TYPE != '8' and MED_REC_NBR <> '999999'")
    }),
    (Seq("H984442_837"), (df: DataFrame) => {
      df.withColumn("CLM_DT", coalesce(df("MIN_SVC_DT"),df("CLM_START_DT"),df("MIN_ASS_DT")))
        .filter("regexp_replace(MED_REC_NBR,'0','') <> '' and BILL_TYPE != '8' and MED_REC_NBR <> '999999' and MED_REC_NBR <> '0000000' and MED_REC_NBR <> '_'")
    })
  )

  mapExceptions = Map(
    (Seq("H542284_837","H542284_ATH_837"), "MRN") -> mapFrom("EA_ID"),
    (Seq("H984926_837_MIDET_V1"
      ,"H984926_837"
      ,"H984926_837_ATH_8209_MIDET_V2"
      ,"H984926_837_MIKAL"
      ,"H984926_837_ATH_MIKAL"
      ,"H984926_837_ATH_V2"
      ,"H984926_837_MISAG"
      ,"H984926_837_ATH_MISAG"
      ,"H984926_837_ATH_8209_MIROC_V2"
      ,"H984275_837"
      ,"H984275_837_R1"
      ,"H641171_837_PM"
      ,"H984787_837_INVISION"
      ,"H984186_837_V1"
      ,"H984197_837"
      ), "MED_REC_NBR") -> ((col: String, df: DataFrame) => {
        df.withColumn(col, concat_ws("", coalesce(df("EA_ID"),df("CID")), lit("-"), df("FACILITYID")))
    }),
    ("H973241_837","ENC_ID") -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat_ws("",lit("e837"), df("CLM_ID")))
    }),
    ("H973241_837","CLM_ID") -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("CLM_DATE", regexp_replace(to_date(coalesce(df("MIN_SVC_DT"),df("CLM_START_DT"),df("MIN_ASS_DT")),"yyyyMMdd"),"-",""))
      df1.withColumn(col, concat_ws("", df1("CLAIM_TYPE"),df1("CLM_ID"),df1("CLM_DATE"),df1("LOC_TYPE_CD")))
    })
  )

}

//val es = new TemptableTempclaim(cfg); val temp = build(es,allColumns=true)

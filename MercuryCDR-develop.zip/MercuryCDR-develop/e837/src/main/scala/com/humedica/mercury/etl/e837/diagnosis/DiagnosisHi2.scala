package com.humedica.mercury.etl.e837.diagnosis

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import org.apache.spark.sql.DataFrame
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class DiagnosisHi2(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temphi:e837.temptable.TemptableTemphisegment"
  )

  columnSelect = Map(
    "temphi" -> List("CLM_TYPE","PATIENTID","ENCOUNTERID","LOCALCODE","ONSET_DT","PRIMARYDIAGNOSIS","LOCALADMITFLG"
      ,"POA_IND_F","CD_TIMESTAMP","SOURCEID","DX_CODETYPE","HOSP_DX_FLAG","CD_QUAL_FINAL")
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "DX_TIMESTAMP" -> mapFrom("ONSET_DT"),
    "LOCALDIAGNOSIS" -> mapFrom("LOCALCODE"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "PRIMARYDIAGNOSIS" ->  mapFrom("PRIMARYDIAGNOSIS"),
    "LOCALADMITFLG" -> mapFrom("LOCALADMITFLG"),
    "MAPPEDDIAGNOSIS" -> mapFrom("LOCALCODE"), // TODO:  //formaticd9(localcode)
    "CODETYPE" -> mapFrom("DX_CODETYPE"),
    "LOCALPRESENTONADMISSION" -> mapFrom("POA_IND_F"),
    "HOSP_DX_FLAG" -> mapFrom("HOSP_DX_FLAG"),
    "SOURCEID" -> mapFrom("SOURCEID")
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("CD_QUAL_FINAL = 'Dx' and ONSET_DT < CD_TIMESTAMP")
    val cols = Engine.schema.getStringList("Diagnosis").asScala.map(_.split("-")(0).toUpperCase())
    fil.select(cols.map(col): _*)
      .distinct
  }

}

// val es = new DiagnosisHi2(cfg); val diag2 = build(es,allColumns=true)
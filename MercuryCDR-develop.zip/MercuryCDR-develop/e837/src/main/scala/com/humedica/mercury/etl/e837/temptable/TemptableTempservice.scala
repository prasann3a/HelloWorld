package com.humedica.mercury.etl.e837.temptable

import com.humedica.mercury.etl.core.engine.EntitySource
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Functions._

class TemptableTempservice(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  cacheMe = true

  tables = List(
    "temptable:e837.temptable.TemptableTempclaim"
    ,"e837_loop_2400_sv1"
    ,"e837_loop_2400_sv2"
    ,"e837_loop_2400_lx"
    ,"e837_loop_2310_nm1"
    ,"e837_loop_2400_dtp"
    ,"e837_loop_2420_nm1"
    ,"e837_loop_2330_nm1"
    ,"e837_loop_2430_svd" // EXCEPTION FOR H827
    ,"cdr.ref_billtype_pos_xref" // EXCEPTION FOR H827
  )

  columnSelect = Map(
    "temptable" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","MED_REC_NBR","CLM_TYPE","CLM_ID","ENC_ID","CLM_DT","SUBMIT_DT","BILLING_PROV"
      ,"BILL_PROV_LNAME","BILL_PROV_FNAME","ORDER_PROV","LOC_TYPE_CD"),
    "e837_loop_2400_sv1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_2400_IDX","R01_R01","R01_R02","R02","R04","R01_R03","R01_R04","R01_R05","R01_R06"
      ,"R07_R01","R07_R02","R07_R03","R07_R04"),
    "e837_loop_2400_sv2" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_2400_IDX","R01","R02_R01","R02_R02","R03","R05","R02_R03","R02_R04","R02_R05","R02_R06"
    ),
    "e837_loop_2400_lx" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_2400_IDX","r01"),
    "e837_loop_2310_nm1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_QUALIFIER","R01","R02","R03","R04","R08","R09"),
    "e837_loop_2400_dtp" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_2400_IDX","R01","R02","R03"),
    "e837_loop_2420_nm1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_2400_IDX","LOOP_QUALIFIER","R01","R02","R03","R04","R08","R09"),
    "e837_loop_2330_nm1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_QUALIFIER","R01","R03","R04","R09"),
    "e837_loop_2430_svd" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_2400_IDX","R02","R03_R02")
  )

  columns = List("PATIENTID","CLM_TYPE","CLAIMID","CLAIMLINEID","ENCOUNTERID","PERFPROVID","PERFPROV_LAST","PERFPROV_FIRST"
    ,"REFPROVID","REFPROV_LAST","REFPROV_FIRST","ORDERINGPROVID","ORDERINGPROV_LAST","ORDERINGPROV_FIRST","RENDERINGPROVID"
    ,"RENDERINGPROV_LAST","RENDERINGPROV_FIRST","PROC_DT","SUBMIT_DT","PROC_CD","PROC_TYP","CHARGE_AMT","QTY","CPTMOD1"
    ,"CPTMOD2","CPTMOD3","CPTMOD4","FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
    ,"LOOP_2000C_IDX","DIAG_PT_1","DIAG_PT_2","DIAG_PT_3","DIAG_PT_4","POS","PAID","REV_CODE"
  )

  beforeJoin = Map(
    "temptable" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("MED_REC_NBR is not null")
    }),
    "e837_loop_2400_sv1" -> ((df: DataFrame) => {
      val svc1 = df.coalesce(1000)
          .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
          .withColumnRenamed("R01_R01","CODETYPE")
          .withColumnRenamed("R01_R02","CODEVALUE")
          .withColumnRenamed("R02", "CHARGE_AMT")
          .withColumnRenamed("R04", "QTY")
          .withColumnRenamed("R01_R03", "CPTMOD1")
          .withColumnRenamed("R01_R04", "CPTMOD2")
          .withColumnRenamed("R01_R05", "CPTMOD3")
          .withColumnRenamed("R01_R06", "CPTMOD4")
          .withColumnRenamed("R07_R01", "DIAG_PT_1")
          .withColumnRenamed("R07_R02", "DIAG_PT_2")
          .withColumnRenamed("R07_R03", "DIAG_PT_3")
          .withColumnRenamed("R07_R04", "DIAG_PT_4")
          .select("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
            ,"LOOP_2000C_IDX","LOOP_2400_IDX","CODETYPE","CODEVALUE","CHARGE_AMT","QTY","CPTMOD1","CPTMOD2","CPTMOD3"
            ,"CPTMOD4","DIAG_PT_1","DIAG_PT_2","DIAG_PT_3","DIAG_PT_4")

      val svc2 = table("e837_loop_2400_sv2").coalesce(1000)
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R02_R01", "CODETYPE")
        .withColumnRenamed("R02_R02", "CODEVALUE")
        .withColumnRenamed("R03", "CHARGE_AMT")
        .withColumnRenamed("R05", "QTY")
        .withColumnRenamed("R02_R03", "CPTMOD1")
        .withColumnRenamed("R02_R04", "CPTMOD2")
        .withColumnRenamed("R02_R05",  "CPTMOD3")
        .withColumnRenamed("R02_R06","CPTMOD4")
        .withColumn("DIAG_PT_1", lit(null))
        .withColumn("DIAG_PT_2", lit(null))
        .withColumn("DIAG_PT_3", lit(null))
        .withColumn("DIAG_PT_4", lit(null))
        .select("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
          ,"LOOP_2000C_IDX","LOOP_2400_IDX","CODETYPE","CODEVALUE","CHARGE_AMT","QTY","CPTMOD1","CPTMOD2","CPTMOD3"
          ,"CPTMOD4","DIAG_PT_1","DIAG_PT_2","DIAG_PT_3","DIAG_PT_4")

      svc1.union(svc2)
        .select("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
          ,"LOOP_2000C_IDX","LOOP_2400_IDX","CODETYPE","CODEVALUE","CHARGE_AMT","QTY","CPTMOD1","CPTMOD2","CPTMOD3"
          ,"CPTMOD4","DIAG_PT_1","DIAG_PT_2","DIAG_PT_3","DIAG_PT_4")
        .filter("CODETYPE = 'HC'")
    }),
    "e837_loop_2400_lx" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R01","LX_R01")
    }),
    "e837_loop_2400_dtp" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("R01 = '472'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R01","DTP_R01")
        .withColumnRenamed("R02","DTP_R02")
        .withColumnRenamed("R03","DTP_R03")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val clmperfprov = table("e837_loop_2310_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'B' and R02 = '1' and R08 = 'XX'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","clmperfprov_R03")
      .withColumnRenamed("R04","clmperfprov_R04")
      .withColumnRenamed("R09","clmperfprov_R09")

    val clmrendprov = table("e837_loop_2310_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'D' and R01 = '82'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","clmrendprov_R03")
      .withColumnRenamed("R04","clmrendprov_R04")
      .withColumnRenamed("R09","clmrendprov_R09")

    val clmreffprov1 = table("e837_loop_2310_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'F' and R01 = 'DN'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","clmreffprov1_R03")
      .withColumnRenamed("R04","clmreffprov1_R04")
      .withColumnRenamed("R09","clmreffprov1_R09")

    val clmrefprov = table("e837_loop_2310_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'A' and R01 = 'DN' and R08 in ('XX','24')")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","clmrefprov_R03")
      .withColumnRenamed("R04","clmrefprov_R04")
      .withColumnRenamed("R09","clmrefprov_R09")

    val svcperfprov = table("e837_loop_2420_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'A' and R08 = 'XX' and R02 = '1' and R01 = '82'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","svcperfprov_R03")
      .withColumnRenamed("R04","svcperfprov_R04")
      .withColumnRenamed("R09","svcperfprov_R09")

    val svcperfprovi = table("e837_loop_2420_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'B' and R08 = 'XX' and R02 = '1' and R01 = '72'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","svcperfprovi_R03")
      .withColumnRenamed("R04","svcperfprovi_R04")
      .withColumnRenamed("R09","svcperfprovi_R09")

    val svcrendprovi = table("e837_loop_2420_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'C' and R01 = '82'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","svcrendprovi_R03")
      .withColumnRenamed("R04","svcrendprovi_R04")
      .withColumnRenamed("R09","svcrendprovi_R09")

    val svcreffprovi1 = table("e837_loop_2420_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'D' and R01 = 'DN'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","svcreffprovi1_R03")
      .withColumnRenamed("R04","svcreffprovi1_R04")
      .withColumnRenamed("R09","svcreffprovi1_R09")

    val svcrefprov = table("e837_loop_2420_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'F' and R01 = 'DN' and R08 in ('XX','24')")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","svcrefprov_R03")
      .withColumnRenamed("R04","svcrefprov_R04")
      .withColumnRenamed("R09","svcrefprov_R09")

    val svcordprov = table("e837_loop_2420_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'E' and R08 in ('XX','24') and R02 = '1' and R01 = 'DK'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","svcordprov_R03")
      .withColumnRenamed("R04","svcordprov_R04")
      .withColumnRenamed("R09","svcordprov_R09")

    val subnmrend = table("e837_loop_2330_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'G' and R01 = '82'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","subnmrend_R03")
      .withColumnRenamed("R04","subnmrend_R04")
      .withColumnRenamed("R09","subnmrend_R09")

    val subnmreff1 = table("e837_loop_2330_nm1").coalesce(1000)
      .filter("LOOP_QUALIFIER = 'H' and R01 = 'DN'")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
      .withColumnRenamed("R03","subnmreff1_R03")
      .withColumnRenamed("R04","subnmreff1_R04")
      .withColumnRenamed("R09","subnmreff1_R09")

    dfs("temptable")
      .join(dfs("e837_loop_2400_sv1"),Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
        ,"LOOP_2000C_IDX"),"inner")
      .join(dfs("e837_loop_2400_lx"),Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX","LOOP_2000A_IDX"
        ,"LOOP_2000B_IDX","LOOP_2000C_IDX"),"inner")
      .join(clmperfprov, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
        ,"LOOP_2000C_IDX"),"left_outer")
      .join(clmrendprov, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
        ,"LOOP_2000C_IDX"),"left_outer")
      .join(clmreffprov1, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
        ,"LOOP_2000C_IDX"),"left_outer")
      .join(clmrefprov, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
        ,"LOOP_2000C_IDX"),"left_outer")
      .join(dfs("e837_loop_2400_dtp"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(svcperfprov, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(svcperfprovi, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(svcrendprovi, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(svcreffprovi1, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(svcrefprov, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(svcordprov, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(subnmrend, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX"), "left_outer")
      .join(subnmreff1, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX"), "left_outer")
  }

  map = Map(
    "PATIENTID" -> mapFrom("MED_REC_NBR"),
    "CLM_TYPE" -> mapFrom("CLM_TYPE"),
    "CLAIMID" -> mapFrom("CLM_ID"),
    "CLAIMLINEID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat_ws("",df("CLM_ID"),lit("_"),df("LX_R01")))
    }),
    "ENCOUNTERID" -> mapFrom("ENC_ID"),
    "PERFPROVID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(substring(df("CLM_TYPE"),1,4) === "837I", coalesce(df("svcperfprovi_R09"),df("clmperfprov_R09")))
        .when(substring(df("CLM_TYPE"),1,4) === "837P", coalesce(df("svcperfprov_R09"),df("clmperfprov_R09"),df("BILLING_PROV")))
        .otherwise(df("clmperfprov_R09")))
    }),
    "PERFPROV_LAST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(substring(df("CLM_TYPE"),1,4) === "837I", coalesce(df("svcperfprovi_R03"),df("clmperfprov_R03")))
        .when(substring(df("CLM_TYPE"),1,4) === "837P", coalesce(df("svcperfprov_R03"),df("clmperfprov_R03"),df("BILL_PROV_LNAME")))
        .otherwise(df("clmperfprov_R03")))
    }),
    "PERFPROV_FIRST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(substring(df("CLM_TYPE"),1,4) === "837I", coalesce(df("svcperfprovi_R04"),df("clmperfprov_R04")))
        .when(substring(df("CLM_TYPE"),1,4) === "837P", coalesce(df("svcperfprov_R04"),df("clmperfprov_R04"),df("BILL_PROV_FNAME")))
        .otherwise(df("clmperfprov_R04")))
    }),
    "REFPROVID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("svcrefprov_R09"),df("clmrefprov_R09"),df("clmreffprov1_R09"),df("subnmreff1_R09"),df("svcreffprovi1_R09")))
    }),
    "REFPROV_LAST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("svcrefprov_R03"),df("clmrefprov_R03"),df("clmreffprov1_R03"),df("subnmreff1_R03"),df("svcreffprovi1_R03")))
    }),
    "REFPROV_FIRST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("svcrefprov_R04"),df("clmrefprov_R04"),df("clmreffprov1_R04"),df("subnmreff1_R04"),df("svcreffprovi1_R04")))
    }),
    "ORDERINGPROVID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("svcordprov_R09"),df("svcperfprov_R09"),df("clmperfprov_R09"),df("ORDER_PROV"),df("BILLING_PROV")))
    }),
    "ORDERINGPROV_LAST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("svcordprov_R03"),df("svcperfprov_R03"),df("clmperfprov_R03"),df("BILL_PROV_LNAME")))
    }),
    "ORDERINGPROV_FIRST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("svcordprov_R04"),df("svcperfprov_R04"),df("clmperfprov_R04"),df("BILL_PROV_FNAME")))
    }),
    "RENDERINGPROVID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("clmrendprov_R09"),df("svcrendprovi_R09"),df("subnmrend_R09")))
    }),
    "RENDERINGPROV_LAST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("clmrendprov_R03"),df("svcrendprovi_R03"),df("subnmrend_R03")))
    }),
    "RENDERINGPROV_FIRST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("clmrendprov_R04"),df("svcrendprovi_R04"),df("subnmrend_R04")))
    }),
    "PROC_DT" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("DTP_R03", when(df("DTP_R02") === "RD8", substring(df("DTP_R03"),1,8))
        .otherwise(df("DTP_R03")))

      val len = df1.withColumn("lenAddm", datelengthcheck(df1("DTP_R03"), lit("yyyyMMdd")))
      val df2 = len.withColumn("DTP_R03_1",
        when(length(len("DTP_R03")).lt(len("lenAddm")), expr("rpad(DTP_R03, lenAddm, '0')"))
          .when(length(len("DTP_R03")).gt(len("lenAddm")), expr("substr(DTP_R03, 0, lenAddm)"))
          .otherwise(len("DTP_R03")))

      val df3 = df2.withColumn("DTP_R03_DT", to_timestamp(df2("DTP_R03_1"), "yyyyMMdd"))

      df3.withColumn(col, coalesce(df3("DTP_R03_DT"),df3("CLM_DT")))
    }),
    "SUBMIT_DT" -> mapFrom("SUBMIT_DT"),
    "PROC_CD" -> mapFrom("CODEVALUE"),
    "PROC_TYP" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("CODEVALUE").rlike("^[0-9]{4}[0-9A-Z]$"), "CPT4")
          .when(df("CODEVALUE").rlike("^[A-Z][0-9]{4}$"), "HCPCS")
          .when(df("CODEVALUE").rlike("^[0-9]{2,2}\\.?[0-9]{1,2}$"), "ICD9")
          .otherwise(null))
    }),
    "CHARGE_AMT" -> mapFrom("CHARGE_AMT"),
    "QTY" -> mapFrom("QTY"),
    "CPTMOD1" -> mapFrom("CPTMOD1"),
    "CPTMOD2" -> mapFrom("CPTMOD2"),
    "CPTMOD3" -> mapFrom("CPTMOD3"),
    "CPTMOD4" -> mapFrom("CPTMOD4"),
    "FILE_ID" -> mapFrom("FILE_ID"),
    "DOC_IDX" -> mapFrom("DOC_IDX"),
    "INTERCHANGE_IDX" -> mapFrom("INTERCHANGE_IDX"),
    "LOOP_2300_IDX" -> mapFrom("LOOP_2300_IDX"),
    "LOOP_2000A_IDX" -> mapFrom("LOOP_2000A_IDX"),
    "LOOP_2000B_IDX" -> mapFrom("LOOP_2000B_IDX"),
    "LOOP_2000C_IDX" -> mapFrom("LOOP_2000C_IDX"),
    "DIAG_PT_1" -> mapFrom("DIAG_PT_1"),
    "DIAG_PT_2" -> mapFrom("DIAG_PT_2"),
    "DIAG_PT_3" -> mapFrom("DIAG_PT_3"),
    "DIAG_PT_4" -> mapFrom("DIAG_PT_4"),
    "POS" -> nullValue(),
    "REV_CODE" -> nullValue(),
    "PAID" -> nullValue()
  )

}

//val es = new TemptableTempservice(cfg); val temp = build(es,allColumns=true)
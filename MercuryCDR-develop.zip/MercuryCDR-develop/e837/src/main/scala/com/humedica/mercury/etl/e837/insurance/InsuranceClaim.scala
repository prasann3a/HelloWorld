package com.humedica.mercury.etl.e837.insurance

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window
import scala.collection.JavaConverters._

class InsuranceClaim(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temptable:e837.temptable.TemptableTempclaim"
    , "e837_loop_2000_sbr"
    , "e837_loop_1000_nm1"
    , "e837_loop_2010_nm1"
    , "e837_gs"
    , "e837_loop_2320_sbr"
    , "e837_loop_2330_nm1"
  )

  columnSelect = Map(
    "temptable" -> List("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX", "LOOP_2000C_IDX"
      , "LOOP_2300_IDX", "CLM_TYPE", "SUBMIT_DT", "CLM_ID", "ENC_ID", "MED_REC_NBR", "CLM_DT"),
    "e837_loop_2000_sbr" -> List("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX"
      , "LOOP_QUALIFIER", "R01", "R09"),
    "e837_loop_1000_nm1" -> List("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_QUALIFIER", "R08"),
    "e837_loop_2010_nm1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_QUALIFIER"
      ,"R03","R08","R09"),
    "e837_gs" -> List("FILE_ID","INTERCHANGE_IDX","R08"),
    "e837_loop_2320_sbr" -> List("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX", "LOOP_2000C_IDX"
      , "LOOP_2300_IDX", "R01", "R09"),
    "e837_loop_2330_nm1" -> List("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX", "LOOP_2000C_IDX"
      , "LOOP_2300_IDX", "LOOP_QUALIFIER", "R03", "R08", "R09")
  )

  beforeJoin = Map(
    "e837_gs" -> ((df: DataFrame) => {
      val clm_tbl1 = table("temptable").coalesce(1000)
        .filter("MED_REC_NBR is not null")
        .withColumn("PLN_CLM_TYPE", expr("substr(CLM_TYPE,1,4)"))

      val nm1_2010_tbl1 = table("e837_loop_2010_nm1").filter("LOOP_QUALIFIER = 'BB'")
      val gs_tbl1 = df //table("e837_gs")
        .withColumnRenamed("R08", "GS_R08").drop("R03")
      val join1 = nm1_2010_tbl1.join(gs_tbl1, Seq("FILE_ID", "INTERCHANGE_IDX"), "inner")
      val pln_tbl1 = join1.filter("GS_R08 in ('004010X098A1','005010X222A1', '005010X222', '0050100X222')")
        .withColumn("PLN_CLM_TYPE", lit("837P"))
        .withColumn("PAYOR_ID", join1("R09"))
        .withColumn("PAYORNAME", join1("R03"))
        .withColumn("PLN_CD", join1("R09"))
        .withColumn("PLN_NM", join1("R03"))
        .select("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX", "PLN_CLM_TYPE"
          , "PAYOR_ID", "PAYORNAME", "PLN_CD", "PLN_NM")

      val nm1_2010_tbl2 = table("e837_loop_2010_nm1").filter("LOOP_QUALIFIER = 'BC'")
      val gs_tbl2 = df //table("e837_gs")
        .withColumnRenamed("R08", "GS_R08").drop("R03")
      val join2 = nm1_2010_tbl2.join(gs_tbl2, Seq("FILE_ID", "INTERCHANGE_IDX"), "inner")
      val pln_tbl2 = join2.filter("GS_R08 in ('004010X096A1','005010X223A2', '005010X096A1')")
        .withColumn("PLN_CLM_TYPE", lit("837I"))
        .withColumn("PAYOR_ID", join2("R09"))
        .withColumn("PAYORNAME", join2("R03"))
        .withColumn("PLN_CD", join2("R09"))
        .withColumn("PLN_NM", join2("R03"))
        .select("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX", "PLN_CLM_TYPE"
          , "PAYOR_ID", "PAYORNAME", "PLN_CD", "PLN_NM")

      val pln = pln_tbl1.union(pln_tbl2)
        .select("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX", "PLN_CLM_TYPE"
          , "PAYOR_ID", "PAYORNAME", "PLN_CD", "PLN_NM")

      val sbr_2000 = table("e837_loop_2000_sbr").filter("LOOP_QUALIFIER = 'B'")
        .withColumnRenamed("R01", "PAYER_RESP_SEQ")
        .withColumnRenamed("R09", "FIN_CLS")

      val nm1_1000_plan = table("e837_loop_1000_nm1").filter("LOOP_QUALIFIER = 'B' and R08 = '46'")

      val nm1_2010_sub = table("e837_loop_2010_nm1").filter("LOOP_QUALIFIER = 'BA' and R08 = 'MI'")
        .withColumnRenamed("R09", "CARDHOLDERID")


      val clm_join1 = clm_tbl1.join(sbr_2000, Seq("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX"), "inner")
        .join(nm1_1000_plan, Seq("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX"), "inner")
        .join(nm1_2010_sub, Seq("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX"), "inner")
        .join(pln,Seq("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX","PLN_CLM_TYPE"),"inner")

      val clm1 = clm_join1.select("CLM_DT", "CLM_TYPE", "SUBMIT_DT", "CLM_ID", "ENC_ID", "MED_REC_NBR", "PAYER_RESP_SEQ"
        , "FIN_CLS", "PAYOR_ID", "PAYORNAME", "PLN_CD", "PLN_NM", "CARDHOLDERID")

      val sbr_2320 = table("e837_loop_2320_sbr")
        .withColumnRenamed("R01", "PAYER_RESP_SEQ")
        .withColumnRenamed("R09", "FIN_CLS")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,0)"))

      val nm1_2330_plan = table("e837_loop_2330_nm1").filter("LOOP_QUALIFIER = 'B' and R08 = 'PI'")
        .withColumn("PAYOR_ID", expr("R09"))
        .withColumn("PAYORNAME", expr("R03"))
        .withColumn("PLN_CD", expr("R09"))
        .withColumn("PLN_NM", expr("R03"))
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,0)"))

      val nm1_2330_sub = table("e837_loop_2330_nm1").filter("LOOP_QUALIFIER = 'A' and R08 = 'MI'")
        .withColumnRenamed("R09", "CARDHOLDERID")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,0)"))

      val clm_join2 = clm_tbl1.join(sbr_2320, Seq("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX"
        , "LOOP_2000C_IDX", "LOOP_2300_IDX"), "inner")
        .join(nm1_2330_plan, Seq("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX"
          , "LOOP_2000C_IDX", "LOOP_2300_IDX"), "inner")
        .join(nm1_2330_sub, Seq("FILE_ID", "DOC_IDX", "INTERCHANGE_IDX", "LOOP_2000A_IDX", "LOOP_2000B_IDX"
          , "LOOP_2000C_IDX", "LOOP_2300_IDX"), "inner")

      val clm2 = clm_join2.select("CLM_DT", "CLM_TYPE", "SUBMIT_DT", "CLM_ID", "ENC_ID", "MED_REC_NBR", "PAYER_RESP_SEQ"
        , "FIN_CLS", "PAYOR_ID", "PAYORNAME", "PLN_CD", "PLN_NM", "CARDHOLDERID")

      val clm = clm1.union(clm2)
      clm.select("CLM_DT", "CLM_TYPE", "SUBMIT_DT", "CLM_ID", "ENC_ID", "MED_REC_NBR", "PAYER_RESP_SEQ"
        ,"FIN_CLS", "PAYOR_ID", "PAYORNAME", "PLN_CD", "PLN_NM", "CARDHOLDERID")
    })
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "PATIENTID" -> mapFrom("MED_REC_NBR"),
    "ENCOUNTERID" -> mapFrom("ENC_ID"),
    "SOURCEID" -> mapFrom("CLM_ID"),
    "INS_TIMESTAMP" -> ((col: String, df: DataFrame) => {
      val groups = Window.partitionBy(df("CLM_ID"))
      val df1 = df.withColumn("SUBMIT_DATE", min(df("SUBMIT_DT")).over(groups))
      df1.withColumn(col, coalesce(df1("CLM_DT"), date_trunc("DAY", df1("SUBMIT_DATE"))))
    }),
    "POLICYNUMBER" -> mapFrom("CARDHOLDERID"),
    "PLANTYPE" -> mapFrom("FIN_CLS"),
    "PAYORCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat_ws("",lit("e837."),df("PAYOR_ID")))
    }),
    "PAYORNAME" -> mapFrom("PAYORNAME"),
    "PLANCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, concat_ws("",lit("e837."),df("PLN_CD")))
    }),
    "PLANNAME" -> mapFrom("PLN_NM"),
    "INSURANCEORDER" -> ((col: String, df: DataFrame) => {
      val groups = Window.partitionBy(df("CLM_ID")).orderBy(df("PAYOR_ID").asc_nulls_last)
      val addcol = df.withColumn("rn", row_number.over(groups))
      addcol.withColumn(col, when(addcol("PAYER_RESP_SEQ") === lit("P"), lit("1"))
        .when(addcol("PAYER_RESP_SEQ") === lit("S"), lit("2"))
        .when(addcol("PAYER_RESP_SEQ") === lit("T"), addcol("rn") + 2)
        .otherwise(null))
    })
  )


  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Insurance ").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*).distinct()
      .filter("PATIENTID is not null and INS_TIMESTAMP is not null")
  }

}

//val es = new InsuranceClm(cfg); val ins = build(es,allColumns=true)
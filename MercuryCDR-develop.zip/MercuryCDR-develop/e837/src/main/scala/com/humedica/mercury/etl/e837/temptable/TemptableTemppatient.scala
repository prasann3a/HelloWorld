package com.humedica.mercury.etl.e837.temptable

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class TemptableTemppatient(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  cacheMe = true

  tables = List(
    "temptable:e837.temptable.TemptableTempclaim"
    ,"e837_loop_2000_hl"
    ,"e837_loop_2000_sbr"
    ,"e837_loop_2010_nm1"
    ,"e837_loop_2000_pat"
    ,"e837_loop_2010_dmg"
    ,"e837_loop_2010_n4"
    ,"e837_loop_2010_n3"
    ,"e837_loop_2010_ref"
  )

  columnSelect = Map(
    "temptable" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"MED_REC_NBR","CLM_TYPE","SUBISPAT","SUBMIT_DT","CLM_DT","MRN"),
    "e837_loop_2000_hl" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_QUALIFIER","R01","R02","R03","R04"),
    "e837_loop_2000_sbr" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_QUALIFIER"),
    "e837_loop_2010_nm1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_QUALIFIER","R02","R03","R04","R08","R09"),
    "e837_loop_2000_pat" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_QUALIFIER","R06"),
    "e837_loop_2010_dmg" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_QUALIFIER","R02","R03"),
    "e837_loop_2010_n4" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_QUALIFIER","R01","R02","R03"),
    "e837_loop_2010_n3" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_QUALIFIER","R01","R02"),
    "e837_loop_2010_ref" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_QUALIFIER","R01","R02")
  )

  columns = List("CLM_DT","SUBMIT_DT","MED_REC_NBR","CLM_TYPE","SUBISPAT","CLM_VERSION","PATIENTID","ENCOUNTERID","DOB"
    ,"DOD","PAT_FIRST","PAT_LAST","PAT_GENDER","PAT_CITY","PAT_STATE","PAT_ADDR_1","PAT_ADDR_2","PAT_ZIP","PAT_ALT_ID"
    ,"PAT_ALT_ID_QUAL","FILE_ID", "MRN", "SUB_ALT_ID", "SUB_ADDR_1", "UPDATE_DT", "SUB_CITY", "SUB_GENDER", "SUB_FIRST"
    ,"SUB_LAST","SUB_STATE"
  )

  beforeJoin = Map(
    "temptable" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("MED_REC_NBR is not null")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val subhl = table("e837_loop_2000_hl").filter("LOOP_QUALIFIER = 'B'")
    val subsbr = table("e837_loop_2000_sbr").filter("LOOP_QUALIFIER = 'B'")
    val subnm1 = table("e837_loop_2010_nm1").filter("LOOP_QUALIFIER = 'BA'")
      .withColumnRenamed("R02","SUBNM1_R02")
      .withColumnRenamed("R03","SUB_LAST")
      .withColumnRenamed("R04","SUB_FIRST")
      .withColumnRenamed("R08", "SUB_ID_QUAL")
      .withColumnRenamed("R09","SUB_ID")
    val subpat = table("e837_loop_2000_pat").filter("LOOP_QUALIFIER = 'B'")
      .withColumnRenamed("R06", "SUB_DOD")
    val subdmg = table("e837_loop_2010_dmg").filter("LOOP_QUALIFIER = 'BA'")
      .withColumnRenamed("R02","SUB_DOB")
      .withColumnRenamed("R03", "SUB_GENDER")
    val subn4 = table("e837_loop_2010_n4").filter("LOOP_QUALIFIER = 'BA'")
      .withColumnRenamed("R01","SUB_CITY")
      .withColumnRenamed("R02", "SUB_STATE")
      .withColumnRenamed("R03", "SUB_ZIP") //need to standardize
    val subn3 = table("e837_loop_2010_n3").filter("LOOP_QUALIFIER = 'BA'")
      .withColumnRenamed("R01","SUB_ADDR_1")
      .withColumnRenamed("R02","SUB_ADDR_2")
    val subref = table("e837_loop_2010_ref").filter("LOOP_QUALIFIER = 'BA'")
      .withColumnRenamed("R01","SUB_ALT_ID_QUAL")
      .withColumnRenamed("R02","SUB_ALT_ID")

    val join1 = subhl.join(subsbr, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"),"inner")
      .join(subnm1, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"),"inner")
      .join(subpat, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"),"left_outer")
      .join(subdmg, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"),"left_outer")
      .join(subn4, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"),"left_outer")
      .join(subn3, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"),"left_outer")
      .join(subref, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"),"left_outer")

    val subtbl = join1.filter("SUBNM1_R02 = '1'")
      .select("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","SUB_LAST"
        ,"SUB_FIRST","SUB_ID_QUAL","SUB_ID","SUB_DOD","SUB_DOB","SUB_GENDER","SUB_CITY","SUB_STATE","SUB_ZIP","SUB_ADDR_1"
        ,"SUB_ADDR_2","SUB_ALT_ID_QUAL","SUB_ALT_ID")

    val pathl = table("e837_loop_2000_hl").filter("LOOP_QUALIFIER = 'C'")
      .withColumnRenamed("R01","PAT_HL_ID")
      .withColumnRenamed("R02","PAT_HL_PARENT")
      .withColumnRenamed("R03","PAT_HL_CD")
      .withColumnRenamed("R04","PAT_HL_CHILD")
      .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,0)"))
    val patnm1 = table("e837_loop_2010_nm1").filter("LOOP_QUALIFIER = 'CA'")
      .withColumnRenamed("R02","PATNM1_R02")
      .withColumnRenamed("R03","PAT_LAST")
      .withColumnRenamed("R04","PAT_FIRST")
      .withColumnRenamed("R08", "PAT_ID_QUAL")
      .withColumnRenamed("R09","PAT_ID")
    val patpat = table("e837_loop_2000_pat").filter("LOOP_QUALIFIER = 'C'")
      .withColumnRenamed("R06", "PAT_DOD")
    val patdmg = table("e837_loop_2010_dmg").filter("LOOP_QUALIFIER = 'CA'")
      .withColumnRenamed("R02","PAT_DOB")
      .withColumnRenamed("R03", "PAT_GENDER")
    val patn4 = table("e837_loop_2010_n4").filter("LOOP_QUALIFIER = 'CA'")
      .withColumnRenamed("R01","PAT_CITY")
      .withColumnRenamed("R02", "PAT_STATE")
      .withColumnRenamed("R03", "PAT_ZIP") //need to standardize
    val patn3 = table("e837_loop_2010_n3").filter("LOOP_QUALIFIER = 'CA'")
      .withColumnRenamed("R01","PAT_ADDR_1")
      .withColumnRenamed("R02","PAT_ADDR_2")
    val patref = table("e837_loop_2010_ref").filter("LOOP_QUALIFIER = 'CA'")
      .withColumnRenamed("R01","PAT_ALT_ID_QUAL")
      .withColumnRenamed("R02","PAT_ALT_ID")

    val join2 = pathl.join(patnm1, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"inner")
      .join(patpat, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(patdmg, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(patn4, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(patn3, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(patref, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")

    val pattbl = join2.filter("PATNM1_R02 = '1'")
      .select("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"PAT_LAST","PAT_FIRST","PAT_ID_QUAL","PAT_ID","PAT_DOD","PAT_DOB","PAT_GENDER","PAT_CITY","PAT_STATE"
        ,"PAT_ZIP","PAT_ADDR_1","PAT_ADDR_2","PAT_ALT_ID_QUAL","PAT_ALT_ID")

    dfs("temptable")
      .join(subtbl, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"),"inner")
      .join(pattbl,Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
  }

  map = Map(
    "PATIENTID" -> mapFrom("MED_REC_NBR"),
    "ENCOUNTERID" -> nullValue(),
    "DOB" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("DOB1", when(df("SUBISPAT") === "0", df("PAT_DOB")).otherwise(df("SUB_DOB")))

      val df2 = df1.withColumn("lenAddm", datelengthcheck(df1("DOB1"), lit("yyyyMMdd")))
      val df3 = df2.withColumn("DOB_upd1",
        when(length(df2("DOB1")).lt(df2("lenAddm")), expr("rpad(DOB1, lenAddm, '0')"))
          .when(length(df2("DOB1")).gt(df2("lenAddm")), expr("substr(DOB1, 0, lenAddm)"))
          .otherwise(df2("DOB1")))

      val df4 = df3.withColumn("BIRTHDATE", to_timestamp(df3("DOB_upd1"), "yyyyMMdd"))
        .drop("lenAddm","DOB_upd1")

      val groups = Window.partitionBy(df("MED_REC_NBR"))
        .orderBy(when(df4("DOB1").isNotNull, lit("1")).otherwise(lit("0")).desc_nulls_last, df("SUBMIT_DT").desc)
      df4.withColumn(col, first(df4("BIRTHDATE")).over(groups))
    }),
    "DOD" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("DOD1", when(df("SUBISPAT") === "0", df("PAT_DOD")).otherwise(df("SUB_DOD")))
      val df2 = df1.withColumn("lenAddm", datelengthcheck(df1("DOD1"), lit("yyyyMMdd")))
      val df3 = df2.withColumn("DOD_upd1",
        when(length(df2("DOD1")).lt(df2("lenAddm")), expr("rpad(DOD1, lenAddm, '0')"))
          .when(length(df2("DOD1")).gt(df2("lenAddm")), expr("substr(DOD1, 0, lenAddm)"))
          .otherwise(df2("DOD1")))

      df3.withColumn(col, to_timestamp(df3("DOD_upd1"), "yyyyMMdd"))
        .drop("lenAddm","DOD_upd1")
    }),
    "PAT_LAST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", df("PAT_LAST")).otherwise(df("SUB_LAST")))
    }),
    "PAT_FIRST" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", df("PAT_FIRST")).otherwise(df("SUB_FIRST")))
    }),
    "PAT_GENDER" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", df("PAT_GENDER")).otherwise(df("SUB_GENDER")))
    }),
    "PAT_CITY" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", df("PAT_CITY")).otherwise(df("SUB_CITY")))
    }),
    "PAT_STATE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", regexp_replace(df("PAT_STATE"),"[[:punct:]0-9 ]",""))
        .otherwise(regexp_replace(df("SUB_STATE"),"[[:punct:]0-9 ]","")))
    }),
    "PAT_ADDR_1" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", df("PAT_ADDR_1")).otherwise(df("SUB_ADDR_1")))
    }),
    "PAT_ADDR_2" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", df("PAT_ADDR_2")).otherwise(df("SUB_ADDR_2")))
    }),
    "PAT_ZIP" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", df("PAT_ZIP")).otherwise(df("SUB_ZIP")))
    }),
    "PAT_ALT_ID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", df("PAT_ALT_ID")).otherwise(df("SUB_ALT_ID")))
    }),
    "PAT_ALT_ID_QUAL" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUBISPAT") === "0", df("PAT_ALT_ID_QUAL")).otherwise(df("SUB_ALT_ID_QUAL")))
    }),
    "UPDATE_DT" -> cascadeFrom(Seq("CLM_DT","SUBMIT_DT"))
  )

}

//val es = new TemptableTemppatient(cfg); val pat = build(es,allColumns=true)



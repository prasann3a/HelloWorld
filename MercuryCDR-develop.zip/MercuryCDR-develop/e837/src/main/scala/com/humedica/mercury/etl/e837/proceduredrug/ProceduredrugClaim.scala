package com.humedica.mercury.etl.e837.proceduredrug

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class ProceduredrugClaim(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "tempservice:e837.temptable.TemptableTempservice"
    ,"e837_loop_2410_lin"
    ,"e837_loop_2410_ref"
    ,"e837_loop_2400_dtp"
  )

  columnSelect = Map(
    "tempservice" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","PATIENTID","PERFPROVID","CLM_TYPE","CLAIMID","ENCOUNTERID","PROC_CD","SUBMIT_DT","PROC_DT"),
    "e837_loop_2410_lin" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_2400_IDX","SEGMENT_IDX","R02","R03"),
    "e837_loop_2410_ref" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_2400_IDX","SEGMENT_IDX","R02"),
    "e837_loop_2400_dtp" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_2400_IDX","SEGMENT_IDX","R01","R02","R03")
  )

  beforeJoin = Map(
    "tempservice" -> ((df: DataFrame) => {
      df.filter("PATIENTID is not null")
    }),
    "e837_loop_2410_lin" -> ((df: DataFrame) => {
      df.filter("R02 = 'N4'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,0)"))
        .withColumnRenamed("R03","LIN_R03")
        .withColumnRenamed("SEGMENT_IDX","LIN_SEGMENT_IDX")
    }),
    "e837_loop_2410_ref" -> ((df: DataFrame) => {
      df.withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,0)"))
        .withColumnRenamed("R02","REF_R02")
    }),
    "e837_loop_2400_dtp" -> ((df: DataFrame) => {
      df.filter("R01 = '472'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,0)"))
        .withColumnRenamed("R02","DTP_R02")
        .withColumnRenamed("R03","DTP_R03")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("e837_loop_2410_lin")
      .join(dfs("tempservice"),Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
        ,"LOOP_2000C_IDX"), "inner")
      .join(dfs("e837_loop_2410_ref"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
      .join(dfs("e837_loop_2400_dtp"),Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2400_IDX","LOOP_2300_IDX"
        ,"LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"),"left_outer")
  }

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "SOURCEID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, coalesce(df("REF_R02"), concat_ws("",df("CLAIMID"),lit("_"),df("LIN_SEGMENT_IDX"))))
    }),
    "PERFORMINGPROVIDERID" -> mapFrom("PERFPROVID"),
    "PROCEDUREDATE" -> ((col: String, df: DataFrame) => {
      val df1 = df.withColumn("PROCDT", when(df("DTP_R02") === "R08", substring(df("DTP_R03"),1,8)).otherwise(df("DTP_R03")))
      val len = df1.withColumn("lenAddm", datelengthcheck(df1("PROCDT"), lit("yyyyMMdd")))
      val df2 = len.withColumn("PROCDT_1",
        when(length(len("PROCDT")).lt(len("lenAddm")), expr("rpad(PROCDT, lenAddm, '0')"))
          .when(length(len("PROCDT")).gt(len("lenAddm")), expr("substr(PROCDT, 0, lenAddm)"))
          .otherwise(len("PROCDT")))
      df2.withColumn(col, coalesce(to_timestamp(df2("PROCDT_1"), "yyyyMMdd"),df2("PROC_DT")))
    }),
    "LOCALCODE" -> mapFrom("PROC_CD"),
    "LOCALMEDCODE" -> mapFrom("LIN_R03")
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("PATIENTID IS NOT NULL AND PROCEDUREDATE IS NOT NULL")
    val groups = Window.partitionBy(fil("PATIENTID"), fil("SOURCEID"), fil("PROCEDUREDATE")).orderBy(fil("SUBMIT_DT").desc_nulls_last)
    val addColumn = fil.withColumn("rn", row_number.over(groups))
    addColumn.filter("rn = 1").drop("rn")
  }


}

//val es = new ProceduredrugClaim(cfg); val pd = build(es,allColumns=true)

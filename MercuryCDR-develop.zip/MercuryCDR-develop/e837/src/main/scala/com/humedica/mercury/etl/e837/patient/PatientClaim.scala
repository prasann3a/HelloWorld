package com.humedica.mercury.etl.e837.patient

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class PatientClaim(config: Map[String,String]) extends EntitySource(config: Map[String,String])  {

  tables = List(
    "temptable:e837.temptable.TemptableTemppatient"
  )

  columnSelect = Map(
    "temptable" -> List("PATIENTID", "DOB", "DOD" ,"CLM_TYPE", "FILE_ID", "MRN")
  )

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "DATEOFBIRTH" -> mapFrom("DOB"),
    "MEDICALRECORDNUMBER" -> mapFrom("MRN"),
    "DATEOFDEATH" -> mapFrom("DOD"),
    "INACTIVE_FLAG" -> nullValue()
  )


  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID")).orderBy(df("FILE_ID").asc_nulls_last)
    val addcol = df.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1 and PATIENTID is not null ").drop("rn")
  }
}


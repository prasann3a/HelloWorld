package com.humedica.mercury.etl.e837.procedure

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Functions._
import scala.collection.JavaConverters._

class ProcedureHi(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temphi:e837.temptable.TemptableTemphisegment"
  )

  columnSelect = Map(
    "temphi" -> List("CLM_TYPE","PATIENTID","ENCOUNTERID","SOURCEID","LOCALCODE","CD_TIMESTAMP","HOSP_DX_FLAG"
      ,"PERFPROV_ID","LOCALPRINCIPLEINDICATOR","CD_QUAL_FINAL")
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "SOURCEID" -> mapFrom("SOURCEID"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "PERFORMINGPROVIDERID" -> mapFrom("PERFPROV_ID"),
    "PROCEDUREDATE" -> mapFrom("CD_TIMESTAMP"),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "CODETYPE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("LOCALCODE").rlike("^[0-9]{4}[0-9A-Z]$"), lit("CPT4"))
          .when(df("LOCALCODE").rlike("^[A-Z][0-9]{4}$"), lit("HCPCS"))
          .when(df("LOCALCODE").rlike("^[0-9]{2,2}\\.?[0-9]{1,2}$"), lit("ICD9"))
          .when(df("LOCALCODE").rlike("^[0-9A-Z]{1}[0-9A-Z]{6}"), lit("ICD10"))
          .otherwise(null))
    }),
    "MAPPEDCODE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, formatICD9Proc(df("LOCALCODE")))
    }),
    "HOSP_PX_FLAG" -> mapFrom("HOSP_DX_FLAG"),
    "ACTUALPROCDATE" -> mapFrom("CD_TIMESTAMP"),
    "LOCALPRINCIPLEINDICATOR" -> mapFrom("LOCALPRINCIPLEINDICATOR")
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("CD_QUAL_FINAL = 'Px' and PROCEDUREDATE is not null and PATIENTID is not null")
    val cols = Engine.schema.getStringList("Procedure").asScala.map(_.split("-")(0).toUpperCase())
    fil.select(cols.map(col): _*)
      .distinct
  }

}

// val es = new ProcedureHi(cfg); val pr = build(es,allColumns=true)

package com.humedica.mercury.etl.e837.temptable

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window

class TemptableTemphisegment(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  cacheMe = true

  tables = List(
    "temptable:e837.temptable.TemptableTempclaim"
    ,"e837_loop_2300_hi"
    ,"e837_loop_2300_k3"
    ,"e837_loop_2310_nm1"
    ,"tempdgpt:e837.temptable.TemptableSer837dgpt"
    ,"cdr.ref_poa_exmpt_diag_cd_icd9"
    ,"cdr.ref_poa_exmpt_diag_cd_icd10"
  )

  columnSelect = Map(
    "temptable" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","MED_REC_NBR","CLM_TYPE","CLM_DT","CLM_START_DT","ONSET_DT","CLM_ID","CLM_VERSION","ENC_ID"),
    "e837_loop_2300_hi" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","SEGMENT_IDX","R01_R02","R02_R02","R03_R02","R04_R02","R05_R02","R06_R02","R07_R02","R08_R02"
      ,"R09_R02","R10_R02","R11_R02","R12_R02","R01_R01","R02_R01","R03_R01","R04_R01","R05_R01","R06_R01","R07_R01"
      ,"R08_R01","R09_R01","R10_R01","R11_R01","R12_R01","R01_R04","R02_R04","R03_R04","R04_R04","R05_R04","R06_R04"
      ,"R07_R04","R08_R04","R09_R04","R10_R04","R11_R04","R12_R04","R01_R09","R02_R09","R03_R09","R04_R09","R05_R09"
      ,"R06_R09","R07_R09","R08_R09","R09_R09","R10_R09","R11_R09","R12_R09"),
    "e837_loop_2300_k3" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","R01"),
    "e837_loop_2310_nm1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
      ,"LOOP_2000C_IDX","LOOP_QUALIFIER","R02","R03","R04","R08","R09"),
    "tempdgpt" -> List("CLAIMID","DIAG_POINTER","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000C_IDX","LOOP_2000A_IDX"
      ,"LOOP_2000B_IDX","CLAIMLINEID")
  )

  columns = List("PATIENTID","CLM_TYPE","CD_DT","CD_TIMESTAMP","ONSET_DT","SOURCEID","CLAIM_ID","LOCALCODE","HOSP_DX_FLAG"
    ,"LOCALPRINCIPLEINDICATOR","ENCOUNTERREASON","CD_QUAL_FINAL","DX_CODETYPE","LOCALADMITFLG","PRIMARYDIAGNOSIS","POA_IND_F"
    ,"PERFPROV_ID","PERFPROV_LAST","PERFPROV_FIRST","CLM_VERSION","ENCOUNTERID"
  )

  beforeJoin = Map(
    "temptable" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("MED_REC_NBR is not null")
        .withColumnRenamed("MED_REC_NBR","PATIENTID")
        .withColumnRenamed("ENC_ID","ENCOUNTERID")
        .withColumnRenamed("CLM_ID","CLAIM_ID")
    }),
    "e837_loop_2300_hi"  -> ((df: DataFrame) => {
      val df1 = df.coalesce(1000)
        .withColumn("row_codes", safe_to_number(when(df("R01_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R02_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R03_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R04_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R05_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R06_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R07_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R08_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R09_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R10_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R11_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0")
          + when(df("R12_R01").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), "1").otherwise("0"))
        )
      val groups = Window.partitionBy(df1("FILE_ID"),df1("INTERCHANGE_IDX"),df1("DOC_IDX"),df1("LOOP_2000A_IDX"),df1("LOOP_2000B_IDX")
        ,df1("LOOP_2000C_IDX"),df1("LOOP_2300_IDX")).orderBy(df1("SEGMENT_IDX"))

      df1.coalesce(1000)
        .withColumn("code_cnt", sum(df1("row_codes")).over(groups))
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumn("LOCALPRINCIPLEINDICATOR", when(df1("R01_R01").isin("BBR","BR"), lit("Y")).otherwise(lit("N")))
        .withColumnRenamed("R01_R02","d1")
        .withColumnRenamed("R02_R02","d2")
        .withColumnRenamed("R03_R02","d3")
        .withColumnRenamed("R04_R02","d4")
        .withColumnRenamed("R05_R02","d5")
        .withColumnRenamed("R06_R02","d6")
        .withColumnRenamed("R07_R02","d7")
        .withColumnRenamed("R08_R02","d8")
        .withColumnRenamed("R09_R02","d9")
        .withColumnRenamed("R10_R02","d10")
        .withColumnRenamed("R11_R02","d11")
        .withColumnRenamed("R12_R02","d12")
        .withColumnRenamed("R01_R01","d1_flg")
        .withColumnRenamed("R02_R01","d2_flg")
        .withColumnRenamed("R03_R01","d3_flg")
        .withColumnRenamed("R04_R01","d4_flg")
        .withColumnRenamed("R05_R01","d5_flg")
        .withColumnRenamed("R06_R01","d6_flg")
        .withColumnRenamed("R07_R01","d7_flg")
        .withColumnRenamed("R08_R01","d8_flg")
        .withColumnRenamed("R09_R01","d9_flg")
        .withColumnRenamed("R10_R01","d10_flg")
        .withColumnRenamed("R11_R01","d11_flg")
        .withColumnRenamed("R12_R01","d12_flg")
        .withColumnRenamed("R01_R04","d1_dt")
        .withColumnRenamed("R02_R04","d2_dt")
        .withColumnRenamed("R03_R04","d3_dt")
        .withColumnRenamed("R04_R04","d4_dt")
        .withColumnRenamed("R05_R04","d5_dt")
        .withColumnRenamed("R06_R04","d6_dt")
        .withColumnRenamed("R07_R04","d7_dt")
        .withColumnRenamed("R08_R04","d8_dt")
        .withColumnRenamed("R09_R04","d9_dt")
        .withColumnRenamed("R10_R04","d10_dt")
        .withColumnRenamed("R11_R04","d11_dt")
        .withColumnRenamed("R12_R04","d12_dt")
        .withColumnRenamed("R01_R09","d1_poa")
        .withColumnRenamed("R02_R09","d2_poa")
        .withColumnRenamed("R03_R09","d3_poa")
        .withColumnRenamed("R04_R09","d4_poa")
        .withColumnRenamed("R05_R09","d5_poa")
        .withColumnRenamed("R06_R09","d6_poa")
        .withColumnRenamed("R07_R09","d7_poa")
        .withColumnRenamed("R08_R09","d8_poa")
        .withColumnRenamed("R09_R09","d9_poa")
        .withColumnRenamed("R10_R09","d10_poa")
        .withColumnRenamed("R11_R09","d11_poa")
        .withColumnRenamed("R12_R09","d12_poa")
    }),
    "e837_loop_2300_k3" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("substr(R01,1,3) = 'POA'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumn("POA_PATTERN", expr("substr(R01,4,length(R01) - 4)"))
    }),
    "e837_loop_2310_nm1" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("LOOP_QUALIFIER = 'B' and R02 ='1' and R08 = 'XX'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R09","PERFPROV_ID")
        .withColumnRenamed("R03","PERFPROV_LAST")
        .withColumnRenamed("R04","PERFPROV_FIRST")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("temptable")
      .join(dfs("e837_loop_2300_hi"),Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000C_IDX","LOOP_2000A_IDX"
        ,"LOOP_2000B_IDX"),"inner")
      .join(dfs("e837_loop_2300_k3"),Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000C_IDX","LOOP_2000A_IDX"
      ,"LOOP_2000B_IDX"),"left_outer")
      .join(dfs("e837_loop_2310_nm1"),Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2300_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX"
        ,"LOOP_2000C_IDX"),"left_outer")
  }

  afterJoin = (df: DataFrame) => {
    val session = Engine.spark
    import session.implicits._
    val list_code_order = List(1,2,3,4,5,6,7,8,9,10,11,12)
    val df1 = list_code_order.map((_,1)).toDF("CODE_ORDER", "FOO").drop("FOO")
    val join1 = df.join(df1)
    val df2 = join1.withColumn("LOCALCODE", when(join1("CODE_ORDER") === 1, join1("d1"))
        .when(join1("CODE_ORDER") === 2, join1("d2"))
        .when(join1("CODE_ORDER") === 3, join1("d3"))
        .when(join1("CODE_ORDER") === 4, join1("d4"))
        .when(join1("CODE_ORDER") === 5, join1("d5"))
        .when(join1("CODE_ORDER") === 6, join1("d6"))
        .when(join1("CODE_ORDER") === 7, join1("d7"))
        .when(join1("CODE_ORDER") === 8, join1("d8"))
        .when(join1("CODE_ORDER") === 9, join1("d9"))
        .when(join1("CODE_ORDER") === 10, join1("d10"))
        .when(join1("CODE_ORDER") === 11, join1("d11"))
        .when(join1("CODE_ORDER") === 12, join1("d12"))
        .otherwise(null))
      .withColumn("CD_QUAL", when(join1("CODE_ORDER") === 1, join1("d1_flg"))
        .when(join1("CODE_ORDER") === 2, join1("d2_flg"))
        .when(join1("CODE_ORDER") === 3, join1("d3_flg"))
        .when(join1("CODE_ORDER") === 4, join1("d4_flg"))
        .when(join1("CODE_ORDER") === 5, join1("d5_flg"))
        .when(join1("CODE_ORDER") === 6, join1("d6_flg"))
        .when(join1("CODE_ORDER") === 7, join1("d7_flg"))
        .when(join1("CODE_ORDER") === 8, join1("d8_flg"))
        .when(join1("CODE_ORDER") === 9, join1("d9_flg"))
        .when(join1("CODE_ORDER") === 10, join1("d10_flg"))
        .when(join1("CODE_ORDER") === 11, join1("d11_flg"))
        .when(join1("CODE_ORDER") === 12, join1("d12_flg"))
        .otherwise(null))
      .withColumn("CD_DT", when(join1("CODE_ORDER") === 1, join1("d1_dt"))
        .when(join1("CODE_ORDER") === 2, join1("d2_dt"))
        .when(join1("CODE_ORDER") === 3, join1("d3_dt"))
        .when(join1("CODE_ORDER") === 4, join1("d4_dt"))
        .when(join1("CODE_ORDER") === 5, join1("d5_dt"))
        .when(join1("CODE_ORDER") === 6, join1("d6_dt"))
        .when(join1("CODE_ORDER") === 7, join1("d7_dt"))
        .when(join1("CODE_ORDER") === 8, join1("d8_dt"))
        .when(join1("CODE_ORDER") === 9, join1("d9_dt"))
        .when(join1("CODE_ORDER") === 10, join1("d10_dt"))
        .when(join1("CODE_ORDER") === 11, join1("d11_dt"))
        .when(join1("CODE_ORDER") === 12, join1("d12_dt"))
        .otherwise(null))
      .withColumn("CD_POA", when(join1("CODE_ORDER") === 1, join1("d1_poa"))
        .when(join1("CODE_ORDER") === 2, join1("d2_poa"))
        .when(join1("CODE_ORDER") === 3, join1("d3_poa"))
        .when(join1("CODE_ORDER") === 4, join1("d4_poa"))
        .when(join1("CODE_ORDER") === 5, join1("d5_poa"))
        .when(join1("CODE_ORDER") === 6, join1("d6_poa"))
        .when(join1("CODE_ORDER") === 7, join1("d7_poa"))
        .when(join1("CODE_ORDER") === 8, join1("d8_poa"))
        .when(join1("CODE_ORDER") === 9, join1("d9_poa"))
        .when(join1("CODE_ORDER") === 10, join1("d10_poa"))
        .when(join1("CODE_ORDER") === 11, join1("d11_poa"))
        .when(join1("CODE_ORDER") === 12, join1("d12_poa"))
        .otherwise(null))
      .withColumn("POA_IND", when(join1("CODE_ORDER") === 1 && join1("d1_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,1 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 2 && join1("d2_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,2 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 3 && join1("d3_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,3 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 4 && join1("d4_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,4 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 5 && join1("d5_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,5 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 6 && join1("d6_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,6 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 7 && join1("d7_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,7 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 8 && join1("d8_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,8 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 9 && join1("d9_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,9 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 10 && join1("d10_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,10 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 11 && join1("d11_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,11 + (code_cnt - row_codes) ,1)"))
        .when(join1("CODE_ORDER") === 12 && join1("d12_flg").isin("BK","BF","BN","ABF","ABJ","ABK","ABN"), expr("substr(POA_PATTERN,12 + (code_cnt - row_codes) ,1)"))
        .otherwise(null))
      .withColumn("HOSP_DX_FLAG", when(join1("CLM_TYPE").like("837I%"), lit("Y")).otherwise(lit("N")))
      .withColumn("CD_TIMESTAMP", coalesce(join1("CLM_DT"),join1("CLM_START_DT")))

    val dgptr = table("tempdgpt")

    val df3 = df2.join(dgptr, df2("CLAIM_ID") === dgptr("CLAIMID") && df2("CODE_ORDER") === dgptr("DIAG_POINTER")
      && df2("DOC_IDX") === dgptr("DOC_IDX") && df2("INTERCHANGE_IDX") === dgptr("INTERCHANGE_IDX")
      && df2("LOOP_2300_IDX") === dgptr("LOOP_2300_IDX") && df2("LOOP_2000C_IDX") === dgptr("LOOP_2000C_IDX")
      && df2("LOOP_2000A_IDX") === dgptr("LOOP_2000A_IDX") && df2("LOOP_2000B_IDX") === dgptr("LOOP_2000B_IDX"), "left_outer")

    val fil = df3.filter("LOCALCODE is not null")
      .withColumnRenamed("CLAIMLINEID","SOURCEID")
      .withColumn("CD_QUAL_FINAL", when(df3("CD_QUAL").isin("BK","BF","ZZ","BJ","BN","ABF","ABJ","ABK","ABN"), lit("Dx"))
          .when(df3("CD_QUAL").isin("BO","BP","BQ","BR","BBQ","BBR"), lit("Px"))
          .otherwise(null))
      .select("PATIENTID","CD_TIMESTAMP","ONSET_DT","CD_DT","CLM_TYPE","SOURCEID","CLAIM_ID","ENCOUNTERID","CD_POA","POA_IND"
        ,"HOSP_DX_FLAG","LOCALPRINCIPLEINDICATOR","CD_QUAL","CD_QUAL_FINAL","PERFPROV_ID","PERFPROV_LAST","PERFPROV_FIRST","CLM_VERSION"
        ,"LOCALCODE")

    val df4 = fil.groupBy("PATIENTID","CD_TIMESTAMP","ONSET_DT","CD_DT","CLM_TYPE","SOURCEID","CLAIM_ID","ENCOUNTERID","LOCALCODE"
      ,"HOSP_DX_FLAG","LOCALPRINCIPLEINDICATOR","CD_QUAL","CD_QUAL_FINAL","PERFPROV_ID","PERFPROV_LAST","PERFPROV_FIRST","CLM_VERSION")
      .agg(max(when(fil("CD_QUAL").isin("BK","ABK"), lit("1")).otherwise(lit("0"))).as("PRIMARYDIAGNOSIS"),
        max(when(substring(fil("CLM_VERSION"),1,3) === "005" && fil("CD_QUAL").isin("BF","BK","BN","ABF","ABK","ABN") && fil("CD_POA").isNotNull, fil("CD_POA"))
            .when(substring(fil("CLM_VERSION"),1,3) === "004" && fil("POA_IND").isNotNull, fil("POA_IND"))
            .otherwise(null)).as("POA_IND1")
      )
      .withColumn("DX_CODETYPE", when(fil("CD_QUAL").isin("ABF","ABJ","ABK","ABN","APR"), lit("ICD10")).otherwise(lit("ICD9")))

    val ref_icd9 = table("cdr.ref_poa_exmpt_diag_cd_icd9")
      .withColumnRenamed("DIAGNOSIS_CODE","DIAGNOSIS_CODE_ICD9")
    val ref_icd10 = table("cdr.ref_poa_exmpt_diag_cd_icd10")
      .withColumnRenamed("DIAGNOSIS_CODE","DIAGNOSIS_CODE_ICD10")

    df4.join(ref_icd9, df4("LOCALCODE") === regexp_replace(ref_icd9("DIAGNOSIS_CODE_ICD9"),"\\.","") && df4("DX_CODETYPE") === lit("ICD9"),"left_outer")
      .join(ref_icd10, df4("LOCALCODE") === regexp_replace(ref_icd10("DIAGNOSIS_CODE_ICD10"),"\\.","") && df4("DX_CODETYPE") === lit("ICD10"),"left_outer")

  }

  map = Map(
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "CLM_TYPE" -> mapFrom("CLM_TYPE"),
    "CD_TIMESTAMP" -> ((col: String, df: DataFrame) => {
      val len = df.withColumn("lenAddm", datelengthcheck(df("CD_DT"), lit("yyyyMMdd")))
      val df1 = len.withColumn("CD_DT_1",
        when(length(len("CD_DT")).lt(len("lenAddm")), expr("rpad(CD_DT, lenAddm, '0')"))
          .when(length(len("CD_DT")).gt(len("lenAddm")), expr("substr(CD_DT, 0, lenAddm)"))
          .otherwise(len("CD_DT")))

      val df2 =  df1.withColumn("CODE_DATE", to_timestamp(df1("CD_DT_1"), "yyyyMMdd"))

      df2.withColumn(col, coalesce(df2("CODE_DATE"), df2("CD_TIMESTAMP")))
    }),
    "ONSET_DT" -> mapFrom("ONSET_DT"),
    "SOURCEID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(substring(df("CLM_TYPE"),1,4) === "837P", expr("nvl(SOURCEID,ENCOUNTERID)"))
          .when(substring(df("CLM_TYPE"),1,4) === "837I", df("ENCOUNTERID"))
          .otherwise(null))
    }),
    "CLAIM_ID" -> mapFrom("CLAIM_ID"),
    "LOCALCODE" -> mapFrom("LOCALCODE"),
    "HOSP_DX_FLAG" -> mapFrom("HOSP_DX_FLAG"),
    "LOCALPRINCIPLEINDICATOR" -> mapFrom("LOCALPRINCIPLEINDICATOR"),
    "ENCOUNTERREASON" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("CD_QUAL").isin("APR","PR","ZZ"), lit("Y")).otherwise(null))
    }),
    "CD_QUAL_FINAL" -> mapFrom("CD_QUAL_FINAL"),
    "DX_CODETYPE" -> mapFrom("DX_CODETYPE"),
    "LOCALADMITFLG" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("CD_QUAL").isin("BJ","ABJ"), df("CD_QUAL")).otherwise(null))
    }),
    "PRIMARYDIAGNOSIS" -> mapFrom("PRIMARYDIAGNOSIS"),
    "POA_IND_F" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("POA_IND1").isNotNull, when(df("POA_IND1") === "", null).otherwise(df("POA_IND1")))
          .when(substring(df("CLM_VERSION"),1,3) === "005" && (df("DIAGNOSIS_CODE_ICD9").isNotNull || df("DIAGNOSIS_CODE_ICD10").isNotNull), lit("EXEMPT"))
          .otherwise(null))
    }),
    "PERFPROV_ID" -> mapFrom("PERFPROV_ID"),
    "PERFPROV_LAST" -> mapFrom("PERFPROV_LAST"),
    "PERFPROV_FIRST" -> mapFrom("PERFPROV_FIRST"),
    "CLM_VERSION" -> mapFrom("CLM_VERSION")
  )
}

// val es = new TemptableTemphisegment(cfg); val temp = build(es,allColumns=true)

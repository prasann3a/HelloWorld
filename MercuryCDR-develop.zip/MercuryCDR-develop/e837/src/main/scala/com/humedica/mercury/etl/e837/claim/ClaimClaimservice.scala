package com.humedica.mercury.etl.e837.claim

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class ClaimClaimservice(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "tempservice:e837.temptable.TemptableTempservice"
  )

  columnSelect = Map(
    "tempservice" -> List("PATIENTID","CLAIMID","ENCOUNTERID","CLM_TYPE","SUBMIT_DT","PROC_DT","CHARGE_AMT","QTY"
      ,"PROC_CD","CPTMOD1","CPTMOD2","CPTMOD3","CPTMOD4","PERFPROVID","CLAIMLINEID","POS","REV_CODE","PAID")
  )

  beforeJoin = Map(
    "temptable" -> ((df: DataFrame) => {
      df.filter("PATIENTID is not null and PROC_DT is not null")
    })
  )

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "FACILITYID" -> nullValue(),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "CLAIMID" -> mapFrom("CLAIMID"),
    "SERVICEDATE" -> mapFrom("PROC_DT"),
    "CHARGE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, bround(df("CHARGE_AMT"),2))
    }),
    "QUANTITY" -> mapFrom("QTY"),
    "LOCALCPT" -> mapFrom("PROC_CD"),
    "LOCALCPTMOD1" -> mapFrom("CPTMOD1"),
    "LOCALCPTMOD2" -> mapFrom("CPTMOD2"),
    "LOCALCPTMOD3" -> mapFrom("CPTMOD3"),
    "LOCALCPTMOD4" -> mapFrom("CPTMOD4"),
    "CLAIMPROVIDERID" -> mapFrom("PERFPROVID"),
    "LOCALBILLINGPROVIDERID" -> nullValue(),
    "MAPPEDCPT" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, substring(df("PROC_CD"),1,5))
    }),
    "MAPPEDCPTMOD1" -> mapFrom("CPTMOD1"),
    "MAPPEDCPTMOD2" -> mapFrom("CPTMOD2"),
    "MAPPEDCPTMOD3" -> mapFrom("CPTMOD3"),
    "MAPPEDCPTMOD4" -> mapFrom("CPTMOD4"),
    "SOURCEID" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(substring(df("CLM_TYPE"),1,4) === lit("837P"), df("CLAIMLINEID"))
          .when(substring(df("CLM_TYPE"),1,4) === lit("837I"), df("ENCOUNTERID"))
          .otherwise(null))
    })
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("CLAIMID is not null and SERVICEDATE is not null and PATIENTID is not null")
    val cols = Engine.schema.getStringList("Claim").asScala.map(_.split("-")(0).toUpperCase())
    fil.select(cols.map(col): _*).distinct()
  }

}

//val es = new ClaimClaimservice(cfg); val clm = build(es,allColumns=true)
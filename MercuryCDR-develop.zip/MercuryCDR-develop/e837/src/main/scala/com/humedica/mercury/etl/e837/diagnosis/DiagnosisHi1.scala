package com.humedica.mercury.etl.e837.diagnosis

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import org.apache.spark.sql.DataFrame
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class DiagnosisHi1(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temphi:e837.temptable.TemptableTemphisegment"
  )

  columnSelect = Map(
    "temphi" -> List("CLM_TYPE","PATIENTID","ENCOUNTERID","LOCALCODE","CD_TIMESTAMP","PRIMARYDIAGNOSIS","LOCALADMITFLG"
      ,"POA_IND_F","SOURCEID","DX_CODETYPE","HOSP_DX_FLAG","CD_QUAL_FINAL")
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "DX_TIMESTAMP" -> mapFrom("CD_TIMESTAMP"),
    "LOCALDIAGNOSIS" -> mapFrom("LOCALCODE"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ENCOUNTERID" -> mapFrom("ENCOUNTERID"),
    "PRIMARYDIAGNOSIS" ->  mapFrom("PRIMARYDIAGNOSIS"),
    "LOCALADMITFLG" -> mapFrom("LOCALADMITFLG"),
    "MAPPEDDIAGNOSIS" -> mapFrom("LOCALCODE"), // TODO:  //formaticd9(localcode)
    "CODETYPE" -> mapFrom("DX_CODETYPE"),
    "LOCALPRESENTONADMISSION" -> mapFrom("POA_IND_F"),
    "HOSP_DX_FLAG" -> mapFrom("HOSP_DX_FLAG"),
    "SOURCEID" -> mapFrom("SOURCEID")
  )

  afterMap = (df: DataFrame) => {
    val fil = df.filter("CD_QUAL_FINAL = 'Dx' and DX_TIMESTAMP is not null")
    val cols = Engine.schema.getStringList("Diagnosis").asScala.map(_.split("-")(0).toUpperCase())
    fil.select(cols.map(col): _*)
      .distinct
  }
}

// val es = new DiagnosisHi1(cfg); val diag1 = build(es,allColumns=true)
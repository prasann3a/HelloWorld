package com.humedica.mercury.etl.e837.facility

import com.humedica.mercury.etl.core.engine.EntitySource
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.expressions.Window

class FacilityInpatient(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temptable:e837.temptable.TemptableTempclaim"
    ,"e837_loop_2010_n4"
  )

  columnSelect = Map(
    "temptable" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","FACILITYID","FACILITY_NM"),
    "e837_loop_2010_n4" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","R03","LOOP_QUALIFIER")
  )

  beforeJoin = Map(
    "temptable" -> ((df: DataFrame) => {
     df.coalesce(1000)
       .filter("FACILITYID is not null")

     }),
    "e837_loop_2010_n4" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("LOOP_QUALIFIER = 'AA'")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("temptable")
      .join(dfs("e837_loop_2010_n4"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX"), "left_outer")
  }

  afterJoin = (df: DataFrame) => {
    val groups1 = Window.partitionBy(df("FACILITYID"),df("FACILITY_NM"),df("R03"))
    val df1 = df.withColumn("cnt", count("*").over(groups1))

    val groups2 = Window.partitionBy(df1("FACILITYID")).orderBy(df1("cnt").desc_nulls_last)
    val rank1 = df1.withColumn("facnm_rnk", dense_rank.over(groups2))
      .withColumn("postalcd_rnk", dense_rank.over(groups2))

    val df2 = rank1.withColumn("fac_nm", when(rank1("facnm_rnk") === 1, rank1("FACILITY_NM")).otherwise(null))
      .withColumn("fac_postalcd", when(rank1("postalcd_rnk") === 1, rank1("R03")).otherwise(null))

    df2.groupBy(df2("FACILITYID"))
      .agg(min(df2("fac_nm")).as("FACILITY_NM"),
        min(df2("fac_postalcd")).as("FACILITYPOSTALCD")
      )
  }

  map = Map(
    "FACILITYID" -> mapFrom("FACILITYID"),
    "FACILITYNAME" -> mapFrom("FACILITY_NM"),
    "FACILITYPOSTALCD" -> mapFrom("FACILITYPOSTALCD")
  )

}

//val es = new FacilityInpatient(cfg); val fac = build(es,allColumns=true); fac.count()
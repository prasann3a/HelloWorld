package com.humedica.mercury.etl.e837.facility

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import com.humedica.mercury.etl.core.engine.Constants._

class FacilityProfessional(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "e837_loop_2310_nm1"
    ,"e837_loop_2010_n4"
    ,"facip:e837.facility.FacilityInpatient"
  )

  columnSelect = Map(
    "e837_loop_2310_nm1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_QUALIFIER","R02","R03","R09"),
    "e837_loop_2010_n4" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_QUALIFIER","R03"),
    "facip" -> List("GROUPID","CLIENT_DS_ID","FACILITYID")
  )

  beforeJoin = Map(
    "e837_loop_2310_nm1" -> ((df: DataFrame) => {
      df.filter("R09 is not null and LOOP_QUALIFIER = 'D' and R02 = '2'")
    }),
    "e837_loop_2010_n4" -> ((df: DataFrame) => {
      df.filter("LOOP_QUALIFIER = 'AA'")
        .withColumnRenamed("R03", "R03_zip")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("e837_loop_2310_nm1")
      .join(dfs("e837_loop_2010_n4"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX"), "left_outer")
  }

  afterJoin = (df: DataFrame) => {
    val df1 = df.groupBy(df("R09"),df("R03"),df("R03_zip")).count().withColumnRenamed("count","cnt")

    val groups2 = Window.partitionBy(df1("R09")).orderBy(df1("cnt").desc_nulls_last)
    val rank1 = df1.withColumn("facnm_rnk", dense_rank.over(groups2))
    val nm = rank1.withColumn("fac_nm", when(rank1("facnm_rnk") === 1, rank1("R03")).otherwise(null))

    nm.groupBy(nm("R09"))
      .agg(min(nm("fac_nm")).as("FACILITY_NM"),
        min(nm("R03_zip")).as("FACILITYPOSTALCD")
      )
  }

  map = Map(
    "FACILITYID" -> mapFrom("R09"),
    "FACILITYNAME" -> mapFrom("FACILITY_NM"),
    "FACILITYPOSTALCD" -> mapFrom("FACILITYPOSTALCD")
  )

  afterMap = (df: DataFrame) => {
    val zh_fac = table("facip")
      .withColumnRenamed("GROUPID","ZH_GROUPID")
      .withColumnRenamed("CLIENT_DS_ID","ZH_CLIENT_DS_ID")
      .filter("ZH_GROUPID = '" + config(GROUPID) + "' and ZH_CLIENT_DS_ID = '" + config(CLIENT_DS_ID) + "'")
      .withColumnRenamed("FACILITYID","ZH_FACILITYID")
    val join1 = df.join(zh_fac,df("FACILITYID") === zh_fac("ZH_FACILITYID"),"left_outer")
    join1.filter("ZH_FACILITYID is null")
  }

}

//val es = new FacilityProfessional(cfg); val fac = build(es,allColumns=true); fac.count()
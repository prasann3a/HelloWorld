package com.humedica.mercury.etl.e837.provider

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class ProviderClaim(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "tempservice:e837.temptable.TemptableTempservice",
    "temphi:e837.temptable.TemptableTemphisegment"
  )

  columnSelect = Map(
    "tempservice" -> List("CLM_TYPE","CLAIMID","PERFPROVID","PERFPROV_LAST","PERFPROV_FIRST","REFPROVID"
      ,"REFPROV_LAST","REFPROV_FIRST","ORDERINGPROVID","ORDERINGPROV_LAST","ORDERINGPROV_FIRST","RENDERINGPROVID"
      ,"RENDERINGPROV_LAST","RENDERINGPROV_FIRST"),
    "temphi" -> List("CLM_TYPE","PERFPROV_ID","PERFPROV_FIRST","PERFPROV_LAST")
  )

  beforeJoin = Map(
    "tempservice" -> ((df: DataFrame) => {
      val tbl1 = df.select("CLM_TYPE","CLAIMID","PERFPROVID","PERFPROV_LAST","PERFPROV_FIRST")
        .withColumnRenamed("PERFPROVID","PROVIDERID")
        .withColumnRenamed("PERFPROV_LAST","PROV_LAST")
        .withColumnRenamed("PERFPROV_FIRST","PROV_FIRST")
      val ser_tbl1 = tbl1
        .withColumn("NAME_CNT", approx_count_distinct(tbl1("CLAIMID")).over(Window.partitionBy(tbl1("PROVIDERID"),tbl1("PROV_LAST"),tbl1("PROV_FIRST"))))
        .select("PROVIDERID","PROV_FIRST","PROV_LAST","NAME_CNT")

      val tbl2 = table("tempservice").select("CLAIMID","REFPROVID","REFPROV_LAST","REFPROV_FIRST")
        .withColumnRenamed("REFPROVID","PROVIDERID")
        .withColumnRenamed("REFPROV_LAST","PROV_LAST")
        .withColumnRenamed("REFPROV_FIRST","PROV_FIRST")

      val ser_tbl2 = tbl2
        .withColumn("NAME_CNT", approx_count_distinct(tbl2("CLAIMID")).over(Window.partitionBy(tbl2("PROVIDERID"),tbl2("PROV_LAST"),tbl2("PROV_FIRST"))))
        .select("PROVIDERID","PROV_FIRST","PROV_LAST","NAME_CNT")

      val tbl3 = table("tempservice").select("CLAIMID","ORDERINGPROVID","ORDERINGPROV_LAST","ORDERINGPROV_FIRST")
        .withColumnRenamed("ORDERINGPROVID","PROVIDERID")
        .withColumnRenamed("ORDERINGPROV_LAST","PROV_LAST")
        .withColumnRenamed("ORDERINGPROV_FIRST","PROV_FIRST")

      val ser_tbl3 = tbl3
        .withColumn("NAME_CNT", approx_count_distinct(tbl3("CLAIMID")).over(Window.partitionBy(tbl3("PROVIDERID"),tbl3("PROV_LAST"),tbl3("PROV_FIRST"))))
        .select("PROVIDERID","PROV_FIRST","PROV_LAST","NAME_CNT")

      val tbl4 = table("tempservice").select("CLAIMID","RENDERINGPROVID","RENDERINGPROV_LAST","RENDERINGPROV_FIRST")
        .withColumnRenamed("RENDERINGPROVID","PROVIDERID")
        .withColumnRenamed("RENDERINGPROV_LAST","PROV_LAST")
        .withColumnRenamed("RENDERINGPROV_FIRST","PROV_FIRST")

      val ser_tbl4 = tbl4
        .withColumn("NAME_CNT", approx_count_distinct(tbl4("CLAIMID")).over(Window.partitionBy(tbl4("PROVIDERID"),tbl4("PROV_LAST"),tbl4("PROV_FIRST"))))
        .select("PROVIDERID","PROV_FIRST","PROV_LAST","NAME_CNT")

      val tbl5 = table("temphi").select("CLM_TYPE","PERFPROV_ID","PERFPROV_FIRST","PERFPROV_LAST")
        .withColumnRenamed("PERFPROV_ID","PROVIDERID")
        .withColumnRenamed("PERFPROV_LAST","PROV_LAST")
        .withColumnRenamed("PERFPROV_FIRST","PROV_FIRST")

      val hi_tbl = tbl5
        .withColumn("NAME_CNT", approx_count_distinct(tbl5("PROVIDERID")).over(Window.partitionBy(tbl5("PROVIDERID"),tbl5("PROV_LAST"),tbl5("PROV_FIRST"))))
        .select("PROVIDERID","PROV_FIRST","PROV_LAST","NAME_CNT")

      val uni = ser_tbl1.union(ser_tbl2).union(ser_tbl3).union(ser_tbl4).union(hi_tbl)
        .select("PROVIDERID","PROV_FIRST","PROV_LAST","NAME_CNT")

      val df1 = uni.withColumn("PFNAME", first(uni("PROV_FIRST")).over(Window.partitionBy(uni("PROVIDERID")).orderBy(uni("NAME_CNT").desc_nulls_last)))
        .withColumn("PLNAME", first(uni("PROV_LAST")).over(Window.partitionBy(uni("PROVIDERID")).orderBy(uni("NAME_CNT").desc_nulls_last)))
        .withColumn("prov_num", safe_to_number(uni("PROVIDERID")))
        .filter("length(PROVIDERID) = 10 and prov_num > 0")

      df1.groupBy(df1("PROVIDERID"))
        .agg(
          min(df1("PFNAME")).as("FIRST_NAME"),
          min(df1("PLNAME")).as("LAST_NAME")
        )
    })
  )

  join = noJoin()

  map = Map(
    "DATASRC" -> literal("service837"),
    "LOCALPROVIDERID" -> mapFrom("PROVIDERID"),
    "FIRST_NAME" -> mapFrom("FIRST_NAME"),
    "LAST_NAME" -> mapFrom("LAST_NAME"),
    "NPI" -> mapFrom("PROVIDERID")
  )

  afterMap = (df: DataFrame) => {
    df.filter("PROVIDERID is not null")
  }

}

//val es= new ProviderClaim(cfg); val pr = build(es,allColumns=true)
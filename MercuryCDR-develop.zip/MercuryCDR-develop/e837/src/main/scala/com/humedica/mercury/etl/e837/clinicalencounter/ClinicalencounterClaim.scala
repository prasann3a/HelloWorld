package com.humedica.mercury.etl.e837.clinicalencounter

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import com.humedica.mercury.etl.core.engine.Constants._

class ClinicalencounterClaim(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {

  tables = List(
    "temptable:e837.temptable.TemptableTempclaim"
    ,"e837_loop_2300_hi"
    ,"e837_loop_2300_cl1"
    ,"e837_loop_2400_sv2"
    ,"e837_loop_2400_dtp"
    ,"e837_loop_2310_nm1"
    ,"cdr.map_care_area"
  )

  columnSelect = Map(
    "temptable" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","MED_REC_NBR","CLM_TYPE","SUBISPAT","SUBMIT_DT","CLM_DT","MRN","ENC_ID","ADMIT_DT","CLM_START_DT"
      ,"DISCHARGE_DT","DISCHARGE_TM","CLM_END_DT","LOC_TYPE_CD","TOTAL_CHARGE","FACILITYID","BATCH_ID"),
    "e837_loop_2300_hi" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","R01_R01","R01_R02"),
    "e837_loop_2300_cl1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","R01","R02","R03"),
    "e837_loop_2400_sv2" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","LOOP_2400_IDX","SEGMENT_IDX","R01"),
    "e837_loop_2400_dtp" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","LOOP_2400_IDX","R01","R02","R03"),
    "e837_loop_2310_nm1" -> List("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
      ,"LOOP_2300_IDX","LOOP_QUALIFIER","R02","R09","BATCH_ID"),
  "cdr.map_care_area" -> List("GROUPID","LOCAL_CODE","CUI")
  )

  beforeJoin = Map(
    "temptable" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .withColumn("SUPRESS_DRGS", when(lit(config(CLIENT_DS_ID)).isin("2241","561","4825","7548","7549"), lit("Y"))
          .otherwise(lit("N")))
        .filter("MED_REC_NBR is not null and ENC_ID is not null and CLM_DT is not null")
    }),
    "e837_loop_2300_hi" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("R01_R01 = 'DR'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R01_R01","DRG_R01_R01")
        .withColumnRenamed("R01_R02","DRG_R01_R02")
    }),
    "e837_loop_2300_cl1" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R01","CL1_R01")
        .withColumnRenamed("R02","CL1_R02")
        .withColumnRenamed("R03","CL1_R03")
    }),
    "e837_loop_2400_sv2" -> ((df: DataFrame) => {
      val svctbl = df.coalesce(1000)
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumn("SVC_R01", lpad(df("R01"),4,"0"))

      val dtptbl = table("e837_loop_2400_dtp").coalesce(1000).filter("R01 = '472'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R01","DTP_R01")
        .withColumnRenamed("R02","DTP_R02")
        .withColumnRenamed("R03","DTP_R03")

      svctbl.join(dtptbl, Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX","LOOP_2400_IDX"), "left_outer")

    }),
    "e837_loop_2310_nm1" -> ((df: DataFrame) => {
      df.coalesce(1000)
        .filter("LOOP_QUALIFIER = 'D' and R02 = '2'")
        .withColumn("LOOP_2000C_IDX", expr("nvl(LOOP_2000C_IDX,'0')"))
        .withColumnRenamed("R02","CLMRENDPROV_R02")
        .withColumnRenamed("R09","CLMRENDPROV_R09")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("temptable")
      .join(dfs("e837_loop_2300_hi"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX"),"left_outer")
      .join(dfs("e837_loop_2300_cl1"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX"),"left_outer")
      .join(dfs("e837_loop_2400_sv2"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX"),"left_outer")
      .join(dfs("e837_loop_2310_nm1"), Seq("FILE_ID","DOC_IDX","INTERCHANGE_IDX","LOOP_2000A_IDX","LOOP_2000B_IDX","LOOP_2000C_IDX"
        ,"LOOP_2300_IDX","BATCH_ID"),"left_outer")
      .join(dfs("cdr.map_care_area"), lit(config(GROUP)) === dfs("cdr.map_care_area")("GROUPID")
        && dfs("e837_loop_2400_sv2")("SVC_R01") === dfs("cdr.map_care_area")("LOCAL_CODE"), "left_outer")
  }

  map = Map(
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "PATIENTID" -> mapFrom("MED_REC_NBR"),
    "ENCOUNTERID" -> mapFrom("ENC_ID"),
    "ARRIVALTIME" -> mapFrom("CLM_DT"),
    "ADMITTIME" -> cascadeFrom(Seq("ADMIT_DT","CLM_START_DT")),
    "DISCHARGETIME" -> ((col: String, df: DataFrame) => {
     val df1 = df.withColumn("DISCHARGE_DTTM", concat_ws("", coalesce(df("DISCHARGE_DT"),df("CLM_END_DT")), df("DISCHARGE_TM")))
      val len = df1.withColumn("lenAddm", datelengthcheck(df1("DISCHARGE_DTTM"), lit("yyyyMMddHHmm")))
      val df2 = len.withColumn("DISCHARGE_DTTM_1",
        when(length(len("DISCHARGE_DTTM")).lt(len("lenAddm")), expr("rpad(DISCHARGE_DTTM, lenAddm, '0')"))
          .when(length(len("DISCHARGE_DTTM")).gt(len("lenAddm")), expr("substr(DISCHARGE_DTTM, 0, lenAddm)"))
          .otherwise(len("DISCHARGE_DTTM")))

      df2.withColumn(col, to_timestamp(df2("DISCHARGE_DTTM_1"), "yyyyMMddHHmm"))
    }),
    "LOCALADMITSOURCE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("CL1_R01").isNull, df("CL1_R02"))
        .otherwise(concat_ws("",df("CL1_R01"),lit("_"),df("CL1_R02"))))
    }),
    "LOCALDRG" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUPRESS_DRGS") === lit("Y"), null)
        .when(length(df("DRG_R01_R02")) gt 3, null)
        .when(length(df("DRG_R01_R02")) lt 3, lpad(df("DRG_R01_R02"),3,"0"))
        .otherwise(df("DRG_R01_R02")))
    }),
    "LOCALDRGTYPE" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUPRESS_DRGS") === lit("Y"), null)
        .when(length(df("DRG_R01_R02")) === 3 && coalesce(date_format(df("SUBMIT_DT"),"yyyyMMdd"),date_format(df("CLM_DT"),"yyyyMMdd")).geq("20071001"), lit("MSDRG"))
        .when(length(df("DRG_R01_R02")) === 3 && coalesce(date_format(df("SUBMIT_DT"),"yyyyMMdd"),date_format(df("CLM_DT"),"yyyyMMdd")).leq("20071001"), lit("preMSDRG"))
        .otherwise(null))
    }),
    "APRDRG_CD" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUPRESS_DRGS") === lit("Y"), null)
        .when(length(df("DRG_R01_R02")).between(4,5), substring(df("DRG_R01_R02"),1,3))
        .otherwise(null))
    }),
    "APRDRG_SOI" -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("SUPRESS_DRGS") === lit("Y"), null)
        .when(length(df("DRG_R01_R02")) === 4, substring(df("DRG_R01_R02"),4,1))
        .otherwise(null))
    }),
    "APRDRG_ROM" -> nullValue(),
    "LOCALDISCHARGEDISPOSITION" -> mapFrom("CL1_R03"),
    "LOCALACCOUNTSTATUS" -> mapFrom("CL1_R03"),
    "TOTALCHARGE" -> mapFrom("TOTAL_CHARGE"),
    "FACILITYID" -> cascadeFrom(Seq("FACILITYID","CLMRENDPROV_R09"))
  )

  afterMap = (df: DataFrame) => {
    val pattype = df.withColumn("PATTYPE", when(df("SVC_R01").isin("0450","0451","0452","0456","0459","0516","0526","0760","0762")
      && lower(substring(df("CLM_TYPE"),4,1)) === lit("i") && df("CUI") === lit("CH000030"), lit("i.A13_OBS"))
      .when(df("SVC_R01").isin("0450", "0451","0452","0456","0459","0516","0526","0760","0762")
        && lower(substring(df("CLM_TYPE"),4,1)) === lit("i") && df("CUI") =!= lit("CH000030"), lit("i.A13_ED"))
      .otherwise(concat_ws("",lower(substring(df("CLM_TYPE"),4,1)),lit("."),df("LOC_TYPE_CD"))))

    val groups1 = Window.partitionBy(pattype("ENCOUNTERID"))
    val addcol1 = pattype.withColumn("PATIENTTYPE", max(pattype("PATTYPE")).over(groups1))
    val addcol2 = addcol1.withColumn("LOCALPATIENTTYPE", when(addcol1("PATTYPE").like("i.A13%"), addcol1("PATIENTTYPE"))
      .otherwise(addcol1("PATTYPE")))

    val groups = Window.partitionBy(addcol2("ENCOUNTERID")).orderBy(addcol2("ARRIVALTIME").asc_nulls_last)
    val addcol3 = addcol2.withColumn("rn", row_number.over(groups))
    addcol3.filter("rn = 1 and PATIENTID is not null and ENCOUNTERID is not null and ARRIVALTIME is not null")
  }

}


//val es = new ClinicalencounterClaim(cfg); val ce = build(es,allColumns=true).drop("ROW_SOURCE","MODIFIED_DATE")


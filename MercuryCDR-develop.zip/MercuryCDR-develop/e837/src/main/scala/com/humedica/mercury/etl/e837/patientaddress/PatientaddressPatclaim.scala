package com.humedica.mercury.etl.e837.patientaddress

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions.{standardizeZip, _}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame

class PatientaddressPatclaim(config: Map[String,String]) extends EntitySource(config: Map[String,String])  {

  tables = List(
    "temptable:e837.temptable.TemptableTemppatient"
  )

  columnSelect = Map(
    "temptable" -> List("PATIENTID","CLM_TYPE","FILE_ID","PAT_ADDR_1","PAT_ADDR_2","PAT_CITY","PAT_STATE","PAT_ZIP"
      ,"CLM_DT","SUBMIT_DT","SUB_ADDR_1","SUBISPAT")
  )

  map = Map(
    "PATIENTID" -> mapFrom("PATIENTID"),
    "DATASRC" -> mapFrom("CLM_TYPE"),
    "ADDRESS_DATE" -> cascadeFrom(Seq("CLM_DT","SUBMIT_DT")),
    "ADDRESS_LINE1" -> mapFrom("PAT_ADDR_1"),
    "ADDRESS_LINE2" -> mapFrom("PAT_ADDR_2"),
    "CITY" -> mapFrom("PAT_CITY"),
    "STATE" -> mapFrom("PAT_STATE"),
    "ZIPCODE" -> standardizeZip("PAT_ZIP",zip5=true)
  )

  afterMap = (df: DataFrame) => {
    val df1 = df.withColumn("addr_1",when(df("SUBISPAT") === lit(0), df("PAT_ADDR_1")).otherwise(df("SUB_ADDR_1")))
    val groups = Window.partitionBy(df1("PATIENTID"), df1("addr_1")).orderBy(df1("FILE_ID").desc_nulls_last)
    val addcol = df1.withColumn("rn", row_number.over(groups))
    addcol.filter("rn = 1 and PATIENTID is not null and coalesce(PAT_ADDR_1,PAT_ADDR_2,PAT_CITY,PAT_STATE,PAT_ZIP) is not null and (length(pat_state) = 2 or pat_state is null)").drop("rn", "addr_1")

  }
}

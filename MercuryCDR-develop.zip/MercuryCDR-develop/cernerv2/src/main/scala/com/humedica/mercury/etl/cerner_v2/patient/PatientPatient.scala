package com.humedica.mercury.etl.cerner_v2.patient

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


/**
  * Auto-generated on 08/09/2018
  */


class PatientPatient(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  cacheMe = true

  tables = List("person_alias", "patient:cerner_v2.patient.PatientTemptable","cdr.map_predicate_values",
    "clinicalenc:cerner_v2.clinicalencounter.ClinicalencounterEncounter"
  )

  columnSelect = Map(
    "person_alias" -> List("PERSON_ALIAS_TYPE_CD", "ALIAS_POOL_CD", "ALIAS", "PERSON_ID", "UPDT_DT_TM", "ACTIVE_IND", "END_EFFECTIVE_DT_TM", "PERSON_ALIAS_ID"),
    "patient" -> List("PERSON_ID", "BIRTH_DT_TM", "DECEASED_DT_TM", "UPDT_DT_TM", "NAME_FIRST", "NAME_LAST", "NAME_MIDDLE", "SPECIES_CD", "NAME_FULL_FORMATTED", "ACTIVE_IND"),
    "clinicalenc" ->  List("PATIENTID")
  )

  beforeJoin = Map(
    "patient" -> ((df: DataFrame) => {
      val df1 = df.withColumn("inactive_patient_flag",when(df("ACTIVE_IND") === lit("0"),lit("Y"))
        .otherwise( lit("N")))

      df1.withColumnRenamed("UPDT_DT_TM", "update_date")
    }),
    "person_alias" -> ((df: DataFrame) => {
      val list_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val list_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_rmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val list_rmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_ptoly_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT_ONLY", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val list_ptoly_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT_ONLY", "PERSON_ALIAS", "ALIAS_POOL_CD")

      val groups = Window.partitionBy(df("person_alias_id"))
        .orderBy(df("UPDT_DT_TM").desc_nulls_last, df("active_ind").desc_nulls_last)
      val addColumn1 = df.withColumn("alias_row", row_number.over(groups))

      val df1 = addColumn1.filter("alias_row = 1")

      val fil = df1.filter("end_effective_dt_tm > current_date()")
      val fil1 = fil.filter(fil("person_alias_type_cd").isin(list_person_alias_type_cd: _*) || fil("alias_pool_cd").isin(list_alias_pool_cd: _*) || fil("person_alias_type_cd").isin(list_ptoly_person_alias_type_cd: _*) || fil("alias_pool_cd").isin(list_ptoly_alias_pool_cd: _*))
      val fil2 = fil.filter(fil("person_alias_type_cd").isin(list_rmrn_person_alias_type_cd: _*) && fil("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*))
      val df2 = fil1.union(fil2)

      val groups1 = Window.partitionBy(df2("person_id"))
        .orderBy(df2("UPDT_DT_TM").desc_nulls_last, df2("active_ind").desc_nulls_last)
      val addColumn2 = df2.withColumn("rwnum_id", row_number.over(groups1))

      val df3 = addColumn2.filter("rwnum_id = 1")


      val df4 = df3.withColumn("MRN",
        when(df3("ACTIVE_IND") === lit("1") &&
            (df3("PERSON_ALIAS_TYPE_CD").isin(list_person_alias_type_cd: _*) || df3("ALIAS_POOL_CD").isin(list_alias_pool_cd: _*) || df3("person_alias_type_cd").isin(list_ptoly_person_alias_type_cd: _*) || df3("alias_pool_cd").isin(list_ptoly_alias_pool_cd: _*)),
          df3("ALIAS"))
          .otherwise(null))
        .withColumn("RMRN", when(df3("ACTIVE_IND") === lit("1") &&
          df3("PERSON_ALIAS_TYPE_CD").isin(list_rmrn_person_alias_type_cd: _*) &&
          df3("ALIAS_POOL_CD").isin(list_rmrn_alias_pool_cd: _*),
          df3("ALIAS"))
          .otherwise(null))

      df4.withColumnRenamed("UPDT_DT_TM", "pa_update_date").withColumnRenamed("ACTIVE_IND","PA_ACTIVE_IND")
    }),
    "clinicalenc" -> ((df: DataFrame) => {
      df.select("PATIENTID").distinct
        .withColumnRenamed("PATIENTID","PATIENTID_ENC")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("patient")
      .join(dfs("person_alias"), Seq("PERSON_ID"), "left_outer")
      .join(dfs("clinicalenc"), dfs("clinicalenc")("PATIENTID_ENC") === dfs("patient")("PERSON_ID"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("patient"),
    "PATIENTID" -> mapFrom("PERSON_ID"),
    "DATEOFBIRTH" -> ((col: String, df: DataFrame) => {
      val groups = Window.partitionBy(df("PERSON_ID"))
        .orderBy(when(df("BIRTH_DT_TM").isNotNull, lit("1")).otherwise(lit("0")).desc, df("update_date").desc_nulls_last)
      df.withColumn(col, first(df("BIRTH_DT_TM"), ignoreNulls = true).over(groups))
    }),
    "DATEOFDEATH" -> ((col: String, df: DataFrame) => {
      val groups = Window.partitionBy(df("PERSON_ID"))
        .orderBy(df("update_date").asc_nulls_first)
        .rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
      df.withColumn(col, last(df("DECEASED_DT_TM")).over(groups))
    }),
    "MEDICALRECORDNUMBER" -> ((col: String, df: DataFrame) => {
      val groups = Window.partitionBy(df("PERSON_ID"))
        .orderBy(df("pa_update_date").desc_nulls_last, df("PA_ACTIVE_IND").desc_nulls_last, when(df("MRN").isNotNull, lit("1")).otherwise(lit("0")).desc)
      df.withColumn(col, first(df("MRN"), ignoreNulls = true).over(groups))
    }),
    "INACTIVE_FLAG" -> ((col: String, df: DataFrame) => {
      val groups = Window.partitionBy(df("PERSON_ID"))
        .orderBy(df("update_date").desc_nulls_last, df("ACTIVE_IND").desc_nulls_last, when(df("INACTIVE_PATIENT_FLAG").isNotNull, lit("1")).otherwise(lit("0")).desc)
      df.withColumn(col, first(df("INACTIVE_PATIENT_FLAG"), ignoreNulls = true).over(groups))
    })

  )

  afterMap = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PATIENTID")).orderBy(df("update_date").desc_nulls_last)
    df.withColumn("rn", row_number.over(groups))
      .filter("rn = 1 and patientid is not null")
      .drop("rn")
  }

  mapExceptions = Map(
    (Seq("H984197_CR2", "H984945_CR2"), "MEDICALRECORDNUMBER") -> ((col: String, df: DataFrame) => {
      val groups = Window.partitionBy(df("PERSON_ID"))
        .orderBy(df("pa_update_date").desc_nulls_last, df("PA_ACTIVE_IND").desc_nulls_last, when(df("RMRN").isNotNull, lit("1")).otherwise(lit("0")).desc)
      df.withColumn(col, first(df("RMRN"), ignoreNulls = true).over(groups))
    }),
    (Seq("H984197_CR2",
      "H984442_CR2",
      "H984474_CR_ONECHRT_FLPEN",
      "H984474_CR_ONECHRT_ALMOB",
      "H984728_CERNER_ONECHART",
      "H984926_CR2_MIDET_V1",
      "H984926_CR2_MIKAL",
      "H984164_CR2",
      "H984186_CR2",
      "H984531_CR2",
      "H984787_CR2",
      "H_993_CR2",
      "H984216_MIROC_CERNER_V1"),"PATIENTID") -> ((col: String, df: DataFrame) => {
      df.withColumn(col, when(df("PATIENTID_ENC").isNotNull, df("PERSON_ID")).otherwise(null))
    })
  )

}
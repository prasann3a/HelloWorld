package com.humedica.mercury.etl.cerner_v2.immunization

import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class ImmunizationImmunizationmodifiercustom(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("pneumovac"
    ,"immunization:cerner_v2.immunization.ImmunizationImmunizationmodifier"
    ,"patientidentifierencalias:cerner_v2.patientidentifier.PatientidentifierEncalias"
    ,"patientidentifierpatient:cerner_v2.patientidentifier.PatientidentifierPatient"
  )

  columnSelect = Map(
    "pneumovac" -> List("MRN", "EVENT_CD", "VACCINATION_DATE")
  )

  beforeJoin = Map(
    "pneumovac" -> ((df: DataFrame) => {
      df.withColumnRenamed("EVENT_CD", "LOCALIMMUNIZATIONCD")
        .withColumn("ADMINDATE", df("VACCINATION_DATE"))
        .withColumn("DOCUMENTEDDATE", df("VACCINATION_DATE"))
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val pat = dfs("patientidentifierencalias").union(dfs("patientidentifierpatient")).filter("idtype = 'MRN'")
    dfs("pneumovac")
      .join(pat, dfs("pneumovac")("MRN") === pat("idvalue"), "inner")
      .join(dfs("immunization"), Seq("patientid", "localimmunizationcd", "admindate"), "left_anti")
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("MRN"), df("LOCALIMMUNIZATIONCD"), df("VACCINATION_DATE"), df("patientid")).orderBy(lit(1))
    val addColumn = df.withColumn("rn", row_number.over(groups))
    addColumn.filter("rn = 1").drop("rn")
  }

  map = Map(
    "DATASRC" -> literal("immunization_modifier"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "LOCALIMMUNIZATIONCD" -> mapFrom("LOCALIMMUNIZATIONCD"),
    "ADMINDATE" -> mapFrom("ADMINDATE"),
    "DOCUMENTEDDATE" -> mapFrom("DOCUMENTEDDATE"),
    "ENCOUNTERID" -> nullValue(),
    "LOCALIMMUNIZATIONDESC" -> nullValue(),
    "LOCALNDC" -> nullValue()
  )
}
package com.humedica.mercury.etl.cerner_v2.patientidentifier

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

class PatientidentifierEncalias(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("enc_alias", "clinicalenc:cerner_v2.clinicalencounter.ClinicalencounterTemptable", "cdr.map_predicate_values")

  columnSelect = Map(
    "enc_alias" -> List("ALIAS","ENCNTR_ID","ALIAS_POOL_CD","ENCNTR_ALIAS_TYPE_CD","ENCNTR_ALIAS_ID","ACTIVE_IND","UPDT_DT_TM","BEG_EFFECTIVE_DT_TM","END_EFFECTIVE_DT_TM"),
    "clinicalenc" -> List("PERSON_ID","ENCNTR_ID","ACTIVE_IND","UPDT_DT_TM","ORGANIZATION_ID"),
    "cdr.map_predicate_values" -> List("GROUPID", "CLIENT_DS_ID", "DATA_SRC", "ENTITY", "TABLE_NAME", "COLUMN_NAME", "COLUMN_VALUE")
  )

  beforeJoin = Map(
    "enc_alias" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("ENCNTR_ALIAS_ID")).orderBy(df("UPDT_DT_TM").desc_nulls_last)
      df.withColumn("rn", row_number.over(groups)).filter("rn=1").drop("rn")
      val list_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "ENC_ALIAS", "PATIENT_ID", "ENC_ALIAS", "ENCNTR_ALIAS_TYPE_CD")
      val list_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "ENC_ALIAS", "PATIENT_ID", "ENC_ALIAS", "ALIAS_POOL_CD")
      val df2 = df.filter(df("alias_pool_cd").isin(list_alias_pool_cd: _*) || df("encntr_alias_type_cd").isin(list_alias_type_cd: _*))
      df2.filter("active_ind = '1' and end_effective_dt_tm > current_date()")
        .withColumnRenamed("ENCNTR_ID","ENCNTR_ID_EA")
        .withColumnRenamed("UPDT_DT_TM","UPDT_DT_TM_EA")
    }),
    "clinicalenc" -> ((df: DataFrame) => {
      val list_encntr_type_cd = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "ENCOUNTER", "CLINICALENCOUNTER", "ENCOUNTER", "ENCNTR_TYPE_CD")
      df.filter("rownumber = 1 and arrivaltime is not null and active_ind <> '0' and (reason_for_visit is null or reason_for_visit not in ('CANCELLED', 'NO SHOW')) " +
        "and (encntr_type_cd is null or encntr_type_cd not in (" + list_encntr_type_cd + "))")
    }),
    "cdr.map_predicate_values" -> ((df: DataFrame) => {
      val fil = df.filter("GROUPID = '" + config(GROUP) + "' AND DATA_SRC = 'CERNER' AND ENTITY = 'APPLY_ORG_ID_FILTER' AND TABLE_NAME = 'ENCOUNTER.ORGANIZATION_ID' AND CLIENT_DS_ID = '" + config(CLIENT_DS_ID) + "'")
      fil.select("CLIENT_DS_ID","COLUMN_VALUE","COLUMN_NAME")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val encJoinType = lookupList(readTable("cdr.map_predicate_values", config).where("GROUPID='" + config(GROUP) + "' AND CLIENT_DS_ID='" + config(CLIENT_DS_ID) + "' AND DATA_SRC = 'CERNER' AND ENTITY = 'APPLY_ORG_ID_FILTER' AND TABLE_NAME = 'ENCOUNTER.ORGANIZATION_ID'"), "1=1", "COLUMN_VALUE")
    val joinType = if(encJoinType.isEmpty){"left_outer"} else{"inner"}
    dfs("enc_alias")
      .join(dfs("clinicalenc"), dfs("clinicalenc")("ENCNTR_ID") === dfs("enc_alias")("ENCNTR_ID_EA"), "inner")
      .join(dfs("cdr.map_predicate_values"), dfs("clinicalenc")("ORGANIZATION_ID") === dfs("cdr.map_predicate_values")("COLUMN_VALUE"), joinType)
  }

  afterJoin = (df: DataFrame) => {
    val groups = Window.partitionBy(df("PERSON_ID"), df("ALIAS_POOL_CD")).orderBy(df("BEG_EFFECTIVE_DT_TM").asc_nulls_last,df("UPDT_DT_TM_EA").desc_nulls_last)
    val addColumn = df.withColumn("rn", row_number.over(groups))
    addColumn.filter("rn = 1").drop("rn")
    .select("PERSON_ID", "ALIAS", "COLUMN_NAME").distinct
  }

  map = Map(
    "DATASRC" -> literal("enc_alias"),
    "PATIENTID" -> mapFrom("PERSON_ID"),
    "IDTYPE" -> literal("MRN"),
    "IDVALUE" -> mapFrom("ALIAS"),
    "ID_SUBTYPE" -> mapFrom("COLUMN_NAME")
  )

  afterMap = includeIf("patientid is not null and idvalue is not null")
}
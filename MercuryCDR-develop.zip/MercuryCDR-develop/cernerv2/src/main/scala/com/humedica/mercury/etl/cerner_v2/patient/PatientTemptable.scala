package com.humedica.mercury.etl.cerner_v2.patient

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


class PatientTemptable(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  cacheMe = true

  tables = List("person")

  columns = List("PERSON_ID", "BIRTH_DT_TM", "DECEASED_DT_TM", "UPDT_DT_TM", "NAME_FIRST", "NAME_LAST", "NAME_MIDDLE", "SPECIES_CD", "NAME_FULL_FORMATTED", "ACTIVE_IND", "temppat_rn")

  columnSelect = Map(
    "person" -> List("PERSON_ID", "BIRTH_DT_TM", "DECEASED_DT_TM", "UPDT_DT_TM", "NAME_FIRST", "NAME_LAST", "NAME_MIDDLE", "SPECIES_CD", "NAME_FULL_FORMATTED", "ACTIVE_IND")
  )

  beforeJoin = Map(
    "person" -> ((df: DataFrame) => {
      val df1 = df.filter(
        "not (LOWER(name_last) LIKE 'zz%' OR (LOWER(name_full_formatted) LIKE '%patient%' " +
          " AND LOWER(name_full_formatted) LIKE '%test%'))" +
          "  and person_id is not null")

      val groups = Window.partitionBy(df("PERSON_ID")).orderBy(df("UPDT_DT_TM").desc_nulls_last)
      df1.withColumn("temppat_rn", row_number.over(groups)) //.filter("temppat_rn=1").drop("rn")
    })
  )
}
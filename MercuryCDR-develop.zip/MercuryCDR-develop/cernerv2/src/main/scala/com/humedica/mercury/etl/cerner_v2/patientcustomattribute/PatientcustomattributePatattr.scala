package com.humedica.mercury.etl.cerner_v2.patientcustomattribute

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class PatientcustomattributePatattr(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {

  tables = List("patattr")

  columnSelect = Map(
    "patattr" -> List("PATIENTID", "ATTRIBUTE_VALUE", "ATTRIBUTE_NUMBER", "UPDATE_DATE")
  )

  afterJoin = (df: DataFrame) => {
    val patientidParition = Window.partitionBy(df("PATIENTID"))
      .orderBy(df("UPDATE_DATE").desc_nulls_last)

    val dfAfterRownumberFilter = df.withColumn("rn", row_number.over(patientidParition))
      .filter("rn = 1")

    dfAfterRownumberFilter
      .withColumn("ATTRIBUTE_TYPE_CUI", expr(
        """
          |CASE ATTRIBUTE_NUMBER
          |		WHEN '1' THEN 'CH002785'
          |		WHEN '2' THEN 'CH002786'
          |		WHEN '3' THEN 'CH002787'
          |		WHEN '4' THEN 'CH002788'
          |		WHEN '5' THEN 'CH002949'
          |		WHEN '6' THEN 'CH002950' ELSE NULL END
        """.stripMargin)
      )
      .filter("PATIENTID is not null")
      .filter("ATTRIBUTE_TYPE_CUI is not null")
  }


  map = Map(
    "DATASRC" -> literal("patattr"),
    "PATIENTID" -> mapFrom("PATIENTID"),
    "ATTRIBUTE_VALUE" -> mapFrom("ATTRIBUTE_VALUE"),
    "EFF_DATE" -> mapFrom("UPDATE_DATE"),
    "ATTRIBUTE_TYPE_CUI" -> mapFrom("ATTRIBUTE_TYPE_CUI")
  )

  afterMap = (df: DataFrame) => {
    val cols = Engine.schema.getStringList("Patientcustomattribute").asScala.map(_.split("-")(0).toUpperCase())
    df.select(cols.map(col): _*).distinct()
  }
}

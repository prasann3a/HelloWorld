package com.humedica.mercury.etl.cerner_v2.medicationmapsrc

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcCemedresult(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "ce_med_result",
    "clinical_event",
    "zh_code_value",
    "zh_order_catalog_item_r",
    "zh_med_identifier",
    "cdr.map_predicate_values"
  )

  columnSelect = Map(
    "ce_med_result" -> List("EVENT_ID"),
    "clinical_event" -> List("EVENT_CD", "EVENT_ID", "CATALOG_CD", "EVENT_CLASS_CD"),
    "zh_code_value" -> List("DESCRIPTION", "CODE_VALUE"),
    "zh_order_catalog_item_r" -> List("CATALOG_CD", "ITEM_ID"),
    "zh_med_identifier" -> List("VALUE_KEY", "ITEM_ID")
  )

  beforeJoin = Map(
    "clinical_event" -> ((df: DataFrame) => {
      val list_event_class_cd = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "IMMUNIZATION_MODIFIER",
        "IMMUNIZATION", "CLINICAL_EVENT", "EVENT_CLASS_CD")
      df.filter("EVENT_CLASS_CD in (" + list_event_class_cd + ")" +
                "AND EVENT_CD is NOT NULL")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("ce_med_result").join(table("clinical_event"), Seq("EVENT_ID"), "inner")
      .join(table("zh_code_value"), table("zh_code_value")("CODE_VALUE") === table("clinical_event")("EVENT_CD"), "left_outer")
      .join(table("zh_order_catalog_item_r"), Seq("CATALOG_CD"), "left_outer")
      .join(table("zh_med_identifier"), Seq("ITEM_ID"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("ce_med_result"),
    "LOCALMEDCODE" -> ((col:String, df:DataFrame) => df.withColumn(col, substring(df("EVENT_CD"),1,100))),
    "LOCALDESCRIPTION" -> mapFrom("DESCRIPTION"),
    "LOCALNDC" -> ((col:String, df:DataFrame) => df.withColumn(col, substring(df("VALUE_KEY"),1,11)))
  )

  afterMap = (df: DataFrame) => {
    val group_df = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALDESCRIPTION"), df("LOCALNDC"))
    val df1 = df.withColumn("NO_NDC", sum(when(df("LOCALNDC").isNull, 1).otherwise(0)).over(group_df))
      .withColumn("HAS_NDC", sum(when(df("LOCALNDC").isNull, 0).otherwise(1)).over(group_df))
      .withColumn("NUM_RECS", count(lit(1)).over(group_df))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcCemedresult(cfg); val med_s = build(a, allColumns = true) ;

package com.humedica.mercury.etl.cerner_v2.medicationmapsrc

import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcAllergy(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "allergy",
    "zh_nomenclature"
  )

  columnSelect = Map(
    "allergy" -> List("SUBSTANCE_NOM_ID", "SUBSTANCE_FTDESC", "ONSET_DT_TM", "REACTION_STATUS_DT_TM", "UPDT_DT_TM", "CANCEL_REASON_CD"),
    "zh_nomenclature" -> List("SOURCE_STRING_KEYCAP", "NOMENCLATURE_ID")
  )

  beforeJoin = Map(
    "allergy" -> ((df: DataFrame) => {
      val can_reason_fil = df.filter("CANCEL_REASON_CD = '0'")
      val add_column_df = can_reason_fil.withColumn("LOCALMEDCODE", when(can_reason_fil("SUBSTANCE_NOM_ID") === 0 or can_reason_fil("SUBSTANCE_NOM_ID").isNull, can_reason_fil("SUBSTANCE_FTDESC"))
                                          .otherwise(can_reason_fil("SUBSTANCE_NOM_ID")))

      val groups = Window.partitionBy(add_column_df("LOCALMEDCODE"), coalesce(add_column_df("ONSET_DT_TM"), add_column_df("REACTION_STATUS_DT_TM")))
                         .orderBy(add_column_df("UPDT_DT_TM").desc_nulls_last)
      val rn = add_column_df.withColumn("rn", row_number.over(groups))

      rn.filter("LOCALMEDCODE IS NOT NULL AND rn = 1").drop("rn")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    dfs("allergy").join(dfs("zh_nomenclature"), dfs("allergy")("SUBSTANCE_NOM_ID") === dfs("zh_nomenclature")("NOMENCLATURE_ID"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("allergy"),
    "LOCALMEDCODE" -> ((col, df) => df.withColumn(col, trim(substring(df("LOCALMEDCODE"),1,100)))),
    "LOCALNDC" -> nullValue(),
    "LOCALGENERIC" -> nullValue(),
    "NDC_SRC" -> literal("src"),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, coalesce(df("SOURCE_STRING_KEYCAP"), df("SUBSTANCE_FTDESC"))))
  )

  afterMap = (df: DataFrame) => {
    val group_df = Window.partitionBy(df("DATASRC"), df("LOCALMEDCODE"), df("LOCALDESCRIPTION"))
    val df1 = df.withColumn("NO_NDC", count("*").over(group_df))
                .withColumn("HAS_NDC", lit(0))
                .withColumn("NUM_RECS", count("*").over(group_df))

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}
//val a = new MedicationmapsrcAllergy(cfg); val med_s = build(a, allColumns = true) ;

package com.humedica.mercury.etl.cerner_v2.patientidentifier

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.EntitySource
import com.humedica.mercury.etl.core.engine.Functions.{mpvList1, _}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


/**
  * Auto-generated on 08/09/2018
  */


class PatientidentifierPatient(config: Map[String, String]) extends EntitySource(config: Map[String, String]) {
  tables = List("person_alias",
    "person",
    "cdr.map_predicate_values",
    "patient:cerner_v2.patient.PatientPatient",
    "clinicalenc:cerner_v2.clinicalencounter.ClinicalencounterTemptable",
    "enc_alias")

  columnSelect = Map(
    "person_alias" -> List("person_alias_type_cd", "alias_pool_cd", "ALIAS", "person_id", "UPDT_DT_TM", "active_ind", "end_effective_dt_tm","beg_effective_dt_tm"),
    "person" -> List("NATIONALITY_CD", "PERSON_ID", "BIRTH_DT_TM", "DECEASED_DT_TM", "UPDT_DT_TM",
      "DECEASED_CD", "ETHNIC_GRP_CD", "NAME_FIRST", "SEX_CD", "religion_cd",
      "LANGUAGE_CD", "NAME_LAST", "MARITAL_TYPE_CD", "NAME_MIDDLE", "RACE_CD"),
    "patient" -> List("PATIENTID", "MEDICALRECORDNUMBER"),
    "enc_alias" -> List("ALIAS","ENCNTR_ID","ENCNTR_ALIAS_TYPE_CD","ENCNTR_ALIAS_ID","ACTIVE_IND","UPDT_DT_TM"),
    "clinicalenc" ->  List("PERSON_ID","ENCNTR_ID")

  )


  beforeJoin = Map(
    "person" -> ((df: DataFrame) => {
      val df1 = df.filter(
        "not (LOWER(name_last) LIKE 'zz%' OR (LOWER(name_full_formatted) LIKE '%patient%' " +
          " AND LOWER(name_full_formatted) LIKE '%test%'))" +
          "  and person_id is not null")
      df1.withColumnRenamed("UPDT_DT_TM", "update_date")

    }),
    "enc_alias" -> ((df: DataFrame) => {
      val groups = Window.partitionBy(df("ENCNTR_ALIAS_ID")).orderBy(df("UPDT_DT_TM").desc_nulls_last)
      df.withColumn("rn", row_number.over(groups)).filter("rn=1").drop("rn")
        .withColumnRenamed("ALIAS","ALIAS_ENC")
        .withColumnRenamed("ENCNTR_ID","ENCNTR_ID_ENC")
        .withColumnRenamed("ACTIVE_IND","ACTIVE_IND_ENC")
        .withColumnRenamed("UPDT_DT_TM","UPDT_DT_TM_ENC")
    }),
   "clinicalenc" -> ((df: DataFrame) => {
     df.withColumnRenamed("PERSON_ID","PERSON_ID_ENCNTR")
      .withColumnRenamed("ENCNTR_ID","ENCNTR_ID_ENCNTR")
  }),
    "person_alias" -> ((df: DataFrame) => {

      val list_cmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CMRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val list_ssn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val list_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val list_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_rmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val list_rmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_hicn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "HICN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")


      val list1 = list_cmrn_person_alias_type_cd ::: list_ssn_person_alias_type_cd ::: list_person_alias_type_cd ::: list_hicn_person_alias_type_cd


      val fil1 = df.filter(df("person_alias_type_cd").isin(list1: _*) || df("alias_pool_cd").isin(list_alias_pool_cd: _*))
      val fil2 = df.filter(df("person_alias_type_cd").isin(list_rmrn_person_alias_type_cd: _*) && df("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*))
      val fil3 = fil1.union(fil2)


      val groups = Window.partitionBy(fil3("person_id"), fil3("person_alias_type_cd"), fil3("alias")).orderBy(fil3("UPDT_DT_TM").desc, fil3("active_ind").desc)
      val fil4 = fil3.withColumn("alias_row", row_number.over(groups))
      val fil5 = fil4.filter("alias_row = 1")

      val fil6 = fil5.filter(" end_effective_dt_tm > current_date() ")

      val groups1 = Window.partitionBy(fil6("person_id"), fil6("person_alias_type_cd")).orderBy(fil6("UPDT_DT_TM").desc, fil6("active_ind").desc).rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
      val addColumn1 = fil6.withColumn("active_patient_flag", first("active_ind").over(groups1))
      addColumn1.withColumnRenamed("UPDT_DT_TM", "pa_update_date")


    }
      ))

  join = (dfs: Map[String, DataFrame]) => {
    dfs("person")
      .join(dfs("person_alias"), Seq("PERSON_ID"), "left_outer")
      .join(dfs("patient"), dfs("person")("PERSON_ID") === dfs("patient")("patientid"), "inner")

  }


  joinExceptions = Map(
    "H743123_CR2" -> ((dfs: Map[String, DataFrame]) => {

     dfs("person")
        .join(dfs("person_alias"), Seq("PERSON_ID"), "left_outer")
        .join(dfs("patient"), dfs("person")("PERSON_ID") === dfs("patient")("patientid"), "left_outer")
        .join(dfs("clinicalenc"),  dfs("person")("PERSON_ID") === dfs("clinicalenc")("PERSON_ID_ENCNTR"), "left_outer")
        .join(dfs("enc_alias"), dfs("clinicalenc")("ENCNTR_ID_ENCNTR") === dfs("enc_alias")("ENCNTR_ID_ENC"), "left_outer")

       })
  )

  afterJoin = (df: DataFrame) => {


    val list_rmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
    val list_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "ALIAS_POOL_CD")
    val list_cmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CMRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
    val list_cmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CMRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
    val list_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
    val df_active = df.filter(" active_ind = '1' and active_patient_flag = '1' ")
      .withColumn("ID_SUBTYPE",
        when(df("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*), lit("MRN"))
          .when(df("alias_pool_cd").isin(list_cmrn_alias_pool_cd: _*), lit("CMRN"))
          .otherwise(null))



    val list_ssn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
    val df1 = df_active.withColumn("SSN", when(df_active("person_alias_type_cd").isin(list_ssn_person_alias_type_cd: _*), df_active("alias")))
    val groups1 = Window.partitionBy(df1("PERSON_ID"), df1("person_alias_type_cd")).orderBy(df1("pa_update_date").desc)
    val df2 = df1.withColumn("ssn_row", row_number.over(groups1))
    val df3 = df2.filter("ssn_row = 1 ")
    val satSSN = standardizeSSN("SSN")

    val ssn_inclusion = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN_INCLUSION", "PATIENT_ID", "PERSON_ALIAS", "MEDICALRECORDNUMBER_NOT_NULL")
    val dfSSN1 = satSSN("SSN", df3)
    val dfSSN2 = if(ssn_inclusion == "'Y'") dfSSN1.filter("SSN is not null and MEDICALRECORDNUMBER IS NOT NULL") else dfSSN1.filter("SSN is not null")
    val dfSSN = dfSSN2.withColumn("IDTYPE", lit("SSN")).withColumnRenamed("SSN", "IDVALUE")
      .select("PERSON_ID","idtype","idvalue", "id_subtype")



    val df5 = df_active.withColumn("idvalue", when(df_active("person_alias_type_cd").isin(list_person_alias_type_cd: _*), df_active("alias")))
    val df6 = df_active.withColumn("idvalue", when(df_active("alias_pool_cd").isin(list_alias_pool_cd: _*), df_active("alias")))
    val df7 = df5.union(df6)
    val df8 = df7.withColumn("idtype", lit("MRN"))
    val groups2 = Window.partitionBy(df8("PERSON_ID"), df8("idvalue")).orderBy(df8("pa_update_date").desc)
    val df9 = df8.withColumn("mrn_row", row_number.over(groups2))
    val dfMRN = df9.filter("mrn_row = 1 and idvalue is not null ")
      .select("PERSON_ID","idtype","idvalue", "id_subtype")



    val df10 = df_active.withColumn("idtype", lit("MRN"))
    val list_rmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
    val df11 = df10.withColumn("idvalue", when(df10("person_alias_type_cd").isin(list_rmrn_person_alias_type_cd: _*) && df10("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*), df10("alias")))
    val groups3 = Window.partitionBy(df11("PERSON_ID"), df11("idvalue")).orderBy(df11("pa_update_date").desc)
    val df12 = df11.withColumn("rmrn_row", row_number.over(groups3))
    val dfRMRN = df12.filter("rmrn_row = 1 and idvalue is not null ")
      .select("PERSON_ID","idtype","idvalue", "id_subtype")

    val df13 = df_active.withColumn("idtype",lit("HICN"))
    val list_hicn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "HICN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
    val df14 = df13.withColumn("idvalue", when(df13("person_alias_type_cd").isin(list_hicn_person_alias_type_cd: _*), df13("alias")))
    val groups4 = Window.partitionBy(df14("PERSON_ID"), df14("idvalue")).orderBy(df14("pa_update_date").desc)
    val df15 = df14.withColumn("hicn_row", row_number.over(groups4))
    val dfHICN = df15.filter("hicn_row = 1 and idvalue is not null")
      .select("PERSON_ID","idtype","idvalue", "id_subtype")

    dfSSN.union(dfMRN).union(dfRMRN).union(dfHICN)
  }

  afterJoinExceptions = Map(
    "H984197_CR2" -> ((df: DataFrame) => {


      val list_rmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_cmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CMRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val list_cmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CMRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val df_active = df.filter(" active_ind = '1' and active_patient_flag = '1' ")
        .withColumn("ID_SUBTYPE",
          when(df("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*), lit("MRN"))
            .when(df("alias_pool_cd").isin(list_cmrn_alias_pool_cd: _*), lit("CMRN"))
            .otherwise(null))



      val list_ssn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val df1 = df_active.withColumn("SSN", when(df_active("person_alias_type_cd").isin(list_ssn_person_alias_type_cd: _*), df_active("alias")))
      val groups1 = Window.partitionBy(df1("PERSON_ID"), df1("person_alias_type_cd")).orderBy(df1("pa_update_date").desc)
      val df2 = df1.withColumn("ssn_row", row_number.over(groups1))
      val df3 = df2.filter("ssn_row = 1 ")
      val satSSN = standardizeSSN("SSN")
      val ssn_inclusion = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN_INCLUSION", "PATIENT_ID", "PERSON_ALIAS", "MEDICALRECORDNUMBER_NOT_NULL")
      val dfSSN1 = satSSN("SSN", df3)
      val dfSSN2 = if(ssn_inclusion == "'Y'") dfSSN1.filter("SSN is not null and MEDICALRECORDNUMBER IS NOT NULL") else dfSSN1.filter("SSN is not null")
      val dfSSN = dfSSN2.withColumn("IDTYPE", lit("SSN")).withColumnRenamed("SSN", "IDVALUE")
        .select("PERSON_ID","idtype","idvalue", "id_subtype")

      val df5 = df_active.withColumn("idvalue", when(df_active("person_alias_type_cd").isin(list_person_alias_type_cd: _*), df_active("alias")))
      val df6 = df_active.withColumn("idvalue", when(df_active("alias_pool_cd").isin(list_alias_pool_cd: _*), df_active("alias")))
      val df7 = df5.union(df6)
      val df8 = df7.withColumn("idtype", lit("MRN_CMRN"))

      val groups2 = Window.partitionBy(df8("PERSON_ID"), df8("idvalue")).orderBy(df8("pa_update_date").desc)
      val df9 = df8.withColumn("mrn_row", row_number.over(groups2))
      val dfMRN = df9.filter("mrn_row = 1 and idvalue is not null ")
        .select("PERSON_ID","idtype","idvalue", "id_subtype")



      val df10 = df_active.withColumn("idtype", lit("MRN"))
      val list_rmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val df11 = df10.withColumn("idvalue", when(df10("person_alias_type_cd").isin(list_rmrn_person_alias_type_cd: _*) && df10("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*), df10("alias")))
      val groups3 = Window.partitionBy(df11("PERSON_ID"), df11("idvalue")).orderBy(df11("pa_update_date").desc)
      val df12 = df11.withColumn("rmrn_row", row_number.over(groups3))
      val dfRMRN = df12.filter("rmrn_row = 1 and idvalue is not null ")
        .select("PERSON_ID","idtype","idvalue", "id_subtype")


      dfSSN.union(dfMRN).union(dfRMRN)
    }),
    "H984945_CR2" -> ((df: DataFrame) => {


      val list_rmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_cmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CMRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val list_cmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CMRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val df_active = df.filter(" active_ind = '1' and active_patient_flag = '1' ")
        .withColumn("ID_SUBTYPE",
          when(df("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*), lit("MRN"))
            .when(df("alias_pool_cd").isin(list_cmrn_alias_pool_cd: _*), lit("CMRN"))
            .otherwise(null))



      val list_ssn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val df1 = df_active.withColumn("SSN", when(df_active("person_alias_type_cd").isin(list_ssn_person_alias_type_cd: _*), df_active("alias")))
      val groups1 = Window.partitionBy(df1("PERSON_ID"), df1("person_alias_type_cd")).orderBy(df1("pa_update_date").desc)
      val df2 = df1.withColumn("ssn_row", row_number.over(groups1))
      val df3 = df2.filter("ssn_row = 1 ")
      val satSSN = standardizeSSN("SSN")
      val ssn_inclusion = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN_INCLUSION", "PATIENT_ID", "PERSON_ALIAS", "MEDICALRECORDNUMBER_NOT_NULL")
      val dfSSN1 = satSSN("SSN", df3)
      val dfSSN2 = if(ssn_inclusion == "'Y'") dfSSN1.filter("SSN is not null and MEDICALRECORDNUMBER IS NOT NULL") else dfSSN1.filter("SSN is not null")
      val dfSSN = dfSSN2.withColumn("IDTYPE", lit("SSN")).withColumnRenamed("SSN", "IDVALUE")
        .select("PERSON_ID","idtype","idvalue", "id_subtype")

      val df5 = df_active.withColumn("idvalue", when(df_active("person_alias_type_cd").isin(list_person_alias_type_cd: _*), df_active("alias")))
      val df6 = df_active.withColumn("idvalue", when(df_active("alias_pool_cd").isin(list_alias_pool_cd: _*), df_active("alias")))
      val df7 = df5.union(df6)
      val df8 = df7.withColumn("idtype",lit("MRN"))
        .withColumn("id_subtype",lit("CMRN"))
      val groups2 = Window.partitionBy(df8("PERSON_ID"), df8("idvalue")).orderBy(df8("pa_update_date").desc)
      val df9 = df8.withColumn("mrn_row", row_number.over(groups2))
      val dfMRN = df9.filter("mrn_row = 1 and idvalue is not null ")
        .select("PERSON_ID","idtype","idvalue", "id_subtype")
      val df10 = df_active.withColumn("idtype", lit("MRN"))
      val list_rmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val df11 = df10.withColumn("idvalue", when(df10("person_alias_type_cd").isin(list_rmrn_person_alias_type_cd: _*) && df10("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*), df10("alias")))
        .withColumn("id_subtype", lit(null))
      val groups3 = Window.partitionBy(df11("PERSON_ID"), df11("idvalue")).orderBy(df11("pa_update_date").desc)
      val df12 = df11.withColumn("rmrn_row", row_number.over(groups3))
      val dfRMRN = df12.filter("rmrn_row = 1 and idvalue is not null ")
        .select("PERSON_ID","idtype","idvalue", "id_subtype")


      dfSSN.union(dfMRN).union(dfRMRN)
    }),
    "H_993_CR2" -> ((df: DataFrame) => {

      val list_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "ALIAS_POOL_CD")
      val list_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")

      val df_active = df.filter(" active_ind = '1' and active_patient_flag = '1' ")
        .withColumn("ID_SUBTYPE",
          when(df("alias_pool_cd").isin(list_alias_pool_cd: _*), lit("MRN"))
            .when(df("person_alias_type_cd").isin(list_person_alias_type_cd: _*), lit("CMRN"))
            .otherwise(null))

      val list_ssn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
      val df1 = df_active.withColumn("SSN", when(df_active("person_alias_type_cd").isin(list_ssn_person_alias_type_cd: _*), df_active("alias")))
      val groups1 = Window.partitionBy(df1("PERSON_ID"), df1("person_alias_type_cd")).orderBy(df1("pa_update_date").desc)
      val df2 = df1.withColumn("ssn_row", row_number.over(groups1))
      val df3 = df2.filter("ssn_row = 1 ")
      val satSSN = standardizeSSN("SSN")
      val ssn_inclusion = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN_INCLUSION", "PATIENT_ID", "PERSON_ALIAS", "MEDICALRECORDNUMBER_NOT_NULL")
      val dfSSN1 = satSSN("SSN", df3)
      val dfSSN2 = if(ssn_inclusion == "'Y'") dfSSN1.filter("SSN is not null and MEDICALRECORDNUMBER IS NOT NULL") else dfSSN1.filter("SSN is not null")
      val dfSSN = dfSSN2.withColumn("IDTYPE", lit("SSN")).withColumnRenamed("SSN", "IDVALUE")
        .select("PERSON_ID","idtype","idvalue", "id_subtype")

      val df5 = df_active.withColumn("idvalue", when(df_active("person_alias_type_cd").isin(list_person_alias_type_cd: _*), df_active("alias")))
      val df6 = df5.withColumn("idtype", lit("MRN"))
      val groups2 = Window.partitionBy(df6("PERSON_ID"), df6("idvalue")).orderBy(df6("pa_update_date").desc)
      val df7 = df6.withColumn("mrn_row", row_number.over(groups2))
      val dfCMRN = df7.filter("mrn_row = 1 and idvalue is not null ")
        .select("PERSON_ID","idtype","idvalue", "id_subtype")

      val df8 = df_active.withColumn("idvalue", when(df_active("alias_pool_cd").isin(list_alias_pool_cd: _*), df_active("alias")))
      val df9 = df8.withColumn("idtype", lit("MRN"))
      val groups3 = Window.partitionBy(df9("PERSON_ID"), df9("idvalue")).orderBy(df9("pa_update_date").desc)
      val df10 = df9.withColumn("mrn_row", row_number.over(groups3))
      val dfMRN = df10.filter("mrn_row = 1 and idvalue is not null ")
        .select("PERSON_ID","idtype","idvalue", "id_subtype")


      dfSSN.union(dfMRN).union(dfCMRN)
    }),
    "H743123_CR2" -> ((df: DataFrame) => {

  val list_rmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
  val list_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "ALIAS_POOL_CD")
  val list_cmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CMRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
  val list_cmrn_alias_pool_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "CMRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "ALIAS_POOL_CD")
  val list_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "PATIENT", "PATIENT", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
  val df_active = df.filter(" active_ind = '1' and active_patient_flag = '1' ")
    .withColumn("ID_SUBTYPE",
      when(df("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*), lit("MRN"))
        .when(df("alias_pool_cd").isin(list_cmrn_alias_pool_cd: _*), lit("CMRN"))
        .otherwise(null))
      val df_active1 = df.filter(" ACTIVE_IND_ENC = '1' and ENCNTR_ALIAS_TYPE_CD=1079 ")
        .withColumn("ID_SUBTYPE",
          when(df("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*), lit("MRN"))
            .when(df("alias_pool_cd").isin(list_cmrn_alias_pool_cd: _*), lit("CMRN"))
            .otherwise(null))



  val list_ssn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
  val df1 = df_active.withColumn("SSN", when(df_active("person_alias_type_cd").isin(list_ssn_person_alias_type_cd: _*), df_active("alias")))
  val groups1 = Window.partitionBy(df1("PERSON_ID"), df1("person_alias_type_cd")).orderBy(df1("pa_update_date").desc)
  val df2 = df1.withColumn("ssn_row", row_number.over(groups1))
  val df3 = df2.filter("ssn_row = 1 ")
  val satSSN = standardizeSSN("SSN")

  val ssn_inclusion = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "SSN_INCLUSION", "PATIENT_ID", "PERSON_ALIAS", "MEDICALRECORDNUMBER_NOT_NULL")
  val dfSSN1 = satSSN("SSN", df3)
  val dfSSN2 = if(ssn_inclusion == "'Y'") dfSSN1.filter("SSN is not null and MEDICALRECORDNUMBER IS NOT NULL") else dfSSN1.filter("SSN is not null")
  val dfSSN = dfSSN2.withColumn("IDTYPE", lit("SSN")).withColumnRenamed("SSN", "IDVALUE")
    .select("PERSON_ID","idtype","idvalue", "id_subtype")



      val df5 = df_active1.withColumn("idvalue", df_active1("alias_enc"))
      val df8 = df5.withColumn("idtype", lit("MRN"))
      val groups2 = Window.partitionBy(df8("PERSON_ID_ENCNTR")).orderBy(df8("UPDT_DT_TM_ENC").desc)
      val df9 = df8.withColumn("mrn_row", row_number.over(groups2))
      val dfMRN = df9.filter("mrn_row = 1 and idvalue is not null ")
        .select("PERSON_ID_ENCNTR","idtype","idvalue", "id_subtype")



  val df10 = df_active.withColumn("idtype", lit("MRN"))
  val list_rmrn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "MRN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
  val df11 = df10.withColumn("idvalue", when(df10("person_alias_type_cd").isin(list_rmrn_person_alias_type_cd: _*) && df10("alias_pool_cd").isin(list_rmrn_alias_pool_cd: _*), df10("alias")))
  val groups3 = Window.partitionBy(df11("PERSON_ID"), df11("idvalue")).orderBy(df11("pa_update_date").desc)
  val df12 = df11.withColumn("rmrn_row", row_number.over(groups3))
  val dfRMRN = df12.filter("rmrn_row = 1 and idvalue is not null ")
    .select("PERSON_ID","idtype","idvalue", "id_subtype")

  val df13 = df_active.withColumn("idtype",lit("HICN"))
  val list_hicn_person_alias_type_cd = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "HICN", "PATIENT_IDENTIFIER", "PERSON_ALIAS", "PERSON_ALIAS_TYPE_CD")
  val df14 = df13.withColumn("idvalue", when(df13("person_alias_type_cd").isin(list_hicn_person_alias_type_cd: _*), df13("alias")))
  val groups4 = Window.partitionBy(df14("PERSON_ID"), df14("idvalue")).orderBy(df14("pa_update_date").desc)
  val df15 = df14.withColumn("hicn_row", row_number.over(groups4))
  val dfHICN = df15.filter("hicn_row = 1 and idvalue is not null")
    .select("PERSON_ID","idtype","idvalue", "id_subtype")

  dfSSN.union(dfMRN).union(dfRMRN).union(dfHICN)

    })

  )


  map = Map(
    "DATASRC" -> literal("patient"),
    "PATIENTID" -> mapFrom("PERSON_ID"),
    "idtype" -> mapFrom("IDTYPE"),
    "idvalue" -> mapFrom("IDVALUE"),
    "id_subtype" -> mapFrom("ID_SUBTYPE")
  )

}

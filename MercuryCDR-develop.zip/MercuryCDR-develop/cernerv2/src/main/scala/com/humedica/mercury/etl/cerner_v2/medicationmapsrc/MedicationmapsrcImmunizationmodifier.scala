package com.humedica.mercury.etl.cerner_v2.medicationmapsrc

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcImmunizationmodifier(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "immunization_modifier",
    "clinical_event",
    "zh_code_value",
    "zh_order_catalog_item_r",
    "zh_med_identifier",
    "cdr.map_predicate_values"
  )

  columnSelect = Map(
    "immunization_modifier" -> List("EVENT_ID"),
    "clinical_event" -> List("EVENT_ID", "EVENT_CLASS_CD", "EVENT_CD", "CATALOG_CD"),
    "zh_code_value" -> List("DISPLAY", "CODE_VALUE"),
    "zh_order_catalog_item_r" -> List("CATALOG_CD", "ITEM_ID"),
    "zh_med_identifier" -> List("VALUE", "VALUE_KEY", "MED_IDENTIFIER_TYPE_CD", "ITEM_ID", "ACTIVE_IND")
  )

  beforeJoin = Map(
    "clinical_event" -> ((df: DataFrame) => {
      val list_event_class_cd = mpvClause(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "IMMUNIZATION_MODIFIER",
                                          "IMMUNIZATION", "CLINICAL_EVENT", "EVENT_CLASS_CD")
      df.filter("EVENT_CLASS_CD in (" + list_event_class_cd + ")")
    }),
    "zh_med_identifier" -> ((df: DataFrame) => {
      df.filter("ACTIVE_IND = '1'")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val list_local_drug_desc = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "LOCALDRUGDESC",
      "TEMP_MEDS_" + config(GROUP), "ZH_MED_IDENTIFIER", "MED_IDENTIFIER_TYPE_CD")

    val im_df = dfs("immunization_modifier")
    val clc_df = dfs("clinical_event")
    val zh_ord_df = dfs("zh_order_catalog_item_r")
    val zh_med = dfs("zh_med_identifier")
    val zh_code = dfs("zh_code_value")

    val joined = im_df.join(clc_df, clc_df("EVENT_ID") === im_df("EVENT_ID"), "inner")
                      .join(zh_ord_df, zh_ord_df("CATALOG_CD") === clc_df("CATALOG_CD"), "inner")
                      .join(zh_med, zh_ord_df("ITEM_ID") === zh_med("ITEM_ID"), "inner")
                      .select(zh_ord_df("CATALOG_CD")
                        ,when(zh_med("VALUE").rlike("^[0-9]{5}-[0-9]{4}-[0-9]{1,2}$"), zh_med("VALUE_KEY")).otherwise(null).as("LOCALNDC")
                        ,when(zh_med("MED_IDENTIFIER_TYPE_CD").isin(list_local_drug_desc: _*), zh_med("VALUE")).otherwise(null).as("LOCALGENERIC"))

    val med_df = joined.groupBy(joined("CATALOG_CD"), joined("LOCALNDC")).agg(max(joined("LOCALGENERIC")).as("LOCALGEN"))

    im_df.join(clc_df, im_df("EVENT_ID") === clc_df("EVENT_ID"), "inner")
         .join(zh_code, zh_code("CODE_VALUE") === clc_df("EVENT_CD"), "left_outer")
         .join(med_df, med_df("CATALOG_CD") === clc_df("CATALOG_CD"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("immunization_modifier"),
    "LOCALMEDCODE" -> mapFrom("EVENT_CD"),
    "LOCALGENERIC" -> mapFrom("LOCALGEN"),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, lower(df("DISPLAY")))),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, normalizeNDC(df, "LOCALNDC"))),
    "NDC_SRC" -> literal("src")
  )

  afterMap = (df: DataFrame) => {
    val group_df = Window.partitionBy(df("LOCALMEDCODE"), df("LOCALDESCRIPTION"), df("LOCALNDC"), df("LOCALGENERIC"))
    val df1 = df.withColumn("NO_NDC", sum(when(substring(df("LOCALNDC"), 1, 11).isNull, 1).otherwise(0)).over(group_df))
      .withColumn("HAS_NDC", sum(when(substring(df("LOCALNDC"), 1, 11).isNull, 0).otherwise(1)).over(group_df))
      .withColumn("NUM_RECS", count(lit(1)).over(group_df))
      .withColumn("LOCALDESCRIPTION_NEW", coalesce(df("LOCALDESCRIPTION"), df("LOCALGENERIC")))
      .drop("LOCALDESCRIPTION")
      .withColumnRenamed("LOCALDESCRIPTION_NEW","LOCALDESCRIPTION")

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcImmunizationmodifier(cfg); val med_s = build(a, allColumns = true) ;

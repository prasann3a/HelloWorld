package com.humedica.mercury.etl.cerner_v2.medicationmapsrc

import com.humedica.mercury.etl.core.engine.Constants._
import com.humedica.mercury.etl.core.engine.{Engine, EntitySource}
import com.humedica.mercury.etl.core.engine.Functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import scala.collection.JavaConverters._

class MedicationmapsrcOrdercompliance(config: Map[String,String]) extends EntitySource(config: Map[String,String]) {
  tables = List(
    "orders",
    "zh_code_value",
    "zh_order_catalog_item_r",
    "zh_med_identifier",
    "cdr.map_predicate_values"
  )

  columnSelect = Map(
    "orders" -> List("ACTIVITY_TYPE_CD", "CATALOG_CD", "TEMPLATE_ORDER_ID", "ORIG_ORD_AS_FLAG", "ACTIVE_IND"),
    "zh_code_value" -> List("CODE_VALUE", "CODE_SET", "DISPLAY"),
    "zh_order_catalog_item_r" -> List("CATALOG_CD", "ITEM_ID"),
    "zh_med_identifier" -> List("VALUE", "VALUE_KEY", "MED_IDENTIFIER_TYPE_CD", "ACTIVE_IND", "ITEM_ID")
  )

  beforeJoin = Map(
    "orders"-> ((df: DataFrame) => {
      val list_activity_type_cd = mpvClause(table("cdr.map_predicate_values"), config(GROUP), null, "ORDERS", "RX",
                                            "ORDERS", "ACTIVITY_TYPE_CD")
      df.filter("TEMPLATE_ORDER_ID = '0' " +
        "AND ORIG_ORD_AS_FLAG in ('0', '1', '2', '4', '5') " +
        "AND ACTIVE_IND != '0' AND ACTIVITY_TYPE_CD in (" + list_activity_type_cd + ")")
    }),
    "zh_med_identifier" -> ((df: DataFrame) => {
      df.filter("ACTIVE_IND = '1'")
    }),
    "zh_code_value" -> ((df: DataFrame) => {
      df.filter("CODE_SET = '200'")
    })
  )

  join = (dfs: Map[String, DataFrame]) => {
    val list_local_drug_desc = mpvList1(table("cdr.map_predicate_values"), config(GROUP), config(CLIENT_DS_ID), "LOCALDRUGDESC",
      "TEMP_MEDS_" + config(GROUP), "ZH_MED_IDENTIFIER", "MED_IDENTIFIER_TYPE_CD")

    val zh_ord_df = dfs("zh_order_catalog_item_r").withColumnRenamed("CATALOG_CD", "ZH_ORDER_CATALOG_CD")
    val orders_df = dfs("orders")
    val zh_med_df = dfs("zh_med_identifier")
    val zh_code_df = dfs("zh_code_value")

    val joined = zh_ord_df.join(zh_med_df, zh_ord_df("ITEM_ID") === zh_med_df("ITEM_ID"), "inner")
                          .select(zh_ord_df("ZH_ORDER_CATALOG_CD")
                            ,when(zh_med_df("VALUE").rlike("^[0-9]{5}-[0-9]{4}-[0-9]{1,2}$"), zh_med_df("VALUE_KEY")).otherwise(null).as("ZH_MED_LOCALNDC")
                            ,when(zh_med_df("MED_IDENTIFIER_TYPE_CD").isin(list_local_drug_desc: _*), zh_med_df("VALUE")).otherwise(null).as("ZH_MED_LOCALGENERIC"))

    val med_df = joined.groupBy(joined("ZH_ORDER_CATALOG_CD"), joined("ZH_MED_LOCALNDC")).agg(max(joined("ZH_MED_LOCALGENERIC")).as("LOCALGEN"))

    orders_df.join(zh_code_df, zh_code_df("CODE_VALUE") === orders_df("CATALOG_CD"), "left_outer")
             .join(med_df, med_df("ZH_ORDER_CATALOG_CD") === orders_df("CATALOG_CD"), "left_outer")
  }

  map = Map(
    "DATASRC" -> literal("order_compliance"),
    "LOCALMEDCODE" -> mapFrom("CATALOG_CD"),
    "LOCALDESCRIPTION" -> ((col, df) => df.withColumn(col, lower(df("DISPLAY")))),
    "LOCALNDC" -> ((col, df) => df.withColumn(col, normalizeNDC(df, "ZH_MED_LOCALNDC"))),
    "NDC_SRC" -> literal("src")
  )

  afterMap = (df: DataFrame) => {
    val group_df = Window.partitionBy(df("LOCALMEDCODE"), df("ZH_MED_LOCALNDC"), df("DISPLAY"))
    val addColumn_df = df.withColumn("LOCALGENERIC", max(df("LOCALGEN")).over(group_df))
                         .withColumn("NO_NDC", sum(when(substring(df("ZH_MED_LOCALNDC"), 1, 11).isNull, 1).otherwise(0)).over(group_df))
                         .withColumn("HAS_NDC", sum(when(substring(df("ZH_MED_LOCALNDC"), 1, 11).isNull, 0).otherwise(1)).over(group_df))
                         .withColumn("NUM_RECS", count(lit(1)).over(group_df))

    val df1 = addColumn_df.withColumn("LOCALDESCRIPTION_NEW", coalesce(addColumn_df("LOCALDESCRIPTION"), addColumn_df("LOCALGENERIC")))
                          .drop("LOCALDESCRIPTION")
                          .withColumnRenamed("LOCALDESCRIPTION_NEW","LOCALDESCRIPTION")

    val cols = Engine.schema.getStringList("Medicationmapsrc").asScala.map(_.split("-")(0).toUpperCase())
    df1.select(cols.map(col): _*).distinct()
  }
}

//val a = new MedicationmapsrcOrdercompliance(cfg); val med_s = build(a, allColumns = true) ;

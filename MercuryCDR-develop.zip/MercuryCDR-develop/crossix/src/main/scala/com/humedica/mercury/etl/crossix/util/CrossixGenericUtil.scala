package com.humedica.mercury.etl.crossix.util

import com.humedica.mercury.etl.core.engine.EntitySource
import org.apache.spark.sql.DataFrame

/**
  * Created by rbabu on 5/1/18.
  */
object CrossixGenericUtil {

    def build(entitySource: EntitySource):DataFrame={
        // Toolkit.build(entitySource, allColumns = true)
      null
    }

    def summary(dataFrame: DataFrame) = {
        // com.humedica.mercury.etl.core.metrics.Metrics.summary(dataFrame).show(100, false)
    }
}
